package com.jio.hook.saml.filter;

import com.jio.hook.common.util.JioSamlUtil;
import com.jio.portlet.saml.model.SamlSession;
import com.jio.portlet.saml.profile.SingleLogoutProfileUtil;
import com.jio.portlet.saml.profile.WebSsoProfileUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.BaseFilter;
import com.liferay.portal.kernel.struts.LastPath;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.HttpUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.util.PortalUtil;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SamlFilter extends BaseFilter {
	public boolean isFilterEnabled() {
		if (JioSamlUtil.isEnabled()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isFilterEnabled(HttpServletRequest request,
			HttpServletResponse response) {

		if (!JioSamlUtil.isEnabled() ) {
			return false;
		}

		try {
			User user = PortalUtil.getUser(request);

			if (user != null) {
				return true;
			}
		} catch (Exception e) {
			if (_log.isWarnEnabled()) {
				_log.warn(e, e);
			}
		}

		String requestPath = JioSamlUtil.getRequestPath(request);

		if (requestPath.equals("/c/portal/login")
				|| requestPath.equals("/c/portal/logout")) {

			return true;
		}

		return false;
	}

	protected Log getLog() {
		return _log;
	}

	protected void login(HttpServletRequest request,
			HttpServletResponse response) throws PortalException,
			SystemException {

		String relayState = ParamUtil.getString(request, "redirect");

		if (Validator.isNotNull(relayState)) {
			relayState = PortalUtil.escapeRedirect(relayState);
		}

		HttpSession session = request.getSession();

		LastPath lastPath = (LastPath) session.getAttribute(WebKeys.LAST_PATH);

		if (GetterUtil.getBoolean(PropsUtil
				.get(PropsKeys.AUTH_FORWARD_BY_LAST_PATH))
				&& (lastPath != null) && Validator.isNull(relayState)) {

			StringBundler sb = new StringBundler(4);

			sb.append(PortalUtil.getPortalURL(request));
			sb.append(lastPath.getContextPath());
			sb.append(lastPath.getPath());
			sb.append(HttpUtil.parameterMapToString(lastPath.getParameterMap()));

			relayState = sb.toString();
		} else if (Validator.isNull(relayState)) {
			relayState = PortalUtil.getPathMain();
		}

		WebSsoProfileUtil.sendAuthnRequest(request, response, relayState);
	}

	protected void processFilter(HttpServletRequest request,
			HttpServletResponse response, FilterChain filterChain)
			throws Exception {

		String requestPath = JioSamlUtil.getRequestPath(request);

		if (requestPath.equals("/c/portal/login")) {
			login(request, response);
		} else if (requestPath.equals("/c/portal/logout")
				&& SingleLogoutProfileUtil.isSingleLogoutSupported(request)) {

			SamlSession samlSession = SingleLogoutProfileUtil
					.getSamlSession(request);

			if (samlSession != null) {
				SingleLogoutProfileUtil.processSpLogout(request, response);
			} else {
				filterChain.doFilter(request, response);
			}
		} else {
			SamlSession samlSpSession = SingleLogoutProfileUtil
					.getSamlSession(request);

			if ((samlSpSession != null) && samlSpSession.isTerminated()) {
				SingleLogoutProfileUtil.terminateSpSession(request, response);

				SingleLogoutProfileUtil.logout(request, response);

				response.sendRedirect(PortalUtil.getCurrentCompleteURL(request));
			} else {
				WebSsoProfileUtil.updateSamlSession(request, response);

				filterChain.doFilter(request, response);
			}
		}
	}

	private static Log _log = LogFactoryUtil.getLog(SamlFilter.class);
}
