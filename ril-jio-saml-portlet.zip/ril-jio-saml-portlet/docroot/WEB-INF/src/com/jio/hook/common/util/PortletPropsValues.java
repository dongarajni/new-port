package com.jio.hook.common.util;

import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.util.portlet.PortletProps;

public class PortletPropsValues {

	public static final boolean SAML_ENABLED = GetterUtil.getBoolean(
			PropsUtil.get(PortletPropsKeys.SAML_ENABLED), false);

	public static final long SAML_METADATA_MAX_REFRESH_DELAY = GetterUtil
			.getLong(PortletProps
					.get(PortletPropsKeys.SAML_METADATA_MAX_REFRESH_DELAY),
					14400000);

	public static final int SAML_METADATA_MIN_REFRESH_DELAY = GetterUtil
			.getInteger(PortletProps
					.get(PortletPropsKeys.SAML_METADATA_MIN_REFRESH_DELAY),
					300000);

	public static final int SAML_REPLAY_CACHE_DURATION = GetterUtil.getInteger(
			PortletProps.get(PortletPropsKeys.SAML_REPLAY_CACHE_DURATION),
			3600000);
	
	public static final String SAML_KEYSTORE_MANAGER_IMPL = PortletProps.get(
			PortletPropsKeys.SAML_KEYSTORE_MANAGER_IMPL);

}
