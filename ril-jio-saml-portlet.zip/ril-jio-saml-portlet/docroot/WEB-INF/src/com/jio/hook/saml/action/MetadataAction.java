
package com.jio.hook.saml.action;

import com.jio.hook.common.util.OpenSamlUtil;
import com.jio.portlet.saml.metadata.MetadataManagerUtil;
import com.liferay.portal.kernel.util.ContentTypes;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.opensaml.saml2.metadata.EntityDescriptor;


public class MetadataAction extends BaseSamlStrutsAction {


	protected String doExecute(
			HttpServletRequest request, HttpServletResponse response)
		throws Exception {

		response.setContentType(ContentTypes.TEXT_XML);

		EntityDescriptor entityDescriptor =
			MetadataManagerUtil.getEntityDescriptor(request);

		String metadata = OpenSamlUtil.marshall(entityDescriptor);

		PrintWriter printWriter = response.getWriter();

		printWriter.print(metadata);

		return null;
	}

}