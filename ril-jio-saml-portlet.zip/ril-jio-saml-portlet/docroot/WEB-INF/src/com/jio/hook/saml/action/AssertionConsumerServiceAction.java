
package com.jio.hook.saml.action;

import com.jio.portlet.saml.profile.WebSsoProfileUtil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class AssertionConsumerServiceAction extends BaseSamlStrutsAction {




	protected String doExecute(
			HttpServletRequest request, HttpServletResponse response)
		throws Exception {

		WebSsoProfileUtil.processResponse(request, response);

		return null;
	}

}