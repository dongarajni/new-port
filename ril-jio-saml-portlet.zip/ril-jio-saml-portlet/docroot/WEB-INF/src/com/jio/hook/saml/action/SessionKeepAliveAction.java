package com.jio.hook.saml.action;

import com.liferay.portal.kernel.servlet.HttpHeaders;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SessionKeepAliveAction extends BaseSamlStrutsAction {

	protected String doExecute(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		executeSpSessionKeepAlive(request, response);

		return null;
	}

	protected void executeSpSessionKeepAlive(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		response.setHeader(HttpHeaders.CACHE_CONTROL,
				HttpHeaders.CACHE_CONTROL_NO_CACHE_VALUE);
		response.setHeader(HttpHeaders.PRAGMA,
				HttpHeaders.PRAGMA_NO_CACHE_VALUE);

		RequestDispatcher requestDispatcher = request
				.getRequestDispatcher("/html/themes/_unstyled/spacer.png");

		requestDispatcher.forward(request, response);
	}

}