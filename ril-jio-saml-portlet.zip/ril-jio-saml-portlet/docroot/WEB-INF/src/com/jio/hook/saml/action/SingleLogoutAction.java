package com.jio.hook.saml.action;

import com.jio.portlet.saml.profile.SingleLogoutProfileUtil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class SingleLogoutAction extends BaseSamlStrutsAction {

	protected String doExecute(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		SingleLogoutProfileUtil.processSingleLogout(request, response);

		return null;
	}

}