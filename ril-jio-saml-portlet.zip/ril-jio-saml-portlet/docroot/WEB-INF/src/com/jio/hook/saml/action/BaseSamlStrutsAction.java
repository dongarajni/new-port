
package com.jio.hook.saml.action;

import com.jio.hook.common.util.JioSamlUtil;
import com.jio.hook.common.util.JspUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.struts.BaseStrutsAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




public abstract class BaseSamlStrutsAction extends BaseStrutsAction {


	public String execute(
			HttpServletRequest request, HttpServletResponse response)
		throws Exception {

		if (!isEnabled()) {
			return "/common/referer_js.jsp";
		}

		try {
			return doExecute(request, response);
		}
		catch (Exception e) {
			_log.error(e, e);

			SessionErrors.add(request, e.getClass().getName());

			JspUtil.dispatch(
				request, response, JspUtil.PATH_PORTAL_SAML_ERROR, "status");
		}

		return null;
	}

	public boolean isEnabled() {
		return JioSamlUtil.isEnabled();
	}

	protected abstract String doExecute(
			HttpServletRequest request, HttpServletResponse response)
		throws Exception;

	private static Log _log = LogFactoryUtil.getLog(BaseSamlStrutsAction.class);

}