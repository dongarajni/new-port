package com.jio.hook.saml.event;

import com.jio.hook.common.util.JioSamlUtil;
import com.jio.portlet.saml.model.SamlSession;
import com.jio.portlet.saml.service.SamlSessionLocalServiceUtil;
import com.liferay.portal.kernel.events.ActionException;
import com.liferay.portal.kernel.events.SessionAction;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;

import javax.servlet.http.HttpSession;

public class SamlSessionDestroyAction extends SessionAction {


	public void run(HttpSession session) throws ActionException {
		if (!JioSamlUtil.isEnabled() ) {
			return;
		}

		try {
			SamlSession samlSpSession =
				SamlSessionLocalServiceUtil.getSamlSessionByJSessionId(
					session.getId());

			if (_log.isDebugEnabled()) {
				_log.debug(
					"HTTP session " + session.getId() +
						" expiring SAML SP session " +
							samlSpSession.getSessionKey());
			}

			SamlSessionLocalServiceUtil.deleteSamlSession(
				samlSpSession.getSessionId());
		}
		catch (Exception e) {
		}
	}

	private static Log _log = LogFactoryUtil.getLog(
		SamlSessionDestroyAction.class);

}