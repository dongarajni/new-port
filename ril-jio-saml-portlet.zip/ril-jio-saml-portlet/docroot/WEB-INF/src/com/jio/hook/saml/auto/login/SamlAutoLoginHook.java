package com.jio.hook.saml.auto.login;

import com.jio.hook.common.util.JioSamlUtil;
import com.jio.portlet.saml.model.SamlSession;
import com.jio.portlet.saml.profile.WebSsoProfileUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.model.User;
import com.liferay.portal.security.auth.AutoLoginException;
import com.liferay.portal.security.auth.BaseAutoLogin;
import com.liferay.portal.service.UserLocalServiceUtil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SamlAutoLoginHook extends BaseAutoLogin {

	@Override
	protected String[] doLogin(HttpServletRequest request,
			HttpServletResponse response) throws AutoLoginException {

		try {
			if (!JioSamlUtil.isSamlEnabled()) {
				return null;
			}

			SamlSession samlSpSession = WebSsoProfileUtil
					.getSamlSession(request);

			if (samlSpSession == null) {
				return null;
			}

			User user = UserLocalServiceUtil.fetchUser(samlSpSession
					.getUserId());

			if (user == null) {
				return null;
			}

			String[] credentials = new String[3];

			credentials[0] = String.valueOf(user.getUserId());
			credentials[1] = user.getPassword();
			credentials[2] = Boolean.TRUE.toString();

			return credentials;
		} catch (Exception e) {
			_log.warn(e, e);

			throw new AutoLoginException(e);
		}
	}

	private static Log _log = LogFactoryUtil.getLog(SamlAutoLoginHook.class);

}
