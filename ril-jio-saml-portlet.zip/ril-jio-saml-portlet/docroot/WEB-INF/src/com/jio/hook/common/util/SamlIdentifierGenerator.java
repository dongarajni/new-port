package com.jio.hook.common.util;

import com.liferay.portal.kernel.security.SecureRandom;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.UnicodeFormatter;

import org.opensaml.common.IdentifierGenerator;

public class SamlIdentifierGenerator implements IdentifierGenerator {


	public String generateIdentifier() {
		return generateIdentifier(16);
	}


	public String generateIdentifier(int size) {
		byte[] bytes = new byte[size];

		_secureRandom.nextBytes(bytes);

		return StringPool.UNDERLINE.concat(UnicodeFormatter.bytesToHex(bytes));
	}

	private SecureRandom _secureRandom = new SecureRandom();

}