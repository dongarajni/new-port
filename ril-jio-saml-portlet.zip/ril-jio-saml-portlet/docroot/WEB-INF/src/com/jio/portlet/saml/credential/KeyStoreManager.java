package com.jio.portlet.saml.credential;

import java.security.KeyStore;

public interface KeyStoreManager {

	public KeyStore getKeyStore();

	public void saveKeyStore(KeyStore keyStore) throws Exception;

}