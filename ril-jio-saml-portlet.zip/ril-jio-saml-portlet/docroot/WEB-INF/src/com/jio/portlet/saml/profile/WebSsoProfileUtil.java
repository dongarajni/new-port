package com.jio.portlet.saml.profile;

import com.jio.portlet.saml.model.SamlSession;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class WebSsoProfileUtil {

	public static SamlSession getSamlSession(HttpServletRequest request)
		throws SystemException {

		return getWebSsoProfile().getSamlSession(request);
	}

	public static WebSsoProfile getWebSsoProfile() {
		return _webSsoProfile;
	}


	public static void processResponse(
			HttpServletRequest request, HttpServletResponse response)
		throws PortalException, SystemException {

		getWebSsoProfile().processResponse(request, response);
	}

	public static void sendAuthnRequest(
			HttpServletRequest request, HttpServletResponse response,
			String relayState)
		throws PortalException, SystemException {

		getWebSsoProfile().sendAuthnRequest(request, response, relayState);
	}

	public static void updateSamlSession(
			HttpServletRequest request, HttpServletResponse response)
		throws SystemException {

		getWebSsoProfile().updateSamlSession(request, response);
	}

	public void setWebSsoProfile(WebSsoProfile webSsoProfile) {
		_webSsoProfile = webSsoProfile;
	}

	private static WebSsoProfile _webSsoProfile;

}