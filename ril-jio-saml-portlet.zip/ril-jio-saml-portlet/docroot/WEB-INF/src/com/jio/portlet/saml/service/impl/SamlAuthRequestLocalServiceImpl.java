/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.service.impl;

import com.jio.portlet.saml.model.SamlAuthRequest;
import com.jio.portlet.saml.service.base.SamlAuthRequestLocalServiceBaseImpl;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.service.ServiceContext;

import java.util.Date;

/**
 * The implementation of the saml auth request local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jio.portlet.saml.service.SamlAuthRequestLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Liferay Developer
 * @see com.jio.portlet.saml.service.base.SamlAuthRequestLocalServiceBaseImpl
 * @see com.jio.portlet.saml.service.SamlAuthRequestLocalServiceUtil
 */
public class SamlAuthRequestLocalServiceImpl
	extends SamlAuthRequestLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.jio.portlet.saml.service.SamlAuthRequestLocalServiceUtil} to access the saml auth request local service.
	 */
	
	public SamlAuthRequest addSamlAuthRequest(
			String samlIdpEntityId, String samlSpAuthRequestKey,
			ServiceContext serviceContext)
		throws SystemException {

		long samlAuthRequestId = counterLocalService.increment(
			SamlAuthRequest.class.getName());

		SamlAuthRequest samlAuthRequest =
			samlAuthRequestPersistence.create(samlAuthRequestId);

		samlAuthRequest.setCompanyId(serviceContext.getCompanyId());
		samlAuthRequest.setCreateDate(new Date());
		samlAuthRequest.setEntityId(samlIdpEntityId);
		samlAuthRequest.setAuthRequestKey(samlSpAuthRequestKey);

		samlAuthRequestPersistence.update(samlAuthRequest);

		return samlAuthRequest;
	}


	public SamlAuthRequest fetchSamlAuthRequest(
			String samlIdpEntityId, String samlSpAuthRequestKey)
		throws SystemException {

		return samlAuthRequestPersistence.fetchByEntityId_AuthReqKey(
			samlIdpEntityId, samlSpAuthRequestKey);
	}


	public SamlAuthRequest getSamlAuthRequest(
			String samlIdpEntityId, String samlSpAuthRequestKey)
		throws PortalException, SystemException {

		return samlAuthRequestPersistence.findByEntityId_AuthReqKey(
			samlIdpEntityId, samlSpAuthRequestKey);
	}
}