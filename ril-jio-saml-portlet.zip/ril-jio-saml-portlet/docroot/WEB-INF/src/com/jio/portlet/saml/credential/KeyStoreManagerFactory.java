package com.jio.portlet.saml.credential;

import com.jio.hook.common.util.PortletPropsValues;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.InstanceFactory;

public class KeyStoreManagerFactory {

	public static KeyStoreManager getInstance() {
		if (_keyStoreManager != null) {
			return _keyStoreManager;
		}

		Thread currentThread = Thread.currentThread();

		ClassLoader classLoader = currentThread.getContextClassLoader();

		try {
			_keyStoreManager = (KeyStoreManager)InstanceFactory.newInstance(
				classLoader, PortletPropsValues.SAML_KEYSTORE_MANAGER_IMPL);
		}
		catch (Exception e) {
			_log.error(
				"Unable to load keystore manager class " +
					PortletPropsValues.SAML_KEYSTORE_MANAGER_IMPL,
				e);
		}

		return _keyStoreManager;
	}

	private static Log _log = LogFactoryUtil.getLog(
		KeyStoreManagerFactory.class);

	private static KeyStoreManager _keyStoreManager;

}