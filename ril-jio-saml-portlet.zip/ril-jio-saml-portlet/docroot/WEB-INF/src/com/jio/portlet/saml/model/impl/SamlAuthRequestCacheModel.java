/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.model.impl;

import com.jio.portlet.saml.model.SamlAuthRequest;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing SamlAuthRequest in entity cache.
 *
 * @author Ashish Jadhav
 * @see SamlAuthRequest
 * @generated
 */
public class SamlAuthRequestCacheModel implements CacheModel<SamlAuthRequest>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{samlAuthnRequestId=");
		sb.append(samlAuthnRequestId);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", entityId=");
		sb.append(entityId);
		sb.append(", authRequestKey=");
		sb.append(authRequestKey);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public SamlAuthRequest toEntityModel() {
		SamlAuthRequestImpl samlAuthRequestImpl = new SamlAuthRequestImpl();

		samlAuthRequestImpl.setSamlAuthnRequestId(samlAuthnRequestId);
		samlAuthRequestImpl.setCompanyId(companyId);

		if (createDate == Long.MIN_VALUE) {
			samlAuthRequestImpl.setCreateDate(null);
		}
		else {
			samlAuthRequestImpl.setCreateDate(new Date(createDate));
		}

		if (entityId == null) {
			samlAuthRequestImpl.setEntityId(StringPool.BLANK);
		}
		else {
			samlAuthRequestImpl.setEntityId(entityId);
		}

		if (authRequestKey == null) {
			samlAuthRequestImpl.setAuthRequestKey(StringPool.BLANK);
		}
		else {
			samlAuthRequestImpl.setAuthRequestKey(authRequestKey);
		}

		samlAuthRequestImpl.resetOriginalValues();

		return samlAuthRequestImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		samlAuthnRequestId = objectInput.readLong();
		companyId = objectInput.readLong();
		createDate = objectInput.readLong();
		entityId = objectInput.readUTF();
		authRequestKey = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(samlAuthnRequestId);
		objectOutput.writeLong(companyId);
		objectOutput.writeLong(createDate);

		if (entityId == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(entityId);
		}

		if (authRequestKey == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(authRequestKey);
		}
	}

	public long samlAuthnRequestId;
	public long companyId;
	public long createDate;
	public String entityId;
	public String authRequestKey;
}