/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.service.persistence;

import com.jio.portlet.saml.NoSuchSamlIdpConnectionException;
import com.jio.portlet.saml.model.SamlIdpConnection;
import com.jio.portlet.saml.model.impl.SamlIdpConnectionImpl;
import com.jio.portlet.saml.model.impl.SamlIdpConnectionModelImpl;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the saml idp connection service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Ashish Jadhav
 * @see SamlIdpConnectionPersistence
 * @see SamlIdpConnectionUtil
 * @generated
 */
public class SamlIdpConnectionPersistenceImpl extends BasePersistenceImpl<SamlIdpConnection>
	implements SamlIdpConnectionPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link SamlIdpConnectionUtil} to access the saml idp connection persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = SamlIdpConnectionImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(SamlIdpConnectionModelImpl.ENTITY_CACHE_ENABLED,
			SamlIdpConnectionModelImpl.FINDER_CACHE_ENABLED,
			SamlIdpConnectionImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(SamlIdpConnectionModelImpl.ENTITY_CACHE_ENABLED,
			SamlIdpConnectionModelImpl.FINDER_CACHE_ENABLED,
			SamlIdpConnectionImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(SamlIdpConnectionModelImpl.ENTITY_CACHE_ENABLED,
			SamlIdpConnectionModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_COMPANYID =
		new FinderPath(SamlIdpConnectionModelImpl.ENTITY_CACHE_ENABLED,
			SamlIdpConnectionModelImpl.FINDER_CACHE_ENABLED,
			SamlIdpConnectionImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCompanyId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANYID =
		new FinderPath(SamlIdpConnectionModelImpl.ENTITY_CACHE_ENABLED,
			SamlIdpConnectionModelImpl.FINDER_CACHE_ENABLED,
			SamlIdpConnectionImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCompanyId",
			new String[] { Long.class.getName() },
			SamlIdpConnectionModelImpl.COMPANYID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_COMPANYID = new FinderPath(SamlIdpConnectionModelImpl.ENTITY_CACHE_ENABLED,
			SamlIdpConnectionModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCompanyId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the saml idp connections where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching saml idp connections
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SamlIdpConnection> findByCompanyId(long companyId)
		throws SystemException {
		return findByCompanyId(companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the saml idp connections where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlIdpConnectionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of saml idp connections
	 * @param end the upper bound of the range of saml idp connections (not inclusive)
	 * @return the range of matching saml idp connections
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SamlIdpConnection> findByCompanyId(long companyId, int start,
		int end) throws SystemException {
		return findByCompanyId(companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the saml idp connections where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlIdpConnectionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of saml idp connections
	 * @param end the upper bound of the range of saml idp connections (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching saml idp connections
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SamlIdpConnection> findByCompanyId(long companyId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANYID;
			finderArgs = new Object[] { companyId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_COMPANYID;
			finderArgs = new Object[] { companyId, start, end, orderByComparator };
		}

		List<SamlIdpConnection> list = (List<SamlIdpConnection>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (SamlIdpConnection samlIdpConnection : list) {
				if ((companyId != samlIdpConnection.getCompanyId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_SAMLIDPCONNECTION_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SamlIdpConnectionModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<SamlIdpConnection>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SamlIdpConnection>(list);
				}
				else {
					list = (List<SamlIdpConnection>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first saml idp connection in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching saml idp connection
	 * @throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException if a matching saml idp connection could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlIdpConnection findByCompanyId_First(long companyId,
		OrderByComparator orderByComparator)
		throws NoSuchSamlIdpConnectionException, SystemException {
		SamlIdpConnection samlIdpConnection = fetchByCompanyId_First(companyId,
				orderByComparator);

		if (samlIdpConnection != null) {
			return samlIdpConnection;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSamlIdpConnectionException(msg.toString());
	}

	/**
	 * Returns the first saml idp connection in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching saml idp connection, or <code>null</code> if a matching saml idp connection could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlIdpConnection fetchByCompanyId_First(long companyId,
		OrderByComparator orderByComparator) throws SystemException {
		List<SamlIdpConnection> list = findByCompanyId(companyId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last saml idp connection in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching saml idp connection
	 * @throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException if a matching saml idp connection could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlIdpConnection findByCompanyId_Last(long companyId,
		OrderByComparator orderByComparator)
		throws NoSuchSamlIdpConnectionException, SystemException {
		SamlIdpConnection samlIdpConnection = fetchByCompanyId_Last(companyId,
				orderByComparator);

		if (samlIdpConnection != null) {
			return samlIdpConnection;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSamlIdpConnectionException(msg.toString());
	}

	/**
	 * Returns the last saml idp connection in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching saml idp connection, or <code>null</code> if a matching saml idp connection could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlIdpConnection fetchByCompanyId_Last(long companyId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByCompanyId(companyId);

		if (count == 0) {
			return null;
		}

		List<SamlIdpConnection> list = findByCompanyId(companyId, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the saml idp connections before and after the current saml idp connection in the ordered set where companyId = &#63;.
	 *
	 * @param samlIdpConnectionId the primary key of the current saml idp connection
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next saml idp connection
	 * @throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException if a saml idp connection with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlIdpConnection[] findByCompanyId_PrevAndNext(
		long samlIdpConnectionId, long companyId,
		OrderByComparator orderByComparator)
		throws NoSuchSamlIdpConnectionException, SystemException {
		SamlIdpConnection samlIdpConnection = findByPrimaryKey(samlIdpConnectionId);

		Session session = null;

		try {
			session = openSession();

			SamlIdpConnection[] array = new SamlIdpConnectionImpl[3];

			array[0] = getByCompanyId_PrevAndNext(session, samlIdpConnection,
					companyId, orderByComparator, true);

			array[1] = samlIdpConnection;

			array[2] = getByCompanyId_PrevAndNext(session, samlIdpConnection,
					companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected SamlIdpConnection getByCompanyId_PrevAndNext(Session session,
		SamlIdpConnection samlIdpConnection, long companyId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SAMLIDPCONNECTION_WHERE);

		query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SamlIdpConnectionModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(companyId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(samlIdpConnection);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<SamlIdpConnection> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the saml idp connections where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByCompanyId(long companyId) throws SystemException {
		for (SamlIdpConnection samlIdpConnection : findByCompanyId(companyId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(samlIdpConnection);
		}
	}

	/**
	 * Returns the number of saml idp connections where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching saml idp connections
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByCompanyId(long companyId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_COMPANYID;

		Object[] finderArgs = new Object[] { companyId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_SAMLIDPCONNECTION_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_COMPANYID_COMPANYID_2 = "samlIdpConnection.companyId = ?";
	public static final FinderPath FINDER_PATH_FETCH_BY_COMPANYID_IDPENTITYID = new FinderPath(SamlIdpConnectionModelImpl.ENTITY_CACHE_ENABLED,
			SamlIdpConnectionModelImpl.FINDER_CACHE_ENABLED,
			SamlIdpConnectionImpl.class, FINDER_CLASS_NAME_ENTITY,
			"fetchByCompanyId_IdpEntityId",
			new String[] { Long.class.getName(), String.class.getName() },
			SamlIdpConnectionModelImpl.COMPANYID_COLUMN_BITMASK |
			SamlIdpConnectionModelImpl.SAMLIDPENTITYID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_COMPANYID_IDPENTITYID = new FinderPath(SamlIdpConnectionModelImpl.ENTITY_CACHE_ENABLED,
			SamlIdpConnectionModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByCompanyId_IdpEntityId",
			new String[] { Long.class.getName(), String.class.getName() });

	/**
	 * Returns the saml idp connection where companyId = &#63; and samlIdpEntityId = &#63; or throws a {@link com.jio.portlet.saml.NoSuchSamlIdpConnectionException} if it could not be found.
	 *
	 * @param companyId the company ID
	 * @param samlIdpEntityId the saml idp entity ID
	 * @return the matching saml idp connection
	 * @throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException if a matching saml idp connection could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlIdpConnection findByCompanyId_IdpEntityId(long companyId,
		String samlIdpEntityId)
		throws NoSuchSamlIdpConnectionException, SystemException {
		SamlIdpConnection samlIdpConnection = fetchByCompanyId_IdpEntityId(companyId,
				samlIdpEntityId);

		if (samlIdpConnection == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("companyId=");
			msg.append(companyId);

			msg.append(", samlIdpEntityId=");
			msg.append(samlIdpEntityId);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchSamlIdpConnectionException(msg.toString());
		}

		return samlIdpConnection;
	}

	/**
	 * Returns the saml idp connection where companyId = &#63; and samlIdpEntityId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param companyId the company ID
	 * @param samlIdpEntityId the saml idp entity ID
	 * @return the matching saml idp connection, or <code>null</code> if a matching saml idp connection could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlIdpConnection fetchByCompanyId_IdpEntityId(long companyId,
		String samlIdpEntityId) throws SystemException {
		return fetchByCompanyId_IdpEntityId(companyId, samlIdpEntityId, true);
	}

	/**
	 * Returns the saml idp connection where companyId = &#63; and samlIdpEntityId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param companyId the company ID
	 * @param samlIdpEntityId the saml idp entity ID
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching saml idp connection, or <code>null</code> if a matching saml idp connection could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlIdpConnection fetchByCompanyId_IdpEntityId(long companyId,
		String samlIdpEntityId, boolean retrieveFromCache)
		throws SystemException {
		Object[] finderArgs = new Object[] { companyId, samlIdpEntityId };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_COMPANYID_IDPENTITYID,
					finderArgs, this);
		}

		if (result instanceof SamlIdpConnection) {
			SamlIdpConnection samlIdpConnection = (SamlIdpConnection)result;

			if ((companyId != samlIdpConnection.getCompanyId()) ||
					!Validator.equals(samlIdpEntityId,
						samlIdpConnection.getSamlIdpEntityId())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_SAMLIDPCONNECTION_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_IDPENTITYID_COMPANYID_2);

			boolean bindSamlIdpEntityId = false;

			if (samlIdpEntityId == null) {
				query.append(_FINDER_COLUMN_COMPANYID_IDPENTITYID_SAMLIDPENTITYID_1);
			}
			else if (samlIdpEntityId.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_COMPANYID_IDPENTITYID_SAMLIDPENTITYID_3);
			}
			else {
				bindSamlIdpEntityId = true;

				query.append(_FINDER_COLUMN_COMPANYID_IDPENTITYID_SAMLIDPENTITYID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindSamlIdpEntityId) {
					qPos.add(samlIdpEntityId);
				}

				List<SamlIdpConnection> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_COMPANYID_IDPENTITYID,
						finderArgs, list);
				}
				else {
					if ((list.size() > 1) && _log.isWarnEnabled()) {
						_log.warn(
							"SamlIdpConnectionPersistenceImpl.fetchByCompanyId_IdpEntityId(long, String, boolean) with parameters (" +
							StringUtil.merge(finderArgs) +
							") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
					}

					SamlIdpConnection samlIdpConnection = list.get(0);

					result = samlIdpConnection;

					cacheResult(samlIdpConnection);

					if ((samlIdpConnection.getCompanyId() != companyId) ||
							(samlIdpConnection.getSamlIdpEntityId() == null) ||
							!samlIdpConnection.getSamlIdpEntityId()
												  .equals(samlIdpEntityId)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_COMPANYID_IDPENTITYID,
							finderArgs, samlIdpConnection);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_COMPANYID_IDPENTITYID,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (SamlIdpConnection)result;
		}
	}

	/**
	 * Removes the saml idp connection where companyId = &#63; and samlIdpEntityId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @param samlIdpEntityId the saml idp entity ID
	 * @return the saml idp connection that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlIdpConnection removeByCompanyId_IdpEntityId(long companyId,
		String samlIdpEntityId)
		throws NoSuchSamlIdpConnectionException, SystemException {
		SamlIdpConnection samlIdpConnection = findByCompanyId_IdpEntityId(companyId,
				samlIdpEntityId);

		return remove(samlIdpConnection);
	}

	/**
	 * Returns the number of saml idp connections where companyId = &#63; and samlIdpEntityId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param samlIdpEntityId the saml idp entity ID
	 * @return the number of matching saml idp connections
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByCompanyId_IdpEntityId(long companyId,
		String samlIdpEntityId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_COMPANYID_IDPENTITYID;

		Object[] finderArgs = new Object[] { companyId, samlIdpEntityId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_SAMLIDPCONNECTION_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_IDPENTITYID_COMPANYID_2);

			boolean bindSamlIdpEntityId = false;

			if (samlIdpEntityId == null) {
				query.append(_FINDER_COLUMN_COMPANYID_IDPENTITYID_SAMLIDPENTITYID_1);
			}
			else if (samlIdpEntityId.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_COMPANYID_IDPENTITYID_SAMLIDPENTITYID_3);
			}
			else {
				bindSamlIdpEntityId = true;

				query.append(_FINDER_COLUMN_COMPANYID_IDPENTITYID_SAMLIDPENTITYID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (bindSamlIdpEntityId) {
					qPos.add(samlIdpEntityId);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_COMPANYID_IDPENTITYID_COMPANYID_2 =
		"samlIdpConnection.companyId = ? AND ";
	private static final String _FINDER_COLUMN_COMPANYID_IDPENTITYID_SAMLIDPENTITYID_1 =
		"samlIdpConnection.samlIdpEntityId IS NULL";
	private static final String _FINDER_COLUMN_COMPANYID_IDPENTITYID_SAMLIDPENTITYID_2 =
		"samlIdpConnection.samlIdpEntityId = ?";
	private static final String _FINDER_COLUMN_COMPANYID_IDPENTITYID_SAMLIDPENTITYID_3 =
		"(samlIdpConnection.samlIdpEntityId IS NULL OR samlIdpConnection.samlIdpEntityId = '')";

	public SamlIdpConnectionPersistenceImpl() {
		setModelClass(SamlIdpConnection.class);
	}

	/**
	 * Caches the saml idp connection in the entity cache if it is enabled.
	 *
	 * @param samlIdpConnection the saml idp connection
	 */
	@Override
	public void cacheResult(SamlIdpConnection samlIdpConnection) {
		EntityCacheUtil.putResult(SamlIdpConnectionModelImpl.ENTITY_CACHE_ENABLED,
			SamlIdpConnectionImpl.class, samlIdpConnection.getPrimaryKey(),
			samlIdpConnection);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_COMPANYID_IDPENTITYID,
			new Object[] {
				samlIdpConnection.getCompanyId(),
				samlIdpConnection.getSamlIdpEntityId()
			}, samlIdpConnection);

		samlIdpConnection.resetOriginalValues();
	}

	/**
	 * Caches the saml idp connections in the entity cache if it is enabled.
	 *
	 * @param samlIdpConnections the saml idp connections
	 */
	@Override
	public void cacheResult(List<SamlIdpConnection> samlIdpConnections) {
		for (SamlIdpConnection samlIdpConnection : samlIdpConnections) {
			if (EntityCacheUtil.getResult(
						SamlIdpConnectionModelImpl.ENTITY_CACHE_ENABLED,
						SamlIdpConnectionImpl.class,
						samlIdpConnection.getPrimaryKey()) == null) {
				cacheResult(samlIdpConnection);
			}
			else {
				samlIdpConnection.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all saml idp connections.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(SamlIdpConnectionImpl.class.getName());
		}

		EntityCacheUtil.clearCache(SamlIdpConnectionImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the saml idp connection.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(SamlIdpConnection samlIdpConnection) {
		EntityCacheUtil.removeResult(SamlIdpConnectionModelImpl.ENTITY_CACHE_ENABLED,
			SamlIdpConnectionImpl.class, samlIdpConnection.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache(samlIdpConnection);
	}

	@Override
	public void clearCache(List<SamlIdpConnection> samlIdpConnections) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (SamlIdpConnection samlIdpConnection : samlIdpConnections) {
			EntityCacheUtil.removeResult(SamlIdpConnectionModelImpl.ENTITY_CACHE_ENABLED,
				SamlIdpConnectionImpl.class, samlIdpConnection.getPrimaryKey());

			clearUniqueFindersCache(samlIdpConnection);
		}
	}

	protected void cacheUniqueFindersCache(SamlIdpConnection samlIdpConnection) {
		if (samlIdpConnection.isNew()) {
			Object[] args = new Object[] {
					samlIdpConnection.getCompanyId(),
					samlIdpConnection.getSamlIdpEntityId()
				};

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_COMPANYID_IDPENTITYID,
				args, Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_COMPANYID_IDPENTITYID,
				args, samlIdpConnection);
		}
		else {
			SamlIdpConnectionModelImpl samlIdpConnectionModelImpl = (SamlIdpConnectionModelImpl)samlIdpConnection;

			if ((samlIdpConnectionModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_COMPANYID_IDPENTITYID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						samlIdpConnection.getCompanyId(),
						samlIdpConnection.getSamlIdpEntityId()
					};

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_COMPANYID_IDPENTITYID,
					args, Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_COMPANYID_IDPENTITYID,
					args, samlIdpConnection);
			}
		}
	}

	protected void clearUniqueFindersCache(SamlIdpConnection samlIdpConnection) {
		SamlIdpConnectionModelImpl samlIdpConnectionModelImpl = (SamlIdpConnectionModelImpl)samlIdpConnection;

		Object[] args = new Object[] {
				samlIdpConnection.getCompanyId(),
				samlIdpConnection.getSamlIdpEntityId()
			};

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_COMPANYID_IDPENTITYID,
			args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_COMPANYID_IDPENTITYID,
			args);

		if ((samlIdpConnectionModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_COMPANYID_IDPENTITYID.getColumnBitmask()) != 0) {
			args = new Object[] {
					samlIdpConnectionModelImpl.getOriginalCompanyId(),
					samlIdpConnectionModelImpl.getOriginalSamlIdpEntityId()
				};

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_COMPANYID_IDPENTITYID,
				args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_COMPANYID_IDPENTITYID,
				args);
		}
	}

	/**
	 * Creates a new saml idp connection with the primary key. Does not add the saml idp connection to the database.
	 *
	 * @param samlIdpConnectionId the primary key for the new saml idp connection
	 * @return the new saml idp connection
	 */
	@Override
	public SamlIdpConnection create(long samlIdpConnectionId) {
		SamlIdpConnection samlIdpConnection = new SamlIdpConnectionImpl();

		samlIdpConnection.setNew(true);
		samlIdpConnection.setPrimaryKey(samlIdpConnectionId);

		return samlIdpConnection;
	}

	/**
	 * Removes the saml idp connection with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param samlIdpConnectionId the primary key of the saml idp connection
	 * @return the saml idp connection that was removed
	 * @throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException if a saml idp connection with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlIdpConnection remove(long samlIdpConnectionId)
		throws NoSuchSamlIdpConnectionException, SystemException {
		return remove((Serializable)samlIdpConnectionId);
	}

	/**
	 * Removes the saml idp connection with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the saml idp connection
	 * @return the saml idp connection that was removed
	 * @throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException if a saml idp connection with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlIdpConnection remove(Serializable primaryKey)
		throws NoSuchSamlIdpConnectionException, SystemException {
		Session session = null;

		try {
			session = openSession();

			SamlIdpConnection samlIdpConnection = (SamlIdpConnection)session.get(SamlIdpConnectionImpl.class,
					primaryKey);

			if (samlIdpConnection == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchSamlIdpConnectionException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(samlIdpConnection);
		}
		catch (NoSuchSamlIdpConnectionException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected SamlIdpConnection removeImpl(SamlIdpConnection samlIdpConnection)
		throws SystemException {
		samlIdpConnection = toUnwrappedModel(samlIdpConnection);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(samlIdpConnection)) {
				samlIdpConnection = (SamlIdpConnection)session.get(SamlIdpConnectionImpl.class,
						samlIdpConnection.getPrimaryKeyObj());
			}

			if (samlIdpConnection != null) {
				session.delete(samlIdpConnection);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (samlIdpConnection != null) {
			clearCache(samlIdpConnection);
		}

		return samlIdpConnection;
	}

	@Override
	public SamlIdpConnection updateImpl(
		com.jio.portlet.saml.model.SamlIdpConnection samlIdpConnection)
		throws SystemException {
		samlIdpConnection = toUnwrappedModel(samlIdpConnection);

		boolean isNew = samlIdpConnection.isNew();

		SamlIdpConnectionModelImpl samlIdpConnectionModelImpl = (SamlIdpConnectionModelImpl)samlIdpConnection;

		Session session = null;

		try {
			session = openSession();

			if (samlIdpConnection.isNew()) {
				session.save(samlIdpConnection);

				samlIdpConnection.setNew(false);
			}
			else {
				session.merge(samlIdpConnection);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !SamlIdpConnectionModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((samlIdpConnectionModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANYID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						samlIdpConnectionModelImpl.getOriginalCompanyId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_COMPANYID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANYID,
					args);

				args = new Object[] { samlIdpConnectionModelImpl.getCompanyId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_COMPANYID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANYID,
					args);
			}
		}

		EntityCacheUtil.putResult(SamlIdpConnectionModelImpl.ENTITY_CACHE_ENABLED,
			SamlIdpConnectionImpl.class, samlIdpConnection.getPrimaryKey(),
			samlIdpConnection);

		clearUniqueFindersCache(samlIdpConnection);
		cacheUniqueFindersCache(samlIdpConnection);

		return samlIdpConnection;
	}

	protected SamlIdpConnection toUnwrappedModel(
		SamlIdpConnection samlIdpConnection) {
		if (samlIdpConnection instanceof SamlIdpConnectionImpl) {
			return samlIdpConnection;
		}

		SamlIdpConnectionImpl samlIdpConnectionImpl = new SamlIdpConnectionImpl();

		samlIdpConnectionImpl.setNew(samlIdpConnection.isNew());
		samlIdpConnectionImpl.setPrimaryKey(samlIdpConnection.getPrimaryKey());

		samlIdpConnectionImpl.setSamlIdpConnectionId(samlIdpConnection.getSamlIdpConnectionId());
		samlIdpConnectionImpl.setCompanyId(samlIdpConnection.getCompanyId());
		samlIdpConnectionImpl.setUserId(samlIdpConnection.getUserId());
		samlIdpConnectionImpl.setUserName(samlIdpConnection.getUserName());
		samlIdpConnectionImpl.setCreateDate(samlIdpConnection.getCreateDate());
		samlIdpConnectionImpl.setModifiedDate(samlIdpConnection.getModifiedDate());
		samlIdpConnectionImpl.setSamlIdpEntityId(samlIdpConnection.getSamlIdpEntityId());
		samlIdpConnectionImpl.setAssertionSignatureRequired(samlIdpConnection.isAssertionSignatureRequired());
		samlIdpConnectionImpl.setClockSkew(samlIdpConnection.getClockSkew());
		samlIdpConnectionImpl.setEnabled(samlIdpConnection.isEnabled());
		samlIdpConnectionImpl.setForceAuthn(samlIdpConnection.isForceAuthn());
		samlIdpConnectionImpl.setLdapImportEnabled(samlIdpConnection.isLdapImportEnabled());
		samlIdpConnectionImpl.setMetadataUrl(samlIdpConnection.getMetadataUrl());
		samlIdpConnectionImpl.setMetadataXml(samlIdpConnection.getMetadataXml());
		samlIdpConnectionImpl.setMetadataUpdatedDate(samlIdpConnection.getMetadataUpdatedDate());
		samlIdpConnectionImpl.setName(samlIdpConnection.getName());
		samlIdpConnectionImpl.setNameIdFormat(samlIdpConnection.getNameIdFormat());
		samlIdpConnectionImpl.setSignAuthnRequest(samlIdpConnection.isSignAuthnRequest());
		samlIdpConnectionImpl.setUserAttributeMappings(samlIdpConnection.getUserAttributeMappings());

		return samlIdpConnectionImpl;
	}

	/**
	 * Returns the saml idp connection with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the saml idp connection
	 * @return the saml idp connection
	 * @throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException if a saml idp connection with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlIdpConnection findByPrimaryKey(Serializable primaryKey)
		throws NoSuchSamlIdpConnectionException, SystemException {
		SamlIdpConnection samlIdpConnection = fetchByPrimaryKey(primaryKey);

		if (samlIdpConnection == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchSamlIdpConnectionException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return samlIdpConnection;
	}

	/**
	 * Returns the saml idp connection with the primary key or throws a {@link com.jio.portlet.saml.NoSuchSamlIdpConnectionException} if it could not be found.
	 *
	 * @param samlIdpConnectionId the primary key of the saml idp connection
	 * @return the saml idp connection
	 * @throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException if a saml idp connection with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlIdpConnection findByPrimaryKey(long samlIdpConnectionId)
		throws NoSuchSamlIdpConnectionException, SystemException {
		return findByPrimaryKey((Serializable)samlIdpConnectionId);
	}

	/**
	 * Returns the saml idp connection with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the saml idp connection
	 * @return the saml idp connection, or <code>null</code> if a saml idp connection with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlIdpConnection fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		SamlIdpConnection samlIdpConnection = (SamlIdpConnection)EntityCacheUtil.getResult(SamlIdpConnectionModelImpl.ENTITY_CACHE_ENABLED,
				SamlIdpConnectionImpl.class, primaryKey);

		if (samlIdpConnection == _nullSamlIdpConnection) {
			return null;
		}

		if (samlIdpConnection == null) {
			Session session = null;

			try {
				session = openSession();

				samlIdpConnection = (SamlIdpConnection)session.get(SamlIdpConnectionImpl.class,
						primaryKey);

				if (samlIdpConnection != null) {
					cacheResult(samlIdpConnection);
				}
				else {
					EntityCacheUtil.putResult(SamlIdpConnectionModelImpl.ENTITY_CACHE_ENABLED,
						SamlIdpConnectionImpl.class, primaryKey,
						_nullSamlIdpConnection);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(SamlIdpConnectionModelImpl.ENTITY_CACHE_ENABLED,
					SamlIdpConnectionImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return samlIdpConnection;
	}

	/**
	 * Returns the saml idp connection with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param samlIdpConnectionId the primary key of the saml idp connection
	 * @return the saml idp connection, or <code>null</code> if a saml idp connection with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlIdpConnection fetchByPrimaryKey(long samlIdpConnectionId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)samlIdpConnectionId);
	}

	/**
	 * Returns all the saml idp connections.
	 *
	 * @return the saml idp connections
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SamlIdpConnection> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the saml idp connections.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlIdpConnectionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of saml idp connections
	 * @param end the upper bound of the range of saml idp connections (not inclusive)
	 * @return the range of saml idp connections
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SamlIdpConnection> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the saml idp connections.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlIdpConnectionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of saml idp connections
	 * @param end the upper bound of the range of saml idp connections (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of saml idp connections
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SamlIdpConnection> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<SamlIdpConnection> list = (List<SamlIdpConnection>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_SAMLIDPCONNECTION);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_SAMLIDPCONNECTION;

				if (pagination) {
					sql = sql.concat(SamlIdpConnectionModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<SamlIdpConnection>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SamlIdpConnection>(list);
				}
				else {
					list = (List<SamlIdpConnection>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the saml idp connections from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (SamlIdpConnection samlIdpConnection : findAll()) {
			remove(samlIdpConnection);
		}
	}

	/**
	 * Returns the number of saml idp connections.
	 *
	 * @return the number of saml idp connections
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_SAMLIDPCONNECTION);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the saml idp connection persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.jio.portlet.saml.model.SamlIdpConnection")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<SamlIdpConnection>> listenersList = new ArrayList<ModelListener<SamlIdpConnection>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<SamlIdpConnection>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(SamlIdpConnectionImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_SAMLIDPCONNECTION = "SELECT samlIdpConnection FROM SamlIdpConnection samlIdpConnection";
	private static final String _SQL_SELECT_SAMLIDPCONNECTION_WHERE = "SELECT samlIdpConnection FROM SamlIdpConnection samlIdpConnection WHERE ";
	private static final String _SQL_COUNT_SAMLIDPCONNECTION = "SELECT COUNT(samlIdpConnection) FROM SamlIdpConnection samlIdpConnection";
	private static final String _SQL_COUNT_SAMLIDPCONNECTION_WHERE = "SELECT COUNT(samlIdpConnection) FROM SamlIdpConnection samlIdpConnection WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "samlIdpConnection.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No SamlIdpConnection exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No SamlIdpConnection exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(SamlIdpConnectionPersistenceImpl.class);
	private static SamlIdpConnection _nullSamlIdpConnection = new SamlIdpConnectionImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<SamlIdpConnection> toCacheModel() {
				return _nullSamlIdpConnectionCacheModel;
			}
		};

	private static CacheModel<SamlIdpConnection> _nullSamlIdpConnectionCacheModel =
		new CacheModel<SamlIdpConnection>() {
			@Override
			public SamlIdpConnection toEntityModel() {
				return _nullSamlIdpConnection;
			}
		};
}