package com.jio.portlet.saml.binding.transport;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.apache.commons.httpclient.methods.RequestEntity;

public class OutputStreamRequestEntity implements RequestEntity {

	public OutputStreamRequestEntity(
		ByteArrayOutputStream byteArrayOutputStream) {

		this(byteArrayOutputStream, null);
	}

	public OutputStreamRequestEntity(
		ByteArrayOutputStream byteArrayOutputStream, String contentType) {

		_byteArrayOutputStream = byteArrayOutputStream;
		_contentType = contentType;
	}


	public long getContentLength() {
		return _byteArrayOutputStream.size();
	}


	public String getContentType() {
		return _contentType;
	}


	public boolean isRepeatable() {
		return true;
	}


	public void writeRequest(OutputStream outputStream) throws IOException {
		_byteArrayOutputStream.writeTo(outputStream);
	}

	private ByteArrayOutputStream _byteArrayOutputStream;
	private String _contentType;

}