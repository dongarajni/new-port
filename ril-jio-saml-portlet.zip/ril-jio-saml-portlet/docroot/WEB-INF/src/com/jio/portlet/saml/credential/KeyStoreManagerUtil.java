package com.jio.portlet.saml.credential;

import java.security.KeyStore;

public class KeyStoreManagerUtil {

	public static KeyStore getKeyStore() {
		KeyStoreManager keyStoreManager = KeyStoreManagerFactory.getInstance();

		return keyStoreManager.getKeyStore();
	}

	public static void saveKeyStore(KeyStore keyStore) throws Exception {
		KeyStoreManager keyStoreManager = KeyStoreManagerFactory.getInstance();

		keyStoreManager.saveKeyStore(keyStore);
	}

}