/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.model.impl;

import com.jio.portlet.saml.model.SamlIdpConnection;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing SamlIdpConnection in entity cache.
 *
 * @author Ashish Jadhav
 * @see SamlIdpConnection
 * @generated
 */
public class SamlIdpConnectionCacheModel implements CacheModel<SamlIdpConnection>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(39);

		sb.append("{samlIdpConnectionId=");
		sb.append(samlIdpConnectionId);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", userId=");
		sb.append(userId);
		sb.append(", userName=");
		sb.append(userName);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", modifiedDate=");
		sb.append(modifiedDate);
		sb.append(", samlIdpEntityId=");
		sb.append(samlIdpEntityId);
		sb.append(", assertionSignatureRequired=");
		sb.append(assertionSignatureRequired);
		sb.append(", clockSkew=");
		sb.append(clockSkew);
		sb.append(", enabled=");
		sb.append(enabled);
		sb.append(", forceAuthn=");
		sb.append(forceAuthn);
		sb.append(", ldapImportEnabled=");
		sb.append(ldapImportEnabled);
		sb.append(", metadataUrl=");
		sb.append(metadataUrl);
		sb.append(", metadataXml=");
		sb.append(metadataXml);
		sb.append(", metadataUpdatedDate=");
		sb.append(metadataUpdatedDate);
		sb.append(", name=");
		sb.append(name);
		sb.append(", nameIdFormat=");
		sb.append(nameIdFormat);
		sb.append(", signAuthnRequest=");
		sb.append(signAuthnRequest);
		sb.append(", userAttributeMappings=");
		sb.append(userAttributeMappings);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public SamlIdpConnection toEntityModel() {
		SamlIdpConnectionImpl samlIdpConnectionImpl = new SamlIdpConnectionImpl();

		samlIdpConnectionImpl.setSamlIdpConnectionId(samlIdpConnectionId);
		samlIdpConnectionImpl.setCompanyId(companyId);
		samlIdpConnectionImpl.setUserId(userId);

		if (userName == null) {
			samlIdpConnectionImpl.setUserName(StringPool.BLANK);
		}
		else {
			samlIdpConnectionImpl.setUserName(userName);
		}

		if (createDate == Long.MIN_VALUE) {
			samlIdpConnectionImpl.setCreateDate(null);
		}
		else {
			samlIdpConnectionImpl.setCreateDate(new Date(createDate));
		}

		if (modifiedDate == Long.MIN_VALUE) {
			samlIdpConnectionImpl.setModifiedDate(null);
		}
		else {
			samlIdpConnectionImpl.setModifiedDate(new Date(modifiedDate));
		}

		if (samlIdpEntityId == null) {
			samlIdpConnectionImpl.setSamlIdpEntityId(StringPool.BLANK);
		}
		else {
			samlIdpConnectionImpl.setSamlIdpEntityId(samlIdpEntityId);
		}

		samlIdpConnectionImpl.setAssertionSignatureRequired(assertionSignatureRequired);
		samlIdpConnectionImpl.setClockSkew(clockSkew);
		samlIdpConnectionImpl.setEnabled(enabled);
		samlIdpConnectionImpl.setForceAuthn(forceAuthn);
		samlIdpConnectionImpl.setLdapImportEnabled(ldapImportEnabled);

		if (metadataUrl == null) {
			samlIdpConnectionImpl.setMetadataUrl(StringPool.BLANK);
		}
		else {
			samlIdpConnectionImpl.setMetadataUrl(metadataUrl);
		}

		if (metadataXml == null) {
			samlIdpConnectionImpl.setMetadataXml(StringPool.BLANK);
		}
		else {
			samlIdpConnectionImpl.setMetadataXml(metadataXml);
		}

		if (metadataUpdatedDate == Long.MIN_VALUE) {
			samlIdpConnectionImpl.setMetadataUpdatedDate(null);
		}
		else {
			samlIdpConnectionImpl.setMetadataUpdatedDate(new Date(
					metadataUpdatedDate));
		}

		if (name == null) {
			samlIdpConnectionImpl.setName(StringPool.BLANK);
		}
		else {
			samlIdpConnectionImpl.setName(name);
		}

		if (nameIdFormat == null) {
			samlIdpConnectionImpl.setNameIdFormat(StringPool.BLANK);
		}
		else {
			samlIdpConnectionImpl.setNameIdFormat(nameIdFormat);
		}

		samlIdpConnectionImpl.setSignAuthnRequest(signAuthnRequest);

		if (userAttributeMappings == null) {
			samlIdpConnectionImpl.setUserAttributeMappings(StringPool.BLANK);
		}
		else {
			samlIdpConnectionImpl.setUserAttributeMappings(userAttributeMappings);
		}

		samlIdpConnectionImpl.resetOriginalValues();

		return samlIdpConnectionImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		samlIdpConnectionId = objectInput.readLong();
		companyId = objectInput.readLong();
		userId = objectInput.readLong();
		userName = objectInput.readUTF();
		createDate = objectInput.readLong();
		modifiedDate = objectInput.readLong();
		samlIdpEntityId = objectInput.readUTF();
		assertionSignatureRequired = objectInput.readBoolean();
		clockSkew = objectInput.readLong();
		enabled = objectInput.readBoolean();
		forceAuthn = objectInput.readBoolean();
		ldapImportEnabled = objectInput.readBoolean();
		metadataUrl = objectInput.readUTF();
		metadataXml = objectInput.readUTF();
		metadataUpdatedDate = objectInput.readLong();
		name = objectInput.readUTF();
		nameIdFormat = objectInput.readUTF();
		signAuthnRequest = objectInput.readBoolean();
		userAttributeMappings = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(samlIdpConnectionId);
		objectOutput.writeLong(companyId);
		objectOutput.writeLong(userId);

		if (userName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(userName);
		}

		objectOutput.writeLong(createDate);
		objectOutput.writeLong(modifiedDate);

		if (samlIdpEntityId == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(samlIdpEntityId);
		}

		objectOutput.writeBoolean(assertionSignatureRequired);
		objectOutput.writeLong(clockSkew);
		objectOutput.writeBoolean(enabled);
		objectOutput.writeBoolean(forceAuthn);
		objectOutput.writeBoolean(ldapImportEnabled);

		if (metadataUrl == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(metadataUrl);
		}

		if (metadataXml == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(metadataXml);
		}

		objectOutput.writeLong(metadataUpdatedDate);

		if (name == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(name);
		}

		if (nameIdFormat == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(nameIdFormat);
		}

		objectOutput.writeBoolean(signAuthnRequest);

		if (userAttributeMappings == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(userAttributeMappings);
		}
	}

	public long samlIdpConnectionId;
	public long companyId;
	public long userId;
	public String userName;
	public long createDate;
	public long modifiedDate;
	public String samlIdpEntityId;
	public boolean assertionSignatureRequired;
	public long clockSkew;
	public boolean enabled;
	public boolean forceAuthn;
	public boolean ldapImportEnabled;
	public String metadataUrl;
	public String metadataXml;
	public long metadataUpdatedDate;
	public String name;
	public String nameIdFormat;
	public boolean signAuthnRequest;
	public String userAttributeMappings;
}