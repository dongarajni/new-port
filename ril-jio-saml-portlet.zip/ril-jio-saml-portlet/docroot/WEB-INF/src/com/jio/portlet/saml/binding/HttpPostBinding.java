
package com.jio.portlet.saml.binding;

import org.apache.velocity.app.VelocityEngine;

import org.opensaml.common.xml.SAMLConstants;
import org.opensaml.saml2.binding.decoding.HTTPPostDecoder;
import org.opensaml.saml2.binding.encoding.HTTPPostEncoder;
import org.opensaml.xml.parse.ParserPool;

public class HttpPostBinding extends BaseSamlBinding {

	public HttpPostBinding(
		ParserPool parserPool, VelocityEngine velocityEngine) {

		super(
			new HTTPPostDecoder(parserPool),
			new HTTPPostEncoder(
				velocityEngine, "/templates/saml2-post-binding.vm"));
	}


	public String getCommunicationProfileId() {
		return SAMLConstants.SAML2_POST_BINDING_URI;
	}

}