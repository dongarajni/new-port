
package com.jio.portlet.saml.binding;

import com.jio.portlet.saml.binding.SamlBinding;

import org.opensaml.ws.message.decoder.MessageDecoder;
import org.opensaml.ws.message.encoder.MessageEncoder;


public abstract class BaseSamlBinding implements SamlBinding {

	public BaseSamlBinding(
		MessageDecoder messageDecoder, MessageEncoder messageEncoder) {

		_messageDecoder = messageDecoder;
		_messageEncoder = messageEncoder;
	}


	public MessageDecoder getMessageDecoder() {
		return _messageDecoder;
	}


	public MessageEncoder getMessageEncoder() {
		return _messageEncoder;
	}

	private MessageDecoder _messageDecoder;
	private MessageEncoder _messageEncoder;

}