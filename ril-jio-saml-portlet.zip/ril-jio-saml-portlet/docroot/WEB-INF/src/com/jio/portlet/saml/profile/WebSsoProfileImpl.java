package com.jio.portlet.saml.profile;

import com.jio.hook.common.util.JioSamlUtil;
import com.jio.hook.common.util.OpenSamlUtil;
import com.jio.hook.common.util.PortletPropsValues;
import com.jio.hook.common.util.PortletWebKeys;
import com.jio.hook.saml.context.SamlSsoRequestContext;
import com.jio.portlet.saml.binding.SamlBinding;
import com.jio.portlet.saml.metadata.MetadataManagerUtil;
import com.jio.portlet.saml.model.SamlAuthRequest;
import com.jio.portlet.saml.model.SamlIdpConnection;
import com.jio.portlet.saml.model.SamlMessage;
import com.jio.portlet.saml.model.SamlSession;
import com.jio.portlet.saml.resolver.UserResolverUtil;
import com.jio.portlet.saml.service.SamlAuthRequestLocalServiceUtil;
import com.jio.portlet.saml.service.SamlIdpConnectionLocalServiceUtil;
import com.jio.portlet.saml.service.SamlMessageLocalServiceUtil;
import com.jio.portlet.saml.service.SamlSessionLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.HttpHeaders;
import com.liferay.portal.kernel.util.HttpUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.security.auth.CompanyThreadLocal;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.opensaml.common.SAMLObject;
import org.opensaml.common.SAMLVersion;
import org.opensaml.common.binding.SAMLMessageContext;
import org.opensaml.common.xml.SAMLConstants;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.Attribute;
import org.opensaml.saml2.core.AttributeStatement;
import org.opensaml.saml2.core.Audience;
import org.opensaml.saml2.core.AudienceRestriction;
import org.opensaml.saml2.core.AuthnContext;
import org.opensaml.saml2.core.AuthnContextClassRef;
import org.opensaml.saml2.core.AuthnRequest;
import org.opensaml.saml2.core.AuthnStatement;
import org.opensaml.saml2.core.Conditions;
import org.opensaml.saml2.core.Issuer;
import org.opensaml.saml2.core.NameID;
import org.opensaml.saml2.core.NameIDPolicy;
import org.opensaml.saml2.core.NameIDType;
import org.opensaml.saml2.core.Response;
import org.opensaml.saml2.core.Status;
import org.opensaml.saml2.core.StatusCode;
import org.opensaml.saml2.core.Subject;
import org.opensaml.saml2.core.SubjectConfirmation;
import org.opensaml.saml2.core.SubjectConfirmationData;
import org.opensaml.saml2.metadata.AssertionConsumerService;
import org.opensaml.saml2.metadata.IDPSSODescriptor;
import org.opensaml.saml2.metadata.SPSSODescriptor;
import org.opensaml.saml2.metadata.SingleSignOnService;
import org.opensaml.security.MetadataCriteria;
import org.opensaml.security.SAMLSignatureProfileValidator;
import org.opensaml.xml.security.CriteriaSet;
import org.opensaml.xml.security.SecurityException;
import org.opensaml.xml.security.credential.Credential;
import org.opensaml.xml.security.credential.UsageType;
import org.opensaml.xml.security.criteria.EntityIDCriteria;
import org.opensaml.xml.security.criteria.UsageCriteria;
import org.opensaml.xml.security.trust.TrustEngine;
import org.opensaml.xml.signature.Signature;
import org.opensaml.xml.signature.SignatureException;
import org.opensaml.xml.signature.SignatureTrustEngine;

public class WebSsoProfileImpl extends BaseProfile implements WebSsoProfile {

	public void processResponse(HttpServletRequest request,
			HttpServletResponse response) throws PortalException,
			SystemException {

		try {
			doProcessResponse(request, response);
		} catch (Exception e) {
			if (e instanceof PortalException) {
				throw (PortalException) e;
			} else if (e instanceof SystemException) {
				throw (SystemException) e;
			} else {
				throw new PortalException(e);
			}
		}
	}

	public void sendAuthnRequest(HttpServletRequest request,
			HttpServletResponse response, String relayState)
			throws PortalException, SystemException {

		try {
			doSendAuthnRequest(request, response, relayState);
		} catch (Exception e) {
			if (e instanceof PortalException) {
				throw (PortalException) e;
			} else if (e instanceof SystemException) {
				throw (SystemException) e;
			} else {
				throw new PortalException(e);
			}
		}
	}

	public void updateSamlSession(HttpServletRequest request,
			HttpServletResponse response) throws SystemException {

		SamlSession samlSpSession = getSamlSession(request);

		HttpSession session = request.getSession();

		String jSessionId = session.getId();

		if ((samlSpSession != null)
				&& !jSessionId.equals(samlSpSession.getJSessionId())) {

			try {
				SamlSessionLocalServiceUtil.updateSamlSession(
						samlSpSession.getPrimaryKey(), jSessionId);
			} catch (Exception e) {
			}
		}
	}

	protected SamlSsoRequestContext decodeAuthnRequest(
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		HttpSession session = request.getSession();

		SamlSsoRequestContext samlSsoRequestContext = (SamlSsoRequestContext) session
				.getAttribute(PortletWebKeys.SAML_SSO_REQUEST_CONTEXT);

		if (samlSsoRequestContext != null) {
			session.removeAttribute(PortletWebKeys.SAML_SSO_REQUEST_CONTEXT);

			SAMLMessageContext<AuthnRequest, Response, NameID> samlMessageContext = (SAMLMessageContext<AuthnRequest, Response, NameID>) getSamlMessageContext(
					request, response, samlSsoRequestContext.getPeerEntityId());

			samlSsoRequestContext.setSAMLMessageContext(samlMessageContext);

			String authnRequestXml = samlSsoRequestContext.getAutnRequestXml();

			if (Validator.isNotNull(authnRequestXml)) {
				AuthnRequest authnRequest = (AuthnRequest) OpenSamlUtil
						.unmarshall(authnRequestXml);

				samlMessageContext.setInboundSAMLMessage(authnRequest);
			}

			String relayState = samlSsoRequestContext.getRelayState();

			samlMessageContext.setRelayState(relayState);

			String samlSsoSessionId = getSamlSsoSessionId(request);

			if (Validator.isNotNull(samlSsoSessionId)) {
				samlSsoRequestContext.setSamlSsoSessionId(samlSsoSessionId);
			} else {
				samlSsoRequestContext.setNewSession(true);
				samlSsoRequestContext
						.setSamlSsoSessionId(generateIdentifier(30));
			}

			samlSsoRequestContext
					.setStage(SamlSsoRequestContext.STAGE_AUTHENTICATED);

			long userId = PortalUtil.getUserId(request);

			samlSsoRequestContext.setUserId(userId);

			return samlSsoRequestContext;
		}

		SAMLMessageContext<AuthnRequest, Response, NameID> samlMessageContext = null;

		SamlBinding samlBinding = null;

		if (StringUtil.equalsIgnoreCase(request.getMethod(), "GET")) {
			samlBinding = getSamlBinding(SAMLConstants.SAML2_REDIRECT_BINDING_URI);
		} else {
			samlBinding = getSamlBinding(SAMLConstants.SAML2_POST_BINDING_URI);
		}

		String entityId = ParamUtil.getString(request, "entityId");
		String samlRequest = ParamUtil.getString(request, "SAMLRequest");

		if (Validator.isNotNull(entityId) && Validator.isNull(samlRequest)) {
			samlMessageContext = (SAMLMessageContext<AuthnRequest, Response, NameID>) getSamlMessageContext(
					request, response, entityId);

			samlMessageContext.setCommunicationProfileId(samlBinding
					.getCommunicationProfileId());

			String relayState = ParamUtil.getString(request, "RelayState");

			samlMessageContext.setRelayState(relayState);

			samlSsoRequestContext = new SamlSsoRequestContext(
					samlMessageContext.getPeerEntityId(), relayState,
					samlMessageContext);
		} else {
			samlMessageContext = (SAMLMessageContext<AuthnRequest, Response, NameID>) decodeSamlMessage(
					request, response, samlBinding,
					MetadataManagerUtil.isWantAuthnRequestSigned());

			AuthnRequest authnRequest = samlMessageContext
					.getInboundSAMLMessage();

			String authnRequestXml = OpenSamlUtil.marshall(authnRequest);

			samlSsoRequestContext = new SamlSsoRequestContext(authnRequestXml,
					samlMessageContext.getPeerEntityId(),
					samlMessageContext.getRelayState(), samlMessageContext);
		}

		String samlSsoSessionId = getSamlSsoSessionId(request);

		if (Validator.isNotNull(samlSsoSessionId)) {
			samlSsoRequestContext.setSamlSsoSessionId(samlSsoSessionId);
		} else {
			samlSsoRequestContext.setNewSession(true);
			samlSsoRequestContext.setSamlSsoSessionId(generateIdentifier(30));
		}

		samlSsoRequestContext.setStage(SamlSsoRequestContext.STAGE_INITIAL);

		long userId = PortalUtil.getUserId(request);

		samlSsoRequestContext.setUserId(userId);

		return samlSsoRequestContext;
	}

	protected void doProcessResponse(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		SAMLMessageContext<Response, SAMLObject, NameID> samlMessageContext = (SAMLMessageContext<Response, SAMLObject, NameID>) decodeSamlMessage(
				request, response,
				getSamlBinding(SAMLConstants.SAML2_POST_BINDING_URI), true);

		Response samlResponse = samlMessageContext.getInboundSAMLMessage();

		Status status = samlResponse.getStatus();

		StatusCode statusCode = status.getStatusCode();

		String statusCodeURI = statusCode.getValue();

		if (!statusCodeURI.equals(StatusCode.SUCCESS_URI)) {
			throw new PortalException(statusCode.getValue());
		}

		verifyInResponseTo(samlResponse);
		verifyDestination(samlMessageContext, samlResponse.getDestination());
		verifyIssuer(samlMessageContext, samlResponse.getIssuer());

		Assertion assertion = null;

		SignatureTrustEngine signatureTrustEngine = MetadataManagerUtil
				.getSignatureTrustEngine();

		List<Attribute> attributes = new ArrayList<Attribute>();

		for (Assertion curAssertion : samlResponse.getAssertions()) {
			try {
				verifyAssertion(curAssertion, samlMessageContext,
						signatureTrustEngine);
			} catch (PortalException samle) {
				if (_log.isDebugEnabled()) {
					_log.debug("Rejecting assertion " + curAssertion.getID(),
							samle);
				}

				continue;
			}

			List<AuthnStatement> authnStatements = curAssertion
					.getAuthnStatements();

			if (!authnStatements.isEmpty()) {
				Subject subject = curAssertion.getSubject();

				if ((subject != null)
						&& (subject.getSubjectConfirmations() != null)) {

					for (SubjectConfirmation subjectConfirmation : subject
							.getSubjectConfirmations()) {

						if (SubjectConfirmation.METHOD_BEARER
								.equals(subjectConfirmation.getMethod())) {

							assertion = curAssertion;

							break;
						}
					}
				}
			}

			if (assertion != null) {
				for (AttributeStatement attributeStatement : curAssertion
						.getAttributeStatements()) {

					for (Attribute attribute : attributeStatement
							.getAttributes()) {

						attributes.add(attribute);
					}
				}

				break;
			}
		}

		if (assertion == null) {
			throw new PortalException(
					"Response does not contain any acceptable assertions");
		}

		NameID nameId = samlMessageContext.getSubjectNameIdentifier();

		if (nameId == null) {
			throw new PortalException("Name ID not present in subject");
		}

		if (_log.isDebugEnabled()) {
			_log.debug("SAML authenticated user " + nameId.getValue());
		}

		String assertionXml = OpenSamlUtil.marshall(assertion);

		List<AuthnStatement> authnStatements = assertion.getAuthnStatements();

		AuthnStatement authnStatement = authnStatements.get(0);

		String sessionIndex = authnStatement.getSessionIndex();

		ServiceContext serviceContext = ServiceContextFactory
				.getInstance(request);

		User user = UserResolverUtil.resolveUser(assertion, samlMessageContext,
				serviceContext);

		serviceContext.setUserId(user.getUserId());

		HttpSession session = request.getSession();

		SamlSession samlSession = getSamlSession(request);

		if (samlSession != null) {
			SamlSessionLocalServiceUtil.updateSamlSession(
					samlSession.getSessionId(), samlSession.getSessionKey(),
					assertionXml, session.getId(), nameId.getFormat(),
					nameId.getNameQualifier(), nameId.getSPNameQualifier(),
					nameId.getValue(), sessionIndex, serviceContext);
		} else {
			String samlSpSessionKey = generateIdentifier(30);

			samlSession = SamlSessionLocalServiceUtil.addSamlSession(
					samlSpSessionKey, assertionXml, session.getId(),
					nameId.getFormat(), nameId.getNameQualifier(),
					nameId.getSPNameQualifier(), nameId.getValue(),
					sessionIndex, serviceContext);
		}

		session.setAttribute(PortletWebKeys.SAML_SP_SESSION_KEY,
				samlSession.getSessionKey());

		Cookie cookie = new Cookie(PortletWebKeys.SAML_SP_SESSION_KEY,
				samlSession.getSessionKey());

		cookie.setMaxAge(-1);

		if (Validator.isNull(PortalUtil.getPathContext())) {
			cookie.setPath(StringPool.SLASH);
		} else {
			cookie.setPath(PortalUtil.getPathContext());
		}

		cookie.setSecure(request.isSecure());

		response.addCookie(cookie);

		StringBundler sb = new StringBundler(3);

		ThemeDisplay themeDisplay = (ThemeDisplay) request
				.getAttribute(WebKeys.THEME_DISPLAY);

		sb.append(themeDisplay.getPathMain());
		sb.append("/portal/saml/auth_redirect?redirect=");

		String relayState = PortalUtil.escapeRedirect(samlMessageContext
				.getRelayState());

		if (Validator.isNull(relayState)) {
			relayState = PortalUtil.getHomeURL(request);
		}

		sb.append(HttpUtil.encodeURL(relayState));

		response.sendRedirect(sb.toString());
	}

	protected void doSendAuthnRequest(HttpServletRequest request,
			HttpServletResponse response, String relayState) throws Exception {

		String entityId = MetadataManagerUtil.getDefaultIdpEntityId();

		SAMLMessageContext<SAMLObject, AuthnRequest, SAMLObject> samlMessageContext = (SAMLMessageContext<SAMLObject, AuthnRequest, SAMLObject>) getSamlMessageContext(
				request, response, entityId);

		SPSSODescriptor spSsoDescriptor = (SPSSODescriptor) samlMessageContext
				.getLocalEntityRoleMetadata();

		AssertionConsumerService assertionConsumerService = JioSamlUtil
				.getAssertionConsumerServiceForBinding(spSsoDescriptor,
						SAMLConstants.SAML2_POST_BINDING_URI);

		IDPSSODescriptor idpSsoDescriptor = (IDPSSODescriptor) samlMessageContext
				.getPeerEntityRoleMetadata();

		SingleSignOnService singleSignOnService = JioSamlUtil
				.resolveSingleSignOnService(idpSsoDescriptor,
						SAMLConstants.SAML2_POST_BINDING_URI);

		NameIDPolicy nameIdPolicy = OpenSamlUtil.buildNameIdPolicy();

		nameIdPolicy.setAllowCreate(true);
		nameIdPolicy.setFormat(MetadataManagerUtil.getNameIdFormat(entityId));

		AuthnRequest authnRequest = OpenSamlUtil.buildAuthnRequest(
				spSsoDescriptor, assertionConsumerService, singleSignOnService,
				nameIdPolicy);

		authnRequest.setID(generateIdentifier(20));

		long companyId = PortalUtil.getCompanyId(request);

		boolean forceAuthn = false;

		try {
			SamlIdpConnection samlSpIdpConnection = SamlIdpConnectionLocalServiceUtil
					.getSamlIdpConnection(companyId, entityId);

			forceAuthn = samlSpIdpConnection.isForceAuthn();
		} catch (PortalException nssice) {
		}

		authnRequest.setForceAuthn(forceAuthn);

		samlMessageContext.setOutboundSAMLMessage(authnRequest);

		if (spSsoDescriptor.isAuthnRequestsSigned()
				|| idpSsoDescriptor.getWantAuthnRequestsSigned()) {

			Credential credential = MetadataManagerUtil.getSigningCredential();

			samlMessageContext
					.setOutboundSAMLMessageSigningCredential(credential);

			OpenSamlUtil.signObject(authnRequest, credential);
		}

		samlMessageContext.setPeerEntityEndpoint(singleSignOnService);
		samlMessageContext.setRelayState(relayState);

		ServiceContext serviceContext = ServiceContextFactory
				.getInstance(request);

		SamlAuthRequestLocalServiceUtil.addSamlAuthRequest(
				samlMessageContext.getPeerEntityId(), authnRequest.getID(),
				serviceContext);

		sendSamlMessage(samlMessageContext);
	}

	protected AudienceRestriction getSuccessAudienceRestriction(String entityId) {

		AudienceRestriction audienceRestriction = OpenSamlUtil
				.buildAudienceRestriction();

		List<Audience> audiences = audienceRestriction.getAudiences();

		Audience audience = OpenSamlUtil.buildAudience();

		audience.setAudienceURI(entityId);

		audiences.add(audience);

		return audienceRestriction;
	}

	protected AuthnContext getSuccessAuthnContext() {
		AuthnContext authnContext = OpenSamlUtil.buildAuthnContext();

		AuthnContextClassRef authnContextClassRef = OpenSamlUtil
				.buildAuthnContextClassRef();

		authnContextClassRef
				.setAuthnContextClassRef(AuthnContext.UNSPECIFIED_AUTHN_CTX);

		authnContext.setAuthnContextClassRef(authnContextClassRef);

		return authnContext;
	}

	protected AuthnStatement getSuccessAuthnStatement(
			SamlSsoRequestContext samlSsoRequestContext, Assertion assertion) {

		AuthnStatement authnStatement = OpenSamlUtil.buildAuthnStatement();

		AuthnContext authnContext = getSuccessAuthnContext();

		authnStatement.setAuthnContext(authnContext);

		authnStatement.setAuthnInstant(assertion.getIssueInstant());
		authnStatement.setSessionIndex(samlSsoRequestContext
				.getSamlSsoSessionId());

		return authnStatement;
	}

	protected Conditions getSuccessConditions(
			SamlSsoRequestContext samlSsoRequestContext,
			DateTime notBeforeDateTime, DateTime notOnOrAfterDateTime) {

		Conditions conditions = OpenSamlUtil.buildConditions();

		conditions.setNotBefore(notBeforeDateTime);
		conditions.setNotOnOrAfter(notOnOrAfterDateTime);

		List<AudienceRestriction> audienceRestrictions = conditions
				.getAudienceRestrictions();

		SAMLMessageContext<AuthnRequest, Response, NameID> samlMessageContext = samlSsoRequestContext
				.getSAMLMessageContext();

		AudienceRestriction audienceRestriction = getSuccessAudienceRestriction(samlMessageContext
				.getPeerEntityId());

		audienceRestrictions.add(audienceRestriction);

		return conditions;
	}

	protected Response getSuccessResponse(
			SamlSsoRequestContext samlSsoRequestContext,
			AssertionConsumerService assertionConsumerService,
			Assertion assertion) {

		Response response = OpenSamlUtil.buildResponse();

		response.setDestination(assertionConsumerService.getLocation());
		response.setID(generateIdentifier(20));

		SAMLMessageContext<AuthnRequest, Response, NameID> samlMessageContext = samlSsoRequestContext
				.getSAMLMessageContext();

		if (Validator.isNotNull(samlMessageContext.getInboundSAMLMessageId())) {
			response.setInResponseTo(samlMessageContext
					.getInboundSAMLMessageId());
		}

		response.setIssueInstant(assertion.getIssueInstant());

		Issuer issuer = OpenSamlUtil.buildIssuer(samlMessageContext
				.getLocalEntityId());

		response.setIssuer(issuer);

		StatusCode statusCode = OpenSamlUtil
				.buildStatusCode(StatusCode.SUCCESS_URI);

		Status status = OpenSamlUtil.buildStatus(statusCode);

		response.setStatus(status);

		response.setVersion(SAMLVersion.VERSION_20);

		List<Assertion> assertions = response.getAssertions();

		assertions.add(assertion);

		return response;
	}

	protected Subject getSuccessSubject(
			SamlSsoRequestContext samlSsoRequestContext,
			AssertionConsumerService assertionConsumerService, NameID nameId,
			SubjectConfirmationData subjectConfirmationData) {

		SubjectConfirmation subjectConfirmation = OpenSamlUtil
				.buildSubjectConfirmation();

		subjectConfirmation.setMethod(SubjectConfirmation.METHOD_BEARER);
		subjectConfirmation.setSubjectConfirmationData(subjectConfirmationData);

		Subject subject = OpenSamlUtil.buildSubject(nameId);

		List<SubjectConfirmation> subjectConfirmations = subject
				.getSubjectConfirmations();

		subjectConfirmations.add(subjectConfirmation);

		return subject;
	}

	protected void redirectToLogin(HttpServletRequest request,
			HttpServletResponse response,
			SamlSsoRequestContext samlSsoRequestContext, boolean forceAuthn)
			throws SystemException {

		HttpSession session = request.getSession();

		if (forceAuthn) {
			logout(request, response);

			session = request.getSession(true);

			session.setAttribute(PortletWebKeys.FORCE_REAUHENTICATION,
					Boolean.TRUE);
		}

		samlSsoRequestContext.setSAMLMessageContext(null);

		session.setAttribute(PortletWebKeys.SAML_SSO_REQUEST_CONTEXT,
				samlSsoRequestContext);

		response.addHeader(HttpHeaders.CACHE_CONTROL,
				HttpHeaders.CACHE_CONTROL_NO_CACHE_VALUE);
		response.addHeader(HttpHeaders.PRAGMA,
				HttpHeaders.PRAGMA_NO_CACHE_VALUE);

		StringBundler sb = new StringBundler(4);

		ThemeDisplay themeDisplay = (ThemeDisplay) request
				.getAttribute(WebKeys.THEME_DISPLAY);

		sb.append(themeDisplay.getPathMain());
		sb.append("/portal/login?redirect=");
		sb.append(themeDisplay.getPathMain());
		sb.append("/portal/saml/sso");

		String redirect = sb.toString();

		try {
			response.sendRedirect(redirect);
		} catch (IOException ioe) {
			throw new SystemException(ioe);
		}
	}

	protected void sendFailureResponse(
			SamlSsoRequestContext samlSsoRequestContext, String statusURI)
			throws PortalException {

		SAMLMessageContext<AuthnRequest, Response, NameID> samlMessageContext = samlSsoRequestContext
				.getSAMLMessageContext();

		SamlBinding samlBinding = getSamlBinding(SAMLConstants.SAML2_POST_BINDING_URI);

		AssertionConsumerService assertionConsumerService = JioSamlUtil
				.resolverAssertionConsumerService(samlMessageContext,
						samlBinding.getCommunicationProfileId());

		samlMessageContext.setPeerEntityEndpoint(assertionConsumerService);

		try {
			Credential credential = MetadataManagerUtil.getSigningCredential();

			samlMessageContext
					.setOutboundSAMLMessageSigningCredential(credential);
		} catch (SecurityException se) {
			throw new PortalException(se);
		}

		Response response = OpenSamlUtil.buildResponse();

		response.setDestination(assertionConsumerService.getLocation());
		response.setInResponseTo(samlMessageContext.getInboundSAMLMessageId());

		DateTime issueInstantDateTime = new DateTime(DateTimeZone.UTC);

		response.setIssueInstant(issueInstantDateTime);

		Issuer issuer = OpenSamlUtil.buildIssuer(samlMessageContext
				.getLocalEntityId());

		response.setIssuer(issuer);

		StatusCode statusCode = OpenSamlUtil.buildStatusCode(statusURI);

		Status status = OpenSamlUtil.buildStatus(statusCode);

		response.setStatus(status);

		samlMessageContext.setOutboundSAMLMessage(response);

		sendSamlMessage(samlMessageContext);
	}

	protected void verifyAssertion(Assertion assertion,
			SAMLMessageContext<?, ?, NameID> samlMessageContext,
			TrustEngine<Signature> trustEngine) throws PortalException {

		verifyReplay(samlMessageContext, assertion);
		verifyIssuer(samlMessageContext, assertion.getIssuer());
		verifyAssertionSignature(assertion.getSignature(), samlMessageContext,
				trustEngine);
		verifyConditions(samlMessageContext, assertion.getConditions());
		verifySubject(samlMessageContext, assertion.getSubject());
	}

	protected void verifyAssertionSignature(Signature signature,
			SAMLMessageContext<?, ?, ?> samlMessageContext,
			TrustEngine<Signature> trustEngine) throws PortalException {

		SPSSODescriptor spSsoDescriptor = (SPSSODescriptor) samlMessageContext
				.getLocalEntityRoleMetadata();

		if (signature != null) {
			verifySignature(samlMessageContext, signature, trustEngine);
		} else if (spSsoDescriptor.getWantAssertionsSigned()
				&& (signature == null)) {

			throw new PortalException("SAML assertion is not signed");
		}
	}

	protected void verifyAudienceRestrictions(
			List<AudienceRestriction> audienceRestrictions,
			SAMLMessageContext<?, ?, ?> samlMessageContext)
			throws PortalException {

		if (audienceRestrictions.isEmpty()) {
			return;
		}

		for (AudienceRestriction audienceRestriction : audienceRestrictions) {
			for (Audience audience : audienceRestriction.getAudiences()) {
				String audienceURI = audience.getAudienceURI();

				if (audienceURI.equals(samlMessageContext.getLocalEntityId())) {
					return;
				}
			}
		}

		throw new PortalException("Unable verify audience");
	}

	protected void verifyConditions(
			SAMLMessageContext<?, ?, ?> samlMessageContext,
			Conditions conditions) throws PortalException {

		verifyAudienceRestrictions(conditions.getAudienceRestrictions(),
				samlMessageContext);

		if (conditions.getNotOnOrAfter() != null) {
			verifyNotOnOrAfterDateTime(MetadataManagerUtil.getClockSkew(),
					conditions.getNotOnOrAfter());
		}
	}

	protected void verifyDestination(
			SAMLMessageContext<?, ?, ?> samlMessageContext, String destination)
			throws PortalException {

		SPSSODescriptor spSsoDescriptor = (SPSSODescriptor) samlMessageContext
				.getLocalEntityRoleMetadata();

		List<AssertionConsumerService> assertionConsumerServices = spSsoDescriptor
				.getAssertionConsumerServices();

		for (AssertionConsumerService assertionConsumerService : assertionConsumerServices) {

			String binding = assertionConsumerService.getBinding();

			if (destination.equals(assertionConsumerService.getLocation())
					&& binding.equals(samlMessageContext
							.getCommunicationProfileId())) {

				return;
			}
		}

		throw new PortalException("Destination " + destination
				+ " does not match any assertion "
				+ "consumer location with binding "
				+ samlMessageContext.getCommunicationProfileId());
	}

	protected void verifyInResponseTo(Response samlResponse)
			throws PortalException, SystemException {

		if (Validator.isNull(samlResponse.getInResponseTo())) {
			return;
		}

		Issuer issuer = samlResponse.getIssuer();
		String issuerEntityId = issuer.getValue();
		String inResponseTo = samlResponse.getInResponseTo();

		SamlAuthRequest samlSpAuthRequest = SamlAuthRequestLocalServiceUtil
				.fetchSamlAuthRequest(issuerEntityId, inResponseTo);

		if (samlSpAuthRequest != null) {
			SamlAuthRequestLocalServiceUtil
					.deleteSamlAuthRequest(samlSpAuthRequest);
		} else {
			throw new PortalException("Response in response to " + inResponseTo
					+ " does not match " + "any authentication requests");
		}
	}

	protected void verifyIssuer(SAMLMessageContext<?, ?, ?> samlMessageContext,
			Issuer issuer) throws PortalException {

		String issuerFormat = issuer.getFormat();

		if ((issuerFormat != null) && !issuerFormat.equals(NameIDType.ENTITY)) {
			throw new PortalException("Invalid issuer format " + issuerFormat);
		}

		String peerEntityId = samlMessageContext.getPeerEntityId();

		if (!peerEntityId.equals(issuer.getValue())) {
			throw new PortalException(
					"Issuer does not match expected peer entity ID "
							+ peerEntityId);
		}
	}

	protected void verifyNotOnOrAfterDateTime(long clockSkew, DateTime dateTime)
			throws PortalException {

		DateTime nowDateTime = new DateTime(DateTimeZone.UTC);

		DateTime upperBoundDateTime = dateTime.plusMillis((int) clockSkew);

		if (upperBoundDateTime.isBefore(nowDateTime)) {
			throw new PortalException("Date " + upperBoundDateTime.toString()
					+ " is before " + nowDateTime.toString());
		}
	}

	protected void verifyReplay(SAMLMessageContext<?, ?, ?> samlMessageContext,
			Assertion assertion) throws PortalException {

		Issuer issuer = assertion.getIssuer();
		String idpEntityId = issuer.getValue();
		String messageKey = assertion.getID();

		DateTime notOnOrAfter = new DateTime();

		notOnOrAfter = notOnOrAfter
				.plusMillis(PortletPropsValues.SAML_REPLAY_CACHE_DURATION);

		try {
			SamlMessage samlMessage = SamlMessageLocalServiceUtil
					.fetchSamlMessage(idpEntityId, messageKey);

			if ((samlMessage != null) && !samlMessage.isExpired()) {
				throw new PortalException("SAML assertion " + messageKey
						+ " replayed from IdP " + idpEntityId);
			} else {
				if (samlMessage != null) {
					SamlMessageLocalServiceUtil.deleteSamlMessage(samlMessage);
				}

				ServiceContext serviceContext = new ServiceContext();

				long companyId = CompanyThreadLocal.getCompanyId();

				serviceContext.setCompanyId(companyId);

				SamlMessageLocalServiceUtil.addSamlMessage(idpEntityId,
						messageKey, notOnOrAfter.toDate(), serviceContext);
			}
		} catch (SystemException se) {
			throw new PortalException(se);
		}
	}

	protected void verifySignature(
			SAMLMessageContext<?, ?, ?> samlMessageContext,
			Signature signature, TrustEngine<Signature> trustEngine)
			throws PortalException {

		try {
			_samlSignatureProfileValidator.validate(signature);

			CriteriaSet criteriaSet = new CriteriaSet();

			criteriaSet.add(new EntityIDCriteria(samlMessageContext
					.getPeerEntityId()));
			criteriaSet.add(new MetadataCriteria(
					IDPSSODescriptor.DEFAULT_ELEMENT_NAME,
					SAMLConstants.SAML20P_NS));
			criteriaSet.add(new UsageCriteria(UsageType.SIGNING));

			if (!trustEngine.validate(signature, criteriaSet)) {
				throw new SignatureException("Unable validate signature trust");
			}
		} catch (Exception e) {
			if (e instanceof PortalException) {
				throw (PortalException) e;
			}

			throw new PortalException("Unable to verify signature", e);
		}
	}

	protected void verifySubject(
			SAMLMessageContext<?, ?, NameID> samlMessageContext, Subject subject)
			throws PortalException {

		List<SubjectConfirmation> subjectConfirmations = subject
				.getSubjectConfirmations();

		for (SubjectConfirmation subjectConfirmation : subjectConfirmations) {
			String method = subjectConfirmation.getMethod();

			if (method.equals(SubjectConfirmation.METHOD_BEARER)) {
				SubjectConfirmationData subjectConfirmationData = subjectConfirmation
						.getSubjectConfirmationData();

				if (subjectConfirmationData == null) {
					continue;
				}

				verifyNotOnOrAfterDateTime(MetadataManagerUtil.getClockSkew(),
						subjectConfirmationData.getNotOnOrAfter());

				if (Validator.isNull(subjectConfirmationData.getRecipient())) {
					continue;
				} else {
					verifyDestination(samlMessageContext,
							subjectConfirmationData.getRecipient());
				}

				NameID nameId = subject.getNameID();

				samlMessageContext.setSubjectNameIdentifier(nameId);

				return;
			}
		}

		throw new PortalException("Unable to verify subject");
	}

	private static Log _log = LogFactoryUtil.getLog(WebSsoProfileImpl.class);

	private static SAMLSignatureProfileValidator _samlSignatureProfileValidator = new SAMLSignatureProfileValidator();

}