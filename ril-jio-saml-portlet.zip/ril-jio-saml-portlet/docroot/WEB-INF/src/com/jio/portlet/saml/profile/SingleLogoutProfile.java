package com.jio.portlet.saml.profile;

import com.jio.portlet.saml.model.SamlSession;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface SingleLogoutProfile {

	public SamlSession getSamlSession(HttpServletRequest request)
		throws SystemException;

	public boolean isSingleLogoutSupported(HttpServletRequest request);

	public void logout(
		HttpServletRequest request, HttpServletResponse response);

	public void processSingleLogout(
			HttpServletRequest request, HttpServletResponse response)
		throws PortalException, SystemException;

	public void processSpLogout(
			HttpServletRequest request, HttpServletResponse response)
		throws PortalException, SystemException;

	public void terminateSpSession(
		HttpServletRequest request, HttpServletResponse response);



}