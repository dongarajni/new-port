package com.jio.portlet.saml.binding;

import org.opensaml.ws.message.decoder.MessageDecoder;
import org.opensaml.ws.message.encoder.MessageEncoder;

public interface SamlBinding {

	public String getCommunicationProfileId();

	public MessageDecoder getMessageDecoder();

	public MessageEncoder getMessageEncoder();

}