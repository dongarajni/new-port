package com.jio.portlet.saml.metadata;

import com.jio.hook.common.util.PortletPropsKeys;
import com.jio.hook.common.util.PortletPropsValues;
import com.jio.portlet.saml.provider.CachingChainingMetadataProvider;
import com.jio.portlet.saml.provider.DBMetadataProvider;
import com.jio.portlet.saml.provider.ReinitializingFilesystemMetadataProvider;
import com.jio.portlet.saml.provider.ReinitializingHttpMetadataProvider;
import com.liferay.portal.kernel.concurrent.ReadWriteLockKey;
import com.liferay.portal.kernel.concurrent.ReadWriteLockRegistry;
import com.liferay.portal.kernel.configuration.Filter;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.security.auth.CompanyThreadLocal;

import java.io.File;
import java.util.List;
import java.util.Timer;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.httpclient.HttpClient;
import org.opensaml.Configuration;
import org.opensaml.common.binding.security.SAMLProtocolMessageXMLSignatureSecurityPolicyRule;
import org.opensaml.common.xml.SAMLConstants;
import org.opensaml.saml2.binding.security.SAML2HTTPPostSimpleSignRule;
import org.opensaml.saml2.binding.security.SAML2HTTPRedirectDeflateSignatureRule;
import org.opensaml.saml2.core.NameIDType;
import org.opensaml.saml2.metadata.EntityDescriptor;
import org.opensaml.saml2.metadata.provider.BaseMetadataProvider;
import org.opensaml.saml2.metadata.provider.FilesystemMetadataProvider;
import org.opensaml.saml2.metadata.provider.HTTPMetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.opensaml.security.MetadataCredentialResolver;
import org.opensaml.ws.security.SecurityPolicy;
import org.opensaml.ws.security.SecurityPolicyResolver;
import org.opensaml.ws.security.SecurityPolicyRule;
import org.opensaml.ws.security.provider.BasicSecurityPolicy;
import org.opensaml.ws.security.provider.HTTPRule;
import org.opensaml.ws.security.provider.MandatoryAuthenticatedMessageRule;
import org.opensaml.ws.security.provider.MandatoryIssuerRule;
import org.opensaml.ws.security.provider.StaticSecurityPolicyResolver;
import org.opensaml.xml.parse.ParserPool;
import org.opensaml.xml.security.CriteriaSet;
import org.opensaml.xml.security.SecurityConfiguration;
import org.opensaml.xml.security.SecurityException;
import org.opensaml.xml.security.credential.Credential;
import org.opensaml.xml.security.credential.CredentialResolver;
import org.opensaml.xml.security.criteria.EntityIDCriteria;
import org.opensaml.xml.security.keyinfo.KeyInfoCredentialResolver;
import org.opensaml.xml.signature.SignatureTrustEngine;
import org.opensaml.xml.signature.impl.ChainingSignatureTrustEngine;
import org.opensaml.xml.signature.impl.ExplicitKeySignatureTrustEngine;

public class MetadataManagerImpl implements MetadataManager {

	public static final int SAML_IDP_ASSERTION_LIFETIME_DEFAULT = 1800;

	public long getClockSkew() {
		return GetterUtil.getInteger(
				PropsUtil.get(PortletPropsKeys.SAML_SP_CLOCK_SKEW), 3000);
	}

	public String getDefaultIdpEntityId() {
		return GetterUtil.getString(PropsUtil
				.get(PortletPropsKeys.SAML_SP_DEFAULT_IDP_ENTITY_ID));
	}

	public EntityDescriptor getEntityDescriptor(HttpServletRequest request)
			throws MetadataProviderException {

		try {

			return MetadataGeneratorUtil.buildSpEntityDescriptor(request,
					getLocalEntityId(), isSignAuthnRequests(),
					isSignMetadata(), isSSLRequired(),
					isWantAssertionsSigned(), getSigningCredential());

		} catch (Exception e) {
			throw new MetadataProviderException(e);
		}
	}

	public String getLocalEntityId() {
		return GetterUtil.getString(PropsUtil
				.get(PortletPropsKeys.SAML_ENTITY_ID));
	}

	public MetadataProvider getMetadataProvider()
			throws MetadataProviderException {

		long companyId = CompanyThreadLocal.getCompanyId();

		ReadWriteLockKey<Long> readWriteLockKey = new ReadWriteLockKey<Long>(
				companyId, true);

		Lock lock = _readWriteLockRegistry.acquireLock(readWriteLockKey);

		lock.lock();

		try {
			MetadataProvider metadataProvider = _metadataProviders
					.get(companyId);

			if (metadataProvider != null) {
				return metadataProvider;
			}

			CachingChainingMetadataProvider cachingChainingMetadataProvider = new CachingChainingMetadataProvider();

			metadataProvider = cachingChainingMetadataProvider;

			DBMetadataProvider dbMetadataProvider = new DBMetadataProvider();

			dbMetadataProvider.setParserPool(_parserPool);

			cachingChainingMetadataProvider.addMetadataProvider(
				dbMetadataProvider);
			
			String[] paths = PropsUtil
					.getArray(PortletPropsKeys.SAML_METADATA_PATHS);

			for (String path : paths) {
				if (path.startsWith("http://") || path.startsWith("https://")) {
					HTTPMetadataProvider httpMetadataProvider = new ReinitializingHttpMetadataProvider(
							_timer, _httpClient, path);

					httpMetadataProvider.setFailFastInitialization(false);
					httpMetadataProvider
							.setMaxRefreshDelay(PortletPropsValues.SAML_METADATA_MAX_REFRESH_DELAY);
					httpMetadataProvider
							.setMinRefreshDelay(PortletPropsValues.SAML_METADATA_MIN_REFRESH_DELAY);
					httpMetadataProvider.setParserPool(_parserPool);

					try {
						httpMetadataProvider.initialize();
					} catch (MetadataProviderException mpe) {
						if (_log.isWarnEnabled()) {
							_log.warn("Unable to initialize provider " + path);
						}
					}

					cachingChainingMetadataProvider
							.addMetadataProvider(httpMetadataProvider);
				} else {
					FilesystemMetadataProvider filesystemMetadataProvider = new ReinitializingFilesystemMetadataProvider(
							_timer, new File(path));

					filesystemMetadataProvider.setFailFastInitialization(false);
					filesystemMetadataProvider
							.setMaxRefreshDelay(PortletPropsValues.SAML_METADATA_MAX_REFRESH_DELAY);
					filesystemMetadataProvider
							.setMinRefreshDelay(PortletPropsValues.SAML_METADATA_MIN_REFRESH_DELAY);
					filesystemMetadataProvider.setParserPool(_parserPool);

					try {
						filesystemMetadataProvider.initialize();
					} catch (MetadataProviderException mpe) {
						if (_log.isWarnEnabled()) {
							_log.warn("Unable to initialize provider " + path);
						}
					}

					cachingChainingMetadataProvider
							.addMetadataProvider(filesystemMetadataProvider);
				}
			}

			_metadataProviders.put(companyId, metadataProvider);

			return metadataProvider;
		} finally {
			lock.unlock();

			if (readWriteLockKey != null) {
				_readWriteLockRegistry.releaseLock(readWriteLockKey);
			}
		}
	}

	public String getNameIdFormat(String entityId) {
		String nameIdFormat = StringPool.BLANK;

		nameIdFormat = GetterUtil.getString(PropsUtil.get(
				PortletPropsKeys.SAML_SP_NAME_ID_FORMAT, new Filter(entityId)));

		if (Validator.isNull(nameIdFormat)) {
			nameIdFormat = NameIDType.EMAIL;
		}

		return nameIdFormat;
	}

	public SecurityPolicyResolver getSecurityPolicyResolver(
			String communicationProfileId, boolean requireSignature)
			throws MetadataProviderException {

		SecurityPolicy securityPolicy = new BasicSecurityPolicy();

		List<SecurityPolicyRule> securityPolicyRules = securityPolicy
				.getPolicyRules();

		if (requireSignature) {
			SignatureTrustEngine signatureTrustEngine = getSignatureTrustEngine();

			if (communicationProfileId
					.equals(SAMLConstants.SAML2_REDIRECT_BINDING_URI)) {

				SecurityPolicyRule securityPolicyRule = new SAML2HTTPRedirectDeflateSignatureRule(
						signatureTrustEngine);

				securityPolicyRules.add(securityPolicyRule);
			} else if (communicationProfileId
					.equals(SAMLConstants.SAML2_POST_SIMPLE_SIGN_BINDING_URI)) {

				SecurityConfiguration securityConfiguration = Configuration
						.getGlobalSecurityConfiguration();

				KeyInfoCredentialResolver keyInfoCredentialResolver = securityConfiguration
						.getDefaultKeyInfoCredentialResolver();

				SecurityPolicyRule securityPolicyRule = new SAML2HTTPPostSimpleSignRule(
						signatureTrustEngine, _parserPool,
						keyInfoCredentialResolver);

				securityPolicyRules.add(securityPolicyRule);
			} else {
				SecurityPolicyRule securityPolicyRule = new SAMLProtocolMessageXMLSignatureSecurityPolicyRule(
						signatureTrustEngine);

				securityPolicyRules.add(securityPolicyRule);
			}

			MandatoryAuthenticatedMessageRule mandatoryAuthenticatedMessageRule = new MandatoryAuthenticatedMessageRule();

			securityPolicyRules.add(mandatoryAuthenticatedMessageRule);
		}

		HTTPRule httpRule = new HTTPRule(null, null,
				MetadataManagerUtil.isSSLRequired());

		securityPolicyRules.add(httpRule);

		MandatoryIssuerRule mandatoryIssuerRule = new MandatoryIssuerRule();

		securityPolicyRules.add(mandatoryIssuerRule);

		StaticSecurityPolicyResolver securityPolicyResolver = new StaticSecurityPolicyResolver(
				securityPolicy);

		return securityPolicyResolver;
	}

	public String getSessionKeepAliveURL(String entityId) {
		return PropsUtil.get(
				PortletPropsKeys.SAML_IDP_METADATA_SESSION_KEEP_ALIVE_URL,
				new Filter(entityId));
	}

	public long getSessionMaximumAge() {
		return GetterUtil.getLong(PropsUtil
				.get(PortletPropsKeys.SAML_IDP_SESSION_MAXIMUM_AGE));
	}

	public long getSessionTimeout() {
		return GetterUtil.getLong(PropsUtil
				.get(PortletPropsKeys.SAML_IDP_SESSION_TIMEOUT));
	}

	public SignatureTrustEngine getSignatureTrustEngine()
			throws MetadataProviderException {

		ChainingSignatureTrustEngine chainingSignatureTrustEngine = new ChainingSignatureTrustEngine();

		List<SignatureTrustEngine> signatureTrustEngines = chainingSignatureTrustEngine
				.getChain();

		MetadataCredentialResolver metadataCredentialResolver = new MetadataCredentialResolver(
				getMetadataProvider());

		SecurityConfiguration securityConfiguration = Configuration
				.getGlobalSecurityConfiguration();

		KeyInfoCredentialResolver keyInfoCredentialResolver = securityConfiguration
				.getDefaultKeyInfoCredentialResolver();

		SignatureTrustEngine signatureTrustEngine = new ExplicitKeySignatureTrustEngine(
				metadataCredentialResolver, keyInfoCredentialResolver);

		signatureTrustEngines.add(signatureTrustEngine);

		signatureTrustEngine = new ExplicitKeySignatureTrustEngine(
				_credentialResolver, keyInfoCredentialResolver);

		signatureTrustEngines.add(signatureTrustEngine);

		return chainingSignatureTrustEngine;
	}

	public Credential getSigningCredential() throws SecurityException {
		CriteriaSet criteriaSet = new CriteriaSet();

		String entityId = getLocalEntityId();

		if (Validator.isNull(entityId)) {
			return null;
		}

		EntityIDCriteria entityIdCriteria = new EntityIDCriteria(entityId);

		criteriaSet.add(entityIdCriteria);

		return _credentialResolver.resolveSingle(criteriaSet);
	}

	public String getUserAttributeMappings(String entityId) {
		return PropsUtil.get(PortletPropsKeys.SAML_SP_USER_ATTRIBUTE_MAPPINGS);
	}

	public boolean isSignAuthnRequests() {
		return GetterUtil.getBoolean(PropsUtil
				.get(PortletPropsKeys.SAML_SP_SIGN_AUTHN_REQUEST));
	}

	public boolean isSignMetadata() {
		return GetterUtil.getBoolean(PropsUtil
				.get(PortletPropsKeys.SAML_SIGN_METADATA));
	}

	public boolean isSSLRequired() {
		return GetterUtil.getBoolean(PropsUtil
				.get(PortletPropsKeys.SAML_SSL_REQUIRED));
	}

	public boolean isWantAssertionsSigned() {
		return GetterUtil.getBoolean(PropsUtil
				.get(PortletPropsKeys.SAML_SP_ASSERTION_SIGNATURE_REQUIRED));
	}

	public boolean isWantAuthnRequestSigned() {
		return GetterUtil
				.getBoolean(PropsUtil
						.get(PortletPropsKeys.SAML_IDP_AUTHN_REQUEST_SIGNATURE_REQUIRED));
	}

	public void setCredentialResolver(CredentialResolver credentialResolver) {
		_credentialResolver = credentialResolver;
	}

	public void setHttpClient(HttpClient httpClient) {
		_httpClient = httpClient;
	}

	public void setParserPool(ParserPool parserPool) {
		_parserPool = parserPool;
	}

	public void shutdown() {
		for (MetadataProvider metadataProvider : _metadataProviders.values()) {
			if (metadataProvider instanceof BaseMetadataProvider) {
				BaseMetadataProvider baseMetadataProvider = (BaseMetadataProvider) metadataProvider;

				baseMetadataProvider.destroy();
			}
		}

		_metadataProviders.clear();
		_timer.cancel();
	}

	private static Log _log = LogFactoryUtil.getLog(MetadataManagerImpl.class);

	private CredentialResolver _credentialResolver;
	private HttpClient _httpClient;
	private ConcurrentHashMap<Long, MetadataProvider> _metadataProviders = new ConcurrentHashMap<Long, MetadataProvider>();
	private ParserPool _parserPool;
	private ReadWriteLockRegistry _readWriteLockRegistry = new ReadWriteLockRegistry();
	private Timer _timer = new Timer(true);

}