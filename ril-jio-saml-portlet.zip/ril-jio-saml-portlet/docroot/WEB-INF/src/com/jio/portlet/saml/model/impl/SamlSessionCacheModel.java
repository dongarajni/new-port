/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.model.impl;

import com.jio.portlet.saml.model.SamlSession;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing SamlSession in entity cache.
 *
 * @author Ashish Jadhav
 * @see SamlSession
 * @generated
 */
public class SamlSessionCacheModel implements CacheModel<SamlSession>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(31);

		sb.append("{sessionId=");
		sb.append(sessionId);
		sb.append(", sessionKey=");
		sb.append(sessionKey);
		sb.append(", assertionXml=");
		sb.append(assertionXml);
		sb.append(", jSessionId=");
		sb.append(jSessionId);
		sb.append(", nameIdFormat=");
		sb.append(nameIdFormat);
		sb.append(", nameIdNameQualifier=");
		sb.append(nameIdNameQualifier);
		sb.append(", nameIdSPNameQualifier=");
		sb.append(nameIdSPNameQualifier);
		sb.append(", nameIdValue=");
		sb.append(nameIdValue);
		sb.append(", sessionIndex=");
		sb.append(sessionIndex);
		sb.append(", terminated=");
		sb.append(terminated);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", userId=");
		sb.append(userId);
		sb.append(", userName=");
		sb.append(userName);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", modifiedDate=");
		sb.append(modifiedDate);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public SamlSession toEntityModel() {
		SamlSessionImpl samlSessionImpl = new SamlSessionImpl();

		samlSessionImpl.setSessionId(sessionId);

		if (sessionKey == null) {
			samlSessionImpl.setSessionKey(StringPool.BLANK);
		}
		else {
			samlSessionImpl.setSessionKey(sessionKey);
		}

		if (assertionXml == null) {
			samlSessionImpl.setAssertionXml(StringPool.BLANK);
		}
		else {
			samlSessionImpl.setAssertionXml(assertionXml);
		}

		if (jSessionId == null) {
			samlSessionImpl.setJSessionId(StringPool.BLANK);
		}
		else {
			samlSessionImpl.setJSessionId(jSessionId);
		}

		if (nameIdFormat == null) {
			samlSessionImpl.setNameIdFormat(StringPool.BLANK);
		}
		else {
			samlSessionImpl.setNameIdFormat(nameIdFormat);
		}

		if (nameIdNameQualifier == null) {
			samlSessionImpl.setNameIdNameQualifier(StringPool.BLANK);
		}
		else {
			samlSessionImpl.setNameIdNameQualifier(nameIdNameQualifier);
		}

		if (nameIdSPNameQualifier == null) {
			samlSessionImpl.setNameIdSPNameQualifier(StringPool.BLANK);
		}
		else {
			samlSessionImpl.setNameIdSPNameQualifier(nameIdSPNameQualifier);
		}

		if (nameIdValue == null) {
			samlSessionImpl.setNameIdValue(StringPool.BLANK);
		}
		else {
			samlSessionImpl.setNameIdValue(nameIdValue);
		}

		if (sessionIndex == null) {
			samlSessionImpl.setSessionIndex(StringPool.BLANK);
		}
		else {
			samlSessionImpl.setSessionIndex(sessionIndex);
		}

		samlSessionImpl.setTerminated(terminated);
		samlSessionImpl.setCompanyId(companyId);
		samlSessionImpl.setUserId(userId);

		if (userName == null) {
			samlSessionImpl.setUserName(StringPool.BLANK);
		}
		else {
			samlSessionImpl.setUserName(userName);
		}

		if (createDate == Long.MIN_VALUE) {
			samlSessionImpl.setCreateDate(null);
		}
		else {
			samlSessionImpl.setCreateDate(new Date(createDate));
		}

		if (modifiedDate == Long.MIN_VALUE) {
			samlSessionImpl.setModifiedDate(null);
		}
		else {
			samlSessionImpl.setModifiedDate(new Date(modifiedDate));
		}

		samlSessionImpl.resetOriginalValues();

		return samlSessionImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		sessionId = objectInput.readLong();
		sessionKey = objectInput.readUTF();
		assertionXml = objectInput.readUTF();
		jSessionId = objectInput.readUTF();
		nameIdFormat = objectInput.readUTF();
		nameIdNameQualifier = objectInput.readUTF();
		nameIdSPNameQualifier = objectInput.readUTF();
		nameIdValue = objectInput.readUTF();
		sessionIndex = objectInput.readUTF();
		terminated = objectInput.readBoolean();
		companyId = objectInput.readLong();
		userId = objectInput.readLong();
		userName = objectInput.readUTF();
		createDate = objectInput.readLong();
		modifiedDate = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(sessionId);

		if (sessionKey == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(sessionKey);
		}

		if (assertionXml == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(assertionXml);
		}

		if (jSessionId == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(jSessionId);
		}

		if (nameIdFormat == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(nameIdFormat);
		}

		if (nameIdNameQualifier == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(nameIdNameQualifier);
		}

		if (nameIdSPNameQualifier == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(nameIdSPNameQualifier);
		}

		if (nameIdValue == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(nameIdValue);
		}

		if (sessionIndex == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(sessionIndex);
		}

		objectOutput.writeBoolean(terminated);
		objectOutput.writeLong(companyId);
		objectOutput.writeLong(userId);

		if (userName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(userName);
		}

		objectOutput.writeLong(createDate);
		objectOutput.writeLong(modifiedDate);
	}

	public long sessionId;
	public String sessionKey;
	public String assertionXml;
	public String jSessionId;
	public String nameIdFormat;
	public String nameIdNameQualifier;
	public String nameIdSPNameQualifier;
	public String nameIdValue;
	public String sessionIndex;
	public boolean terminated;
	public long companyId;
	public long userId;
	public String userName;
	public long createDate;
	public long modifiedDate;
}