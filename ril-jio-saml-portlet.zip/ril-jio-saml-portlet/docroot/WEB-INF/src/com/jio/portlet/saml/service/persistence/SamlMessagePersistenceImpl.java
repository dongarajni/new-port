/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.service.persistence;

import com.jio.portlet.saml.NoSuchSamlMessageException;
import com.jio.portlet.saml.model.SamlMessage;
import com.jio.portlet.saml.model.impl.SamlMessageImpl;
import com.jio.portlet.saml.model.impl.SamlMessageModelImpl;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the saml message service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Ashish Jadhav
 * @see SamlMessagePersistence
 * @see SamlMessageUtil
 * @generated
 */
public class SamlMessagePersistenceImpl extends BasePersistenceImpl<SamlMessage>
	implements SamlMessagePersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link SamlMessageUtil} to access the saml message persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = SamlMessageImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(SamlMessageModelImpl.ENTITY_CACHE_ENABLED,
			SamlMessageModelImpl.FINDER_CACHE_ENABLED, SamlMessageImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(SamlMessageModelImpl.ENTITY_CACHE_ENABLED,
			SamlMessageModelImpl.FINDER_CACHE_ENABLED, SamlMessageImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(SamlMessageModelImpl.ENTITY_CACHE_ENABLED,
			SamlMessageModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_FETCH_BY_ENTITYID_RESPONSEKEY = new FinderPath(SamlMessageModelImpl.ENTITY_CACHE_ENABLED,
			SamlMessageModelImpl.FINDER_CACHE_ENABLED, SamlMessageImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByEntityId_ResponseKey",
			new String[] { String.class.getName(), String.class.getName() },
			SamlMessageModelImpl.ENTITYID_COLUMN_BITMASK |
			SamlMessageModelImpl.RESPONSEKEY_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_ENTITYID_RESPONSEKEY = new FinderPath(SamlMessageModelImpl.ENTITY_CACHE_ENABLED,
			SamlMessageModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByEntityId_ResponseKey",
			new String[] { String.class.getName(), String.class.getName() });

	/**
	 * Returns the saml message where entityId = &#63; and responseKey = &#63; or throws a {@link com.jio.portlet.saml.NoSuchSamlMessageException} if it could not be found.
	 *
	 * @param entityId the entity ID
	 * @param responseKey the response key
	 * @return the matching saml message
	 * @throws com.jio.portlet.saml.NoSuchSamlMessageException if a matching saml message could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlMessage findByEntityId_ResponseKey(String entityId,
		String responseKey) throws NoSuchSamlMessageException, SystemException {
		SamlMessage samlMessage = fetchByEntityId_ResponseKey(entityId,
				responseKey);

		if (samlMessage == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("entityId=");
			msg.append(entityId);

			msg.append(", responseKey=");
			msg.append(responseKey);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchSamlMessageException(msg.toString());
		}

		return samlMessage;
	}

	/**
	 * Returns the saml message where entityId = &#63; and responseKey = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param entityId the entity ID
	 * @param responseKey the response key
	 * @return the matching saml message, or <code>null</code> if a matching saml message could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlMessage fetchByEntityId_ResponseKey(String entityId,
		String responseKey) throws SystemException {
		return fetchByEntityId_ResponseKey(entityId, responseKey, true);
	}

	/**
	 * Returns the saml message where entityId = &#63; and responseKey = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param entityId the entity ID
	 * @param responseKey the response key
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching saml message, or <code>null</code> if a matching saml message could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlMessage fetchByEntityId_ResponseKey(String entityId,
		String responseKey, boolean retrieveFromCache)
		throws SystemException {
		Object[] finderArgs = new Object[] { entityId, responseKey };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_ENTITYID_RESPONSEKEY,
					finderArgs, this);
		}

		if (result instanceof SamlMessage) {
			SamlMessage samlMessage = (SamlMessage)result;

			if (!Validator.equals(entityId, samlMessage.getEntityId()) ||
					!Validator.equals(responseKey, samlMessage.getResponseKey())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_SAMLMESSAGE_WHERE);

			boolean bindEntityId = false;

			if (entityId == null) {
				query.append(_FINDER_COLUMN_ENTITYID_RESPONSEKEY_ENTITYID_1);
			}
			else if (entityId.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_ENTITYID_RESPONSEKEY_ENTITYID_3);
			}
			else {
				bindEntityId = true;

				query.append(_FINDER_COLUMN_ENTITYID_RESPONSEKEY_ENTITYID_2);
			}

			boolean bindResponseKey = false;

			if (responseKey == null) {
				query.append(_FINDER_COLUMN_ENTITYID_RESPONSEKEY_RESPONSEKEY_1);
			}
			else if (responseKey.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_ENTITYID_RESPONSEKEY_RESPONSEKEY_3);
			}
			else {
				bindResponseKey = true;

				query.append(_FINDER_COLUMN_ENTITYID_RESPONSEKEY_RESPONSEKEY_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindEntityId) {
					qPos.add(entityId);
				}

				if (bindResponseKey) {
					qPos.add(responseKey);
				}

				List<SamlMessage> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_ENTITYID_RESPONSEKEY,
						finderArgs, list);
				}
				else {
					if ((list.size() > 1) && _log.isWarnEnabled()) {
						_log.warn(
							"SamlMessagePersistenceImpl.fetchByEntityId_ResponseKey(String, String, boolean) with parameters (" +
							StringUtil.merge(finderArgs) +
							") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
					}

					SamlMessage samlMessage = list.get(0);

					result = samlMessage;

					cacheResult(samlMessage);

					if ((samlMessage.getEntityId() == null) ||
							!samlMessage.getEntityId().equals(entityId) ||
							(samlMessage.getResponseKey() == null) ||
							!samlMessage.getResponseKey().equals(responseKey)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_ENTITYID_RESPONSEKEY,
							finderArgs, samlMessage);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_ENTITYID_RESPONSEKEY,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (SamlMessage)result;
		}
	}

	/**
	 * Removes the saml message where entityId = &#63; and responseKey = &#63; from the database.
	 *
	 * @param entityId the entity ID
	 * @param responseKey the response key
	 * @return the saml message that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlMessage removeByEntityId_ResponseKey(String entityId,
		String responseKey) throws NoSuchSamlMessageException, SystemException {
		SamlMessage samlMessage = findByEntityId_ResponseKey(entityId,
				responseKey);

		return remove(samlMessage);
	}

	/**
	 * Returns the number of saml messages where entityId = &#63; and responseKey = &#63;.
	 *
	 * @param entityId the entity ID
	 * @param responseKey the response key
	 * @return the number of matching saml messages
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByEntityId_ResponseKey(String entityId, String responseKey)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_ENTITYID_RESPONSEKEY;

		Object[] finderArgs = new Object[] { entityId, responseKey };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_SAMLMESSAGE_WHERE);

			boolean bindEntityId = false;

			if (entityId == null) {
				query.append(_FINDER_COLUMN_ENTITYID_RESPONSEKEY_ENTITYID_1);
			}
			else if (entityId.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_ENTITYID_RESPONSEKEY_ENTITYID_3);
			}
			else {
				bindEntityId = true;

				query.append(_FINDER_COLUMN_ENTITYID_RESPONSEKEY_ENTITYID_2);
			}

			boolean bindResponseKey = false;

			if (responseKey == null) {
				query.append(_FINDER_COLUMN_ENTITYID_RESPONSEKEY_RESPONSEKEY_1);
			}
			else if (responseKey.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_ENTITYID_RESPONSEKEY_RESPONSEKEY_3);
			}
			else {
				bindResponseKey = true;

				query.append(_FINDER_COLUMN_ENTITYID_RESPONSEKEY_RESPONSEKEY_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindEntityId) {
					qPos.add(entityId);
				}

				if (bindResponseKey) {
					qPos.add(responseKey);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_ENTITYID_RESPONSEKEY_ENTITYID_1 = "samlMessage.entityId IS NULL AND ";
	private static final String _FINDER_COLUMN_ENTITYID_RESPONSEKEY_ENTITYID_2 = "samlMessage.entityId = ? AND ";
	private static final String _FINDER_COLUMN_ENTITYID_RESPONSEKEY_ENTITYID_3 = "(samlMessage.entityId IS NULL OR samlMessage.entityId = '') AND ";
	private static final String _FINDER_COLUMN_ENTITYID_RESPONSEKEY_RESPONSEKEY_1 =
		"samlMessage.responseKey IS NULL";
	private static final String _FINDER_COLUMN_ENTITYID_RESPONSEKEY_RESPONSEKEY_2 =
		"samlMessage.responseKey = ?";
	private static final String _FINDER_COLUMN_ENTITYID_RESPONSEKEY_RESPONSEKEY_3 =
		"(samlMessage.responseKey IS NULL OR samlMessage.responseKey = '')";

	public SamlMessagePersistenceImpl() {
		setModelClass(SamlMessage.class);
	}

	/**
	 * Caches the saml message in the entity cache if it is enabled.
	 *
	 * @param samlMessage the saml message
	 */
	@Override
	public void cacheResult(SamlMessage samlMessage) {
		EntityCacheUtil.putResult(SamlMessageModelImpl.ENTITY_CACHE_ENABLED,
			SamlMessageImpl.class, samlMessage.getPrimaryKey(), samlMessage);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_ENTITYID_RESPONSEKEY,
			new Object[] { samlMessage.getEntityId(), samlMessage.getResponseKey() },
			samlMessage);

		samlMessage.resetOriginalValues();
	}

	/**
	 * Caches the saml messages in the entity cache if it is enabled.
	 *
	 * @param samlMessages the saml messages
	 */
	@Override
	public void cacheResult(List<SamlMessage> samlMessages) {
		for (SamlMessage samlMessage : samlMessages) {
			if (EntityCacheUtil.getResult(
						SamlMessageModelImpl.ENTITY_CACHE_ENABLED,
						SamlMessageImpl.class, samlMessage.getPrimaryKey()) == null) {
				cacheResult(samlMessage);
			}
			else {
				samlMessage.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all saml messages.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(SamlMessageImpl.class.getName());
		}

		EntityCacheUtil.clearCache(SamlMessageImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the saml message.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(SamlMessage samlMessage) {
		EntityCacheUtil.removeResult(SamlMessageModelImpl.ENTITY_CACHE_ENABLED,
			SamlMessageImpl.class, samlMessage.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache(samlMessage);
	}

	@Override
	public void clearCache(List<SamlMessage> samlMessages) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (SamlMessage samlMessage : samlMessages) {
			EntityCacheUtil.removeResult(SamlMessageModelImpl.ENTITY_CACHE_ENABLED,
				SamlMessageImpl.class, samlMessage.getPrimaryKey());

			clearUniqueFindersCache(samlMessage);
		}
	}

	protected void cacheUniqueFindersCache(SamlMessage samlMessage) {
		if (samlMessage.isNew()) {
			Object[] args = new Object[] {
					samlMessage.getEntityId(), samlMessage.getResponseKey()
				};

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_ENTITYID_RESPONSEKEY,
				args, Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_ENTITYID_RESPONSEKEY,
				args, samlMessage);
		}
		else {
			SamlMessageModelImpl samlMessageModelImpl = (SamlMessageModelImpl)samlMessage;

			if ((samlMessageModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_ENTITYID_RESPONSEKEY.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						samlMessage.getEntityId(), samlMessage.getResponseKey()
					};

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_ENTITYID_RESPONSEKEY,
					args, Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_ENTITYID_RESPONSEKEY,
					args, samlMessage);
			}
		}
	}

	protected void clearUniqueFindersCache(SamlMessage samlMessage) {
		SamlMessageModelImpl samlMessageModelImpl = (SamlMessageModelImpl)samlMessage;

		Object[] args = new Object[] {
				samlMessage.getEntityId(), samlMessage.getResponseKey()
			};

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ENTITYID_RESPONSEKEY,
			args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_ENTITYID_RESPONSEKEY,
			args);

		if ((samlMessageModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_ENTITYID_RESPONSEKEY.getColumnBitmask()) != 0) {
			args = new Object[] {
					samlMessageModelImpl.getOriginalEntityId(),
					samlMessageModelImpl.getOriginalResponseKey()
				};

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ENTITYID_RESPONSEKEY,
				args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_ENTITYID_RESPONSEKEY,
				args);
		}
	}

	/**
	 * Creates a new saml message with the primary key. Does not add the saml message to the database.
	 *
	 * @param samlMessageId the primary key for the new saml message
	 * @return the new saml message
	 */
	@Override
	public SamlMessage create(long samlMessageId) {
		SamlMessage samlMessage = new SamlMessageImpl();

		samlMessage.setNew(true);
		samlMessage.setPrimaryKey(samlMessageId);

		return samlMessage;
	}

	/**
	 * Removes the saml message with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param samlMessageId the primary key of the saml message
	 * @return the saml message that was removed
	 * @throws com.jio.portlet.saml.NoSuchSamlMessageException if a saml message with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlMessage remove(long samlMessageId)
		throws NoSuchSamlMessageException, SystemException {
		return remove((Serializable)samlMessageId);
	}

	/**
	 * Removes the saml message with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the saml message
	 * @return the saml message that was removed
	 * @throws com.jio.portlet.saml.NoSuchSamlMessageException if a saml message with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlMessage remove(Serializable primaryKey)
		throws NoSuchSamlMessageException, SystemException {
		Session session = null;

		try {
			session = openSession();

			SamlMessage samlMessage = (SamlMessage)session.get(SamlMessageImpl.class,
					primaryKey);

			if (samlMessage == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchSamlMessageException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(samlMessage);
		}
		catch (NoSuchSamlMessageException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected SamlMessage removeImpl(SamlMessage samlMessage)
		throws SystemException {
		samlMessage = toUnwrappedModel(samlMessage);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(samlMessage)) {
				samlMessage = (SamlMessage)session.get(SamlMessageImpl.class,
						samlMessage.getPrimaryKeyObj());
			}

			if (samlMessage != null) {
				session.delete(samlMessage);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (samlMessage != null) {
			clearCache(samlMessage);
		}

		return samlMessage;
	}

	@Override
	public SamlMessage updateImpl(
		com.jio.portlet.saml.model.SamlMessage samlMessage)
		throws SystemException {
		samlMessage = toUnwrappedModel(samlMessage);

		boolean isNew = samlMessage.isNew();

		Session session = null;

		try {
			session = openSession();

			if (samlMessage.isNew()) {
				session.save(samlMessage);

				samlMessage.setNew(false);
			}
			else {
				session.merge(samlMessage);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !SamlMessageModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		EntityCacheUtil.putResult(SamlMessageModelImpl.ENTITY_CACHE_ENABLED,
			SamlMessageImpl.class, samlMessage.getPrimaryKey(), samlMessage);

		clearUniqueFindersCache(samlMessage);
		cacheUniqueFindersCache(samlMessage);

		return samlMessage;
	}

	protected SamlMessage toUnwrappedModel(SamlMessage samlMessage) {
		if (samlMessage instanceof SamlMessageImpl) {
			return samlMessage;
		}

		SamlMessageImpl samlMessageImpl = new SamlMessageImpl();

		samlMessageImpl.setNew(samlMessage.isNew());
		samlMessageImpl.setPrimaryKey(samlMessage.getPrimaryKey());

		samlMessageImpl.setSamlMessageId(samlMessage.getSamlMessageId());
		samlMessageImpl.setCompanyId(samlMessage.getCompanyId());
		samlMessageImpl.setCreateDate(samlMessage.getCreateDate());
		samlMessageImpl.setEntityId(samlMessage.getEntityId());
		samlMessageImpl.setResponseKey(samlMessage.getResponseKey());
		samlMessageImpl.setExpirationDate(samlMessage.getExpirationDate());

		return samlMessageImpl;
	}

	/**
	 * Returns the saml message with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the saml message
	 * @return the saml message
	 * @throws com.jio.portlet.saml.NoSuchSamlMessageException if a saml message with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlMessage findByPrimaryKey(Serializable primaryKey)
		throws NoSuchSamlMessageException, SystemException {
		SamlMessage samlMessage = fetchByPrimaryKey(primaryKey);

		if (samlMessage == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchSamlMessageException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return samlMessage;
	}

	/**
	 * Returns the saml message with the primary key or throws a {@link com.jio.portlet.saml.NoSuchSamlMessageException} if it could not be found.
	 *
	 * @param samlMessageId the primary key of the saml message
	 * @return the saml message
	 * @throws com.jio.portlet.saml.NoSuchSamlMessageException if a saml message with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlMessage findByPrimaryKey(long samlMessageId)
		throws NoSuchSamlMessageException, SystemException {
		return findByPrimaryKey((Serializable)samlMessageId);
	}

	/**
	 * Returns the saml message with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the saml message
	 * @return the saml message, or <code>null</code> if a saml message with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlMessage fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		SamlMessage samlMessage = (SamlMessage)EntityCacheUtil.getResult(SamlMessageModelImpl.ENTITY_CACHE_ENABLED,
				SamlMessageImpl.class, primaryKey);

		if (samlMessage == _nullSamlMessage) {
			return null;
		}

		if (samlMessage == null) {
			Session session = null;

			try {
				session = openSession();

				samlMessage = (SamlMessage)session.get(SamlMessageImpl.class,
						primaryKey);

				if (samlMessage != null) {
					cacheResult(samlMessage);
				}
				else {
					EntityCacheUtil.putResult(SamlMessageModelImpl.ENTITY_CACHE_ENABLED,
						SamlMessageImpl.class, primaryKey, _nullSamlMessage);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(SamlMessageModelImpl.ENTITY_CACHE_ENABLED,
					SamlMessageImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return samlMessage;
	}

	/**
	 * Returns the saml message with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param samlMessageId the primary key of the saml message
	 * @return the saml message, or <code>null</code> if a saml message with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlMessage fetchByPrimaryKey(long samlMessageId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)samlMessageId);
	}

	/**
	 * Returns all the saml messages.
	 *
	 * @return the saml messages
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SamlMessage> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the saml messages.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlMessageModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of saml messages
	 * @param end the upper bound of the range of saml messages (not inclusive)
	 * @return the range of saml messages
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SamlMessage> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the saml messages.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlMessageModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of saml messages
	 * @param end the upper bound of the range of saml messages (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of saml messages
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SamlMessage> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<SamlMessage> list = (List<SamlMessage>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_SAMLMESSAGE);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_SAMLMESSAGE;

				if (pagination) {
					sql = sql.concat(SamlMessageModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<SamlMessage>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SamlMessage>(list);
				}
				else {
					list = (List<SamlMessage>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the saml messages from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (SamlMessage samlMessage : findAll()) {
			remove(samlMessage);
		}
	}

	/**
	 * Returns the number of saml messages.
	 *
	 * @return the number of saml messages
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_SAMLMESSAGE);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the saml message persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.jio.portlet.saml.model.SamlMessage")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<SamlMessage>> listenersList = new ArrayList<ModelListener<SamlMessage>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<SamlMessage>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(SamlMessageImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_SAMLMESSAGE = "SELECT samlMessage FROM SamlMessage samlMessage";
	private static final String _SQL_SELECT_SAMLMESSAGE_WHERE = "SELECT samlMessage FROM SamlMessage samlMessage WHERE ";
	private static final String _SQL_COUNT_SAMLMESSAGE = "SELECT COUNT(samlMessage) FROM SamlMessage samlMessage";
	private static final String _SQL_COUNT_SAMLMESSAGE_WHERE = "SELECT COUNT(samlMessage) FROM SamlMessage samlMessage WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "samlMessage.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No SamlMessage exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No SamlMessage exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(SamlMessagePersistenceImpl.class);
	private static SamlMessage _nullSamlMessage = new SamlMessageImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<SamlMessage> toCacheModel() {
				return _nullSamlMessageCacheModel;
			}
		};

	private static CacheModel<SamlMessage> _nullSamlMessageCacheModel = new CacheModel<SamlMessage>() {
			@Override
			public SamlMessage toEntityModel() {
				return _nullSamlMessage;
			}
		};
}