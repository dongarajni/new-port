

package com.jio.portlet.saml.model.impl;

public class SamlAuthRequestImpl extends SamlAuthRequestBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this class directly. All methods that expect a saml auth request model instance should use the {@link com.jio.portlet.saml.model.SamlAuthRequest} interface instead.
	 */
	public SamlAuthRequestImpl() {
	}
}