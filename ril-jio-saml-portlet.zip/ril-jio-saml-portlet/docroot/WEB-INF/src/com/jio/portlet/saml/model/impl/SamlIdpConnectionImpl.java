package com.jio.portlet.saml.model.impl;

/**
 * The extended model implementation for the SamlIdpConnection service. Represents a row in the &quot;JIO_SamlIdpConnection&quot; database table, with each column mapped to a property of this class.
 *
 * <p>
 * Helper methods and all application logic should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jio.portlet.saml.model.SamlIdpConnection} interface.
 * </p>
 *
 */
public class SamlIdpConnectionImpl extends SamlIdpConnectionBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this class directly. All methods that expect a saml idp connection model instance should use the {@link com.jio.portlet.saml.model.SamlIdpConnection} interface instead.
	 */
	public SamlIdpConnectionImpl() {
	}
}