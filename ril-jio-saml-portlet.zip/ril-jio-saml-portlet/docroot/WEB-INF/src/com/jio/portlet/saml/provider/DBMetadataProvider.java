package com.jio.portlet.saml.provider;

import com.jio.hook.common.util.JioSamlUtil;
import com.jio.portlet.saml.model.SamlIdpConnection;
import com.jio.portlet.saml.service.SamlIdpConnectionLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.security.auth.CompanyThreadLocal;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.xml.namespace.QName;

import org.joda.time.DateTime;
import org.opensaml.saml2.common.Extensions;
import org.opensaml.saml2.metadata.EntitiesDescriptor;
import org.opensaml.saml2.metadata.EntityDescriptor;
import org.opensaml.saml2.metadata.RoleDescriptor;
import org.opensaml.saml2.metadata.provider.BaseMetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.opensaml.xml.Namespace;
import org.opensaml.xml.NamespaceManager;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.parse.ParserPool;
import org.opensaml.xml.schema.XSBooleanValue;
import org.opensaml.xml.signature.Signature;
import org.opensaml.xml.util.IDIndex;
import org.opensaml.xml.util.LazySet;
import org.opensaml.xml.util.XMLObjectHelper;
import org.w3c.dom.Element;

public class DBMetadataProvider extends BaseMetadataProvider {


	public EntitiesDescriptor getEntitiesDescriptor(String name) {
		return null;
	}


	public EntityDescriptor getEntityDescriptor(String entityId)
		throws MetadataProviderException {

		try {
			String metadataXml = getMetadataXml(entityId);

			if (Validator.isNull(metadataXml)) {
				return null;
			}

			XMLObject metadataXmlObject = XMLObjectHelper.unmarshallFromReader(
				_parserPool, new StringReader(metadataXml));

			EntityDescriptor entityDescriptor =
				JioSamlUtil.getEntityDescriptorById(entityId, metadataXmlObject);

			return entityDescriptor;
		}
		catch (Exception e) {
			throw new MetadataProviderException(e);
		}
	}


	public XMLObject getMetadata() {
		return new DBEntitiesDescriptor();
	}


	public List<RoleDescriptor> getRole(String entityId, QName qName)
		throws MetadataProviderException {

		EntityDescriptor entityDescriptor = getEntityDescriptor(entityId);

		if (entityDescriptor != null) {
			return entityDescriptor.getRoleDescriptors(qName);
		}

		return null;
	}


	public RoleDescriptor getRole(
			String entityId, QName qName, String supportedProtocol)
		throws MetadataProviderException {

		List<RoleDescriptor> roleDescriptors = getRole(entityId, qName);

		if ((roleDescriptors == null) || roleDescriptors.isEmpty()) {
			return null;
		}

		for (RoleDescriptor roleDescriptor : roleDescriptors) {
			if (roleDescriptor.isSupportedProtocol(supportedProtocol)) {
				return roleDescriptor;
			}
		}

		return null;
	}

	public void setParserPool(ParserPool parserPool) {
		_parserPool = parserPool;
	}

	protected String getMetadataXml(String entityId) throws Exception {
		long companyId = CompanyThreadLocal.getCompanyId();


			try {
				SamlIdpConnection samlIdpConnection =
					SamlIdpConnectionLocalServiceUtil.getSamlIdpConnection(
						companyId, entityId);

				if (!samlIdpConnection.isEnabled()) {
					return null;
				}

				return samlIdpConnection.getMetadataXml();
			}
			catch (PortalException nssice) {
				return null;
			}
	}

	private ParserPool _parserPool;

	private class DBEntitiesDescriptor implements EntitiesDescriptor {

		public DBEntitiesDescriptor() {
		}


		public void addNamespace(Namespace namespace) {
		}


		@SuppressWarnings("rawtypes")
		public void deregisterValidator(
			org.opensaml.xml.validation.Validator validator) {
		}


		public void detach() {
		}


		public Long getCacheDuration() {
			return null;
		}


		public Element getDOM() {
			return null;
		}


		public QName getElementQName() {
			return EntitiesDescriptor.DEFAULT_ELEMENT_NAME;
		}


		public List<EntitiesDescriptor> getEntitiesDescriptors() {
			List<EntitiesDescriptor> entitiesDescriptors =
				new ArrayList<EntitiesDescriptor>();

			for (XMLObject xmlObject : _xmlObjects) {
				if (xmlObject instanceof EntitiesDescriptor) {
					EntitiesDescriptor entitiesDescriptor =
						(EntitiesDescriptor)xmlObject;

					entitiesDescriptors.add(entitiesDescriptor);
				}
			}

			return entitiesDescriptors;
		}


		public List<EntityDescriptor> getEntityDescriptors() {
			List<EntityDescriptor> entityDescriptors =
				new ArrayList<EntityDescriptor>();

			for (XMLObject xmlObject : _xmlObjects) {
				if (xmlObject instanceof EntityDescriptor) {
					EntityDescriptor entityDescriptor =
						(EntityDescriptor)xmlObject;

					entityDescriptors.add(entityDescriptor);
				}
			}

			return entityDescriptors;
		}


		public Extensions getExtensions() {
			return null;
		}


		public String getID() {
			return null;
		}


		public IDIndex getIDIndex() {
			return null;
		}


		public String getName() {
			return null;
		}


		public NamespaceManager getNamespaceManager() {
			return null;
		}


		public Set<Namespace> getNamespaces() {
			return new LazySet<Namespace>();
		}


		public String getNoNamespaceSchemaLocation() {
			return null;
		}


		public List<XMLObject> getOrderedChildren() {
			return new ArrayList<XMLObject>();
		}


		public XMLObject getParent() {
			return null;
		}


		public String getSchemaLocation() {
			return null;
		}


		public QName getSchemaType() {
			return EntitiesDescriptor.TYPE_NAME;
		}


		public Signature getSignature() {
			return null;
		}


		public String getSignatureReferenceID() {
			return null;
		}


		@SuppressWarnings("rawtypes")
		public List<org.opensaml.xml.validation.Validator> getValidators() {
			return new ArrayList<org.opensaml.xml.validation.Validator>();
		}


		public DateTime getValidUntil() {
			return null;
		}


		public boolean hasChildren() {
			List<XMLObject> xmlObjects = getOrderedChildren();

			return !xmlObjects.isEmpty();
		}


		public boolean hasParent() {
			return false;
		}


		public Boolean isNil() {
			return Boolean.FALSE;
		}


		public XSBooleanValue isNilXSBoolean() {
			return new XSBooleanValue(Boolean.FALSE, false);
		}


		public boolean isSigned() {
			return false;
		}


		public boolean isValid() {
			return true;
		}


		@SuppressWarnings("rawtypes")
		public void registerValidator(
			org.opensaml.xml.validation.Validator validator) {
		}


		public void releaseChildrenDOM(boolean propagateRelease) {
		}


		public void releaseDOM() {
		}


		public void releaseParentDOM(boolean propagateRelease) {
		}


		public void removeNamespace(Namespace namespace) {
		}


		public XMLObject resolveID(String id) {
			return null;
		}


		public XMLObject resolveIDFromRoot(String id) {
			return null;
		}


		public void setCacheDuration(Long duration) {
		}


		public void setDOM(Element element) {
		}


		public void setExtensions(Extensions extensions) {
		}


		public void setID(String id) {
		}


		public void setName(String name) {
		}


		public void setNil(Boolean value) {
		}


		public void setNil(XSBooleanValue value) {
		}


		public void setNoNamespaceSchemaLocation(String location) {
		}


		public void setParent(XMLObject xmlObject) {
		}


		public void setSchemaLocation(String location) {
		}


		public void setSignature(Signature signature) {
		}


		public void setValidUntil(DateTime validUntil) {
		}


		public void validate(boolean validateDescendants) {
		}

		private List<XMLObject> _xmlObjects;
	}

}