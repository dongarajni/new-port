package com.jio.portlet.saml.provider;

import java.util.Timer;
import java.util.TimerTask;

import org.apache.commons.httpclient.HttpClient;

import org.opensaml.saml2.metadata.provider.HTTPMetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;

public class ReinitializingHttpMetadataProvider extends HTTPMetadataProvider {

	public ReinitializingHttpMetadataProvider(
			Timer timer, HttpClient httpClient, String url)
		throws MetadataProviderException {

		super(timer, httpClient, url);

		_timer = timer;
	}


	public synchronized void destroy() {
		super.destroy();

		_timer.cancel();
	}


	public synchronized void initialize() throws MetadataProviderException {
		try {
			super.initialize();

			if (!super.isInitialized()) {
				scheduleReinitialization();
			}
		}
		catch (MetadataProviderException mpe) {
			scheduleReinitialization();

			throw mpe;
		}
	}

	protected void scheduleReinitialization() {
		TimerTask timerTask = new ReinitializingTimerTask(_timer, this);

		_timer.schedule(timerTask, getMinRefreshDelay());
	}

	private Timer _timer;

}