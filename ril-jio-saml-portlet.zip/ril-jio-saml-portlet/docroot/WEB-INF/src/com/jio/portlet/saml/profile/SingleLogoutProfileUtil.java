package com.jio.portlet.saml.profile;

import com.jio.portlet.saml.model.SamlSession;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SingleLogoutProfileUtil {

	public static SamlSession getSamlSession(HttpServletRequest request)
		throws SystemException {

		return getSingleLogoutProfile().getSamlSession(request);
	}

	public static SingleLogoutProfile getSingleLogoutProfile() {
		return _singleLogoutProfile;
	}

	public static boolean isSingleLogoutSupported(HttpServletRequest request) {
		return getSingleLogoutProfile().isSingleLogoutSupported(request);
	}

	public static void logout(
		HttpServletRequest request, HttpServletResponse response) {

		getSingleLogoutProfile().logout(request, response);
	}

		public static void processSingleLogout(
			HttpServletRequest request, HttpServletResponse response)
		throws PortalException, SystemException {

		getSingleLogoutProfile().processSingleLogout(request, response);
	}

	public static void processSpLogout(
			HttpServletRequest request, HttpServletResponse response)
		throws PortalException, SystemException {

		getSingleLogoutProfile().processSpLogout(request, response);
	}

	public static void terminateSpSession(
		HttpServletRequest request, HttpServletResponse response) {

		getSingleLogoutProfile().terminateSpSession(request, response);
	}

	
	public void setSingleLogoutProfile(
		SingleLogoutProfile singleLogoutProfile) {

		_singleLogoutProfile = singleLogoutProfile;
	}

	private static SingleLogoutProfile _singleLogoutProfile;

}