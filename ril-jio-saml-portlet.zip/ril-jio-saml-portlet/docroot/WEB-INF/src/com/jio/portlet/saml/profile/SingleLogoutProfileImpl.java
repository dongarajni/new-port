
package com.jio.portlet.saml.profile;

import com.jio.hook.common.util.JioSamlUtil;
import com.jio.hook.common.util.OpenSamlUtil;
import com.jio.hook.common.util.PortletWebKeys;
import com.jio.portlet.saml.binding.SamlBinding;
import com.jio.portlet.saml.metadata.MetadataManagerUtil;
import com.jio.portlet.saml.model.SamlSession;
import com.jio.portlet.saml.service.SamlSessionLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.HttpMethods;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.util.PortalUtil;

import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.opensaml.common.SAMLObject;
import org.opensaml.common.SAMLVersion;
import org.opensaml.common.binding.SAMLMessageContext;
import org.opensaml.common.xml.SAMLConstants;
import org.opensaml.saml2.core.Issuer;
import org.opensaml.saml2.core.LogoutRequest;
import org.opensaml.saml2.core.LogoutResponse;
import org.opensaml.saml2.core.NameID;
import org.opensaml.saml2.core.SessionIndex;
import org.opensaml.saml2.core.Status;
import org.opensaml.saml2.core.StatusCode;
import org.opensaml.saml2.metadata.EntityDescriptor;
import org.opensaml.saml2.metadata.IDPSSODescriptor;
import org.opensaml.saml2.metadata.SSODescriptor;
import org.opensaml.saml2.metadata.SingleLogoutService;
import org.opensaml.saml2.metadata.provider.MetadataProvider;

public class SingleLogoutProfileImpl extends BaseProfile implements
		SingleLogoutProfile {

	public boolean isSingleLogoutSupported(HttpServletRequest request) {
		try {
			MetadataProvider metadataProvider = MetadataManagerUtil
					.getMetadataProvider();

			String entityId = MetadataManagerUtil.getDefaultIdpEntityId();

			EntityDescriptor entityDescriptor = metadataProvider
					.getEntityDescriptor(entityId);

			IDPSSODescriptor idpSsoDescriptor = entityDescriptor
					.getIDPSSODescriptor(SAMLConstants.SAML20P_NS);

			SingleLogoutService singleLogoutService = JioSamlUtil
					.resolveSingleLogoutService(idpSsoDescriptor,
							SAMLConstants.SAML2_REDIRECT_BINDING_URI);

			if (singleLogoutService != null) {
				String binding = singleLogoutService.getBinding();

				if (!binding.equals(SAMLConstants.SAML2_SOAP11_BINDING_URI)) {
					return true;
				}
			}
		} catch (Exception e) {
			if (_log.isWarnEnabled()) {
				_log.warn("Unable to verify single logout support", e);
			}
		}

		return false;
	}

	public void processSingleLogout(HttpServletRequest request,
			HttpServletResponse response) throws PortalException,
			SystemException {

		SamlBinding samlBinding = null;

		String method = request.getMethod();
		String requestPath = JioSamlUtil.getRequestPath(request);

		if (requestPath.endsWith("/slo")
				&& StringUtil.equalsIgnoreCase(method, HttpMethods.GET)) {

			samlBinding = getSamlBinding(SAMLConstants.SAML2_REDIRECT_BINDING_URI);
		} else if (requestPath.endsWith("/slo")
				&& StringUtil.equalsIgnoreCase(method, HttpMethods.POST)) {

			samlBinding = getSamlBinding(SAMLConstants.SAML2_POST_BINDING_URI);
		} else if (requestPath.endsWith("/slo_soap")
				&& StringUtil.equalsIgnoreCase(method, HttpMethods.POST)) {

			samlBinding = getSamlBinding(SAMLConstants.SAML2_SOAP11_BINDING_URI);
		} else {
			throw new PortalException();
		}

		try {
			SAMLMessageContext<?, ?, ?> samlMessageContext = decodeSamlMessage(
					request, response, samlBinding, true);

			Object inboundSamlMessage = samlMessageContext
					.getInboundSAMLMessage();

			if (inboundSamlMessage instanceof LogoutRequest) {
				processSingleLogoutRequest(
						request,
						response,
						(SAMLMessageContext<LogoutRequest, LogoutResponse, NameID>) samlMessageContext);
			} else if (inboundSamlMessage instanceof LogoutResponse) {
				processSingleLogoutResponse(
						request,
						response,
						(SAMLMessageContext<LogoutResponse, ?, ?>) samlMessageContext);
			} else {
				throw new PortalException("Unrecognized inbound SAML message "
						+ inboundSamlMessage.getClass());
			}
		} catch (Exception e) {
			if (e instanceof PortalException) {
				throw (PortalException) e;
			} else if (e instanceof SystemException) {
				throw (SystemException) e;
			} else {
				throw new PortalException(e);
			}
		}
	}

	public void processSpLogout(HttpServletRequest request,
			HttpServletResponse response) throws PortalException,
			SystemException {

		try {
			sendSpLogoutRequest(request, response);
		} catch (Exception e) {
			if (e instanceof PortalException) {
				throw (PortalException) e;
			} else if (e instanceof SystemException) {
				throw (SystemException) e;
			} else {
				throw new PortalException(e);
			}
		}
	}

	public void terminateSpSession(HttpServletRequest request,
			HttpServletResponse response) {

		try {
			SamlSession samlSpSession = getSamlSession(request);

			if (samlSpSession == null) {
				return;
			}

			SamlSessionLocalServiceUtil.deleteSamlSession(samlSpSession);

			Cookie cookie = new Cookie(PortletWebKeys.SAML_SP_SESSION_KEY,
					StringPool.BLANK);

			cookie.setMaxAge(0);

			if (Validator.isNull(PortalUtil.getPathContext())) {
				cookie.setPath(StringPool.SLASH);
			} else {
				cookie.setPath(PortalUtil.getPathContext());
			}

			cookie.setSecure(request.isSecure());

			response.addCookie(cookie);
		} catch (SystemException se) {
			_log.error(se, se);
		}
	}

	protected void addSessionIndex(LogoutRequest logoutRequest,
			String sessionIndexString) {

		if (Validator.isNull(sessionIndexString)) {
			return;
		}

		List<SessionIndex> sessionIndexes = logoutRequest.getSessionIndexes();

		SessionIndex sessionIndex = OpenSamlUtil
				.buildSessionIndex(sessionIndexString);

		sessionIndexes.add(sessionIndex);
	}

	protected void processSingleLogoutRequest(
			HttpServletRequest request,
			HttpServletResponse response,
			SAMLMessageContext<LogoutRequest, LogoutResponse, NameID> samlMessageContext)
			throws Exception {

		processSpLogoutRequest(request, response, samlMessageContext);
	}

	protected void processSingleLogoutResponse(HttpServletRequest request,
			HttpServletResponse response,
			SAMLMessageContext<LogoutResponse, ?, ?> samlMessageContext)
			throws Exception {

		processSpLogoutResponse(request, response, samlMessageContext);
	}

	protected void processSpLogoutRequest(
			HttpServletRequest request,
			HttpServletResponse response,
			SAMLMessageContext<LogoutRequest, LogoutResponse, NameID> samlMessageContext)
			throws Exception {

		LogoutRequest logoutRequest = samlMessageContext
				.getInboundSAMLMessage();

		NameID nameId = logoutRequest.getNameID();

		List<SessionIndex> sessionIndexes = logoutRequest.getSessionIndexes();

		String statusCodeURI = StatusCode.SUCCESS_URI;

		if (sessionIndexes.isEmpty()) {
			List<SamlSession> samlSpSessions = SamlSessionLocalServiceUtil
					.getSamlSessions(nameId.getValue());

			if (samlSpSessions.isEmpty()) {
				statusCodeURI = StatusCode.UNKNOWN_PRINCIPAL_URI;
			}

			for (SamlSession samlSpSession : samlSpSessions) {
				samlSpSession.setTerminated(true);

				SamlSessionLocalServiceUtil.updateSamlSession(samlSpSession);
			}
		}

		for (SessionIndex sessionIndex : sessionIndexes) {
			SamlSession samlSpSession = SamlSessionLocalServiceUtil
					.fetchSamlSessionBySessionIndex(sessionIndex
							.getSessionIndex());

			if (samlSpSession == null) {
				statusCodeURI = StatusCode.UNKNOWN_PRINCIPAL_URI;

				continue;
			}

			if (Validator.equals(samlSpSession.getNameIdValue(),
					nameId.getValue())
					&& Validator.equals(samlSpSession.getNameIdFormat(),
							nameId.getFormat())) {

				samlSpSession.setTerminated(true);

				SamlSessionLocalServiceUtil.updateSamlSession(samlSpSession);
			} else if (!statusCodeURI.equals(StatusCode.PARTIAL_LOGOUT_URI)) {
				statusCodeURI = StatusCode.UNKNOWN_PRINCIPAL_URI;

				continue;
			}

			if (statusCodeURI.equals(StatusCode.UNKNOWN_PRINCIPAL_URI)) {
				statusCodeURI = StatusCode.PARTIAL_LOGOUT_URI;
			}
		}

		samlMessageContext
				.setOutboundSAMLMessageSigningCredential(MetadataManagerUtil
						.getSigningCredential());

		LogoutResponse logoutResponse = OpenSamlUtil.buildLogoutResponse();

		samlMessageContext.setOutboundSAMLMessage(logoutResponse);

		logoutResponse.setID(generateIdentifier(20));
		logoutResponse.setInResponseTo(logoutRequest.getID());
		logoutResponse.setIssueInstant(new DateTime(DateTimeZone.UTC));

		Issuer issuer = OpenSamlUtil.buildIssuer(samlMessageContext
				.getLocalEntityId());

		logoutResponse.setIssuer(issuer);

		StatusCode statusCode = OpenSamlUtil.buildStatusCode(statusCodeURI);

		Status status = OpenSamlUtil.buildStatus(statusCode);

		logoutResponse.setStatus(status);

		logoutResponse.setVersion(SAMLVersion.VERSION_20);

		SSODescriptor ssoDescriptor = (SSODescriptor) samlMessageContext
				.getPeerEntityRoleMetadata();

		SingleLogoutService singleLogoutService = JioSamlUtil
				.resolveSingleLogoutService(ssoDescriptor,
						samlMessageContext.getCommunicationProfileId());

		samlMessageContext.setPeerEntityEndpoint(singleLogoutService);

		sendSamlMessage(samlMessageContext);
	}

	protected void processSpLogoutResponse(HttpServletRequest request,
			HttpServletResponse response,
			SAMLMessageContext<LogoutResponse, ?, ?> samlMessageContext)
			throws Exception {

		redirectToLogout(request, response);
	}

	protected void redirectToLogout(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		terminateSpSession(request, response);

		String portalURL = PortalUtil.getPortalURL(request);

		String pathMain = PortalUtil.getPathMain();

		String redirect = portalURL.concat(pathMain).concat("/portal/logout");

		response.sendRedirect(redirect);
	}

	protected void sendSpLogoutRequest(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		SamlSession samlSpSession = getSamlSession(request);

		if ((samlSpSession == null) || samlSpSession.isTerminated()) {
			redirectToLogout(request, response);

			return;
		}

		LogoutRequest logoutRequest = OpenSamlUtil.buildLogoutRequest();

		String entityId = MetadataManagerUtil.getDefaultIdpEntityId();

		SAMLMessageContext<SAMLObject, LogoutRequest, SAMLObject> samlMessageContext = (SAMLMessageContext<SAMLObject, LogoutRequest, SAMLObject>) getSamlMessageContext(
				request, response, entityId);

		IDPSSODescriptor idpSsoDescriptor = (IDPSSODescriptor) samlMessageContext
				.getPeerEntityRoleMetadata();

		SingleLogoutService singleLogoutService = JioSamlUtil
				.resolveSingleLogoutService(idpSsoDescriptor,
						SAMLConstants.SAML2_POST_BINDING_URI);

		logoutRequest.setDestination(singleLogoutService.getLocation());

		logoutRequest.setID(generateIdentifier(20));

		DateTime issueInstantDateTime = new DateTime(DateTimeZone.UTC);

		logoutRequest.setIssueInstant(issueInstantDateTime);

		Issuer issuer = OpenSamlUtil.buildIssuer(samlMessageContext
				.getLocalEntityId());

		logoutRequest.setIssuer(issuer);

		String nameIdFormat = samlSpSession.getNameIdFormat();
		String nameIdNameQualifier = samlSpSession.getNameIdNameQualifier();
		String nameIdSPNameQualifier = samlSpSession.getNameIdSPNameQualifier();
		String nameIdValue = samlSpSession.getNameIdValue();

		NameID nameId = OpenSamlUtil.buildNameId(nameIdFormat,
				nameIdNameQualifier, nameIdSPNameQualifier, nameIdValue);

		logoutRequest.setNameID(nameId);

		logoutRequest.setVersion(SAMLVersion.VERSION_20);

		addSessionIndex(logoutRequest, samlSpSession.getSessionIndex());

		samlMessageContext.setOutboundSAMLMessage(logoutRequest);

		samlMessageContext
				.setOutboundSAMLMessageSigningCredential(MetadataManagerUtil
						.getSigningCredential());
		samlMessageContext.setPeerEntityEndpoint(singleLogoutService);

		sendSamlMessage(samlMessageContext);
	}

	private static Log _log = LogFactoryUtil
			.getLog(SingleLogoutProfileImpl.class);

}