package com.jio.portlet.saml.metadata;

import javax.servlet.http.HttpServletRequest;

import org.opensaml.saml2.metadata.EntityDescriptor;
import org.opensaml.saml2.metadata.provider.MetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.opensaml.ws.security.SecurityPolicyResolver;
import org.opensaml.xml.security.SecurityException;
import org.opensaml.xml.security.credential.Credential;
import org.opensaml.xml.signature.SignatureTrustEngine;

public interface MetadataManager {

   public long getClockSkew();

	public String getDefaultIdpEntityId();

	public EntityDescriptor getEntityDescriptor(HttpServletRequest request)
		throws MetadataProviderException;

	public String getLocalEntityId();

	public MetadataProvider getMetadataProvider()
		throws MetadataProviderException;

	public String getNameIdFormat(String entityId);

	public SecurityPolicyResolver getSecurityPolicyResolver(
			String communicationProfileId, boolean requireSignature)
		throws MetadataProviderException;

	public String getSessionKeepAliveURL(String entityId);

	public long getSessionMaximumAge();

	public long getSessionTimeout();

	public SignatureTrustEngine getSignatureTrustEngine()
		throws MetadataProviderException;

	public Credential getSigningCredential() throws SecurityException;

	public String getUserAttributeMappings(String entityId);

	public boolean isSignAuthnRequests();

	public boolean isSignMetadata();

	public boolean isSSLRequired();

	public boolean isWantAssertionsSigned();

	public boolean isWantAuthnRequestSigned();

}