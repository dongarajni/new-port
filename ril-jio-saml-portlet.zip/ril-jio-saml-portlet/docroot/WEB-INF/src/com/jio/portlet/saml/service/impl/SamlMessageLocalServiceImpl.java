/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.service.impl;

import com.jio.portlet.saml.model.SamlMessage;
import com.jio.portlet.saml.service.base.SamlMessageLocalServiceBaseImpl;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.service.ServiceContext;

import java.util.Date;

/**
 * The implementation of the saml message local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jio.portlet.saml.service.SamlMessageLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Liferay Developer
 * @see com.jio.portlet.saml.service.base.SamlMessageLocalServiceBaseImpl
 * @see com.jio.portlet.saml.service.SamlMessageLocalServiceUtil
 */
public class SamlMessageLocalServiceImpl extends SamlMessageLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.jio.portlet.saml.service.SamlMessageLocalServiceUtil} to access the saml message local service.
	 */
	
	public SamlMessage addSamlMessage(
			String samlIdpEntityId, String samlIdpResponseKey,
			Date expirationDate, ServiceContext serviceContext)
		throws SystemException {

		long samlSpMessageId = counterLocalService.increment(
			SamlMessage.class.getName());

		SamlMessage samlSpMessage = samlMessagePersistence.create(
			samlSpMessageId);

		samlSpMessage.setCompanyId(serviceContext.getCompanyId());
		samlSpMessage.setCreateDate(new Date());
		samlSpMessage.setEntityId(samlIdpEntityId);
		samlSpMessage.setResponseKey(samlIdpResponseKey);
		samlSpMessage.setExpirationDate(expirationDate);

		samlMessagePersistence.update(samlSpMessage);

		return samlSpMessage;
	}


	public SamlMessage fetchSamlMessage(
			String samlIdpEntityId, String samlIdpResponseKey)
		throws SystemException {

		return samlMessagePersistence.fetchByEntityId_ResponseKey(
			samlIdpEntityId, samlIdpResponseKey);
	}


	public SamlMessage getSamlMessage(
			String samlIdpEntityId, String samlIdpResponseKey)
		throws PortalException, SystemException {

		return samlMessagePersistence.findByEntityId_ResponseKey(
			samlIdpEntityId, samlIdpResponseKey);
	}
}