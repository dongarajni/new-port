/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.service.persistence;

import com.jio.portlet.saml.NoSuchSamlAuthRequestException;
import com.jio.portlet.saml.model.SamlAuthRequest;
import com.jio.portlet.saml.model.impl.SamlAuthRequestImpl;
import com.jio.portlet.saml.model.impl.SamlAuthRequestModelImpl;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the saml auth request service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Ashish Jadhav
 * @see SamlAuthRequestPersistence
 * @see SamlAuthRequestUtil
 * @generated
 */
public class SamlAuthRequestPersistenceImpl extends BasePersistenceImpl<SamlAuthRequest>
	implements SamlAuthRequestPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link SamlAuthRequestUtil} to access the saml auth request persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = SamlAuthRequestImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(SamlAuthRequestModelImpl.ENTITY_CACHE_ENABLED,
			SamlAuthRequestModelImpl.FINDER_CACHE_ENABLED,
			SamlAuthRequestImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(SamlAuthRequestModelImpl.ENTITY_CACHE_ENABLED,
			SamlAuthRequestModelImpl.FINDER_CACHE_ENABLED,
			SamlAuthRequestImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(SamlAuthRequestModelImpl.ENTITY_CACHE_ENABLED,
			SamlAuthRequestModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_FETCH_BY_ENTITYID_AUTHREQKEY = new FinderPath(SamlAuthRequestModelImpl.ENTITY_CACHE_ENABLED,
			SamlAuthRequestModelImpl.FINDER_CACHE_ENABLED,
			SamlAuthRequestImpl.class, FINDER_CLASS_NAME_ENTITY,
			"fetchByEntityId_AuthReqKey",
			new String[] { String.class.getName(), String.class.getName() },
			SamlAuthRequestModelImpl.ENTITYID_COLUMN_BITMASK |
			SamlAuthRequestModelImpl.AUTHREQUESTKEY_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_ENTITYID_AUTHREQKEY = new FinderPath(SamlAuthRequestModelImpl.ENTITY_CACHE_ENABLED,
			SamlAuthRequestModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByEntityId_AuthReqKey",
			new String[] { String.class.getName(), String.class.getName() });

	/**
	 * Returns the saml auth request where entityId = &#63; and authRequestKey = &#63; or throws a {@link com.jio.portlet.saml.NoSuchSamlAuthRequestException} if it could not be found.
	 *
	 * @param entityId the entity ID
	 * @param authRequestKey the auth request key
	 * @return the matching saml auth request
	 * @throws com.jio.portlet.saml.NoSuchSamlAuthRequestException if a matching saml auth request could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlAuthRequest findByEntityId_AuthReqKey(String entityId,
		String authRequestKey)
		throws NoSuchSamlAuthRequestException, SystemException {
		SamlAuthRequest samlAuthRequest = fetchByEntityId_AuthReqKey(entityId,
				authRequestKey);

		if (samlAuthRequest == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("entityId=");
			msg.append(entityId);

			msg.append(", authRequestKey=");
			msg.append(authRequestKey);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchSamlAuthRequestException(msg.toString());
		}

		return samlAuthRequest;
	}

	/**
	 * Returns the saml auth request where entityId = &#63; and authRequestKey = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param entityId the entity ID
	 * @param authRequestKey the auth request key
	 * @return the matching saml auth request, or <code>null</code> if a matching saml auth request could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlAuthRequest fetchByEntityId_AuthReqKey(String entityId,
		String authRequestKey) throws SystemException {
		return fetchByEntityId_AuthReqKey(entityId, authRequestKey, true);
	}

	/**
	 * Returns the saml auth request where entityId = &#63; and authRequestKey = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param entityId the entity ID
	 * @param authRequestKey the auth request key
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching saml auth request, or <code>null</code> if a matching saml auth request could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlAuthRequest fetchByEntityId_AuthReqKey(String entityId,
		String authRequestKey, boolean retrieveFromCache)
		throws SystemException {
		Object[] finderArgs = new Object[] { entityId, authRequestKey };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_ENTITYID_AUTHREQKEY,
					finderArgs, this);
		}

		if (result instanceof SamlAuthRequest) {
			SamlAuthRequest samlAuthRequest = (SamlAuthRequest)result;

			if (!Validator.equals(entityId, samlAuthRequest.getEntityId()) ||
					!Validator.equals(authRequestKey,
						samlAuthRequest.getAuthRequestKey())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_SAMLAUTHREQUEST_WHERE);

			boolean bindEntityId = false;

			if (entityId == null) {
				query.append(_FINDER_COLUMN_ENTITYID_AUTHREQKEY_ENTITYID_1);
			}
			else if (entityId.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_ENTITYID_AUTHREQKEY_ENTITYID_3);
			}
			else {
				bindEntityId = true;

				query.append(_FINDER_COLUMN_ENTITYID_AUTHREQKEY_ENTITYID_2);
			}

			boolean bindAuthRequestKey = false;

			if (authRequestKey == null) {
				query.append(_FINDER_COLUMN_ENTITYID_AUTHREQKEY_AUTHREQUESTKEY_1);
			}
			else if (authRequestKey.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_ENTITYID_AUTHREQKEY_AUTHREQUESTKEY_3);
			}
			else {
				bindAuthRequestKey = true;

				query.append(_FINDER_COLUMN_ENTITYID_AUTHREQKEY_AUTHREQUESTKEY_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindEntityId) {
					qPos.add(entityId);
				}

				if (bindAuthRequestKey) {
					qPos.add(authRequestKey);
				}

				List<SamlAuthRequest> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_ENTITYID_AUTHREQKEY,
						finderArgs, list);
				}
				else {
					if ((list.size() > 1) && _log.isWarnEnabled()) {
						_log.warn(
							"SamlAuthRequestPersistenceImpl.fetchByEntityId_AuthReqKey(String, String, boolean) with parameters (" +
							StringUtil.merge(finderArgs) +
							") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
					}

					SamlAuthRequest samlAuthRequest = list.get(0);

					result = samlAuthRequest;

					cacheResult(samlAuthRequest);

					if ((samlAuthRequest.getEntityId() == null) ||
							!samlAuthRequest.getEntityId().equals(entityId) ||
							(samlAuthRequest.getAuthRequestKey() == null) ||
							!samlAuthRequest.getAuthRequestKey()
												.equals(authRequestKey)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_ENTITYID_AUTHREQKEY,
							finderArgs, samlAuthRequest);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_ENTITYID_AUTHREQKEY,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (SamlAuthRequest)result;
		}
	}

	/**
	 * Removes the saml auth request where entityId = &#63; and authRequestKey = &#63; from the database.
	 *
	 * @param entityId the entity ID
	 * @param authRequestKey the auth request key
	 * @return the saml auth request that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlAuthRequest removeByEntityId_AuthReqKey(String entityId,
		String authRequestKey)
		throws NoSuchSamlAuthRequestException, SystemException {
		SamlAuthRequest samlAuthRequest = findByEntityId_AuthReqKey(entityId,
				authRequestKey);

		return remove(samlAuthRequest);
	}

	/**
	 * Returns the number of saml auth requests where entityId = &#63; and authRequestKey = &#63;.
	 *
	 * @param entityId the entity ID
	 * @param authRequestKey the auth request key
	 * @return the number of matching saml auth requests
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByEntityId_AuthReqKey(String entityId, String authRequestKey)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_ENTITYID_AUTHREQKEY;

		Object[] finderArgs = new Object[] { entityId, authRequestKey };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_SAMLAUTHREQUEST_WHERE);

			boolean bindEntityId = false;

			if (entityId == null) {
				query.append(_FINDER_COLUMN_ENTITYID_AUTHREQKEY_ENTITYID_1);
			}
			else if (entityId.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_ENTITYID_AUTHREQKEY_ENTITYID_3);
			}
			else {
				bindEntityId = true;

				query.append(_FINDER_COLUMN_ENTITYID_AUTHREQKEY_ENTITYID_2);
			}

			boolean bindAuthRequestKey = false;

			if (authRequestKey == null) {
				query.append(_FINDER_COLUMN_ENTITYID_AUTHREQKEY_AUTHREQUESTKEY_1);
			}
			else if (authRequestKey.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_ENTITYID_AUTHREQKEY_AUTHREQUESTKEY_3);
			}
			else {
				bindAuthRequestKey = true;

				query.append(_FINDER_COLUMN_ENTITYID_AUTHREQKEY_AUTHREQUESTKEY_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindEntityId) {
					qPos.add(entityId);
				}

				if (bindAuthRequestKey) {
					qPos.add(authRequestKey);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_ENTITYID_AUTHREQKEY_ENTITYID_1 = "samlAuthRequest.entityId IS NULL AND ";
	private static final String _FINDER_COLUMN_ENTITYID_AUTHREQKEY_ENTITYID_2 = "samlAuthRequest.entityId = ? AND ";
	private static final String _FINDER_COLUMN_ENTITYID_AUTHREQKEY_ENTITYID_3 = "(samlAuthRequest.entityId IS NULL OR samlAuthRequest.entityId = '') AND ";
	private static final String _FINDER_COLUMN_ENTITYID_AUTHREQKEY_AUTHREQUESTKEY_1 =
		"samlAuthRequest.authRequestKey IS NULL";
	private static final String _FINDER_COLUMN_ENTITYID_AUTHREQKEY_AUTHREQUESTKEY_2 =
		"samlAuthRequest.authRequestKey = ?";
	private static final String _FINDER_COLUMN_ENTITYID_AUTHREQKEY_AUTHREQUESTKEY_3 =
		"(samlAuthRequest.authRequestKey IS NULL OR samlAuthRequest.authRequestKey = '')";

	public SamlAuthRequestPersistenceImpl() {
		setModelClass(SamlAuthRequest.class);
	}

	/**
	 * Caches the saml auth request in the entity cache if it is enabled.
	 *
	 * @param samlAuthRequest the saml auth request
	 */
	@Override
	public void cacheResult(SamlAuthRequest samlAuthRequest) {
		EntityCacheUtil.putResult(SamlAuthRequestModelImpl.ENTITY_CACHE_ENABLED,
			SamlAuthRequestImpl.class, samlAuthRequest.getPrimaryKey(),
			samlAuthRequest);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_ENTITYID_AUTHREQKEY,
			new Object[] {
				samlAuthRequest.getEntityId(),
				samlAuthRequest.getAuthRequestKey()
			}, samlAuthRequest);

		samlAuthRequest.resetOriginalValues();
	}

	/**
	 * Caches the saml auth requests in the entity cache if it is enabled.
	 *
	 * @param samlAuthRequests the saml auth requests
	 */
	@Override
	public void cacheResult(List<SamlAuthRequest> samlAuthRequests) {
		for (SamlAuthRequest samlAuthRequest : samlAuthRequests) {
			if (EntityCacheUtil.getResult(
						SamlAuthRequestModelImpl.ENTITY_CACHE_ENABLED,
						SamlAuthRequestImpl.class,
						samlAuthRequest.getPrimaryKey()) == null) {
				cacheResult(samlAuthRequest);
			}
			else {
				samlAuthRequest.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all saml auth requests.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(SamlAuthRequestImpl.class.getName());
		}

		EntityCacheUtil.clearCache(SamlAuthRequestImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the saml auth request.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(SamlAuthRequest samlAuthRequest) {
		EntityCacheUtil.removeResult(SamlAuthRequestModelImpl.ENTITY_CACHE_ENABLED,
			SamlAuthRequestImpl.class, samlAuthRequest.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache(samlAuthRequest);
	}

	@Override
	public void clearCache(List<SamlAuthRequest> samlAuthRequests) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (SamlAuthRequest samlAuthRequest : samlAuthRequests) {
			EntityCacheUtil.removeResult(SamlAuthRequestModelImpl.ENTITY_CACHE_ENABLED,
				SamlAuthRequestImpl.class, samlAuthRequest.getPrimaryKey());

			clearUniqueFindersCache(samlAuthRequest);
		}
	}

	protected void cacheUniqueFindersCache(SamlAuthRequest samlAuthRequest) {
		if (samlAuthRequest.isNew()) {
			Object[] args = new Object[] {
					samlAuthRequest.getEntityId(),
					samlAuthRequest.getAuthRequestKey()
				};

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_ENTITYID_AUTHREQKEY,
				args, Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_ENTITYID_AUTHREQKEY,
				args, samlAuthRequest);
		}
		else {
			SamlAuthRequestModelImpl samlAuthRequestModelImpl = (SamlAuthRequestModelImpl)samlAuthRequest;

			if ((samlAuthRequestModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_ENTITYID_AUTHREQKEY.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						samlAuthRequest.getEntityId(),
						samlAuthRequest.getAuthRequestKey()
					};

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_ENTITYID_AUTHREQKEY,
					args, Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_ENTITYID_AUTHREQKEY,
					args, samlAuthRequest);
			}
		}
	}

	protected void clearUniqueFindersCache(SamlAuthRequest samlAuthRequest) {
		SamlAuthRequestModelImpl samlAuthRequestModelImpl = (SamlAuthRequestModelImpl)samlAuthRequest;

		Object[] args = new Object[] {
				samlAuthRequest.getEntityId(),
				samlAuthRequest.getAuthRequestKey()
			};

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ENTITYID_AUTHREQKEY,
			args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_ENTITYID_AUTHREQKEY,
			args);

		if ((samlAuthRequestModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_ENTITYID_AUTHREQKEY.getColumnBitmask()) != 0) {
			args = new Object[] {
					samlAuthRequestModelImpl.getOriginalEntityId(),
					samlAuthRequestModelImpl.getOriginalAuthRequestKey()
				};

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ENTITYID_AUTHREQKEY,
				args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_ENTITYID_AUTHREQKEY,
				args);
		}
	}

	/**
	 * Creates a new saml auth request with the primary key. Does not add the saml auth request to the database.
	 *
	 * @param samlAuthnRequestId the primary key for the new saml auth request
	 * @return the new saml auth request
	 */
	@Override
	public SamlAuthRequest create(long samlAuthnRequestId) {
		SamlAuthRequest samlAuthRequest = new SamlAuthRequestImpl();

		samlAuthRequest.setNew(true);
		samlAuthRequest.setPrimaryKey(samlAuthnRequestId);

		return samlAuthRequest;
	}

	/**
	 * Removes the saml auth request with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param samlAuthnRequestId the primary key of the saml auth request
	 * @return the saml auth request that was removed
	 * @throws com.jio.portlet.saml.NoSuchSamlAuthRequestException if a saml auth request with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlAuthRequest remove(long samlAuthnRequestId)
		throws NoSuchSamlAuthRequestException, SystemException {
		return remove((Serializable)samlAuthnRequestId);
	}

	/**
	 * Removes the saml auth request with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the saml auth request
	 * @return the saml auth request that was removed
	 * @throws com.jio.portlet.saml.NoSuchSamlAuthRequestException if a saml auth request with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlAuthRequest remove(Serializable primaryKey)
		throws NoSuchSamlAuthRequestException, SystemException {
		Session session = null;

		try {
			session = openSession();

			SamlAuthRequest samlAuthRequest = (SamlAuthRequest)session.get(SamlAuthRequestImpl.class,
					primaryKey);

			if (samlAuthRequest == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchSamlAuthRequestException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(samlAuthRequest);
		}
		catch (NoSuchSamlAuthRequestException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected SamlAuthRequest removeImpl(SamlAuthRequest samlAuthRequest)
		throws SystemException {
		samlAuthRequest = toUnwrappedModel(samlAuthRequest);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(samlAuthRequest)) {
				samlAuthRequest = (SamlAuthRequest)session.get(SamlAuthRequestImpl.class,
						samlAuthRequest.getPrimaryKeyObj());
			}

			if (samlAuthRequest != null) {
				session.delete(samlAuthRequest);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (samlAuthRequest != null) {
			clearCache(samlAuthRequest);
		}

		return samlAuthRequest;
	}

	@Override
	public SamlAuthRequest updateImpl(
		com.jio.portlet.saml.model.SamlAuthRequest samlAuthRequest)
		throws SystemException {
		samlAuthRequest = toUnwrappedModel(samlAuthRequest);

		boolean isNew = samlAuthRequest.isNew();

		Session session = null;

		try {
			session = openSession();

			if (samlAuthRequest.isNew()) {
				session.save(samlAuthRequest);

				samlAuthRequest.setNew(false);
			}
			else {
				session.merge(samlAuthRequest);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !SamlAuthRequestModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		EntityCacheUtil.putResult(SamlAuthRequestModelImpl.ENTITY_CACHE_ENABLED,
			SamlAuthRequestImpl.class, samlAuthRequest.getPrimaryKey(),
			samlAuthRequest);

		clearUniqueFindersCache(samlAuthRequest);
		cacheUniqueFindersCache(samlAuthRequest);

		return samlAuthRequest;
	}

	protected SamlAuthRequest toUnwrappedModel(SamlAuthRequest samlAuthRequest) {
		if (samlAuthRequest instanceof SamlAuthRequestImpl) {
			return samlAuthRequest;
		}

		SamlAuthRequestImpl samlAuthRequestImpl = new SamlAuthRequestImpl();

		samlAuthRequestImpl.setNew(samlAuthRequest.isNew());
		samlAuthRequestImpl.setPrimaryKey(samlAuthRequest.getPrimaryKey());

		samlAuthRequestImpl.setSamlAuthnRequestId(samlAuthRequest.getSamlAuthnRequestId());
		samlAuthRequestImpl.setCompanyId(samlAuthRequest.getCompanyId());
		samlAuthRequestImpl.setCreateDate(samlAuthRequest.getCreateDate());
		samlAuthRequestImpl.setEntityId(samlAuthRequest.getEntityId());
		samlAuthRequestImpl.setAuthRequestKey(samlAuthRequest.getAuthRequestKey());

		return samlAuthRequestImpl;
	}

	/**
	 * Returns the saml auth request with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the saml auth request
	 * @return the saml auth request
	 * @throws com.jio.portlet.saml.NoSuchSamlAuthRequestException if a saml auth request with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlAuthRequest findByPrimaryKey(Serializable primaryKey)
		throws NoSuchSamlAuthRequestException, SystemException {
		SamlAuthRequest samlAuthRequest = fetchByPrimaryKey(primaryKey);

		if (samlAuthRequest == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchSamlAuthRequestException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return samlAuthRequest;
	}

	/**
	 * Returns the saml auth request with the primary key or throws a {@link com.jio.portlet.saml.NoSuchSamlAuthRequestException} if it could not be found.
	 *
	 * @param samlAuthnRequestId the primary key of the saml auth request
	 * @return the saml auth request
	 * @throws com.jio.portlet.saml.NoSuchSamlAuthRequestException if a saml auth request with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlAuthRequest findByPrimaryKey(long samlAuthnRequestId)
		throws NoSuchSamlAuthRequestException, SystemException {
		return findByPrimaryKey((Serializable)samlAuthnRequestId);
	}

	/**
	 * Returns the saml auth request with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the saml auth request
	 * @return the saml auth request, or <code>null</code> if a saml auth request with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlAuthRequest fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		SamlAuthRequest samlAuthRequest = (SamlAuthRequest)EntityCacheUtil.getResult(SamlAuthRequestModelImpl.ENTITY_CACHE_ENABLED,
				SamlAuthRequestImpl.class, primaryKey);

		if (samlAuthRequest == _nullSamlAuthRequest) {
			return null;
		}

		if (samlAuthRequest == null) {
			Session session = null;

			try {
				session = openSession();

				samlAuthRequest = (SamlAuthRequest)session.get(SamlAuthRequestImpl.class,
						primaryKey);

				if (samlAuthRequest != null) {
					cacheResult(samlAuthRequest);
				}
				else {
					EntityCacheUtil.putResult(SamlAuthRequestModelImpl.ENTITY_CACHE_ENABLED,
						SamlAuthRequestImpl.class, primaryKey,
						_nullSamlAuthRequest);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(SamlAuthRequestModelImpl.ENTITY_CACHE_ENABLED,
					SamlAuthRequestImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return samlAuthRequest;
	}

	/**
	 * Returns the saml auth request with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param samlAuthnRequestId the primary key of the saml auth request
	 * @return the saml auth request, or <code>null</code> if a saml auth request with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public SamlAuthRequest fetchByPrimaryKey(long samlAuthnRequestId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)samlAuthnRequestId);
	}

	/**
	 * Returns all the saml auth requests.
	 *
	 * @return the saml auth requests
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SamlAuthRequest> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the saml auth requests.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlAuthRequestModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of saml auth requests
	 * @param end the upper bound of the range of saml auth requests (not inclusive)
	 * @return the range of saml auth requests
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SamlAuthRequest> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the saml auth requests.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlAuthRequestModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of saml auth requests
	 * @param end the upper bound of the range of saml auth requests (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of saml auth requests
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<SamlAuthRequest> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<SamlAuthRequest> list = (List<SamlAuthRequest>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_SAMLAUTHREQUEST);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_SAMLAUTHREQUEST;

				if (pagination) {
					sql = sql.concat(SamlAuthRequestModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<SamlAuthRequest>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<SamlAuthRequest>(list);
				}
				else {
					list = (List<SamlAuthRequest>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the saml auth requests from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (SamlAuthRequest samlAuthRequest : findAll()) {
			remove(samlAuthRequest);
		}
	}

	/**
	 * Returns the number of saml auth requests.
	 *
	 * @return the number of saml auth requests
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_SAMLAUTHREQUEST);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the saml auth request persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.jio.portlet.saml.model.SamlAuthRequest")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<SamlAuthRequest>> listenersList = new ArrayList<ModelListener<SamlAuthRequest>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<SamlAuthRequest>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(SamlAuthRequestImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_SAMLAUTHREQUEST = "SELECT samlAuthRequest FROM SamlAuthRequest samlAuthRequest";
	private static final String _SQL_SELECT_SAMLAUTHREQUEST_WHERE = "SELECT samlAuthRequest FROM SamlAuthRequest samlAuthRequest WHERE ";
	private static final String _SQL_COUNT_SAMLAUTHREQUEST = "SELECT COUNT(samlAuthRequest) FROM SamlAuthRequest samlAuthRequest";
	private static final String _SQL_COUNT_SAMLAUTHREQUEST_WHERE = "SELECT COUNT(samlAuthRequest) FROM SamlAuthRequest samlAuthRequest WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "samlAuthRequest.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No SamlAuthRequest exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No SamlAuthRequest exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(SamlAuthRequestPersistenceImpl.class);
	private static SamlAuthRequest _nullSamlAuthRequest = new SamlAuthRequestImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<SamlAuthRequest> toCacheModel() {
				return _nullSamlAuthRequestCacheModel;
			}
		};

	private static CacheModel<SamlAuthRequest> _nullSamlAuthRequestCacheModel = new CacheModel<SamlAuthRequest>() {
			@Override
			public SamlAuthRequest toEntityModel() {
				return _nullSamlAuthRequest;
			}
		};
}