package com.jio.portlet.saml.resolver;

import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;

import org.opensaml.common.SAMLObject;
import org.opensaml.common.binding.SAMLMessageContext;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.NameID;
import org.opensaml.saml2.core.Response;

public class UserResolverUtil {

	public static UserResolver getUserResolver() {
		return _userResolver;
	}

	public static User resolveUser(
			Assertion assertion,
			SAMLMessageContext<Response, SAMLObject, NameID> samlMessageContext,
			ServiceContext serviceContext)
		throws Exception {

		return getUserResolver().resolveUser(
			assertion, samlMessageContext, serviceContext);
	}

	public void setUserResolver(UserResolver userResolver) {
		_userResolver = userResolver;
	}

	private static UserResolver _userResolver;

}