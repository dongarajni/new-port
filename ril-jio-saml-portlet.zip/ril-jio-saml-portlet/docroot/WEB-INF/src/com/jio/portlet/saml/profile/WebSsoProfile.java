package com.jio.portlet.saml.profile;

import com.jio.portlet.saml.model.SamlSession;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface WebSsoProfile {

	public SamlSession getSamlSession(HttpServletRequest request)
		throws SystemException;

	public void processResponse(
			HttpServletRequest request, HttpServletResponse response)
		throws PortalException, SystemException;

	public void sendAuthnRequest(
			HttpServletRequest request, HttpServletResponse response,
			String relayState)
		throws PortalException, SystemException;

	public void updateSamlSession(
			HttpServletRequest request, HttpServletResponse httpServletResponse)
		throws SystemException;

}