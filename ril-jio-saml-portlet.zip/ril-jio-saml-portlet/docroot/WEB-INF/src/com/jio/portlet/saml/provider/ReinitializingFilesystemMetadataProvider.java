package com.jio.portlet.saml.provider;

import java.io.File;

import java.util.Timer;
import java.util.TimerTask;

import org.opensaml.saml2.metadata.provider.FilesystemMetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;

public class ReinitializingFilesystemMetadataProvider
	extends FilesystemMetadataProvider {

	public ReinitializingFilesystemMetadataProvider(Timer timer, File file)
		throws MetadataProviderException {

		super(timer, file);

		_timer = timer;
	}


	public synchronized void destroy() {
		super.destroy();

		_timer.cancel();
	}


	public synchronized void initialize() throws MetadataProviderException {
		try {
			super.initialize();

			if (!super.isInitialized()) {
				scheduleReinitialization();
			}
		}
		catch (MetadataProviderException mpe) {
			scheduleReinitialization();

			throw mpe;
		}
	}

	protected void scheduleReinitialization() {
		TimerTask timerTask = new ReinitializingTimerTask(_timer, this);

		_timer.schedule(timerTask, getMinRefreshDelay());
	}

	private Timer _timer;

}