/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.service.impl;

import com.jio.hook.common.util.MetadataUtil;
import com.jio.portlet.saml.model.SamlIdpConnection;
import com.jio.portlet.saml.service.base.SamlIdpConnectionLocalServiceBaseImpl;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.service.ServiceContext;

import java.io.InputStream;
import java.util.Date;
import java.util.List;

/**
 * The implementation of the saml idp connection local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jio.portlet.saml.service.SamlIdpConnectionLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Liferay Developer
 * @see com.jio.portlet.saml.service.base.SamlIdpConnectionLocalServiceBaseImpl
 * @see com.jio.portlet.saml.service.SamlIdpConnectionLocalServiceUtil
 */
public class SamlIdpConnectionLocalServiceImpl
	extends SamlIdpConnectionLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.jio.portlet.saml.service.SamlIdpConnectionLocalServiceUtil} to access the saml idp connection local service.
	 */
	
	public SamlIdpConnection addSamlIdpConnection(
			String samlIdpEntityId, boolean assertionSignatureRequired,
			long clockSkew, boolean enabled, boolean forceAuthn,
			boolean ldapImportEnabled, String metadataUrl,
			InputStream metadataXmlInputStream, String name,
			String nameIdFormat, boolean signAuthnRequest,
			String userAttributeMappings, ServiceContext serviceContext)
		throws PortalException, SystemException {

		Date now = new Date();

		if (Validator.isNull(samlIdpEntityId)) {
			throw new PortalException();
		}

		if (samlIdpConnectionPersistence.fetchByCompanyId_IdpEntityId (
				serviceContext.getCompanyId(), samlIdpEntityId) != null) {

			throw new PortalException();
		}

		long samlIdpConnectionId = counterLocalService.increment(
			SamlIdpConnection.class.getName());

		SamlIdpConnection samlIdpConnection =
			samlIdpConnectionPersistence.create(samlIdpConnectionId);

		samlIdpConnection.setCompanyId(serviceContext.getCompanyId());
		samlIdpConnection.setCreateDate(now);
		samlIdpConnection.setModifiedDate(now);
		samlIdpConnection.setSamlIdpEntityId(samlIdpEntityId);
		samlIdpConnection.setAssertionSignatureRequired(
			assertionSignatureRequired);
		samlIdpConnection.setClockSkew(clockSkew);
		samlIdpConnection.setEnabled(enabled);
		samlIdpConnection.setForceAuthn(forceAuthn);
		samlIdpConnection.setLdapImportEnabled(ldapImportEnabled);
		samlIdpConnection.setMetadataUpdatedDate(now);

		if ((metadataXmlInputStream == null) &&
			Validator.isNotNull(metadataUrl)) {

			samlIdpConnection.setMetadataUrl(metadataUrl);

			metadataXmlInputStream = MetadataUtil.getMetadata(metadataUrl);
		}

		if (metadataXmlInputStream == null) {
			throw new PortalException();
		}

		samlIdpConnection.setMetadataXml(
			getMetadataXml(metadataXmlInputStream, samlIdpEntityId));
		samlIdpConnection.setName(name);
		samlIdpConnection.setNameIdFormat(nameIdFormat);
		samlIdpConnection.setSamlIdpEntityId(samlIdpEntityId);
		samlIdpConnection.setSignAuthnRequest(signAuthnRequest);
		samlIdpConnection.setUserAttributeMappings(userAttributeMappings);

		samlIdpConnectionPersistence.update(samlIdpConnection);

		return samlIdpConnection;
	}


	public SamlIdpConnection getSamlIdpConnection(
			long companyId, String samlIdpEntityId)
		throws PortalException, SystemException {

		return samlIdpConnectionPersistence.findByCompanyId_IdpEntityId(
			companyId, samlIdpEntityId);
	}


	public List<SamlIdpConnection> getSamlIdpConnections(long companyId)
		throws SystemException {

		return samlIdpConnectionPersistence.findByCompanyId(companyId);
	}


	public List<SamlIdpConnection> getSamlIdpConnections(
			long companyId, int start, int end)
		throws SystemException {

		return samlIdpConnectionPersistence.findByCompanyId(
			companyId, start, end);
	}


	public List<SamlIdpConnection> getSamlIdpConnections(
			long companyId, int start, int end,
			OrderByComparator orderByComparator)
		throws SystemException {

		return samlIdpConnectionPersistence.findByCompanyId(
			companyId, start, end, orderByComparator);
	}


	public int getSamlIdpConnectionsCount(long companyId)
		throws SystemException {

		return samlIdpConnectionPersistence.countByCompanyId(companyId);
	}


	public void updateMetadata(long samlIdpConnectionId)
		throws PortalException, SystemException {

		SamlIdpConnection samlIdpConnection =
			samlIdpConnectionPersistence.findByPrimaryKey(
				samlIdpConnectionId);

		String metadataUrl = samlIdpConnection.getMetadataUrl();

		if (Validator.isNull(metadataUrl)) {
			return;
		}

		InputStream metadataXmlInputStream = MetadataUtil.getMetadata(
			metadataUrl);

		if (metadataXmlInputStream == null) {
			if (_log.isWarnEnabled()) {
				_log.warn("Unable to get metadata from " + metadataUrl);
			}

			return;
		}

		String metadataXml = StringPool.BLANK;

		try {
			metadataXml = MetadataUtil.parseMetadataXml(
				metadataXmlInputStream,
				samlIdpConnection.getSamlIdpEntityId());
		}
		catch (Exception e) {
			_log.warn("Unable to parse metadata", e);
		}

		if (Validator.isNotNull(metadataXml)) {
			samlIdpConnection.setMetadataUpdatedDate(new Date());
			samlIdpConnection.setMetadataXml(metadataXml);

			samlIdpConnectionPersistence.update(samlIdpConnection);
		}
	}


	public SamlIdpConnection updateSamlIdpConnection(
			long samlIdpConnectionId, String samlIdpEntityId,
			boolean assertionSignatureRequired, long clockSkew, boolean enabled,
			boolean forceAuthn, boolean ldapImportEnabled, String metadataUrl,
			InputStream metadataXmlInputStream, String name,
			String nameIdFormat, boolean signAuthnRequest,
			String userAttributeMappings, ServiceContext serviceContext)
		throws PortalException, SystemException {

		Date now = new Date();

		if (Validator.isNull(samlIdpEntityId)) {
			throw new PortalException();
		}

		SamlIdpConnection samlIdpConnection =
			samlIdpConnectionPersistence.findByPrimaryKey(
				samlIdpConnectionId);

		if (!samlIdpEntityId.equals(samlIdpConnection.getSamlIdpEntityId())) {
			if (samlIdpConnectionPersistence.fetchByCompanyId_IdpEntityId(
					serviceContext.getCompanyId(), samlIdpEntityId) != null) {

				throw
					new PortalException();
			}
		}

		samlIdpConnection.setCompanyId(serviceContext.getCompanyId());
		samlIdpConnection.setCreateDate(now);
		samlIdpConnection.setModifiedDate(now);
		samlIdpConnection.setSamlIdpEntityId(samlIdpEntityId);
		samlIdpConnection.setAssertionSignatureRequired(
			assertionSignatureRequired);
		samlIdpConnection.setClockSkew(clockSkew);
		samlIdpConnection.setEnabled(enabled);
		samlIdpConnection.setForceAuthn(forceAuthn);
		samlIdpConnection.setLdapImportEnabled(ldapImportEnabled);
		samlIdpConnection.setMetadataUpdatedDate(now);

		if ((metadataXmlInputStream == null) &&
			Validator.isNotNull(metadataUrl)) {

			samlIdpConnection.setMetadataUrl(metadataUrl);

			metadataXmlInputStream = MetadataUtil.getMetadata(metadataUrl);
		}

		String metadataXml = StringPool.BLANK;

		if (metadataXmlInputStream != null) {
			metadataXml = getMetadataXml(
				metadataXmlInputStream, samlIdpEntityId);
		}

		if (Validator.isNotNull(metadataXml)) {
			samlIdpConnection.setMetadataUpdatedDate(now);
			samlIdpConnection.setMetadataXml(metadataXml);
		}

		samlIdpConnection.setName(name);
		samlIdpConnection.setNameIdFormat(nameIdFormat);
		samlIdpConnection.setSamlIdpEntityId(samlIdpEntityId);
		samlIdpConnection.setSignAuthnRequest(signAuthnRequest);
		samlIdpConnection.setUserAttributeMappings(userAttributeMappings);

		samlIdpConnectionPersistence.update(samlIdpConnection);

		return samlIdpConnection;
	}

	protected String getMetadataXml(
			InputStream metadataXmlInputStream, String samlIdpEntityId)
		throws PortalException {

		String metadataXml = StringPool.BLANK;

		try {
			metadataXml = MetadataUtil.parseMetadataXml(
				metadataXmlInputStream, samlIdpEntityId);
		}
		catch (Exception e) {
			throw new PortalException(e);
		}

		if (Validator.isNull(metadataXml)) {
			throw new PortalException();
		}

		return metadataXml;
	}

	private static Log _log = LogFactoryUtil.getLog(
		SamlIdpConnectionLocalServiceImpl.class);
}