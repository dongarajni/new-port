package com.jio.portlet.saml.metadata;

import javax.servlet.http.HttpServletRequest;

import org.opensaml.saml2.metadata.EntityDescriptor;
import org.opensaml.saml2.metadata.provider.MetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.opensaml.ws.security.SecurityPolicyResolver;
import org.opensaml.xml.security.SecurityException;
import org.opensaml.xml.security.credential.Credential;
import org.opensaml.xml.signature.SignatureTrustEngine;

public class MetadataManagerUtil {


	public static long getClockSkew() {
		return getMetadataManager().getClockSkew();
	}

	public static String getDefaultIdpEntityId() {
		return getMetadataManager().getDefaultIdpEntityId();
	}

	public static EntityDescriptor getEntityDescriptor(
			HttpServletRequest request)
		throws MetadataProviderException {

		return getMetadataManager().getEntityDescriptor(request);
	}

	public static String getLocalEntityId() {
		return getMetadataManager().getLocalEntityId();
	}

	public static MetadataManager getMetadataManager() {
		return _metadataManager;
	}

	public static MetadataProvider getMetadataProvider()
		throws MetadataProviderException {

		return getMetadataManager().getMetadataProvider();
	}


	public static String getNameIdFormat(String entityId) {
		return getMetadataManager().getNameIdFormat(entityId);
	}

	public static SecurityPolicyResolver getSecurityPolicyResolver(
			String communicationProfileId, boolean requireSignature)
		throws MetadataProviderException {

		return getMetadataManager().getSecurityPolicyResolver(
			communicationProfileId, requireSignature);
	}

	public static String getSessionKeepAliveURL(String entityId) {
		return getMetadataManager().getSessionKeepAliveURL(entityId);
	}

	public static long getSessionMaximumAge() {
		return getMetadataManager().getSessionMaximumAge();
	}

	public static long getSessionTimeout() {
		return getMetadataManager().getSessionTimeout();
	}

	public static SignatureTrustEngine getSignatureTrustEngine()
		throws MetadataProviderException {

		return getMetadataManager().getSignatureTrustEngine();
	}

	public static Credential getSigningCredential() throws SecurityException {
		return getMetadataManager().getSigningCredential();
	}

	public static String getUserAttributeMappings(String entityId) {
		return getMetadataManager().getUserAttributeMappings(entityId);
	}

	public static boolean isSignAuthnRequests() {
		return getMetadataManager().isSignAuthnRequests();
	}

	public static boolean isSignMetadata() {
		return getMetadataManager().isSignMetadata();
	}

	public static boolean isSSLRequired() {
		return getMetadataManager().isSSLRequired();
	}

	public static boolean isWantAssertionsSigned() {
		return getMetadataManager().isWantAssertionsSigned();
	}

	public static boolean isWantAuthnRequestSigned() {
		return getMetadataManager().isWantAuthnRequestSigned();
	}

	public void setMetadataManager(MetadataManager metadataManager) {
		_metadataManager = metadataManager;
	}

	private static MetadataManager _metadataManager;

}