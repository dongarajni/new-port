package com.jio.portlet.saml.provider;

import java.util.Timer;
import java.util.TimerTask;

import org.opensaml.saml2.metadata.provider.AbstractReloadingMetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;

public class ReinitializingTimerTask extends TimerTask {

	public ReinitializingTimerTask(
		Timer timer,
		AbstractReloadingMetadataProvider abstractReloadingMetadataProvider) {

		_timer = timer;
		_abstractReloadingMetadataProvider = abstractReloadingMetadataProvider;
	}


	public void run() {
		try {
			_abstractReloadingMetadataProvider.initialize();
		}
		catch (MetadataProviderException mpe) {
			TimerTask timerTask = new ReinitializingTimerTask(
				_timer, _abstractReloadingMetadataProvider);

			_timer.schedule(
				timerTask,
				_abstractReloadingMetadataProvider.getMinRefreshDelay());
		}
	}

	private AbstractReloadingMetadataProvider
		_abstractReloadingMetadataProvider;
	private Timer _timer;

}