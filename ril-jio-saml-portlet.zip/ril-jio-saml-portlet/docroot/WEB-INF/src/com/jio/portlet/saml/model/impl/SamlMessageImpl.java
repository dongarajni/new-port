package com.jio.portlet.saml.model.impl;

import java.util.Date;

/**
 * The extended model implementation for the SamlMessage service. Represents a row in the &quot;JIO_SamlMessage&quot; database table, with each column mapped to a property of this class.
 *
 * <p>
 * Helper methods and all application logic should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jio.portlet.saml.model.SamlMessage} interface.
 * </p>
 *
 */
public class SamlMessageImpl extends SamlMessageBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this class directly. All methods that expect a saml message model instance should use the {@link com.jio.portlet.saml.model.SamlMessage} interface instead.
	 */
	public SamlMessageImpl() {
	}
	
	public boolean isExpired() {
		Date now = new Date();

		Date expirationDate = getExpirationDate();

		return expirationDate.before(now);
	}

}