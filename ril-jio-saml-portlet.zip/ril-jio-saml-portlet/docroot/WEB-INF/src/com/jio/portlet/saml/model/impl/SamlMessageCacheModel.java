/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.model.impl;

import com.jio.portlet.saml.model.SamlMessage;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing SamlMessage in entity cache.
 *
 * @author Ashish Jadhav
 * @see SamlMessage
 * @generated
 */
public class SamlMessageCacheModel implements CacheModel<SamlMessage>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{samlMessageId=");
		sb.append(samlMessageId);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", entityId=");
		sb.append(entityId);
		sb.append(", responseKey=");
		sb.append(responseKey);
		sb.append(", expirationDate=");
		sb.append(expirationDate);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public SamlMessage toEntityModel() {
		SamlMessageImpl samlMessageImpl = new SamlMessageImpl();

		samlMessageImpl.setSamlMessageId(samlMessageId);
		samlMessageImpl.setCompanyId(companyId);

		if (createDate == Long.MIN_VALUE) {
			samlMessageImpl.setCreateDate(null);
		}
		else {
			samlMessageImpl.setCreateDate(new Date(createDate));
		}

		if (entityId == null) {
			samlMessageImpl.setEntityId(StringPool.BLANK);
		}
		else {
			samlMessageImpl.setEntityId(entityId);
		}

		if (responseKey == null) {
			samlMessageImpl.setResponseKey(StringPool.BLANK);
		}
		else {
			samlMessageImpl.setResponseKey(responseKey);
		}

		if (expirationDate == Long.MIN_VALUE) {
			samlMessageImpl.setExpirationDate(null);
		}
		else {
			samlMessageImpl.setExpirationDate(new Date(expirationDate));
		}

		samlMessageImpl.resetOriginalValues();

		return samlMessageImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		samlMessageId = objectInput.readLong();
		companyId = objectInput.readLong();
		createDate = objectInput.readLong();
		entityId = objectInput.readUTF();
		responseKey = objectInput.readUTF();
		expirationDate = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(samlMessageId);
		objectOutput.writeLong(companyId);
		objectOutput.writeLong(createDate);

		if (entityId == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(entityId);
		}

		if (responseKey == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(responseKey);
		}

		objectOutput.writeLong(expirationDate);
	}

	public long samlMessageId;
	public long companyId;
	public long createDate;
	public String entityId;
	public String responseKey;
	public long expirationDate;
}