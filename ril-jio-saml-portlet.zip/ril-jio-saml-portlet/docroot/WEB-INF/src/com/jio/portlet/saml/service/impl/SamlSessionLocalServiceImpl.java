/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.service.impl;

import com.jio.portlet.saml.NoSuchSamlSessionException;
import com.jio.portlet.saml.model.SamlSession;
import com.jio.portlet.saml.service.base.SamlSessionLocalServiceBaseImpl;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;

import java.util.Date;
import java.util.List;

/**
 * The implementation of the saml session local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jio.portlet.saml.service.SamlSessionLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Liferay Developer
 * @see com.jio.portlet.saml.service.base.SamlSessionLocalServiceBaseImpl
 * @see com.jio.portlet.saml.service.SamlSessionLocalServiceUtil
 */
public class SamlSessionLocalServiceImpl extends SamlSessionLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.jio.portlet.saml.service.SamlSessionLocalServiceUtil} to access the saml session local service.
	 */
	
	public SamlSession addSamlSession(
			String sessionKey, String assertionXml, String jSessionId,
			String nameIdFormat, String nameIdNameQualifier,
			String nameIdSPNameQualifier, String nameIdValue,
			String sessionIndex, ServiceContext serviceContext)
		throws PortalException, SystemException {

		User user = userLocalService.getUserById(serviceContext.getUserId());
		Date now = new Date();

		long samlSessionId = counterLocalService.increment(
			SamlSession.class.getName());

		SamlSession samlSession = samlSessionPersistence.create(
			samlSessionId);

		samlSession.setCompanyId(serviceContext.getCompanyId());
		samlSession.setUserId(user.getUserId());
		samlSession.setUserName(user.getFullName());
		samlSession.setCreateDate(now);
		samlSession.setModifiedDate(now);
		samlSession.setSessionKey(sessionKey);
		samlSession.setAssertionXml(assertionXml);
		samlSession.setJSessionId(jSessionId);
		samlSession.setNameIdFormat(nameIdFormat);
		samlSession.setNameIdNameQualifier(nameIdNameQualifier);
		samlSession.setNameIdSPNameQualifier(nameIdSPNameQualifier);
		samlSession.setNameIdValue(nameIdValue);
		samlSession.setSessionIndex(sessionIndex);
		samlSession.setTerminated(false);

		samlSessionPersistence.update(samlSession);

		return samlSession;
	}


	public SamlSession fetchSamlSessionByJSessionId(String jSessionId)
		throws SystemException {

		return samlSessionPersistence.fetchByJSessionId(jSessionId);
	}


	public SamlSession fetchSamlSessionBySessionKey(
			String sessionKey)
		throws SystemException {

		return samlSessionPersistence.fetchBySessionKey(
			sessionKey);
	}


	public SamlSession fetchSamlSessionBySessionIndex(String sessionIndex)
		throws SystemException {

		if (Validator.isNull(sessionIndex)) {
			return null;
		}

		return samlSessionPersistence.fetchBySessionIndex(sessionIndex);
	}


	public SamlSession getSamlSessionByJSessionId(String jSessionId)
		throws PortalException, SystemException {

		return samlSessionPersistence.findByJSessionId(jSessionId);
	}


	public SamlSession getSamlSessionBySamlSpSessionKey(
			String samlSpSessionKey)
		throws PortalException, SystemException {

		return samlSessionPersistence.findBySessionKey(
			samlSpSessionKey);
	}


	public SamlSession getSamlSessionBySessionIndex(String sessionIndex)
		throws PortalException, SystemException {

		if (Validator.isNull(sessionIndex)) {
			throw new NoSuchSamlSessionException();
		}

		return samlSessionPersistence.findBySessionIndex(sessionIndex);
	}


	public List<SamlSession> getSamlSessions(String nameIdValue)
		throws SystemException {

		return samlSessionPersistence.findByNameIdValue(nameIdValue);
	}


	public SamlSession updateSamlSession(
			long samlSessionId, String jSessionId)
		throws PortalException, SystemException {

		SamlSession samlSession = samlSessionPersistence.findByPrimaryKey(
			samlSessionId);

		samlSession.setModifiedDate(new Date());
		samlSession.setJSessionId(jSessionId);

		samlSessionPersistence.update(samlSession);

		return samlSession;
	}


	public SamlSession updateSamlSession(
			long samlSpSessionId, String samlSpSessionKey, String assertionXml,
			String jSessionId, String nameIdFormat, String nameIdNameQualifier,
			String nameIdSPNameQualifier, String nameIdValue,
			String sessionIndex, ServiceContext serviceContext)
		throws PortalException, SystemException {

		User user = userLocalService.getUserById(serviceContext.getUserId());

		SamlSession samlSession = samlSessionPersistence.findByPrimaryKey(
			samlSpSessionId);

		samlSession.setCompanyId(serviceContext.getCompanyId());
		samlSession.setUserId(user.getUserId());
		samlSession.setUserName(user.getFullName());
		samlSession.setModifiedDate(new Date());
		samlSession.setSessionKey(samlSpSessionKey);
		samlSession.setAssertionXml(assertionXml);
		samlSession.setJSessionId(jSessionId);
		samlSession.setNameIdFormat(nameIdFormat);
		samlSession.setNameIdNameQualifier(nameIdNameQualifier);
		samlSession.setNameIdSPNameQualifier(nameIdSPNameQualifier);
		samlSession.setNameIdValue(nameIdValue);
		samlSession.setSessionIndex(sessionIndex);

		samlSessionPersistence.update(samlSession);

		return samlSession;
	}
}