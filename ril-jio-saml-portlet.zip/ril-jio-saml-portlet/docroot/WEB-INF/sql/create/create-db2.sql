drop database lportal;
create database lportal pagesize 8192;
connect to lportal;
create table JIO_SamlAuthRequest (
	samlAuthnRequestId bigint not null primary key,
	companyId bigint,
	createDate timestamp,
	entityId varchar(1024),
	authRequestKey varchar(75)
);

create table JIO_SamlIdpConnection (
	samlIdpConnectionId bigint not null primary key,
	companyId bigint,
	userId bigint,
	userName varchar(75),
	createDate timestamp,
	modifiedDate timestamp,
	samlIdpEntityId varchar(1024),
	assertionSignatureRequired smallint,
	clockSkew bigint,
	enabled smallint,
	forceAuthn smallint,
	ldapImportEnabled smallint,
	metadataUrl varchar(1024),
	metadataXml clob,
	metadataUpdatedDate timestamp,
	name varchar(75),
	nameIdFormat varchar(1024),
	signAuthnRequest smallint,
	userAttributeMappings varchar(750)
);

create table JIO_SamlMessage (
	samlMessageId bigint not null primary key,
	companyId bigint,
	createDate timestamp,
	entityId varchar(1024),
	responseKey varchar(75),
	expirationDate timestamp
);

create table JIO_SamlSession (
	sessionId bigint not null primary key,
	sessionKey varchar(75),
	assertionXml clob,
	jSessionId varchar(200),
	nameIdFormat varchar(1024),
	nameIdNameQualifier varchar(1024),
	nameIdSPNameQualifier varchar(1024),
	nameIdValue varchar(1024),
	sessionIndex varchar(75),
	terminated_ smallint,
	companyId bigint,
	userId bigint,
	userName varchar(75),
	createDate timestamp,
	modifiedDate timestamp
);


create index IX_EA93A7CF on JIO_SamlAuthRequest (entityId, authRequestKey);

create index IX_2BDD05AB on JIO_SamlIdpConnection (companyId);
create index IX_C60474EB on JIO_SamlIdpConnection (companyId, samlIdpEntityId);

create index IX_AE0F646B on JIO_SamlMessage (entityId, responseKey);

create index IX_67AB217B on JIO_SamlSession (jSessionId);
create index IX_654889BB on JIO_SamlSession (nameIdValue);
create index IX_6BF63690 on JIO_SamlSession (sessionIndex);
create unique index IX_AC074FDD on JIO_SamlSession (sessionKey);


