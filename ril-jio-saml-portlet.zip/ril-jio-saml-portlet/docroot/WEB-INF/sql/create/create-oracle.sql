drop user &1 cascade;
create user &1 identified by &2;
grant connect,resource to &1;
connect &1/&2;
set define off;

create table JIO_SamlAuthRequest (
	samlAuthnRequestId number(30,0) not null primary key,
	companyId number(30,0),
	createDate timestamp null,
	entityId VARCHAR2(1024 CHAR) null,
	authRequestKey VARCHAR2(75 CHAR) null
);

create table JIO_SamlIdpConnection (
	samlIdpConnectionId number(30,0) not null primary key,
	companyId number(30,0),
	userId number(30,0),
	userName VARCHAR2(75 CHAR) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	samlIdpEntityId VARCHAR2(1024 CHAR) null,
	assertionSignatureRequired number(1, 0),
	clockSkew number(30,0),
	enabled number(1, 0),
	forceAuthn number(1, 0),
	ldapImportEnabled number(1, 0),
	metadataUrl VARCHAR2(1024 CHAR) null,
	metadataXml clob null,
	metadataUpdatedDate timestamp null,
	name VARCHAR2(75 CHAR) null,
	nameIdFormat VARCHAR2(1024 CHAR) null,
	signAuthnRequest number(1, 0),
	userAttributeMappings varchar2(4000) null
);

create table JIO_SamlMessage (
	samlMessageId number(30,0) not null primary key,
	companyId number(30,0),
	createDate timestamp null,
	entityId VARCHAR2(1024 CHAR) null,
	responseKey VARCHAR2(75 CHAR) null,
	expirationDate timestamp null
);

create table JIO_SamlSession (
	sessionId number(30,0) not null primary key,
	sessionKey VARCHAR2(75 CHAR) null,
	assertionXml clob null,
	jSessionId VARCHAR2(200 CHAR) null,
	nameIdFormat VARCHAR2(1024 CHAR) null,
	nameIdNameQualifier VARCHAR2(1024 CHAR) null,
	nameIdSPNameQualifier VARCHAR2(1024 CHAR) null,
	nameIdValue VARCHAR2(1024 CHAR) null,
	sessionIndex VARCHAR2(75 CHAR) null,
	terminated_ number(1, 0),
	companyId number(30,0),
	userId number(30,0),
	userName VARCHAR2(75 CHAR) null,
	createDate timestamp null,
	modifiedDate timestamp null
);


create index IX_EA93A7CF on JIO_SamlAuthRequest (entityId, authRequestKey);

create index IX_2BDD05AB on JIO_SamlIdpConnection (companyId);
create index IX_C60474EB on JIO_SamlIdpConnection (companyId, samlIdpEntityId);

create index IX_AE0F646B on JIO_SamlMessage (entityId, responseKey);

create index IX_67AB217B on JIO_SamlSession (jSessionId);
create index IX_654889BB on JIO_SamlSession (nameIdValue);
create index IX_6BF63690 on JIO_SamlSession (sessionIndex);
create unique index IX_AC074FDD on JIO_SamlSession (sessionKey);



quit