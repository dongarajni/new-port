database sysmaster;
drop database lportal;
create database lportal WITH LOG;

create procedure 'lportal'.isnull(test_string varchar)
returning boolean;
IF test_string IS NULL THEN
	RETURN 't';
ELSE
	RETURN 'f';
END IF
end procedure;


create table JIO_SamlAuthRequest (
	samlAuthnRequestId int8 not null primary key,
	companyId int8,
	createDate datetime YEAR TO FRACTION,
	entityId lvarchar(1024),
	authRequestKey varchar(75)
)
extent size 16 next size 16
lock mode row;

create table JIO_SamlIdpConnection (
	samlIdpConnectionId int8 not null primary key,
	companyId int8,
	userId int8,
	userName varchar(75),
	createDate datetime YEAR TO FRACTION,
	modifiedDate datetime YEAR TO FRACTION,
	samlIdpEntityId lvarchar(1024),
	assertionSignatureRequired boolean,
	clockSkew int8,
	enabled boolean,
	forceAuthn boolean,
	ldapImportEnabled boolean,
	metadataUrl lvarchar(1024),
	metadataXml text,
	metadataUpdatedDate datetime YEAR TO FRACTION,
	name varchar(75),
	nameIdFormat lvarchar(1024),
	signAuthnRequest boolean,
	userAttributeMappings lvarchar
)
extent size 16 next size 16
lock mode row;

create table JIO_SamlMessage (
	samlMessageId int8 not null primary key,
	companyId int8,
	createDate datetime YEAR TO FRACTION,
	entityId lvarchar(1024),
	responseKey varchar(75),
	expirationDate datetime YEAR TO FRACTION
)
extent size 16 next size 16
lock mode row;

create table JIO_SamlSession (
	sessionId int8 not null primary key,
	sessionKey varchar(75),
	assertionXml text,
	jSessionId varchar(200),
	nameIdFormat lvarchar(1024),
	nameIdNameQualifier lvarchar(1024),
	nameIdSPNameQualifier lvarchar(1024),
	nameIdValue lvarchar(1024),
	sessionIndex varchar(75),
	terminated_ boolean,
	companyId int8,
	userId int8,
	userName varchar(75),
	createDate datetime YEAR TO FRACTION,
	modifiedDate datetime YEAR TO FRACTION
)
extent size 16 next size 16
lock mode row;


create index IX_EA93A7CF on JIO_SamlAuthRequest (entityId, authRequestKey);

create index IX_2BDD05AB on JIO_SamlIdpConnection (companyId);
create index IX_C60474EB on JIO_SamlIdpConnection (companyId, samlIdpEntityId);

create index IX_AE0F646B on JIO_SamlMessage (entityId, responseKey);

create index IX_67AB217B on JIO_SamlSession (jSessionId);
create index IX_654889BB on JIO_SamlSession (nameIdValue);
create index IX_6BF63690 on JIO_SamlSession (sessionIndex);
create unique index IX_AC074FDD on JIO_SamlSession (sessionKey);


