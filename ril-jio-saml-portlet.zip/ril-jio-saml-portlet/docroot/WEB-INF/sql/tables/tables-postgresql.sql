create table JIO_SamlAuthRequest (
	samlAuthnRequestId bigint not null primary key,
	companyId bigint,
	createDate timestamp null,
	entityId varchar(1024) null,
	authRequestKey varchar(75) null
);

create table JIO_SamlIdpConnection (
	samlIdpConnectionId bigint not null primary key,
	companyId bigint,
	userId bigint,
	userName varchar(75) null,
	createDate timestamp null,
	modifiedDate timestamp null,
	samlIdpEntityId varchar(1024) null,
	assertionSignatureRequired bool,
	clockSkew bigint,
	enabled bool,
	forceAuthn bool,
	ldapImportEnabled bool,
	metadataUrl varchar(1024) null,
	metadataXml text null,
	metadataUpdatedDate timestamp null,
	name varchar(75) null,
	nameIdFormat varchar(1024) null,
	signAuthnRequest bool,
	userAttributeMappings text null
);

create table JIO_SamlMessage (
	samlMessageId bigint not null primary key,
	companyId bigint,
	createDate timestamp null,
	entityId varchar(1024) null,
	responseKey varchar(75) null,
	expirationDate timestamp null
);

create table JIO_SamlSession (
	sessionId bigint not null primary key,
	sessionKey varchar(75) null,
	assertionXml text null,
	jSessionId varchar(200) null,
	nameIdFormat varchar(1024) null,
	nameIdNameQualifier varchar(1024) null,
	nameIdSPNameQualifier varchar(1024) null,
	nameIdValue varchar(1024) null,
	sessionIndex varchar(75) null,
	terminated_ bool,
	companyId bigint,
	userId bigint,
	userName varchar(75) null,
	createDate timestamp null,
	modifiedDate timestamp null
);
