create table JIO_SamlAuthRequest (
	samlAuthnRequestId bigint not null primary key,
	companyId bigint,
	createDate datetime null,
	entityId nvarchar(1024) null,
	authRequestKey nvarchar(75) null
);

create table JIO_SamlIdpConnection (
	samlIdpConnectionId bigint not null primary key,
	companyId bigint,
	userId bigint,
	userName nvarchar(75) null,
	createDate datetime null,
	modifiedDate datetime null,
	samlIdpEntityId nvarchar(1024) null,
	assertionSignatureRequired bit,
	clockSkew bigint,
	enabled bit,
	forceAuthn bit,
	ldapImportEnabled bit,
	metadataUrl nvarchar(1024) null,
	metadataXml nvarchar(max) null,
	metadataUpdatedDate datetime null,
	name nvarchar(75) null,
	nameIdFormat nvarchar(1024) null,
	signAuthnRequest bit,
	userAttributeMappings nvarchar(2000) null
);

create table JIO_SamlMessage (
	samlMessageId bigint not null primary key,
	companyId bigint,
	createDate datetime null,
	entityId nvarchar(1024) null,
	responseKey nvarchar(75) null,
	expirationDate datetime null
);

create table JIO_SamlSession (
	sessionId bigint not null primary key,
	sessionKey nvarchar(75) null,
	assertionXml nvarchar(max) null,
	jSessionId nvarchar(200) null,
	nameIdFormat nvarchar(1024) null,
	nameIdNameQualifier nvarchar(1024) null,
	nameIdSPNameQualifier nvarchar(1024) null,
	nameIdValue nvarchar(1024) null,
	sessionIndex nvarchar(75) null,
	terminated_ bit,
	companyId bigint,
	userId bigint,
	userName nvarchar(75) null,
	createDate datetime null,
	modifiedDate datetime null
);
