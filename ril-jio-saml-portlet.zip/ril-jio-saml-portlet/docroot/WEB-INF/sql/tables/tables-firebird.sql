create table JIO_SamlAuthRequest (
	samlAuthnRequestId int64 not null primary key,
	companyId int64,
	createDate timestamp,
	entityId varchar(1024),
	authRequestKey varchar(75)
);

create table JIO_SamlIdpConnection (
	samlIdpConnectionId int64 not null primary key,
	companyId int64,
	userId int64,
	userName varchar(75),
	createDate timestamp,
	modifiedDate timestamp,
	samlIdpEntityId varchar(1024),
	assertionSignatureRequired smallint,
	clockSkew int64,
	enabled smallint,
	forceAuthn smallint,
	ldapImportEnabled smallint,
	metadataUrl varchar(1024),
	metadataXml blob,
	metadataUpdatedDate timestamp,
	name varchar(75),
	nameIdFormat varchar(1024),
	signAuthnRequest smallint,
	userAttributeMappings varchar(4000)
);

create table JIO_SamlMessage (
	samlMessageId int64 not null primary key,
	companyId int64,
	createDate timestamp,
	entityId varchar(1024),
	responseKey varchar(75),
	expirationDate timestamp
);

create table JIO_SamlSession (
	sessionId int64 not null primary key,
	sessionKey varchar(75),
	assertionXml blob,
	jSessionId varchar(200),
	nameIdFormat varchar(1024),
	nameIdNameQualifier varchar(1024),
	nameIdSPNameQualifier varchar(1024),
	nameIdValue varchar(1024),
	sessionIndex varchar(75),
	terminated_ smallint,
	companyId int64,
	userId int64,
	userName varchar(75),
	createDate timestamp,
	modifiedDate timestamp
);
