create table JIO_SamlAuthRequest (
	samlAuthnRequestId bigint not null primary key,
	companyId bigint,
	createDate date null,
	entityId varchar(1024) null,
	authRequestKey varchar(75) null
);

create table JIO_SamlIdpConnection (
	samlIdpConnectionId bigint not null primary key,
	companyId bigint,
	userId bigint,
	userName varchar(75) null,
	createDate date null,
	modifiedDate date null,
	samlIdpEntityId varchar(1024) null,
	assertionSignatureRequired boolean,
	clockSkew bigint,
	enabled boolean,
	forceAuthn boolean,
	ldapImportEnabled boolean,
	metadataUrl varchar(1024) null,
	metadataXml long varchar null,
	metadataUpdatedDate date null,
	name varchar(75) null,
	nameIdFormat varchar(1024) null,
	signAuthnRequest boolean,
	userAttributeMappings long varchar null
);

create table JIO_SamlMessage (
	samlMessageId bigint not null primary key,
	companyId bigint,
	createDate date null,
	entityId varchar(1024) null,
	responseKey varchar(75) null,
	expirationDate date null
);

create table JIO_SamlSession (
	sessionId bigint not null primary key,
	sessionKey varchar(75) null,
	assertionXml long varchar null,
	jSessionId varchar(200) null,
	nameIdFormat varchar(1024) null,
	nameIdNameQualifier varchar(1024) null,
	nameIdSPNameQualifier varchar(1024) null,
	nameIdValue varchar(1024) null,
	sessionIndex varchar(75) null,
	terminated_ boolean,
	companyId bigint,
	userId bigint,
	userName varchar(75) null,
	createDate date null,
	modifiedDate date null
);
