create table JIO_SamlAuthRequest (
	samlAuthnRequestId decimal(20,0) not null primary key,
	companyId decimal(20,0),
	createDate datetime null,
	entityId varchar(1024) null,
	authRequestKey varchar(75) null
)
go

create table JIO_SamlIdpConnection (
	samlIdpConnectionId decimal(20,0) not null primary key,
	companyId decimal(20,0),
	userId decimal(20,0),
	userName varchar(75) null,
	createDate datetime null,
	modifiedDate datetime null,
	samlIdpEntityId varchar(1024) null,
	assertionSignatureRequired int,
	clockSkew decimal(20,0),
	enabled int,
	forceAuthn int,
	ldapImportEnabled int,
	metadataUrl varchar(1024) null,
	metadataXml text null,
	metadataUpdatedDate datetime null,
	name varchar(75) null,
	nameIdFormat varchar(1024) null,
	signAuthnRequest int,
	userAttributeMappings varchar(1000) null
)
go

create table JIO_SamlMessage (
	samlMessageId decimal(20,0) not null primary key,
	companyId decimal(20,0),
	createDate datetime null,
	entityId varchar(1024) null,
	responseKey varchar(75) null,
	expirationDate datetime null
)
go

create table JIO_SamlSession (
	sessionId decimal(20,0) not null primary key,
	sessionKey varchar(75) null,
	assertionXml text null,
	jSessionId varchar(200) null,
	nameIdFormat varchar(1024) null,
	nameIdNameQualifier varchar(1024) null,
	nameIdSPNameQualifier varchar(1024) null,
	nameIdValue varchar(1024) null,
	sessionIndex varchar(75) null,
	terminated_ int,
	companyId decimal(20,0),
	userId decimal(20,0),
	userName varchar(75) null,
	createDate datetime null,
	modifiedDate datetime null
)
go
