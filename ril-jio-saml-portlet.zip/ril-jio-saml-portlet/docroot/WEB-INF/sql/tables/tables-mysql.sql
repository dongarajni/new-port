create table JIO_SamlAuthRequest (
	samlAuthnRequestId bigint not null primary key,
	companyId bigint,
	createDate datetime null,
	entityId varchar(1024) null,
	authRequestKey varchar(75) null
) engine InnoDB;

create table JIO_SamlIdpConnection (
	samlIdpConnectionId bigint not null primary key,
	companyId bigint,
	userId bigint,
	userName varchar(75) null,
	createDate datetime null,
	modifiedDate datetime null,
	samlIdpEntityId varchar(1024) null,
	assertionSignatureRequired tinyint,
	clockSkew bigint,
	enabled tinyint,
	forceAuthn tinyint,
	ldapImportEnabled tinyint,
	metadataUrl varchar(1024) null,
	metadataXml longtext null,
	metadataUpdatedDate datetime null,
	name varchar(75) null,
	nameIdFormat varchar(1024) null,
	signAuthnRequest tinyint,
	userAttributeMappings longtext null
) engine InnoDB;

create table JIO_SamlMessage (
	samlMessageId bigint not null primary key,
	companyId bigint,
	createDate datetime null,
	entityId varchar(1024) null,
	responseKey varchar(75) null,
	expirationDate datetime null
) engine InnoDB;

create table JIO_SamlSession (
	sessionId bigint not null primary key,
	sessionKey varchar(75) null,
	assertionXml longtext null,
	jSessionId varchar(200) null,
	nameIdFormat varchar(1024) null,
	nameIdNameQualifier varchar(1024) null,
	nameIdSPNameQualifier varchar(1024) null,
	nameIdValue varchar(1024) null,
	sessionIndex varchar(75) null,
	terminated_ tinyint,
	companyId bigint,
	userId bigint,
	userName varchar(75) null,
	createDate datetime null,
	modifiedDate datetime null
) engine InnoDB;
