create table JIO_SamlAuthRequest (
	samlAuthnRequestId LONG not null primary key,
	companyId LONG,
	createDate DATE null,
	entityId VARCHAR(1024) null,
	authRequestKey VARCHAR(75) null
);

create table JIO_SamlIdpConnection (
	samlIdpConnectionId LONG not null primary key,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	samlIdpEntityId VARCHAR(1024) null,
	assertionSignatureRequired BOOLEAN,
	clockSkew LONG,
	enabled BOOLEAN,
	forceAuthn BOOLEAN,
	ldapImportEnabled BOOLEAN,
	metadataUrl VARCHAR(1024) null,
	metadataXml TEXT null,
	metadataUpdatedDate DATE null,
	name VARCHAR(75) null,
	nameIdFormat VARCHAR(1024) null,
	signAuthnRequest BOOLEAN,
	userAttributeMappings STRING null
);

create table JIO_SamlMessage (
	samlMessageId LONG not null primary key,
	companyId LONG,
	createDate DATE null,
	entityId VARCHAR(1024) null,
	responseKey VARCHAR(75) null,
	expirationDate DATE null
);

create table JIO_SamlSession (
	sessionId LONG not null primary key,
	sessionKey VARCHAR(75) null,
	assertionXml TEXT null,
	jSessionId VARCHAR(200) null,
	nameIdFormat VARCHAR(1024) null,
	nameIdNameQualifier VARCHAR(1024) null,
	nameIdSPNameQualifier VARCHAR(1024) null,
	nameIdValue VARCHAR(1024) null,
	sessionIndex VARCHAR(75) null,
	terminated_ BOOLEAN,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null
);