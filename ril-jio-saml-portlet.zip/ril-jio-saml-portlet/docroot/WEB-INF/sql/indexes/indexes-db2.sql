create index IX_EA93A7CF on JIO_SamlAuthRequest (entityId, authRequestKey);

create index IX_2BDD05AB on JIO_SamlIdpConnection (companyId);
create index IX_C60474EB on JIO_SamlIdpConnection (companyId, samlIdpEntityId);

create index IX_AE0F646B on JIO_SamlMessage (entityId, responseKey);

create index IX_67AB217B on JIO_SamlSession (jSessionId);
create index IX_654889BB on JIO_SamlSession (nameIdValue);
create index IX_6BF63690 on JIO_SamlSession (sessionIndex);
create unique index IX_AC074FDD on JIO_SamlSession (sessionKey);
