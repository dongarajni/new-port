/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.service.persistence;

import com.jio.portlet.saml.model.SamlIdpConnection;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import java.util.List;

/**
 * The persistence utility for the saml idp connection service. This utility wraps {@link SamlIdpConnectionPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Ashish Jadhav
 * @see SamlIdpConnectionPersistence
 * @see SamlIdpConnectionPersistenceImpl
 * @generated
 */
public class SamlIdpConnectionUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(SamlIdpConnection samlIdpConnection) {
		getPersistence().clearCache(samlIdpConnection);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<SamlIdpConnection> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<SamlIdpConnection> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<SamlIdpConnection> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static SamlIdpConnection update(SamlIdpConnection samlIdpConnection)
		throws SystemException {
		return getPersistence().update(samlIdpConnection);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static SamlIdpConnection update(
		SamlIdpConnection samlIdpConnection, ServiceContext serviceContext)
		throws SystemException {
		return getPersistence().update(samlIdpConnection, serviceContext);
	}

	/**
	* Returns all the saml idp connections where companyId = &#63;.
	*
	* @param companyId the company ID
	* @return the matching saml idp connections
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.portlet.saml.model.SamlIdpConnection> findByCompanyId(
		long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByCompanyId(companyId);
	}

	/**
	* Returns a range of all the saml idp connections where companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlIdpConnectionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param companyId the company ID
	* @param start the lower bound of the range of saml idp connections
	* @param end the upper bound of the range of saml idp connections (not inclusive)
	* @return the range of matching saml idp connections
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.portlet.saml.model.SamlIdpConnection> findByCompanyId(
		long companyId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByCompanyId(companyId, start, end);
	}

	/**
	* Returns an ordered range of all the saml idp connections where companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlIdpConnectionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param companyId the company ID
	* @param start the lower bound of the range of saml idp connections
	* @param end the upper bound of the range of saml idp connections (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching saml idp connections
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.portlet.saml.model.SamlIdpConnection> findByCompanyId(
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByCompanyId(companyId, start, end, orderByComparator);
	}

	/**
	* Returns the first saml idp connection in the ordered set where companyId = &#63;.
	*
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching saml idp connection
	* @throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException if a matching saml idp connection could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlIdpConnection findByCompanyId_First(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByCompanyId_First(companyId, orderByComparator);
	}

	/**
	* Returns the first saml idp connection in the ordered set where companyId = &#63;.
	*
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching saml idp connection, or <code>null</code> if a matching saml idp connection could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlIdpConnection fetchByCompanyId_First(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByCompanyId_First(companyId, orderByComparator);
	}

	/**
	* Returns the last saml idp connection in the ordered set where companyId = &#63;.
	*
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching saml idp connection
	* @throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException if a matching saml idp connection could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlIdpConnection findByCompanyId_Last(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByCompanyId_Last(companyId, orderByComparator);
	}

	/**
	* Returns the last saml idp connection in the ordered set where companyId = &#63;.
	*
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching saml idp connection, or <code>null</code> if a matching saml idp connection could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlIdpConnection fetchByCompanyId_Last(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByCompanyId_Last(companyId, orderByComparator);
	}

	/**
	* Returns the saml idp connections before and after the current saml idp connection in the ordered set where companyId = &#63;.
	*
	* @param samlIdpConnectionId the primary key of the current saml idp connection
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next saml idp connection
	* @throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException if a saml idp connection with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlIdpConnection[] findByCompanyId_PrevAndNext(
		long samlIdpConnectionId, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByCompanyId_PrevAndNext(samlIdpConnectionId, companyId,
			orderByComparator);
	}

	/**
	* Removes all the saml idp connections where companyId = &#63; from the database.
	*
	* @param companyId the company ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByCompanyId(long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByCompanyId(companyId);
	}

	/**
	* Returns the number of saml idp connections where companyId = &#63;.
	*
	* @param companyId the company ID
	* @return the number of matching saml idp connections
	* @throws SystemException if a system exception occurred
	*/
	public static int countByCompanyId(long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByCompanyId(companyId);
	}

	/**
	* Returns the saml idp connection where companyId = &#63; and samlIdpEntityId = &#63; or throws a {@link com.jio.portlet.saml.NoSuchSamlIdpConnectionException} if it could not be found.
	*
	* @param companyId the company ID
	* @param samlIdpEntityId the saml idp entity ID
	* @return the matching saml idp connection
	* @throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException if a matching saml idp connection could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlIdpConnection findByCompanyId_IdpEntityId(
		long companyId, java.lang.String samlIdpEntityId)
		throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByCompanyId_IdpEntityId(companyId, samlIdpEntityId);
	}

	/**
	* Returns the saml idp connection where companyId = &#63; and samlIdpEntityId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param companyId the company ID
	* @param samlIdpEntityId the saml idp entity ID
	* @return the matching saml idp connection, or <code>null</code> if a matching saml idp connection could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlIdpConnection fetchByCompanyId_IdpEntityId(
		long companyId, java.lang.String samlIdpEntityId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByCompanyId_IdpEntityId(companyId, samlIdpEntityId);
	}

	/**
	* Returns the saml idp connection where companyId = &#63; and samlIdpEntityId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param companyId the company ID
	* @param samlIdpEntityId the saml idp entity ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching saml idp connection, or <code>null</code> if a matching saml idp connection could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlIdpConnection fetchByCompanyId_IdpEntityId(
		long companyId, java.lang.String samlIdpEntityId,
		boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByCompanyId_IdpEntityId(companyId, samlIdpEntityId,
			retrieveFromCache);
	}

	/**
	* Removes the saml idp connection where companyId = &#63; and samlIdpEntityId = &#63; from the database.
	*
	* @param companyId the company ID
	* @param samlIdpEntityId the saml idp entity ID
	* @return the saml idp connection that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlIdpConnection removeByCompanyId_IdpEntityId(
		long companyId, java.lang.String samlIdpEntityId)
		throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .removeByCompanyId_IdpEntityId(companyId, samlIdpEntityId);
	}

	/**
	* Returns the number of saml idp connections where companyId = &#63; and samlIdpEntityId = &#63;.
	*
	* @param companyId the company ID
	* @param samlIdpEntityId the saml idp entity ID
	* @return the number of matching saml idp connections
	* @throws SystemException if a system exception occurred
	*/
	public static int countByCompanyId_IdpEntityId(long companyId,
		java.lang.String samlIdpEntityId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .countByCompanyId_IdpEntityId(companyId, samlIdpEntityId);
	}

	/**
	* Caches the saml idp connection in the entity cache if it is enabled.
	*
	* @param samlIdpConnection the saml idp connection
	*/
	public static void cacheResult(
		com.jio.portlet.saml.model.SamlIdpConnection samlIdpConnection) {
		getPersistence().cacheResult(samlIdpConnection);
	}

	/**
	* Caches the saml idp connections in the entity cache if it is enabled.
	*
	* @param samlIdpConnections the saml idp connections
	*/
	public static void cacheResult(
		java.util.List<com.jio.portlet.saml.model.SamlIdpConnection> samlIdpConnections) {
		getPersistence().cacheResult(samlIdpConnections);
	}

	/**
	* Creates a new saml idp connection with the primary key. Does not add the saml idp connection to the database.
	*
	* @param samlIdpConnectionId the primary key for the new saml idp connection
	* @return the new saml idp connection
	*/
	public static com.jio.portlet.saml.model.SamlIdpConnection create(
		long samlIdpConnectionId) {
		return getPersistence().create(samlIdpConnectionId);
	}

	/**
	* Removes the saml idp connection with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param samlIdpConnectionId the primary key of the saml idp connection
	* @return the saml idp connection that was removed
	* @throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException if a saml idp connection with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlIdpConnection remove(
		long samlIdpConnectionId)
		throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().remove(samlIdpConnectionId);
	}

	public static com.jio.portlet.saml.model.SamlIdpConnection updateImpl(
		com.jio.portlet.saml.model.SamlIdpConnection samlIdpConnection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(samlIdpConnection);
	}

	/**
	* Returns the saml idp connection with the primary key or throws a {@link com.jio.portlet.saml.NoSuchSamlIdpConnectionException} if it could not be found.
	*
	* @param samlIdpConnectionId the primary key of the saml idp connection
	* @return the saml idp connection
	* @throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException if a saml idp connection with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlIdpConnection findByPrimaryKey(
		long samlIdpConnectionId)
		throws com.jio.portlet.saml.NoSuchSamlIdpConnectionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPrimaryKey(samlIdpConnectionId);
	}

	/**
	* Returns the saml idp connection with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param samlIdpConnectionId the primary key of the saml idp connection
	* @return the saml idp connection, or <code>null</code> if a saml idp connection with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlIdpConnection fetchByPrimaryKey(
		long samlIdpConnectionId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(samlIdpConnectionId);
	}

	/**
	* Returns all the saml idp connections.
	*
	* @return the saml idp connections
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.portlet.saml.model.SamlIdpConnection> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the saml idp connections.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlIdpConnectionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of saml idp connections
	* @param end the upper bound of the range of saml idp connections (not inclusive)
	* @return the range of saml idp connections
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.portlet.saml.model.SamlIdpConnection> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the saml idp connections.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlIdpConnectionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of saml idp connections
	* @param end the upper bound of the range of saml idp connections (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of saml idp connections
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.portlet.saml.model.SamlIdpConnection> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the saml idp connections from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of saml idp connections.
	*
	* @return the number of saml idp connections
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static SamlIdpConnectionPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (SamlIdpConnectionPersistence)PortletBeanLocatorUtil.locate(com.jio.portlet.saml.service.ClpSerializer.getServletContextName(),
					SamlIdpConnectionPersistence.class.getName());

			ReferenceRegistry.registerReference(SamlIdpConnectionUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(SamlIdpConnectionPersistence persistence) {
	}

	private static SamlIdpConnectionPersistence _persistence;
}