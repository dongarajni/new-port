/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableLocalService;

/**
 * Provides the local service utility for SamlSession. This utility wraps
 * {@link com.jio.portlet.saml.service.impl.SamlSessionLocalServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Ashish Jadhav
 * @see SamlSessionLocalService
 * @see com.jio.portlet.saml.service.base.SamlSessionLocalServiceBaseImpl
 * @see com.jio.portlet.saml.service.impl.SamlSessionLocalServiceImpl
 * @generated
 */
public class SamlSessionLocalServiceUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to {@link com.jio.portlet.saml.service.impl.SamlSessionLocalServiceImpl} and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	* Adds the saml session to the database. Also notifies the appropriate model listeners.
	*
	* @param samlSession the saml session
	* @return the saml session that was added
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession addSamlSession(
		com.jio.portlet.saml.model.SamlSession samlSession)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().addSamlSession(samlSession);
	}

	/**
	* Creates a new saml session with the primary key. Does not add the saml session to the database.
	*
	* @param sessionId the primary key for the new saml session
	* @return the new saml session
	*/
	public static com.jio.portlet.saml.model.SamlSession createSamlSession(
		long sessionId) {
		return getService().createSamlSession(sessionId);
	}

	/**
	* Deletes the saml session with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param sessionId the primary key of the saml session
	* @return the saml session that was removed
	* @throws PortalException if a saml session with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession deleteSamlSession(
		long sessionId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteSamlSession(sessionId);
	}

	/**
	* Deletes the saml session from the database. Also notifies the appropriate model listeners.
	*
	* @param samlSession the saml session
	* @return the saml session that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession deleteSamlSession(
		com.jio.portlet.saml.model.SamlSession samlSession)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteSamlSession(samlSession);
	}

	public static com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlSessionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlSessionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static com.jio.portlet.saml.model.SamlSession fetchSamlSession(
		long sessionId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().fetchSamlSession(sessionId);
	}

	/**
	* Returns the saml session with the primary key.
	*
	* @param sessionId the primary key of the saml session
	* @return the saml session
	* @throws PortalException if a saml session with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession getSamlSession(
		long sessionId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getSamlSession(sessionId);
	}

	public static com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the saml sessions.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlSessionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of saml sessions
	* @param end the upper bound of the range of saml sessions (not inclusive)
	* @return the range of saml sessions
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.portlet.saml.model.SamlSession> getSamlSessions(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getSamlSessions(start, end);
	}

	/**
	* Returns the number of saml sessions.
	*
	* @return the number of saml sessions
	* @throws SystemException if a system exception occurred
	*/
	public static int getSamlSessionsCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getSamlSessionsCount();
	}

	/**
	* Updates the saml session in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param samlSession the saml session
	* @return the saml session that was updated
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession updateSamlSession(
		com.jio.portlet.saml.model.SamlSession samlSession)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().updateSamlSession(samlSession);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	public static java.lang.String getBeanIdentifier() {
		return getService().getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	public static void setBeanIdentifier(java.lang.String beanIdentifier) {
		getService().setBeanIdentifier(beanIdentifier);
	}

	public static java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return getService().invokeMethod(name, parameterTypes, arguments);
	}

	public static com.jio.portlet.saml.model.SamlSession addSamlSession(
		java.lang.String sessionKey, java.lang.String assertionXml,
		java.lang.String jSessionId, java.lang.String nameIdFormat,
		java.lang.String nameIdNameQualifier,
		java.lang.String nameIdSPNameQualifier, java.lang.String nameIdValue,
		java.lang.String sessionIndex,
		com.liferay.portal.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .addSamlSession(sessionKey, assertionXml, jSessionId,
			nameIdFormat, nameIdNameQualifier, nameIdSPNameQualifier,
			nameIdValue, sessionIndex, serviceContext);
	}

	public static com.jio.portlet.saml.model.SamlSession fetchSamlSessionByJSessionId(
		java.lang.String jSessionId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().fetchSamlSessionByJSessionId(jSessionId);
	}

	public static com.jio.portlet.saml.model.SamlSession fetchSamlSessionBySessionKey(
		java.lang.String sessionKey)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().fetchSamlSessionBySessionKey(sessionKey);
	}

	public static com.jio.portlet.saml.model.SamlSession fetchSamlSessionBySessionIndex(
		java.lang.String sessionIndex)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().fetchSamlSessionBySessionIndex(sessionIndex);
	}

	public static com.jio.portlet.saml.model.SamlSession getSamlSessionByJSessionId(
		java.lang.String jSessionId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getSamlSessionByJSessionId(jSessionId);
	}

	public static com.jio.portlet.saml.model.SamlSession getSamlSessionBySamlSpSessionKey(
		java.lang.String samlSpSessionKey)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getSamlSessionBySamlSpSessionKey(samlSpSessionKey);
	}

	public static com.jio.portlet.saml.model.SamlSession getSamlSessionBySessionIndex(
		java.lang.String sessionIndex)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getSamlSessionBySessionIndex(sessionIndex);
	}

	public static java.util.List<com.jio.portlet.saml.model.SamlSession> getSamlSessions(
		java.lang.String nameIdValue)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getSamlSessions(nameIdValue);
	}

	public static com.jio.portlet.saml.model.SamlSession updateSamlSession(
		long samlSessionId, java.lang.String jSessionId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().updateSamlSession(samlSessionId, jSessionId);
	}

	public static com.jio.portlet.saml.model.SamlSession updateSamlSession(
		long samlSpSessionId, java.lang.String samlSpSessionKey,
		java.lang.String assertionXml, java.lang.String jSessionId,
		java.lang.String nameIdFormat, java.lang.String nameIdNameQualifier,
		java.lang.String nameIdSPNameQualifier, java.lang.String nameIdValue,
		java.lang.String sessionIndex,
		com.liferay.portal.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .updateSamlSession(samlSpSessionId, samlSpSessionKey,
			assertionXml, jSessionId, nameIdFormat, nameIdNameQualifier,
			nameIdSPNameQualifier, nameIdValue, sessionIndex, serviceContext);
	}

	public static void clearService() {
		_service = null;
	}

	public static SamlSessionLocalService getService() {
		if (_service == null) {
			InvokableLocalService invokableLocalService = (InvokableLocalService)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
					SamlSessionLocalService.class.getName());

			if (invokableLocalService instanceof SamlSessionLocalService) {
				_service = (SamlSessionLocalService)invokableLocalService;
			}
			else {
				_service = new SamlSessionLocalServiceClp(invokableLocalService);
			}

			ReferenceRegistry.registerReference(SamlSessionLocalServiceUtil.class,
				"_service");
		}

		return _service;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setService(SamlSessionLocalService service) {
	}

	private static SamlSessionLocalService _service;
}