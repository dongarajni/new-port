/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.model;

import com.jio.portlet.saml.service.ClpSerializer;
import com.jio.portlet.saml.service.SamlMessageLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Ashish Jadhav
 */
public class SamlMessageClp extends BaseModelImpl<SamlMessage>
	implements SamlMessage {
	public SamlMessageClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return SamlMessage.class;
	}

	@Override
	public String getModelClassName() {
		return SamlMessage.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _samlMessageId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setSamlMessageId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _samlMessageId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("samlMessageId", getSamlMessageId());
		attributes.put("companyId", getCompanyId());
		attributes.put("createDate", getCreateDate());
		attributes.put("entityId", getEntityId());
		attributes.put("responseKey", getResponseKey());
		attributes.put("expirationDate", getExpirationDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long samlMessageId = (Long)attributes.get("samlMessageId");

		if (samlMessageId != null) {
			setSamlMessageId(samlMessageId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		String entityId = (String)attributes.get("entityId");

		if (entityId != null) {
			setEntityId(entityId);
		}

		String responseKey = (String)attributes.get("responseKey");

		if (responseKey != null) {
			setResponseKey(responseKey);
		}

		Date expirationDate = (Date)attributes.get("expirationDate");

		if (expirationDate != null) {
			setExpirationDate(expirationDate);
		}
	}

	@Override
	public long getSamlMessageId() {
		return _samlMessageId;
	}

	@Override
	public void setSamlMessageId(long samlMessageId) {
		_samlMessageId = samlMessageId;

		if (_samlMessageRemoteModel != null) {
			try {
				Class<?> clazz = _samlMessageRemoteModel.getClass();

				Method method = clazz.getMethod("setSamlMessageId", long.class);

				method.invoke(_samlMessageRemoteModel, samlMessageId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getCompanyId() {
		return _companyId;
	}

	@Override
	public void setCompanyId(long companyId) {
		_companyId = companyId;

		if (_samlMessageRemoteModel != null) {
			try {
				Class<?> clazz = _samlMessageRemoteModel.getClass();

				Method method = clazz.getMethod("setCompanyId", long.class);

				method.invoke(_samlMessageRemoteModel, companyId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getCreateDate() {
		return _createDate;
	}

	@Override
	public void setCreateDate(Date createDate) {
		_createDate = createDate;

		if (_samlMessageRemoteModel != null) {
			try {
				Class<?> clazz = _samlMessageRemoteModel.getClass();

				Method method = clazz.getMethod("setCreateDate", Date.class);

				method.invoke(_samlMessageRemoteModel, createDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEntityId() {
		return _entityId;
	}

	@Override
	public void setEntityId(String entityId) {
		_entityId = entityId;

		if (_samlMessageRemoteModel != null) {
			try {
				Class<?> clazz = _samlMessageRemoteModel.getClass();

				Method method = clazz.getMethod("setEntityId", String.class);

				method.invoke(_samlMessageRemoteModel, entityId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getResponseKey() {
		return _responseKey;
	}

	@Override
	public void setResponseKey(String responseKey) {
		_responseKey = responseKey;

		if (_samlMessageRemoteModel != null) {
			try {
				Class<?> clazz = _samlMessageRemoteModel.getClass();

				Method method = clazz.getMethod("setResponseKey", String.class);

				method.invoke(_samlMessageRemoteModel, responseKey);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getExpirationDate() {
		return _expirationDate;
	}

	@Override
	public void setExpirationDate(Date expirationDate) {
		_expirationDate = expirationDate;

		if (_samlMessageRemoteModel != null) {
			try {
				Class<?> clazz = _samlMessageRemoteModel.getClass();

				Method method = clazz.getMethod("setExpirationDate", Date.class);

				method.invoke(_samlMessageRemoteModel, expirationDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public boolean isExpired() {
		try {
			String methodName = "isExpired";

			Class<?>[] parameterTypes = new Class<?>[] {  };

			Object[] parameterValues = new Object[] {  };

			Boolean returnObj = (Boolean)invokeOnRemoteModel(methodName,
					parameterTypes, parameterValues);

			return returnObj;
		}
		catch (Exception e) {
			throw new UnsupportedOperationException(e);
		}
	}

	public BaseModel<?> getSamlMessageRemoteModel() {
		return _samlMessageRemoteModel;
	}

	public void setSamlMessageRemoteModel(BaseModel<?> samlMessageRemoteModel) {
		_samlMessageRemoteModel = samlMessageRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _samlMessageRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_samlMessageRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			SamlMessageLocalServiceUtil.addSamlMessage(this);
		}
		else {
			SamlMessageLocalServiceUtil.updateSamlMessage(this);
		}
	}

	@Override
	public SamlMessage toEscapedModel() {
		return (SamlMessage)ProxyUtil.newProxyInstance(SamlMessage.class.getClassLoader(),
			new Class[] { SamlMessage.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		SamlMessageClp clone = new SamlMessageClp();

		clone.setSamlMessageId(getSamlMessageId());
		clone.setCompanyId(getCompanyId());
		clone.setCreateDate(getCreateDate());
		clone.setEntityId(getEntityId());
		clone.setResponseKey(getResponseKey());
		clone.setExpirationDate(getExpirationDate());

		return clone;
	}

	@Override
	public int compareTo(SamlMessage samlMessage) {
		long primaryKey = samlMessage.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof SamlMessageClp)) {
			return false;
		}

		SamlMessageClp samlMessage = (SamlMessageClp)obj;

		long primaryKey = samlMessage.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{samlMessageId=");
		sb.append(getSamlMessageId());
		sb.append(", companyId=");
		sb.append(getCompanyId());
		sb.append(", createDate=");
		sb.append(getCreateDate());
		sb.append(", entityId=");
		sb.append(getEntityId());
		sb.append(", responseKey=");
		sb.append(getResponseKey());
		sb.append(", expirationDate=");
		sb.append(getExpirationDate());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(22);

		sb.append("<model><model-name>");
		sb.append("com.jio.portlet.saml.model.SamlMessage");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>samlMessageId</column-name><column-value><![CDATA[");
		sb.append(getSamlMessageId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>companyId</column-name><column-value><![CDATA[");
		sb.append(getCompanyId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>createDate</column-name><column-value><![CDATA[");
		sb.append(getCreateDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>entityId</column-name><column-value><![CDATA[");
		sb.append(getEntityId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>responseKey</column-name><column-value><![CDATA[");
		sb.append(getResponseKey());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>expirationDate</column-name><column-value><![CDATA[");
		sb.append(getExpirationDate());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _samlMessageId;
	private long _companyId;
	private Date _createDate;
	private String _entityId;
	private String _responseKey;
	private Date _expirationDate;
	private BaseModel<?> _samlMessageRemoteModel;
	private Class<?> _clpSerializerClass = com.jio.portlet.saml.service.ClpSerializer.class;
}