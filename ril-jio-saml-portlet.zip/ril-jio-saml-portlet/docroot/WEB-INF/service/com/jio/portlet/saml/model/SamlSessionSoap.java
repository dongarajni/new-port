/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author Ashish Jadhav
 * @generated
 */
public class SamlSessionSoap implements Serializable {
	public static SamlSessionSoap toSoapModel(SamlSession model) {
		SamlSessionSoap soapModel = new SamlSessionSoap();

		soapModel.setSessionId(model.getSessionId());
		soapModel.setSessionKey(model.getSessionKey());
		soapModel.setAssertionXml(model.getAssertionXml());
		soapModel.setJSessionId(model.getJSessionId());
		soapModel.setNameIdFormat(model.getNameIdFormat());
		soapModel.setNameIdNameQualifier(model.getNameIdNameQualifier());
		soapModel.setNameIdSPNameQualifier(model.getNameIdSPNameQualifier());
		soapModel.setNameIdValue(model.getNameIdValue());
		soapModel.setSessionIndex(model.getSessionIndex());
		soapModel.setTerminated(model.getTerminated());
		soapModel.setCompanyId(model.getCompanyId());
		soapModel.setUserId(model.getUserId());
		soapModel.setUserName(model.getUserName());
		soapModel.setCreateDate(model.getCreateDate());
		soapModel.setModifiedDate(model.getModifiedDate());

		return soapModel;
	}

	public static SamlSessionSoap[] toSoapModels(SamlSession[] models) {
		SamlSessionSoap[] soapModels = new SamlSessionSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static SamlSessionSoap[][] toSoapModels(SamlSession[][] models) {
		SamlSessionSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new SamlSessionSoap[models.length][models[0].length];
		}
		else {
			soapModels = new SamlSessionSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static SamlSessionSoap[] toSoapModels(List<SamlSession> models) {
		List<SamlSessionSoap> soapModels = new ArrayList<SamlSessionSoap>(models.size());

		for (SamlSession model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new SamlSessionSoap[soapModels.size()]);
	}

	public SamlSessionSoap() {
	}

	public long getPrimaryKey() {
		return _sessionId;
	}

	public void setPrimaryKey(long pk) {
		setSessionId(pk);
	}

	public long getSessionId() {
		return _sessionId;
	}

	public void setSessionId(long sessionId) {
		_sessionId = sessionId;
	}

	public String getSessionKey() {
		return _sessionKey;
	}

	public void setSessionKey(String sessionKey) {
		_sessionKey = sessionKey;
	}

	public String getAssertionXml() {
		return _assertionXml;
	}

	public void setAssertionXml(String assertionXml) {
		_assertionXml = assertionXml;
	}

	public String getJSessionId() {
		return _jSessionId;
	}

	public void setJSessionId(String jSessionId) {
		_jSessionId = jSessionId;
	}

	public String getNameIdFormat() {
		return _nameIdFormat;
	}

	public void setNameIdFormat(String nameIdFormat) {
		_nameIdFormat = nameIdFormat;
	}

	public String getNameIdNameQualifier() {
		return _nameIdNameQualifier;
	}

	public void setNameIdNameQualifier(String nameIdNameQualifier) {
		_nameIdNameQualifier = nameIdNameQualifier;
	}

	public String getNameIdSPNameQualifier() {
		return _nameIdSPNameQualifier;
	}

	public void setNameIdSPNameQualifier(String nameIdSPNameQualifier) {
		_nameIdSPNameQualifier = nameIdSPNameQualifier;
	}

	public String getNameIdValue() {
		return _nameIdValue;
	}

	public void setNameIdValue(String nameIdValue) {
		_nameIdValue = nameIdValue;
	}

	public String getSessionIndex() {
		return _sessionIndex;
	}

	public void setSessionIndex(String sessionIndex) {
		_sessionIndex = sessionIndex;
	}

	public boolean getTerminated() {
		return _terminated;
	}

	public boolean isTerminated() {
		return _terminated;
	}

	public void setTerminated(boolean terminated) {
		_terminated = terminated;
	}

	public long getCompanyId() {
		return _companyId;
	}

	public void setCompanyId(long companyId) {
		_companyId = companyId;
	}

	public long getUserId() {
		return _userId;
	}

	public void setUserId(long userId) {
		_userId = userId;
	}

	public String getUserName() {
		return _userName;
	}

	public void setUserName(String userName) {
		_userName = userName;
	}

	public Date getCreateDate() {
		return _createDate;
	}

	public void setCreateDate(Date createDate) {
		_createDate = createDate;
	}

	public Date getModifiedDate() {
		return _modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;
	}

	private long _sessionId;
	private String _sessionKey;
	private String _assertionXml;
	private String _jSessionId;
	private String _nameIdFormat;
	private String _nameIdNameQualifier;
	private String _nameIdSPNameQualifier;
	private String _nameIdValue;
	private String _sessionIndex;
	private boolean _terminated;
	private long _companyId;
	private long _userId;
	private String _userName;
	private Date _createDate;
	private Date _modifiedDate;
}