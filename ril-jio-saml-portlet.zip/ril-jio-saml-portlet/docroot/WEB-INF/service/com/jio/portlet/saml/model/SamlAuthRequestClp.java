/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.model;

import com.jio.portlet.saml.service.ClpSerializer;
import com.jio.portlet.saml.service.SamlAuthRequestLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Ashish Jadhav
 */
public class SamlAuthRequestClp extends BaseModelImpl<SamlAuthRequest>
	implements SamlAuthRequest {
	public SamlAuthRequestClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return SamlAuthRequest.class;
	}

	@Override
	public String getModelClassName() {
		return SamlAuthRequest.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _samlAuthnRequestId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setSamlAuthnRequestId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _samlAuthnRequestId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("samlAuthnRequestId", getSamlAuthnRequestId());
		attributes.put("companyId", getCompanyId());
		attributes.put("createDate", getCreateDate());
		attributes.put("entityId", getEntityId());
		attributes.put("authRequestKey", getAuthRequestKey());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long samlAuthnRequestId = (Long)attributes.get("samlAuthnRequestId");

		if (samlAuthnRequestId != null) {
			setSamlAuthnRequestId(samlAuthnRequestId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		String entityId = (String)attributes.get("entityId");

		if (entityId != null) {
			setEntityId(entityId);
		}

		String authRequestKey = (String)attributes.get("authRequestKey");

		if (authRequestKey != null) {
			setAuthRequestKey(authRequestKey);
		}
	}

	@Override
	public long getSamlAuthnRequestId() {
		return _samlAuthnRequestId;
	}

	@Override
	public void setSamlAuthnRequestId(long samlAuthnRequestId) {
		_samlAuthnRequestId = samlAuthnRequestId;

		if (_samlAuthRequestRemoteModel != null) {
			try {
				Class<?> clazz = _samlAuthRequestRemoteModel.getClass();

				Method method = clazz.getMethod("setSamlAuthnRequestId",
						long.class);

				method.invoke(_samlAuthRequestRemoteModel, samlAuthnRequestId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getCompanyId() {
		return _companyId;
	}

	@Override
	public void setCompanyId(long companyId) {
		_companyId = companyId;

		if (_samlAuthRequestRemoteModel != null) {
			try {
				Class<?> clazz = _samlAuthRequestRemoteModel.getClass();

				Method method = clazz.getMethod("setCompanyId", long.class);

				method.invoke(_samlAuthRequestRemoteModel, companyId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getCreateDate() {
		return _createDate;
	}

	@Override
	public void setCreateDate(Date createDate) {
		_createDate = createDate;

		if (_samlAuthRequestRemoteModel != null) {
			try {
				Class<?> clazz = _samlAuthRequestRemoteModel.getClass();

				Method method = clazz.getMethod("setCreateDate", Date.class);

				method.invoke(_samlAuthRequestRemoteModel, createDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEntityId() {
		return _entityId;
	}

	@Override
	public void setEntityId(String entityId) {
		_entityId = entityId;

		if (_samlAuthRequestRemoteModel != null) {
			try {
				Class<?> clazz = _samlAuthRequestRemoteModel.getClass();

				Method method = clazz.getMethod("setEntityId", String.class);

				method.invoke(_samlAuthRequestRemoteModel, entityId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAuthRequestKey() {
		return _authRequestKey;
	}

	@Override
	public void setAuthRequestKey(String authRequestKey) {
		_authRequestKey = authRequestKey;

		if (_samlAuthRequestRemoteModel != null) {
			try {
				Class<?> clazz = _samlAuthRequestRemoteModel.getClass();

				Method method = clazz.getMethod("setAuthRequestKey",
						String.class);

				method.invoke(_samlAuthRequestRemoteModel, authRequestKey);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getSamlAuthRequestRemoteModel() {
		return _samlAuthRequestRemoteModel;
	}

	public void setSamlAuthRequestRemoteModel(
		BaseModel<?> samlAuthRequestRemoteModel) {
		_samlAuthRequestRemoteModel = samlAuthRequestRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _samlAuthRequestRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_samlAuthRequestRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			SamlAuthRequestLocalServiceUtil.addSamlAuthRequest(this);
		}
		else {
			SamlAuthRequestLocalServiceUtil.updateSamlAuthRequest(this);
		}
	}

	@Override
	public SamlAuthRequest toEscapedModel() {
		return (SamlAuthRequest)ProxyUtil.newProxyInstance(SamlAuthRequest.class.getClassLoader(),
			new Class[] { SamlAuthRequest.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		SamlAuthRequestClp clone = new SamlAuthRequestClp();

		clone.setSamlAuthnRequestId(getSamlAuthnRequestId());
		clone.setCompanyId(getCompanyId());
		clone.setCreateDate(getCreateDate());
		clone.setEntityId(getEntityId());
		clone.setAuthRequestKey(getAuthRequestKey());

		return clone;
	}

	@Override
	public int compareTo(SamlAuthRequest samlAuthRequest) {
		long primaryKey = samlAuthRequest.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof SamlAuthRequestClp)) {
			return false;
		}

		SamlAuthRequestClp samlAuthRequest = (SamlAuthRequestClp)obj;

		long primaryKey = samlAuthRequest.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{samlAuthnRequestId=");
		sb.append(getSamlAuthnRequestId());
		sb.append(", companyId=");
		sb.append(getCompanyId());
		sb.append(", createDate=");
		sb.append(getCreateDate());
		sb.append(", entityId=");
		sb.append(getEntityId());
		sb.append(", authRequestKey=");
		sb.append(getAuthRequestKey());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(19);

		sb.append("<model><model-name>");
		sb.append("com.jio.portlet.saml.model.SamlAuthRequest");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>samlAuthnRequestId</column-name><column-value><![CDATA[");
		sb.append(getSamlAuthnRequestId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>companyId</column-name><column-value><![CDATA[");
		sb.append(getCompanyId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>createDate</column-name><column-value><![CDATA[");
		sb.append(getCreateDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>entityId</column-name><column-value><![CDATA[");
		sb.append(getEntityId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>authRequestKey</column-name><column-value><![CDATA[");
		sb.append(getAuthRequestKey());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _samlAuthnRequestId;
	private long _companyId;
	private Date _createDate;
	private String _entityId;
	private String _authRequestKey;
	private BaseModel<?> _samlAuthRequestRemoteModel;
	private Class<?> _clpSerializerClass = com.jio.portlet.saml.service.ClpSerializer.class;
}