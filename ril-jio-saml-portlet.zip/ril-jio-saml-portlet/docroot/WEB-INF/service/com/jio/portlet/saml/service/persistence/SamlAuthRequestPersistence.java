/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.service.persistence;

import com.jio.portlet.saml.model.SamlAuthRequest;

import com.liferay.portal.service.persistence.BasePersistence;

/**
 * The persistence interface for the saml auth request service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Ashish Jadhav
 * @see SamlAuthRequestPersistenceImpl
 * @see SamlAuthRequestUtil
 * @generated
 */
public interface SamlAuthRequestPersistence extends BasePersistence<SamlAuthRequest> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link SamlAuthRequestUtil} to access the saml auth request persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns the saml auth request where entityId = &#63; and authRequestKey = &#63; or throws a {@link com.jio.portlet.saml.NoSuchSamlAuthRequestException} if it could not be found.
	*
	* @param entityId the entity ID
	* @param authRequestKey the auth request key
	* @return the matching saml auth request
	* @throws com.jio.portlet.saml.NoSuchSamlAuthRequestException if a matching saml auth request could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jio.portlet.saml.model.SamlAuthRequest findByEntityId_AuthReqKey(
		java.lang.String entityId, java.lang.String authRequestKey)
		throws com.jio.portlet.saml.NoSuchSamlAuthRequestException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the saml auth request where entityId = &#63; and authRequestKey = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param entityId the entity ID
	* @param authRequestKey the auth request key
	* @return the matching saml auth request, or <code>null</code> if a matching saml auth request could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jio.portlet.saml.model.SamlAuthRequest fetchByEntityId_AuthReqKey(
		java.lang.String entityId, java.lang.String authRequestKey)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the saml auth request where entityId = &#63; and authRequestKey = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param entityId the entity ID
	* @param authRequestKey the auth request key
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching saml auth request, or <code>null</code> if a matching saml auth request could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jio.portlet.saml.model.SamlAuthRequest fetchByEntityId_AuthReqKey(
		java.lang.String entityId, java.lang.String authRequestKey,
		boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the saml auth request where entityId = &#63; and authRequestKey = &#63; from the database.
	*
	* @param entityId the entity ID
	* @param authRequestKey the auth request key
	* @return the saml auth request that was removed
	* @throws SystemException if a system exception occurred
	*/
	public com.jio.portlet.saml.model.SamlAuthRequest removeByEntityId_AuthReqKey(
		java.lang.String entityId, java.lang.String authRequestKey)
		throws com.jio.portlet.saml.NoSuchSamlAuthRequestException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of saml auth requests where entityId = &#63; and authRequestKey = &#63;.
	*
	* @param entityId the entity ID
	* @param authRequestKey the auth request key
	* @return the number of matching saml auth requests
	* @throws SystemException if a system exception occurred
	*/
	public int countByEntityId_AuthReqKey(java.lang.String entityId,
		java.lang.String authRequestKey)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the saml auth request in the entity cache if it is enabled.
	*
	* @param samlAuthRequest the saml auth request
	*/
	public void cacheResult(
		com.jio.portlet.saml.model.SamlAuthRequest samlAuthRequest);

	/**
	* Caches the saml auth requests in the entity cache if it is enabled.
	*
	* @param samlAuthRequests the saml auth requests
	*/
	public void cacheResult(
		java.util.List<com.jio.portlet.saml.model.SamlAuthRequest> samlAuthRequests);

	/**
	* Creates a new saml auth request with the primary key. Does not add the saml auth request to the database.
	*
	* @param samlAuthnRequestId the primary key for the new saml auth request
	* @return the new saml auth request
	*/
	public com.jio.portlet.saml.model.SamlAuthRequest create(
		long samlAuthnRequestId);

	/**
	* Removes the saml auth request with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param samlAuthnRequestId the primary key of the saml auth request
	* @return the saml auth request that was removed
	* @throws com.jio.portlet.saml.NoSuchSamlAuthRequestException if a saml auth request with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jio.portlet.saml.model.SamlAuthRequest remove(
		long samlAuthnRequestId)
		throws com.jio.portlet.saml.NoSuchSamlAuthRequestException,
			com.liferay.portal.kernel.exception.SystemException;

	public com.jio.portlet.saml.model.SamlAuthRequest updateImpl(
		com.jio.portlet.saml.model.SamlAuthRequest samlAuthRequest)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the saml auth request with the primary key or throws a {@link com.jio.portlet.saml.NoSuchSamlAuthRequestException} if it could not be found.
	*
	* @param samlAuthnRequestId the primary key of the saml auth request
	* @return the saml auth request
	* @throws com.jio.portlet.saml.NoSuchSamlAuthRequestException if a saml auth request with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jio.portlet.saml.model.SamlAuthRequest findByPrimaryKey(
		long samlAuthnRequestId)
		throws com.jio.portlet.saml.NoSuchSamlAuthRequestException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the saml auth request with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param samlAuthnRequestId the primary key of the saml auth request
	* @return the saml auth request, or <code>null</code> if a saml auth request with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jio.portlet.saml.model.SamlAuthRequest fetchByPrimaryKey(
		long samlAuthnRequestId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the saml auth requests.
	*
	* @return the saml auth requests
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jio.portlet.saml.model.SamlAuthRequest> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the saml auth requests.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlAuthRequestModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of saml auth requests
	* @param end the upper bound of the range of saml auth requests (not inclusive)
	* @return the range of saml auth requests
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jio.portlet.saml.model.SamlAuthRequest> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the saml auth requests.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlAuthRequestModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of saml auth requests
	* @param end the upper bound of the range of saml auth requests (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of saml auth requests
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jio.portlet.saml.model.SamlAuthRequest> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the saml auth requests from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of saml auth requests.
	*
	* @return the number of saml auth requests
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}