/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author Ashish Jadhav
 * @generated
 */
public class SamlIdpConnectionSoap implements Serializable {
	public static SamlIdpConnectionSoap toSoapModel(SamlIdpConnection model) {
		SamlIdpConnectionSoap soapModel = new SamlIdpConnectionSoap();

		soapModel.setSamlIdpConnectionId(model.getSamlIdpConnectionId());
		soapModel.setCompanyId(model.getCompanyId());
		soapModel.setUserId(model.getUserId());
		soapModel.setUserName(model.getUserName());
		soapModel.setCreateDate(model.getCreateDate());
		soapModel.setModifiedDate(model.getModifiedDate());
		soapModel.setSamlIdpEntityId(model.getSamlIdpEntityId());
		soapModel.setAssertionSignatureRequired(model.getAssertionSignatureRequired());
		soapModel.setClockSkew(model.getClockSkew());
		soapModel.setEnabled(model.getEnabled());
		soapModel.setForceAuthn(model.getForceAuthn());
		soapModel.setLdapImportEnabled(model.getLdapImportEnabled());
		soapModel.setMetadataUrl(model.getMetadataUrl());
		soapModel.setMetadataXml(model.getMetadataXml());
		soapModel.setMetadataUpdatedDate(model.getMetadataUpdatedDate());
		soapModel.setName(model.getName());
		soapModel.setNameIdFormat(model.getNameIdFormat());
		soapModel.setSignAuthnRequest(model.getSignAuthnRequest());
		soapModel.setUserAttributeMappings(model.getUserAttributeMappings());

		return soapModel;
	}

	public static SamlIdpConnectionSoap[] toSoapModels(
		SamlIdpConnection[] models) {
		SamlIdpConnectionSoap[] soapModels = new SamlIdpConnectionSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static SamlIdpConnectionSoap[][] toSoapModels(
		SamlIdpConnection[][] models) {
		SamlIdpConnectionSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new SamlIdpConnectionSoap[models.length][models[0].length];
		}
		else {
			soapModels = new SamlIdpConnectionSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static SamlIdpConnectionSoap[] toSoapModels(
		List<SamlIdpConnection> models) {
		List<SamlIdpConnectionSoap> soapModels = new ArrayList<SamlIdpConnectionSoap>(models.size());

		for (SamlIdpConnection model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new SamlIdpConnectionSoap[soapModels.size()]);
	}

	public SamlIdpConnectionSoap() {
	}

	public long getPrimaryKey() {
		return _samlIdpConnectionId;
	}

	public void setPrimaryKey(long pk) {
		setSamlIdpConnectionId(pk);
	}

	public long getSamlIdpConnectionId() {
		return _samlIdpConnectionId;
	}

	public void setSamlIdpConnectionId(long samlIdpConnectionId) {
		_samlIdpConnectionId = samlIdpConnectionId;
	}

	public long getCompanyId() {
		return _companyId;
	}

	public void setCompanyId(long companyId) {
		_companyId = companyId;
	}

	public long getUserId() {
		return _userId;
	}

	public void setUserId(long userId) {
		_userId = userId;
	}

	public String getUserName() {
		return _userName;
	}

	public void setUserName(String userName) {
		_userName = userName;
	}

	public Date getCreateDate() {
		return _createDate;
	}

	public void setCreateDate(Date createDate) {
		_createDate = createDate;
	}

	public Date getModifiedDate() {
		return _modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;
	}

	public String getSamlIdpEntityId() {
		return _samlIdpEntityId;
	}

	public void setSamlIdpEntityId(String samlIdpEntityId) {
		_samlIdpEntityId = samlIdpEntityId;
	}

	public boolean getAssertionSignatureRequired() {
		return _assertionSignatureRequired;
	}

	public boolean isAssertionSignatureRequired() {
		return _assertionSignatureRequired;
	}

	public void setAssertionSignatureRequired(
		boolean assertionSignatureRequired) {
		_assertionSignatureRequired = assertionSignatureRequired;
	}

	public long getClockSkew() {
		return _clockSkew;
	}

	public void setClockSkew(long clockSkew) {
		_clockSkew = clockSkew;
	}

	public boolean getEnabled() {
		return _enabled;
	}

	public boolean isEnabled() {
		return _enabled;
	}

	public void setEnabled(boolean enabled) {
		_enabled = enabled;
	}

	public boolean getForceAuthn() {
		return _forceAuthn;
	}

	public boolean isForceAuthn() {
		return _forceAuthn;
	}

	public void setForceAuthn(boolean forceAuthn) {
		_forceAuthn = forceAuthn;
	}

	public boolean getLdapImportEnabled() {
		return _ldapImportEnabled;
	}

	public boolean isLdapImportEnabled() {
		return _ldapImportEnabled;
	}

	public void setLdapImportEnabled(boolean ldapImportEnabled) {
		_ldapImportEnabled = ldapImportEnabled;
	}

	public String getMetadataUrl() {
		return _metadataUrl;
	}

	public void setMetadataUrl(String metadataUrl) {
		_metadataUrl = metadataUrl;
	}

	public String getMetadataXml() {
		return _metadataXml;
	}

	public void setMetadataXml(String metadataXml) {
		_metadataXml = metadataXml;
	}

	public Date getMetadataUpdatedDate() {
		return _metadataUpdatedDate;
	}

	public void setMetadataUpdatedDate(Date metadataUpdatedDate) {
		_metadataUpdatedDate = metadataUpdatedDate;
	}

	public String getName() {
		return _name;
	}

	public void setName(String name) {
		_name = name;
	}

	public String getNameIdFormat() {
		return _nameIdFormat;
	}

	public void setNameIdFormat(String nameIdFormat) {
		_nameIdFormat = nameIdFormat;
	}

	public boolean getSignAuthnRequest() {
		return _signAuthnRequest;
	}

	public boolean isSignAuthnRequest() {
		return _signAuthnRequest;
	}

	public void setSignAuthnRequest(boolean signAuthnRequest) {
		_signAuthnRequest = signAuthnRequest;
	}

	public String getUserAttributeMappings() {
		return _userAttributeMappings;
	}

	public void setUserAttributeMappings(String userAttributeMappings) {
		_userAttributeMappings = userAttributeMappings;
	}

	private long _samlIdpConnectionId;
	private long _companyId;
	private long _userId;
	private String _userName;
	private Date _createDate;
	private Date _modifiedDate;
	private String _samlIdpEntityId;
	private boolean _assertionSignatureRequired;
	private long _clockSkew;
	private boolean _enabled;
	private boolean _forceAuthn;
	private boolean _ldapImportEnabled;
	private String _metadataUrl;
	private String _metadataXml;
	private Date _metadataUpdatedDate;
	private String _name;
	private String _nameIdFormat;
	private boolean _signAuthnRequest;
	private String _userAttributeMappings;
}