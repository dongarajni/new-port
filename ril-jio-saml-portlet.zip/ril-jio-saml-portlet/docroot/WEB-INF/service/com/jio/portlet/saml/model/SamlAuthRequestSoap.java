/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author Ashish Jadhav
 * @generated
 */
public class SamlAuthRequestSoap implements Serializable {
	public static SamlAuthRequestSoap toSoapModel(SamlAuthRequest model) {
		SamlAuthRequestSoap soapModel = new SamlAuthRequestSoap();

		soapModel.setSamlAuthnRequestId(model.getSamlAuthnRequestId());
		soapModel.setCompanyId(model.getCompanyId());
		soapModel.setCreateDate(model.getCreateDate());
		soapModel.setEntityId(model.getEntityId());
		soapModel.setAuthRequestKey(model.getAuthRequestKey());

		return soapModel;
	}

	public static SamlAuthRequestSoap[] toSoapModels(SamlAuthRequest[] models) {
		SamlAuthRequestSoap[] soapModels = new SamlAuthRequestSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static SamlAuthRequestSoap[][] toSoapModels(
		SamlAuthRequest[][] models) {
		SamlAuthRequestSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new SamlAuthRequestSoap[models.length][models[0].length];
		}
		else {
			soapModels = new SamlAuthRequestSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static SamlAuthRequestSoap[] toSoapModels(
		List<SamlAuthRequest> models) {
		List<SamlAuthRequestSoap> soapModels = new ArrayList<SamlAuthRequestSoap>(models.size());

		for (SamlAuthRequest model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new SamlAuthRequestSoap[soapModels.size()]);
	}

	public SamlAuthRequestSoap() {
	}

	public long getPrimaryKey() {
		return _samlAuthnRequestId;
	}

	public void setPrimaryKey(long pk) {
		setSamlAuthnRequestId(pk);
	}

	public long getSamlAuthnRequestId() {
		return _samlAuthnRequestId;
	}

	public void setSamlAuthnRequestId(long samlAuthnRequestId) {
		_samlAuthnRequestId = samlAuthnRequestId;
	}

	public long getCompanyId() {
		return _companyId;
	}

	public void setCompanyId(long companyId) {
		_companyId = companyId;
	}

	public Date getCreateDate() {
		return _createDate;
	}

	public void setCreateDate(Date createDate) {
		_createDate = createDate;
	}

	public String getEntityId() {
		return _entityId;
	}

	public void setEntityId(String entityId) {
		_entityId = entityId;
	}

	public String getAuthRequestKey() {
		return _authRequestKey;
	}

	public void setAuthRequestKey(String authRequestKey) {
		_authRequestKey = authRequestKey;
	}

	private long _samlAuthnRequestId;
	private long _companyId;
	private Date _createDate;
	private String _entityId;
	private String _authRequestKey;
}