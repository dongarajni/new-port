/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.service.persistence;

import com.jio.portlet.saml.model.SamlSession;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import java.util.List;

/**
 * The persistence utility for the saml session service. This utility wraps {@link SamlSessionPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Ashish Jadhav
 * @see SamlSessionPersistence
 * @see SamlSessionPersistenceImpl
 * @generated
 */
public class SamlSessionUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(SamlSession samlSession) {
		getPersistence().clearCache(samlSession);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<SamlSession> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<SamlSession> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<SamlSession> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static SamlSession update(SamlSession samlSession)
		throws SystemException {
		return getPersistence().update(samlSession);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static SamlSession update(SamlSession samlSession,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(samlSession, serviceContext);
	}

	/**
	* Returns the saml session where sessionKey = &#63; or throws a {@link com.jio.portlet.saml.NoSuchSamlSessionException} if it could not be found.
	*
	* @param sessionKey the session key
	* @return the matching saml session
	* @throws com.jio.portlet.saml.NoSuchSamlSessionException if a matching saml session could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession findBySessionKey(
		java.lang.String sessionKey)
		throws com.jio.portlet.saml.NoSuchSamlSessionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBySessionKey(sessionKey);
	}

	/**
	* Returns the saml session where sessionKey = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param sessionKey the session key
	* @return the matching saml session, or <code>null</code> if a matching saml session could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession fetchBySessionKey(
		java.lang.String sessionKey)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBySessionKey(sessionKey);
	}

	/**
	* Returns the saml session where sessionKey = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param sessionKey the session key
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching saml session, or <code>null</code> if a matching saml session could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession fetchBySessionKey(
		java.lang.String sessionKey, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBySessionKey(sessionKey, retrieveFromCache);
	}

	/**
	* Removes the saml session where sessionKey = &#63; from the database.
	*
	* @param sessionKey the session key
	* @return the saml session that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession removeBySessionKey(
		java.lang.String sessionKey)
		throws com.jio.portlet.saml.NoSuchSamlSessionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().removeBySessionKey(sessionKey);
	}

	/**
	* Returns the number of saml sessions where sessionKey = &#63;.
	*
	* @param sessionKey the session key
	* @return the number of matching saml sessions
	* @throws SystemException if a system exception occurred
	*/
	public static int countBySessionKey(java.lang.String sessionKey)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBySessionKey(sessionKey);
	}

	/**
	* Returns the saml session where jSessionId = &#63; or throws a {@link com.jio.portlet.saml.NoSuchSamlSessionException} if it could not be found.
	*
	* @param jSessionId the j session ID
	* @return the matching saml session
	* @throws com.jio.portlet.saml.NoSuchSamlSessionException if a matching saml session could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession findByJSessionId(
		java.lang.String jSessionId)
		throws com.jio.portlet.saml.NoSuchSamlSessionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByJSessionId(jSessionId);
	}

	/**
	* Returns the saml session where jSessionId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param jSessionId the j session ID
	* @return the matching saml session, or <code>null</code> if a matching saml session could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession fetchByJSessionId(
		java.lang.String jSessionId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByJSessionId(jSessionId);
	}

	/**
	* Returns the saml session where jSessionId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param jSessionId the j session ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching saml session, or <code>null</code> if a matching saml session could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession fetchByJSessionId(
		java.lang.String jSessionId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByJSessionId(jSessionId, retrieveFromCache);
	}

	/**
	* Removes the saml session where jSessionId = &#63; from the database.
	*
	* @param jSessionId the j session ID
	* @return the saml session that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession removeByJSessionId(
		java.lang.String jSessionId)
		throws com.jio.portlet.saml.NoSuchSamlSessionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().removeByJSessionId(jSessionId);
	}

	/**
	* Returns the number of saml sessions where jSessionId = &#63;.
	*
	* @param jSessionId the j session ID
	* @return the number of matching saml sessions
	* @throws SystemException if a system exception occurred
	*/
	public static int countByJSessionId(java.lang.String jSessionId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByJSessionId(jSessionId);
	}

	/**
	* Returns all the saml sessions where nameIdValue = &#63;.
	*
	* @param nameIdValue the name ID value
	* @return the matching saml sessions
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.portlet.saml.model.SamlSession> findByNameIdValue(
		java.lang.String nameIdValue)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByNameIdValue(nameIdValue);
	}

	/**
	* Returns a range of all the saml sessions where nameIdValue = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlSessionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param nameIdValue the name ID value
	* @param start the lower bound of the range of saml sessions
	* @param end the upper bound of the range of saml sessions (not inclusive)
	* @return the range of matching saml sessions
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.portlet.saml.model.SamlSession> findByNameIdValue(
		java.lang.String nameIdValue, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByNameIdValue(nameIdValue, start, end);
	}

	/**
	* Returns an ordered range of all the saml sessions where nameIdValue = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlSessionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param nameIdValue the name ID value
	* @param start the lower bound of the range of saml sessions
	* @param end the upper bound of the range of saml sessions (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching saml sessions
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.portlet.saml.model.SamlSession> findByNameIdValue(
		java.lang.String nameIdValue, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByNameIdValue(nameIdValue, start, end, orderByComparator);
	}

	/**
	* Returns the first saml session in the ordered set where nameIdValue = &#63;.
	*
	* @param nameIdValue the name ID value
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching saml session
	* @throws com.jio.portlet.saml.NoSuchSamlSessionException if a matching saml session could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession findByNameIdValue_First(
		java.lang.String nameIdValue,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jio.portlet.saml.NoSuchSamlSessionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByNameIdValue_First(nameIdValue, orderByComparator);
	}

	/**
	* Returns the first saml session in the ordered set where nameIdValue = &#63;.
	*
	* @param nameIdValue the name ID value
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching saml session, or <code>null</code> if a matching saml session could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession fetchByNameIdValue_First(
		java.lang.String nameIdValue,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByNameIdValue_First(nameIdValue, orderByComparator);
	}

	/**
	* Returns the last saml session in the ordered set where nameIdValue = &#63;.
	*
	* @param nameIdValue the name ID value
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching saml session
	* @throws com.jio.portlet.saml.NoSuchSamlSessionException if a matching saml session could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession findByNameIdValue_Last(
		java.lang.String nameIdValue,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jio.portlet.saml.NoSuchSamlSessionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByNameIdValue_Last(nameIdValue, orderByComparator);
	}

	/**
	* Returns the last saml session in the ordered set where nameIdValue = &#63;.
	*
	* @param nameIdValue the name ID value
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching saml session, or <code>null</code> if a matching saml session could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession fetchByNameIdValue_Last(
		java.lang.String nameIdValue,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByNameIdValue_Last(nameIdValue, orderByComparator);
	}

	/**
	* Returns the saml sessions before and after the current saml session in the ordered set where nameIdValue = &#63;.
	*
	* @param sessionId the primary key of the current saml session
	* @param nameIdValue the name ID value
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next saml session
	* @throws com.jio.portlet.saml.NoSuchSamlSessionException if a saml session with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession[] findByNameIdValue_PrevAndNext(
		long sessionId, java.lang.String nameIdValue,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jio.portlet.saml.NoSuchSamlSessionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByNameIdValue_PrevAndNext(sessionId, nameIdValue,
			orderByComparator);
	}

	/**
	* Removes all the saml sessions where nameIdValue = &#63; from the database.
	*
	* @param nameIdValue the name ID value
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByNameIdValue(java.lang.String nameIdValue)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByNameIdValue(nameIdValue);
	}

	/**
	* Returns the number of saml sessions where nameIdValue = &#63;.
	*
	* @param nameIdValue the name ID value
	* @return the number of matching saml sessions
	* @throws SystemException if a system exception occurred
	*/
	public static int countByNameIdValue(java.lang.String nameIdValue)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByNameIdValue(nameIdValue);
	}

	/**
	* Returns the saml session where sessionIndex = &#63; or throws a {@link com.jio.portlet.saml.NoSuchSamlSessionException} if it could not be found.
	*
	* @param sessionIndex the session index
	* @return the matching saml session
	* @throws com.jio.portlet.saml.NoSuchSamlSessionException if a matching saml session could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession findBySessionIndex(
		java.lang.String sessionIndex)
		throws com.jio.portlet.saml.NoSuchSamlSessionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBySessionIndex(sessionIndex);
	}

	/**
	* Returns the saml session where sessionIndex = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param sessionIndex the session index
	* @return the matching saml session, or <code>null</code> if a matching saml session could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession fetchBySessionIndex(
		java.lang.String sessionIndex)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBySessionIndex(sessionIndex);
	}

	/**
	* Returns the saml session where sessionIndex = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param sessionIndex the session index
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching saml session, or <code>null</code> if a matching saml session could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession fetchBySessionIndex(
		java.lang.String sessionIndex, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBySessionIndex(sessionIndex, retrieveFromCache);
	}

	/**
	* Removes the saml session where sessionIndex = &#63; from the database.
	*
	* @param sessionIndex the session index
	* @return the saml session that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession removeBySessionIndex(
		java.lang.String sessionIndex)
		throws com.jio.portlet.saml.NoSuchSamlSessionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().removeBySessionIndex(sessionIndex);
	}

	/**
	* Returns the number of saml sessions where sessionIndex = &#63;.
	*
	* @param sessionIndex the session index
	* @return the number of matching saml sessions
	* @throws SystemException if a system exception occurred
	*/
	public static int countBySessionIndex(java.lang.String sessionIndex)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBySessionIndex(sessionIndex);
	}

	/**
	* Caches the saml session in the entity cache if it is enabled.
	*
	* @param samlSession the saml session
	*/
	public static void cacheResult(
		com.jio.portlet.saml.model.SamlSession samlSession) {
		getPersistence().cacheResult(samlSession);
	}

	/**
	* Caches the saml sessions in the entity cache if it is enabled.
	*
	* @param samlSessions the saml sessions
	*/
	public static void cacheResult(
		java.util.List<com.jio.portlet.saml.model.SamlSession> samlSessions) {
		getPersistence().cacheResult(samlSessions);
	}

	/**
	* Creates a new saml session with the primary key. Does not add the saml session to the database.
	*
	* @param sessionId the primary key for the new saml session
	* @return the new saml session
	*/
	public static com.jio.portlet.saml.model.SamlSession create(long sessionId) {
		return getPersistence().create(sessionId);
	}

	/**
	* Removes the saml session with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param sessionId the primary key of the saml session
	* @return the saml session that was removed
	* @throws com.jio.portlet.saml.NoSuchSamlSessionException if a saml session with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession remove(long sessionId)
		throws com.jio.portlet.saml.NoSuchSamlSessionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().remove(sessionId);
	}

	public static com.jio.portlet.saml.model.SamlSession updateImpl(
		com.jio.portlet.saml.model.SamlSession samlSession)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(samlSession);
	}

	/**
	* Returns the saml session with the primary key or throws a {@link com.jio.portlet.saml.NoSuchSamlSessionException} if it could not be found.
	*
	* @param sessionId the primary key of the saml session
	* @return the saml session
	* @throws com.jio.portlet.saml.NoSuchSamlSessionException if a saml session with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession findByPrimaryKey(
		long sessionId)
		throws com.jio.portlet.saml.NoSuchSamlSessionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPrimaryKey(sessionId);
	}

	/**
	* Returns the saml session with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param sessionId the primary key of the saml session
	* @return the saml session, or <code>null</code> if a saml session with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.portlet.saml.model.SamlSession fetchByPrimaryKey(
		long sessionId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(sessionId);
	}

	/**
	* Returns all the saml sessions.
	*
	* @return the saml sessions
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.portlet.saml.model.SamlSession> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the saml sessions.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlSessionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of saml sessions
	* @param end the upper bound of the range of saml sessions (not inclusive)
	* @return the range of saml sessions
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.portlet.saml.model.SamlSession> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the saml sessions.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlSessionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of saml sessions
	* @param end the upper bound of the range of saml sessions (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of saml sessions
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.portlet.saml.model.SamlSession> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the saml sessions from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of saml sessions.
	*
	* @return the number of saml sessions
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static SamlSessionPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (SamlSessionPersistence)PortletBeanLocatorUtil.locate(com.jio.portlet.saml.service.ClpSerializer.getServletContextName(),
					SamlSessionPersistence.class.getName());

			ReferenceRegistry.registerReference(SamlSessionUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(SamlSessionPersistence persistence) {
	}

	private static SamlSessionPersistence _persistence;
}