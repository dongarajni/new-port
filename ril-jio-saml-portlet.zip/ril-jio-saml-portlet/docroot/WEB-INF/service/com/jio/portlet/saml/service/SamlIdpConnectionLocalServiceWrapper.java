/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link SamlIdpConnectionLocalService}.
 *
 * @author Ashish Jadhav
 * @see SamlIdpConnectionLocalService
 * @generated
 */
public class SamlIdpConnectionLocalServiceWrapper
	implements SamlIdpConnectionLocalService,
		ServiceWrapper<SamlIdpConnectionLocalService> {
	public SamlIdpConnectionLocalServiceWrapper(
		SamlIdpConnectionLocalService samlIdpConnectionLocalService) {
		_samlIdpConnectionLocalService = samlIdpConnectionLocalService;
	}

	/**
	* Adds the saml idp connection to the database. Also notifies the appropriate model listeners.
	*
	* @param samlIdpConnection the saml idp connection
	* @return the saml idp connection that was added
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.jio.portlet.saml.model.SamlIdpConnection addSamlIdpConnection(
		com.jio.portlet.saml.model.SamlIdpConnection samlIdpConnection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.addSamlIdpConnection(samlIdpConnection);
	}

	/**
	* Creates a new saml idp connection with the primary key. Does not add the saml idp connection to the database.
	*
	* @param samlIdpConnectionId the primary key for the new saml idp connection
	* @return the new saml idp connection
	*/
	@Override
	public com.jio.portlet.saml.model.SamlIdpConnection createSamlIdpConnection(
		long samlIdpConnectionId) {
		return _samlIdpConnectionLocalService.createSamlIdpConnection(samlIdpConnectionId);
	}

	/**
	* Deletes the saml idp connection with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param samlIdpConnectionId the primary key of the saml idp connection
	* @return the saml idp connection that was removed
	* @throws PortalException if a saml idp connection with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.jio.portlet.saml.model.SamlIdpConnection deleteSamlIdpConnection(
		long samlIdpConnectionId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.deleteSamlIdpConnection(samlIdpConnectionId);
	}

	/**
	* Deletes the saml idp connection from the database. Also notifies the appropriate model listeners.
	*
	* @param samlIdpConnection the saml idp connection
	* @return the saml idp connection that was removed
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.jio.portlet.saml.model.SamlIdpConnection deleteSamlIdpConnection(
		com.jio.portlet.saml.model.SamlIdpConnection samlIdpConnection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.deleteSamlIdpConnection(samlIdpConnection);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _samlIdpConnectionLocalService.dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlIdpConnectionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.dynamicQuery(dynamicQuery, start,
			end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlIdpConnectionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.dynamicQuery(dynamicQuery, start,
			end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.dynamicQueryCount(dynamicQuery,
			projection);
	}

	@Override
	public com.jio.portlet.saml.model.SamlIdpConnection fetchSamlIdpConnection(
		long samlIdpConnectionId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.fetchSamlIdpConnection(samlIdpConnectionId);
	}

	/**
	* Returns the saml idp connection with the primary key.
	*
	* @param samlIdpConnectionId the primary key of the saml idp connection
	* @return the saml idp connection
	* @throws PortalException if a saml idp connection with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.jio.portlet.saml.model.SamlIdpConnection getSamlIdpConnection(
		long samlIdpConnectionId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.getSamlIdpConnection(samlIdpConnectionId);
	}

	@Override
	public com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the saml idp connections.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.portlet.saml.model.impl.SamlIdpConnectionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of saml idp connections
	* @param end the upper bound of the range of saml idp connections (not inclusive)
	* @return the range of saml idp connections
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.jio.portlet.saml.model.SamlIdpConnection> getSamlIdpConnections(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.getSamlIdpConnections(start, end);
	}

	/**
	* Returns the number of saml idp connections.
	*
	* @return the number of saml idp connections
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getSamlIdpConnectionsCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.getSamlIdpConnectionsCount();
	}

	/**
	* Updates the saml idp connection in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param samlIdpConnection the saml idp connection
	* @return the saml idp connection that was updated
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.jio.portlet.saml.model.SamlIdpConnection updateSamlIdpConnection(
		com.jio.portlet.saml.model.SamlIdpConnection samlIdpConnection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.updateSamlIdpConnection(samlIdpConnection);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _samlIdpConnectionLocalService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_samlIdpConnectionLocalService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _samlIdpConnectionLocalService.invokeMethod(name,
			parameterTypes, arguments);
	}

	@Override
	public com.jio.portlet.saml.model.SamlIdpConnection addSamlIdpConnection(
		java.lang.String samlIdpEntityId, boolean assertionSignatureRequired,
		long clockSkew, boolean enabled, boolean forceAuthn,
		boolean ldapImportEnabled, java.lang.String metadataUrl,
		java.io.InputStream metadataXmlInputStream, java.lang.String name,
		java.lang.String nameIdFormat, boolean signAuthnRequest,
		java.lang.String userAttributeMappings,
		com.liferay.portal.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.addSamlIdpConnection(samlIdpEntityId,
			assertionSignatureRequired, clockSkew, enabled, forceAuthn,
			ldapImportEnabled, metadataUrl, metadataXmlInputStream, name,
			nameIdFormat, signAuthnRequest, userAttributeMappings,
			serviceContext);
	}

	@Override
	public com.jio.portlet.saml.model.SamlIdpConnection getSamlIdpConnection(
		long companyId, java.lang.String samlIdpEntityId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.getSamlIdpConnection(companyId,
			samlIdpEntityId);
	}

	@Override
	public java.util.List<com.jio.portlet.saml.model.SamlIdpConnection> getSamlIdpConnections(
		long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.getSamlIdpConnections(companyId);
	}

	@Override
	public java.util.List<com.jio.portlet.saml.model.SamlIdpConnection> getSamlIdpConnections(
		long companyId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.getSamlIdpConnections(companyId,
			start, end);
	}

	@Override
	public java.util.List<com.jio.portlet.saml.model.SamlIdpConnection> getSamlIdpConnections(
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.getSamlIdpConnections(companyId,
			start, end, orderByComparator);
	}

	@Override
	public int getSamlIdpConnectionsCount(long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.getSamlIdpConnectionsCount(companyId);
	}

	@Override
	public void updateMetadata(long samlIdpConnectionId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		_samlIdpConnectionLocalService.updateMetadata(samlIdpConnectionId);
	}

	@Override
	public com.jio.portlet.saml.model.SamlIdpConnection updateSamlIdpConnection(
		long samlIdpConnectionId, java.lang.String samlIdpEntityId,
		boolean assertionSignatureRequired, long clockSkew, boolean enabled,
		boolean forceAuthn, boolean ldapImportEnabled,
		java.lang.String metadataUrl,
		java.io.InputStream metadataXmlInputStream, java.lang.String name,
		java.lang.String nameIdFormat, boolean signAuthnRequest,
		java.lang.String userAttributeMappings,
		com.liferay.portal.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnectionLocalService.updateSamlIdpConnection(samlIdpConnectionId,
			samlIdpEntityId, assertionSignatureRequired, clockSkew, enabled,
			forceAuthn, ldapImportEnabled, metadataUrl, metadataXmlInputStream,
			name, nameIdFormat, signAuthnRequest, userAttributeMappings,
			serviceContext);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public SamlIdpConnectionLocalService getWrappedSamlIdpConnectionLocalService() {
		return _samlIdpConnectionLocalService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedSamlIdpConnectionLocalService(
		SamlIdpConnectionLocalService samlIdpConnectionLocalService) {
		_samlIdpConnectionLocalService = samlIdpConnectionLocalService;
	}

	@Override
	public SamlIdpConnectionLocalService getWrappedService() {
		return _samlIdpConnectionLocalService;
	}

	@Override
	public void setWrappedService(
		SamlIdpConnectionLocalService samlIdpConnectionLocalService) {
		_samlIdpConnectionLocalService = samlIdpConnectionLocalService;
	}

	private SamlIdpConnectionLocalService _samlIdpConnectionLocalService;
}