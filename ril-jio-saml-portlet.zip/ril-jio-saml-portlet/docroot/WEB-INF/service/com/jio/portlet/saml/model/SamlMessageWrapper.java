/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link SamlMessage}.
 * </p>
 *
 * @author Ashish Jadhav
 * @see SamlMessage
 * @generated
 */
public class SamlMessageWrapper implements SamlMessage,
	ModelWrapper<SamlMessage> {
	public SamlMessageWrapper(SamlMessage samlMessage) {
		_samlMessage = samlMessage;
	}

	@Override
	public Class<?> getModelClass() {
		return SamlMessage.class;
	}

	@Override
	public String getModelClassName() {
		return SamlMessage.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("samlMessageId", getSamlMessageId());
		attributes.put("companyId", getCompanyId());
		attributes.put("createDate", getCreateDate());
		attributes.put("entityId", getEntityId());
		attributes.put("responseKey", getResponseKey());
		attributes.put("expirationDate", getExpirationDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long samlMessageId = (Long)attributes.get("samlMessageId");

		if (samlMessageId != null) {
			setSamlMessageId(samlMessageId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		String entityId = (String)attributes.get("entityId");

		if (entityId != null) {
			setEntityId(entityId);
		}

		String responseKey = (String)attributes.get("responseKey");

		if (responseKey != null) {
			setResponseKey(responseKey);
		}

		Date expirationDate = (Date)attributes.get("expirationDate");

		if (expirationDate != null) {
			setExpirationDate(expirationDate);
		}
	}

	/**
	* Returns the primary key of this saml message.
	*
	* @return the primary key of this saml message
	*/
	@Override
	public long getPrimaryKey() {
		return _samlMessage.getPrimaryKey();
	}

	/**
	* Sets the primary key of this saml message.
	*
	* @param primaryKey the primary key of this saml message
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_samlMessage.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the saml message ID of this saml message.
	*
	* @return the saml message ID of this saml message
	*/
	@Override
	public long getSamlMessageId() {
		return _samlMessage.getSamlMessageId();
	}

	/**
	* Sets the saml message ID of this saml message.
	*
	* @param samlMessageId the saml message ID of this saml message
	*/
	@Override
	public void setSamlMessageId(long samlMessageId) {
		_samlMessage.setSamlMessageId(samlMessageId);
	}

	/**
	* Returns the company ID of this saml message.
	*
	* @return the company ID of this saml message
	*/
	@Override
	public long getCompanyId() {
		return _samlMessage.getCompanyId();
	}

	/**
	* Sets the company ID of this saml message.
	*
	* @param companyId the company ID of this saml message
	*/
	@Override
	public void setCompanyId(long companyId) {
		_samlMessage.setCompanyId(companyId);
	}

	/**
	* Returns the create date of this saml message.
	*
	* @return the create date of this saml message
	*/
	@Override
	public java.util.Date getCreateDate() {
		return _samlMessage.getCreateDate();
	}

	/**
	* Sets the create date of this saml message.
	*
	* @param createDate the create date of this saml message
	*/
	@Override
	public void setCreateDate(java.util.Date createDate) {
		_samlMessage.setCreateDate(createDate);
	}

	/**
	* Returns the entity ID of this saml message.
	*
	* @return the entity ID of this saml message
	*/
	@Override
	public java.lang.String getEntityId() {
		return _samlMessage.getEntityId();
	}

	/**
	* Sets the entity ID of this saml message.
	*
	* @param entityId the entity ID of this saml message
	*/
	@Override
	public void setEntityId(java.lang.String entityId) {
		_samlMessage.setEntityId(entityId);
	}

	/**
	* Returns the response key of this saml message.
	*
	* @return the response key of this saml message
	*/
	@Override
	public java.lang.String getResponseKey() {
		return _samlMessage.getResponseKey();
	}

	/**
	* Sets the response key of this saml message.
	*
	* @param responseKey the response key of this saml message
	*/
	@Override
	public void setResponseKey(java.lang.String responseKey) {
		_samlMessage.setResponseKey(responseKey);
	}

	/**
	* Returns the expiration date of this saml message.
	*
	* @return the expiration date of this saml message
	*/
	@Override
	public java.util.Date getExpirationDate() {
		return _samlMessage.getExpirationDate();
	}

	/**
	* Sets the expiration date of this saml message.
	*
	* @param expirationDate the expiration date of this saml message
	*/
	@Override
	public void setExpirationDate(java.util.Date expirationDate) {
		_samlMessage.setExpirationDate(expirationDate);
	}

	@Override
	public boolean isNew() {
		return _samlMessage.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_samlMessage.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _samlMessage.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_samlMessage.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _samlMessage.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _samlMessage.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_samlMessage.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _samlMessage.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_samlMessage.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_samlMessage.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_samlMessage.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new SamlMessageWrapper((SamlMessage)_samlMessage.clone());
	}

	@Override
	public int compareTo(com.jio.portlet.saml.model.SamlMessage samlMessage) {
		return _samlMessage.compareTo(samlMessage);
	}

	@Override
	public int hashCode() {
		return _samlMessage.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jio.portlet.saml.model.SamlMessage> toCacheModel() {
		return _samlMessage.toCacheModel();
	}

	@Override
	public com.jio.portlet.saml.model.SamlMessage toEscapedModel() {
		return new SamlMessageWrapper(_samlMessage.toEscapedModel());
	}

	@Override
	public com.jio.portlet.saml.model.SamlMessage toUnescapedModel() {
		return new SamlMessageWrapper(_samlMessage.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _samlMessage.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _samlMessage.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_samlMessage.persist();
	}

	@Override
	public boolean isExpired() {
		return _samlMessage.isExpired();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof SamlMessageWrapper)) {
			return false;
		}

		SamlMessageWrapper samlMessageWrapper = (SamlMessageWrapper)obj;

		if (Validator.equals(_samlMessage, samlMessageWrapper._samlMessage)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public SamlMessage getWrappedSamlMessage() {
		return _samlMessage;
	}

	@Override
	public SamlMessage getWrappedModel() {
		return _samlMessage;
	}

	@Override
	public void resetOriginalValues() {
		_samlMessage.resetOriginalValues();
	}

	private SamlMessage _samlMessage;
}