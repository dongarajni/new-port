/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link SamlAuthRequest}.
 * </p>
 *
 * @author Ashish Jadhav
 * @see SamlAuthRequest
 * @generated
 */
public class SamlAuthRequestWrapper implements SamlAuthRequest,
	ModelWrapper<SamlAuthRequest> {
	public SamlAuthRequestWrapper(SamlAuthRequest samlAuthRequest) {
		_samlAuthRequest = samlAuthRequest;
	}

	@Override
	public Class<?> getModelClass() {
		return SamlAuthRequest.class;
	}

	@Override
	public String getModelClassName() {
		return SamlAuthRequest.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("samlAuthnRequestId", getSamlAuthnRequestId());
		attributes.put("companyId", getCompanyId());
		attributes.put("createDate", getCreateDate());
		attributes.put("entityId", getEntityId());
		attributes.put("authRequestKey", getAuthRequestKey());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long samlAuthnRequestId = (Long)attributes.get("samlAuthnRequestId");

		if (samlAuthnRequestId != null) {
			setSamlAuthnRequestId(samlAuthnRequestId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		String entityId = (String)attributes.get("entityId");

		if (entityId != null) {
			setEntityId(entityId);
		}

		String authRequestKey = (String)attributes.get("authRequestKey");

		if (authRequestKey != null) {
			setAuthRequestKey(authRequestKey);
		}
	}

	/**
	* Returns the primary key of this saml auth request.
	*
	* @return the primary key of this saml auth request
	*/
	@Override
	public long getPrimaryKey() {
		return _samlAuthRequest.getPrimaryKey();
	}

	/**
	* Sets the primary key of this saml auth request.
	*
	* @param primaryKey the primary key of this saml auth request
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_samlAuthRequest.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the saml authn request ID of this saml auth request.
	*
	* @return the saml authn request ID of this saml auth request
	*/
	@Override
	public long getSamlAuthnRequestId() {
		return _samlAuthRequest.getSamlAuthnRequestId();
	}

	/**
	* Sets the saml authn request ID of this saml auth request.
	*
	* @param samlAuthnRequestId the saml authn request ID of this saml auth request
	*/
	@Override
	public void setSamlAuthnRequestId(long samlAuthnRequestId) {
		_samlAuthRequest.setSamlAuthnRequestId(samlAuthnRequestId);
	}

	/**
	* Returns the company ID of this saml auth request.
	*
	* @return the company ID of this saml auth request
	*/
	@Override
	public long getCompanyId() {
		return _samlAuthRequest.getCompanyId();
	}

	/**
	* Sets the company ID of this saml auth request.
	*
	* @param companyId the company ID of this saml auth request
	*/
	@Override
	public void setCompanyId(long companyId) {
		_samlAuthRequest.setCompanyId(companyId);
	}

	/**
	* Returns the create date of this saml auth request.
	*
	* @return the create date of this saml auth request
	*/
	@Override
	public java.util.Date getCreateDate() {
		return _samlAuthRequest.getCreateDate();
	}

	/**
	* Sets the create date of this saml auth request.
	*
	* @param createDate the create date of this saml auth request
	*/
	@Override
	public void setCreateDate(java.util.Date createDate) {
		_samlAuthRequest.setCreateDate(createDate);
	}

	/**
	* Returns the entity ID of this saml auth request.
	*
	* @return the entity ID of this saml auth request
	*/
	@Override
	public java.lang.String getEntityId() {
		return _samlAuthRequest.getEntityId();
	}

	/**
	* Sets the entity ID of this saml auth request.
	*
	* @param entityId the entity ID of this saml auth request
	*/
	@Override
	public void setEntityId(java.lang.String entityId) {
		_samlAuthRequest.setEntityId(entityId);
	}

	/**
	* Returns the auth request key of this saml auth request.
	*
	* @return the auth request key of this saml auth request
	*/
	@Override
	public java.lang.String getAuthRequestKey() {
		return _samlAuthRequest.getAuthRequestKey();
	}

	/**
	* Sets the auth request key of this saml auth request.
	*
	* @param authRequestKey the auth request key of this saml auth request
	*/
	@Override
	public void setAuthRequestKey(java.lang.String authRequestKey) {
		_samlAuthRequest.setAuthRequestKey(authRequestKey);
	}

	@Override
	public boolean isNew() {
		return _samlAuthRequest.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_samlAuthRequest.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _samlAuthRequest.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_samlAuthRequest.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _samlAuthRequest.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _samlAuthRequest.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_samlAuthRequest.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _samlAuthRequest.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_samlAuthRequest.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_samlAuthRequest.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_samlAuthRequest.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new SamlAuthRequestWrapper((SamlAuthRequest)_samlAuthRequest.clone());
	}

	@Override
	public int compareTo(
		com.jio.portlet.saml.model.SamlAuthRequest samlAuthRequest) {
		return _samlAuthRequest.compareTo(samlAuthRequest);
	}

	@Override
	public int hashCode() {
		return _samlAuthRequest.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jio.portlet.saml.model.SamlAuthRequest> toCacheModel() {
		return _samlAuthRequest.toCacheModel();
	}

	@Override
	public com.jio.portlet.saml.model.SamlAuthRequest toEscapedModel() {
		return new SamlAuthRequestWrapper(_samlAuthRequest.toEscapedModel());
	}

	@Override
	public com.jio.portlet.saml.model.SamlAuthRequest toUnescapedModel() {
		return new SamlAuthRequestWrapper(_samlAuthRequest.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _samlAuthRequest.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _samlAuthRequest.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_samlAuthRequest.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof SamlAuthRequestWrapper)) {
			return false;
		}

		SamlAuthRequestWrapper samlAuthRequestWrapper = (SamlAuthRequestWrapper)obj;

		if (Validator.equals(_samlAuthRequest,
					samlAuthRequestWrapper._samlAuthRequest)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public SamlAuthRequest getWrappedSamlAuthRequest() {
		return _samlAuthRequest;
	}

	@Override
	public SamlAuthRequest getWrappedModel() {
		return _samlAuthRequest;
	}

	@Override
	public void resetOriginalValues() {
		_samlAuthRequest.resetOriginalValues();
	}

	private SamlAuthRequest _samlAuthRequest;
}