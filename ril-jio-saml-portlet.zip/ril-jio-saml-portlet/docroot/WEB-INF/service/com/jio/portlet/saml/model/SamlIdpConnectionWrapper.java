/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link SamlIdpConnection}.
 * </p>
 *
 * @author Ashish Jadhav
 * @see SamlIdpConnection
 * @generated
 */
public class SamlIdpConnectionWrapper implements SamlIdpConnection,
	ModelWrapper<SamlIdpConnection> {
	public SamlIdpConnectionWrapper(SamlIdpConnection samlIdpConnection) {
		_samlIdpConnection = samlIdpConnection;
	}

	@Override
	public Class<?> getModelClass() {
		return SamlIdpConnection.class;
	}

	@Override
	public String getModelClassName() {
		return SamlIdpConnection.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("samlIdpConnectionId", getSamlIdpConnectionId());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("samlIdpEntityId", getSamlIdpEntityId());
		attributes.put("assertionSignatureRequired",
			getAssertionSignatureRequired());
		attributes.put("clockSkew", getClockSkew());
		attributes.put("enabled", getEnabled());
		attributes.put("forceAuthn", getForceAuthn());
		attributes.put("ldapImportEnabled", getLdapImportEnabled());
		attributes.put("metadataUrl", getMetadataUrl());
		attributes.put("metadataXml", getMetadataXml());
		attributes.put("metadataUpdatedDate", getMetadataUpdatedDate());
		attributes.put("name", getName());
		attributes.put("nameIdFormat", getNameIdFormat());
		attributes.put("signAuthnRequest", getSignAuthnRequest());
		attributes.put("userAttributeMappings", getUserAttributeMappings());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long samlIdpConnectionId = (Long)attributes.get("samlIdpConnectionId");

		if (samlIdpConnectionId != null) {
			setSamlIdpConnectionId(samlIdpConnectionId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		String samlIdpEntityId = (String)attributes.get("samlIdpEntityId");

		if (samlIdpEntityId != null) {
			setSamlIdpEntityId(samlIdpEntityId);
		}

		Boolean assertionSignatureRequired = (Boolean)attributes.get(
				"assertionSignatureRequired");

		if (assertionSignatureRequired != null) {
			setAssertionSignatureRequired(assertionSignatureRequired);
		}

		Long clockSkew = (Long)attributes.get("clockSkew");

		if (clockSkew != null) {
			setClockSkew(clockSkew);
		}

		Boolean enabled = (Boolean)attributes.get("enabled");

		if (enabled != null) {
			setEnabled(enabled);
		}

		Boolean forceAuthn = (Boolean)attributes.get("forceAuthn");

		if (forceAuthn != null) {
			setForceAuthn(forceAuthn);
		}

		Boolean ldapImportEnabled = (Boolean)attributes.get("ldapImportEnabled");

		if (ldapImportEnabled != null) {
			setLdapImportEnabled(ldapImportEnabled);
		}

		String metadataUrl = (String)attributes.get("metadataUrl");

		if (metadataUrl != null) {
			setMetadataUrl(metadataUrl);
		}

		String metadataXml = (String)attributes.get("metadataXml");

		if (metadataXml != null) {
			setMetadataXml(metadataXml);
		}

		Date metadataUpdatedDate = (Date)attributes.get("metadataUpdatedDate");

		if (metadataUpdatedDate != null) {
			setMetadataUpdatedDate(metadataUpdatedDate);
		}

		String name = (String)attributes.get("name");

		if (name != null) {
			setName(name);
		}

		String nameIdFormat = (String)attributes.get("nameIdFormat");

		if (nameIdFormat != null) {
			setNameIdFormat(nameIdFormat);
		}

		Boolean signAuthnRequest = (Boolean)attributes.get("signAuthnRequest");

		if (signAuthnRequest != null) {
			setSignAuthnRequest(signAuthnRequest);
		}

		String userAttributeMappings = (String)attributes.get(
				"userAttributeMappings");

		if (userAttributeMappings != null) {
			setUserAttributeMappings(userAttributeMappings);
		}
	}

	/**
	* Returns the primary key of this saml idp connection.
	*
	* @return the primary key of this saml idp connection
	*/
	@Override
	public long getPrimaryKey() {
		return _samlIdpConnection.getPrimaryKey();
	}

	/**
	* Sets the primary key of this saml idp connection.
	*
	* @param primaryKey the primary key of this saml idp connection
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_samlIdpConnection.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the saml idp connection ID of this saml idp connection.
	*
	* @return the saml idp connection ID of this saml idp connection
	*/
	@Override
	public long getSamlIdpConnectionId() {
		return _samlIdpConnection.getSamlIdpConnectionId();
	}

	/**
	* Sets the saml idp connection ID of this saml idp connection.
	*
	* @param samlIdpConnectionId the saml idp connection ID of this saml idp connection
	*/
	@Override
	public void setSamlIdpConnectionId(long samlIdpConnectionId) {
		_samlIdpConnection.setSamlIdpConnectionId(samlIdpConnectionId);
	}

	/**
	* Returns the company ID of this saml idp connection.
	*
	* @return the company ID of this saml idp connection
	*/
	@Override
	public long getCompanyId() {
		return _samlIdpConnection.getCompanyId();
	}

	/**
	* Sets the company ID of this saml idp connection.
	*
	* @param companyId the company ID of this saml idp connection
	*/
	@Override
	public void setCompanyId(long companyId) {
		_samlIdpConnection.setCompanyId(companyId);
	}

	/**
	* Returns the user ID of this saml idp connection.
	*
	* @return the user ID of this saml idp connection
	*/
	@Override
	public long getUserId() {
		return _samlIdpConnection.getUserId();
	}

	/**
	* Sets the user ID of this saml idp connection.
	*
	* @param userId the user ID of this saml idp connection
	*/
	@Override
	public void setUserId(long userId) {
		_samlIdpConnection.setUserId(userId);
	}

	/**
	* Returns the user uuid of this saml idp connection.
	*
	* @return the user uuid of this saml idp connection
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _samlIdpConnection.getUserUuid();
	}

	/**
	* Sets the user uuid of this saml idp connection.
	*
	* @param userUuid the user uuid of this saml idp connection
	*/
	@Override
	public void setUserUuid(java.lang.String userUuid) {
		_samlIdpConnection.setUserUuid(userUuid);
	}

	/**
	* Returns the user name of this saml idp connection.
	*
	* @return the user name of this saml idp connection
	*/
	@Override
	public java.lang.String getUserName() {
		return _samlIdpConnection.getUserName();
	}

	/**
	* Sets the user name of this saml idp connection.
	*
	* @param userName the user name of this saml idp connection
	*/
	@Override
	public void setUserName(java.lang.String userName) {
		_samlIdpConnection.setUserName(userName);
	}

	/**
	* Returns the create date of this saml idp connection.
	*
	* @return the create date of this saml idp connection
	*/
	@Override
	public java.util.Date getCreateDate() {
		return _samlIdpConnection.getCreateDate();
	}

	/**
	* Sets the create date of this saml idp connection.
	*
	* @param createDate the create date of this saml idp connection
	*/
	@Override
	public void setCreateDate(java.util.Date createDate) {
		_samlIdpConnection.setCreateDate(createDate);
	}

	/**
	* Returns the modified date of this saml idp connection.
	*
	* @return the modified date of this saml idp connection
	*/
	@Override
	public java.util.Date getModifiedDate() {
		return _samlIdpConnection.getModifiedDate();
	}

	/**
	* Sets the modified date of this saml idp connection.
	*
	* @param modifiedDate the modified date of this saml idp connection
	*/
	@Override
	public void setModifiedDate(java.util.Date modifiedDate) {
		_samlIdpConnection.setModifiedDate(modifiedDate);
	}

	/**
	* Returns the saml idp entity ID of this saml idp connection.
	*
	* @return the saml idp entity ID of this saml idp connection
	*/
	@Override
	public java.lang.String getSamlIdpEntityId() {
		return _samlIdpConnection.getSamlIdpEntityId();
	}

	/**
	* Sets the saml idp entity ID of this saml idp connection.
	*
	* @param samlIdpEntityId the saml idp entity ID of this saml idp connection
	*/
	@Override
	public void setSamlIdpEntityId(java.lang.String samlIdpEntityId) {
		_samlIdpConnection.setSamlIdpEntityId(samlIdpEntityId);
	}

	/**
	* Returns the assertion signature required of this saml idp connection.
	*
	* @return the assertion signature required of this saml idp connection
	*/
	@Override
	public boolean getAssertionSignatureRequired() {
		return _samlIdpConnection.getAssertionSignatureRequired();
	}

	/**
	* Returns <code>true</code> if this saml idp connection is assertion signature required.
	*
	* @return <code>true</code> if this saml idp connection is assertion signature required; <code>false</code> otherwise
	*/
	@Override
	public boolean isAssertionSignatureRequired() {
		return _samlIdpConnection.isAssertionSignatureRequired();
	}

	/**
	* Sets whether this saml idp connection is assertion signature required.
	*
	* @param assertionSignatureRequired the assertion signature required of this saml idp connection
	*/
	@Override
	public void setAssertionSignatureRequired(
		boolean assertionSignatureRequired) {
		_samlIdpConnection.setAssertionSignatureRequired(assertionSignatureRequired);
	}

	/**
	* Returns the clock skew of this saml idp connection.
	*
	* @return the clock skew of this saml idp connection
	*/
	@Override
	public long getClockSkew() {
		return _samlIdpConnection.getClockSkew();
	}

	/**
	* Sets the clock skew of this saml idp connection.
	*
	* @param clockSkew the clock skew of this saml idp connection
	*/
	@Override
	public void setClockSkew(long clockSkew) {
		_samlIdpConnection.setClockSkew(clockSkew);
	}

	/**
	* Returns the enabled of this saml idp connection.
	*
	* @return the enabled of this saml idp connection
	*/
	@Override
	public boolean getEnabled() {
		return _samlIdpConnection.getEnabled();
	}

	/**
	* Returns <code>true</code> if this saml idp connection is enabled.
	*
	* @return <code>true</code> if this saml idp connection is enabled; <code>false</code> otherwise
	*/
	@Override
	public boolean isEnabled() {
		return _samlIdpConnection.isEnabled();
	}

	/**
	* Sets whether this saml idp connection is enabled.
	*
	* @param enabled the enabled of this saml idp connection
	*/
	@Override
	public void setEnabled(boolean enabled) {
		_samlIdpConnection.setEnabled(enabled);
	}

	/**
	* Returns the force authn of this saml idp connection.
	*
	* @return the force authn of this saml idp connection
	*/
	@Override
	public boolean getForceAuthn() {
		return _samlIdpConnection.getForceAuthn();
	}

	/**
	* Returns <code>true</code> if this saml idp connection is force authn.
	*
	* @return <code>true</code> if this saml idp connection is force authn; <code>false</code> otherwise
	*/
	@Override
	public boolean isForceAuthn() {
		return _samlIdpConnection.isForceAuthn();
	}

	/**
	* Sets whether this saml idp connection is force authn.
	*
	* @param forceAuthn the force authn of this saml idp connection
	*/
	@Override
	public void setForceAuthn(boolean forceAuthn) {
		_samlIdpConnection.setForceAuthn(forceAuthn);
	}

	/**
	* Returns the ldap import enabled of this saml idp connection.
	*
	* @return the ldap import enabled of this saml idp connection
	*/
	@Override
	public boolean getLdapImportEnabled() {
		return _samlIdpConnection.getLdapImportEnabled();
	}

	/**
	* Returns <code>true</code> if this saml idp connection is ldap import enabled.
	*
	* @return <code>true</code> if this saml idp connection is ldap import enabled; <code>false</code> otherwise
	*/
	@Override
	public boolean isLdapImportEnabled() {
		return _samlIdpConnection.isLdapImportEnabled();
	}

	/**
	* Sets whether this saml idp connection is ldap import enabled.
	*
	* @param ldapImportEnabled the ldap import enabled of this saml idp connection
	*/
	@Override
	public void setLdapImportEnabled(boolean ldapImportEnabled) {
		_samlIdpConnection.setLdapImportEnabled(ldapImportEnabled);
	}

	/**
	* Returns the metadata url of this saml idp connection.
	*
	* @return the metadata url of this saml idp connection
	*/
	@Override
	public java.lang.String getMetadataUrl() {
		return _samlIdpConnection.getMetadataUrl();
	}

	/**
	* Sets the metadata url of this saml idp connection.
	*
	* @param metadataUrl the metadata url of this saml idp connection
	*/
	@Override
	public void setMetadataUrl(java.lang.String metadataUrl) {
		_samlIdpConnection.setMetadataUrl(metadataUrl);
	}

	/**
	* Returns the metadata xml of this saml idp connection.
	*
	* @return the metadata xml of this saml idp connection
	*/
	@Override
	public java.lang.String getMetadataXml() {
		return _samlIdpConnection.getMetadataXml();
	}

	/**
	* Sets the metadata xml of this saml idp connection.
	*
	* @param metadataXml the metadata xml of this saml idp connection
	*/
	@Override
	public void setMetadataXml(java.lang.String metadataXml) {
		_samlIdpConnection.setMetadataXml(metadataXml);
	}

	/**
	* Returns the metadata updated date of this saml idp connection.
	*
	* @return the metadata updated date of this saml idp connection
	*/
	@Override
	public java.util.Date getMetadataUpdatedDate() {
		return _samlIdpConnection.getMetadataUpdatedDate();
	}

	/**
	* Sets the metadata updated date of this saml idp connection.
	*
	* @param metadataUpdatedDate the metadata updated date of this saml idp connection
	*/
	@Override
	public void setMetadataUpdatedDate(java.util.Date metadataUpdatedDate) {
		_samlIdpConnection.setMetadataUpdatedDate(metadataUpdatedDate);
	}

	/**
	* Returns the name of this saml idp connection.
	*
	* @return the name of this saml idp connection
	*/
	@Override
	public java.lang.String getName() {
		return _samlIdpConnection.getName();
	}

	/**
	* Sets the name of this saml idp connection.
	*
	* @param name the name of this saml idp connection
	*/
	@Override
	public void setName(java.lang.String name) {
		_samlIdpConnection.setName(name);
	}

	/**
	* Returns the name ID format of this saml idp connection.
	*
	* @return the name ID format of this saml idp connection
	*/
	@Override
	public java.lang.String getNameIdFormat() {
		return _samlIdpConnection.getNameIdFormat();
	}

	/**
	* Sets the name ID format of this saml idp connection.
	*
	* @param nameIdFormat the name ID format of this saml idp connection
	*/
	@Override
	public void setNameIdFormat(java.lang.String nameIdFormat) {
		_samlIdpConnection.setNameIdFormat(nameIdFormat);
	}

	/**
	* Returns the sign authn request of this saml idp connection.
	*
	* @return the sign authn request of this saml idp connection
	*/
	@Override
	public boolean getSignAuthnRequest() {
		return _samlIdpConnection.getSignAuthnRequest();
	}

	/**
	* Returns <code>true</code> if this saml idp connection is sign authn request.
	*
	* @return <code>true</code> if this saml idp connection is sign authn request; <code>false</code> otherwise
	*/
	@Override
	public boolean isSignAuthnRequest() {
		return _samlIdpConnection.isSignAuthnRequest();
	}

	/**
	* Sets whether this saml idp connection is sign authn request.
	*
	* @param signAuthnRequest the sign authn request of this saml idp connection
	*/
	@Override
	public void setSignAuthnRequest(boolean signAuthnRequest) {
		_samlIdpConnection.setSignAuthnRequest(signAuthnRequest);
	}

	/**
	* Returns the user attribute mappings of this saml idp connection.
	*
	* @return the user attribute mappings of this saml idp connection
	*/
	@Override
	public java.lang.String getUserAttributeMappings() {
		return _samlIdpConnection.getUserAttributeMappings();
	}

	/**
	* Sets the user attribute mappings of this saml idp connection.
	*
	* @param userAttributeMappings the user attribute mappings of this saml idp connection
	*/
	@Override
	public void setUserAttributeMappings(java.lang.String userAttributeMappings) {
		_samlIdpConnection.setUserAttributeMappings(userAttributeMappings);
	}

	@Override
	public boolean isNew() {
		return _samlIdpConnection.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_samlIdpConnection.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _samlIdpConnection.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_samlIdpConnection.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _samlIdpConnection.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _samlIdpConnection.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_samlIdpConnection.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _samlIdpConnection.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_samlIdpConnection.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_samlIdpConnection.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_samlIdpConnection.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new SamlIdpConnectionWrapper((SamlIdpConnection)_samlIdpConnection.clone());
	}

	@Override
	public int compareTo(
		com.jio.portlet.saml.model.SamlIdpConnection samlIdpConnection) {
		return _samlIdpConnection.compareTo(samlIdpConnection);
	}

	@Override
	public int hashCode() {
		return _samlIdpConnection.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jio.portlet.saml.model.SamlIdpConnection> toCacheModel() {
		return _samlIdpConnection.toCacheModel();
	}

	@Override
	public com.jio.portlet.saml.model.SamlIdpConnection toEscapedModel() {
		return new SamlIdpConnectionWrapper(_samlIdpConnection.toEscapedModel());
	}

	@Override
	public com.jio.portlet.saml.model.SamlIdpConnection toUnescapedModel() {
		return new SamlIdpConnectionWrapper(_samlIdpConnection.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _samlIdpConnection.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _samlIdpConnection.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_samlIdpConnection.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof SamlIdpConnectionWrapper)) {
			return false;
		}

		SamlIdpConnectionWrapper samlIdpConnectionWrapper = (SamlIdpConnectionWrapper)obj;

		if (Validator.equals(_samlIdpConnection,
					samlIdpConnectionWrapper._samlIdpConnection)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public SamlIdpConnection getWrappedSamlIdpConnection() {
		return _samlIdpConnection;
	}

	@Override
	public SamlIdpConnection getWrappedModel() {
		return _samlIdpConnection;
	}

	@Override
	public void resetOriginalValues() {
		_samlIdpConnection.resetOriginalValues();
	}

	private SamlIdpConnection _samlIdpConnection;
}