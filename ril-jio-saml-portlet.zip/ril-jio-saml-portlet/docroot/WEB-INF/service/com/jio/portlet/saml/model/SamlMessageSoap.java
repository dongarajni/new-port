/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author Ashish Jadhav
 * @generated
 */
public class SamlMessageSoap implements Serializable {
	public static SamlMessageSoap toSoapModel(SamlMessage model) {
		SamlMessageSoap soapModel = new SamlMessageSoap();

		soapModel.setSamlMessageId(model.getSamlMessageId());
		soapModel.setCompanyId(model.getCompanyId());
		soapModel.setCreateDate(model.getCreateDate());
		soapModel.setEntityId(model.getEntityId());
		soapModel.setResponseKey(model.getResponseKey());
		soapModel.setExpirationDate(model.getExpirationDate());

		return soapModel;
	}

	public static SamlMessageSoap[] toSoapModels(SamlMessage[] models) {
		SamlMessageSoap[] soapModels = new SamlMessageSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static SamlMessageSoap[][] toSoapModels(SamlMessage[][] models) {
		SamlMessageSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new SamlMessageSoap[models.length][models[0].length];
		}
		else {
			soapModels = new SamlMessageSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static SamlMessageSoap[] toSoapModels(List<SamlMessage> models) {
		List<SamlMessageSoap> soapModels = new ArrayList<SamlMessageSoap>(models.size());

		for (SamlMessage model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new SamlMessageSoap[soapModels.size()]);
	}

	public SamlMessageSoap() {
	}

	public long getPrimaryKey() {
		return _samlMessageId;
	}

	public void setPrimaryKey(long pk) {
		setSamlMessageId(pk);
	}

	public long getSamlMessageId() {
		return _samlMessageId;
	}

	public void setSamlMessageId(long samlMessageId) {
		_samlMessageId = samlMessageId;
	}

	public long getCompanyId() {
		return _companyId;
	}

	public void setCompanyId(long companyId) {
		_companyId = companyId;
	}

	public Date getCreateDate() {
		return _createDate;
	}

	public void setCreateDate(Date createDate) {
		_createDate = createDate;
	}

	public String getEntityId() {
		return _entityId;
	}

	public void setEntityId(String entityId) {
		_entityId = entityId;
	}

	public String getResponseKey() {
		return _responseKey;
	}

	public void setResponseKey(String responseKey) {
		_responseKey = responseKey;
	}

	public Date getExpirationDate() {
		return _expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		_expirationDate = expirationDate;
	}

	private long _samlMessageId;
	private long _companyId;
	private Date _createDate;
	private String _entityId;
	private String _responseKey;
	private Date _expirationDate;
}