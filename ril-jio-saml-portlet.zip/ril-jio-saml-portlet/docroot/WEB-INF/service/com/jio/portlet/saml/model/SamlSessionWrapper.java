/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link SamlSession}.
 * </p>
 *
 * @author Ashish Jadhav
 * @see SamlSession
 * @generated
 */
public class SamlSessionWrapper implements SamlSession,
	ModelWrapper<SamlSession> {
	public SamlSessionWrapper(SamlSession samlSession) {
		_samlSession = samlSession;
	}

	@Override
	public Class<?> getModelClass() {
		return SamlSession.class;
	}

	@Override
	public String getModelClassName() {
		return SamlSession.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("sessionId", getSessionId());
		attributes.put("sessionKey", getSessionKey());
		attributes.put("assertionXml", getAssertionXml());
		attributes.put("jSessionId", getJSessionId());
		attributes.put("nameIdFormat", getNameIdFormat());
		attributes.put("nameIdNameQualifier", getNameIdNameQualifier());
		attributes.put("nameIdSPNameQualifier", getNameIdSPNameQualifier());
		attributes.put("nameIdValue", getNameIdValue());
		attributes.put("sessionIndex", getSessionIndex());
		attributes.put("terminated", getTerminated());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long sessionId = (Long)attributes.get("sessionId");

		if (sessionId != null) {
			setSessionId(sessionId);
		}

		String sessionKey = (String)attributes.get("sessionKey");

		if (sessionKey != null) {
			setSessionKey(sessionKey);
		}

		String assertionXml = (String)attributes.get("assertionXml");

		if (assertionXml != null) {
			setAssertionXml(assertionXml);
		}

		String jSessionId = (String)attributes.get("jSessionId");

		if (jSessionId != null) {
			setJSessionId(jSessionId);
		}

		String nameIdFormat = (String)attributes.get("nameIdFormat");

		if (nameIdFormat != null) {
			setNameIdFormat(nameIdFormat);
		}

		String nameIdNameQualifier = (String)attributes.get(
				"nameIdNameQualifier");

		if (nameIdNameQualifier != null) {
			setNameIdNameQualifier(nameIdNameQualifier);
		}

		String nameIdSPNameQualifier = (String)attributes.get(
				"nameIdSPNameQualifier");

		if (nameIdSPNameQualifier != null) {
			setNameIdSPNameQualifier(nameIdSPNameQualifier);
		}

		String nameIdValue = (String)attributes.get("nameIdValue");

		if (nameIdValue != null) {
			setNameIdValue(nameIdValue);
		}

		String sessionIndex = (String)attributes.get("sessionIndex");

		if (sessionIndex != null) {
			setSessionIndex(sessionIndex);
		}

		Boolean terminated = (Boolean)attributes.get("terminated");

		if (terminated != null) {
			setTerminated(terminated);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}
	}

	/**
	* Returns the primary key of this saml session.
	*
	* @return the primary key of this saml session
	*/
	@Override
	public long getPrimaryKey() {
		return _samlSession.getPrimaryKey();
	}

	/**
	* Sets the primary key of this saml session.
	*
	* @param primaryKey the primary key of this saml session
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_samlSession.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the session ID of this saml session.
	*
	* @return the session ID of this saml session
	*/
	@Override
	public long getSessionId() {
		return _samlSession.getSessionId();
	}

	/**
	* Sets the session ID of this saml session.
	*
	* @param sessionId the session ID of this saml session
	*/
	@Override
	public void setSessionId(long sessionId) {
		_samlSession.setSessionId(sessionId);
	}

	/**
	* Returns the session key of this saml session.
	*
	* @return the session key of this saml session
	*/
	@Override
	public java.lang.String getSessionKey() {
		return _samlSession.getSessionKey();
	}

	/**
	* Sets the session key of this saml session.
	*
	* @param sessionKey the session key of this saml session
	*/
	@Override
	public void setSessionKey(java.lang.String sessionKey) {
		_samlSession.setSessionKey(sessionKey);
	}

	/**
	* Returns the assertion xml of this saml session.
	*
	* @return the assertion xml of this saml session
	*/
	@Override
	public java.lang.String getAssertionXml() {
		return _samlSession.getAssertionXml();
	}

	/**
	* Sets the assertion xml of this saml session.
	*
	* @param assertionXml the assertion xml of this saml session
	*/
	@Override
	public void setAssertionXml(java.lang.String assertionXml) {
		_samlSession.setAssertionXml(assertionXml);
	}

	/**
	* Returns the j session ID of this saml session.
	*
	* @return the j session ID of this saml session
	*/
	@Override
	public java.lang.String getJSessionId() {
		return _samlSession.getJSessionId();
	}

	/**
	* Sets the j session ID of this saml session.
	*
	* @param jSessionId the j session ID of this saml session
	*/
	@Override
	public void setJSessionId(java.lang.String jSessionId) {
		_samlSession.setJSessionId(jSessionId);
	}

	/**
	* Returns the name ID format of this saml session.
	*
	* @return the name ID format of this saml session
	*/
	@Override
	public java.lang.String getNameIdFormat() {
		return _samlSession.getNameIdFormat();
	}

	/**
	* Sets the name ID format of this saml session.
	*
	* @param nameIdFormat the name ID format of this saml session
	*/
	@Override
	public void setNameIdFormat(java.lang.String nameIdFormat) {
		_samlSession.setNameIdFormat(nameIdFormat);
	}

	/**
	* Returns the name ID name qualifier of this saml session.
	*
	* @return the name ID name qualifier of this saml session
	*/
	@Override
	public java.lang.String getNameIdNameQualifier() {
		return _samlSession.getNameIdNameQualifier();
	}

	/**
	* Sets the name ID name qualifier of this saml session.
	*
	* @param nameIdNameQualifier the name ID name qualifier of this saml session
	*/
	@Override
	public void setNameIdNameQualifier(java.lang.String nameIdNameQualifier) {
		_samlSession.setNameIdNameQualifier(nameIdNameQualifier);
	}

	/**
	* Returns the name ID s p name qualifier of this saml session.
	*
	* @return the name ID s p name qualifier of this saml session
	*/
	@Override
	public java.lang.String getNameIdSPNameQualifier() {
		return _samlSession.getNameIdSPNameQualifier();
	}

	/**
	* Sets the name ID s p name qualifier of this saml session.
	*
	* @param nameIdSPNameQualifier the name ID s p name qualifier of this saml session
	*/
	@Override
	public void setNameIdSPNameQualifier(java.lang.String nameIdSPNameQualifier) {
		_samlSession.setNameIdSPNameQualifier(nameIdSPNameQualifier);
	}

	/**
	* Returns the name ID value of this saml session.
	*
	* @return the name ID value of this saml session
	*/
	@Override
	public java.lang.String getNameIdValue() {
		return _samlSession.getNameIdValue();
	}

	/**
	* Sets the name ID value of this saml session.
	*
	* @param nameIdValue the name ID value of this saml session
	*/
	@Override
	public void setNameIdValue(java.lang.String nameIdValue) {
		_samlSession.setNameIdValue(nameIdValue);
	}

	/**
	* Returns the session index of this saml session.
	*
	* @return the session index of this saml session
	*/
	@Override
	public java.lang.String getSessionIndex() {
		return _samlSession.getSessionIndex();
	}

	/**
	* Sets the session index of this saml session.
	*
	* @param sessionIndex the session index of this saml session
	*/
	@Override
	public void setSessionIndex(java.lang.String sessionIndex) {
		_samlSession.setSessionIndex(sessionIndex);
	}

	/**
	* Returns the terminated of this saml session.
	*
	* @return the terminated of this saml session
	*/
	@Override
	public boolean getTerminated() {
		return _samlSession.getTerminated();
	}

	/**
	* Returns <code>true</code> if this saml session is terminated.
	*
	* @return <code>true</code> if this saml session is terminated; <code>false</code> otherwise
	*/
	@Override
	public boolean isTerminated() {
		return _samlSession.isTerminated();
	}

	/**
	* Sets whether this saml session is terminated.
	*
	* @param terminated the terminated of this saml session
	*/
	@Override
	public void setTerminated(boolean terminated) {
		_samlSession.setTerminated(terminated);
	}

	/**
	* Returns the company ID of this saml session.
	*
	* @return the company ID of this saml session
	*/
	@Override
	public long getCompanyId() {
		return _samlSession.getCompanyId();
	}

	/**
	* Sets the company ID of this saml session.
	*
	* @param companyId the company ID of this saml session
	*/
	@Override
	public void setCompanyId(long companyId) {
		_samlSession.setCompanyId(companyId);
	}

	/**
	* Returns the user ID of this saml session.
	*
	* @return the user ID of this saml session
	*/
	@Override
	public long getUserId() {
		return _samlSession.getUserId();
	}

	/**
	* Sets the user ID of this saml session.
	*
	* @param userId the user ID of this saml session
	*/
	@Override
	public void setUserId(long userId) {
		_samlSession.setUserId(userId);
	}

	/**
	* Returns the user uuid of this saml session.
	*
	* @return the user uuid of this saml session
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _samlSession.getUserUuid();
	}

	/**
	* Sets the user uuid of this saml session.
	*
	* @param userUuid the user uuid of this saml session
	*/
	@Override
	public void setUserUuid(java.lang.String userUuid) {
		_samlSession.setUserUuid(userUuid);
	}

	/**
	* Returns the user name of this saml session.
	*
	* @return the user name of this saml session
	*/
	@Override
	public java.lang.String getUserName() {
		return _samlSession.getUserName();
	}

	/**
	* Sets the user name of this saml session.
	*
	* @param userName the user name of this saml session
	*/
	@Override
	public void setUserName(java.lang.String userName) {
		_samlSession.setUserName(userName);
	}

	/**
	* Returns the create date of this saml session.
	*
	* @return the create date of this saml session
	*/
	@Override
	public java.util.Date getCreateDate() {
		return _samlSession.getCreateDate();
	}

	/**
	* Sets the create date of this saml session.
	*
	* @param createDate the create date of this saml session
	*/
	@Override
	public void setCreateDate(java.util.Date createDate) {
		_samlSession.setCreateDate(createDate);
	}

	/**
	* Returns the modified date of this saml session.
	*
	* @return the modified date of this saml session
	*/
	@Override
	public java.util.Date getModifiedDate() {
		return _samlSession.getModifiedDate();
	}

	/**
	* Sets the modified date of this saml session.
	*
	* @param modifiedDate the modified date of this saml session
	*/
	@Override
	public void setModifiedDate(java.util.Date modifiedDate) {
		_samlSession.setModifiedDate(modifiedDate);
	}

	@Override
	public boolean isNew() {
		return _samlSession.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_samlSession.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _samlSession.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_samlSession.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _samlSession.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _samlSession.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_samlSession.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _samlSession.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_samlSession.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_samlSession.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_samlSession.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new SamlSessionWrapper((SamlSession)_samlSession.clone());
	}

	@Override
	public int compareTo(com.jio.portlet.saml.model.SamlSession samlSession) {
		return _samlSession.compareTo(samlSession);
	}

	@Override
	public int hashCode() {
		return _samlSession.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jio.portlet.saml.model.SamlSession> toCacheModel() {
		return _samlSession.toCacheModel();
	}

	@Override
	public com.jio.portlet.saml.model.SamlSession toEscapedModel() {
		return new SamlSessionWrapper(_samlSession.toEscapedModel());
	}

	@Override
	public com.jio.portlet.saml.model.SamlSession toUnescapedModel() {
		return new SamlSessionWrapper(_samlSession.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _samlSession.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _samlSession.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_samlSession.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof SamlSessionWrapper)) {
			return false;
		}

		SamlSessionWrapper samlSessionWrapper = (SamlSessionWrapper)obj;

		if (Validator.equals(_samlSession, samlSessionWrapper._samlSession)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public SamlSession getWrappedSamlSession() {
		return _samlSession;
	}

	@Override
	public SamlSession getWrappedModel() {
		return _samlSession;
	}

	@Override
	public void resetOriginalValues() {
		_samlSession.resetOriginalValues();
	}

	private SamlSession _samlSession;
}