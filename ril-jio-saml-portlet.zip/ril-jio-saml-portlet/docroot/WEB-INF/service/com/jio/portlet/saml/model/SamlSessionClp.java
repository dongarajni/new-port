/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.saml.model;

import com.jio.portlet.saml.service.ClpSerializer;
import com.jio.portlet.saml.service.SamlSessionLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Ashish Jadhav
 */
public class SamlSessionClp extends BaseModelImpl<SamlSession>
	implements SamlSession {
	public SamlSessionClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return SamlSession.class;
	}

	@Override
	public String getModelClassName() {
		return SamlSession.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _sessionId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setSessionId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _sessionId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("sessionId", getSessionId());
		attributes.put("sessionKey", getSessionKey());
		attributes.put("assertionXml", getAssertionXml());
		attributes.put("jSessionId", getJSessionId());
		attributes.put("nameIdFormat", getNameIdFormat());
		attributes.put("nameIdNameQualifier", getNameIdNameQualifier());
		attributes.put("nameIdSPNameQualifier", getNameIdSPNameQualifier());
		attributes.put("nameIdValue", getNameIdValue());
		attributes.put("sessionIndex", getSessionIndex());
		attributes.put("terminated", getTerminated());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long sessionId = (Long)attributes.get("sessionId");

		if (sessionId != null) {
			setSessionId(sessionId);
		}

		String sessionKey = (String)attributes.get("sessionKey");

		if (sessionKey != null) {
			setSessionKey(sessionKey);
		}

		String assertionXml = (String)attributes.get("assertionXml");

		if (assertionXml != null) {
			setAssertionXml(assertionXml);
		}

		String jSessionId = (String)attributes.get("jSessionId");

		if (jSessionId != null) {
			setJSessionId(jSessionId);
		}

		String nameIdFormat = (String)attributes.get("nameIdFormat");

		if (nameIdFormat != null) {
			setNameIdFormat(nameIdFormat);
		}

		String nameIdNameQualifier = (String)attributes.get(
				"nameIdNameQualifier");

		if (nameIdNameQualifier != null) {
			setNameIdNameQualifier(nameIdNameQualifier);
		}

		String nameIdSPNameQualifier = (String)attributes.get(
				"nameIdSPNameQualifier");

		if (nameIdSPNameQualifier != null) {
			setNameIdSPNameQualifier(nameIdSPNameQualifier);
		}

		String nameIdValue = (String)attributes.get("nameIdValue");

		if (nameIdValue != null) {
			setNameIdValue(nameIdValue);
		}

		String sessionIndex = (String)attributes.get("sessionIndex");

		if (sessionIndex != null) {
			setSessionIndex(sessionIndex);
		}

		Boolean terminated = (Boolean)attributes.get("terminated");

		if (terminated != null) {
			setTerminated(terminated);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}
	}

	@Override
	public long getSessionId() {
		return _sessionId;
	}

	@Override
	public void setSessionId(long sessionId) {
		_sessionId = sessionId;

		if (_samlSessionRemoteModel != null) {
			try {
				Class<?> clazz = _samlSessionRemoteModel.getClass();

				Method method = clazz.getMethod("setSessionId", long.class);

				method.invoke(_samlSessionRemoteModel, sessionId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSessionKey() {
		return _sessionKey;
	}

	@Override
	public void setSessionKey(String sessionKey) {
		_sessionKey = sessionKey;

		if (_samlSessionRemoteModel != null) {
			try {
				Class<?> clazz = _samlSessionRemoteModel.getClass();

				Method method = clazz.getMethod("setSessionKey", String.class);

				method.invoke(_samlSessionRemoteModel, sessionKey);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAssertionXml() {
		return _assertionXml;
	}

	@Override
	public void setAssertionXml(String assertionXml) {
		_assertionXml = assertionXml;

		if (_samlSessionRemoteModel != null) {
			try {
				Class<?> clazz = _samlSessionRemoteModel.getClass();

				Method method = clazz.getMethod("setAssertionXml", String.class);

				method.invoke(_samlSessionRemoteModel, assertionXml);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getJSessionId() {
		return _jSessionId;
	}

	@Override
	public void setJSessionId(String jSessionId) {
		_jSessionId = jSessionId;

		if (_samlSessionRemoteModel != null) {
			try {
				Class<?> clazz = _samlSessionRemoteModel.getClass();

				Method method = clazz.getMethod("setJSessionId", String.class);

				method.invoke(_samlSessionRemoteModel, jSessionId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNameIdFormat() {
		return _nameIdFormat;
	}

	@Override
	public void setNameIdFormat(String nameIdFormat) {
		_nameIdFormat = nameIdFormat;

		if (_samlSessionRemoteModel != null) {
			try {
				Class<?> clazz = _samlSessionRemoteModel.getClass();

				Method method = clazz.getMethod("setNameIdFormat", String.class);

				method.invoke(_samlSessionRemoteModel, nameIdFormat);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNameIdNameQualifier() {
		return _nameIdNameQualifier;
	}

	@Override
	public void setNameIdNameQualifier(String nameIdNameQualifier) {
		_nameIdNameQualifier = nameIdNameQualifier;

		if (_samlSessionRemoteModel != null) {
			try {
				Class<?> clazz = _samlSessionRemoteModel.getClass();

				Method method = clazz.getMethod("setNameIdNameQualifier",
						String.class);

				method.invoke(_samlSessionRemoteModel, nameIdNameQualifier);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNameIdSPNameQualifier() {
		return _nameIdSPNameQualifier;
	}

	@Override
	public void setNameIdSPNameQualifier(String nameIdSPNameQualifier) {
		_nameIdSPNameQualifier = nameIdSPNameQualifier;

		if (_samlSessionRemoteModel != null) {
			try {
				Class<?> clazz = _samlSessionRemoteModel.getClass();

				Method method = clazz.getMethod("setNameIdSPNameQualifier",
						String.class);

				method.invoke(_samlSessionRemoteModel, nameIdSPNameQualifier);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNameIdValue() {
		return _nameIdValue;
	}

	@Override
	public void setNameIdValue(String nameIdValue) {
		_nameIdValue = nameIdValue;

		if (_samlSessionRemoteModel != null) {
			try {
				Class<?> clazz = _samlSessionRemoteModel.getClass();

				Method method = clazz.getMethod("setNameIdValue", String.class);

				method.invoke(_samlSessionRemoteModel, nameIdValue);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSessionIndex() {
		return _sessionIndex;
	}

	@Override
	public void setSessionIndex(String sessionIndex) {
		_sessionIndex = sessionIndex;

		if (_samlSessionRemoteModel != null) {
			try {
				Class<?> clazz = _samlSessionRemoteModel.getClass();

				Method method = clazz.getMethod("setSessionIndex", String.class);

				method.invoke(_samlSessionRemoteModel, sessionIndex);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public boolean getTerminated() {
		return _terminated;
	}

	@Override
	public boolean isTerminated() {
		return _terminated;
	}

	@Override
	public void setTerminated(boolean terminated) {
		_terminated = terminated;

		if (_samlSessionRemoteModel != null) {
			try {
				Class<?> clazz = _samlSessionRemoteModel.getClass();

				Method method = clazz.getMethod("setTerminated", boolean.class);

				method.invoke(_samlSessionRemoteModel, terminated);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getCompanyId() {
		return _companyId;
	}

	@Override
	public void setCompanyId(long companyId) {
		_companyId = companyId;

		if (_samlSessionRemoteModel != null) {
			try {
				Class<?> clazz = _samlSessionRemoteModel.getClass();

				Method method = clazz.getMethod("setCompanyId", long.class);

				method.invoke(_samlSessionRemoteModel, companyId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getUserId() {
		return _userId;
	}

	@Override
	public void setUserId(long userId) {
		_userId = userId;

		if (_samlSessionRemoteModel != null) {
			try {
				Class<?> clazz = _samlSessionRemoteModel.getClass();

				Method method = clazz.getMethod("setUserId", long.class);

				method.invoke(_samlSessionRemoteModel, userId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUserUuid() throws SystemException {
		return PortalUtil.getUserValue(getUserId(), "uuid", _userUuid);
	}

	@Override
	public void setUserUuid(String userUuid) {
		_userUuid = userUuid;
	}

	@Override
	public String getUserName() {
		return _userName;
	}

	@Override
	public void setUserName(String userName) {
		_userName = userName;

		if (_samlSessionRemoteModel != null) {
			try {
				Class<?> clazz = _samlSessionRemoteModel.getClass();

				Method method = clazz.getMethod("setUserName", String.class);

				method.invoke(_samlSessionRemoteModel, userName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getCreateDate() {
		return _createDate;
	}

	@Override
	public void setCreateDate(Date createDate) {
		_createDate = createDate;

		if (_samlSessionRemoteModel != null) {
			try {
				Class<?> clazz = _samlSessionRemoteModel.getClass();

				Method method = clazz.getMethod("setCreateDate", Date.class);

				method.invoke(_samlSessionRemoteModel, createDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getModifiedDate() {
		return _modifiedDate;
	}

	@Override
	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;

		if (_samlSessionRemoteModel != null) {
			try {
				Class<?> clazz = _samlSessionRemoteModel.getClass();

				Method method = clazz.getMethod("setModifiedDate", Date.class);

				method.invoke(_samlSessionRemoteModel, modifiedDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getSamlSessionRemoteModel() {
		return _samlSessionRemoteModel;
	}

	public void setSamlSessionRemoteModel(BaseModel<?> samlSessionRemoteModel) {
		_samlSessionRemoteModel = samlSessionRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _samlSessionRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_samlSessionRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			SamlSessionLocalServiceUtil.addSamlSession(this);
		}
		else {
			SamlSessionLocalServiceUtil.updateSamlSession(this);
		}
	}

	@Override
	public SamlSession toEscapedModel() {
		return (SamlSession)ProxyUtil.newProxyInstance(SamlSession.class.getClassLoader(),
			new Class[] { SamlSession.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		SamlSessionClp clone = new SamlSessionClp();

		clone.setSessionId(getSessionId());
		clone.setSessionKey(getSessionKey());
		clone.setAssertionXml(getAssertionXml());
		clone.setJSessionId(getJSessionId());
		clone.setNameIdFormat(getNameIdFormat());
		clone.setNameIdNameQualifier(getNameIdNameQualifier());
		clone.setNameIdSPNameQualifier(getNameIdSPNameQualifier());
		clone.setNameIdValue(getNameIdValue());
		clone.setSessionIndex(getSessionIndex());
		clone.setTerminated(getTerminated());
		clone.setCompanyId(getCompanyId());
		clone.setUserId(getUserId());
		clone.setUserName(getUserName());
		clone.setCreateDate(getCreateDate());
		clone.setModifiedDate(getModifiedDate());

		return clone;
	}

	@Override
	public int compareTo(SamlSession samlSession) {
		long primaryKey = samlSession.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof SamlSessionClp)) {
			return false;
		}

		SamlSessionClp samlSession = (SamlSessionClp)obj;

		long primaryKey = samlSession.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(31);

		sb.append("{sessionId=");
		sb.append(getSessionId());
		sb.append(", sessionKey=");
		sb.append(getSessionKey());
		sb.append(", assertionXml=");
		sb.append(getAssertionXml());
		sb.append(", jSessionId=");
		sb.append(getJSessionId());
		sb.append(", nameIdFormat=");
		sb.append(getNameIdFormat());
		sb.append(", nameIdNameQualifier=");
		sb.append(getNameIdNameQualifier());
		sb.append(", nameIdSPNameQualifier=");
		sb.append(getNameIdSPNameQualifier());
		sb.append(", nameIdValue=");
		sb.append(getNameIdValue());
		sb.append(", sessionIndex=");
		sb.append(getSessionIndex());
		sb.append(", terminated=");
		sb.append(getTerminated());
		sb.append(", companyId=");
		sb.append(getCompanyId());
		sb.append(", userId=");
		sb.append(getUserId());
		sb.append(", userName=");
		sb.append(getUserName());
		sb.append(", createDate=");
		sb.append(getCreateDate());
		sb.append(", modifiedDate=");
		sb.append(getModifiedDate());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(49);

		sb.append("<model><model-name>");
		sb.append("com.jio.portlet.saml.model.SamlSession");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>sessionId</column-name><column-value><![CDATA[");
		sb.append(getSessionId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>sessionKey</column-name><column-value><![CDATA[");
		sb.append(getSessionKey());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>assertionXml</column-name><column-value><![CDATA[");
		sb.append(getAssertionXml());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>jSessionId</column-name><column-value><![CDATA[");
		sb.append(getJSessionId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>nameIdFormat</column-name><column-value><![CDATA[");
		sb.append(getNameIdFormat());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>nameIdNameQualifier</column-name><column-value><![CDATA[");
		sb.append(getNameIdNameQualifier());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>nameIdSPNameQualifier</column-name><column-value><![CDATA[");
		sb.append(getNameIdSPNameQualifier());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>nameIdValue</column-name><column-value><![CDATA[");
		sb.append(getNameIdValue());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>sessionIndex</column-name><column-value><![CDATA[");
		sb.append(getSessionIndex());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>terminated</column-name><column-value><![CDATA[");
		sb.append(getTerminated());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>companyId</column-name><column-value><![CDATA[");
		sb.append(getCompanyId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userId</column-name><column-value><![CDATA[");
		sb.append(getUserId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userName</column-name><column-value><![CDATA[");
		sb.append(getUserName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>createDate</column-name><column-value><![CDATA[");
		sb.append(getCreateDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>modifiedDate</column-name><column-value><![CDATA[");
		sb.append(getModifiedDate());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _sessionId;
	private String _sessionKey;
	private String _assertionXml;
	private String _jSessionId;
	private String _nameIdFormat;
	private String _nameIdNameQualifier;
	private String _nameIdSPNameQualifier;
	private String _nameIdValue;
	private String _sessionIndex;
	private boolean _terminated;
	private long _companyId;
	private long _userId;
	private String _userUuid;
	private String _userName;
	private Date _createDate;
	private Date _modifiedDate;
	private BaseModel<?> _samlSessionRemoteModel;
	private Class<?> _clpSerializerClass = com.jio.portlet.saml.service.ClpSerializer.class;
}