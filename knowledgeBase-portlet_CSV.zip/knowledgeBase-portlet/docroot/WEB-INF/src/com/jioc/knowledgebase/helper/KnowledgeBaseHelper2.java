package com.jioc.knowledgebase.helper;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.PropsUtil;

import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.apache.commons.csv.CSVRecord;

public class KnowledgeBaseHelper2 {

	public static String[] ASSET_TAG_NAMES = PropsUtil.getArray("jioc.article");
	private static final String FILE_PATH=GetterUtil.getString(PropsUtil.get("jioc.file.path"));
	private static final String FOLDER_NAME=GetterUtil.getString(PropsUtil.get("jioc.dl.knowledgebase.folder"));
	private static final Log LOGGER = LogFactoryUtil.getLog(KnowledgeBaseHelper.class);
	public static final long STRUCTURE_ID = GetterUtil.getLong(PropsUtil.get("jioc.structure.id"));
	public static final long TEMPLATE_ID = GetterUtil.getLong(PropsUtil.get("jioc.template.id"));
	
	public static void processRequest(ActionRequest actionRequest, ActionResponse ationResponse) {
		//List<CSVRecord> csvRecords = getCSVRecords();
	}
	
}
