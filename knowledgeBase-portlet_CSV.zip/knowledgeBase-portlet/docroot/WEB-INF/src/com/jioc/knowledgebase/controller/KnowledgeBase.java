package com.jioc.knowledgebase.controller;

import com.jioc.knowledgebase.helper.KnowledgeBaseHelper;
import com.liferay.util.bridges.mvc.MVCPortlet;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

/**
 * Portlet implementation class KnowledgeBase
 */
public class KnowledgeBase extends MVCPortlet {
 
	public void uploadKnowledgeBase(ActionRequest actionRequest,ActionResponse actionResponse){
		KnowledgeBaseHelper.processCSV(actionRequest,actionResponse);
	}
}
