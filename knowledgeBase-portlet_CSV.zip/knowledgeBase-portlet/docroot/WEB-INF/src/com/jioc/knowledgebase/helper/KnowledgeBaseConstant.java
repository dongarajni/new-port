package com.jioc.knowledgebase.helper;

public class KnowledgeBaseConstant {

	public static final String FILENAME = "fileName";
	public static final String TITLE = "Title";
	public static final String KEYWORD = "Keywords";
	public static final String DESCRIPTION = "Description";
	public static final String OC_NAME = "OC_Name";
	public static final String UPLOADED_BY = "Uploaded_By";
	public static final String UPLOADED_DATE = "Uploaded_Date";
	public static final String FILE_NAME = "File_Name";
	public static final String KB_ID = "KB_ID";
	
	
	
}
