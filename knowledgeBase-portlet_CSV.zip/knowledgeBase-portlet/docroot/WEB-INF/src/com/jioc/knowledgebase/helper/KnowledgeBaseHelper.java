package com.jioc.knowledgebase.helper;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.repository.model.Folder;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.FriendlyURLNormalizerUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.MimeTypesUtil;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.documentlibrary.model.DLFileShortcut;
import com.liferay.portlet.documentlibrary.model.DLFolder;
import com.liferay.portlet.documentlibrary.model.DLFolderConstants;
import com.liferay.portlet.documentlibrary.service.DLAppLocalServiceUtil;
import com.liferay.portlet.documentlibrary.service.DLFolderLocalServiceUtil;
import com.liferay.portlet.documentlibrary.service.DLFolderServiceUtil;
import com.liferay.portlet.dynamicdatamapping.model.DDMStructure;
import com.liferay.portlet.dynamicdatamapping.model.DDMTemplate;
import com.liferay.portlet.dynamicdatamapping.service.DDMStructureLocalServiceUtil;
import com.liferay.portlet.dynamicdatamapping.service.DDMTemplateLocalServiceUtil;
import com.liferay.portlet.journal.model.JournalArticle;
import com.liferay.portlet.journal.service.JournalArticleLocalServiceUtil;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

public class KnowledgeBaseHelper {
	public static String[] ASSET_TAG_NAMES = PropsUtil.getArray("jioc.article");
	private static final String FILE_PATH=GetterUtil.getString(PropsUtil.get("jioc.file.path"));
	private static final String FOLDER_NAME=GetterUtil.getString(PropsUtil.get("jioc.dl.knowledgebase.folder"));
	private static final Log LOGGER = LogFactoryUtil.getLog(KnowledgeBaseHelper.class);
	public static final long STRUCTURE_ID = GetterUtil.getLong(PropsUtil.get("jioc.structure.id"));
	public static final long TEMPLATE_ID = GetterUtil.getLong(PropsUtil.get("jioc.template.id"));
	private static Pattern _friendlyURLPattern = Pattern.compile("[^a-z0-9_-]");
	
	public static void processCSV(ActionRequest actionRequest, ActionResponse actionResponse) {
		
		//TODO getCSVRecords
		//TODO processCSVRecord
			//GetFile
			//uploadContent
		//TODO showFinalStatus
		//TODO cleanup
		
		ThemeDisplay themeDisplay = (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		DDMStructure ddmStructure = KnowledgeBaseHelper.getDDMStructure(STRUCTURE_ID);
		DDMTemplate ddmTemplate = KnowledgeBaseHelper.getDDMTemplate(TEMPLATE_ID);
		
		if(Validator.isNull(ddmStructure)){
			LOGGER.info("No Structure found for structureId "+STRUCTURE_ID);
			return;
		}
		if(Validator.isNull(ddmTemplate)){
			LOGGER.info("No Template found for templateId "+TEMPLATE_ID);
			return;
		}
		
		UploadRequest request = PortalUtil.getUploadPortletRequest(actionRequest);
        File file = request.getFile(KnowledgeBaseConstant.FILENAME);
       
        FileReader fileReader = null;
        CSVParser csvFileParser = null;
        List<String> success = new ArrayList<String>();
		List<String> failure = new ArrayList<String>();
		List<String> failureFile = new ArrayList<String>();
        try {
        	CSVFormat csvFileFormat = CSVFormat.DEFAULT.withHeader().withDelimiter(',');
            fileReader = new FileReader(file);
			csvFileParser = new CSVParser(fileReader, csvFileFormat);
			List<CSVRecord> csvRecords = csvFileParser.getRecords();
			
			for (int i = 0; i < csvRecords.size(); i++) {
				CSVRecord record = csvRecords.get(i);
				
                String title = record.get("Title");
                //String description = record.get("Description");
                String keywords = record.get("Keywords");
                String oc_name = record.get("OC_Name");
                String uploadedBy = record.get("Uploaded_By");
                String upload_date = record.get("Uploaded_Date");
                String fileName= record.get("File_Name");
                String kbId = record.get("KB_ID");
                
                User user = null;
                long userId = 0;
	            try {
	            	user = UserLocalServiceUtil.getUserByScreenName(themeDisplay.getCompanyId(), uploadedBy);
	              	userId= user.getUserId();
	            } catch (PortalException e1) {
	            	LOGGER.error("error occurred while getting user by screenName");
	            } catch (SystemException e1) {
	            	LOGGER.error("error occurred while getting user by screenName");
	            }
	            
	            if(userId > 0){
	            	JournalArticle article = getArticle(actionRequest, actionResponse,title,themeDisplay);
	            	String fileURL = getFileURL(actionRequest, actionResponse, fileName);
	            	if(Validator.isNull(fileURL)){
	            		failureFile.add(fileName);
	            	}
	                boolean isProcessed  = processRecord(themeDisplay,ddmStructure,ddmTemplate,title,keywords,oc_name,userId,upload_date,fileURL,article);
	                if(isProcessed){
	                	success.add(kbId+" "+title);
	                } else {
	                	failure.add(kbId+" "+title);
	                }
                }else{
                	failure.add(kbId+" "+title);
                }
			}
        }catch (FileNotFoundException e) {
        	LOGGER.error("Error occurred during fileReader");
		} catch (IOException e) {
			LOGGER.error("Error occurred during fileReader");
		}finally {
               try {
                     if(fileReader !=null){
                            fileReader.close();
                     }
                     if(csvFileParser !=null){
                            csvFileParser.close();
                     }
               } catch (IOException e) {
                     LOGGER.error("Error occurred during closing stream");
               }
               LOGGER.info(" ================================================= SUCCESS =========================================================");
               LOGGER.info("Success Count : "+success.size());
               for (String s : success) {
            	   LOGGER.info(s);
               }
               LOGGER.info("Success Count : "+success.size());
               LOGGER.info("\n");
               
               LOGGER.info(" ================================================= FAILURE =========================================================");
               LOGGER.info("Failure Count : "+failure.size());
               for (String f : failure) {
            	   LOGGER.info(f);
               }
               LOGGER.info("Failure Count : "+failure.size());
               LOGGER.info("================ FAILER FILE ==========");
               LOGGER.info("Failure Count : "+failureFile.size());
               for (String failedFile : failureFile) {
				LOGGER.info("Failed File :"+failedFile);
               }
               
		}
    }
	

	private static JournalArticle getArticle(ActionRequest actionRequest,ActionResponse actionResponse, String title,ThemeDisplay themeDisplay) {
		
		title = FriendlyURLNormalizerUtil.normalize(title, _friendlyURLPattern);
		JournalArticle article = null;
		try {
			article = JournalArticleLocalServiceUtil.getArticleByUrlTitle(themeDisplay.getScopeGroupId(), title);
		} catch (PortalException e) {
			LOGGER.info("Exception occured while getting article by title");
		} catch (SystemException e) {
			LOGGER.info("Exception occured while getting article by title");
		}
		return article;
	}


	private static String getFileURL(ActionRequest actionRequest,ActionResponse response, String fileName) {
		String fileURL = StringPool.BLANK;
		if(Validator.isNotNull(fileName)){
				FileEntry fileEntry = getFile(actionRequest, response, fileName);
				if(Validator.isNotNull(fileEntry)) {
					fileURL="/documents/" + fileEntry.getGroupId() + StringPool.SLASH + fileEntry.getFolderId() + StringPool.SLASH + fileEntry.getTitle() + StringPool.SLASH + fileEntry.getUuid();
				}
		}
		return fileURL;
	}

	private static boolean processRecord(ThemeDisplay themeDisplay,DDMStructure ddmStructure,DDMTemplate ddmTemplate,String title,
			String keywords,String oc_name,long userId,String upload_date,String fileURL,JournalArticle article) {
	    boolean success = false;
	    DateFormat dateFormate=new SimpleDateFormat("dd-MMM-yy");
	    Date createDate = null;
		try {
			createDate = dateFormate.parse(upload_date);
		} catch (ParseException e1) {
			LOGGER.error("error occurred while parse upload date");
		}
		
		Map<Locale,String> titleMap=new HashMap<Locale,String>();
	    titleMap.put(themeDisplay.getLocale(), title);
		String content = "<root available-locales=\"en_US\" default-locale=\"en_US\"> <dynamic-element name=\"keywords\" type=\"text\" index-type=\"keyword\" index=\"0\"> <dynamic-content language-id=\"en_US\"><![CDATA["+keywords+"]]></dynamic-content> </dynamic-element> <dynamic-element name=\"Select8781\" type=\"list\" index-type=\"keyword\" index=\"0\"> <dynamic-content language-id=\"en_US\"><![CDATA["+oc_name+"]]></dynamic-content> </dynamic-element> <dynamic-element name=\"documents_file\" type=\"document_library\" index-type=\"keyword\" index=\"0\"> <dynamic-content language-id=\"en_US\"><![CDATA["+fileURL+"]]></dynamic-content> </dynamic-element> </root>";
		
		ServiceContext serviceContext = new ServiceContext();
	    serviceContext.setScopeGroupId(themeDisplay.getScopeGroupId());
		serviceContext.setAssetTagNames(ASSET_TAG_NAMES);
		serviceContext.setCreateDate(createDate);
		serviceContext.setAddGroupPermissions(true);
		
	    try {
	    	if(Validator.isNotNull(article)){
	    		article.setContent(content);
	    		JournalArticleLocalServiceUtil.updateJournalArticle(article);
	    	}else{
	    		JournalArticle journalarticle = JournalArticleLocalServiceUtil.addArticle(userId, themeDisplay.getScopeGroupId(), DLFolderConstants.DEFAULT_PARENT_FOLDER_ID, titleMap, null, content, ddmStructure.getStructureKey(), ddmTemplate.getTemplateKey(), serviceContext);
	    	}
	    	
			
			success = true;
		} catch (PortalException e) {
			System.out.println("error get by journalArticle"+e.getMessage());
		} catch (SystemException e) {
			System.out.println("error get by journalArticle"+e.getMessage());
		}
		return success;
	}
	
	public static DDMStructure getDDMStructure(long structureId){
		DDMStructure structure = null;
		try {
			 structure=DDMStructureLocalServiceUtil.getDDMStructure(structureId);
		} catch (PortalException e) {
			System.out.println("error get in ddmstructure"+e.getMessage());
		} catch (SystemException e) {
			System.out.println("error get in ddmstructure"+e.getMessage());
		}
		return structure;
	}
	
	public static DDMTemplate getDDMTemplate(long templateId){
		DDMTemplate template = null;
		try {
			template=DDMTemplateLocalServiceUtil.getDDMTemplate(templateId);
		} catch (PortalException e) {
			System.out.println("error get in ddmstructure"+e.getMessage());
		} catch (SystemException e) {
			System.out.println("error get in ddmstructure"+e.getMessage());
		}
		return template;
	}
	
	public static FileEntry getFile(ActionRequest request,ActionResponse response,String fileName){
		ThemeDisplay themeDisplay = (ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
		long groupId=themeDisplay.getLayout().getGroupId();
		long parentFolderId=DLFolderConstants.DEFAULT_PARENT_FOLDER_ID;
		
		String filepath =PropsUtil.get(PropsKeys.LIFERAY_HOME)+File.separator+"data"+File.separator+FILE_PATH+File.separator+fileName;
		boolean isExists = new File(filepath).exists();
		File sourceFile = new File(filepath);
		
		if(!isExists || Validator.isNull(sourceFile)){
			LOGGER.error("No file found at path : "+filepath);
			return null;
		}
		FileEntry fileEntry =null;
		DLFolder dir=null;
		
		try{
			dir=DLFolderLocalServiceUtil.getFolder(groupId, parentFolderId, FOLDER_NAME);
		}catch(Exception e){
			LOGGER.error("Error while getting folder ::> "+e.getMessage());
		}
		
		if(Validator.isNull(dir)){
			long repositoryId=themeDisplay.getScopeGroupId();
			try {
				ServiceContext serviceContext=ServiceContextFactory.getInstance(DLFileShortcut.class.getName(), request);
				serviceContext.setAddGuestPermissions(true);
				dir=DLFolderServiceUtil.addFolder(groupId, repositoryId, false, parentFolderId, FOLDER_NAME, null, serviceContext);
			} catch (PortalException e) {
				LOGGER.error("Error while adding folder ::> "+e.getMessage());
			} catch (SystemException e) {	
				LOGGER.error("Error while adding folder ::> "+e.getMessage());
			}
		}
		
		
		
		try {
			ServiceContext serviceContext=ServiceContextFactory.getInstance(DLFileShortcut.class.getName(), request);
			serviceContext.setAddGuestPermissions(true);
			Folder folder = DLAppLocalServiceUtil.getFolder(dir.getFolderId());
			FileEntry oldFileEntry = getFileEntry(groupId, folder, fileName);
			if(Validator.isNotNull(oldFileEntry)){
				fileEntry = DLAppLocalServiceUtil.updateFileEntry(themeDisplay.getUserId(), oldFileEntry.getFileEntryId(), fileName, MimeTypesUtil.getContentType(sourceFile), fileName, StringPool.BLANK, StringPool.BLANK, false, sourceFile, serviceContext);
			}else{
				fileEntry = DLAppLocalServiceUtil.addFileEntry(themeDisplay.getUserId(), folder.getRepositoryId(), folder.getFolderId(), fileName, MimeTypesUtil.getContentType(sourceFile), fileName, StringPool.BLANK, StringPool.BLANK, sourceFile, serviceContext);
			}
			
		} catch (PortalException e) {
			LOGGER.error("Error while adding fileEntry ::> "+e.getMessage());
		} catch (SystemException e) {
			LOGGER.error("Error while adding fileEntry ::> "+e.getMessage());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return fileEntry;
	}
	
	
	public static FileEntry getFileEntry(long groupId, Folder folder, String fileName){
		FileEntry oldFileEntry = null;
		try {
			oldFileEntry = DLAppLocalServiceUtil.getFileEntry(groupId, folder.getFolderId(), fileName);
		} catch (PortalException e) {
			
		} catch (SystemException e) {
			
		}
		return oldFileEntry;
	}
	
	
}
