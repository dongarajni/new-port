package com.lep.search.util;

public class SearchConstants {
	public static String PROP_COMMON_TIMESTAMP_FORMAT_OUTPUT 	= "COMMON.TIMESTAMP.FORMAT.OUTPUT";
	
}
