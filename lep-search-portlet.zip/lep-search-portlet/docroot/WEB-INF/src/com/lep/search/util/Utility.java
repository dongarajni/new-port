package com.lep.search.util;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.util.portlet.PortletProps;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Utility {
	
	private static Log LOGGER = LogFactoryUtil.getLog(Utility.class.getName());
	
	public static String formatDisplayDate(Date date){
		String dateStr = "";
		try{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(PortletProps.get(SearchConstants.PROP_COMMON_TIMESTAMP_FORMAT_OUTPUT));
			if(Validator.isNotNull(date)){
				dateStr = simpleDateFormat.format(date);
			}
		}catch(Exception e){
			LOGGER.error("Exception while formatting display date " + e.getMessage());
		}
		
		return dateStr;
	}
}
