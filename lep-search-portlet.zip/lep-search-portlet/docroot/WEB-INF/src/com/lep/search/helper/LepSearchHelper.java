package com.lep.search.helper;

import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.language.LanguageUtil;
import com.liferay.portal.kernel.search.Document;
import com.liferay.portal.kernel.search.Field;
import com.liferay.portal.kernel.search.Hits;
import com.liferay.portal.kernel.search.Indexer;
import com.liferay.portal.kernel.search.IndexerRegistryUtil;
import com.liferay.portal.kernel.search.QueryConfig;
import com.liferay.portal.kernel.search.SearchContext;
import com.liferay.portal.kernel.search.SearchContextFactory;
import com.liferay.portal.kernel.search.SearchException;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.HtmlUtil;
import com.liferay.portal.kernel.util.ListUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.xml.DocumentException;
import com.liferay.portal.kernel.xml.Node;
import com.liferay.portal.kernel.xml.SAXReaderUtil;
import com.liferay.portal.service.GroupLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.PortletURLUtil;
import com.liferay.portlet.journal.model.JournalArticle;
import com.liferay.portlet.journal.service.JournalArticleLocalServiceUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;


public class LepSearchHelper {
	
	public static void getJournalSearchDetails(RenderRequest request,
			RenderResponse response){
		
		long articleGroupId = ParamUtil.getLong(request, "articleGroupId");
		String articleId = ParamUtil.getString(request, "articleId");
		String keyword = ParamUtil.getString(request, "keyword");
		request.setAttribute("keyword", keyword);
		JournalArticle journalArticle= null;
		try {
			journalArticle = JournalArticleLocalServiceUtil.getArticle(articleGroupId, articleId);
			
			String content = journalArticle.getContent();
//			System.out.println("Content==="+content);
			
			com.liferay.portal.kernel.xml.Document document = SAXReaderUtil.read(content);
			
			Node xPathDescription = document.selectSingleNode("/root/dynamic-element[@name='description']/dynamic-content");
			Node xPathKeywords = document.selectSingleNode("/root/dynamic-element[@name='keywords']/dynamic-content");
			Node xPathOCTag = document.selectSingleNode("/root/dynamic-element[@name='Select8781']/dynamic-content");
			
			
			List<Node> xPathDocumentFiles = document.selectNodes("/root/dynamic-element[@name='documents_file']/dynamic-content");
			
			request.setAttribute("documents", xPathDocumentFiles);
			
//			for (Node node : xPathDocumentFiles) {
//				System.out.println("node===++"+node.getText());
//			}
			
			String description ="";
			String keywords = "";
			if(Validator.isNotNull(xPathDescription)){
				description = xPathDescription.getText();
			}
			String[] queryTerms = (String[]) request.getAttribute("queryTerms"); 
			if(Validator.isNotNull(xPathKeywords)){
				keywords = xPathKeywords.getText();
				keywords = StringUtil.highlight(keywords, queryTerms);
			}
			String ocTag = xPathOCTag.getText();
			
			request.setAttribute("description", description);
			request.setAttribute("keywords", keywords);
			request.setAttribute("ocTag", ocTag);
			request.setAttribute("modifiedDate", journalArticle.getModifiedDate());
			
		} catch (PortalException e) {
			e.printStackTrace();
		} catch (SystemException e) {
			e.printStackTrace();
		}catch (DocumentException e) {
			e.printStackTrace();
		}
		
	}
	

	public static void getJournalSearchResults(RenderRequest request,
			RenderResponse response){
		ThemeDisplay themeDisplay = (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
		
		HttpServletRequest originalRequest = PortalUtil.getHttpServletRequest(request);
		String keywords = ParamUtil.getString(request, "keywords");
		keywords = StringPool.QUOTE + keywords + StringPool.QUOTE;
		request.setAttribute("keyword", keywords);
		//System.out.println("keywords==="+keywords);
		if(Validator.isNull(keywords)){
			SessionMessages.add(request, "success");
			return;
		}
		PortletURL portletURL = response.createRenderURL();
		portletURL = PortletURLUtil.getCurrent(request, response);
		Indexer indexer = IndexerRegistryUtil.getIndexer(JournalArticle.class);
		SearchContainer<JournalArticle> searchContainer = new SearchContainer<JournalArticle>(request, null, null, SearchContainer.DEFAULT_CUR_PARAM, SearchContainer.DEFAULT_DELTA, 
				portletURL, null, LanguageUtil.format(themeDisplay.getLocale(), "no-pages-were-found-that-matched-the-keywords-x", "<strong>" + HtmlUtil.escape(keywords) + "</strong>"));

		SearchContext searchContext = SearchContextFactory.getInstance(originalRequest);
		
		//searchContext.setAttribute("articleType", type);
//		long[] groupId= {24201} ;
		
		String strTagname = "article";
		String[] tagName = new String[] {strTagname};
		searchContext.setGroupIds(null);
		searchContext.setAssetTagNames(tagName);
		searchContext.setKeywords(keywords);
		
		QueryConfig queryConfig = new QueryConfig();
		
		queryConfig.setHighlightEnabled(true);

		searchContext.setQueryConfig(queryConfig);
	
		Hits hits = null;
		int total = 0;
		String[] queryTerms = null;
		try {
			hits = indexer.search(searchContext);

//			System.out.println("hits=="+hits);
			queryTerms = hits.getQueryTerms();
			total = hits.getLength();
//			System.out.println("Total==="+total);
			
		} catch (SearchException e) {
			e.printStackTrace();
		}

		List<Document> results = ListUtil.toList(hits.getDocs());
		
		List<JournalArticle> journals = new ArrayList<JournalArticle>();
		
		for (int i = 0; i < results.size(); i++) {
			Document doc = results.get(i);
			
			long articleGroupId = GetterUtil.getLong(doc.get(Field.GROUP_ID));
			String articleId = doc.get("articleId");
			
			try {
				JournalArticle journalArticle = JournalArticleLocalServiceUtil.getLatestArticle(articleGroupId, articleId);
				journals.add(journalArticle);
				
				String groupFriendlyUrl = GroupLocalServiceUtil.getGroup(journalArticle.getGroupId()).getFriendlyURL();
				request.setAttribute("groupFriendlyUrl", groupFriendlyUrl);
			} catch (PortalException e) {
				
				e.printStackTrace();
			} catch ( SystemException e) {
				
				e.printStackTrace();
			}
		}
		
		Collections.sort(journals, new Comparator<JournalArticle>(){
			public int compare(JournalArticle a1, JournalArticle a2) {
				// TODO Auto-generated method stub
				return a1.getModifiedDate().compareTo(a2.getModifiedDate());
			}
			
		});
		
		Collections.reverse(journals);
		//System.out.println("Journals list===="+journals);
		
		List<JournalArticle> subLists = ListUtil.subList(journals, searchContainer.getStart(), searchContainer.getEnd());
 		searchContainer.setResults(subLists);
 		searchContainer.setTotal(total);
		searchContainer.setDeltaConfigurable(true);
		request.setAttribute("searchContainer", searchContainer);
		request.setAttribute("queryTerms", queryTerms);
	}

}
