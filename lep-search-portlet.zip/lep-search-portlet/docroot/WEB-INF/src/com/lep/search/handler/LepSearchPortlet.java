package com.lep.search.handler;

import com.lep.search.helper.LepSearchHelper;
import com.liferay.portal.kernel.util.Constants;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

import java.io.IOException;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

public class LepSearchPortlet extends MVCPortlet {

	
	@Override
	public void render(RenderRequest request, RenderResponse response)
			throws PortletException, IOException {
		
		String cmd=ParamUtil.getString(request, Constants.CMD);
//		System.out.println("cmd=="+cmd);
		if(cmd.equals("details")){
			LepSearchHelper.getJournalSearchDetails(request, response);
		}else{
			LepSearchHelper.getJournalSearchResults(request,response);
		}
		
		
		super.render(request, response);
	}
}
