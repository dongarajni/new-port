create table jioc_Article (
	articleId LONG not null primary key,
	title VARCHAR(75) null,
	description VARCHAR(75) null,
	createdBy LONG,
	createDate DATE null,
	modifiedDate DATE null
);

create table jioc_CASE_RES_MST (
	CASE_RES_ID LONG not null primary key,
	CASE_RES_NAME VARCHAR(75) null,
	IS_ACTIVE INTEGER,
	OC VARCHAR(75) null,
	UPDATED_TIMESTAMP DATE null
);

create table jioc_EMP_DETAILS (
	EMP_ID VARCHAR(10) not null primary key,
	AREA VARCHAR(80) null,
	CADRE VARCHAR(10) null,
	CLIENT_ID VARCHAR(5) null,
	COMPANY_CODE VARCHAR(10) null,
	COMPANY_TEXT VARCHAR(100) null,
	DATE_OF_BIRTH DATE null,
	DATE_OF_JOINING DATE null,
	DATE_OF_LEAVE DATE null,
	DEPARTMENT VARCHAR(255) null,
	DESIGNATION_CODE VARCHAR(10) null,
	DESIGNATION_TEXT VARCHAR(100) null,
	EMAIL VARCHAR(200) null,
	EMP_GROUP VARCHAR(10) null,
	EMPLOYEE_DOMAIN_ID VARCHAR(200) null,
	EMPLOYMENT_STATUS VARCHAR(5) null,
	EMPLOYMENT_STATUS_TEXT VARCHAR(30) null,
	FIRST_NAME VARCHAR(80) null,
	FULL_NAME VARCHAR(170) null,
	GENDER_TEXT VARCHAR(10) null,
	HR_EMAIL VARCHAR(200) null,
	HR_EMP_CD VARCHAR(10) null,
	HR_HEAD_EMPCD VARCHAR(10) null,
	HR_HEAD_NAME VARCHAR(200) null,
	HR_NAME VARCHAR(200) null,
	JIO_CENTER VARCHAR(80) null,
	JIO_ID VARCHAR(20) null,
	JO_REGION VARCHAR(255) null,
	JO_TYPE VARCHAR(80) null,
	JOB VARCHAR(100) null,
	JOB_ROLE_CODE VARCHAR(20) null,
	L1_EMAIL_ID VARCHAR(200) null,
	L1_EMPLOYEE_CODE VARCHAR(10) null,
	L1_NAME VARCHAR(200) null,
	LAST_NAME VARCHAR(80) null,
	LOCATION_CITY VARCHAR(100) null,
	LOCATION_CODE VARCHAR(10) null,
	LOCATION_COUNTRY VARCHAR(100) null,
	LOCATION_STATE VARCHAR(100) null,
	LOCATION_TEXT VARCHAR(100) null,
	MOBILE_NO VARCHAR(80) null,
	OFFICE_NO VARCHAR(80) null,
	ORG_UNIT VARCHAR(20) null,
	ORG_UNIT_TEXT VARCHAR(150) null,
	PERSONNEL_AREA_CODE VARCHAR(15) null,
	R4G_STATE VARCHAR(80) null,
	SAML_FEDERATION_ID VARCHAR(255) null,
	STORE_CODE VARCHAR(255) null,
	SUB_FUNCTIONAL_AREA VARCHAR(150) null,
	TITLE VARCHAR(15) null,
	IS_RESOLVER INTEGER,
	RESOLVER_LEVEL INTEGER,
	PERSONAL_AREA_TEXT VARCHAR(80) null,
	FUNCTIONAL_AREA VARCHAR(80) null,
	RESOLVER_STATUS INTEGER
);

create table jioc_Emp_User_Mapping (
	userId LONG not null primary key,
	empId VARCHAR(75) null,
	emailId VARCHAR(75) null,
	domainId VARCHAR(75) null,
	samlFederationId VARCHAR(75) null,
	status INTEGER
);

create table jioc_OC_CAT_MST (
	CAT_ID LONG not null primary key,
	CAT_NAME VARCHAR(75) null,
	HPSM_GROUP VARCHAR(75) null,
	IS_ACTIVE INTEGER,
	OC VARCHAR(75) null,
	RESOLVER_LEVEL INTEGER,
	UPDATED_TIMESTAMP DATE null
);

create table jioc_OC_JOB_FUNCTION_MST (
	OC_JOB_FUNCTION_ID LONG not null primary key,
	FUNCTIONAL_AREA VARCHAR(75) null,
	JOB VARCHAR(75) null,
	OC VARCHAR(75) null,
	SUB_FUNCTIONAL_AREA VARCHAR(75) null
);

create table jioc_OC_SUB_CAT_MST (
	SUB_CAT_ID LONG not null primary key,
	CAT_ID LONG,
	IS_ACTIVE INTEGER,
	SUB_CAT_NAME VARCHAR(75) null,
	UPDATED_TIMESTAMP DATE null
);

create table jioc_QUERY_MOD_DEFAULTS (
	QUERY_MOD_DEFAULTS_ID INTEGER not null primary key,
	CURR_VAL VARCHAR(75) null,
	NEW_VAL VARCHAR(75) null,
	IS_ACTIVE INTEGER,
	UPDATED_TIMESTAMP DATE null,
	TYPE VARCHAR(75) null,
	CURR_LEVEL INTEGER
);

create table jioc_Query_Add_Param_OC (
	queryAddParamOCId LONG not null primary key,
	OC VARCHAR(75) null,
	status INTEGER,
	updatedTimestamp DATE null
);

create table jioc_Query_Attachments (
	AttachmentId LONG not null primary key,
	fileEntryId LONG,
	updatedBy LONG,
	updatedTimestamp DATE null,
	queryId LONG,
	file_name VARCHAR(75) null
);

create table jioc_Query_Details (
	queryDetailsId LONG not null primary key,
	queryId LONG,
	updatedTimestamp DATE null,
	updatedBy LONG,
	assignedTo LONG,
	action VARCHAR(75) null,
	status VARCHAR(75) null,
	state_ VARCHAR(75) null,
	region VARCHAR(75) null,
	oc VARCHAR(75) null,
	queueLevel INTEGER,
	comment_ VARCHAR(1000) null,
	category LONG,
	subCategory LONG,
	caseResolution LONG,
	is_closed INTEGER,
	closed_date DATE null
);

create table jioc_Query_Transaction (
	queryId LONG not null primary key,
	caseNo VARCHAR(20) null,
	description VARCHAR(2000) null,
	raisedTimestamp DATE null,
	raisedById LONG,
	toDisplay INTEGER,
	orn_no VARCHAR(50) null,
	caf_no VARCHAR(20) null,
	customer_MSISDN VARCHAR(15) null,
	amt_request LONG,
	amt_done LONG,
	raised_by_email VARCHAR(50) null,
	pcId VARCHAR(20) null,
	ack INTEGER,
	source VARCHAR(4) null,
	ack_timestamp DATE null,
	assignment_group VARCHAR(75) null,
	ISACTIVE INTEGER
);

create table jioc_Query_Txn (
	queryId LONG not null primary key,
	caseNo VARCHAR(75) null,
	description VARCHAR(75) null,
	raisedBy VARCHAR(75) null,
	raisedTimestamp DATE null,
	lastUpdatedTimestamp DATE null,
	status VARCHAR(75) null,
	oc VARCHAR(75) null,
	state_ VARCHAR(75) null,
	region VARCHAR(75) null,
	queueName VARCHAR(75) null,
	queueLevel INTEGER,
	assignedTo VARCHAR(75) null
);

create table jioc_RESOLVER_DEFAULTS (
	DEFAULT_ID LONG not null primary key,
	RESOLVER_LEVEL_ID LONG,
	TYPE VARCHAR(75) null,
	VALUE VARCHAR(75) null,
	TO_DISPLAY INTEGER
);

create table jioc_RESOLVER_DEFAULTS_4_OC (
	DEFAULT_ID LONG not null primary key,
	RESOLVER_LEVEL_ID LONG,
	OC VARCHAR(75) null
);

create table jioc_RESOLVER_LEVEL_MST (
	LEVEL_ID LONG not null primary key,
	LEVEL_NAME VARCHAR(75) null,
	RESOLVER_LEVEL INTEGER
);

create table jioc_Setup (
	setup_id LONG not null primary key,
	key_ VARCHAR(50) null,
	val1 VARCHAR(200) null,
	val2 VARCHAR(200) null,
	status INTEGER,
	updated_timestamp DATE null
);