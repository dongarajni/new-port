create index IX_928A61FC on jioc_Article (description);
create index IX_70004BD8 on jioc_Article (title);
create index IX_7A462854 on jioc_Article (title, description);

create index IX_E5A3860C on jioc_EMP_DETAILS (DATE_OF_JOINING);
create index IX_1EF2286B on jioc_EMP_DETAILS (DEPARTMENT);
create index IX_F14054AB on jioc_EMP_DETAILS (EMP_ID);
create index IX_8D0F9A0 on jioc_EMP_DETAILS (EMP_ID, FULL_NAME);
create index IX_330BC708 on jioc_EMP_DETAILS (JOB);
create index IX_F382431F on jioc_EMP_DETAILS (JO_TYPE);

create index IX_E04A8C24 on jioc_Emp_User_Mapping (emailId);
create index IX_83884E10 on jioc_Emp_User_Mapping (empId);

create index IX_DBE3683C on jioc_OC_JOB_FUNCTION_MST (AREA, JOB, SUB_FUNCTIONAL_AREA);
create index IX_72791CD8 on jioc_OC_JOB_FUNCTION_MST (FUNCTIONAL_AREA, JOB, SUB_FUNCTIONAL_AREA);

create index IX_4699F98E on jioc_QUERY_MOD_DEFAULTS (TYPE, CURR_VAL);
create index IX_54546A5D on jioc_QUERY_MOD_DEFAULTS (TYPE, CURR_VAL, IS_ACTIVE);
create index IX_C6C9E6A8 on jioc_QUERY_MOD_DEFAULTS (TYPE, CURR_VAL, IS_ACTIVE, CURR_LEVEL);

create index IX_3B1F5AC0 on jioc_Query_Attachments (queryId);
create index IX_6608D941 on jioc_Query_Attachments (queryId, fileEntryId);

create index IX_214BE6E on jioc_Query_Details (queryId);

create index IX_79EB62E3 on jioc_Query_Transaction (pcId);
create index IX_905C991F on jioc_Query_Transaction (raisedById);

create index IX_1224E2EE on jioc_RESOLVER_DEFAULTS (TYPE, VALUE);

create index IX_3216604D on jioc_RESOLVER_DEFAULTS_4_OC (OC);

create index IX_2EAB828B on jioc_Setup (key_);
create index IX_1D700671 on jioc_Setup (key_, status);