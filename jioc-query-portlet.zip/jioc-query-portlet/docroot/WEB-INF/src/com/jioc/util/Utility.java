package com.jioc.util;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.util.mail.MailEngine;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Random;

import javax.mail.internet.InternetAddress;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

public class Utility {
	
	private static Log _log = LogFactoryUtil.getLog(Utility.class.getName());
	
	public static XMLGregorianCalendar getCurrentXMLGregorianCalendar(){
		GregorianCalendar gregorianCalendar = new GregorianCalendar();
		XMLGregorianCalendar XMLGregorianCalendar = null;
		try {
			gregorianCalendar.setTime(new Date());
			XMLGregorianCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
		} catch (Exception e) {
			_log.error("Exception while getting current XMLGregorianCalendar " + e.getMessage());
		}
		
		return XMLGregorianCalendar;
	}
	
	public static boolean isStringNotEmpty(String str){
		if(Validator.isNotNull(str) && !str.equals("")){
			return true;
		}
		return false;
	}
	
	public static int generateRandomNumber(int length){
		Random rand = new Random();
		return rand.nextInt(length) + 1;
	}
	
	public static String createUniqueFileName(String fileName, String id){
		String uniqueFileName = fileName;
		if(Validator.isNotNull(fileName) && Validator.isNotNull(id) && fileName.contains(".")){
			//uniqueFileName = fileName.substring(0, fileName.indexOf(".")) + "_" + id + fileName.substring(fileName.indexOf("."), fileName.length());
			uniqueFileName = fileName.substring(0, fileName.indexOf(".")) + "_" + id + "_" + generateRandomNumber(1000) + "_"+ fileName.substring(fileName.indexOf("."), fileName.length());
		}
		
		return uniqueFileName;
	}
	
	public static boolean isValidMimeType(String uploadedMimeType){
		boolean isValidMimeType = false;
		List<String> allowedMimeTypes = new ArrayList<String>(Arrays.asList(PropsUtil.getArray(QueryConstants.QUERY_ATTACHMENT_MIME_TYPES)));
		if(Validator.isNotNull(allowedMimeTypes) && allowedMimeTypes.size() > 0 && Validator.isNotNull(uploadedMimeType) && allowedMimeTypes.contains(uploadedMimeType)){
			isValidMimeType = true;
		}
		return isValidMimeType;
	}
	
	public static boolean allowUnauthorisedWSAccess(String serviceName) {
		String allowUnauthorisedAccess = null;
		if(QueryConstants.SERVICE_NAME_PUSH_TICKET.equalsIgnoreCase(serviceName)){
			allowUnauthorisedAccess = PropsUtil.get("jioc.query.ws.push.ticket.allow.unauthorised");
		}else if(QueryConstants.SERVICE_NAME_GET_COUNTER.equalsIgnoreCase(serviceName)){
			allowUnauthorisedAccess = PropsUtil.get("jioc.query.ws.get.counter.allow.unauthorised");
		}
        
        
        return "true".equalsIgnoreCase(allowUnauthorisedAccess);
	}
	
	public static boolean validateWSKey(String serviceName, String clientAPIKey) {
		boolean validKey = false;
		try{
			String allowedAPIKey = null;
			if(QueryConstants.SERVICE_NAME_PUSH_TICKET.equalsIgnoreCase(serviceName)){
				allowedAPIKey = PropsUtil.get("jioc.query.ws.push.ticket.api.key");
			}else if(QueryConstants.SERVICE_NAME_GET_COUNTER.equalsIgnoreCase(serviceName)){
				allowedAPIKey = PropsUtil.get("jioc.query.ws.get.counter.api.key");
			}
			
			if(Validator.isNotNull(allowedAPIKey) && clientAPIKey.equals(allowedAPIKey)){
				validKey = true;
			}
		}catch(Exception e){
			_log.error("Exception while validating WSKey "+e.getMessage());
		}
        return validKey;
	}

	public static boolean validateAllowedIP4WS(String serviceName, String clientIP) {
	    String []allowedHosts = null;
	    if(QueryConstants.SERVICE_NAME_PUSH_TICKET.equalsIgnoreCase(serviceName)){
	    	allowedHosts = PropsUtil.getArray("jioc.query.ws.push.ticket.allowed.hosts");
	    }else if(QueryConstants.SERVICE_NAME_GET_COUNTER.equalsIgnoreCase(serviceName)){
	    	allowedHosts = PropsUtil.getArray("jioc.query.ws.get.counter.allowed.hosts");
	    }
	    
	    boolean isValid = false;
	    for (String host : allowedHosts) {
	       try {
	         InetAddress add = InetAddress.getByName(host);
	         String allowedIP = add.getHostAddress();
	         if(allowedIP.equalsIgnoreCase(clientIP)){
	            isValid = true;
	            break;
	         }
	       } catch (UnknownHostException e) {
	    	   _log.error("Exception while validating allowed IP for WS "+e.getMessage());
	       }
	    }
	    return isValid;
	}
	
	public static void sendEmail(String fromAddress, String toAddress, String subject, String body) {
		try {
			InternetAddress from = new InternetAddress(fromAddress);
			InternetAddress to = new InternetAddress(toAddress);
			
			MailEngine.send(from, to, subject, body, Boolean.TRUE);
			_log.info("Email sent");
		} catch (Exception e) {
			_log.error("Error while sending email "+e.getMessage());
		}
	}
	
	public static String formatDisplayDate(Date date, String format){
		String dateStr = "";
		try{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
			if(Validator.isNotNull(date)){
				dateStr = simpleDateFormat.format(date);
			}
		}catch(Exception e){
			_log.error("Exception while formatting date " + e.getMessage());
		}
		
		return dateStr;
	}

}
