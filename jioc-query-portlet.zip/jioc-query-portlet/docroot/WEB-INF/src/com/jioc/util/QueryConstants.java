package com.jioc.util;

import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portlet.documentlibrary.model.DLFolderConstants;
import com.liferay.util.ContentUtil;
import com.liferay.util.portlet.PortletProps;

public class QueryConstants {
	public static final String SERVICE_STATUS_SUCCESS = "SUCCESS";
	public static final String SERVICE_STATUS_FAILURE = "FAILURE";
	
	public static final String QUERY_STATUS_OPEN   = "OPEN";
	public static final String QUERY_STATUS_CLOSE  = "CLOSE";
	
	public static final String QUERY_ACTION_CREATE   = "CREATE";
	public static final String QUERY_ACTION_ESCALATE = "ESCALATE";
	public static final String QUERY_ACTION_REOPEN   = "REOPEN";
	public static final String QUERY_ACTION_RESOLVE  = "RESOLVE";
	public static final String QUERY_ACTION_CLOSE    = "CLOSE";
	
	public static final int QUEUE_LEVEL_STATE_OC  = 1;
	public static final int QUEUE_LEVEL_STATE     = 2;
	public static final int QUEUE_LEVEL_REGION_OC = 3;
	public static final int QUEUE_LEVEL_REGION    = 4;
	public static final int QUEUE_LEVEL_OC        = 5;
	public static final int QUEUE_LEVEL_BA        = 6;
	
	public static final String OC        	  		= "OC";
	public static final String OC_FTTX        		= "FTTX";
	public static final String OC_JIO_MONEY   		= "JIO MONEY";
	public static final String OC_APPLICATIONS 		= "APPLICATIONS";
	public static final String OC_ANY_OTHER   		= "ANY OTHER";
	public static final String JOTYPE	   	  		= "JOTYPE";
	public static final String JOTYPE_NHQ   	  	= "NHQ";
	public static final String JOTYPE_REGION_OFFICE = "REGION OFFICE";
	
	public static final String REGION = "REGION";
	public static final String REGION_NHQ = "NHQ";
	
	public static final String CIRCLE = "CIRCLE";
	public static final String CIRCLE_STATE = "STATE";
	public static final String CIRCLE_REGION = "REGION";
	
	public static final String RESOLVER_DEFAULTS_DEFAULT   = "DEFAULT";
	
	public static final int TO_DISPLAY_ALL = 1;
	public static final int TO_DISPLAY_ABOVE_STATE = 0;
	
	
	// Query
	public static String ROOT_FOLDER_NAME 				= PortletProps.get("query.attachments.folder.name"); 
	public static String ROOT_FOLDER_DESCRIPTION 		= PortletProps.get("query.attachments.folder.description"); 
	public static long PARENT_FOLDER_ID 				= DLFolderConstants.DEFAULT_PARENT_FOLDER_ID;
	public static String QUERY_ATTACHMENT_EXTENSIONS 	= "query.attachment.extensions";
	public static String QUERY_ATTACHMENT_MIME_TYPES 	= "query.attachment.mime.types";
	public static String QUERY_ATTACHMENT_MAX_SIZE 		= "query.attachment.max.size";
	public static int QUERY_ACTIVE 						= 1;
	public static int QUERY_INACTIVE 					= 0;
	
	public static int QUERY_MOD_DEFAULTS_ACTIVE 		= 1;
	
	public static final String QUERY_SOURCE_JC = "JC";
	public static final String QUERY_SOURCE_PC = "PC";
	
	public static String PROP_COMMON_DATE_FORMAT_INPUT  = "COMMON.DATE.FORMAT.INPUT";
	public static String PROP_COMMON_DATE_FORMAT_OUTPUT = "COMMON.DATE.FORMAT.OUTPUT";
	
	//Query Email
	public static final String QUERY_MAIL_DATE_FORMAT 			= GetterUtil.getString(PortletProps.get("query.mail.date.format"));
	public static final boolean QUERY_SEND_MAIL_ON 				= GetterUtil.getBoolean(PropsUtil.get("jioc.query.sendemail"), Boolean.TRUE);
	public static final String FROM_MAIL_ID 					= GetterUtil.getString(PropsUtil.get("sender.email.address"));
	
	public static final String EMAIL_TMPL_QUERY_RAISED_SUB_CREATOR 		= ContentUtil.get("/templates/email_tmpl_query_raised_sub_creator.tmpl");
	public static final String EMAIL_TMPL_QUERY_RAISED_BODY_CREATOR 	= ContentUtil.get("/templates/email_tmpl_query_raised_body_creator.tmpl");
	
	public static final String EMAIL_TMPL_QUERY_ASSIGNED_SUB_RESOLVER 	= ContentUtil.get("/templates/email_tmpl_query_assigned_sub_resolver.tmpl");
	public static final String EMAIL_TMPL_QUERY_ASSIGNED_BODY_RESOLVER 	= ContentUtil.get("/templates/email_tmpl_query_assigned_body_resolver.tmpl");
	
	
	// pushticket
	public static String SERVICE_ERR_CODE_INVALID_QUERY_STATUS  = "SERVICE.ERR.CODE.INVALID.QUERY.STATUS";
	public static String SERVICE_ERR_MSG_INVALID_QUERY_STATUS  = "SERVICE.ERR.MSG.INVALID.QUERY.STATUS";
	
	public static String SERVICE_ERR_CODE_SERVICE_FAILED  = "SERVICE.ERR.CODE.SERVICE.FAILED";
	public static String SERVICE_ERR_MSG_SERVICE_FAILED  = "SERVICE.ERR_MSG.SERVICE.FAILED";
	
	public static String SERVICE_ERR_CODE_TICKET_ALREADY_RAISED  = "SERVICE.ERR.CODE.TICKET.ALREADY.RAISED";
	public static String SERVICE_ERR_MSG_TICKET_ALREADY_RAISED  = "SERVICE.ERR.MSG.TICKET.ALREADY.RAISED";
	
	public static String SERVICE_ERR_CODE_INVALID_EMPLOYEE_EMAIL  = "SERVICE.ERR.CODE.INVALID.EMPLOYEE.EMAIL";
	public static String SERVICE_ERR_MSG_INVALID_EMPLOYEE_EMAIL  = "SERVICE.ERR.MSG.INVALID.EMPLOYEE.EMAIL";
	
	public static String SERVICE_ERR_CODE_INVALID_INPUT  = "SERVICE.ERR.CODE.INVALID.INPUT";
	public static String SERVICE_ERR_MSG_INVALID_INPUT  = "SERVICE.ERR.MSG.INVALID.INPUT";
	
	public static String SERVICE_ERR_CODE_UNAUTHORISED_ACCESS  = "SERVICE.ERR.CODE.UNAUTHORISED.ACCESS";
	public static String SERVICE_ERR_MSG_UNAUTHORISED_ACCESS  = "SERVICE.ERR.MSG.UNAUTHORISED.ACCESS";
	
	public static String QUERY_SOURCE_PARTNER_CENTRAL  = "Partner Central";
	
	// HPSM
	public static String HPSM_INCIDENT_ENDPOINT_ADDRESS_PROPERTY 	= "HPSM.INCIDENT.ENDPOINT.ADDRESS.PROPERTY";
	public static String HPSM_INCIDENT_USERNAME_PROPERTY 			= "HPSM.INCIDENT.USERNAME.PROPERTY";
	public static String HPSM_INCIDENT_PASSWORD_PROPERTY 			= "HPSM.INCIDENT.PASSWORD.PROPERTY";
	public static String HPSM_CREATE_QUERY_SUCCESS_MSG 				= "HPSM.CREATE.QUERY.SUCCESS.MSG";
	public static String HPSM_QUERY_ASSIGNMENT_GROUP 				= "HPSM_QUERY_ASSIGNMENT_GROUP";
	public static String HPSM_INCIDENT_WSDL_NAME 					= "HPSM.INCIDENT.WSDL.NAME";
	public static String HPSM_INCIDENT_CREATE 						= "HPSM.INCIDENT.CREATE";
	
	// Setup
	public static int SETUP_STATUS_ACTIVE   = 1;
	public static int SETUP_STATUS_INACTIVE = 0;
	
	//QUERY WS
	public static String SERVICE_NAME_PUSH_TICKET = "SERVICE_NAME_PUSH_TICKET";
	public static String SERVICE_NAME_GET_COUNTER = "SERVICE_NAME_GET_COUNTER";
	public static String GET_COUNTER_QUERY_DETAILS = "QUERY_DETAILS";
	public static String SERVICE_ERR_CODE_COUNTER_NOT_GENERATED  = "SERVICE.ERR.CODE.COUNTER.NOT.GENERATED";
	public static String SERVICE_ERR_MSG_COUNTER_NOT_GENERATED  = "SERVICE.ERR.MSG.COUNTER_NOT_GENERATED";
	
}


