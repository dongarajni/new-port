package com.jioc.controller;

import com.jioc.beans.CreateJioCentralIncRequestBean;
import com.jioc.beans.CreateJioCentralIncResponseBean;
import com.jioc.beans.QueryBean;
import com.jioc.hpsm.inc.CreateJioCentralIncRequest;
import com.jioc.hpsm.inc.CreateJioCentralIncResponse;
import com.jioc.hpsm.inc.JioCentralInc;
import com.jioc.hpsm.inc.JioCentralIncInstanceType;
import com.jioc.hpsm.inc.JioCentralIncKeysType;
import com.jioc.hpsm.inc.JioCentralIncModelType;
import com.jioc.hpsm.inc.JioCentralInc_Service;
import com.jioc.hpsm.inc.ObjectFactory;
import com.jioc.query.model.EMP_DETAILS;
import com.jioc.query.model.Setup;
import com.jioc.query.service.EMP_DETAILSLocalServiceUtil;
import com.jioc.query.service.Emp_User_MappingLocalServiceUtil;
import com.jioc.query.service.SetupLocalServiceUtil;
import com.jioc.util.QueryConstants;
import com.jioc.util.Utility;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.util.portlet.PortletProps;

import javax.portlet.ActionRequest;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.BindingProvider;

//import com.jio.model.Emp_Details;

public class HPSMIncHelper {
	
	private static Log _log = LogFactoryUtil.getLog(HPSMIncHelper.class.getName());

	//public static CreateJioCentralIncResponseBean createIncInHPSM(ActionRequest request) {
	public static CreateJioCentralIncResponseBean createIncInHPSM(QueryBean queryBean) {
		
	/*CreateJioCentralResponseBean createQueryInHPSM(ActionRequest request)
	{*/
		CreateJioCentralIncResponseBean createJioCentralIncResponseBean = null;
	
		try {
			ObjectFactory objectFactory = new ObjectFactory();
			CreateJioCentralIncRequest serviceRequest = new CreateJioCentralIncRequest();
			JioCentralInc service = new JioCentralInc_Service().getPort(JioCentralInc.class);
			JioCentralIncModelType modelType = objectFactory.createJioCentralIncModelType();
			JioCentralIncKeysType keysType = objectFactory.createJioCentralIncKeysType();
			
			BindingProvider provider = (BindingProvider)service;
			provider = initBindingProvider(provider);
			
			CreateJioCentralIncRequestBean createJioCentralIncRequestBean = new CreateJioCentralIncRequestBean(objectFactory);
			createJioCentralIncRequestBean = initCreateJioCentralIncRequestBean(createJioCentralIncRequestBean, queryBean);
			
			//set parameters in request
			if(Validator.isNotNull(createJioCentralIncRequestBean)){
				JioCentralIncInstanceType instance = createJioCentralIncInstanceType(createJioCentralIncRequestBean);
				keysType.setIncidentID(createJioCentralIncRequestBean.getIncidentID());
				modelType.setKeys(keysType);
				modelType.setInstance(instance);
				serviceRequest.setModel(modelType);
				
				//call service
				CreateJioCentralIncResponse response = service.createJioCentralInc(serviceRequest);
				createJioCentralIncResponseBean= createJioCentralIncResponseBean(response);	
				
				/*System.out.println("response:"+createJioCentralIncResponseBean.getStatus());
				System.out.println("error:"+createJioCentralIncResponseBean.getErrorMessage());*/
			}
			else{
				_log.info("Not raising incident");
			}
			
		
		}
		catch(Exception e) {
			_log.error("Exception while calling raise incident service ", e);
		}
		
		return createJioCentralIncResponseBean;
	}

	private static CreateJioCentralIncRequestBean initCreateJioCentralIncRequestBean(CreateJioCentralIncRequestBean createJioCentralIncRequestBean, QueryBean queryBean){
		EMP_DETAILS empDetails = null;
		//XMLGregorianCalendar XMLGregorianCalendar = null;
		try {
			//ThemeDisplay themeDisplay = (ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
			//XMLGregorianCalendar = Utility.getCurrentXMLGregorianCalendar();
			empDetails = EMP_DETAILSLocalServiceUtil.getEMP_DETAILS(Emp_User_MappingLocalServiceUtil.getEmp_User_Mapping(queryBean.getUser().getUserId()).getEmpId());
			
			if(Validator.isNotNull(empDetails)) {
				createJioCentralIncRequestBean.getIncidentID().getValue().setValue("");
				createJioCentralIncRequestBean.getCategory().getValue().setValue("Incident");
				createJioCentralIncRequestBean.getContact().getValue().setValue(queryBean.getUser().getScreenName());
				createJioCentralIncRequestBean.getOpenedBy().getValue().setValue("");//Jio-Central
				createJioCentralIncRequestBean.getUpdatedBy().getValue().setValue("");//Jio-Central				
				createJioCentralIncRequestBean.getSeverity().getValue().setValue("4");
				createJioCentralIncRequestBean.getUserPriority().getValue().setValue("4");
				createJioCentralIncRequestBean.getInitialImpact().getValue().setValue("4");
				createJioCentralIncRequestBean.getService().getValue().setValue("Others");
				createJioCentralIncRequestBean.getBriefDescription().getValue().setValue(String.valueOf(queryBean.getQueryId()));
				Setup setup = SetupLocalServiceUtil.findSetupByKey(QueryConstants.HPSM_QUERY_ASSIGNMENT_GROUP);
								
				if(Validator.isNotNull(setup) && Validator.isNotNull(setup.getVal1())){
					createJioCentralIncRequestBean.getPrimaryAssignmentGroup().getValue().setValue(setup.getVal1());
				}else{
					_log.info("Default Assignment Group not found in setup");
				}
			
				createJioCentralIncRequestBean.getIncidentDescription().getIncidentDescription().get(0).setValue(queryBean.getQueryDescription());				
				createJioCentralIncRequestBean.getSubcategory().getValue().setValue("JioCentral");
				createJioCentralIncRequestBean.getProductType().getValue().setValue("JioCentral");
				//createJioCentralIncRequestBean.getJournalUpdates().getJournalUpdates().get(0).setValue("");
				//createJioCentralIncRequestBean.getTicketOwner().getValue().setValue("");
				//createJioCentralIncRequestBean.getIMTicketStatus().getValue().setValue("");
				//createJioCentralIncRequestBean.getOpenTime().getValue().setValue(XMLGregorianCalendar);
				//createJioCentralIncRequestBean.getUpdatedTime().getValue().setValue(XMLGregorianCalendar);							

				queryBean.setEmpId(empDetails.getEMP_ID());
				queryBean.setSamlFederationId(empDetails.getSAML_FEDERATION_ID());
				queryBean.setEmpMobile(empDetails.getMOBILE_NO());
			}else{
				createJioCentralIncRequestBean = null;
				_log.info("User details not found");
			}
		}
		catch(Exception e) {
			createJioCentralIncRequestBean = null;
			_log.error("Exception while creating CreateJioCentralIncRequestBean ", e);
		}
		
		return createJioCentralIncRequestBean;
	}
	
	private static JioCentralIncInstanceType createJioCentralIncInstanceType(CreateJioCentralIncRequestBean createJioCentralIncRequestBean) {
		JioCentralIncInstanceType instance = new JioCentralIncInstanceType();
		
		instance.setIncidentID(createJioCentralIncRequestBean.getIncidentID());
		instance.setCategory(createJioCentralIncRequestBean.getCategory());
		instance.setOpenTime(createJioCentralIncRequestBean.getOpenTime());
		instance.setOpenedBy(createJioCentralIncRequestBean.getOpenedBy());
		instance.setSeverity(createJioCentralIncRequestBean.getSeverity());
		instance.setUpdatedTime(createJioCentralIncRequestBean.getUpdatedTime());
		instance.setPrimaryAssignmentGroup(createJioCentralIncRequestBean.getPrimaryAssignmentGroup());
		instance.setIncidentDescription(createJioCentralIncRequestBean.getIncidentDescription());
		instance.setContact(createJioCentralIncRequestBean.getContact());
		instance.setJournalUpdates(createJioCentralIncRequestBean.getJournalUpdates());
		instance.setBriefDescription(createJioCentralIncRequestBean.getBriefDescription());
		instance.setTicketOwner(createJioCentralIncRequestBean.getTicketOwner());
		instance.setUpdatedBy(createJioCentralIncRequestBean.getUpdatedBy());
		instance.setIMTicketStatus(createJioCentralIncRequestBean.getIMTicketStatus());
		instance.setSubcategory(createJioCentralIncRequestBean.getSubcategory());
		instance.setProductType(createJioCentralIncRequestBean.getProductType());
		instance.setProblemType(createJioCentralIncRequestBean.getProblemType());
		instance.setUserPriority(createJioCentralIncRequestBean.getUserPriority());
		instance.setInitialImpact(createJioCentralIncRequestBean.getInitialImpact());
		instance.setService(createJioCentralIncRequestBean.getService());
		
		return instance;
	}
	
	private static CreateJioCentralIncResponseBean createJioCentralIncResponseBean(CreateJioCentralIncResponse response) {
		CreateJioCentralIncResponseBean createJioCentralIncResponseBean = new CreateJioCentralIncResponseBean();
		createJioCentralIncResponseBean.setIncidentId(response.getModel().getInstance().getIncidentID().getValue().getValue());
		createJioCentralIncResponseBean.setStatus(response.getStatus().value());
		createJioCentralIncResponseBean.setErrorMessage(response.getMessage());
		
		return createJioCentralIncResponseBean;
	}

	private static BindingProvider initBindingProvider(BindingProvider provider){
		provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, PropsUtil.get(QueryConstants.HPSM_INCIDENT_ENDPOINT_ADDRESS_PROPERTY));
		provider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, PropsUtil.get(QueryConstants.HPSM_INCIDENT_USERNAME_PROPERTY));
		provider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, PropsUtil.get(QueryConstants.HPSM_INCIDENT_PASSWORD_PROPERTY));
		
		return provider;
	}
	
}
	