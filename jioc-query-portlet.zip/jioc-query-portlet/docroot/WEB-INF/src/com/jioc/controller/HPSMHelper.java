package com.jioc.controller;

import javax.portlet.ActionRequest;
import javax.xml.bind.JAXBElement;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;

import com.jioc.beans.CreateJioCentralRequestBean;
import com.jioc.beans.CreateJioCentralResponseBean;
import com.jioc.beans.UpdateJioCentralRequestBean;
import com.jioc.beans.UpdateJioCentralResponseBean;
import com.jioc.hpsm.AttachmentType;
import com.jioc.hpsm.BooleanType;
import com.jioc.hpsm.CreateJioCentralRequest;
import com.jioc.hpsm.CreateJioCentralResponse;
import com.jioc.hpsm.JioCentral;
import com.jioc.hpsm.JioCentralInstanceType;
import com.jioc.hpsm.JioCentralInstanceType.Assignment;
import com.jioc.hpsm.JioCentralInstanceType.Description;
import com.jioc.hpsm.JioCentralKeysType;
import com.jioc.hpsm.JioCentralModelType;
import com.jioc.hpsm.JioCentral_Service;
import com.jioc.hpsm.ObjectFactory;
import com.jioc.hpsm.StringType;
import com.jioc.hpsm.UpdateJioCentralRequest;
import com.jioc.hpsm.UpdateJioCentralResponse;
import com.jioc.query.model.EMP_DETAILS;
import com.jioc.query.model.Emp_User_Mapping;
import com.jioc.query.service.EMP_DETAILSLocalServiceUtil;
import com.jioc.query.service.Emp_User_MappingLocalServiceUtil;
import com.jioc.util.QueryConstants;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.upload.FileItem;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.util.portlet.PortletProps;

import java.io.File;
import java.io.FileInputStream;
import java.util.Map;
import java.util.Map.Entry;

public class HPSMHelper {
	
	private static Log _log = LogFactoryUtil.getLog(HPSMHelper.class.getName());
	
	public static CreateJioCentralResponseBean createQueryInHPSM(ActionRequest request) {
		CreateJioCentralResponseBean createJioCentralResponseBean = null;
		try{
			
			ObjectFactory objectFactory = new ObjectFactory();
			CreateJioCentralRequest serviceRequest = new CreateJioCentralRequest();
			JioCentral service = new JioCentral_Service().getPort(JioCentral.class);
			JioCentralModelType modelType = objectFactory.createJioCentralModelType();
			JioCentralKeysType keysType = objectFactory.createJioCentralKeysType();
			
			BindingProvider provider = (BindingProvider)service;
			//client1.setAttachmentData();
			
			provider = initBindingProvider(provider);
			
			//set parameters in request
			CreateJioCentralRequestBean createJioCentralRequestBean = new CreateJioCentralRequestBean(objectFactory);
			createJioCentralRequestBean = initCreateJioCentralRequestBean(createJioCentralRequestBean, request);
			if(Validator.isNotNull(createJioCentralRequestBean)){
				JioCentralInstanceType instance = createJioCentralInstanceType(createJioCentralRequestBean);
				keysType.setCallID(createJioCentralRequestBean.getCallId());
				modelType.setKeys(keysType);
				modelType.setInstance(instance);
				serviceRequest.setModel(modelType);
				
				//call service
				CreateJioCentralResponse response = service.createJioCentral(serviceRequest);
				createJioCentralResponseBean = createJioCentralResponseBean(response);
			}else{
				_log.info("Not raising query");
			}
			
		}catch(Exception e){
			_log.error("Exception while calling raise query service ", e);
		}
		return createJioCentralResponseBean;
	}
	
	private static BindingProvider initBindingProvider(BindingProvider provider){
		provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, PropsUtil.get(QueryConstants.HPSM_INCIDENT_ENDPOINT_ADDRESS_PROPERTY));
		provider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, PropsUtil.get(QueryConstants.HPSM_INCIDENT_USERNAME_PROPERTY));
		provider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, PropsUtil.get(QueryConstants.HPSM_INCIDENT_PASSWORD_PROPERTY));
		
		return provider;
	}
	
	private static CreateJioCentralRequestBean initCreateJioCentralRequestBean(CreateJioCentralRequestBean createJioCentralRequestBean, ActionRequest request){
		ThemeDisplay themeDisplay = (ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
		EMP_DETAILS empDetails;
		
		//System.out.println("in create req");
		
		try {
			
			empDetails = EMP_DETAILSLocalServiceUtil.getEMP_DETAILS(Emp_User_MappingLocalServiceUtil.getEmp_User_Mapping(themeDisplay.getUserId()).getEmpId());
		
			if(Validator.isNotNull(empDetails)){
				createJioCentralRequestBean.getOpenedBy().getValue().setValue(empDetails.getEMP_ID());
				createJioCentralRequestBean.getArea().getValue().setValue("JioCentral");
				createJioCentralRequestBean.getSiteCategory().getValue().setValue("JioCentral");
				createJioCentralRequestBean.getCategory().getValue().setValue("Incident");
				createJioCentralRequestBean.getSubarea().getValue().setValue("JioCentral");
				createJioCentralRequestBean.getImpact().getValue().setValue("4");
				createJioCentralRequestBean.getUrgency().getValue().setValue("1");
				createJioCentralRequestBean.getDescription().getDescription().get(0).setValue(ParamUtil.getString(request, "queryDescription"));
				createJioCentralRequestBean.getTitle().getValue().setValue("Jio Central Query Management System");
				createJioCentralRequestBean.getEnteredByESS().getValue().setValue(false);
				createJioCentralRequestBean.getAssignment().getAssignment().get(0).setValue("Resolver Group");
				createJioCentralRequestBean.getPriority().getValue().setValue("1");
				createJioCentralRequestBean.getNotifyBy().getValue().setValue("Portal");
				createJioCentralRequestBean.getServiceRecipient().getValue().setValue("OC Resolver");
				createJioCentralRequestBean.getAffectedService().getValue().setValue("Others");
				createJioCentralRequestBean.getCallerDepartment().getValue().setValue(empDetails.getDEPARTMENT());
				createJioCentralRequestBean.getCallerLocation().getValue().setValue(empDetails.getJO_TYPE());
				createJioCentralRequestBean.getProblemType().getValue().setValue("JioCentral");
				createJioCentralRequestBean.getCompany().getValue().setValue(empDetails.getCOMPANY_CODE());
				createJioCentralRequestBean.getContactEmail().getValue().setValue(themeDisplay.getUser().getEmailAddress());
				createJioCentralRequestBean.getLocationFullName().getValue().setValue(empDetails.getLOCATION_TEXT());
				createJioCentralRequestBean.getContactLastName().getValue().setValue(themeDisplay.getUser().getLastName());
				createJioCentralRequestBean.getCallId().getValue().setValue("");
				
				createJioCentralRequestBean.getContact().getValue().setValue(empDetails.getMOBILE_NO());
				createJioCentralRequestBean.getUpdate().getUpdate().get(0).setValue("JioCentral");
				createJioCentralRequestBean.getLocation().getValue().setValue(empDetails.getLOCATION_CODE());
				createJioCentralRequestBean.getContactFirstName().getValue().setValue(themeDisplay.getUser().getFirstName());
			}else{
				createJioCentralRequestBean = null;
				_log.info("User details not found");
			}
			
		
		} catch (Exception e) {
			createJioCentralRequestBean = null;
			_log.error("Exception while creating RaiseQuery request ", e);
		}
		
		return createJioCentralRequestBean;
	}
	
	private static JioCentralInstanceType createJioCentralInstanceType(CreateJioCentralRequestBean createJioCentralRequestBean){
		JioCentralInstanceType instance = new JioCentralInstanceType();
		
		instance.setOpenedBy(createJioCentralRequestBean.getOpenedBy());
		instance.setArea(createJioCentralRequestBean.getArea());
		instance.setSiteCategory(createJioCentralRequestBean.getSiteCategory());
		instance.setCategory(createJioCentralRequestBean.getCategory());
		instance.setSubarea(createJioCentralRequestBean.getSubarea());
		instance.setImpact(createJioCentralRequestBean.getImpact());
		instance.setUrgency(createJioCentralRequestBean.getUrgency());
		instance.setDescription(createJioCentralRequestBean.getDescription());
		instance.setTitle(createJioCentralRequestBean.getTitle());
		instance.setEnteredByESS(createJioCentralRequestBean.getEnteredByESS());
		instance.setAssignment(createJioCentralRequestBean.getAssignment());
		instance.setPriority(createJioCentralRequestBean.getPriority());
		instance.setNotifyBy(createJioCentralRequestBean.getNotifyBy());
		instance.setServiceRecipient(createJioCentralRequestBean.getServiceRecipient());
		instance.setAffectedService(createJioCentralRequestBean.getAffectedService());
		instance.setCallerDepartment(createJioCentralRequestBean.getCallerDepartment());
		instance.setCallerLocation(createJioCentralRequestBean.getCallerLocation());
		instance.setProblemType(createJioCentralRequestBean.getProblemType());
		instance.setCompany(createJioCentralRequestBean.getCompany());
		instance.setContactEmail(createJioCentralRequestBean.getContactEmail());
		instance.setLocationFullName(createJioCentralRequestBean.getLocationFullName());
		instance.setContactLastName(createJioCentralRequestBean.getContactLastName());
		
		return instance;
	}
	
	private static CreateJioCentralResponseBean createJioCentralResponseBean(CreateJioCentralResponse response){
		CreateJioCentralResponseBean createJioCentralResponseBean = new CreateJioCentralResponseBean();
		createJioCentralResponseBean.setCaseNo(response.getModel().getInstance().getCallID().getValue().getValue());
		createJioCentralResponseBean.setStatus(response.getStatus().value());
		createJioCentralResponseBean.setErrorMessage(response.getMessage());
		
		return createJioCentralResponseBean;
	}
	
	
	public static UpdateJioCentralResponseBean updateQueryInHPSM(ActionRequest request) {
		UpdateJioCentralResponseBean updateJioCentralResponseBean = null;
		try{
			
			ObjectFactory objectFactory = new ObjectFactory();
			UpdateJioCentralRequest serviceRequest = new UpdateJioCentralRequest();
			JioCentral service = new JioCentral_Service().getPort(JioCentral.class);
			JioCentralModelType modelType = objectFactory.createJioCentralModelType();
			JioCentralKeysType keysType = objectFactory.createJioCentralKeysType();
			
			BindingProvider provider = (BindingProvider)service;
			//client1.setAttachmentData();
			
			provider = initBindingProvider(provider);
			
			
			//set parameters in request
			UpdateJioCentralRequestBean updateJioCentralRequestBean = new UpdateJioCentralRequestBean(objectFactory);
			updateJioCentralRequestBean = initUpdateJioCentralRequestBean(updateJioCentralRequestBean, request, objectFactory);
			if(Validator.isNotNull(updateJioCentralRequestBean)){
				JioCentralInstanceType instance = updateJioCentralInstanceType(updateJioCentralRequestBean);
				keysType.setCallID(updateJioCentralRequestBean.getCallId());
				modelType.setKeys(keysType);
				modelType.setInstance(instance);
				serviceRequest.setModel(modelType);
				
				
				//call service
				UpdateJioCentralResponse response = service.updateJioCentral(serviceRequest);
				updateJioCentralResponseBean = updateJioCentralResponseBean(response);
				
				/*System.out.println("status:"+updateJioCentralResponseBean.getStatus());
				System.out.println("error:"+updateJioCentralResponseBean.getErrorMessage());*/
				
			}else{
				_log.info("Not raising query");
			}
			
		}catch(Exception e){
			_log.error("Exception while calling raise query service ", e);
		}
		return updateJioCentralResponseBean;
	}
	
	private static UpdateJioCentralRequestBean initUpdateJioCentralRequestBean(UpdateJioCentralRequestBean updateJioCentralRequestBean, ActionRequest request, ObjectFactory objectFactory){
		ThemeDisplay themeDisplay = (ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
		EMP_DETAILS empDetails;
		
		//System.out.println("in update req");
		
		AttachmentType attachmentType = null;
		
		try {
			UploadPortletRequest uploadPortletRequest = PortalUtil.getUploadPortletRequest(request);
			
			empDetails = EMP_DETAILSLocalServiceUtil.getEMP_DETAILS(Emp_User_MappingLocalServiceUtil.getEmp_User_Mapping(themeDisplay.getUserId()).getEmpId());
		
			if(Validator.isNotNull(empDetails)){
				updateJioCentralRequestBean.getOpenedBy().getValue().setValue(empDetails.getEMP_ID());
				updateJioCentralRequestBean.getArea().getValue().setValue("JioCentral");
				updateJioCentralRequestBean.getSiteCategory().getValue().setValue("JioCentral");
				updateJioCentralRequestBean.getCategory().getValue().setValue("Incident");
				updateJioCentralRequestBean.getSubarea().getValue().setValue("JioCentral");
				updateJioCentralRequestBean.getImpact().getValue().setValue("4");
				updateJioCentralRequestBean.getUrgency().getValue().setValue("1");
				updateJioCentralRequestBean.getDescription().getDescription().get(0).setValue(ParamUtil.getString(request, "queryDescription"));
				updateJioCentralRequestBean.getTitle().getValue().setValue("Jio Central Query Management System");
				updateJioCentralRequestBean.getEnteredByESS().getValue().setValue(false);
				updateJioCentralRequestBean.getAssignment().getAssignment().get(0).setValue("Resolver Group");
				updateJioCentralRequestBean.getPriority().getValue().setValue("1");
				updateJioCentralRequestBean.getNotifyBy().getValue().setValue("Portal");
				updateJioCentralRequestBean.getServiceRecipient().getValue().setValue("OC Resolver");
				updateJioCentralRequestBean.getAffectedService().getValue().setValue("Others");
				updateJioCentralRequestBean.getCallerDepartment().getValue().setValue(empDetails.getDEPARTMENT());
				updateJioCentralRequestBean.getCallerLocation().getValue().setValue(empDetails.getJO_TYPE());
				updateJioCentralRequestBean.getProblemType().getValue().setValue("JioCentral");
				updateJioCentralRequestBean.getCompany().getValue().setValue(empDetails.getCOMPANY_CODE());
				updateJioCentralRequestBean.getContactEmail().getValue().setValue(themeDisplay.getUser().getEmailAddress());
				updateJioCentralRequestBean.getLocationFullName().getValue().setValue(empDetails.getLOCATION_TEXT());
				updateJioCentralRequestBean.getContactLastName().getValue().setValue(themeDisplay.getUser().getLastName());
				updateJioCentralRequestBean.getCallId().getValue().setValue(ParamUtil.getString(uploadPortletRequest, "caseNo"));
				
				updateJioCentralRequestBean.getContact().getValue().setValue(empDetails.getMOBILE_NO());
				updateJioCentralRequestBean.getUpdate().getUpdate().get(0).setValue("JioCentral");
				updateJioCentralRequestBean.getLocation().getValue().setValue(empDetails.getLOCATION_CODE());
				updateJioCentralRequestBean.getContactFirstName().getValue().setValue(themeDisplay.getUser().getFirstName());
				
				
				
				//multiple files
				//long queryId = ParamUtil.getLong(request, "queryId");
				/*Map<String, FileItem[]> files= uploadPortletRequest.getMultipartParameterMap();
				for (Entry<String, FileItem[]> file2 : files.entrySet()) {
					FileItem item[] =file2.getValue();
					//_log.info("attaching "+item.length+" files for queryId:"+queryId);
					for (FileItem fileItem : item) {
						byte[] b = new byte[(int) fileItem.getSize()];
						//String title = fileItem.getFileName();
						fileItem.getInputStream().read(b);
						for (int i = 0; i < b.length; i++) {
	                        System.out.print((char)b[i]);
						}
						
					}
				}*/
				
				File file = uploadPortletRequest.getFile("uploadedFile");
				if(Validator.isNotNull(file) && file.exists()){
					byte[] b = new byte[(int) file.length()];
					char[] a = new char[(int) file.length()];
					StringBuilder sb = new StringBuilder("");
			        try {
			        	FileInputStream fileInputStream = new FileInputStream(file);
			        	fileInputStream.read(b);
			        	//System.out.println("b length:"+b.length);
			        	//System.out.println("file:");
			        	for (int i = 0; i < b.length; i++) {
			        		//System.out.print((char)b[i]);
			        		/*a[i] = (char)b[i];
			        		System.out.print(a[i]);*/
			        		sb.append(b[i]);
		                }
			        	
			        	attachmentType = objectFactory.createAttachmentType();
						attachmentType.setAttachmentType(sb.toString());
						updateJioCentralRequestBean.getAttachmentsType().getValue().getAttachment().add(attachmentType);
			        } catch (Exception e) {
			        	_log.error("Exception while getting file from request ", e);
			        }
					
					
				}else{
					_log.info("File not found in request");
				}
				
			}else{
				updateJioCentralRequestBean = null;
				_log.info("User details not found");
			}
			
		
		} catch (Exception e) {
			updateJioCentralRequestBean = null;
			_log.error("Exception while creating RaiseQuery request ", e);
		}
		
		return updateJioCentralRequestBean;
	}
	
	private static JioCentralInstanceType updateJioCentralInstanceType(UpdateJioCentralRequestBean updateJioCentralRequestBean){
		JioCentralInstanceType instance = new JioCentralInstanceType();
		
		instance.setOpenedBy(updateJioCentralRequestBean.getOpenedBy());
		instance.setArea(updateJioCentralRequestBean.getArea());
		instance.setSiteCategory(updateJioCentralRequestBean.getSiteCategory());
		instance.setCategory(updateJioCentralRequestBean.getCategory());
		instance.setSubarea(updateJioCentralRequestBean.getSubarea());
		instance.setImpact(updateJioCentralRequestBean.getImpact());
		instance.setUrgency(updateJioCentralRequestBean.getUrgency());
		instance.setDescription(updateJioCentralRequestBean.getDescription());
		instance.setTitle(updateJioCentralRequestBean.getTitle());
		instance.setEnteredByESS(updateJioCentralRequestBean.getEnteredByESS());
		instance.setAssignment(updateJioCentralRequestBean.getAssignment());
		instance.setPriority(updateJioCentralRequestBean.getPriority());
		instance.setNotifyBy(updateJioCentralRequestBean.getNotifyBy());
		instance.setServiceRecipient(updateJioCentralRequestBean.getServiceRecipient());
		instance.setAffectedService(updateJioCentralRequestBean.getAffectedService());
		instance.setCallerDepartment(updateJioCentralRequestBean.getCallerDepartment());
		instance.setCallerLocation(updateJioCentralRequestBean.getCallerLocation());
		instance.setProblemType(updateJioCentralRequestBean.getProblemType());
		instance.setCompany(updateJioCentralRequestBean.getCompany());
		instance.setContactEmail(updateJioCentralRequestBean.getContactEmail());
		instance.setLocationFullName(updateJioCentralRequestBean.getLocationFullName());
		instance.setContactLastName(updateJioCentralRequestBean.getContactLastName());
		instance.setCallID(updateJioCentralRequestBean.getCallId());
		
		instance.setContact(updateJioCentralRequestBean.getContact());
		instance.setUpdate(updateJioCentralRequestBean.getUpdate());
		instance.setLocation(updateJioCentralRequestBean.getLocation());
		instance.setContactFirstName(updateJioCentralRequestBean.getContactFirstName());
		instance.setAttachments(updateJioCentralRequestBean.getAttachmentsType());
		
		return instance;
	}
	
	private static UpdateJioCentralResponseBean updateJioCentralResponseBean(UpdateJioCentralResponse response){
		UpdateJioCentralResponseBean updateJioCentralResponseBean = new UpdateJioCentralResponseBean();
		updateJioCentralResponseBean.setCaseNo(response.getModel().getInstance().getCallID().getValue().getValue());
		updateJioCentralResponseBean.setStatus(response.getStatus().value());
		updateJioCentralResponseBean.setErrorMessage(response.getMessage());
		
		return updateJioCentralResponseBean;
	}
}
