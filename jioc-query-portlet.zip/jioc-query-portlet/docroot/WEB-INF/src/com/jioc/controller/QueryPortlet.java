package com.jioc.controller;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.LiferayPortletURL;
import com.liferay.portal.kernel.upload.FileItem;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.service.LayoutLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.PortletURLFactoryUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletMode;
import javax.portlet.PortletRequest;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;
import javax.servlet.http.HttpServletRequest;

public class QueryPortlet extends MVCPortlet{

	private static Log _log = LogFactoryUtil.getLog(QueryPortlet.class.getName());
	
	@Override
	public void doView(RenderRequest renderRequest,
			RenderResponse renderResponse) throws IOException, PortletException {
		
		QueryHelper.permissionChecker(renderRequest);
		
		super.doView(renderRequest, renderResponse);
	}
	
	
	public void searchSite(ActionRequest actionRequest, ActionResponse actionResponse) throws IOException, PortletException, PortalException, SystemException {

		String keyword = ParamUtil.getString(actionRequest, "keyword");

		ThemeDisplay themeDisplay = (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
	
//		long plid = themeDisplay.getPlid();
//		long plid = 24894 ;
		String portletId = "lepsearch_WAR_lepsearchportlet";
		long plid = PortalUtil.getPlidFromPortletId(themeDisplay.getScopeGroupId(), portletId);
//		System.out.println("pplid=="+plid);

		LiferayPortletURL portletURL = PortletURLFactoryUtil.create(actionRequest, portletId, plid , PortletRequest.RENDER_PHASE);
		portletURL.setWindowState(WindowState.NORMAL);
		portletURL.setPortletMode(PortletMode.VIEW);
		portletURL.setParameter("keywords", keyword);
		
		
		actionResponse.sendRedirect(portletURL.toString());

	}
	
	@Override
	public void render(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		ThemeDisplay themeDisplay = (ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
		String pageName = themeDisplay.getLayout().getName(themeDisplay.getLocale());
		//System.out.println("pageName:"+pageName);
		if("Article Search".equalsIgnoreCase(pageName)){
			HttpServletRequest httpRequest = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(request));
			//System.out.println("searchKey::"+httpRequest.getParameter("searchKey"));
			viewTemplate = "/html/query/search.jsp";
			
			QueryHelper.searchArticle(request, httpRequest.getParameter("searchKey"));
			
		}else{
			viewTemplate = "/html/query/view.jsp";
		}
		
		/*boolean isSearch = ParamUtil.getBoolean(request, "isSearch");
		if(isSearch){
			QueryHelper.searchArticle(request, ParamUtil.getString(request, "searchKey"));
		}*/
		
		//System.out.println("isRaiseQuery:"+request.getParameter("isRaiseQuery"));
		request.setAttribute("caseNo", request.getParameter("caseNo"));
		request.setAttribute("queryId", request.getParameter("queryId"));
		request.setAttribute("isRaiseQuery", request.getParameter("isRaiseQuery"));
		request.setAttribute("raiseQueryResponse", request.getParameter("raiseQueryResponse"));
		
		super.render(request, response);
	}
	
	public void raiseQuery(ActionRequest request, ActionResponse response){
		_log.info("Raise query request received");
		QueryHelper.raiseQuery(request, response);
		
	}
	
	public void attachDocument(ActionRequest request, ActionResponse response){
		_log.info("Attach document for query request received");
		QueryHelper.attachDocument(request, response);
		
	}
	
}
