package com.jioc.controller;

import com.jioc.beans.CreateJioCentralIncResponseBean;
import com.jioc.beans.CreateJioCentralResponseBean;
import com.jioc.beans.QueryBean;
import com.jioc.query.model.Article;
import com.jioc.query.model.EMP_DETAILS;
import com.jioc.query.model.Emp_User_Mapping;
import com.jioc.query.model.QUERY_MOD_DEFAULTS;
import com.jioc.query.model.Query_Attachments;
import com.jioc.query.model.Query_Details;
import com.jioc.query.model.Query_Transaction;
import com.jioc.query.model.RESOLVER_DEFAULTS;
import com.jioc.query.model.RESOLVER_LEVEL_MST;
import com.jioc.query.model.Setup;
import com.jioc.query.service.ArticleLocalServiceUtil;
import com.jioc.query.service.EMP_DETAILSLocalServiceUtil;
import com.jioc.query.service.Emp_User_MappingLocalServiceUtil;
import com.jioc.query.service.QUERY_MOD_DEFAULTSLocalServiceUtil;
import com.jioc.query.service.Query_Add_Param_OCLocalServiceUtil;
import com.jioc.query.service.Query_AttachmentsLocalServiceUtil;
import com.jioc.query.service.Query_DetailsLocalServiceUtil;
import com.jioc.query.service.Query_TransactionLocalServiceUtil;
import com.jioc.query.service.RESOLVER_DEFAULTSLocalServiceUtil;
import com.jioc.query.service.RESOLVER_LEVEL_MSTLocalServiceUtil;
import com.jioc.query.service.SetupLocalServiceUtil;
import com.jioc.util.QueryConstants;
import com.jioc.util.Utility;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.repository.model.Folder;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.security.permission.PermissionChecker;
import com.liferay.portal.service.RoleServiceUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.service.persistence.PortletUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.documentlibrary.model.DLFileEntry;
import com.liferay.portlet.documentlibrary.service.DLAppServiceUtil;
import com.liferay.util.mail.MailEngine;
import com.liferay.util.mail.MailEngineException;
import com.liferay.util.portlet.PortletProps;

import java.io.File;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.RenderRequest;

public class QueryHelper {
	private static Log _log = LogFactoryUtil.getLog(QueryHelper.class.getName());
	
	public static void permissionChecker(RenderRequest renderRequest) {
		try {
			ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
			PermissionChecker permissionChecker = themeDisplay.getPermissionChecker();
		
			renderRequest.setAttribute("permissionCheck", (permissionChecker.isOmniadmin() || RoleServiceUtil.hasUserRole(themeDisplay.getUserId(), themeDisplay.getCompanyId(), "Content Editor", true)));
		}  catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void searchArticle(RenderRequest request, String searchKey){
		//System.out.println("searchKey:"+searchKey);
		//List<Article> searchedArticles = ArticleLocalServiceUtil.findByArticleLike(searchKey);
		List<Article> searchedArticles = null;
		try {
			searchedArticles = ArticleLocalServiceUtil.getArticles(QueryUtil.ALL_POS, QueryUtil.ALL_POS);
		} catch (SystemException e) {
			e.printStackTrace();
		}
		
		request.setAttribute("searchedArticles", searchedArticles);
		//System.out.println("searchedArticles:"+searchedArticles);
		
	}
	
	public static void raiseQuery(ActionRequest request, ActionResponse response){
		try {
			ThemeDisplay themeDisplay = (ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
			QueryBean queryBean = new QueryBean();
			queryBean.setUser(themeDisplay.getUser());
			queryBean.setQueryDescription(ParamUtil.getString(request, "queryDescription"));
			queryBean.setSource(QueryConstants.QUERY_SOURCE_JC);
			
			Query_Transaction queryTransaction = addQueryTransactionEntity(queryBean);
			queryBean.setQueryId(queryTransaction.getQueryId());
			queryBean.setRaisedTimestamp(queryTransaction.getRaisedTimestamp());
			
			
			//CreateJioCentralResponseBean createJioCentralResponseBean = createQueryInHPSM(request);
			CreateJioCentralIncResponseBean createJioCentralIncResponseBean = createIncidentInHPSM(queryBean);
			if(Validator.isNotNull(createJioCentralIncResponseBean) && QueryConstants.SERVICE_STATUS_SUCCESS.equalsIgnoreCase(createJioCentralIncResponseBean.getStatus()) && Validator.isNotNull(createJioCentralIncResponseBean.getIncidentId())){
				request.setAttribute("caseNo", createJioCentralIncResponseBean.getIncidentId());
				queryBean.setIncidentId(createJioCentralIncResponseBean.getIncidentId());
				
				queryBean = saveQueryTransactionDetails(queryBean);
				
				response.setRenderParameter("queryId", String.valueOf(queryBean.getQueryId()));
				response.setRenderParameter("caseNo", createJioCentralIncResponseBean.getIncidentId());
				response.setRenderParameter("isRaiseQuery", "TRUE");
				
				String raiseQuerySuccessMsg = PortletProps.get(QueryConstants.HPSM_CREATE_QUERY_SUCCESS_MSG);
				if(Validator.isNotNull(raiseQuerySuccessMsg)){
					raiseQuerySuccessMsg = raiseQuerySuccessMsg.replace("#$$#", createJioCentralIncResponseBean.getIncidentId());
					response.setRenderParameter("raiseQueryResponse", raiseQuerySuccessMsg);
				}
				
				//SessionMessages.add(request, "request_processed", "Your Case No. :"+createJioCentralResponseBean.getCaseNo()+" has been created. Please note this for future reference.");
				
				// send email to query creator and resolver
				sendEmail_QueryRaised(queryBean);
				
			}else{
				SessionErrors.add(request, "request_processed", "Request failed");
			}
			
		} catch (Exception e) {
			_log.error("Exception while raising query ", e);
			SessionErrors.add(request, "request_processed", "Request failed");
		}
		
	}
	
	private static void sendEmail_QueryRaised(QueryBean queryBean) {
		try {
			if(QueryConstants.QUERY_SEND_MAIL_ON == true){
				sendEmail_QueryRaised_Creator(queryBean);
				sendEmail_QueryRaised_Resolver(queryBean);
				
			}else{
				_log.info("Email notification for case is off");
			}
		}catch(Exception e){
			_log.error("Exception while initiating case email "+e.getMessage());
		}
			
	}
	
	private static void sendEmail_QueryRaised_Creator(QueryBean queryBean) {		
		try {
			_log.info("Sending Email to Case Creator Case No.:"+String.valueOf(queryBean.getIncidentId()));
			
			String body = QueryConstants.EMAIL_TMPL_QUERY_RAISED_BODY_CREATOR;
			String subject = QueryConstants.EMAIL_TMPL_QUERY_RAISED_SUB_CREATOR;
			
			subject = StringUtil.replace(subject, new String[]{"[$CASE_NO$]"}, new String []{String.valueOf(queryBean.getIncidentId())});
			    
			String htmlBody =  new StringBuilder("<table border='0'>")
					.append("<tr><td>Case Number</td><td>:</td><td>").append(GetterUtil.getString(queryBean.getIncidentId())).append("</td></tr>")
					.append("<tr><td>Date/Time Opened</td><td>:</td><td>").append(Utility.formatDisplayDate(queryBean.getRaisedTimestamp(), QueryConstants.QUERY_MAIL_DATE_FORMAT)).append("</td></tr>")
					.append("<tr><td>Case Owner</td><td>:</td><td>").append(GetterUtil.getString(queryBean.getAssignedToName())).append("</td></tr>")
					.append("<tr><td>Case Owner Email ID</td><td>:</td><td>").append(GetterUtil.getString(queryBean.getAssignedToEmail())).append("</td></tr>")
					.append("<tr><td>Case Creator's Name</td><td>:</td><td>").append(GetterUtil.getString(queryBean.getUser().getFullName())).append("</td></tr>")
					.append("<tr><td>Case Creator's Email</td><td>:</td><td>").append(GetterUtil.getString(queryBean.getUser().getEmailAddress())).append("</td></tr>")
					.append("<tr><td>Case Creator's Mobile</td><td>:</td><td>").append(GetterUtil.getString(queryBean.getEmpMobile())).append("</td></tr>")
					.append("<tr><td>Case Creator's Employee Id</td><td>:</td><td>").append(GetterUtil.getString(queryBean.getSamlFederationId())).append("</td></tr>")
					.append("<tr><td>Case Details</td><td>:</td><td>").append(GetterUtil.getString(queryBean.getQueryDescription())).append("</td></tr>")
					.append("</table>").toString();
			
			body = StringUtil.replace(body, new String []{"[$USERNAME$]","[$CASE_DETAILS$]" }, new String []{queryBean.getUser().getFullName(), htmlBody});
			
			Utility.sendEmail(QueryConstants.FROM_MAIL_ID, queryBean.getUser().getEmailAddress(), subject, body);
			
		} catch (Exception e) {
			_log.error("Error while sending Email for case creation "+e.getMessage());
		}
	}
	
	private static void sendEmail_QueryRaised_Resolver(QueryBean queryBean) {			
		try {
			_log.info("Sending Email to Case Resolver Case No.:"+String.valueOf(queryBean.getIncidentId()));
			
			String body = QueryConstants.EMAIL_TMPL_QUERY_ASSIGNED_BODY_RESOLVER;
			String subject = QueryConstants.EMAIL_TMPL_QUERY_ASSIGNED_SUB_RESOLVER;
			
			subject = StringUtil.replace(subject, new String[]{"[$CASE_NO$]"}, new String []{String.valueOf(queryBean.getIncidentId())});
			    
			String htmlBody =  new StringBuilder("<table border='0'>")
					.append("<tr><td>Case Number</td><td>:</td><td>").append(GetterUtil.getString(queryBean.getIncidentId())).append("</td></tr>")
					.append("<tr><td>Date/Time Opened</td><td>:</td><td>").append(Utility.formatDisplayDate(queryBean.getRaisedTimestamp(), QueryConstants.QUERY_MAIL_DATE_FORMAT)).append("</td></tr>")
					.append("<tr><td>Case Creator's Name</td><td>:</td><td>").append(GetterUtil.getString(queryBean.getUser().getFullName())).append("</td></tr>")
					.append("<tr><td>Case Creator's Email</td><td>:</td><td>").append(GetterUtil.getString(queryBean.getUser().getEmailAddress())).append("</td></tr>")
					.append("<tr><td>Case Creator's Mobile</td><td>:</td><td>").append(GetterUtil.getString(queryBean.getEmpMobile())).append("</td></tr>")
					.append("<tr><td>Case Creator's Employee Id</td><td>:</td><td>").append(GetterUtil.getString(queryBean.getSamlFederationId())).append("</td></tr>")
					.append("<tr><td>Case Details</td><td>:</td><td>").append(GetterUtil.getString(queryBean.getQueryDescription())).append("</td></tr>")
					.append("</table>").toString();
			
			body = StringUtil.replace(body, new String []{"[$USERNAME$]","[$CASE_DETAILS$]" }, new String []{queryBean.getAssignedToName(), htmlBody});
			
			Utility.sendEmail(QueryConstants.FROM_MAIL_ID, queryBean.getAssignedToEmail(), subject, body);
			
		} catch (Exception e) {
			_log.error("Error while sending Email for case assignment "+e.getMessage());
		}
	}
	
	public static QueryBean raiseQueryExt(String pc_id, String emailId, String source, String description){
		Emp_User_Mapping empUserMapping = null;
		QueryBean queryBean = new QueryBean();
		Query_Transaction queryTransaction = null;
		//CreateJioCentralIncResponseBean createJioCentralIncResponseBean = null;
		try {
			if(Utility.isStringNotEmpty(pc_id) 
				&& Utility.isStringNotEmpty(emailId)
				&& Utility.isStringNotEmpty(source)
				&& Utility.isStringNotEmpty(description)){
					try{
						empUserMapping = Emp_User_MappingLocalServiceUtil.findEmpUserMappingByEmailId(emailId);
					}catch(Exception e){
						empUserMapping = null;
						_log.error("Emp_user_mapping not found for emailId:"+emailId);
					}
					
					if(Validator.isNotNull(empUserMapping)){
						User user = null;
						try{
							user = UserLocalServiceUtil.getUser(empUserMapping.getUserId());
						}catch(Exception e){
							user = null;
							_log.error("User not found for userid:"+empUserMapping.getUserId());
						}
						if(Validator.isNotNull(user)){
							queryBean.setUser(user);
							queryBean.setQueryDescription(description);
							queryBean.setSource(source.toUpperCase());
							queryBean.setEmpId(empUserMapping.getEmpId());
							queryBean.setPcId(pc_id);
							
							try{
								queryTransaction = Query_TransactionLocalServiceUtil.findQueryTransactionByPCId(pc_id);
							}catch(Exception e){
								_log.error("No queryTransaction found for pcId:"+pc_id);
							}
							
							if(Validator.isNull(queryTransaction) || (Validator.isNotNull(queryTransaction) && Validator.isNull(queryTransaction.getCaseNo()))){
								if(Validator.isNull(queryTransaction)){
									//saveQueryTransactionDetails(queryBean);
									queryTransaction = addQueryTransactionEntity(queryBean);
								}
								if(Validator.isNotNull(queryTransaction)){
									queryBean.setQueryId(queryTransaction.getQueryId());
									
									//CreateJioCentralResponseBean createJioCentralResponseBean = createQueryInHPSM(request);
									CreateJioCentralIncResponseBean createJioCentralIncResponseBean = createIncidentInHPSM(queryBean);
									if(Validator.isNotNull(createJioCentralIncResponseBean) && QueryConstants.SERVICE_STATUS_SUCCESS.equalsIgnoreCase(createJioCentralIncResponseBean.getStatus()) && Validator.isNotNull(createJioCentralIncResponseBean.getIncidentId())){
										queryBean.setIncidentId(createJioCentralIncResponseBean.getIncidentId());
										//saveQueryTransactionDetails(queryBean);
										
										try{
											//queryTransaction = Query_TransactionLocalServiceUtil.findQueryTransactionByPCId(pc_id);
											//if(Validator.isNotNull(queryTransaction)){
												/*queryTransaction.setCaseNo(createJioCentralIncResponseBean.getIncidentId());
												Query_TransactionLocalServiceUtil.updateQuery_Transaction(queryTransaction);*/
												
												saveQueryTransactionDetails(queryBean);
												
												queryBean.setServiceStatus(QueryConstants.SERVICE_STATUS_SUCCESS);
												queryBean.setServiceErrMsg("");
											/*}else{
												_log.info("No queryTransaction found for pcId:"+pc_id+". Invalid query status");
												queryBean.setServiceStatus(QueryConstants.SERVICE_STATUS_FAILURE);
												queryBean.setServiceErrMsg("Invalid query status");
											}*/
											
										}catch(Exception e){
											_log.error("Exception while updating query transaction and details for pcId:"+pc_id+". Invalid query status");
											queryBean.setServiceStatus(QueryConstants.SERVICE_STATUS_FAILURE);
											queryBean.setServiceErrCode(PortletProps.get(QueryConstants.SERVICE_ERR_CODE_INVALID_QUERY_STATUS));
											queryBean.setServiceErrMsg(PortletProps.get(QueryConstants.SERVICE_ERR_MSG_INVALID_QUERY_STATUS));
											//queryBean.setServiceErrMsg("Invalid query status");
										}
										
									}else{
										_log.info("Service failed");
										queryBean.setServiceStatus(QueryConstants.SERVICE_STATUS_FAILURE);
										queryBean.setServiceErrCode(PortletProps.get(QueryConstants.SERVICE_ERR_CODE_SERVICE_FAILED));
										queryBean.setServiceErrMsg(PortletProps.get(QueryConstants.SERVICE_ERR_MSG_SERVICE_FAILED));
										//queryBean.setServiceErrMsg("Service failed");
									}
								
								}else{
									_log.info("No queryTransaction found for pcId:"+pc_id+". Invalid query status");
									queryBean.setServiceStatus(QueryConstants.SERVICE_STATUS_FAILURE);
									queryBean.setServiceErrCode(PortletProps.get(QueryConstants.SERVICE_ERR_CODE_INVALID_QUERY_STATUS));
									queryBean.setServiceErrMsg(PortletProps.get(QueryConstants.SERVICE_ERR_MSG_INVALID_QUERY_STATUS));
									//queryBean.setServiceErrMsg("Invalid query status");
								}
							}else {
								_log.info("Case for ticket id:"+pc_id+" was already raised");
								queryBean.setServiceStatus(QueryConstants.SERVICE_STATUS_FAILURE);
								queryBean.setServiceErrCode(PortletProps.get(QueryConstants.SERVICE_ERR_CODE_TICKET_ALREADY_RAISED));
								queryBean.setServiceErrMsg(PortletProps.get(QueryConstants.SERVICE_ERR_MSG_TICKET_ALREADY_RAISED));
								//queryBean.setServiceErrMsg("Case for this ticket id was already raised");
							}
						}else{
							_log.info("Not raising query as User not found");
							queryBean.setServiceStatus(QueryConstants.SERVICE_STATUS_FAILURE);
							queryBean.setServiceErrCode(PortletProps.get(QueryConstants.SERVICE_ERR_CODE_INVALID_EMPLOYEE_EMAIL));
							queryBean.setServiceErrMsg(PortletProps.get(QueryConstants.SERVICE_ERR_MSG_INVALID_EMPLOYEE_EMAIL));
							//queryBean.setServiceErrMsg("Invalid employee email id");
						}
						
						
					}else{
						_log.info("Not raising query as EmpUserMapping not found");
						queryBean.setServiceStatus(QueryConstants.SERVICE_STATUS_FAILURE);
						queryBean.setServiceErrCode(PortletProps.get(QueryConstants.SERVICE_ERR_CODE_INVALID_EMPLOYEE_EMAIL));
						queryBean.setServiceErrMsg(PortletProps.get(QueryConstants.SERVICE_ERR_MSG_INVALID_EMPLOYEE_EMAIL));
						//queryBean.setServiceErrMsg("Invalid employee email id");
					}
			}else{
				_log.info("Not raising query for invalid input");
				queryBean.setServiceStatus(QueryConstants.SERVICE_STATUS_FAILURE);
				queryBean.setServiceErrCode(PortletProps.get(QueryConstants.SERVICE_ERR_CODE_INVALID_INPUT));
				queryBean.setServiceErrMsg(PortletProps.get(QueryConstants.SERVICE_ERR_MSG_INVALID_INPUT));
				//queryBean.setServiceErrMsg("Invalid input");
			}
			
		} catch (Exception e) {
			_log.error("Exception while raising query ", e);
			queryBean.setServiceStatus(QueryConstants.SERVICE_STATUS_FAILURE);
			queryBean.setServiceErrCode(PortletProps.get(QueryConstants.SERVICE_ERR_CODE_SERVICE_FAILED));
			queryBean.setServiceErrMsg(PortletProps.get(QueryConstants.SERVICE_ERR_MSG_SERVICE_FAILED));
			//queryBean.setServiceErrMsg("Service failed");
		}
		
		return queryBean;
	}
	
	private static QueryBean saveQueryTransactionDetails(QueryBean queryBean){
		Query_Transaction queryTransaction = updateQueryTransactionEntity(queryBean);
		if(Validator.isNotNull(queryTransaction)){
			//response.setRenderParameter("queryId", String.valueOf(queryTransaction.getQueryId()));
			queryBean.setQueryId(queryTransaction.getQueryId());
			queryBean = saveQueryDetailsEntity(queryBean, queryTransaction);
		}else{
			_log.info("unable to store query transaction");
		}
		
		return queryBean;
	}
	
	private static Query_Transaction updateQueryTransactionEntity(QueryBean queryBean){
		Query_Transaction queryTxn = null;
		try {
			queryTxn = Query_TransactionLocalServiceUtil.getQuery_Transaction(queryBean.getQueryId());
			queryTxn.setCaseNo(queryBean.getIncidentId());
			queryTxn.setISACTIVE(QueryConstants.QUERY_ACTIVE);
			
			queryTxn = Query_TransactionLocalServiceUtil.updateQuery_Transaction(queryTxn);
			
			_log.info("query transaction data updated for querId:"+queryTxn.getQueryId());
		} catch (Exception e) {
			queryTxn = null;
			_log.error("Exception while updating query transaction " + e.getMessage());
		}
		
		return queryTxn;
	}
	
	private static Query_Transaction addQueryTransactionEntity(QueryBean queryBean){
		Query_Transaction queryTxn = null;
		try {
			//ThemeDisplay themeDisplay = (ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
			Emp_User_Mapping empUserMapping = Emp_User_MappingLocalServiceUtil.getEmp_User_Mapping(queryBean.getUser().getUserId());
			EMP_DETAILS empDetails = EMP_DETAILSLocalServiceUtil.findEmpDetailsById(empUserMapping.getEmpId());
			
			queryTxn = Query_TransactionLocalServiceUtil.createQuery_Transaction(CounterLocalServiceUtil.increment(Query_Transaction.class.getName()));
			//queryTxn.setCaseNo(queryBean.getIncidentId());
			queryTxn.setDescription(queryBean.getQueryDescription());
			queryTxn.setRaisedById(queryBean.getUser().getUserId());
			queryTxn.setRaisedTimestamp(new Date());
			queryTxn.setToDisplay(getToDisplayVal(empDetails.getDEPARTMENT(), empDetails.getJO_TYPE()));
			queryTxn.setRaised_by_email(queryBean.getUser().getEmailAddress());
			queryTxn.setSource(queryBean.getSource());
			queryTxn.setPcId(queryBean.getPcId());
			queryTxn.setISACTIVE(QueryConstants.QUERY_INACTIVE);
			
			Setup setup = SetupLocalServiceUtil.findSetupByKey(QueryConstants.HPSM_QUERY_ASSIGNMENT_GROUP);
			if(Validator.isNotNull(setup) && Validator.isNotNull(setup.getVal1())){
				queryTxn.setAssignment_group(setup.getVal1());
			}else{
				_log.info("Default Assignment Group not found in setup");
			}
			
			queryTxn = Query_TransactionLocalServiceUtil.addQuery_Transaction(queryTxn);
			
			_log.info("query transaction data added for querId:"+queryTxn.getQueryId());
		} catch (Exception e) {
			queryTxn = null;
			_log.error("Exception while adding query transaction " + e.getMessage());
		}
		
		return queryTxn;
	}
	
	private static int getToDisplayVal(String oc, String joType){
		RESOLVER_DEFAULTS resolverDefault = null;
		//System.out.println("to display oc:"+oc+" joType:"+joType);
		int toDisplay = QueryConstants.TO_DISPLAY_ALL;
		
		/*if(Validator.isNotNull(oc) 
				&& Validator.isNotNull(region)
				&& (QueryConstants.OC_FTTX.equalsIgnoreCase(oc) 
						|| QueryConstants.OC_JIO_MONEY.equalsIgnoreCase(oc) 
						|| QueryConstants.OC_APPLICATIONS.equalsIgnoreCase(oc)
						|| QueryConstants.REGION_NHQ.equalsIgnoreCase(region))){
			toDisplay = QueryConstants.TO_DISPLAY_ABOVE_STATE;
		}*/
		try{
			/*if(Validator.isNotNull(joType) && (QueryConstants.JOTYPE_NHQ.equalsIgnoreCase(joType) || QueryConstants.JOTYPE_REGION_OFFICE.equalsIgnoreCase(joType))){
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.JOTYPE, joType.toUpperCase());
			}else if(Validator.isNotNull(oc) && (QueryConstants.OC_ANY_OTHER.equalsIgnoreCase(oc) || QueryConstants.OC_FTTX.equalsIgnoreCase(oc) || QueryConstants.OC_JIO_MONEY.equalsIgnoreCase(oc) || QueryConstants.OC_APPLICATIONS.equalsIgnoreCase(oc))){
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.OC, oc.toUpperCase());
			}else{
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.RESOLVER_DEFAULTS_DEFAULT, QueryConstants.RESOLVER_DEFAULTS_DEFAULT);
			}*/
			
			if(Validator.isNotNull(joType)){
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.JOTYPE, joType.toUpperCase());
			}
			if(Validator.isNotNull(oc) && Validator.isNull(resolverDefault)){
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.OC, oc.toUpperCase());
			}
			if(Validator.isNull(resolverDefault)){
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.RESOLVER_DEFAULTS_DEFAULT, QueryConstants.RESOLVER_DEFAULTS_DEFAULT);
			}
			
			if(Validator.isNotNull(resolverDefault)){
				return resolverDefault.getTO_DISPLAY();
			}
		}catch(Exception e){
			_log.error("Exception while fetching toDisplay val for case " + e.getMessage());
		}
		
		return toDisplay;
	}
	
	private static QueryBean saveQueryDetailsEntity(QueryBean queryBean, Query_Transaction queryTransaction){
		Query_Details queryDetails = null;
		try {
			Emp_User_Mapping empUserMapping = Emp_User_MappingLocalServiceUtil.getEmp_User_Mapping(queryTransaction.getRaisedById());
			EMP_DETAILS empDetails = EMP_DETAILSLocalServiceUtil.findEmpDetailsById(empUserMapping.getEmpId());
			
			queryDetails = Query_DetailsLocalServiceUtil.createQuery_Details(CounterLocalServiceUtil.increment(Query_Details.class.getName()));
			queryDetails.setQueryId(queryTransaction.getQueryId());
			queryDetails.setUpdatedTimestamp(new Date());
			queryDetails.setUpdatedBy(queryTransaction.getRaisedById());
			queryDetails.setAction(QueryConstants.QUERY_ACTION_CREATE);
			queryDetails.setStatus(QueryConstants.QUERY_STATUS_OPEN);
			queryDetails.setState(empDetails.getR4G_STATE());
			queryDetails.setRegion(empDetails.getJO_REGION());
			queryDetails.setQueueLevel(getQueueLevel(empDetails.getDEPARTMENT(), empDetails.getJO_TYPE()));
			queryDetails.setOc(getQueryModDefaults(QueryConstants.OC, empDetails.getDEPARTMENT(), queryDetails.getQueueLevel()));
			queryDetails.setAssignedTo(EMP_DETAILSLocalServiceUtil.getResolverByRR(empDetails.getJO_REGION(), empDetails.getR4G_STATE(), queryDetails.getOc(), empDetails.getJO_TYPE(), queryDetails.getQueueLevel()));
			//queryDetails.setComment(ParamUtil.getString(request, "queryDescription"));
			
			Query_DetailsLocalServiceUtil.addQuery_Details(queryDetails);
			_log.info("Query Details saved for queryId:"+queryTransaction.getQueryId());
			
			try{
				queryBean.setAssignedTo(queryDetails.getAssignedTo());
				User assignedToUser = UserLocalServiceUtil.getUser(queryDetails.getAssignedTo());
				queryBean.setAssignedToName(assignedToUser.getFullName());
				queryBean.setAssignedToEmail(assignedToUser.getEmailAddress());
			}catch(Exception e){
				_log.error("Exception while fetching case owner details "+e.getMessage());
			}
			
		} catch (Exception e) {
			_log.error("Exception while saving query details " + e.getMessage());
		}
		
		return queryBean;
	}
	
	private static int getQueueLevel(String oc, String joType){
		RESOLVER_DEFAULTS resolverDefault = null;
		RESOLVER_LEVEL_MST resolverLevelMaster = null;
		
		try {
			/*if(Validator.isNotNull(region) && QueryConstants.REGION_NHQ.equalsIgnoreCase(region)){
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.REGION, region.toUpperCase());
			}else if(Validator.isNotNull(circle) && QueryConstants.CIRCLE_REGION.equalsIgnoreCase(circle) || QueryConstants.CIRCLE_STATE.equalsIgnoreCase(circle)){
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.CIRCLE, circle.toUpperCase());
			}*/ 
			/*if(Validator.isNotNull(joType) && (QueryConstants.JOTYPE_NHQ.equalsIgnoreCase(joType) || QueryConstants.JOTYPE_REGION_OFFICE.equalsIgnoreCase(joType))){
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.JOTYPE, joType.toUpperCase());
			}else if(Validator.isNotNull(oc) && (QueryConstants.OC_ANY_OTHER.equalsIgnoreCase(oc) || QueryConstants.OC_FTTX.equalsIgnoreCase(oc) || QueryConstants.OC_JIO_MONEY.equalsIgnoreCase(oc) || QueryConstants.OC_APPLICATIONS.equalsIgnoreCase(oc))){
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.OC, oc.toUpperCase());
			}else{
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.RESOLVER_DEFAULTS_DEFAULT, QueryConstants.RESOLVER_DEFAULTS_DEFAULT);
			}*/
			
			if(Validator.isNotNull(joType)){
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.JOTYPE, joType.toUpperCase());
			}
			if(Validator.isNotNull(oc) && Validator.isNull(resolverDefault)){
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.OC, oc.toUpperCase());
			}
			if(Validator.isNull(resolverDefault)){
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.RESOLVER_DEFAULTS_DEFAULT, QueryConstants.RESOLVER_DEFAULTS_DEFAULT);
			}
			
			if(Validator.isNotNull(resolverDefault)){
				resolverLevelMaster = RESOLVER_LEVEL_MSTLocalServiceUtil.getRESOLVER_LEVEL_MST(resolverDefault.getRESOLVER_LEVEL_ID());
				if(Validator.isNotNull(resolverLevelMaster)){
					return resolverLevelMaster.getRESOLVER_LEVEL();
				}
			}
	
		
		} catch (Exception e) {
			_log.error("Exception while fetching queue level " + e.getMessage());
		}
		
		return QueryConstants.QUEUE_LEVEL_STATE_OC;
	}
	
	private static String getQueryModDefaults(String type, String currVal, int queueLevel){
		
		try {
			if(Validator.isNotNull(type) && Validator.isNotNull(currVal)){
				QUERY_MOD_DEFAULTS  queryModDefaults = QUERY_MOD_DEFAULTSLocalServiceUtil.findQueryModDefaultsByCurrType(QueryConstants.OC, currVal, queueLevel);
				if(Validator.isNotNull(queryModDefaults) && Validator.isNotNull(queryModDefaults.getNEW_VAL())){
					return queryModDefaults.getNEW_VAL();
				}
			}
		
		} catch (Exception e) {
			_log.error("Exception while fetching queryModDefaults " + e.getMessage());
		}
		
		return currVal;
	}
	
	
	//to do:call round robin query
	/*private static long getResolverId(int queueLevel, String oc, String region, String circle){
		RESOLVER_DEFAULTS resolverDefault = null;
		RESOLVER_LEVEL_MST resolverLevelMaster = null;
		
		try {
			if(Validator.isNotNull(region) && QueryConstants.REGION_NHQ.equalsIgnoreCase(region)){
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.REGION, region.toUpperCase());
			}else if(Validator.isNotNull(circle) && QueryConstants.CIRCLE_REGION.equalsIgnoreCase(circle) || QueryConstants.CIRCLE_STATE.equalsIgnoreCase(circle)){
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.CIRCLE, circle.toUpperCase());
			}else if(Validator.isNotNull(oc) && (QueryConstants.OC_ANY_OTHER.equalsIgnoreCase(oc) || QueryConstants.OC_FTTX.equalsIgnoreCase(oc) || QueryConstants.OC_JIO_MONEY.equalsIgnoreCase(oc) || QueryConstants.OC_APPLICATIONS.equalsIgnoreCase(oc))){
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.OC, oc.toUpperCase());
			}else{
				resolverDefault = RESOLVER_DEFAULTSLocalServiceUtil.findResolverDefaults(QueryConstants.RESOLVER_DEFAULTS_DEFAULT, QueryConstants.RESOLVER_DEFAULTS_DEFAULT);
			}
			
			if(Validator.isNotNull(resolverDefault)){
				resolverLevelMaster = RESOLVER_LEVEL_MSTLocalServiceUtil.getRESOLVER_LEVEL_MST(resolverDefault.getRESOLVER_LEVEL_ID());
				if(Validator.isNotNull(resolverLevelMaster)){
					return resolverLevelMaster.getRESOLVER_LEVEL();
				}
			}
	
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return QueryConstants.QUEUE_LEVEL_STATE_OC;
	}*/
	
	private static CreateJioCentralResponseBean createQueryInHPSM(ActionRequest request){ 
		return HPSMHelper.createQueryInHPSM(request);
	}
	
	private static CreateJioCentralIncResponseBean createIncidentInHPSM(QueryBean queryBean){
		CreateJioCentralIncResponseBean createJioCentralIncResponseBean = null;
		if("true".equalsIgnoreCase(PropsUtil.get(QueryConstants.HPSM_INCIDENT_CREATE))){
			createJioCentralIncResponseBean = HPSMIncHelper.createIncInHPSM(queryBean);
		}else{
			createJioCentralIncResponseBean = new CreateJioCentralIncResponseBean();
			createJioCentralIncResponseBean.setStatus(QueryConstants.SERVICE_STATUS_SUCCESS);
			createJioCentralIncResponseBean.setIncidentId("SX"+String.valueOf(queryBean.getQueryId()));
		}
		
		return createJioCentralIncResponseBean;
	}
	
	
	public static void attachDocument(ActionRequest request, ActionResponse response){
		try {
			//to do : 2nd phase, update query at HPSM
			//to do: send additional fields in incident description if available in update as 'orn:value'
			/*UpdateJioCentralResponseBean updateJioCentralResponseBean = HPSMHelper.updateQueryInHPSM(request);
			if(Validator.isNotNull(updateJioCentralResponseBean) && QueryConstants.SERVICE_STATUS_SUCCESS.equalsIgnoreCase(updateJioCentralResponseBean.getStatus())){
				_log.info("query updated in hpsm");
			}else{
				_log.info("Could not update query in hpsm");
			}*/
			
			UploadPortletRequest uploadPortletRequest = PortalUtil.getUploadPortletRequest(request);
			File file = uploadPortletRequest.getFile("uploadedFile");
			//System.out.println("file:"+file);
			Query_Attachments queryAttachments = null;
			long queryId = ParamUtil.getLong(request, "queryId");
			ThemeDisplay themeDisplay = (ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
			
			if(queryId != 0){
				// Additional parameters to query for specific oc's
				if(enableAdditionalParams(themeDisplay.getUserId())){
					try{
						//System.out.println("storing additional fields");
						Query_Transaction queryTransaction = Query_TransactionLocalServiceUtil.getQuery_Transaction(queryId);
						if(Validator.isNotNull(queryTransaction)){
							queryTransaction.setOrn_no(ParamUtil.getString(uploadPortletRequest, "ornNo"));
							queryTransaction.setCaf_no(ParamUtil.getString(uploadPortletRequest, "cafNo"));
							queryTransaction.setCustomer_MSISDN(ParamUtil.getString(uploadPortletRequest, "customerMSISDN"));
							queryTransaction.setAmt_request(ParamUtil.getLong(uploadPortletRequest, "amtRequest"));
							queryTransaction.setAmt_done(ParamUtil.getLong(uploadPortletRequest, "amtDone"));
							
							Query_TransactionLocalServiceUtil.updateQuery_Transaction(queryTransaction);
						}
					}catch(Exception e){
						_log.error("Exception while storing query additional params " + e.getMessage());
					}
				}
				
				// Store attachment
				if(Validator.isNotNull(file) && file.exists()) {
					long fileSize = uploadPortletRequest.getSize("uploadedFile");
					//System.out.println("fileSize:"+fileSize);
					if(fileSize > 0 && fileSize < Long.parseLong(PropsUtil.get(QueryConstants.QUERY_ATTACHMENT_MAX_SIZE))){
						_log.info("attaching file for queryId:"+queryId);
						
						FileEntry fileEntry = fileUpload(themeDisplay, request);
						if(Validator.isNotNull(fileEntry)){
							queryAttachments = Query_AttachmentsLocalServiceUtil.createQuery_Attachments(CounterLocalServiceUtil.increment(Query_Attachments.class.getName()));
							queryAttachments.setQueryId(queryId);
							queryAttachments.setUpdatedBy(themeDisplay.getUserId());
							queryAttachments.setUpdatedTimestamp(new Date());
							queryAttachments.setFileEntryId(fileEntry.getFileEntryId());
							queryAttachments.setFile_name(fileEntry.getTitle());
							
							Query_AttachmentsLocalServiceUtil.addQuery_Attachments(queryAttachments);
							_log.info("file reference stored with fileId:"+fileEntry.getFileEntryId()+" for queryId:"+queryId);
						}else{
							_log.info("File reference not created");
						}
					}else{
						_log.info("Not attaching file as file size exceeded");
					}
					
						
				}else{
					_log.info("File not found in request for query attachment");
				}
			}else{
				_log.info("No queryId received for file attachment");
			}
		
		} catch (Exception e) {
			_log.info("Exception while attaching file ", e);
		}
		
	}
	
	
	private static FileEntry fileUpload(ThemeDisplay themeDisplay, ActionRequest actionRequest) {
		UploadPortletRequest uploadPortletRequest = PortalUtil.getUploadPortletRequest(actionRequest);
		//long documentUploadId = 0;
		InputStream is = null;
		FileEntry fileEntry = null;
		
		String fileName = uploadPortletRequest.getFileName("uploadedFile");
		String uniqueFileName = null;
		File file = uploadPortletRequest.getFile("uploadedFile");
		String mimeType = uploadPortletRequest.getContentType("uploadedFile");
		//System.out.println("mimeType:"+mimeType);
		//String title = ParamUtil.getString(uploadPortletRequest, "title");
		String description = ParamUtil.getString(uploadPortletRequest, "description");
		long repositoryId = themeDisplay.getScopeGroupId();
		String caseNo = ParamUtil.getString(uploadPortletRequest, "caseNo");
		
		try {
			//List<String> allowedMimeTypes = new ArrayList<String>(Arrays.asList(PortletProps.getArray(QueryConstants.QUERY_ATTACHMENT_MIME_TYPES)));
			//if(Validator.isNotNull(allowedMimeTypes) && allowedMimeTypes.size() > 0 && Validator.isNotNull(mimeType) && allowedMimeTypes.contains(mimeType)){
			if(Utility.isValidMimeType(mimeType)){
				//System.out.println("uploading file");
				ServiceContext serviceContext = ServiceContextFactory.getInstance(DLFileEntry.class.getName(), actionRequest);
				if(Validator.isNotNull(file) && Validator.isNotNull(fileName)){
					Folder folder = addFolder(serviceContext.getUserId(), repositoryId, QueryConstants.PARENT_FOLDER_ID, QueryConstants.ROOT_FOLDER_NAME, QueryConstants.ROOT_FOLDER_DESCRIPTION , serviceContext);
					if(Validator.isNotNull(folder)){
						//is = new FileInputStream(file);
						is = uploadPortletRequest.getFileAsStream("uploadedFile");
						uniqueFileName = Utility.createUniqueFileName(fileName, caseNo);
						fileEntry = DLAppServiceUtil.addFileEntry(repositoryId, folder.getFolderId(), fileName, mimeType, uniqueFileName, description, "", is, uploadPortletRequest.getSize("uploadedFile"), serviceContext);
						_log.info("file added with id:"+fileEntry.getFileEntryId());
					}else{
						_log.info("folder does not exist to save attachment");
					}
					
				}else{
					_log.info("No file to attach");
				}
			}else{
				_log.info("Not saving invalid file " + fileName);
			}
			
						
		} catch (Exception e) {
			_log.error("Exception while storing file ", e);
		}
		
		return fileEntry;
	}
	
	private static Folder addFolder(long userId, long repositoryId, long parentFolderId, String rootFolderName, String rootFolderDescription, ServiceContext serviceContext) {
		Folder folder = null;
		try {
			boolean folderExist = isFolderExist(repositoryId,  parentFolderId, rootFolderName);
		
			if (!folderExist) {
				//System.out.println("add folder userId:"+userId+" repositoryId:"+repositoryId+" parentFolderId:"+parentFolderId+" rootFolderName:"+rootFolderName+" rootFolderDescription:"+rootFolderDescription);
				//folder = DLAppLocalServiceUtil.addFolder(userId, repositoryId, parentFolderId, rootFolderName, rootFolderDescription, serviceContext);
				folder = DLAppServiceUtil.addFolder(repositoryId, parentFolderId, rootFolderName, rootFolderDescription, serviceContext);
				_log.info("added folder for storing query attachments");
			}else{
				//System.out.println("get folder repositoryId:"+repositoryId+" parentFolderId:"+parentFolderId+" rootFolderName:"+rootFolderName);
				//folder = DLAppLocalServiceUtil.getFolder(repositoryId, parentFolderId, rootFolderName);
				folder = DLAppServiceUtil.getFolder(repositoryId, parentFolderId, rootFolderName);
			}
		} catch (Exception e) {
			_log.error("Exception while getting/creating folder ", e);
		} 
		return folder;
	}

	private static boolean isFolderExist(long repositoryId, long parentFolderId, String rootFolderName) {
		boolean folderExist = false;
		try {
			//System.out.println("is folder exists - repositoryId:"+repositoryId+" parentFolderId:"+parentFolderId+" rootFolderName:"+rootFolderName);
			DLAppServiceUtil.getFolder(repositoryId, parentFolderId, rootFolderName);
			folderExist = true;
		} catch (Exception e) {
			_log.error("Exception while checking if folder already exists " + e.getMessage());
		}
		//System.out.println("folderExist:"+folderExist);
		return folderExist;

	}

	public static boolean enableAdditionalParams(long userId){
		boolean enableAdditionalParams = false;
		try{
			EMP_DETAILS empDetails = EMP_DETAILSLocalServiceUtil.getEmpDetailsByUserId(userId);
			if(Validator.isNotNull(empDetails) && Validator.isNotNull(empDetails.getDEPARTMENT())){
				String empOc = empDetails.getDEPARTMENT();
				enableAdditionalParams = Query_Add_Param_OCLocalServiceUtil.enableAddParam(empOc);	
			}
			
		}catch(Exception e){
			_log.error("Exception while checking whether to enable additional params for query " + e.getMessage());
		}
		
		return enableAdditionalParams;
	}
	
}

