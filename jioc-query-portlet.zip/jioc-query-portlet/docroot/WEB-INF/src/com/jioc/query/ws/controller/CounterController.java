package com.jioc.query.ws.controller;

import com.jioc.beans.CounterRequestBean;
import com.jioc.beans.CounterResponseBean;
import com.jioc.query.model.Query_Details;
import com.jioc.util.QueryConstants;
import com.jioc.util.Utility;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.util.portlet.PortletProps;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

@Path(value = "/counter")
public class CounterController {
	private static Log LOGGER = LogFactoryUtil.getLog(CounterController.class.getName());
	
	@POST
	@Path("/getCounter")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public CounterResponseBean getCounter(@Context HttpServletRequest req, CounterRequestBean request) {
		CounterResponseBean response = null;
		LOGGER.info("Header "+req.getHeader("X-API-Key"));
		LOGGER.info("IP : "+req.getRemoteAddr());
		
		try{
			long counter = 0;
			if(Utility.allowUnauthorisedWSAccess(QueryConstants.SERVICE_NAME_GET_COUNTER) || (Utility.validateWSKey(QueryConstants.SERVICE_NAME_GET_COUNTER, req.getHeader("X-API-Key")) && Utility.validateAllowedIP4WS(QueryConstants.SERVICE_NAME_GET_COUNTER, req.getRemoteAddr()))){
				if(Validator.isNotNull(request) && Validator.isNotNull(request.getCounterDetails())){
					LOGGER.info(new StringBuilder("Get Counter REST request received name:").append(request.getCounterDetails().getName()));
					if(QueryConstants.GET_COUNTER_QUERY_DETAILS.equalsIgnoreCase(request.getCounterDetails().getName())){
						counter = CounterLocalServiceUtil.increment(Query_Details.class.getName());
					}
					response = createResponseJson(counter);
					LOGGER.info("Get Counter REST response:"+response.toString());
				}else{
					LOGGER.info("Empty service input");
				}
			}else{
				LOGGER.info("Unauthorised access");
				response = new CounterResponseBean();
				response.setSuccess("false");
				response.setErrorCode(PortletProps.get(QueryConstants.SERVICE_ERR_CODE_UNAUTHORISED_ACCESS));
				response.setErrorMsg(PortletProps.get(QueryConstants.SERVICE_ERR_MSG_UNAUTHORISED_ACCESS));
			}
			
		}catch(Exception e){
			LOGGER.error("Exception while processing request");
		}
		
		return response;
	}
	
	private static CounterResponseBean createResponseJson(long counter){
		CounterResponseBean response = new CounterResponseBean();
		
		if(counter != 0){
			response.setSuccess("true");
			response.setCounter(counter);
		}else{
			response.setSuccess("false");
			response.setErrorCode(PortletProps.get(QueryConstants.SERVICE_ERR_CODE_COUNTER_NOT_GENERATED));
			response.setErrorMsg(PortletProps.get(QueryConstants.SERVICE_ERR_MSG_COUNTER_NOT_GENERATED));
			response.setCounter(counter);
		}
		
		return response;
	}
}
