/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException;
import com.jioc.query.model.QUERY_MOD_DEFAULTS;
import com.jioc.query.model.impl.QUERY_MOD_DEFAULTSImpl;
import com.jioc.query.model.impl.QUERY_MOD_DEFAULTSModelImpl;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the q u e r y_ m o d_ d e f a u l t s service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see QUERY_MOD_DEFAULTSPersistence
 * @see QUERY_MOD_DEFAULTSUtil
 * @generated
 */
public class QUERY_MOD_DEFAULTSPersistenceImpl extends BasePersistenceImpl<QUERY_MOD_DEFAULTS>
	implements QUERY_MOD_DEFAULTSPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link QUERY_MOD_DEFAULTSUtil} to access the q u e r y_ m o d_ d e f a u l t s persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = QUERY_MOD_DEFAULTSImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(QUERY_MOD_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			QUERY_MOD_DEFAULTSModelImpl.FINDER_CACHE_ENABLED,
			QUERY_MOD_DEFAULTSImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(QUERY_MOD_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			QUERY_MOD_DEFAULTSModelImpl.FINDER_CACHE_ENABLED,
			QUERY_MOD_DEFAULTSImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(QUERY_MOD_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			QUERY_MOD_DEFAULTSModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_CURRTYPE = new FinderPath(QUERY_MOD_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			QUERY_MOD_DEFAULTSModelImpl.FINDER_CACHE_ENABLED,
			QUERY_MOD_DEFAULTSImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCurrType",
			new String[] {
				String.class.getName(), String.class.getName(),
				Integer.class.getName(), Integer.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CURRTYPE =
		new FinderPath(QUERY_MOD_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			QUERY_MOD_DEFAULTSModelImpl.FINDER_CACHE_ENABLED,
			QUERY_MOD_DEFAULTSImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCurrType",
			new String[] {
				String.class.getName(), String.class.getName(),
				Integer.class.getName(), Integer.class.getName()
			},
			QUERY_MOD_DEFAULTSModelImpl.TYPE_COLUMN_BITMASK |
			QUERY_MOD_DEFAULTSModelImpl.CURR_VAL_COLUMN_BITMASK |
			QUERY_MOD_DEFAULTSModelImpl.IS_ACTIVE_COLUMN_BITMASK |
			QUERY_MOD_DEFAULTSModelImpl.CURR_LEVEL_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_CURRTYPE = new FinderPath(QUERY_MOD_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			QUERY_MOD_DEFAULTSModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCurrType",
			new String[] {
				String.class.getName(), String.class.getName(),
				Integer.class.getName(), Integer.class.getName()
			});

	/**
	 * Returns all the q u e r y_ m o d_ d e f a u l t ses where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	 *
	 * @param TYPE the t y p e
	 * @param CURR_VAL the c u r r_ v a l
	 * @param IS_ACTIVE the i s_ a c t i v e
	 * @param CURR_LEVEL the c u r r_ l e v e l
	 * @return the matching q u e r y_ m o d_ d e f a u l t ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<QUERY_MOD_DEFAULTS> findByCurrType(String TYPE,
		String CURR_VAL, int IS_ACTIVE, int CURR_LEVEL)
		throws SystemException {
		return findByCurrType(TYPE, CURR_VAL, IS_ACTIVE, CURR_LEVEL,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the q u e r y_ m o d_ d e f a u l t ses where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.QUERY_MOD_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param TYPE the t y p e
	 * @param CURR_VAL the c u r r_ v a l
	 * @param IS_ACTIVE the i s_ a c t i v e
	 * @param CURR_LEVEL the c u r r_ l e v e l
	 * @param start the lower bound of the range of q u e r y_ m o d_ d e f a u l t ses
	 * @param end the upper bound of the range of q u e r y_ m o d_ d e f a u l t ses (not inclusive)
	 * @return the range of matching q u e r y_ m o d_ d e f a u l t ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<QUERY_MOD_DEFAULTS> findByCurrType(String TYPE,
		String CURR_VAL, int IS_ACTIVE, int CURR_LEVEL, int start, int end)
		throws SystemException {
		return findByCurrType(TYPE, CURR_VAL, IS_ACTIVE, CURR_LEVEL, start,
			end, null);
	}

	/**
	 * Returns an ordered range of all the q u e r y_ m o d_ d e f a u l t ses where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.QUERY_MOD_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param TYPE the t y p e
	 * @param CURR_VAL the c u r r_ v a l
	 * @param IS_ACTIVE the i s_ a c t i v e
	 * @param CURR_LEVEL the c u r r_ l e v e l
	 * @param start the lower bound of the range of q u e r y_ m o d_ d e f a u l t ses
	 * @param end the upper bound of the range of q u e r y_ m o d_ d e f a u l t ses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching q u e r y_ m o d_ d e f a u l t ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<QUERY_MOD_DEFAULTS> findByCurrType(String TYPE,
		String CURR_VAL, int IS_ACTIVE, int CURR_LEVEL, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CURRTYPE;
			finderArgs = new Object[] { TYPE, CURR_VAL, IS_ACTIVE, CURR_LEVEL };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_CURRTYPE;
			finderArgs = new Object[] {
					TYPE, CURR_VAL, IS_ACTIVE, CURR_LEVEL,
					
					start, end, orderByComparator
				};
		}

		List<QUERY_MOD_DEFAULTS> list = (List<QUERY_MOD_DEFAULTS>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (QUERY_MOD_DEFAULTS query_mod_defaults : list) {
				if (!Validator.equals(TYPE, query_mod_defaults.getTYPE()) ||
						!Validator.equals(CURR_VAL,
							query_mod_defaults.getCURR_VAL()) ||
						(IS_ACTIVE != query_mod_defaults.getIS_ACTIVE()) ||
						(CURR_LEVEL != query_mod_defaults.getCURR_LEVEL())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(6 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(6);
			}

			query.append(_SQL_SELECT_QUERY_MOD_DEFAULTS_WHERE);

			boolean bindTYPE = false;

			if (TYPE == null) {
				query.append(_FINDER_COLUMN_CURRTYPE_TYPE_1);
			}
			else if (TYPE.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_CURRTYPE_TYPE_3);
			}
			else {
				bindTYPE = true;

				query.append(_FINDER_COLUMN_CURRTYPE_TYPE_2);
			}

			boolean bindCURR_VAL = false;

			if (CURR_VAL == null) {
				query.append(_FINDER_COLUMN_CURRTYPE_CURR_VAL_1);
			}
			else if (CURR_VAL.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_CURRTYPE_CURR_VAL_3);
			}
			else {
				bindCURR_VAL = true;

				query.append(_FINDER_COLUMN_CURRTYPE_CURR_VAL_2);
			}

			query.append(_FINDER_COLUMN_CURRTYPE_IS_ACTIVE_2);

			query.append(_FINDER_COLUMN_CURRTYPE_CURR_LEVEL_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(QUERY_MOD_DEFAULTSModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindTYPE) {
					qPos.add(TYPE);
				}

				if (bindCURR_VAL) {
					qPos.add(CURR_VAL);
				}

				qPos.add(IS_ACTIVE);

				qPos.add(CURR_LEVEL);

				if (!pagination) {
					list = (List<QUERY_MOD_DEFAULTS>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<QUERY_MOD_DEFAULTS>(list);
				}
				else {
					list = (List<QUERY_MOD_DEFAULTS>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first q u e r y_ m o d_ d e f a u l t s in the ordered set where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	 *
	 * @param TYPE the t y p e
	 * @param CURR_VAL the c u r r_ v a l
	 * @param IS_ACTIVE the i s_ a c t i v e
	 * @param CURR_LEVEL the c u r r_ l e v e l
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching q u e r y_ m o d_ d e f a u l t s
	 * @throws com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException if a matching q u e r y_ m o d_ d e f a u l t s could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public QUERY_MOD_DEFAULTS findByCurrType_First(String TYPE,
		String CURR_VAL, int IS_ACTIVE, int CURR_LEVEL,
		OrderByComparator orderByComparator)
		throws NoSuchQUERY_MOD_DEFAULTSException, SystemException {
		QUERY_MOD_DEFAULTS query_mod_defaults = fetchByCurrType_First(TYPE,
				CURR_VAL, IS_ACTIVE, CURR_LEVEL, orderByComparator);

		if (query_mod_defaults != null) {
			return query_mod_defaults;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("TYPE=");
		msg.append(TYPE);

		msg.append(", CURR_VAL=");
		msg.append(CURR_VAL);

		msg.append(", IS_ACTIVE=");
		msg.append(IS_ACTIVE);

		msg.append(", CURR_LEVEL=");
		msg.append(CURR_LEVEL);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchQUERY_MOD_DEFAULTSException(msg.toString());
	}

	/**
	 * Returns the first q u e r y_ m o d_ d e f a u l t s in the ordered set where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	 *
	 * @param TYPE the t y p e
	 * @param CURR_VAL the c u r r_ v a l
	 * @param IS_ACTIVE the i s_ a c t i v e
	 * @param CURR_LEVEL the c u r r_ l e v e l
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching q u e r y_ m o d_ d e f a u l t s, or <code>null</code> if a matching q u e r y_ m o d_ d e f a u l t s could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public QUERY_MOD_DEFAULTS fetchByCurrType_First(String TYPE,
		String CURR_VAL, int IS_ACTIVE, int CURR_LEVEL,
		OrderByComparator orderByComparator) throws SystemException {
		List<QUERY_MOD_DEFAULTS> list = findByCurrType(TYPE, CURR_VAL,
				IS_ACTIVE, CURR_LEVEL, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last q u e r y_ m o d_ d e f a u l t s in the ordered set where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	 *
	 * @param TYPE the t y p e
	 * @param CURR_VAL the c u r r_ v a l
	 * @param IS_ACTIVE the i s_ a c t i v e
	 * @param CURR_LEVEL the c u r r_ l e v e l
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching q u e r y_ m o d_ d e f a u l t s
	 * @throws com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException if a matching q u e r y_ m o d_ d e f a u l t s could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public QUERY_MOD_DEFAULTS findByCurrType_Last(String TYPE, String CURR_VAL,
		int IS_ACTIVE, int CURR_LEVEL, OrderByComparator orderByComparator)
		throws NoSuchQUERY_MOD_DEFAULTSException, SystemException {
		QUERY_MOD_DEFAULTS query_mod_defaults = fetchByCurrType_Last(TYPE,
				CURR_VAL, IS_ACTIVE, CURR_LEVEL, orderByComparator);

		if (query_mod_defaults != null) {
			return query_mod_defaults;
		}

		StringBundler msg = new StringBundler(10);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("TYPE=");
		msg.append(TYPE);

		msg.append(", CURR_VAL=");
		msg.append(CURR_VAL);

		msg.append(", IS_ACTIVE=");
		msg.append(IS_ACTIVE);

		msg.append(", CURR_LEVEL=");
		msg.append(CURR_LEVEL);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchQUERY_MOD_DEFAULTSException(msg.toString());
	}

	/**
	 * Returns the last q u e r y_ m o d_ d e f a u l t s in the ordered set where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	 *
	 * @param TYPE the t y p e
	 * @param CURR_VAL the c u r r_ v a l
	 * @param IS_ACTIVE the i s_ a c t i v e
	 * @param CURR_LEVEL the c u r r_ l e v e l
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching q u e r y_ m o d_ d e f a u l t s, or <code>null</code> if a matching q u e r y_ m o d_ d e f a u l t s could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public QUERY_MOD_DEFAULTS fetchByCurrType_Last(String TYPE,
		String CURR_VAL, int IS_ACTIVE, int CURR_LEVEL,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByCurrType(TYPE, CURR_VAL, IS_ACTIVE, CURR_LEVEL);

		if (count == 0) {
			return null;
		}

		List<QUERY_MOD_DEFAULTS> list = findByCurrType(TYPE, CURR_VAL,
				IS_ACTIVE, CURR_LEVEL, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the q u e r y_ m o d_ d e f a u l t ses before and after the current q u e r y_ m o d_ d e f a u l t s in the ordered set where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	 *
	 * @param QUERY_MOD_DEFAULTS_ID the primary key of the current q u e r y_ m o d_ d e f a u l t s
	 * @param TYPE the t y p e
	 * @param CURR_VAL the c u r r_ v a l
	 * @param IS_ACTIVE the i s_ a c t i v e
	 * @param CURR_LEVEL the c u r r_ l e v e l
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next q u e r y_ m o d_ d e f a u l t s
	 * @throws com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException if a q u e r y_ m o d_ d e f a u l t s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public QUERY_MOD_DEFAULTS[] findByCurrType_PrevAndNext(
		int QUERY_MOD_DEFAULTS_ID, String TYPE, String CURR_VAL, int IS_ACTIVE,
		int CURR_LEVEL, OrderByComparator orderByComparator)
		throws NoSuchQUERY_MOD_DEFAULTSException, SystemException {
		QUERY_MOD_DEFAULTS query_mod_defaults = findByPrimaryKey(QUERY_MOD_DEFAULTS_ID);

		Session session = null;

		try {
			session = openSession();

			QUERY_MOD_DEFAULTS[] array = new QUERY_MOD_DEFAULTSImpl[3];

			array[0] = getByCurrType_PrevAndNext(session, query_mod_defaults,
					TYPE, CURR_VAL, IS_ACTIVE, CURR_LEVEL, orderByComparator,
					true);

			array[1] = query_mod_defaults;

			array[2] = getByCurrType_PrevAndNext(session, query_mod_defaults,
					TYPE, CURR_VAL, IS_ACTIVE, CURR_LEVEL, orderByComparator,
					false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected QUERY_MOD_DEFAULTS getByCurrType_PrevAndNext(Session session,
		QUERY_MOD_DEFAULTS query_mod_defaults, String TYPE, String CURR_VAL,
		int IS_ACTIVE, int CURR_LEVEL, OrderByComparator orderByComparator,
		boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_QUERY_MOD_DEFAULTS_WHERE);

		boolean bindTYPE = false;

		if (TYPE == null) {
			query.append(_FINDER_COLUMN_CURRTYPE_TYPE_1);
		}
		else if (TYPE.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_CURRTYPE_TYPE_3);
		}
		else {
			bindTYPE = true;

			query.append(_FINDER_COLUMN_CURRTYPE_TYPE_2);
		}

		boolean bindCURR_VAL = false;

		if (CURR_VAL == null) {
			query.append(_FINDER_COLUMN_CURRTYPE_CURR_VAL_1);
		}
		else if (CURR_VAL.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_CURRTYPE_CURR_VAL_3);
		}
		else {
			bindCURR_VAL = true;

			query.append(_FINDER_COLUMN_CURRTYPE_CURR_VAL_2);
		}

		query.append(_FINDER_COLUMN_CURRTYPE_IS_ACTIVE_2);

		query.append(_FINDER_COLUMN_CURRTYPE_CURR_LEVEL_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(QUERY_MOD_DEFAULTSModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindTYPE) {
			qPos.add(TYPE);
		}

		if (bindCURR_VAL) {
			qPos.add(CURR_VAL);
		}

		qPos.add(IS_ACTIVE);

		qPos.add(CURR_LEVEL);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(query_mod_defaults);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<QUERY_MOD_DEFAULTS> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the q u e r y_ m o d_ d e f a u l t ses where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63; from the database.
	 *
	 * @param TYPE the t y p e
	 * @param CURR_VAL the c u r r_ v a l
	 * @param IS_ACTIVE the i s_ a c t i v e
	 * @param CURR_LEVEL the c u r r_ l e v e l
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByCurrType(String TYPE, String CURR_VAL, int IS_ACTIVE,
		int CURR_LEVEL) throws SystemException {
		for (QUERY_MOD_DEFAULTS query_mod_defaults : findByCurrType(TYPE,
				CURR_VAL, IS_ACTIVE, CURR_LEVEL, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(query_mod_defaults);
		}
	}

	/**
	 * Returns the number of q u e r y_ m o d_ d e f a u l t ses where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	 *
	 * @param TYPE the t y p e
	 * @param CURR_VAL the c u r r_ v a l
	 * @param IS_ACTIVE the i s_ a c t i v e
	 * @param CURR_LEVEL the c u r r_ l e v e l
	 * @return the number of matching q u e r y_ m o d_ d e f a u l t ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByCurrType(String TYPE, String CURR_VAL, int IS_ACTIVE,
		int CURR_LEVEL) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_CURRTYPE;

		Object[] finderArgs = new Object[] { TYPE, CURR_VAL, IS_ACTIVE, CURR_LEVEL };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_COUNT_QUERY_MOD_DEFAULTS_WHERE);

			boolean bindTYPE = false;

			if (TYPE == null) {
				query.append(_FINDER_COLUMN_CURRTYPE_TYPE_1);
			}
			else if (TYPE.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_CURRTYPE_TYPE_3);
			}
			else {
				bindTYPE = true;

				query.append(_FINDER_COLUMN_CURRTYPE_TYPE_2);
			}

			boolean bindCURR_VAL = false;

			if (CURR_VAL == null) {
				query.append(_FINDER_COLUMN_CURRTYPE_CURR_VAL_1);
			}
			else if (CURR_VAL.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_CURRTYPE_CURR_VAL_3);
			}
			else {
				bindCURR_VAL = true;

				query.append(_FINDER_COLUMN_CURRTYPE_CURR_VAL_2);
			}

			query.append(_FINDER_COLUMN_CURRTYPE_IS_ACTIVE_2);

			query.append(_FINDER_COLUMN_CURRTYPE_CURR_LEVEL_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindTYPE) {
					qPos.add(TYPE);
				}

				if (bindCURR_VAL) {
					qPos.add(CURR_VAL);
				}

				qPos.add(IS_ACTIVE);

				qPos.add(CURR_LEVEL);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CURRTYPE_TYPE_1 = "query_mod_defaults.TYPE IS NULL AND ";
	private static final String _FINDER_COLUMN_CURRTYPE_TYPE_2 = "query_mod_defaults.TYPE = ? AND ";
	private static final String _FINDER_COLUMN_CURRTYPE_TYPE_3 = "(query_mod_defaults.TYPE IS NULL OR query_mod_defaults.TYPE = '') AND ";
	private static final String _FINDER_COLUMN_CURRTYPE_CURR_VAL_1 = "query_mod_defaults.CURR_VAL IS NULL AND ";
	private static final String _FINDER_COLUMN_CURRTYPE_CURR_VAL_2 = "query_mod_defaults.CURR_VAL = ? AND ";
	private static final String _FINDER_COLUMN_CURRTYPE_CURR_VAL_3 = "(query_mod_defaults.CURR_VAL IS NULL OR query_mod_defaults.CURR_VAL = '') AND ";
	private static final String _FINDER_COLUMN_CURRTYPE_IS_ACTIVE_2 = "query_mod_defaults.IS_ACTIVE = ? AND ";
	private static final String _FINDER_COLUMN_CURRTYPE_CURR_LEVEL_2 = "query_mod_defaults.CURR_LEVEL = ?";

	public QUERY_MOD_DEFAULTSPersistenceImpl() {
		setModelClass(QUERY_MOD_DEFAULTS.class);
	}

	/**
	 * Caches the q u e r y_ m o d_ d e f a u l t s in the entity cache if it is enabled.
	 *
	 * @param query_mod_defaults the q u e r y_ m o d_ d e f a u l t s
	 */
	@Override
	public void cacheResult(QUERY_MOD_DEFAULTS query_mod_defaults) {
		EntityCacheUtil.putResult(QUERY_MOD_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			QUERY_MOD_DEFAULTSImpl.class, query_mod_defaults.getPrimaryKey(),
			query_mod_defaults);

		query_mod_defaults.resetOriginalValues();
	}

	/**
	 * Caches the q u e r y_ m o d_ d e f a u l t ses in the entity cache if it is enabled.
	 *
	 * @param query_mod_defaultses the q u e r y_ m o d_ d e f a u l t ses
	 */
	@Override
	public void cacheResult(List<QUERY_MOD_DEFAULTS> query_mod_defaultses) {
		for (QUERY_MOD_DEFAULTS query_mod_defaults : query_mod_defaultses) {
			if (EntityCacheUtil.getResult(
						QUERY_MOD_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
						QUERY_MOD_DEFAULTSImpl.class,
						query_mod_defaults.getPrimaryKey()) == null) {
				cacheResult(query_mod_defaults);
			}
			else {
				query_mod_defaults.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all q u e r y_ m o d_ d e f a u l t ses.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(QUERY_MOD_DEFAULTSImpl.class.getName());
		}

		EntityCacheUtil.clearCache(QUERY_MOD_DEFAULTSImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the q u e r y_ m o d_ d e f a u l t s.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(QUERY_MOD_DEFAULTS query_mod_defaults) {
		EntityCacheUtil.removeResult(QUERY_MOD_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			QUERY_MOD_DEFAULTSImpl.class, query_mod_defaults.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<QUERY_MOD_DEFAULTS> query_mod_defaultses) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (QUERY_MOD_DEFAULTS query_mod_defaults : query_mod_defaultses) {
			EntityCacheUtil.removeResult(QUERY_MOD_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
				QUERY_MOD_DEFAULTSImpl.class, query_mod_defaults.getPrimaryKey());
		}
	}

	/**
	 * Creates a new q u e r y_ m o d_ d e f a u l t s with the primary key. Does not add the q u e r y_ m o d_ d e f a u l t s to the database.
	 *
	 * @param QUERY_MOD_DEFAULTS_ID the primary key for the new q u e r y_ m o d_ d e f a u l t s
	 * @return the new q u e r y_ m o d_ d e f a u l t s
	 */
	@Override
	public QUERY_MOD_DEFAULTS create(int QUERY_MOD_DEFAULTS_ID) {
		QUERY_MOD_DEFAULTS query_mod_defaults = new QUERY_MOD_DEFAULTSImpl();

		query_mod_defaults.setNew(true);
		query_mod_defaults.setPrimaryKey(QUERY_MOD_DEFAULTS_ID);

		return query_mod_defaults;
	}

	/**
	 * Removes the q u e r y_ m o d_ d e f a u l t s with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param QUERY_MOD_DEFAULTS_ID the primary key of the q u e r y_ m o d_ d e f a u l t s
	 * @return the q u e r y_ m o d_ d e f a u l t s that was removed
	 * @throws com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException if a q u e r y_ m o d_ d e f a u l t s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public QUERY_MOD_DEFAULTS remove(int QUERY_MOD_DEFAULTS_ID)
		throws NoSuchQUERY_MOD_DEFAULTSException, SystemException {
		return remove((Serializable)QUERY_MOD_DEFAULTS_ID);
	}

	/**
	 * Removes the q u e r y_ m o d_ d e f a u l t s with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the q u e r y_ m o d_ d e f a u l t s
	 * @return the q u e r y_ m o d_ d e f a u l t s that was removed
	 * @throws com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException if a q u e r y_ m o d_ d e f a u l t s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public QUERY_MOD_DEFAULTS remove(Serializable primaryKey)
		throws NoSuchQUERY_MOD_DEFAULTSException, SystemException {
		Session session = null;

		try {
			session = openSession();

			QUERY_MOD_DEFAULTS query_mod_defaults = (QUERY_MOD_DEFAULTS)session.get(QUERY_MOD_DEFAULTSImpl.class,
					primaryKey);

			if (query_mod_defaults == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchQUERY_MOD_DEFAULTSException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(query_mod_defaults);
		}
		catch (NoSuchQUERY_MOD_DEFAULTSException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected QUERY_MOD_DEFAULTS removeImpl(
		QUERY_MOD_DEFAULTS query_mod_defaults) throws SystemException {
		query_mod_defaults = toUnwrappedModel(query_mod_defaults);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(query_mod_defaults)) {
				query_mod_defaults = (QUERY_MOD_DEFAULTS)session.get(QUERY_MOD_DEFAULTSImpl.class,
						query_mod_defaults.getPrimaryKeyObj());
			}

			if (query_mod_defaults != null) {
				session.delete(query_mod_defaults);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (query_mod_defaults != null) {
			clearCache(query_mod_defaults);
		}

		return query_mod_defaults;
	}

	@Override
	public QUERY_MOD_DEFAULTS updateImpl(
		com.jioc.query.model.QUERY_MOD_DEFAULTS query_mod_defaults)
		throws SystemException {
		query_mod_defaults = toUnwrappedModel(query_mod_defaults);

		boolean isNew = query_mod_defaults.isNew();

		QUERY_MOD_DEFAULTSModelImpl query_mod_defaultsModelImpl = (QUERY_MOD_DEFAULTSModelImpl)query_mod_defaults;

		Session session = null;

		try {
			session = openSession();

			if (query_mod_defaults.isNew()) {
				session.save(query_mod_defaults);

				query_mod_defaults.setNew(false);
			}
			else {
				session.merge(query_mod_defaults);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !QUERY_MOD_DEFAULTSModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((query_mod_defaultsModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CURRTYPE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						query_mod_defaultsModelImpl.getOriginalTYPE(),
						query_mod_defaultsModelImpl.getOriginalCURR_VAL(),
						query_mod_defaultsModelImpl.getOriginalIS_ACTIVE(),
						query_mod_defaultsModelImpl.getOriginalCURR_LEVEL()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CURRTYPE, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CURRTYPE,
					args);

				args = new Object[] {
						query_mod_defaultsModelImpl.getTYPE(),
						query_mod_defaultsModelImpl.getCURR_VAL(),
						query_mod_defaultsModelImpl.getIS_ACTIVE(),
						query_mod_defaultsModelImpl.getCURR_LEVEL()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CURRTYPE, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CURRTYPE,
					args);
			}
		}

		EntityCacheUtil.putResult(QUERY_MOD_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			QUERY_MOD_DEFAULTSImpl.class, query_mod_defaults.getPrimaryKey(),
			query_mod_defaults);

		return query_mod_defaults;
	}

	protected QUERY_MOD_DEFAULTS toUnwrappedModel(
		QUERY_MOD_DEFAULTS query_mod_defaults) {
		if (query_mod_defaults instanceof QUERY_MOD_DEFAULTSImpl) {
			return query_mod_defaults;
		}

		QUERY_MOD_DEFAULTSImpl query_mod_defaultsImpl = new QUERY_MOD_DEFAULTSImpl();

		query_mod_defaultsImpl.setNew(query_mod_defaults.isNew());
		query_mod_defaultsImpl.setPrimaryKey(query_mod_defaults.getPrimaryKey());

		query_mod_defaultsImpl.setQUERY_MOD_DEFAULTS_ID(query_mod_defaults.getQUERY_MOD_DEFAULTS_ID());
		query_mod_defaultsImpl.setCURR_VAL(query_mod_defaults.getCURR_VAL());
		query_mod_defaultsImpl.setNEW_VAL(query_mod_defaults.getNEW_VAL());
		query_mod_defaultsImpl.setIS_ACTIVE(query_mod_defaults.getIS_ACTIVE());
		query_mod_defaultsImpl.setUPDATED_TIMESTAMP(query_mod_defaults.getUPDATED_TIMESTAMP());
		query_mod_defaultsImpl.setTYPE(query_mod_defaults.getTYPE());
		query_mod_defaultsImpl.setCURR_LEVEL(query_mod_defaults.getCURR_LEVEL());

		return query_mod_defaultsImpl;
	}

	/**
	 * Returns the q u e r y_ m o d_ d e f a u l t s with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the q u e r y_ m o d_ d e f a u l t s
	 * @return the q u e r y_ m o d_ d e f a u l t s
	 * @throws com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException if a q u e r y_ m o d_ d e f a u l t s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public QUERY_MOD_DEFAULTS findByPrimaryKey(Serializable primaryKey)
		throws NoSuchQUERY_MOD_DEFAULTSException, SystemException {
		QUERY_MOD_DEFAULTS query_mod_defaults = fetchByPrimaryKey(primaryKey);

		if (query_mod_defaults == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchQUERY_MOD_DEFAULTSException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return query_mod_defaults;
	}

	/**
	 * Returns the q u e r y_ m o d_ d e f a u l t s with the primary key or throws a {@link com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException} if it could not be found.
	 *
	 * @param QUERY_MOD_DEFAULTS_ID the primary key of the q u e r y_ m o d_ d e f a u l t s
	 * @return the q u e r y_ m o d_ d e f a u l t s
	 * @throws com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException if a q u e r y_ m o d_ d e f a u l t s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public QUERY_MOD_DEFAULTS findByPrimaryKey(int QUERY_MOD_DEFAULTS_ID)
		throws NoSuchQUERY_MOD_DEFAULTSException, SystemException {
		return findByPrimaryKey((Serializable)QUERY_MOD_DEFAULTS_ID);
	}

	/**
	 * Returns the q u e r y_ m o d_ d e f a u l t s with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the q u e r y_ m o d_ d e f a u l t s
	 * @return the q u e r y_ m o d_ d e f a u l t s, or <code>null</code> if a q u e r y_ m o d_ d e f a u l t s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public QUERY_MOD_DEFAULTS fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		QUERY_MOD_DEFAULTS query_mod_defaults = (QUERY_MOD_DEFAULTS)EntityCacheUtil.getResult(QUERY_MOD_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
				QUERY_MOD_DEFAULTSImpl.class, primaryKey);

		if (query_mod_defaults == _nullQUERY_MOD_DEFAULTS) {
			return null;
		}

		if (query_mod_defaults == null) {
			Session session = null;

			try {
				session = openSession();

				query_mod_defaults = (QUERY_MOD_DEFAULTS)session.get(QUERY_MOD_DEFAULTSImpl.class,
						primaryKey);

				if (query_mod_defaults != null) {
					cacheResult(query_mod_defaults);
				}
				else {
					EntityCacheUtil.putResult(QUERY_MOD_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
						QUERY_MOD_DEFAULTSImpl.class, primaryKey,
						_nullQUERY_MOD_DEFAULTS);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(QUERY_MOD_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
					QUERY_MOD_DEFAULTSImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return query_mod_defaults;
	}

	/**
	 * Returns the q u e r y_ m o d_ d e f a u l t s with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param QUERY_MOD_DEFAULTS_ID the primary key of the q u e r y_ m o d_ d e f a u l t s
	 * @return the q u e r y_ m o d_ d e f a u l t s, or <code>null</code> if a q u e r y_ m o d_ d e f a u l t s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public QUERY_MOD_DEFAULTS fetchByPrimaryKey(int QUERY_MOD_DEFAULTS_ID)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)QUERY_MOD_DEFAULTS_ID);
	}

	/**
	 * Returns all the q u e r y_ m o d_ d e f a u l t ses.
	 *
	 * @return the q u e r y_ m o d_ d e f a u l t ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<QUERY_MOD_DEFAULTS> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the q u e r y_ m o d_ d e f a u l t ses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.QUERY_MOD_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of q u e r y_ m o d_ d e f a u l t ses
	 * @param end the upper bound of the range of q u e r y_ m o d_ d e f a u l t ses (not inclusive)
	 * @return the range of q u e r y_ m o d_ d e f a u l t ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<QUERY_MOD_DEFAULTS> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the q u e r y_ m o d_ d e f a u l t ses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.QUERY_MOD_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of q u e r y_ m o d_ d e f a u l t ses
	 * @param end the upper bound of the range of q u e r y_ m o d_ d e f a u l t ses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of q u e r y_ m o d_ d e f a u l t ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<QUERY_MOD_DEFAULTS> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<QUERY_MOD_DEFAULTS> list = (List<QUERY_MOD_DEFAULTS>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_QUERY_MOD_DEFAULTS);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_QUERY_MOD_DEFAULTS;

				if (pagination) {
					sql = sql.concat(QUERY_MOD_DEFAULTSModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<QUERY_MOD_DEFAULTS>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<QUERY_MOD_DEFAULTS>(list);
				}
				else {
					list = (List<QUERY_MOD_DEFAULTS>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the q u e r y_ m o d_ d e f a u l t ses from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (QUERY_MOD_DEFAULTS query_mod_defaults : findAll()) {
			remove(query_mod_defaults);
		}
	}

	/**
	 * Returns the number of q u e r y_ m o d_ d e f a u l t ses.
	 *
	 * @return the number of q u e r y_ m o d_ d e f a u l t ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_QUERY_MOD_DEFAULTS);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the q u e r y_ m o d_ d e f a u l t s persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.jioc.query.model.QUERY_MOD_DEFAULTS")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<QUERY_MOD_DEFAULTS>> listenersList = new ArrayList<ModelListener<QUERY_MOD_DEFAULTS>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<QUERY_MOD_DEFAULTS>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(QUERY_MOD_DEFAULTSImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_QUERY_MOD_DEFAULTS = "SELECT query_mod_defaults FROM QUERY_MOD_DEFAULTS query_mod_defaults";
	private static final String _SQL_SELECT_QUERY_MOD_DEFAULTS_WHERE = "SELECT query_mod_defaults FROM QUERY_MOD_DEFAULTS query_mod_defaults WHERE ";
	private static final String _SQL_COUNT_QUERY_MOD_DEFAULTS = "SELECT COUNT(query_mod_defaults) FROM QUERY_MOD_DEFAULTS query_mod_defaults";
	private static final String _SQL_COUNT_QUERY_MOD_DEFAULTS_WHERE = "SELECT COUNT(query_mod_defaults) FROM QUERY_MOD_DEFAULTS query_mod_defaults WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "query_mod_defaults.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No QUERY_MOD_DEFAULTS exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No QUERY_MOD_DEFAULTS exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(QUERY_MOD_DEFAULTSPersistenceImpl.class);
	private static QUERY_MOD_DEFAULTS _nullQUERY_MOD_DEFAULTS = new QUERY_MOD_DEFAULTSImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<QUERY_MOD_DEFAULTS> toCacheModel() {
				return _nullQUERY_MOD_DEFAULTSCacheModel;
			}
		};

	private static CacheModel<QUERY_MOD_DEFAULTS> _nullQUERY_MOD_DEFAULTSCacheModel =
		new CacheModel<QUERY_MOD_DEFAULTS>() {
			@Override
			public QUERY_MOD_DEFAULTS toEntityModel() {
				return _nullQUERY_MOD_DEFAULTS;
			}
		};
}