/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.impl;

import com.jioc.query.model.Query_Details;
import com.jioc.query.service.base.Query_DetailsLocalServiceBaseImpl;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.SQLQuery;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;

import java.util.List;

/**
 * The implementation of the query_ details local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jioc.query.service.Query_DetailsLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author shantaram.chavan
 * @see com.jioc.query.service.base.Query_DetailsLocalServiceBaseImpl
 * @see com.jioc.query.service.Query_DetailsLocalServiceUtil
 */
public class Query_DetailsLocalServiceImpl
	extends Query_DetailsLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.jioc.query.service.Query_DetailsLocalServiceUtil} to access the query_ details local service.
	 */
	
	public List<Query_Details> findQueryDetailsByQueryId(long queryId){
		try {
			return query_DetailsPersistence.findByQueryId(queryId);
		} catch (SystemException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public List<Object[]> findLatestQueryDetailsByQueryId(long queryId){
		try {
			Session session = query_DetailsPersistence.openSession(); 
			//SQLQuery query = session.createSQLQuery("select * from jioc_query_details where queryId=? and updatedTimestamp=(select max(updatedTimestamp) as updatedTimestamp from jioc_query_details where queryId=?)");
			SQLQuery query = session.createSQLQuery("select querydetailsid, queryid, updatedtimestamp, updatedby, assignedto, action, status, state_, region, oc, queuelevel, comment_, category, subcategory, caseresolution from jioc_query_details where queryId=? and updatedTimestamp=(select max(updatedTimestamp) as updatedTimestamp from jioc_query_details where queryId=?)");
			QueryPos pos = QueryPos.getInstance(query); 
			pos.add(queryId);
			pos.add(queryId);
			return query.list();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
}