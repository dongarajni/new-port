/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.NoSuchRESOLVER_LEVEL_MSTException;
import com.jioc.query.model.RESOLVER_LEVEL_MST;
import com.jioc.query.model.impl.RESOLVER_LEVEL_MSTImpl;
import com.jioc.query.model.impl.RESOLVER_LEVEL_MSTModelImpl;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the r e s o l v e r_ l e v e l_ m s t service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see RESOLVER_LEVEL_MSTPersistence
 * @see RESOLVER_LEVEL_MSTUtil
 * @generated
 */
public class RESOLVER_LEVEL_MSTPersistenceImpl extends BasePersistenceImpl<RESOLVER_LEVEL_MST>
	implements RESOLVER_LEVEL_MSTPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link RESOLVER_LEVEL_MSTUtil} to access the r e s o l v e r_ l e v e l_ m s t persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = RESOLVER_LEVEL_MSTImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(RESOLVER_LEVEL_MSTModelImpl.ENTITY_CACHE_ENABLED,
			RESOLVER_LEVEL_MSTModelImpl.FINDER_CACHE_ENABLED,
			RESOLVER_LEVEL_MSTImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(RESOLVER_LEVEL_MSTModelImpl.ENTITY_CACHE_ENABLED,
			RESOLVER_LEVEL_MSTModelImpl.FINDER_CACHE_ENABLED,
			RESOLVER_LEVEL_MSTImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(RESOLVER_LEVEL_MSTModelImpl.ENTITY_CACHE_ENABLED,
			RESOLVER_LEVEL_MSTModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);

	public RESOLVER_LEVEL_MSTPersistenceImpl() {
		setModelClass(RESOLVER_LEVEL_MST.class);
	}

	/**
	 * Caches the r e s o l v e r_ l e v e l_ m s t in the entity cache if it is enabled.
	 *
	 * @param resolver_level_mst the r e s o l v e r_ l e v e l_ m s t
	 */
	@Override
	public void cacheResult(RESOLVER_LEVEL_MST resolver_level_mst) {
		EntityCacheUtil.putResult(RESOLVER_LEVEL_MSTModelImpl.ENTITY_CACHE_ENABLED,
			RESOLVER_LEVEL_MSTImpl.class, resolver_level_mst.getPrimaryKey(),
			resolver_level_mst);

		resolver_level_mst.resetOriginalValues();
	}

	/**
	 * Caches the r e s o l v e r_ l e v e l_ m s ts in the entity cache if it is enabled.
	 *
	 * @param resolver_level_msts the r e s o l v e r_ l e v e l_ m s ts
	 */
	@Override
	public void cacheResult(List<RESOLVER_LEVEL_MST> resolver_level_msts) {
		for (RESOLVER_LEVEL_MST resolver_level_mst : resolver_level_msts) {
			if (EntityCacheUtil.getResult(
						RESOLVER_LEVEL_MSTModelImpl.ENTITY_CACHE_ENABLED,
						RESOLVER_LEVEL_MSTImpl.class,
						resolver_level_mst.getPrimaryKey()) == null) {
				cacheResult(resolver_level_mst);
			}
			else {
				resolver_level_mst.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all r e s o l v e r_ l e v e l_ m s ts.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(RESOLVER_LEVEL_MSTImpl.class.getName());
		}

		EntityCacheUtil.clearCache(RESOLVER_LEVEL_MSTImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the r e s o l v e r_ l e v e l_ m s t.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(RESOLVER_LEVEL_MST resolver_level_mst) {
		EntityCacheUtil.removeResult(RESOLVER_LEVEL_MSTModelImpl.ENTITY_CACHE_ENABLED,
			RESOLVER_LEVEL_MSTImpl.class, resolver_level_mst.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<RESOLVER_LEVEL_MST> resolver_level_msts) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (RESOLVER_LEVEL_MST resolver_level_mst : resolver_level_msts) {
			EntityCacheUtil.removeResult(RESOLVER_LEVEL_MSTModelImpl.ENTITY_CACHE_ENABLED,
				RESOLVER_LEVEL_MSTImpl.class, resolver_level_mst.getPrimaryKey());
		}
	}

	/**
	 * Creates a new r e s o l v e r_ l e v e l_ m s t with the primary key. Does not add the r e s o l v e r_ l e v e l_ m s t to the database.
	 *
	 * @param LEVEL_ID the primary key for the new r e s o l v e r_ l e v e l_ m s t
	 * @return the new r e s o l v e r_ l e v e l_ m s t
	 */
	@Override
	public RESOLVER_LEVEL_MST create(long LEVEL_ID) {
		RESOLVER_LEVEL_MST resolver_level_mst = new RESOLVER_LEVEL_MSTImpl();

		resolver_level_mst.setNew(true);
		resolver_level_mst.setPrimaryKey(LEVEL_ID);

		return resolver_level_mst;
	}

	/**
	 * Removes the r e s o l v e r_ l e v e l_ m s t with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param LEVEL_ID the primary key of the r e s o l v e r_ l e v e l_ m s t
	 * @return the r e s o l v e r_ l e v e l_ m s t that was removed
	 * @throws com.jioc.query.NoSuchRESOLVER_LEVEL_MSTException if a r e s o l v e r_ l e v e l_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RESOLVER_LEVEL_MST remove(long LEVEL_ID)
		throws NoSuchRESOLVER_LEVEL_MSTException, SystemException {
		return remove((Serializable)LEVEL_ID);
	}

	/**
	 * Removes the r e s o l v e r_ l e v e l_ m s t with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the r e s o l v e r_ l e v e l_ m s t
	 * @return the r e s o l v e r_ l e v e l_ m s t that was removed
	 * @throws com.jioc.query.NoSuchRESOLVER_LEVEL_MSTException if a r e s o l v e r_ l e v e l_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RESOLVER_LEVEL_MST remove(Serializable primaryKey)
		throws NoSuchRESOLVER_LEVEL_MSTException, SystemException {
		Session session = null;

		try {
			session = openSession();

			RESOLVER_LEVEL_MST resolver_level_mst = (RESOLVER_LEVEL_MST)session.get(RESOLVER_LEVEL_MSTImpl.class,
					primaryKey);

			if (resolver_level_mst == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchRESOLVER_LEVEL_MSTException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(resolver_level_mst);
		}
		catch (NoSuchRESOLVER_LEVEL_MSTException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected RESOLVER_LEVEL_MST removeImpl(
		RESOLVER_LEVEL_MST resolver_level_mst) throws SystemException {
		resolver_level_mst = toUnwrappedModel(resolver_level_mst);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(resolver_level_mst)) {
				resolver_level_mst = (RESOLVER_LEVEL_MST)session.get(RESOLVER_LEVEL_MSTImpl.class,
						resolver_level_mst.getPrimaryKeyObj());
			}

			if (resolver_level_mst != null) {
				session.delete(resolver_level_mst);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (resolver_level_mst != null) {
			clearCache(resolver_level_mst);
		}

		return resolver_level_mst;
	}

	@Override
	public RESOLVER_LEVEL_MST updateImpl(
		com.jioc.query.model.RESOLVER_LEVEL_MST resolver_level_mst)
		throws SystemException {
		resolver_level_mst = toUnwrappedModel(resolver_level_mst);

		boolean isNew = resolver_level_mst.isNew();

		Session session = null;

		try {
			session = openSession();

			if (resolver_level_mst.isNew()) {
				session.save(resolver_level_mst);

				resolver_level_mst.setNew(false);
			}
			else {
				session.merge(resolver_level_mst);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		EntityCacheUtil.putResult(RESOLVER_LEVEL_MSTModelImpl.ENTITY_CACHE_ENABLED,
			RESOLVER_LEVEL_MSTImpl.class, resolver_level_mst.getPrimaryKey(),
			resolver_level_mst);

		return resolver_level_mst;
	}

	protected RESOLVER_LEVEL_MST toUnwrappedModel(
		RESOLVER_LEVEL_MST resolver_level_mst) {
		if (resolver_level_mst instanceof RESOLVER_LEVEL_MSTImpl) {
			return resolver_level_mst;
		}

		RESOLVER_LEVEL_MSTImpl resolver_level_mstImpl = new RESOLVER_LEVEL_MSTImpl();

		resolver_level_mstImpl.setNew(resolver_level_mst.isNew());
		resolver_level_mstImpl.setPrimaryKey(resolver_level_mst.getPrimaryKey());

		resolver_level_mstImpl.setLEVEL_ID(resolver_level_mst.getLEVEL_ID());
		resolver_level_mstImpl.setLEVEL_NAME(resolver_level_mst.getLEVEL_NAME());
		resolver_level_mstImpl.setRESOLVER_LEVEL(resolver_level_mst.getRESOLVER_LEVEL());

		return resolver_level_mstImpl;
	}

	/**
	 * Returns the r e s o l v e r_ l e v e l_ m s t with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the r e s o l v e r_ l e v e l_ m s t
	 * @return the r e s o l v e r_ l e v e l_ m s t
	 * @throws com.jioc.query.NoSuchRESOLVER_LEVEL_MSTException if a r e s o l v e r_ l e v e l_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RESOLVER_LEVEL_MST findByPrimaryKey(Serializable primaryKey)
		throws NoSuchRESOLVER_LEVEL_MSTException, SystemException {
		RESOLVER_LEVEL_MST resolver_level_mst = fetchByPrimaryKey(primaryKey);

		if (resolver_level_mst == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchRESOLVER_LEVEL_MSTException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return resolver_level_mst;
	}

	/**
	 * Returns the r e s o l v e r_ l e v e l_ m s t with the primary key or throws a {@link com.jioc.query.NoSuchRESOLVER_LEVEL_MSTException} if it could not be found.
	 *
	 * @param LEVEL_ID the primary key of the r e s o l v e r_ l e v e l_ m s t
	 * @return the r e s o l v e r_ l e v e l_ m s t
	 * @throws com.jioc.query.NoSuchRESOLVER_LEVEL_MSTException if a r e s o l v e r_ l e v e l_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RESOLVER_LEVEL_MST findByPrimaryKey(long LEVEL_ID)
		throws NoSuchRESOLVER_LEVEL_MSTException, SystemException {
		return findByPrimaryKey((Serializable)LEVEL_ID);
	}

	/**
	 * Returns the r e s o l v e r_ l e v e l_ m s t with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the r e s o l v e r_ l e v e l_ m s t
	 * @return the r e s o l v e r_ l e v e l_ m s t, or <code>null</code> if a r e s o l v e r_ l e v e l_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RESOLVER_LEVEL_MST fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		RESOLVER_LEVEL_MST resolver_level_mst = (RESOLVER_LEVEL_MST)EntityCacheUtil.getResult(RESOLVER_LEVEL_MSTModelImpl.ENTITY_CACHE_ENABLED,
				RESOLVER_LEVEL_MSTImpl.class, primaryKey);

		if (resolver_level_mst == _nullRESOLVER_LEVEL_MST) {
			return null;
		}

		if (resolver_level_mst == null) {
			Session session = null;

			try {
				session = openSession();

				resolver_level_mst = (RESOLVER_LEVEL_MST)session.get(RESOLVER_LEVEL_MSTImpl.class,
						primaryKey);

				if (resolver_level_mst != null) {
					cacheResult(resolver_level_mst);
				}
				else {
					EntityCacheUtil.putResult(RESOLVER_LEVEL_MSTModelImpl.ENTITY_CACHE_ENABLED,
						RESOLVER_LEVEL_MSTImpl.class, primaryKey,
						_nullRESOLVER_LEVEL_MST);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(RESOLVER_LEVEL_MSTModelImpl.ENTITY_CACHE_ENABLED,
					RESOLVER_LEVEL_MSTImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return resolver_level_mst;
	}

	/**
	 * Returns the r e s o l v e r_ l e v e l_ m s t with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param LEVEL_ID the primary key of the r e s o l v e r_ l e v e l_ m s t
	 * @return the r e s o l v e r_ l e v e l_ m s t, or <code>null</code> if a r e s o l v e r_ l e v e l_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RESOLVER_LEVEL_MST fetchByPrimaryKey(long LEVEL_ID)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)LEVEL_ID);
	}

	/**
	 * Returns all the r e s o l v e r_ l e v e l_ m s ts.
	 *
	 * @return the r e s o l v e r_ l e v e l_ m s ts
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RESOLVER_LEVEL_MST> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the r e s o l v e r_ l e v e l_ m s ts.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.RESOLVER_LEVEL_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of r e s o l v e r_ l e v e l_ m s ts
	 * @param end the upper bound of the range of r e s o l v e r_ l e v e l_ m s ts (not inclusive)
	 * @return the range of r e s o l v e r_ l e v e l_ m s ts
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RESOLVER_LEVEL_MST> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the r e s o l v e r_ l e v e l_ m s ts.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.RESOLVER_LEVEL_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of r e s o l v e r_ l e v e l_ m s ts
	 * @param end the upper bound of the range of r e s o l v e r_ l e v e l_ m s ts (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of r e s o l v e r_ l e v e l_ m s ts
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RESOLVER_LEVEL_MST> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<RESOLVER_LEVEL_MST> list = (List<RESOLVER_LEVEL_MST>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_RESOLVER_LEVEL_MST);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_RESOLVER_LEVEL_MST;

				if (pagination) {
					sql = sql.concat(RESOLVER_LEVEL_MSTModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<RESOLVER_LEVEL_MST>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<RESOLVER_LEVEL_MST>(list);
				}
				else {
					list = (List<RESOLVER_LEVEL_MST>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the r e s o l v e r_ l e v e l_ m s ts from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (RESOLVER_LEVEL_MST resolver_level_mst : findAll()) {
			remove(resolver_level_mst);
		}
	}

	/**
	 * Returns the number of r e s o l v e r_ l e v e l_ m s ts.
	 *
	 * @return the number of r e s o l v e r_ l e v e l_ m s ts
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_RESOLVER_LEVEL_MST);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the r e s o l v e r_ l e v e l_ m s t persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.jioc.query.model.RESOLVER_LEVEL_MST")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<RESOLVER_LEVEL_MST>> listenersList = new ArrayList<ModelListener<RESOLVER_LEVEL_MST>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<RESOLVER_LEVEL_MST>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(RESOLVER_LEVEL_MSTImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_RESOLVER_LEVEL_MST = "SELECT resolver_level_mst FROM RESOLVER_LEVEL_MST resolver_level_mst";
	private static final String _SQL_COUNT_RESOLVER_LEVEL_MST = "SELECT COUNT(resolver_level_mst) FROM RESOLVER_LEVEL_MST resolver_level_mst";
	private static final String _ORDER_BY_ENTITY_ALIAS = "resolver_level_mst.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No RESOLVER_LEVEL_MST exists with the primary key ";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(RESOLVER_LEVEL_MSTPersistenceImpl.class);
	private static RESOLVER_LEVEL_MST _nullRESOLVER_LEVEL_MST = new RESOLVER_LEVEL_MSTImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<RESOLVER_LEVEL_MST> toCacheModel() {
				return _nullRESOLVER_LEVEL_MSTCacheModel;
			}
		};

	private static CacheModel<RESOLVER_LEVEL_MST> _nullRESOLVER_LEVEL_MSTCacheModel =
		new CacheModel<RESOLVER_LEVEL_MST>() {
			@Override
			public RESOLVER_LEVEL_MST toEntityModel() {
				return _nullRESOLVER_LEVEL_MST;
			}
		};
}