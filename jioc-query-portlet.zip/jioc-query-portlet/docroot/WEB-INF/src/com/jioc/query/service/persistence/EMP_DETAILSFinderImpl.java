package com.jioc.query.service.persistence;

import com.jioc.query.model.EMP_DETAILS;
import com.jioc.query.model.impl.EMP_DETAILSImpl;
import com.liferay.portal.kernel.bean.PortalBeanLocatorUtil;
import com.liferay.portal.kernel.dao.jdbc.DataAccess;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.SQLQuery;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;
import com.liferay.util.dao.orm.CustomSQLUtil;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class EMP_DETAILSFinderImpl extends BasePersistenceImpl<EMP_DETAILS> implements EMP_DETAILSFinder{
	
	Log LOGGER = LogFactoryUtil.getLog(EMP_DETAILSFinderImpl.class.getName());
	
	public long findResolverByRR(String region, String state, String oc, String jioType, int resolverLevel) {
		long userId = 0;
	    //Session session = null;
		Connection connection = null;
	    try {
	        //session = openSession();
	        String sql = CustomSQLUtil.get(FIND_QUERY_RESOLVER_BY_RR);
	        connection = DataAccess.getConnection();
	        CallableStatement cs  = connection.prepareCall(sql);
	        cs.setString("IN_REGION", region);
	        cs.setString("IN_STATE", state);
	        cs.setString("IN_OC", oc);
	        cs.setString("IN_JIO_TYPE", jioType);
	        cs.setInt("IN_RES_LEVEL", resolverLevel);
	        cs.registerOutParameter("OUT_USERID", java.sql.Types.INTEGER);
	        cs.execute();
	        userId = cs.getInt("OUT_USERID");
	    } catch (Exception e) {
	        try {
	            throw new SystemException(e);
	        } catch (SystemException se) {
	        	LOGGER.error("Exception while fetching resolver by round robin "+se.getMessage());
	        }
	    } finally {
	        //closeSession(session);
	    	DataAccess.cleanUp(connection);
	    }

	    return userId;
	}
	
	public void updateEmpDetails() {
	    //Session session = null;
		Connection connection = null;
	    try {
	        //session = openSession();
	        String sql = CustomSQLUtil.get(UPDATE_EMPLOYEE_DETAILS);
	        connection = DataAccess.getConnection();
	        CallableStatement cs  = connection.prepareCall(sql);
	        cs.execute();
	        LOGGER.info("Employee details updated");
	    } catch (Exception e) {
	        try {
	            throw new SystemException(e);
	        } catch (SystemException se) {
	            LOGGER.error("Exception while updating employee details "+e.getMessage());
	        }
	    } finally {
	        //closeSession(session);
	        DataAccess.cleanUp(connection);
	    }
	    
	}
	
	public List<EMP_DETAILS> searchAssignees(String region,String circle,String area,String center,String job){
		
		Session session = null;
        try{
        	
        	session =openSession(); 
        	StringBuilder queryString = new StringBuilder();
        	queryString.append("select ed.FULL_NAME, ed.EMP_ID,eum.userId,EMAIL,ed.FIRST_NAME||' '||ed.LAST_NAME as NAME from jioc_emp_details ed inner join jioc_emp_user_mapping eum on ed.EMP_ID = eum.empId ");
        	
        	if(!region.equals("all") || !circle.equals("all") || !area.equals("all") || !center.equals("all") || !job.equals("all")){
        		queryString.append(" where ");
        		if(!region.equals("all")){
            		queryString.append("JO_REGION='"+region+"'");
            		if(!circle.equals("all") || !area.equals("all") || !center.equals("all") || !job.equals("all")){
            			queryString.append(" and ");
            		}
            	}
        		
            	if(!circle.equals("all")){
            		queryString.append("R4G_STATE='"+circle+"'");
            		if(!area.equals("all") || !center.equals("all") || !job.equals("all")){
            			queryString.append(" and ");
            		}
            	}
            	if(!area.equals("all")){
            		queryString.append("AREA='"+area+"'");
            		if(!center.equals("all") || !job.equals("all")){
            			queryString.append(" and ");
            		}
            	}
            	if(!center.equals("all")){
            		queryString.append("JIO_CENTER='"+center+"'");
            		if(!job.equals("all")){
            			queryString.append(" and ");
            		}
            	}
            	if(!job.equals("all")){
            		queryString.append("JOB='"+job+"'");
            	}
        	}
        	queryString.append("order by EMAIL");
        	
        	//System.out.println("Query=="+queryString.toString());
        	SQLQuery query = session.createSQLQuery(queryString.toString());
            //sql = StringUtil.replace(sql, "[$USERID$]", String.valueOf(userId));
        	query.setCacheable(true);
            
            return getAssigneeList((List<Object[]>)QueryUtil.list(query, getDialect(), QueryUtil.ALL_POS, QueryUtil.ALL_POS));
        } finally{
           if(session !=null) {
        	   closeSession(session);
           }
        }
		
	}
	
	private List<EMP_DETAILS> getAssigneeList(List<Object[]> list) {
		List<EMP_DETAILS> taskList = new ArrayList<EMP_DETAILS>();
		EMP_DETAILS empDetails = null;
	    for (Object[] object : list) {
	    	empDetails = new EMP_DETAILSImpl();
	    	empDetails.setFULL_NAME(GetterUtil.getString(object[0]));
	    	empDetails.setEMP_ID(GetterUtil.getString(object[1]));
	    	empDetails.setUserId(GetterUtil.getLong(object[2]));
	    	empDetails.setEMAIL(GetterUtil.getString(object[3]));
	    	empDetails.setUserName(GetterUtil.getString(object[4]));
	    	
	        taskList.add(empDetails);
	    }
	    return taskList;
	}
	
	
	public List<String> getSearchJobByAreaCircleRegionJioCenterAndOc(String region,String circle,String area,String center){
		
		Session session = null;
        try{
        	
        	session =openSession(); 
        	StringBuilder queryString = new StringBuilder();
        	queryString.append("select distinct(JOB) from JIOC_EMP_DETAILS where ");
        	
    		if(!region.equals("all")){
        		queryString.append("JO_REGION='"+region+"' and ");
        	}
    		
        	if(!circle.equals("all")){
        		queryString.append("R4G_STATE='"+circle+"' and ");
        	}
        	if(!area.equals("all")){
        		queryString.append("AREA='"+area+"' and ");
        	}
        	if(!center.equals("all")){
        		queryString.append("JIO_CENTER='"+center+"' and ");
        	}
        	queryString.append("department in (select OC from jioc_taskocdetails) order by JOB");
        	
        	System.out.println("Query"+queryString.toString());
        	SQLQuery query = session.createSQLQuery(queryString.toString());
            //sql = StringUtil.replace(sql, "[$USERID$]", String.valueOf(userId));
        	query.setCacheable(true);
            
            return getSearchJobByAreaCircleRegionJioCenterAndOcList((List<Object[]>)QueryUtil.list(query, getDialect(), QueryUtil.ALL_POS, QueryUtil.ALL_POS));
        } finally{
           if(session !=null) {
        	   closeSession(session);
           }
        }
	}
	
	private List<String> getSearchJobByAreaCircleRegionJioCenterAndOcList(List<Object[]> list) {
		List<String> taskList = new ArrayList<String>();
	    for (Object object : list) {
	        taskList.add(GetterUtil.getString(object));
	    }
	    return taskList;
	}
	
	
	public static final String FIND_QUERY_RESOLVER_BY_RR = EMP_DETAILSFinder.class.getName() + ".findResolverByRR";
	public static final String UPDATE_EMPLOYEE_DETAILS = EMP_DETAILSFinder.class.getName() + ".updateEmpDetails";
}
