/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.impl;

import com.jioc.query.NoSuchQuery_AttachmentsException;
import com.jioc.query.model.Query_Attachments;
import com.jioc.query.service.base.Query_AttachmentsLocalServiceBaseImpl;
import com.jioc.query.service.persistence.Query_AttachmentsPersistence;
import com.liferay.portal.kernel.exception.SystemException;

import java.util.List;

/**
 * The implementation of the query_ attachments local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jioc.query.service.Query_AttachmentsLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author shantaram.chavan
 * @see com.jioc.query.service.base.Query_AttachmentsLocalServiceBaseImpl
 * @see com.jioc.query.service.Query_AttachmentsLocalServiceUtil
 */
public class Query_AttachmentsLocalServiceImpl
	extends Query_AttachmentsLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.jioc.query.service.Query_AttachmentsLocalServiceUtil} to access the query_ attachments local service.
	 */
	
	public List<Query_Attachments> findQueryAttachmentsByQueryId(long queryId){
		try {
			return query_AttachmentsPersistence.findByQueryId(queryId);
		} catch (SystemException e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	public Query_Attachments getQueryByQueryIdAndFileEntryId(long queryId, long fileEntryId) throws NoSuchQuery_AttachmentsException,SystemException{
		return query_AttachmentsPersistence.findByQueryByQueryIdAndFileEntryId(queryId, fileEntryId);
	}
	
	
}