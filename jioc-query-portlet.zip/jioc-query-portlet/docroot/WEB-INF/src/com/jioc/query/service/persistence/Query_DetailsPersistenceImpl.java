/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.NoSuchQuery_DetailsException;
import com.jioc.query.model.Query_Details;
import com.jioc.query.model.impl.Query_DetailsImpl;
import com.jioc.query.model.impl.Query_DetailsModelImpl;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the query_ details service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see Query_DetailsPersistence
 * @see Query_DetailsUtil
 * @generated
 */
public class Query_DetailsPersistenceImpl extends BasePersistenceImpl<Query_Details>
	implements Query_DetailsPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link Query_DetailsUtil} to access the query_ details persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = Query_DetailsImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(Query_DetailsModelImpl.ENTITY_CACHE_ENABLED,
			Query_DetailsModelImpl.FINDER_CACHE_ENABLED,
			Query_DetailsImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(Query_DetailsModelImpl.ENTITY_CACHE_ENABLED,
			Query_DetailsModelImpl.FINDER_CACHE_ENABLED,
			Query_DetailsImpl.class, FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(Query_DetailsModelImpl.ENTITY_CACHE_ENABLED,
			Query_DetailsModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_QUERYID = new FinderPath(Query_DetailsModelImpl.ENTITY_CACHE_ENABLED,
			Query_DetailsModelImpl.FINDER_CACHE_ENABLED,
			Query_DetailsImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByQueryId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_QUERYID =
		new FinderPath(Query_DetailsModelImpl.ENTITY_CACHE_ENABLED,
			Query_DetailsModelImpl.FINDER_CACHE_ENABLED,
			Query_DetailsImpl.class, FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByQueryId", new String[] { Long.class.getName() },
			Query_DetailsModelImpl.QUERYID_COLUMN_BITMASK |
			Query_DetailsModelImpl.UPDATEDTIMESTAMP_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_QUERYID = new FinderPath(Query_DetailsModelImpl.ENTITY_CACHE_ENABLED,
			Query_DetailsModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByQueryId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the query_ detailses where queryId = &#63;.
	 *
	 * @param queryId the query ID
	 * @return the matching query_ detailses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Details> findByQueryId(long queryId)
		throws SystemException {
		return findByQueryId(queryId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the query_ detailses where queryId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_DetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param queryId the query ID
	 * @param start the lower bound of the range of query_ detailses
	 * @param end the upper bound of the range of query_ detailses (not inclusive)
	 * @return the range of matching query_ detailses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Details> findByQueryId(long queryId, int start, int end)
		throws SystemException {
		return findByQueryId(queryId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the query_ detailses where queryId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_DetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param queryId the query ID
	 * @param start the lower bound of the range of query_ detailses
	 * @param end the upper bound of the range of query_ detailses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching query_ detailses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Details> findByQueryId(long queryId, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_QUERYID;
			finderArgs = new Object[] { queryId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_QUERYID;
			finderArgs = new Object[] { queryId, start, end, orderByComparator };
		}

		List<Query_Details> list = (List<Query_Details>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Query_Details query_Details : list) {
				if ((queryId != query_Details.getQueryId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_QUERY_DETAILS_WHERE);

			query.append(_FINDER_COLUMN_QUERYID_QUERYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(Query_DetailsModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(queryId);

				if (!pagination) {
					list = (List<Query_Details>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Query_Details>(list);
				}
				else {
					list = (List<Query_Details>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first query_ details in the ordered set where queryId = &#63;.
	 *
	 * @param queryId the query ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching query_ details
	 * @throws com.jioc.query.NoSuchQuery_DetailsException if a matching query_ details could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Details findByQueryId_First(long queryId,
		OrderByComparator orderByComparator)
		throws NoSuchQuery_DetailsException, SystemException {
		Query_Details query_Details = fetchByQueryId_First(queryId,
				orderByComparator);

		if (query_Details != null) {
			return query_Details;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("queryId=");
		msg.append(queryId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchQuery_DetailsException(msg.toString());
	}

	/**
	 * Returns the first query_ details in the ordered set where queryId = &#63;.
	 *
	 * @param queryId the query ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching query_ details, or <code>null</code> if a matching query_ details could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Details fetchByQueryId_First(long queryId,
		OrderByComparator orderByComparator) throws SystemException {
		List<Query_Details> list = findByQueryId(queryId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last query_ details in the ordered set where queryId = &#63;.
	 *
	 * @param queryId the query ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching query_ details
	 * @throws com.jioc.query.NoSuchQuery_DetailsException if a matching query_ details could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Details findByQueryId_Last(long queryId,
		OrderByComparator orderByComparator)
		throws NoSuchQuery_DetailsException, SystemException {
		Query_Details query_Details = fetchByQueryId_Last(queryId,
				orderByComparator);

		if (query_Details != null) {
			return query_Details;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("queryId=");
		msg.append(queryId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchQuery_DetailsException(msg.toString());
	}

	/**
	 * Returns the last query_ details in the ordered set where queryId = &#63;.
	 *
	 * @param queryId the query ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching query_ details, or <code>null</code> if a matching query_ details could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Details fetchByQueryId_Last(long queryId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByQueryId(queryId);

		if (count == 0) {
			return null;
		}

		List<Query_Details> list = findByQueryId(queryId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the query_ detailses before and after the current query_ details in the ordered set where queryId = &#63;.
	 *
	 * @param queryDetailsId the primary key of the current query_ details
	 * @param queryId the query ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next query_ details
	 * @throws com.jioc.query.NoSuchQuery_DetailsException if a query_ details with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Details[] findByQueryId_PrevAndNext(long queryDetailsId,
		long queryId, OrderByComparator orderByComparator)
		throws NoSuchQuery_DetailsException, SystemException {
		Query_Details query_Details = findByPrimaryKey(queryDetailsId);

		Session session = null;

		try {
			session = openSession();

			Query_Details[] array = new Query_DetailsImpl[3];

			array[0] = getByQueryId_PrevAndNext(session, query_Details,
					queryId, orderByComparator, true);

			array[1] = query_Details;

			array[2] = getByQueryId_PrevAndNext(session, query_Details,
					queryId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Query_Details getByQueryId_PrevAndNext(Session session,
		Query_Details query_Details, long queryId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_QUERY_DETAILS_WHERE);

		query.append(_FINDER_COLUMN_QUERYID_QUERYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(Query_DetailsModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(queryId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(query_Details);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Query_Details> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the query_ detailses where queryId = &#63; from the database.
	 *
	 * @param queryId the query ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByQueryId(long queryId) throws SystemException {
		for (Query_Details query_Details : findByQueryId(queryId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(query_Details);
		}
	}

	/**
	 * Returns the number of query_ detailses where queryId = &#63;.
	 *
	 * @param queryId the query ID
	 * @return the number of matching query_ detailses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByQueryId(long queryId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_QUERYID;

		Object[] finderArgs = new Object[] { queryId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_QUERY_DETAILS_WHERE);

			query.append(_FINDER_COLUMN_QUERYID_QUERYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(queryId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_QUERYID_QUERYID_2 = "query_Details.queryId = ?";

	public Query_DetailsPersistenceImpl() {
		setModelClass(Query_Details.class);
	}

	/**
	 * Caches the query_ details in the entity cache if it is enabled.
	 *
	 * @param query_Details the query_ details
	 */
	@Override
	public void cacheResult(Query_Details query_Details) {
		EntityCacheUtil.putResult(Query_DetailsModelImpl.ENTITY_CACHE_ENABLED,
			Query_DetailsImpl.class, query_Details.getPrimaryKey(),
			query_Details);

		query_Details.resetOriginalValues();
	}

	/**
	 * Caches the query_ detailses in the entity cache if it is enabled.
	 *
	 * @param query_Detailses the query_ detailses
	 */
	@Override
	public void cacheResult(List<Query_Details> query_Detailses) {
		for (Query_Details query_Details : query_Detailses) {
			if (EntityCacheUtil.getResult(
						Query_DetailsModelImpl.ENTITY_CACHE_ENABLED,
						Query_DetailsImpl.class, query_Details.getPrimaryKey()) == null) {
				cacheResult(query_Details);
			}
			else {
				query_Details.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all query_ detailses.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(Query_DetailsImpl.class.getName());
		}

		EntityCacheUtil.clearCache(Query_DetailsImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the query_ details.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(Query_Details query_Details) {
		EntityCacheUtil.removeResult(Query_DetailsModelImpl.ENTITY_CACHE_ENABLED,
			Query_DetailsImpl.class, query_Details.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<Query_Details> query_Detailses) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (Query_Details query_Details : query_Detailses) {
			EntityCacheUtil.removeResult(Query_DetailsModelImpl.ENTITY_CACHE_ENABLED,
				Query_DetailsImpl.class, query_Details.getPrimaryKey());
		}
	}

	/**
	 * Creates a new query_ details with the primary key. Does not add the query_ details to the database.
	 *
	 * @param queryDetailsId the primary key for the new query_ details
	 * @return the new query_ details
	 */
	@Override
	public Query_Details create(long queryDetailsId) {
		Query_Details query_Details = new Query_DetailsImpl();

		query_Details.setNew(true);
		query_Details.setPrimaryKey(queryDetailsId);

		return query_Details;
	}

	/**
	 * Removes the query_ details with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param queryDetailsId the primary key of the query_ details
	 * @return the query_ details that was removed
	 * @throws com.jioc.query.NoSuchQuery_DetailsException if a query_ details with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Details remove(long queryDetailsId)
		throws NoSuchQuery_DetailsException, SystemException {
		return remove((Serializable)queryDetailsId);
	}

	/**
	 * Removes the query_ details with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the query_ details
	 * @return the query_ details that was removed
	 * @throws com.jioc.query.NoSuchQuery_DetailsException if a query_ details with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Details remove(Serializable primaryKey)
		throws NoSuchQuery_DetailsException, SystemException {
		Session session = null;

		try {
			session = openSession();

			Query_Details query_Details = (Query_Details)session.get(Query_DetailsImpl.class,
					primaryKey);

			if (query_Details == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchQuery_DetailsException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(query_Details);
		}
		catch (NoSuchQuery_DetailsException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected Query_Details removeImpl(Query_Details query_Details)
		throws SystemException {
		query_Details = toUnwrappedModel(query_Details);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(query_Details)) {
				query_Details = (Query_Details)session.get(Query_DetailsImpl.class,
						query_Details.getPrimaryKeyObj());
			}

			if (query_Details != null) {
				session.delete(query_Details);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (query_Details != null) {
			clearCache(query_Details);
		}

		return query_Details;
	}

	@Override
	public Query_Details updateImpl(
		com.jioc.query.model.Query_Details query_Details)
		throws SystemException {
		query_Details = toUnwrappedModel(query_Details);

		boolean isNew = query_Details.isNew();

		Query_DetailsModelImpl query_DetailsModelImpl = (Query_DetailsModelImpl)query_Details;

		Session session = null;

		try {
			session = openSession();

			if (query_Details.isNew()) {
				session.save(query_Details);

				query_Details.setNew(false);
			}
			else {
				session.merge(query_Details);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !Query_DetailsModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((query_DetailsModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_QUERYID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						query_DetailsModelImpl.getOriginalQueryId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_QUERYID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_QUERYID,
					args);

				args = new Object[] { query_DetailsModelImpl.getQueryId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_QUERYID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_QUERYID,
					args);
			}
		}

		EntityCacheUtil.putResult(Query_DetailsModelImpl.ENTITY_CACHE_ENABLED,
			Query_DetailsImpl.class, query_Details.getPrimaryKey(),
			query_Details);

		return query_Details;
	}

	protected Query_Details toUnwrappedModel(Query_Details query_Details) {
		if (query_Details instanceof Query_DetailsImpl) {
			return query_Details;
		}

		Query_DetailsImpl query_DetailsImpl = new Query_DetailsImpl();

		query_DetailsImpl.setNew(query_Details.isNew());
		query_DetailsImpl.setPrimaryKey(query_Details.getPrimaryKey());

		query_DetailsImpl.setQueryDetailsId(query_Details.getQueryDetailsId());
		query_DetailsImpl.setQueryId(query_Details.getQueryId());
		query_DetailsImpl.setUpdatedTimestamp(query_Details.getUpdatedTimestamp());
		query_DetailsImpl.setUpdatedBy(query_Details.getUpdatedBy());
		query_DetailsImpl.setAssignedTo(query_Details.getAssignedTo());
		query_DetailsImpl.setAction(query_Details.getAction());
		query_DetailsImpl.setStatus(query_Details.getStatus());
		query_DetailsImpl.setState(query_Details.getState());
		query_DetailsImpl.setRegion(query_Details.getRegion());
		query_DetailsImpl.setOc(query_Details.getOc());
		query_DetailsImpl.setQueueLevel(query_Details.getQueueLevel());
		query_DetailsImpl.setComment(query_Details.getComment());
		query_DetailsImpl.setCategory(query_Details.getCategory());
		query_DetailsImpl.setSubCategory(query_Details.getSubCategory());
		query_DetailsImpl.setCaseResolution(query_Details.getCaseResolution());
		query_DetailsImpl.setIs_closed(query_Details.getIs_closed());
		query_DetailsImpl.setClosed_date(query_Details.getClosed_date());

		return query_DetailsImpl;
	}

	/**
	 * Returns the query_ details with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the query_ details
	 * @return the query_ details
	 * @throws com.jioc.query.NoSuchQuery_DetailsException if a query_ details with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Details findByPrimaryKey(Serializable primaryKey)
		throws NoSuchQuery_DetailsException, SystemException {
		Query_Details query_Details = fetchByPrimaryKey(primaryKey);

		if (query_Details == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchQuery_DetailsException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return query_Details;
	}

	/**
	 * Returns the query_ details with the primary key or throws a {@link com.jioc.query.NoSuchQuery_DetailsException} if it could not be found.
	 *
	 * @param queryDetailsId the primary key of the query_ details
	 * @return the query_ details
	 * @throws com.jioc.query.NoSuchQuery_DetailsException if a query_ details with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Details findByPrimaryKey(long queryDetailsId)
		throws NoSuchQuery_DetailsException, SystemException {
		return findByPrimaryKey((Serializable)queryDetailsId);
	}

	/**
	 * Returns the query_ details with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the query_ details
	 * @return the query_ details, or <code>null</code> if a query_ details with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Details fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		Query_Details query_Details = (Query_Details)EntityCacheUtil.getResult(Query_DetailsModelImpl.ENTITY_CACHE_ENABLED,
				Query_DetailsImpl.class, primaryKey);

		if (query_Details == _nullQuery_Details) {
			return null;
		}

		if (query_Details == null) {
			Session session = null;

			try {
				session = openSession();

				query_Details = (Query_Details)session.get(Query_DetailsImpl.class,
						primaryKey);

				if (query_Details != null) {
					cacheResult(query_Details);
				}
				else {
					EntityCacheUtil.putResult(Query_DetailsModelImpl.ENTITY_CACHE_ENABLED,
						Query_DetailsImpl.class, primaryKey, _nullQuery_Details);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(Query_DetailsModelImpl.ENTITY_CACHE_ENABLED,
					Query_DetailsImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return query_Details;
	}

	/**
	 * Returns the query_ details with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param queryDetailsId the primary key of the query_ details
	 * @return the query_ details, or <code>null</code> if a query_ details with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Details fetchByPrimaryKey(long queryDetailsId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)queryDetailsId);
	}

	/**
	 * Returns all the query_ detailses.
	 *
	 * @return the query_ detailses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Details> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the query_ detailses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_DetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of query_ detailses
	 * @param end the upper bound of the range of query_ detailses (not inclusive)
	 * @return the range of query_ detailses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Details> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the query_ detailses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_DetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of query_ detailses
	 * @param end the upper bound of the range of query_ detailses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of query_ detailses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Details> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<Query_Details> list = (List<Query_Details>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_QUERY_DETAILS);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_QUERY_DETAILS;

				if (pagination) {
					sql = sql.concat(Query_DetailsModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<Query_Details>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Query_Details>(list);
				}
				else {
					list = (List<Query_Details>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the query_ detailses from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (Query_Details query_Details : findAll()) {
			remove(query_Details);
		}
	}

	/**
	 * Returns the number of query_ detailses.
	 *
	 * @return the number of query_ detailses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_QUERY_DETAILS);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	protected Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	/**
	 * Initializes the query_ details persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.jioc.query.model.Query_Details")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<Query_Details>> listenersList = new ArrayList<ModelListener<Query_Details>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<Query_Details>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(Query_DetailsImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_QUERY_DETAILS = "SELECT query_Details FROM Query_Details query_Details";
	private static final String _SQL_SELECT_QUERY_DETAILS_WHERE = "SELECT query_Details FROM Query_Details query_Details WHERE ";
	private static final String _SQL_COUNT_QUERY_DETAILS = "SELECT COUNT(query_Details) FROM Query_Details query_Details";
	private static final String _SQL_COUNT_QUERY_DETAILS_WHERE = "SELECT COUNT(query_Details) FROM Query_Details query_Details WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "query_Details.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No Query_Details exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No Query_Details exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(Query_DetailsPersistenceImpl.class);
	private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
				"state", "comment"
			});
	private static Query_Details _nullQuery_Details = new Query_DetailsImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<Query_Details> toCacheModel() {
				return _nullQuery_DetailsCacheModel;
			}
		};

	private static CacheModel<Query_Details> _nullQuery_DetailsCacheModel = new CacheModel<Query_Details>() {
			@Override
			public Query_Details toEntityModel() {
				return _nullQuery_Details;
			}
		};
}