/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.NoSuchEMP_DETAILSException;
import com.jioc.query.model.EMP_DETAILS;
import com.jioc.query.model.impl.EMP_DETAILSImpl;
import com.jioc.query.model.impl.EMP_DETAILSModelImpl;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.CalendarUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * The persistence implementation for the e m p_ d e t a i l s service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see EMP_DETAILSPersistence
 * @see EMP_DETAILSUtil
 * @generated
 */
public class EMP_DETAILSPersistenceImpl extends BasePersistenceImpl<EMP_DETAILS>
	implements EMP_DETAILSPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link EMP_DETAILSUtil} to access the e m p_ d e t a i l s persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = EMP_DETAILSImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(EMP_DETAILSModelImpl.ENTITY_CACHE_ENABLED,
			EMP_DETAILSModelImpl.FINDER_CACHE_ENABLED, EMP_DETAILSImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(EMP_DETAILSModelImpl.ENTITY_CACHE_ENABLED,
			EMP_DETAILSModelImpl.FINDER_CACHE_ENABLED, EMP_DETAILSImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(EMP_DETAILSModelImpl.ENTITY_CACHE_ENABLED,
			EMP_DETAILSModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_EMP_ID = new FinderPath(EMP_DETAILSModelImpl.ENTITY_CACHE_ENABLED,
			EMP_DETAILSModelImpl.FINDER_CACHE_ENABLED, EMP_DETAILSImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByEMP_ID",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EMP_ID =
		new FinderPath(EMP_DETAILSModelImpl.ENTITY_CACHE_ENABLED,
			EMP_DETAILSModelImpl.FINDER_CACHE_ENABLED, EMP_DETAILSImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByEMP_ID",
			new String[] { String.class.getName() },
			EMP_DETAILSModelImpl.EMP_ID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_EMP_ID = new FinderPath(EMP_DETAILSModelImpl.ENTITY_CACHE_ENABLED,
			EMP_DETAILSModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByEMP_ID",
			new String[] { String.class.getName() });

	/**
	 * Returns all the e m p_ d e t a i l ses where EMP_ID = &#63;.
	 *
	 * @param EMP_ID the e m p_ i d
	 * @return the matching e m p_ d e t a i l ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EMP_DETAILS> findByEMP_ID(String EMP_ID)
		throws SystemException {
		return findByEMP_ID(EMP_ID, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the e m p_ d e t a i l ses where EMP_ID = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.EMP_DETAILSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param EMP_ID the e m p_ i d
	 * @param start the lower bound of the range of e m p_ d e t a i l ses
	 * @param end the upper bound of the range of e m p_ d e t a i l ses (not inclusive)
	 * @return the range of matching e m p_ d e t a i l ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EMP_DETAILS> findByEMP_ID(String EMP_ID, int start, int end)
		throws SystemException {
		return findByEMP_ID(EMP_ID, start, end, null);
	}

	/**
	 * Returns an ordered range of all the e m p_ d e t a i l ses where EMP_ID = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.EMP_DETAILSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param EMP_ID the e m p_ i d
	 * @param start the lower bound of the range of e m p_ d e t a i l ses
	 * @param end the upper bound of the range of e m p_ d e t a i l ses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching e m p_ d e t a i l ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EMP_DETAILS> findByEMP_ID(String EMP_ID, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EMP_ID;
			finderArgs = new Object[] { EMP_ID };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_EMP_ID;
			finderArgs = new Object[] { EMP_ID, start, end, orderByComparator };
		}

		List<EMP_DETAILS> list = (List<EMP_DETAILS>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (EMP_DETAILS emp_details : list) {
				if (!Validator.equals(EMP_ID, emp_details.getEMP_ID())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_EMP_DETAILS_WHERE);

			boolean bindEMP_ID = false;

			if (EMP_ID == null) {
				query.append(_FINDER_COLUMN_EMP_ID_EMP_ID_1);
			}
			else if (EMP_ID.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_EMP_ID_EMP_ID_3);
			}
			else {
				bindEMP_ID = true;

				query.append(_FINDER_COLUMN_EMP_ID_EMP_ID_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(EMP_DETAILSModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindEMP_ID) {
					qPos.add(EMP_ID);
				}

				if (!pagination) {
					list = (List<EMP_DETAILS>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<EMP_DETAILS>(list);
				}
				else {
					list = (List<EMP_DETAILS>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first e m p_ d e t a i l s in the ordered set where EMP_ID = &#63;.
	 *
	 * @param EMP_ID the e m p_ i d
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching e m p_ d e t a i l s
	 * @throws com.jioc.query.NoSuchEMP_DETAILSException if a matching e m p_ d e t a i l s could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EMP_DETAILS findByEMP_ID_First(String EMP_ID,
		OrderByComparator orderByComparator)
		throws NoSuchEMP_DETAILSException, SystemException {
		EMP_DETAILS emp_details = fetchByEMP_ID_First(EMP_ID, orderByComparator);

		if (emp_details != null) {
			return emp_details;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("EMP_ID=");
		msg.append(EMP_ID);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchEMP_DETAILSException(msg.toString());
	}

	/**
	 * Returns the first e m p_ d e t a i l s in the ordered set where EMP_ID = &#63;.
	 *
	 * @param EMP_ID the e m p_ i d
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching e m p_ d e t a i l s, or <code>null</code> if a matching e m p_ d e t a i l s could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EMP_DETAILS fetchByEMP_ID_First(String EMP_ID,
		OrderByComparator orderByComparator) throws SystemException {
		List<EMP_DETAILS> list = findByEMP_ID(EMP_ID, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last e m p_ d e t a i l s in the ordered set where EMP_ID = &#63;.
	 *
	 * @param EMP_ID the e m p_ i d
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching e m p_ d e t a i l s
	 * @throws com.jioc.query.NoSuchEMP_DETAILSException if a matching e m p_ d e t a i l s could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EMP_DETAILS findByEMP_ID_Last(String EMP_ID,
		OrderByComparator orderByComparator)
		throws NoSuchEMP_DETAILSException, SystemException {
		EMP_DETAILS emp_details = fetchByEMP_ID_Last(EMP_ID, orderByComparator);

		if (emp_details != null) {
			return emp_details;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("EMP_ID=");
		msg.append(EMP_ID);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchEMP_DETAILSException(msg.toString());
	}

	/**
	 * Returns the last e m p_ d e t a i l s in the ordered set where EMP_ID = &#63;.
	 *
	 * @param EMP_ID the e m p_ i d
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching e m p_ d e t a i l s, or <code>null</code> if a matching e m p_ d e t a i l s could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EMP_DETAILS fetchByEMP_ID_Last(String EMP_ID,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByEMP_ID(EMP_ID);

		if (count == 0) {
			return null;
		}

		List<EMP_DETAILS> list = findByEMP_ID(EMP_ID, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Removes all the e m p_ d e t a i l ses where EMP_ID = &#63; from the database.
	 *
	 * @param EMP_ID the e m p_ i d
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByEMP_ID(String EMP_ID) throws SystemException {
		for (EMP_DETAILS emp_details : findByEMP_ID(EMP_ID, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(emp_details);
		}
	}

	/**
	 * Returns the number of e m p_ d e t a i l ses where EMP_ID = &#63;.
	 *
	 * @param EMP_ID the e m p_ i d
	 * @return the number of matching e m p_ d e t a i l ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByEMP_ID(String EMP_ID) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_EMP_ID;

		Object[] finderArgs = new Object[] { EMP_ID };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_EMP_DETAILS_WHERE);

			boolean bindEMP_ID = false;

			if (EMP_ID == null) {
				query.append(_FINDER_COLUMN_EMP_ID_EMP_ID_1);
			}
			else if (EMP_ID.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_EMP_ID_EMP_ID_3);
			}
			else {
				bindEMP_ID = true;

				query.append(_FINDER_COLUMN_EMP_ID_EMP_ID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindEMP_ID) {
					qPos.add(EMP_ID);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_EMP_ID_EMP_ID_1 = "emp_details.EMP_ID IS NULL";
	private static final String _FINDER_COLUMN_EMP_ID_EMP_ID_2 = "emp_details.EMP_ID = ?";
	private static final String _FINDER_COLUMN_EMP_ID_EMP_ID_3 = "(emp_details.EMP_ID IS NULL OR emp_details.EMP_ID = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_DATE_OF_JOINING =
		new FinderPath(EMP_DETAILSModelImpl.ENTITY_CACHE_ENABLED,
			EMP_DETAILSModelImpl.FINDER_CACHE_ENABLED, EMP_DETAILSImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByDATE_OF_JOINING",
			new String[] {
				Date.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DATE_OF_JOINING =
		new FinderPath(EMP_DETAILSModelImpl.ENTITY_CACHE_ENABLED,
			EMP_DETAILSModelImpl.FINDER_CACHE_ENABLED, EMP_DETAILSImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByDATE_OF_JOINING",
			new String[] { Date.class.getName() },
			EMP_DETAILSModelImpl.DATE_OF_JOINING_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_DATE_OF_JOINING = new FinderPath(EMP_DETAILSModelImpl.ENTITY_CACHE_ENABLED,
			EMP_DETAILSModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByDATE_OF_JOINING", new String[] { Date.class.getName() });

	/**
	 * Returns all the e m p_ d e t a i l ses where DATE_OF_JOINING = &#63;.
	 *
	 * @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	 * @return the matching e m p_ d e t a i l ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EMP_DETAILS> findByDATE_OF_JOINING(Date DATE_OF_JOINING)
		throws SystemException {
		return findByDATE_OF_JOINING(DATE_OF_JOINING, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the e m p_ d e t a i l ses where DATE_OF_JOINING = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.EMP_DETAILSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	 * @param start the lower bound of the range of e m p_ d e t a i l ses
	 * @param end the upper bound of the range of e m p_ d e t a i l ses (not inclusive)
	 * @return the range of matching e m p_ d e t a i l ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EMP_DETAILS> findByDATE_OF_JOINING(Date DATE_OF_JOINING,
		int start, int end) throws SystemException {
		return findByDATE_OF_JOINING(DATE_OF_JOINING, start, end, null);
	}

	/**
	 * Returns an ordered range of all the e m p_ d e t a i l ses where DATE_OF_JOINING = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.EMP_DETAILSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	 * @param start the lower bound of the range of e m p_ d e t a i l ses
	 * @param end the upper bound of the range of e m p_ d e t a i l ses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching e m p_ d e t a i l ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EMP_DETAILS> findByDATE_OF_JOINING(Date DATE_OF_JOINING,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DATE_OF_JOINING;
			finderArgs = new Object[] { DATE_OF_JOINING };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_DATE_OF_JOINING;
			finderArgs = new Object[] {
					DATE_OF_JOINING,
					
					start, end, orderByComparator
				};
		}

		List<EMP_DETAILS> list = (List<EMP_DETAILS>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (EMP_DETAILS emp_details : list) {
				if (!Validator.equals(DATE_OF_JOINING,
							emp_details.getDATE_OF_JOINING())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_EMP_DETAILS_WHERE);

			boolean bindDATE_OF_JOINING = false;

			if (DATE_OF_JOINING == null) {
				query.append(_FINDER_COLUMN_DATE_OF_JOINING_DATE_OF_JOINING_1);
			}
			else {
				bindDATE_OF_JOINING = true;

				query.append(_FINDER_COLUMN_DATE_OF_JOINING_DATE_OF_JOINING_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(EMP_DETAILSModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindDATE_OF_JOINING) {
					qPos.add(CalendarUtil.getTimestamp(DATE_OF_JOINING));
				}

				if (!pagination) {
					list = (List<EMP_DETAILS>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<EMP_DETAILS>(list);
				}
				else {
					list = (List<EMP_DETAILS>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first e m p_ d e t a i l s in the ordered set where DATE_OF_JOINING = &#63;.
	 *
	 * @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching e m p_ d e t a i l s
	 * @throws com.jioc.query.NoSuchEMP_DETAILSException if a matching e m p_ d e t a i l s could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EMP_DETAILS findByDATE_OF_JOINING_First(Date DATE_OF_JOINING,
		OrderByComparator orderByComparator)
		throws NoSuchEMP_DETAILSException, SystemException {
		EMP_DETAILS emp_details = fetchByDATE_OF_JOINING_First(DATE_OF_JOINING,
				orderByComparator);

		if (emp_details != null) {
			return emp_details;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("DATE_OF_JOINING=");
		msg.append(DATE_OF_JOINING);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchEMP_DETAILSException(msg.toString());
	}

	/**
	 * Returns the first e m p_ d e t a i l s in the ordered set where DATE_OF_JOINING = &#63;.
	 *
	 * @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching e m p_ d e t a i l s, or <code>null</code> if a matching e m p_ d e t a i l s could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EMP_DETAILS fetchByDATE_OF_JOINING_First(Date DATE_OF_JOINING,
		OrderByComparator orderByComparator) throws SystemException {
		List<EMP_DETAILS> list = findByDATE_OF_JOINING(DATE_OF_JOINING, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last e m p_ d e t a i l s in the ordered set where DATE_OF_JOINING = &#63;.
	 *
	 * @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching e m p_ d e t a i l s
	 * @throws com.jioc.query.NoSuchEMP_DETAILSException if a matching e m p_ d e t a i l s could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EMP_DETAILS findByDATE_OF_JOINING_Last(Date DATE_OF_JOINING,
		OrderByComparator orderByComparator)
		throws NoSuchEMP_DETAILSException, SystemException {
		EMP_DETAILS emp_details = fetchByDATE_OF_JOINING_Last(DATE_OF_JOINING,
				orderByComparator);

		if (emp_details != null) {
			return emp_details;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("DATE_OF_JOINING=");
		msg.append(DATE_OF_JOINING);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchEMP_DETAILSException(msg.toString());
	}

	/**
	 * Returns the last e m p_ d e t a i l s in the ordered set where DATE_OF_JOINING = &#63;.
	 *
	 * @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching e m p_ d e t a i l s, or <code>null</code> if a matching e m p_ d e t a i l s could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EMP_DETAILS fetchByDATE_OF_JOINING_Last(Date DATE_OF_JOINING,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByDATE_OF_JOINING(DATE_OF_JOINING);

		if (count == 0) {
			return null;
		}

		List<EMP_DETAILS> list = findByDATE_OF_JOINING(DATE_OF_JOINING,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the e m p_ d e t a i l ses before and after the current e m p_ d e t a i l s in the ordered set where DATE_OF_JOINING = &#63;.
	 *
	 * @param EMP_ID the primary key of the current e m p_ d e t a i l s
	 * @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next e m p_ d e t a i l s
	 * @throws com.jioc.query.NoSuchEMP_DETAILSException if a e m p_ d e t a i l s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EMP_DETAILS[] findByDATE_OF_JOINING_PrevAndNext(String EMP_ID,
		Date DATE_OF_JOINING, OrderByComparator orderByComparator)
		throws NoSuchEMP_DETAILSException, SystemException {
		EMP_DETAILS emp_details = findByPrimaryKey(EMP_ID);

		Session session = null;

		try {
			session = openSession();

			EMP_DETAILS[] array = new EMP_DETAILSImpl[3];

			array[0] = getByDATE_OF_JOINING_PrevAndNext(session, emp_details,
					DATE_OF_JOINING, orderByComparator, true);

			array[1] = emp_details;

			array[2] = getByDATE_OF_JOINING_PrevAndNext(session, emp_details,
					DATE_OF_JOINING, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected EMP_DETAILS getByDATE_OF_JOINING_PrevAndNext(Session session,
		EMP_DETAILS emp_details, Date DATE_OF_JOINING,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_EMP_DETAILS_WHERE);

		boolean bindDATE_OF_JOINING = false;

		if (DATE_OF_JOINING == null) {
			query.append(_FINDER_COLUMN_DATE_OF_JOINING_DATE_OF_JOINING_1);
		}
		else {
			bindDATE_OF_JOINING = true;

			query.append(_FINDER_COLUMN_DATE_OF_JOINING_DATE_OF_JOINING_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(EMP_DETAILSModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindDATE_OF_JOINING) {
			qPos.add(CalendarUtil.getTimestamp(DATE_OF_JOINING));
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(emp_details);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<EMP_DETAILS> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the e m p_ d e t a i l ses where DATE_OF_JOINING = &#63; from the database.
	 *
	 * @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByDATE_OF_JOINING(Date DATE_OF_JOINING)
		throws SystemException {
		for (EMP_DETAILS emp_details : findByDATE_OF_JOINING(DATE_OF_JOINING,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(emp_details);
		}
	}

	/**
	 * Returns the number of e m p_ d e t a i l ses where DATE_OF_JOINING = &#63;.
	 *
	 * @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	 * @return the number of matching e m p_ d e t a i l ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByDATE_OF_JOINING(Date DATE_OF_JOINING)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_DATE_OF_JOINING;

		Object[] finderArgs = new Object[] { DATE_OF_JOINING };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_EMP_DETAILS_WHERE);

			boolean bindDATE_OF_JOINING = false;

			if (DATE_OF_JOINING == null) {
				query.append(_FINDER_COLUMN_DATE_OF_JOINING_DATE_OF_JOINING_1);
			}
			else {
				bindDATE_OF_JOINING = true;

				query.append(_FINDER_COLUMN_DATE_OF_JOINING_DATE_OF_JOINING_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindDATE_OF_JOINING) {
					qPos.add(CalendarUtil.getTimestamp(DATE_OF_JOINING));
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_DATE_OF_JOINING_DATE_OF_JOINING_1 =
		"emp_details.DATE_OF_JOINING IS NULL";
	private static final String _FINDER_COLUMN_DATE_OF_JOINING_DATE_OF_JOINING_2 =
		"emp_details.DATE_OF_JOINING = ?";

	public EMP_DETAILSPersistenceImpl() {
		setModelClass(EMP_DETAILS.class);
	}

	/**
	 * Caches the e m p_ d e t a i l s in the entity cache if it is enabled.
	 *
	 * @param emp_details the e m p_ d e t a i l s
	 */
	@Override
	public void cacheResult(EMP_DETAILS emp_details) {
		EntityCacheUtil.putResult(EMP_DETAILSModelImpl.ENTITY_CACHE_ENABLED,
			EMP_DETAILSImpl.class, emp_details.getPrimaryKey(), emp_details);

		emp_details.resetOriginalValues();
	}

	/**
	 * Caches the e m p_ d e t a i l ses in the entity cache if it is enabled.
	 *
	 * @param emp_detailses the e m p_ d e t a i l ses
	 */
	@Override
	public void cacheResult(List<EMP_DETAILS> emp_detailses) {
		for (EMP_DETAILS emp_details : emp_detailses) {
			if (EntityCacheUtil.getResult(
						EMP_DETAILSModelImpl.ENTITY_CACHE_ENABLED,
						EMP_DETAILSImpl.class, emp_details.getPrimaryKey()) == null) {
				cacheResult(emp_details);
			}
			else {
				emp_details.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all e m p_ d e t a i l ses.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(EMP_DETAILSImpl.class.getName());
		}

		EntityCacheUtil.clearCache(EMP_DETAILSImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the e m p_ d e t a i l s.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(EMP_DETAILS emp_details) {
		EntityCacheUtil.removeResult(EMP_DETAILSModelImpl.ENTITY_CACHE_ENABLED,
			EMP_DETAILSImpl.class, emp_details.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<EMP_DETAILS> emp_detailses) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (EMP_DETAILS emp_details : emp_detailses) {
			EntityCacheUtil.removeResult(EMP_DETAILSModelImpl.ENTITY_CACHE_ENABLED,
				EMP_DETAILSImpl.class, emp_details.getPrimaryKey());
		}
	}

	/**
	 * Creates a new e m p_ d e t a i l s with the primary key. Does not add the e m p_ d e t a i l s to the database.
	 *
	 * @param EMP_ID the primary key for the new e m p_ d e t a i l s
	 * @return the new e m p_ d e t a i l s
	 */
	@Override
	public EMP_DETAILS create(String EMP_ID) {
		EMP_DETAILS emp_details = new EMP_DETAILSImpl();

		emp_details.setNew(true);
		emp_details.setPrimaryKey(EMP_ID);

		return emp_details;
	}

	/**
	 * Removes the e m p_ d e t a i l s with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param EMP_ID the primary key of the e m p_ d e t a i l s
	 * @return the e m p_ d e t a i l s that was removed
	 * @throws com.jioc.query.NoSuchEMP_DETAILSException if a e m p_ d e t a i l s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EMP_DETAILS remove(String EMP_ID)
		throws NoSuchEMP_DETAILSException, SystemException {
		return remove((Serializable)EMP_ID);
	}

	/**
	 * Removes the e m p_ d e t a i l s with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the e m p_ d e t a i l s
	 * @return the e m p_ d e t a i l s that was removed
	 * @throws com.jioc.query.NoSuchEMP_DETAILSException if a e m p_ d e t a i l s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EMP_DETAILS remove(Serializable primaryKey)
		throws NoSuchEMP_DETAILSException, SystemException {
		Session session = null;

		try {
			session = openSession();

			EMP_DETAILS emp_details = (EMP_DETAILS)session.get(EMP_DETAILSImpl.class,
					primaryKey);

			if (emp_details == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchEMP_DETAILSException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(emp_details);
		}
		catch (NoSuchEMP_DETAILSException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected EMP_DETAILS removeImpl(EMP_DETAILS emp_details)
		throws SystemException {
		emp_details = toUnwrappedModel(emp_details);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(emp_details)) {
				emp_details = (EMP_DETAILS)session.get(EMP_DETAILSImpl.class,
						emp_details.getPrimaryKeyObj());
			}

			if (emp_details != null) {
				session.delete(emp_details);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (emp_details != null) {
			clearCache(emp_details);
		}

		return emp_details;
	}

	@Override
	public EMP_DETAILS updateImpl(com.jioc.query.model.EMP_DETAILS emp_details)
		throws SystemException {
		emp_details = toUnwrappedModel(emp_details);

		boolean isNew = emp_details.isNew();

		EMP_DETAILSModelImpl emp_detailsModelImpl = (EMP_DETAILSModelImpl)emp_details;

		Session session = null;

		try {
			session = openSession();

			if (emp_details.isNew()) {
				session.save(emp_details);

				emp_details.setNew(false);
			}
			else {
				session.merge(emp_details);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !EMP_DETAILSModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((emp_detailsModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EMP_ID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						emp_detailsModelImpl.getOriginalEMP_ID()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_EMP_ID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EMP_ID,
					args);

				args = new Object[] { emp_detailsModelImpl.getEMP_ID() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_EMP_ID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EMP_ID,
					args);
			}

			if ((emp_detailsModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DATE_OF_JOINING.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						emp_detailsModelImpl.getOriginalDATE_OF_JOINING()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DATE_OF_JOINING,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DATE_OF_JOINING,
					args);

				args = new Object[] { emp_detailsModelImpl.getDATE_OF_JOINING() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DATE_OF_JOINING,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DATE_OF_JOINING,
					args);
			}
		}

		EntityCacheUtil.putResult(EMP_DETAILSModelImpl.ENTITY_CACHE_ENABLED,
			EMP_DETAILSImpl.class, emp_details.getPrimaryKey(), emp_details);

		return emp_details;
	}

	protected EMP_DETAILS toUnwrappedModel(EMP_DETAILS emp_details) {
		if (emp_details instanceof EMP_DETAILSImpl) {
			return emp_details;
		}

		EMP_DETAILSImpl emp_detailsImpl = new EMP_DETAILSImpl();

		emp_detailsImpl.setNew(emp_details.isNew());
		emp_detailsImpl.setPrimaryKey(emp_details.getPrimaryKey());

		emp_detailsImpl.setEMP_ID(emp_details.getEMP_ID());
		emp_detailsImpl.setAREA(emp_details.getAREA());
		emp_detailsImpl.setCADRE(emp_details.getCADRE());
		emp_detailsImpl.setCLIENT_ID(emp_details.getCLIENT_ID());
		emp_detailsImpl.setCOMPANY_CODE(emp_details.getCOMPANY_CODE());
		emp_detailsImpl.setCOMPANY_TEXT(emp_details.getCOMPANY_TEXT());
		emp_detailsImpl.setDATE_OF_BIRTH(emp_details.getDATE_OF_BIRTH());
		emp_detailsImpl.setDATE_OF_JOINING(emp_details.getDATE_OF_JOINING());
		emp_detailsImpl.setDATE_OF_LEAVE(emp_details.getDATE_OF_LEAVE());
		emp_detailsImpl.setDEPARTMENT(emp_details.getDEPARTMENT());
		emp_detailsImpl.setDESIGNATION_CODE(emp_details.getDESIGNATION_CODE());
		emp_detailsImpl.setDESIGNATION_TEXT(emp_details.getDESIGNATION_TEXT());
		emp_detailsImpl.setEMAIL(emp_details.getEMAIL());
		emp_detailsImpl.setEMP_GROUP(emp_details.getEMP_GROUP());
		emp_detailsImpl.setEMPLOYEE_DOMAIN_ID(emp_details.getEMPLOYEE_DOMAIN_ID());
		emp_detailsImpl.setEMPLOYMENT_STATUS(emp_details.getEMPLOYMENT_STATUS());
		emp_detailsImpl.setEMPLOYMENT_STATUS_TEXT(emp_details.getEMPLOYMENT_STATUS_TEXT());
		emp_detailsImpl.setFIRST_NAME(emp_details.getFIRST_NAME());
		emp_detailsImpl.setFULL_NAME(emp_details.getFULL_NAME());
		emp_detailsImpl.setGENDER_TEXT(emp_details.getGENDER_TEXT());
		emp_detailsImpl.setHR_EMAIL(emp_details.getHR_EMAIL());
		emp_detailsImpl.setHR_EMP_CD(emp_details.getHR_EMP_CD());
		emp_detailsImpl.setHR_HEAD_EMPCD(emp_details.getHR_HEAD_EMPCD());
		emp_detailsImpl.setHR_HEAD_NAME(emp_details.getHR_HEAD_NAME());
		emp_detailsImpl.setHR_NAME(emp_details.getHR_NAME());
		emp_detailsImpl.setJIO_CENTER(emp_details.getJIO_CENTER());
		emp_detailsImpl.setJIO_ID(emp_details.getJIO_ID());
		emp_detailsImpl.setJO_REGION(emp_details.getJO_REGION());
		emp_detailsImpl.setJO_TYPE(emp_details.getJO_TYPE());
		emp_detailsImpl.setJOB(emp_details.getJOB());
		emp_detailsImpl.setJOB_ROLE_CODE(emp_details.getJOB_ROLE_CODE());
		emp_detailsImpl.setL1_EMAIL_ID(emp_details.getL1_EMAIL_ID());
		emp_detailsImpl.setL1_EMPLOYEE_CODE(emp_details.getL1_EMPLOYEE_CODE());
		emp_detailsImpl.setL1_NAME(emp_details.getL1_NAME());
		emp_detailsImpl.setLAST_NAME(emp_details.getLAST_NAME());
		emp_detailsImpl.setLOCATION_CITY(emp_details.getLOCATION_CITY());
		emp_detailsImpl.setLOCATION_CODE(emp_details.getLOCATION_CODE());
		emp_detailsImpl.setLOCATION_COUNTRY(emp_details.getLOCATION_COUNTRY());
		emp_detailsImpl.setLOCATION_STATE(emp_details.getLOCATION_STATE());
		emp_detailsImpl.setLOCATION_TEXT(emp_details.getLOCATION_TEXT());
		emp_detailsImpl.setMOBILE_NO(emp_details.getMOBILE_NO());
		emp_detailsImpl.setOFFICE_NO(emp_details.getOFFICE_NO());
		emp_detailsImpl.setORG_UNIT(emp_details.getORG_UNIT());
		emp_detailsImpl.setORG_UNIT_TEXT(emp_details.getORG_UNIT_TEXT());
		emp_detailsImpl.setPERSONNEL_AREA_CODE(emp_details.getPERSONNEL_AREA_CODE());
		emp_detailsImpl.setR4G_STATE(emp_details.getR4G_STATE());
		emp_detailsImpl.setSAML_FEDERATION_ID(emp_details.getSAML_FEDERATION_ID());
		emp_detailsImpl.setSTORE_CODE(emp_details.getSTORE_CODE());
		emp_detailsImpl.setSUB_FUNCTIONAL_AREA(emp_details.getSUB_FUNCTIONAL_AREA());
		emp_detailsImpl.setTITLE(emp_details.getTITLE());
		emp_detailsImpl.setIS_RESOLVER(emp_details.getIS_RESOLVER());
		emp_detailsImpl.setRESOLVER_LEVEL(emp_details.getRESOLVER_LEVEL());
		emp_detailsImpl.setPERSONAL_AREA_TEXT(emp_details.getPERSONAL_AREA_TEXT());
		emp_detailsImpl.setFUNCTIONAL_AREA(emp_details.getFUNCTIONAL_AREA());
		emp_detailsImpl.setRESOLVER_STATUS(emp_details.getRESOLVER_STATUS());

		return emp_detailsImpl;
	}

	/**
	 * Returns the e m p_ d e t a i l s with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the e m p_ d e t a i l s
	 * @return the e m p_ d e t a i l s
	 * @throws com.jioc.query.NoSuchEMP_DETAILSException if a e m p_ d e t a i l s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EMP_DETAILS findByPrimaryKey(Serializable primaryKey)
		throws NoSuchEMP_DETAILSException, SystemException {
		EMP_DETAILS emp_details = fetchByPrimaryKey(primaryKey);

		if (emp_details == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchEMP_DETAILSException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return emp_details;
	}

	/**
	 * Returns the e m p_ d e t a i l s with the primary key or throws a {@link com.jioc.query.NoSuchEMP_DETAILSException} if it could not be found.
	 *
	 * @param EMP_ID the primary key of the e m p_ d e t a i l s
	 * @return the e m p_ d e t a i l s
	 * @throws com.jioc.query.NoSuchEMP_DETAILSException if a e m p_ d e t a i l s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EMP_DETAILS findByPrimaryKey(String EMP_ID)
		throws NoSuchEMP_DETAILSException, SystemException {
		return findByPrimaryKey((Serializable)EMP_ID);
	}

	/**
	 * Returns the e m p_ d e t a i l s with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the e m p_ d e t a i l s
	 * @return the e m p_ d e t a i l s, or <code>null</code> if a e m p_ d e t a i l s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EMP_DETAILS fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		EMP_DETAILS emp_details = (EMP_DETAILS)EntityCacheUtil.getResult(EMP_DETAILSModelImpl.ENTITY_CACHE_ENABLED,
				EMP_DETAILSImpl.class, primaryKey);

		if (emp_details == _nullEMP_DETAILS) {
			return null;
		}

		if (emp_details == null) {
			Session session = null;

			try {
				session = openSession();

				emp_details = (EMP_DETAILS)session.get(EMP_DETAILSImpl.class,
						primaryKey);

				if (emp_details != null) {
					cacheResult(emp_details);
				}
				else {
					EntityCacheUtil.putResult(EMP_DETAILSModelImpl.ENTITY_CACHE_ENABLED,
						EMP_DETAILSImpl.class, primaryKey, _nullEMP_DETAILS);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(EMP_DETAILSModelImpl.ENTITY_CACHE_ENABLED,
					EMP_DETAILSImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return emp_details;
	}

	/**
	 * Returns the e m p_ d e t a i l s with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param EMP_ID the primary key of the e m p_ d e t a i l s
	 * @return the e m p_ d e t a i l s, or <code>null</code> if a e m p_ d e t a i l s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public EMP_DETAILS fetchByPrimaryKey(String EMP_ID)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)EMP_ID);
	}

	/**
	 * Returns all the e m p_ d e t a i l ses.
	 *
	 * @return the e m p_ d e t a i l ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EMP_DETAILS> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the e m p_ d e t a i l ses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.EMP_DETAILSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of e m p_ d e t a i l ses
	 * @param end the upper bound of the range of e m p_ d e t a i l ses (not inclusive)
	 * @return the range of e m p_ d e t a i l ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EMP_DETAILS> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the e m p_ d e t a i l ses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.EMP_DETAILSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of e m p_ d e t a i l ses
	 * @param end the upper bound of the range of e m p_ d e t a i l ses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of e m p_ d e t a i l ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<EMP_DETAILS> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<EMP_DETAILS> list = (List<EMP_DETAILS>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_EMP_DETAILS);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_EMP_DETAILS;

				if (pagination) {
					sql = sql.concat(EMP_DETAILSModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<EMP_DETAILS>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<EMP_DETAILS>(list);
				}
				else {
					list = (List<EMP_DETAILS>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the e m p_ d e t a i l ses from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (EMP_DETAILS emp_details : findAll()) {
			remove(emp_details);
		}
	}

	/**
	 * Returns the number of e m p_ d e t a i l ses.
	 *
	 * @return the number of e m p_ d e t a i l ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_EMP_DETAILS);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the e m p_ d e t a i l s persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.jioc.query.model.EMP_DETAILS")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<EMP_DETAILS>> listenersList = new ArrayList<ModelListener<EMP_DETAILS>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<EMP_DETAILS>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(EMP_DETAILSImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_EMP_DETAILS = "SELECT emp_details FROM EMP_DETAILS emp_details";
	private static final String _SQL_SELECT_EMP_DETAILS_WHERE = "SELECT emp_details FROM EMP_DETAILS emp_details WHERE ";
	private static final String _SQL_COUNT_EMP_DETAILS = "SELECT COUNT(emp_details) FROM EMP_DETAILS emp_details";
	private static final String _SQL_COUNT_EMP_DETAILS_WHERE = "SELECT COUNT(emp_details) FROM EMP_DETAILS emp_details WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "emp_details.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No EMP_DETAILS exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No EMP_DETAILS exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(EMP_DETAILSPersistenceImpl.class);
	private static EMP_DETAILS _nullEMP_DETAILS = new EMP_DETAILSImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<EMP_DETAILS> toCacheModel() {
				return _nullEMP_DETAILSCacheModel;
			}
		};

	private static CacheModel<EMP_DETAILS> _nullEMP_DETAILSCacheModel = new CacheModel<EMP_DETAILS>() {
			@Override
			public EMP_DETAILS toEntityModel() {
				return _nullEMP_DETAILS;
			}
		};
}