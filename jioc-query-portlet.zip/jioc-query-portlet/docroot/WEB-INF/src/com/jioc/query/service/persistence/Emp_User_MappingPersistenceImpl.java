/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.NoSuchEmp_User_MappingException;
import com.jioc.query.model.Emp_User_Mapping;
import com.jioc.query.model.impl.Emp_User_MappingImpl;
import com.jioc.query.model.impl.Emp_User_MappingModelImpl;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the emp_ user_ mapping service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see Emp_User_MappingPersistence
 * @see Emp_User_MappingUtil
 * @generated
 */
public class Emp_User_MappingPersistenceImpl extends BasePersistenceImpl<Emp_User_Mapping>
	implements Emp_User_MappingPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link Emp_User_MappingUtil} to access the emp_ user_ mapping persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = Emp_User_MappingImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(Emp_User_MappingModelImpl.ENTITY_CACHE_ENABLED,
			Emp_User_MappingModelImpl.FINDER_CACHE_ENABLED,
			Emp_User_MappingImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(Emp_User_MappingModelImpl.ENTITY_CACHE_ENABLED,
			Emp_User_MappingModelImpl.FINDER_CACHE_ENABLED,
			Emp_User_MappingImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(Emp_User_MappingModelImpl.ENTITY_CACHE_ENABLED,
			Emp_User_MappingModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_EMPID = new FinderPath(Emp_User_MappingModelImpl.ENTITY_CACHE_ENABLED,
			Emp_User_MappingModelImpl.FINDER_CACHE_ENABLED,
			Emp_User_MappingImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByEmpId",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EMPID = new FinderPath(Emp_User_MappingModelImpl.ENTITY_CACHE_ENABLED,
			Emp_User_MappingModelImpl.FINDER_CACHE_ENABLED,
			Emp_User_MappingImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByEmpId",
			new String[] { String.class.getName() },
			Emp_User_MappingModelImpl.EMPID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_EMPID = new FinderPath(Emp_User_MappingModelImpl.ENTITY_CACHE_ENABLED,
			Emp_User_MappingModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByEmpId",
			new String[] { String.class.getName() });

	/**
	 * Returns all the emp_ user_ mappings where empId = &#63;.
	 *
	 * @param empId the emp ID
	 * @return the matching emp_ user_ mappings
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Emp_User_Mapping> findByEmpId(String empId)
		throws SystemException {
		return findByEmpId(empId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the emp_ user_ mappings where empId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Emp_User_MappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param empId the emp ID
	 * @param start the lower bound of the range of emp_ user_ mappings
	 * @param end the upper bound of the range of emp_ user_ mappings (not inclusive)
	 * @return the range of matching emp_ user_ mappings
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Emp_User_Mapping> findByEmpId(String empId, int start, int end)
		throws SystemException {
		return findByEmpId(empId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the emp_ user_ mappings where empId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Emp_User_MappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param empId the emp ID
	 * @param start the lower bound of the range of emp_ user_ mappings
	 * @param end the upper bound of the range of emp_ user_ mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching emp_ user_ mappings
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Emp_User_Mapping> findByEmpId(String empId, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EMPID;
			finderArgs = new Object[] { empId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_EMPID;
			finderArgs = new Object[] { empId, start, end, orderByComparator };
		}

		List<Emp_User_Mapping> list = (List<Emp_User_Mapping>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Emp_User_Mapping emp_User_Mapping : list) {
				if (!Validator.equals(empId, emp_User_Mapping.getEmpId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_EMP_USER_MAPPING_WHERE);

			boolean bindEmpId = false;

			if (empId == null) {
				query.append(_FINDER_COLUMN_EMPID_EMPID_1);
			}
			else if (empId.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_EMPID_EMPID_3);
			}
			else {
				bindEmpId = true;

				query.append(_FINDER_COLUMN_EMPID_EMPID_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(Emp_User_MappingModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindEmpId) {
					qPos.add(empId);
				}

				if (!pagination) {
					list = (List<Emp_User_Mapping>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Emp_User_Mapping>(list);
				}
				else {
					list = (List<Emp_User_Mapping>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first emp_ user_ mapping in the ordered set where empId = &#63;.
	 *
	 * @param empId the emp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching emp_ user_ mapping
	 * @throws com.jioc.query.NoSuchEmp_User_MappingException if a matching emp_ user_ mapping could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Emp_User_Mapping findByEmpId_First(String empId,
		OrderByComparator orderByComparator)
		throws NoSuchEmp_User_MappingException, SystemException {
		Emp_User_Mapping emp_User_Mapping = fetchByEmpId_First(empId,
				orderByComparator);

		if (emp_User_Mapping != null) {
			return emp_User_Mapping;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("empId=");
		msg.append(empId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchEmp_User_MappingException(msg.toString());
	}

	/**
	 * Returns the first emp_ user_ mapping in the ordered set where empId = &#63;.
	 *
	 * @param empId the emp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching emp_ user_ mapping, or <code>null</code> if a matching emp_ user_ mapping could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Emp_User_Mapping fetchByEmpId_First(String empId,
		OrderByComparator orderByComparator) throws SystemException {
		List<Emp_User_Mapping> list = findByEmpId(empId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last emp_ user_ mapping in the ordered set where empId = &#63;.
	 *
	 * @param empId the emp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching emp_ user_ mapping
	 * @throws com.jioc.query.NoSuchEmp_User_MappingException if a matching emp_ user_ mapping could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Emp_User_Mapping findByEmpId_Last(String empId,
		OrderByComparator orderByComparator)
		throws NoSuchEmp_User_MappingException, SystemException {
		Emp_User_Mapping emp_User_Mapping = fetchByEmpId_Last(empId,
				orderByComparator);

		if (emp_User_Mapping != null) {
			return emp_User_Mapping;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("empId=");
		msg.append(empId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchEmp_User_MappingException(msg.toString());
	}

	/**
	 * Returns the last emp_ user_ mapping in the ordered set where empId = &#63;.
	 *
	 * @param empId the emp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching emp_ user_ mapping, or <code>null</code> if a matching emp_ user_ mapping could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Emp_User_Mapping fetchByEmpId_Last(String empId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByEmpId(empId);

		if (count == 0) {
			return null;
		}

		List<Emp_User_Mapping> list = findByEmpId(empId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the emp_ user_ mappings before and after the current emp_ user_ mapping in the ordered set where empId = &#63;.
	 *
	 * @param userId the primary key of the current emp_ user_ mapping
	 * @param empId the emp ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next emp_ user_ mapping
	 * @throws com.jioc.query.NoSuchEmp_User_MappingException if a emp_ user_ mapping with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Emp_User_Mapping[] findByEmpId_PrevAndNext(long userId,
		String empId, OrderByComparator orderByComparator)
		throws NoSuchEmp_User_MappingException, SystemException {
		Emp_User_Mapping emp_User_Mapping = findByPrimaryKey(userId);

		Session session = null;

		try {
			session = openSession();

			Emp_User_Mapping[] array = new Emp_User_MappingImpl[3];

			array[0] = getByEmpId_PrevAndNext(session, emp_User_Mapping, empId,
					orderByComparator, true);

			array[1] = emp_User_Mapping;

			array[2] = getByEmpId_PrevAndNext(session, emp_User_Mapping, empId,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Emp_User_Mapping getByEmpId_PrevAndNext(Session session,
		Emp_User_Mapping emp_User_Mapping, String empId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_EMP_USER_MAPPING_WHERE);

		boolean bindEmpId = false;

		if (empId == null) {
			query.append(_FINDER_COLUMN_EMPID_EMPID_1);
		}
		else if (empId.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_EMPID_EMPID_3);
		}
		else {
			bindEmpId = true;

			query.append(_FINDER_COLUMN_EMPID_EMPID_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(Emp_User_MappingModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindEmpId) {
			qPos.add(empId);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(emp_User_Mapping);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Emp_User_Mapping> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the emp_ user_ mappings where empId = &#63; from the database.
	 *
	 * @param empId the emp ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByEmpId(String empId) throws SystemException {
		for (Emp_User_Mapping emp_User_Mapping : findByEmpId(empId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(emp_User_Mapping);
		}
	}

	/**
	 * Returns the number of emp_ user_ mappings where empId = &#63;.
	 *
	 * @param empId the emp ID
	 * @return the number of matching emp_ user_ mappings
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByEmpId(String empId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_EMPID;

		Object[] finderArgs = new Object[] { empId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_EMP_USER_MAPPING_WHERE);

			boolean bindEmpId = false;

			if (empId == null) {
				query.append(_FINDER_COLUMN_EMPID_EMPID_1);
			}
			else if (empId.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_EMPID_EMPID_3);
			}
			else {
				bindEmpId = true;

				query.append(_FINDER_COLUMN_EMPID_EMPID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindEmpId) {
					qPos.add(empId);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_EMPID_EMPID_1 = "emp_User_Mapping.empId IS NULL";
	private static final String _FINDER_COLUMN_EMPID_EMPID_2 = "emp_User_Mapping.empId = ?";
	private static final String _FINDER_COLUMN_EMPID_EMPID_3 = "(emp_User_Mapping.empId IS NULL OR emp_User_Mapping.empId = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_EMAILID = new FinderPath(Emp_User_MappingModelImpl.ENTITY_CACHE_ENABLED,
			Emp_User_MappingModelImpl.FINDER_CACHE_ENABLED,
			Emp_User_MappingImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByEmailId",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EMAILID =
		new FinderPath(Emp_User_MappingModelImpl.ENTITY_CACHE_ENABLED,
			Emp_User_MappingModelImpl.FINDER_CACHE_ENABLED,
			Emp_User_MappingImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByEmailId",
			new String[] { String.class.getName() },
			Emp_User_MappingModelImpl.EMAILID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_EMAILID = new FinderPath(Emp_User_MappingModelImpl.ENTITY_CACHE_ENABLED,
			Emp_User_MappingModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByEmailId",
			new String[] { String.class.getName() });

	/**
	 * Returns all the emp_ user_ mappings where emailId = &#63;.
	 *
	 * @param emailId the email ID
	 * @return the matching emp_ user_ mappings
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Emp_User_Mapping> findByEmailId(String emailId)
		throws SystemException {
		return findByEmailId(emailId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the emp_ user_ mappings where emailId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Emp_User_MappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param emailId the email ID
	 * @param start the lower bound of the range of emp_ user_ mappings
	 * @param end the upper bound of the range of emp_ user_ mappings (not inclusive)
	 * @return the range of matching emp_ user_ mappings
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Emp_User_Mapping> findByEmailId(String emailId, int start,
		int end) throws SystemException {
		return findByEmailId(emailId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the emp_ user_ mappings where emailId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Emp_User_MappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param emailId the email ID
	 * @param start the lower bound of the range of emp_ user_ mappings
	 * @param end the upper bound of the range of emp_ user_ mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching emp_ user_ mappings
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Emp_User_Mapping> findByEmailId(String emailId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EMAILID;
			finderArgs = new Object[] { emailId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_EMAILID;
			finderArgs = new Object[] { emailId, start, end, orderByComparator };
		}

		List<Emp_User_Mapping> list = (List<Emp_User_Mapping>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Emp_User_Mapping emp_User_Mapping : list) {
				if (!Validator.equals(emailId, emp_User_Mapping.getEmailId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_EMP_USER_MAPPING_WHERE);

			boolean bindEmailId = false;

			if (emailId == null) {
				query.append(_FINDER_COLUMN_EMAILID_EMAILID_1);
			}
			else if (emailId.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_EMAILID_EMAILID_3);
			}
			else {
				bindEmailId = true;

				query.append(_FINDER_COLUMN_EMAILID_EMAILID_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(Emp_User_MappingModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindEmailId) {
					qPos.add(emailId.toLowerCase());
				}

				if (!pagination) {
					list = (List<Emp_User_Mapping>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Emp_User_Mapping>(list);
				}
				else {
					list = (List<Emp_User_Mapping>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first emp_ user_ mapping in the ordered set where emailId = &#63;.
	 *
	 * @param emailId the email ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching emp_ user_ mapping
	 * @throws com.jioc.query.NoSuchEmp_User_MappingException if a matching emp_ user_ mapping could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Emp_User_Mapping findByEmailId_First(String emailId,
		OrderByComparator orderByComparator)
		throws NoSuchEmp_User_MappingException, SystemException {
		Emp_User_Mapping emp_User_Mapping = fetchByEmailId_First(emailId,
				orderByComparator);

		if (emp_User_Mapping != null) {
			return emp_User_Mapping;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("emailId=");
		msg.append(emailId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchEmp_User_MappingException(msg.toString());
	}

	/**
	 * Returns the first emp_ user_ mapping in the ordered set where emailId = &#63;.
	 *
	 * @param emailId the email ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching emp_ user_ mapping, or <code>null</code> if a matching emp_ user_ mapping could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Emp_User_Mapping fetchByEmailId_First(String emailId,
		OrderByComparator orderByComparator) throws SystemException {
		List<Emp_User_Mapping> list = findByEmailId(emailId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last emp_ user_ mapping in the ordered set where emailId = &#63;.
	 *
	 * @param emailId the email ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching emp_ user_ mapping
	 * @throws com.jioc.query.NoSuchEmp_User_MappingException if a matching emp_ user_ mapping could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Emp_User_Mapping findByEmailId_Last(String emailId,
		OrderByComparator orderByComparator)
		throws NoSuchEmp_User_MappingException, SystemException {
		Emp_User_Mapping emp_User_Mapping = fetchByEmailId_Last(emailId,
				orderByComparator);

		if (emp_User_Mapping != null) {
			return emp_User_Mapping;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("emailId=");
		msg.append(emailId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchEmp_User_MappingException(msg.toString());
	}

	/**
	 * Returns the last emp_ user_ mapping in the ordered set where emailId = &#63;.
	 *
	 * @param emailId the email ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching emp_ user_ mapping, or <code>null</code> if a matching emp_ user_ mapping could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Emp_User_Mapping fetchByEmailId_Last(String emailId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByEmailId(emailId);

		if (count == 0) {
			return null;
		}

		List<Emp_User_Mapping> list = findByEmailId(emailId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the emp_ user_ mappings before and after the current emp_ user_ mapping in the ordered set where emailId = &#63;.
	 *
	 * @param userId the primary key of the current emp_ user_ mapping
	 * @param emailId the email ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next emp_ user_ mapping
	 * @throws com.jioc.query.NoSuchEmp_User_MappingException if a emp_ user_ mapping with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Emp_User_Mapping[] findByEmailId_PrevAndNext(long userId,
		String emailId, OrderByComparator orderByComparator)
		throws NoSuchEmp_User_MappingException, SystemException {
		Emp_User_Mapping emp_User_Mapping = findByPrimaryKey(userId);

		Session session = null;

		try {
			session = openSession();

			Emp_User_Mapping[] array = new Emp_User_MappingImpl[3];

			array[0] = getByEmailId_PrevAndNext(session, emp_User_Mapping,
					emailId, orderByComparator, true);

			array[1] = emp_User_Mapping;

			array[2] = getByEmailId_PrevAndNext(session, emp_User_Mapping,
					emailId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Emp_User_Mapping getByEmailId_PrevAndNext(Session session,
		Emp_User_Mapping emp_User_Mapping, String emailId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_EMP_USER_MAPPING_WHERE);

		boolean bindEmailId = false;

		if (emailId == null) {
			query.append(_FINDER_COLUMN_EMAILID_EMAILID_1);
		}
		else if (emailId.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_EMAILID_EMAILID_3);
		}
		else {
			bindEmailId = true;

			query.append(_FINDER_COLUMN_EMAILID_EMAILID_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(Emp_User_MappingModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindEmailId) {
			qPos.add(emailId.toLowerCase());
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(emp_User_Mapping);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Emp_User_Mapping> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the emp_ user_ mappings where emailId = &#63; from the database.
	 *
	 * @param emailId the email ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByEmailId(String emailId) throws SystemException {
		for (Emp_User_Mapping emp_User_Mapping : findByEmailId(emailId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(emp_User_Mapping);
		}
	}

	/**
	 * Returns the number of emp_ user_ mappings where emailId = &#63;.
	 *
	 * @param emailId the email ID
	 * @return the number of matching emp_ user_ mappings
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByEmailId(String emailId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_EMAILID;

		Object[] finderArgs = new Object[] { emailId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_EMP_USER_MAPPING_WHERE);

			boolean bindEmailId = false;

			if (emailId == null) {
				query.append(_FINDER_COLUMN_EMAILID_EMAILID_1);
			}
			else if (emailId.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_EMAILID_EMAILID_3);
			}
			else {
				bindEmailId = true;

				query.append(_FINDER_COLUMN_EMAILID_EMAILID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindEmailId) {
					qPos.add(emailId.toLowerCase());
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_EMAILID_EMAILID_1 = "emp_User_Mapping.emailId IS NULL";
	private static final String _FINDER_COLUMN_EMAILID_EMAILID_2 = "lower(emp_User_Mapping.emailId) = ?";
	private static final String _FINDER_COLUMN_EMAILID_EMAILID_3 = "(emp_User_Mapping.emailId IS NULL OR emp_User_Mapping.emailId = '')";

	public Emp_User_MappingPersistenceImpl() {
		setModelClass(Emp_User_Mapping.class);
	}

	/**
	 * Caches the emp_ user_ mapping in the entity cache if it is enabled.
	 *
	 * @param emp_User_Mapping the emp_ user_ mapping
	 */
	@Override
	public void cacheResult(Emp_User_Mapping emp_User_Mapping) {
		EntityCacheUtil.putResult(Emp_User_MappingModelImpl.ENTITY_CACHE_ENABLED,
			Emp_User_MappingImpl.class, emp_User_Mapping.getPrimaryKey(),
			emp_User_Mapping);

		emp_User_Mapping.resetOriginalValues();
	}

	/**
	 * Caches the emp_ user_ mappings in the entity cache if it is enabled.
	 *
	 * @param emp_User_Mappings the emp_ user_ mappings
	 */
	@Override
	public void cacheResult(List<Emp_User_Mapping> emp_User_Mappings) {
		for (Emp_User_Mapping emp_User_Mapping : emp_User_Mappings) {
			if (EntityCacheUtil.getResult(
						Emp_User_MappingModelImpl.ENTITY_CACHE_ENABLED,
						Emp_User_MappingImpl.class,
						emp_User_Mapping.getPrimaryKey()) == null) {
				cacheResult(emp_User_Mapping);
			}
			else {
				emp_User_Mapping.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all emp_ user_ mappings.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(Emp_User_MappingImpl.class.getName());
		}

		EntityCacheUtil.clearCache(Emp_User_MappingImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the emp_ user_ mapping.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(Emp_User_Mapping emp_User_Mapping) {
		EntityCacheUtil.removeResult(Emp_User_MappingModelImpl.ENTITY_CACHE_ENABLED,
			Emp_User_MappingImpl.class, emp_User_Mapping.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<Emp_User_Mapping> emp_User_Mappings) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (Emp_User_Mapping emp_User_Mapping : emp_User_Mappings) {
			EntityCacheUtil.removeResult(Emp_User_MappingModelImpl.ENTITY_CACHE_ENABLED,
				Emp_User_MappingImpl.class, emp_User_Mapping.getPrimaryKey());
		}
	}

	/**
	 * Creates a new emp_ user_ mapping with the primary key. Does not add the emp_ user_ mapping to the database.
	 *
	 * @param userId the primary key for the new emp_ user_ mapping
	 * @return the new emp_ user_ mapping
	 */
	@Override
	public Emp_User_Mapping create(long userId) {
		Emp_User_Mapping emp_User_Mapping = new Emp_User_MappingImpl();

		emp_User_Mapping.setNew(true);
		emp_User_Mapping.setPrimaryKey(userId);

		return emp_User_Mapping;
	}

	/**
	 * Removes the emp_ user_ mapping with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param userId the primary key of the emp_ user_ mapping
	 * @return the emp_ user_ mapping that was removed
	 * @throws com.jioc.query.NoSuchEmp_User_MappingException if a emp_ user_ mapping with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Emp_User_Mapping remove(long userId)
		throws NoSuchEmp_User_MappingException, SystemException {
		return remove((Serializable)userId);
	}

	/**
	 * Removes the emp_ user_ mapping with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the emp_ user_ mapping
	 * @return the emp_ user_ mapping that was removed
	 * @throws com.jioc.query.NoSuchEmp_User_MappingException if a emp_ user_ mapping with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Emp_User_Mapping remove(Serializable primaryKey)
		throws NoSuchEmp_User_MappingException, SystemException {
		Session session = null;

		try {
			session = openSession();

			Emp_User_Mapping emp_User_Mapping = (Emp_User_Mapping)session.get(Emp_User_MappingImpl.class,
					primaryKey);

			if (emp_User_Mapping == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchEmp_User_MappingException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(emp_User_Mapping);
		}
		catch (NoSuchEmp_User_MappingException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected Emp_User_Mapping removeImpl(Emp_User_Mapping emp_User_Mapping)
		throws SystemException {
		emp_User_Mapping = toUnwrappedModel(emp_User_Mapping);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(emp_User_Mapping)) {
				emp_User_Mapping = (Emp_User_Mapping)session.get(Emp_User_MappingImpl.class,
						emp_User_Mapping.getPrimaryKeyObj());
			}

			if (emp_User_Mapping != null) {
				session.delete(emp_User_Mapping);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (emp_User_Mapping != null) {
			clearCache(emp_User_Mapping);
		}

		return emp_User_Mapping;
	}

	@Override
	public Emp_User_Mapping updateImpl(
		com.jioc.query.model.Emp_User_Mapping emp_User_Mapping)
		throws SystemException {
		emp_User_Mapping = toUnwrappedModel(emp_User_Mapping);

		boolean isNew = emp_User_Mapping.isNew();

		Emp_User_MappingModelImpl emp_User_MappingModelImpl = (Emp_User_MappingModelImpl)emp_User_Mapping;

		Session session = null;

		try {
			session = openSession();

			if (emp_User_Mapping.isNew()) {
				session.save(emp_User_Mapping);

				emp_User_Mapping.setNew(false);
			}
			else {
				session.merge(emp_User_Mapping);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !Emp_User_MappingModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((emp_User_MappingModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EMPID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						emp_User_MappingModelImpl.getOriginalEmpId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_EMPID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EMPID,
					args);

				args = new Object[] { emp_User_MappingModelImpl.getEmpId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_EMPID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EMPID,
					args);
			}

			if ((emp_User_MappingModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EMAILID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						emp_User_MappingModelImpl.getOriginalEmailId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_EMAILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EMAILID,
					args);

				args = new Object[] { emp_User_MappingModelImpl.getEmailId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_EMAILID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EMAILID,
					args);
			}
		}

		EntityCacheUtil.putResult(Emp_User_MappingModelImpl.ENTITY_CACHE_ENABLED,
			Emp_User_MappingImpl.class, emp_User_Mapping.getPrimaryKey(),
			emp_User_Mapping);

		return emp_User_Mapping;
	}

	protected Emp_User_Mapping toUnwrappedModel(
		Emp_User_Mapping emp_User_Mapping) {
		if (emp_User_Mapping instanceof Emp_User_MappingImpl) {
			return emp_User_Mapping;
		}

		Emp_User_MappingImpl emp_User_MappingImpl = new Emp_User_MappingImpl();

		emp_User_MappingImpl.setNew(emp_User_Mapping.isNew());
		emp_User_MappingImpl.setPrimaryKey(emp_User_Mapping.getPrimaryKey());

		emp_User_MappingImpl.setUserId(emp_User_Mapping.getUserId());
		emp_User_MappingImpl.setEmpId(emp_User_Mapping.getEmpId());
		emp_User_MappingImpl.setEmailId(emp_User_Mapping.getEmailId());
		emp_User_MappingImpl.setDomainId(emp_User_Mapping.getDomainId());
		emp_User_MappingImpl.setSamlFederationId(emp_User_Mapping.getSamlFederationId());
		emp_User_MappingImpl.setStatus(emp_User_Mapping.getStatus());

		return emp_User_MappingImpl;
	}

	/**
	 * Returns the emp_ user_ mapping with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the emp_ user_ mapping
	 * @return the emp_ user_ mapping
	 * @throws com.jioc.query.NoSuchEmp_User_MappingException if a emp_ user_ mapping with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Emp_User_Mapping findByPrimaryKey(Serializable primaryKey)
		throws NoSuchEmp_User_MappingException, SystemException {
		Emp_User_Mapping emp_User_Mapping = fetchByPrimaryKey(primaryKey);

		if (emp_User_Mapping == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchEmp_User_MappingException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return emp_User_Mapping;
	}

	/**
	 * Returns the emp_ user_ mapping with the primary key or throws a {@link com.jioc.query.NoSuchEmp_User_MappingException} if it could not be found.
	 *
	 * @param userId the primary key of the emp_ user_ mapping
	 * @return the emp_ user_ mapping
	 * @throws com.jioc.query.NoSuchEmp_User_MappingException if a emp_ user_ mapping with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Emp_User_Mapping findByPrimaryKey(long userId)
		throws NoSuchEmp_User_MappingException, SystemException {
		return findByPrimaryKey((Serializable)userId);
	}

	/**
	 * Returns the emp_ user_ mapping with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the emp_ user_ mapping
	 * @return the emp_ user_ mapping, or <code>null</code> if a emp_ user_ mapping with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Emp_User_Mapping fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		Emp_User_Mapping emp_User_Mapping = (Emp_User_Mapping)EntityCacheUtil.getResult(Emp_User_MappingModelImpl.ENTITY_CACHE_ENABLED,
				Emp_User_MappingImpl.class, primaryKey);

		if (emp_User_Mapping == _nullEmp_User_Mapping) {
			return null;
		}

		if (emp_User_Mapping == null) {
			Session session = null;

			try {
				session = openSession();

				emp_User_Mapping = (Emp_User_Mapping)session.get(Emp_User_MappingImpl.class,
						primaryKey);

				if (emp_User_Mapping != null) {
					cacheResult(emp_User_Mapping);
				}
				else {
					EntityCacheUtil.putResult(Emp_User_MappingModelImpl.ENTITY_CACHE_ENABLED,
						Emp_User_MappingImpl.class, primaryKey,
						_nullEmp_User_Mapping);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(Emp_User_MappingModelImpl.ENTITY_CACHE_ENABLED,
					Emp_User_MappingImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return emp_User_Mapping;
	}

	/**
	 * Returns the emp_ user_ mapping with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param userId the primary key of the emp_ user_ mapping
	 * @return the emp_ user_ mapping, or <code>null</code> if a emp_ user_ mapping with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Emp_User_Mapping fetchByPrimaryKey(long userId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)userId);
	}

	/**
	 * Returns all the emp_ user_ mappings.
	 *
	 * @return the emp_ user_ mappings
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Emp_User_Mapping> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the emp_ user_ mappings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Emp_User_MappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of emp_ user_ mappings
	 * @param end the upper bound of the range of emp_ user_ mappings (not inclusive)
	 * @return the range of emp_ user_ mappings
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Emp_User_Mapping> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the emp_ user_ mappings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Emp_User_MappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of emp_ user_ mappings
	 * @param end the upper bound of the range of emp_ user_ mappings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of emp_ user_ mappings
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Emp_User_Mapping> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<Emp_User_Mapping> list = (List<Emp_User_Mapping>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_EMP_USER_MAPPING);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_EMP_USER_MAPPING;

				if (pagination) {
					sql = sql.concat(Emp_User_MappingModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<Emp_User_Mapping>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Emp_User_Mapping>(list);
				}
				else {
					list = (List<Emp_User_Mapping>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the emp_ user_ mappings from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (Emp_User_Mapping emp_User_Mapping : findAll()) {
			remove(emp_User_Mapping);
		}
	}

	/**
	 * Returns the number of emp_ user_ mappings.
	 *
	 * @return the number of emp_ user_ mappings
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_EMP_USER_MAPPING);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the emp_ user_ mapping persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.jioc.query.model.Emp_User_Mapping")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<Emp_User_Mapping>> listenersList = new ArrayList<ModelListener<Emp_User_Mapping>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<Emp_User_Mapping>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(Emp_User_MappingImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_EMP_USER_MAPPING = "SELECT emp_User_Mapping FROM Emp_User_Mapping emp_User_Mapping";
	private static final String _SQL_SELECT_EMP_USER_MAPPING_WHERE = "SELECT emp_User_Mapping FROM Emp_User_Mapping emp_User_Mapping WHERE ";
	private static final String _SQL_COUNT_EMP_USER_MAPPING = "SELECT COUNT(emp_User_Mapping) FROM Emp_User_Mapping emp_User_Mapping";
	private static final String _SQL_COUNT_EMP_USER_MAPPING_WHERE = "SELECT COUNT(emp_User_Mapping) FROM Emp_User_Mapping emp_User_Mapping WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "emp_User_Mapping.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No Emp_User_Mapping exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No Emp_User_Mapping exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(Emp_User_MappingPersistenceImpl.class);
	private static Emp_User_Mapping _nullEmp_User_Mapping = new Emp_User_MappingImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<Emp_User_Mapping> toCacheModel() {
				return _nullEmp_User_MappingCacheModel;
			}
		};

	private static CacheModel<Emp_User_Mapping> _nullEmp_User_MappingCacheModel = new CacheModel<Emp_User_Mapping>() {
			@Override
			public Emp_User_Mapping toEntityModel() {
				return _nullEmp_User_Mapping;
			}
		};
}