/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model.impl;

import com.jioc.query.model.EMP_DETAILS;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing EMP_DETAILS in entity cache.
 *
 * @author shantaram.chavan
 * @see EMP_DETAILS
 * @generated
 */
public class EMP_DETAILSCacheModel implements CacheModel<EMP_DETAILS>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(111);

		sb.append("{EMP_ID=");
		sb.append(EMP_ID);
		sb.append(", AREA=");
		sb.append(AREA);
		sb.append(", CADRE=");
		sb.append(CADRE);
		sb.append(", CLIENT_ID=");
		sb.append(CLIENT_ID);
		sb.append(", COMPANY_CODE=");
		sb.append(COMPANY_CODE);
		sb.append(", COMPANY_TEXT=");
		sb.append(COMPANY_TEXT);
		sb.append(", DATE_OF_BIRTH=");
		sb.append(DATE_OF_BIRTH);
		sb.append(", DATE_OF_JOINING=");
		sb.append(DATE_OF_JOINING);
		sb.append(", DATE_OF_LEAVE=");
		sb.append(DATE_OF_LEAVE);
		sb.append(", DEPARTMENT=");
		sb.append(DEPARTMENT);
		sb.append(", DESIGNATION_CODE=");
		sb.append(DESIGNATION_CODE);
		sb.append(", DESIGNATION_TEXT=");
		sb.append(DESIGNATION_TEXT);
		sb.append(", EMAIL=");
		sb.append(EMAIL);
		sb.append(", EMP_GROUP=");
		sb.append(EMP_GROUP);
		sb.append(", EMPLOYEE_DOMAIN_ID=");
		sb.append(EMPLOYEE_DOMAIN_ID);
		sb.append(", EMPLOYMENT_STATUS=");
		sb.append(EMPLOYMENT_STATUS);
		sb.append(", EMPLOYMENT_STATUS_TEXT=");
		sb.append(EMPLOYMENT_STATUS_TEXT);
		sb.append(", FIRST_NAME=");
		sb.append(FIRST_NAME);
		sb.append(", FULL_NAME=");
		sb.append(FULL_NAME);
		sb.append(", GENDER_TEXT=");
		sb.append(GENDER_TEXT);
		sb.append(", HR_EMAIL=");
		sb.append(HR_EMAIL);
		sb.append(", HR_EMP_CD=");
		sb.append(HR_EMP_CD);
		sb.append(", HR_HEAD_EMPCD=");
		sb.append(HR_HEAD_EMPCD);
		sb.append(", HR_HEAD_NAME=");
		sb.append(HR_HEAD_NAME);
		sb.append(", HR_NAME=");
		sb.append(HR_NAME);
		sb.append(", JIO_CENTER=");
		sb.append(JIO_CENTER);
		sb.append(", JIO_ID=");
		sb.append(JIO_ID);
		sb.append(", JO_REGION=");
		sb.append(JO_REGION);
		sb.append(", JO_TYPE=");
		sb.append(JO_TYPE);
		sb.append(", JOB=");
		sb.append(JOB);
		sb.append(", JOB_ROLE_CODE=");
		sb.append(JOB_ROLE_CODE);
		sb.append(", L1_EMAIL_ID=");
		sb.append(L1_EMAIL_ID);
		sb.append(", L1_EMPLOYEE_CODE=");
		sb.append(L1_EMPLOYEE_CODE);
		sb.append(", L1_NAME=");
		sb.append(L1_NAME);
		sb.append(", LAST_NAME=");
		sb.append(LAST_NAME);
		sb.append(", LOCATION_CITY=");
		sb.append(LOCATION_CITY);
		sb.append(", LOCATION_CODE=");
		sb.append(LOCATION_CODE);
		sb.append(", LOCATION_COUNTRY=");
		sb.append(LOCATION_COUNTRY);
		sb.append(", LOCATION_STATE=");
		sb.append(LOCATION_STATE);
		sb.append(", LOCATION_TEXT=");
		sb.append(LOCATION_TEXT);
		sb.append(", MOBILE_NO=");
		sb.append(MOBILE_NO);
		sb.append(", OFFICE_NO=");
		sb.append(OFFICE_NO);
		sb.append(", ORG_UNIT=");
		sb.append(ORG_UNIT);
		sb.append(", ORG_UNIT_TEXT=");
		sb.append(ORG_UNIT_TEXT);
		sb.append(", PERSONNEL_AREA_CODE=");
		sb.append(PERSONNEL_AREA_CODE);
		sb.append(", R4G_STATE=");
		sb.append(R4G_STATE);
		sb.append(", SAML_FEDERATION_ID=");
		sb.append(SAML_FEDERATION_ID);
		sb.append(", STORE_CODE=");
		sb.append(STORE_CODE);
		sb.append(", SUB_FUNCTIONAL_AREA=");
		sb.append(SUB_FUNCTIONAL_AREA);
		sb.append(", TITLE=");
		sb.append(TITLE);
		sb.append(", IS_RESOLVER=");
		sb.append(IS_RESOLVER);
		sb.append(", RESOLVER_LEVEL=");
		sb.append(RESOLVER_LEVEL);
		sb.append(", PERSONAL_AREA_TEXT=");
		sb.append(PERSONAL_AREA_TEXT);
		sb.append(", FUNCTIONAL_AREA=");
		sb.append(FUNCTIONAL_AREA);
		sb.append(", RESOLVER_STATUS=");
		sb.append(RESOLVER_STATUS);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public EMP_DETAILS toEntityModel() {
		EMP_DETAILSImpl emp_detailsImpl = new EMP_DETAILSImpl();

		if (EMP_ID == null) {
			emp_detailsImpl.setEMP_ID(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setEMP_ID(EMP_ID);
		}

		if (AREA == null) {
			emp_detailsImpl.setAREA(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setAREA(AREA);
		}

		if (CADRE == null) {
			emp_detailsImpl.setCADRE(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setCADRE(CADRE);
		}

		if (CLIENT_ID == null) {
			emp_detailsImpl.setCLIENT_ID(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setCLIENT_ID(CLIENT_ID);
		}

		if (COMPANY_CODE == null) {
			emp_detailsImpl.setCOMPANY_CODE(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setCOMPANY_CODE(COMPANY_CODE);
		}

		if (COMPANY_TEXT == null) {
			emp_detailsImpl.setCOMPANY_TEXT(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setCOMPANY_TEXT(COMPANY_TEXT);
		}

		if (DATE_OF_BIRTH == Long.MIN_VALUE) {
			emp_detailsImpl.setDATE_OF_BIRTH(null);
		}
		else {
			emp_detailsImpl.setDATE_OF_BIRTH(new Date(DATE_OF_BIRTH));
		}

		if (DATE_OF_JOINING == Long.MIN_VALUE) {
			emp_detailsImpl.setDATE_OF_JOINING(null);
		}
		else {
			emp_detailsImpl.setDATE_OF_JOINING(new Date(DATE_OF_JOINING));
		}

		if (DATE_OF_LEAVE == Long.MIN_VALUE) {
			emp_detailsImpl.setDATE_OF_LEAVE(null);
		}
		else {
			emp_detailsImpl.setDATE_OF_LEAVE(new Date(DATE_OF_LEAVE));
		}

		if (DEPARTMENT == null) {
			emp_detailsImpl.setDEPARTMENT(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setDEPARTMENT(DEPARTMENT);
		}

		if (DESIGNATION_CODE == null) {
			emp_detailsImpl.setDESIGNATION_CODE(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setDESIGNATION_CODE(DESIGNATION_CODE);
		}

		if (DESIGNATION_TEXT == null) {
			emp_detailsImpl.setDESIGNATION_TEXT(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setDESIGNATION_TEXT(DESIGNATION_TEXT);
		}

		if (EMAIL == null) {
			emp_detailsImpl.setEMAIL(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setEMAIL(EMAIL);
		}

		if (EMP_GROUP == null) {
			emp_detailsImpl.setEMP_GROUP(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setEMP_GROUP(EMP_GROUP);
		}

		if (EMPLOYEE_DOMAIN_ID == null) {
			emp_detailsImpl.setEMPLOYEE_DOMAIN_ID(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setEMPLOYEE_DOMAIN_ID(EMPLOYEE_DOMAIN_ID);
		}

		if (EMPLOYMENT_STATUS == null) {
			emp_detailsImpl.setEMPLOYMENT_STATUS(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setEMPLOYMENT_STATUS(EMPLOYMENT_STATUS);
		}

		if (EMPLOYMENT_STATUS_TEXT == null) {
			emp_detailsImpl.setEMPLOYMENT_STATUS_TEXT(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setEMPLOYMENT_STATUS_TEXT(EMPLOYMENT_STATUS_TEXT);
		}

		if (FIRST_NAME == null) {
			emp_detailsImpl.setFIRST_NAME(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setFIRST_NAME(FIRST_NAME);
		}

		if (FULL_NAME == null) {
			emp_detailsImpl.setFULL_NAME(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setFULL_NAME(FULL_NAME);
		}

		if (GENDER_TEXT == null) {
			emp_detailsImpl.setGENDER_TEXT(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setGENDER_TEXT(GENDER_TEXT);
		}

		if (HR_EMAIL == null) {
			emp_detailsImpl.setHR_EMAIL(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setHR_EMAIL(HR_EMAIL);
		}

		if (HR_EMP_CD == null) {
			emp_detailsImpl.setHR_EMP_CD(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setHR_EMP_CD(HR_EMP_CD);
		}

		if (HR_HEAD_EMPCD == null) {
			emp_detailsImpl.setHR_HEAD_EMPCD(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setHR_HEAD_EMPCD(HR_HEAD_EMPCD);
		}

		if (HR_HEAD_NAME == null) {
			emp_detailsImpl.setHR_HEAD_NAME(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setHR_HEAD_NAME(HR_HEAD_NAME);
		}

		if (HR_NAME == null) {
			emp_detailsImpl.setHR_NAME(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setHR_NAME(HR_NAME);
		}

		if (JIO_CENTER == null) {
			emp_detailsImpl.setJIO_CENTER(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setJIO_CENTER(JIO_CENTER);
		}

		if (JIO_ID == null) {
			emp_detailsImpl.setJIO_ID(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setJIO_ID(JIO_ID);
		}

		if (JO_REGION == null) {
			emp_detailsImpl.setJO_REGION(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setJO_REGION(JO_REGION);
		}

		if (JO_TYPE == null) {
			emp_detailsImpl.setJO_TYPE(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setJO_TYPE(JO_TYPE);
		}

		if (JOB == null) {
			emp_detailsImpl.setJOB(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setJOB(JOB);
		}

		if (JOB_ROLE_CODE == null) {
			emp_detailsImpl.setJOB_ROLE_CODE(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setJOB_ROLE_CODE(JOB_ROLE_CODE);
		}

		if (L1_EMAIL_ID == null) {
			emp_detailsImpl.setL1_EMAIL_ID(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setL1_EMAIL_ID(L1_EMAIL_ID);
		}

		if (L1_EMPLOYEE_CODE == null) {
			emp_detailsImpl.setL1_EMPLOYEE_CODE(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setL1_EMPLOYEE_CODE(L1_EMPLOYEE_CODE);
		}

		if (L1_NAME == null) {
			emp_detailsImpl.setL1_NAME(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setL1_NAME(L1_NAME);
		}

		if (LAST_NAME == null) {
			emp_detailsImpl.setLAST_NAME(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setLAST_NAME(LAST_NAME);
		}

		if (LOCATION_CITY == null) {
			emp_detailsImpl.setLOCATION_CITY(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setLOCATION_CITY(LOCATION_CITY);
		}

		if (LOCATION_CODE == null) {
			emp_detailsImpl.setLOCATION_CODE(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setLOCATION_CODE(LOCATION_CODE);
		}

		if (LOCATION_COUNTRY == null) {
			emp_detailsImpl.setLOCATION_COUNTRY(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setLOCATION_COUNTRY(LOCATION_COUNTRY);
		}

		if (LOCATION_STATE == null) {
			emp_detailsImpl.setLOCATION_STATE(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setLOCATION_STATE(LOCATION_STATE);
		}

		if (LOCATION_TEXT == null) {
			emp_detailsImpl.setLOCATION_TEXT(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setLOCATION_TEXT(LOCATION_TEXT);
		}

		if (MOBILE_NO == null) {
			emp_detailsImpl.setMOBILE_NO(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setMOBILE_NO(MOBILE_NO);
		}

		if (OFFICE_NO == null) {
			emp_detailsImpl.setOFFICE_NO(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setOFFICE_NO(OFFICE_NO);
		}

		if (ORG_UNIT == null) {
			emp_detailsImpl.setORG_UNIT(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setORG_UNIT(ORG_UNIT);
		}

		if (ORG_UNIT_TEXT == null) {
			emp_detailsImpl.setORG_UNIT_TEXT(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setORG_UNIT_TEXT(ORG_UNIT_TEXT);
		}

		if (PERSONNEL_AREA_CODE == null) {
			emp_detailsImpl.setPERSONNEL_AREA_CODE(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setPERSONNEL_AREA_CODE(PERSONNEL_AREA_CODE);
		}

		if (R4G_STATE == null) {
			emp_detailsImpl.setR4G_STATE(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setR4G_STATE(R4G_STATE);
		}

		if (SAML_FEDERATION_ID == null) {
			emp_detailsImpl.setSAML_FEDERATION_ID(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setSAML_FEDERATION_ID(SAML_FEDERATION_ID);
		}

		if (STORE_CODE == null) {
			emp_detailsImpl.setSTORE_CODE(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setSTORE_CODE(STORE_CODE);
		}

		if (SUB_FUNCTIONAL_AREA == null) {
			emp_detailsImpl.setSUB_FUNCTIONAL_AREA(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setSUB_FUNCTIONAL_AREA(SUB_FUNCTIONAL_AREA);
		}

		if (TITLE == null) {
			emp_detailsImpl.setTITLE(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setTITLE(TITLE);
		}

		emp_detailsImpl.setIS_RESOLVER(IS_RESOLVER);
		emp_detailsImpl.setRESOLVER_LEVEL(RESOLVER_LEVEL);

		if (PERSONAL_AREA_TEXT == null) {
			emp_detailsImpl.setPERSONAL_AREA_TEXT(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setPERSONAL_AREA_TEXT(PERSONAL_AREA_TEXT);
		}

		if (FUNCTIONAL_AREA == null) {
			emp_detailsImpl.setFUNCTIONAL_AREA(StringPool.BLANK);
		}
		else {
			emp_detailsImpl.setFUNCTIONAL_AREA(FUNCTIONAL_AREA);
		}

		emp_detailsImpl.setRESOLVER_STATUS(RESOLVER_STATUS);

		emp_detailsImpl.resetOriginalValues();

		return emp_detailsImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		EMP_ID = objectInput.readUTF();
		AREA = objectInput.readUTF();
		CADRE = objectInput.readUTF();
		CLIENT_ID = objectInput.readUTF();
		COMPANY_CODE = objectInput.readUTF();
		COMPANY_TEXT = objectInput.readUTF();
		DATE_OF_BIRTH = objectInput.readLong();
		DATE_OF_JOINING = objectInput.readLong();
		DATE_OF_LEAVE = objectInput.readLong();
		DEPARTMENT = objectInput.readUTF();
		DESIGNATION_CODE = objectInput.readUTF();
		DESIGNATION_TEXT = objectInput.readUTF();
		EMAIL = objectInput.readUTF();
		EMP_GROUP = objectInput.readUTF();
		EMPLOYEE_DOMAIN_ID = objectInput.readUTF();
		EMPLOYMENT_STATUS = objectInput.readUTF();
		EMPLOYMENT_STATUS_TEXT = objectInput.readUTF();
		FIRST_NAME = objectInput.readUTF();
		FULL_NAME = objectInput.readUTF();
		GENDER_TEXT = objectInput.readUTF();
		HR_EMAIL = objectInput.readUTF();
		HR_EMP_CD = objectInput.readUTF();
		HR_HEAD_EMPCD = objectInput.readUTF();
		HR_HEAD_NAME = objectInput.readUTF();
		HR_NAME = objectInput.readUTF();
		JIO_CENTER = objectInput.readUTF();
		JIO_ID = objectInput.readUTF();
		JO_REGION = objectInput.readUTF();
		JO_TYPE = objectInput.readUTF();
		JOB = objectInput.readUTF();
		JOB_ROLE_CODE = objectInput.readUTF();
		L1_EMAIL_ID = objectInput.readUTF();
		L1_EMPLOYEE_CODE = objectInput.readUTF();
		L1_NAME = objectInput.readUTF();
		LAST_NAME = objectInput.readUTF();
		LOCATION_CITY = objectInput.readUTF();
		LOCATION_CODE = objectInput.readUTF();
		LOCATION_COUNTRY = objectInput.readUTF();
		LOCATION_STATE = objectInput.readUTF();
		LOCATION_TEXT = objectInput.readUTF();
		MOBILE_NO = objectInput.readUTF();
		OFFICE_NO = objectInput.readUTF();
		ORG_UNIT = objectInput.readUTF();
		ORG_UNIT_TEXT = objectInput.readUTF();
		PERSONNEL_AREA_CODE = objectInput.readUTF();
		R4G_STATE = objectInput.readUTF();
		SAML_FEDERATION_ID = objectInput.readUTF();
		STORE_CODE = objectInput.readUTF();
		SUB_FUNCTIONAL_AREA = objectInput.readUTF();
		TITLE = objectInput.readUTF();
		IS_RESOLVER = objectInput.readInt();
		RESOLVER_LEVEL = objectInput.readInt();
		PERSONAL_AREA_TEXT = objectInput.readUTF();
		FUNCTIONAL_AREA = objectInput.readUTF();
		RESOLVER_STATUS = objectInput.readInt();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		if (EMP_ID == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(EMP_ID);
		}

		if (AREA == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(AREA);
		}

		if (CADRE == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(CADRE);
		}

		if (CLIENT_ID == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(CLIENT_ID);
		}

		if (COMPANY_CODE == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(COMPANY_CODE);
		}

		if (COMPANY_TEXT == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(COMPANY_TEXT);
		}

		objectOutput.writeLong(DATE_OF_BIRTH);
		objectOutput.writeLong(DATE_OF_JOINING);
		objectOutput.writeLong(DATE_OF_LEAVE);

		if (DEPARTMENT == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(DEPARTMENT);
		}

		if (DESIGNATION_CODE == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(DESIGNATION_CODE);
		}

		if (DESIGNATION_TEXT == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(DESIGNATION_TEXT);
		}

		if (EMAIL == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(EMAIL);
		}

		if (EMP_GROUP == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(EMP_GROUP);
		}

		if (EMPLOYEE_DOMAIN_ID == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(EMPLOYEE_DOMAIN_ID);
		}

		if (EMPLOYMENT_STATUS == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(EMPLOYMENT_STATUS);
		}

		if (EMPLOYMENT_STATUS_TEXT == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(EMPLOYMENT_STATUS_TEXT);
		}

		if (FIRST_NAME == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(FIRST_NAME);
		}

		if (FULL_NAME == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(FULL_NAME);
		}

		if (GENDER_TEXT == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(GENDER_TEXT);
		}

		if (HR_EMAIL == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(HR_EMAIL);
		}

		if (HR_EMP_CD == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(HR_EMP_CD);
		}

		if (HR_HEAD_EMPCD == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(HR_HEAD_EMPCD);
		}

		if (HR_HEAD_NAME == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(HR_HEAD_NAME);
		}

		if (HR_NAME == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(HR_NAME);
		}

		if (JIO_CENTER == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(JIO_CENTER);
		}

		if (JIO_ID == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(JIO_ID);
		}

		if (JO_REGION == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(JO_REGION);
		}

		if (JO_TYPE == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(JO_TYPE);
		}

		if (JOB == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(JOB);
		}

		if (JOB_ROLE_CODE == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(JOB_ROLE_CODE);
		}

		if (L1_EMAIL_ID == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(L1_EMAIL_ID);
		}

		if (L1_EMPLOYEE_CODE == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(L1_EMPLOYEE_CODE);
		}

		if (L1_NAME == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(L1_NAME);
		}

		if (LAST_NAME == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(LAST_NAME);
		}

		if (LOCATION_CITY == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(LOCATION_CITY);
		}

		if (LOCATION_CODE == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(LOCATION_CODE);
		}

		if (LOCATION_COUNTRY == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(LOCATION_COUNTRY);
		}

		if (LOCATION_STATE == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(LOCATION_STATE);
		}

		if (LOCATION_TEXT == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(LOCATION_TEXT);
		}

		if (MOBILE_NO == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(MOBILE_NO);
		}

		if (OFFICE_NO == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(OFFICE_NO);
		}

		if (ORG_UNIT == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(ORG_UNIT);
		}

		if (ORG_UNIT_TEXT == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(ORG_UNIT_TEXT);
		}

		if (PERSONNEL_AREA_CODE == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(PERSONNEL_AREA_CODE);
		}

		if (R4G_STATE == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(R4G_STATE);
		}

		if (SAML_FEDERATION_ID == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(SAML_FEDERATION_ID);
		}

		if (STORE_CODE == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(STORE_CODE);
		}

		if (SUB_FUNCTIONAL_AREA == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(SUB_FUNCTIONAL_AREA);
		}

		if (TITLE == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(TITLE);
		}

		objectOutput.writeInt(IS_RESOLVER);
		objectOutput.writeInt(RESOLVER_LEVEL);

		if (PERSONAL_AREA_TEXT == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(PERSONAL_AREA_TEXT);
		}

		if (FUNCTIONAL_AREA == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(FUNCTIONAL_AREA);
		}

		objectOutput.writeInt(RESOLVER_STATUS);
	}

	public String EMP_ID;
	public String AREA;
	public String CADRE;
	public String CLIENT_ID;
	public String COMPANY_CODE;
	public String COMPANY_TEXT;
	public long DATE_OF_BIRTH;
	public long DATE_OF_JOINING;
	public long DATE_OF_LEAVE;
	public String DEPARTMENT;
	public String DESIGNATION_CODE;
	public String DESIGNATION_TEXT;
	public String EMAIL;
	public String EMP_GROUP;
	public String EMPLOYEE_DOMAIN_ID;
	public String EMPLOYMENT_STATUS;
	public String EMPLOYMENT_STATUS_TEXT;
	public String FIRST_NAME;
	public String FULL_NAME;
	public String GENDER_TEXT;
	public String HR_EMAIL;
	public String HR_EMP_CD;
	public String HR_HEAD_EMPCD;
	public String HR_HEAD_NAME;
	public String HR_NAME;
	public String JIO_CENTER;
	public String JIO_ID;
	public String JO_REGION;
	public String JO_TYPE;
	public String JOB;
	public String JOB_ROLE_CODE;
	public String L1_EMAIL_ID;
	public String L1_EMPLOYEE_CODE;
	public String L1_NAME;
	public String LAST_NAME;
	public String LOCATION_CITY;
	public String LOCATION_CODE;
	public String LOCATION_COUNTRY;
	public String LOCATION_STATE;
	public String LOCATION_TEXT;
	public String MOBILE_NO;
	public String OFFICE_NO;
	public String ORG_UNIT;
	public String ORG_UNIT_TEXT;
	public String PERSONNEL_AREA_CODE;
	public String R4G_STATE;
	public String SAML_FEDERATION_ID;
	public String STORE_CODE;
	public String SUB_FUNCTIONAL_AREA;
	public String TITLE;
	public int IS_RESOLVER;
	public int RESOLVER_LEVEL;
	public String PERSONAL_AREA_TEXT;
	public String FUNCTIONAL_AREA;
	public int RESOLVER_STATUS;
}