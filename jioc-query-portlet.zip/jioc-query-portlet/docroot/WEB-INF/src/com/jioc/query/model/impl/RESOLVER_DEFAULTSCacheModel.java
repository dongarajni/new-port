/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model.impl;

import com.jioc.query.model.RESOLVER_DEFAULTS;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing RESOLVER_DEFAULTS in entity cache.
 *
 * @author shantaram.chavan
 * @see RESOLVER_DEFAULTS
 * @generated
 */
public class RESOLVER_DEFAULTSCacheModel implements CacheModel<RESOLVER_DEFAULTS>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{DEFAULT_ID=");
		sb.append(DEFAULT_ID);
		sb.append(", RESOLVER_LEVEL_ID=");
		sb.append(RESOLVER_LEVEL_ID);
		sb.append(", TYPE=");
		sb.append(TYPE);
		sb.append(", VALUE=");
		sb.append(VALUE);
		sb.append(", TO_DISPLAY=");
		sb.append(TO_DISPLAY);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public RESOLVER_DEFAULTS toEntityModel() {
		RESOLVER_DEFAULTSImpl resolver_defaultsImpl = new RESOLVER_DEFAULTSImpl();

		resolver_defaultsImpl.setDEFAULT_ID(DEFAULT_ID);
		resolver_defaultsImpl.setRESOLVER_LEVEL_ID(RESOLVER_LEVEL_ID);

		if (TYPE == null) {
			resolver_defaultsImpl.setTYPE(StringPool.BLANK);
		}
		else {
			resolver_defaultsImpl.setTYPE(TYPE);
		}

		if (VALUE == null) {
			resolver_defaultsImpl.setVALUE(StringPool.BLANK);
		}
		else {
			resolver_defaultsImpl.setVALUE(VALUE);
		}

		resolver_defaultsImpl.setTO_DISPLAY(TO_DISPLAY);

		resolver_defaultsImpl.resetOriginalValues();

		return resolver_defaultsImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		DEFAULT_ID = objectInput.readLong();
		RESOLVER_LEVEL_ID = objectInput.readLong();
		TYPE = objectInput.readUTF();
		VALUE = objectInput.readUTF();
		TO_DISPLAY = objectInput.readInt();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(DEFAULT_ID);
		objectOutput.writeLong(RESOLVER_LEVEL_ID);

		if (TYPE == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(TYPE);
		}

		if (VALUE == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(VALUE);
		}

		objectOutput.writeInt(TO_DISPLAY);
	}

	public long DEFAULT_ID;
	public long RESOLVER_LEVEL_ID;
	public String TYPE;
	public String VALUE;
	public int TO_DISPLAY;
}