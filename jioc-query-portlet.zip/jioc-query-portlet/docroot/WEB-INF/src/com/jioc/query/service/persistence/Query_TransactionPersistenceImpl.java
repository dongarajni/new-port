/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.NoSuchQuery_TransactionException;
import com.jioc.query.model.Query_Transaction;
import com.jioc.query.model.impl.Query_TransactionImpl;
import com.jioc.query.model.impl.Query_TransactionModelImpl;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the query_ transaction service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see Query_TransactionPersistence
 * @see Query_TransactionUtil
 * @generated
 */
public class Query_TransactionPersistenceImpl extends BasePersistenceImpl<Query_Transaction>
	implements Query_TransactionPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link Query_TransactionUtil} to access the query_ transaction persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = Query_TransactionImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(Query_TransactionModelImpl.ENTITY_CACHE_ENABLED,
			Query_TransactionModelImpl.FINDER_CACHE_ENABLED,
			Query_TransactionImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(Query_TransactionModelImpl.ENTITY_CACHE_ENABLED,
			Query_TransactionModelImpl.FINDER_CACHE_ENABLED,
			Query_TransactionImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(Query_TransactionModelImpl.ENTITY_CACHE_ENABLED,
			Query_TransactionModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_RAISEDBYID =
		new FinderPath(Query_TransactionModelImpl.ENTITY_CACHE_ENABLED,
			Query_TransactionModelImpl.FINDER_CACHE_ENABLED,
			Query_TransactionImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByRaisedById",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_RAISEDBYID =
		new FinderPath(Query_TransactionModelImpl.ENTITY_CACHE_ENABLED,
			Query_TransactionModelImpl.FINDER_CACHE_ENABLED,
			Query_TransactionImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByRaisedById",
			new String[] { Long.class.getName() },
			Query_TransactionModelImpl.RAISEDBYID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_RAISEDBYID = new FinderPath(Query_TransactionModelImpl.ENTITY_CACHE_ENABLED,
			Query_TransactionModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByRaisedById",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the query_ transactions where raisedById = &#63;.
	 *
	 * @param raisedById the raised by ID
	 * @return the matching query_ transactions
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Transaction> findByRaisedById(long raisedById)
		throws SystemException {
		return findByRaisedById(raisedById, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the query_ transactions where raisedById = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param raisedById the raised by ID
	 * @param start the lower bound of the range of query_ transactions
	 * @param end the upper bound of the range of query_ transactions (not inclusive)
	 * @return the range of matching query_ transactions
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Transaction> findByRaisedById(long raisedById, int start,
		int end) throws SystemException {
		return findByRaisedById(raisedById, start, end, null);
	}

	/**
	 * Returns an ordered range of all the query_ transactions where raisedById = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param raisedById the raised by ID
	 * @param start the lower bound of the range of query_ transactions
	 * @param end the upper bound of the range of query_ transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching query_ transactions
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Transaction> findByRaisedById(long raisedById, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_RAISEDBYID;
			finderArgs = new Object[] { raisedById };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_RAISEDBYID;
			finderArgs = new Object[] { raisedById, start, end, orderByComparator };
		}

		List<Query_Transaction> list = (List<Query_Transaction>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Query_Transaction query_Transaction : list) {
				if ((raisedById != query_Transaction.getRaisedById())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_QUERY_TRANSACTION_WHERE);

			query.append(_FINDER_COLUMN_RAISEDBYID_RAISEDBYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(Query_TransactionModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(raisedById);

				if (!pagination) {
					list = (List<Query_Transaction>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Query_Transaction>(list);
				}
				else {
					list = (List<Query_Transaction>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first query_ transaction in the ordered set where raisedById = &#63;.
	 *
	 * @param raisedById the raised by ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching query_ transaction
	 * @throws com.jioc.query.NoSuchQuery_TransactionException if a matching query_ transaction could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Transaction findByRaisedById_First(long raisedById,
		OrderByComparator orderByComparator)
		throws NoSuchQuery_TransactionException, SystemException {
		Query_Transaction query_Transaction = fetchByRaisedById_First(raisedById,
				orderByComparator);

		if (query_Transaction != null) {
			return query_Transaction;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("raisedById=");
		msg.append(raisedById);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchQuery_TransactionException(msg.toString());
	}

	/**
	 * Returns the first query_ transaction in the ordered set where raisedById = &#63;.
	 *
	 * @param raisedById the raised by ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching query_ transaction, or <code>null</code> if a matching query_ transaction could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Transaction fetchByRaisedById_First(long raisedById,
		OrderByComparator orderByComparator) throws SystemException {
		List<Query_Transaction> list = findByRaisedById(raisedById, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last query_ transaction in the ordered set where raisedById = &#63;.
	 *
	 * @param raisedById the raised by ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching query_ transaction
	 * @throws com.jioc.query.NoSuchQuery_TransactionException if a matching query_ transaction could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Transaction findByRaisedById_Last(long raisedById,
		OrderByComparator orderByComparator)
		throws NoSuchQuery_TransactionException, SystemException {
		Query_Transaction query_Transaction = fetchByRaisedById_Last(raisedById,
				orderByComparator);

		if (query_Transaction != null) {
			return query_Transaction;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("raisedById=");
		msg.append(raisedById);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchQuery_TransactionException(msg.toString());
	}

	/**
	 * Returns the last query_ transaction in the ordered set where raisedById = &#63;.
	 *
	 * @param raisedById the raised by ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching query_ transaction, or <code>null</code> if a matching query_ transaction could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Transaction fetchByRaisedById_Last(long raisedById,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByRaisedById(raisedById);

		if (count == 0) {
			return null;
		}

		List<Query_Transaction> list = findByRaisedById(raisedById, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the query_ transactions before and after the current query_ transaction in the ordered set where raisedById = &#63;.
	 *
	 * @param queryId the primary key of the current query_ transaction
	 * @param raisedById the raised by ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next query_ transaction
	 * @throws com.jioc.query.NoSuchQuery_TransactionException if a query_ transaction with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Transaction[] findByRaisedById_PrevAndNext(long queryId,
		long raisedById, OrderByComparator orderByComparator)
		throws NoSuchQuery_TransactionException, SystemException {
		Query_Transaction query_Transaction = findByPrimaryKey(queryId);

		Session session = null;

		try {
			session = openSession();

			Query_Transaction[] array = new Query_TransactionImpl[3];

			array[0] = getByRaisedById_PrevAndNext(session, query_Transaction,
					raisedById, orderByComparator, true);

			array[1] = query_Transaction;

			array[2] = getByRaisedById_PrevAndNext(session, query_Transaction,
					raisedById, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Query_Transaction getByRaisedById_PrevAndNext(Session session,
		Query_Transaction query_Transaction, long raisedById,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_QUERY_TRANSACTION_WHERE);

		query.append(_FINDER_COLUMN_RAISEDBYID_RAISEDBYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(Query_TransactionModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(raisedById);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(query_Transaction);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Query_Transaction> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the query_ transactions where raisedById = &#63; from the database.
	 *
	 * @param raisedById the raised by ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByRaisedById(long raisedById) throws SystemException {
		for (Query_Transaction query_Transaction : findByRaisedById(
				raisedById, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(query_Transaction);
		}
	}

	/**
	 * Returns the number of query_ transactions where raisedById = &#63;.
	 *
	 * @param raisedById the raised by ID
	 * @return the number of matching query_ transactions
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByRaisedById(long raisedById) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_RAISEDBYID;

		Object[] finderArgs = new Object[] { raisedById };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_QUERY_TRANSACTION_WHERE);

			query.append(_FINDER_COLUMN_RAISEDBYID_RAISEDBYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(raisedById);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_RAISEDBYID_RAISEDBYID_2 = "query_Transaction.raisedById = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_PCID = new FinderPath(Query_TransactionModelImpl.ENTITY_CACHE_ENABLED,
			Query_TransactionModelImpl.FINDER_CACHE_ENABLED,
			Query_TransactionImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByPCId",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PCID = new FinderPath(Query_TransactionModelImpl.ENTITY_CACHE_ENABLED,
			Query_TransactionModelImpl.FINDER_CACHE_ENABLED,
			Query_TransactionImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByPCId",
			new String[] { String.class.getName() },
			Query_TransactionModelImpl.PCID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_PCID = new FinderPath(Query_TransactionModelImpl.ENTITY_CACHE_ENABLED,
			Query_TransactionModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByPCId",
			new String[] { String.class.getName() });

	/**
	 * Returns all the query_ transactions where pcId = &#63;.
	 *
	 * @param pcId the pc ID
	 * @return the matching query_ transactions
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Transaction> findByPCId(String pcId)
		throws SystemException {
		return findByPCId(pcId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the query_ transactions where pcId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param pcId the pc ID
	 * @param start the lower bound of the range of query_ transactions
	 * @param end the upper bound of the range of query_ transactions (not inclusive)
	 * @return the range of matching query_ transactions
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Transaction> findByPCId(String pcId, int start, int end)
		throws SystemException {
		return findByPCId(pcId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the query_ transactions where pcId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param pcId the pc ID
	 * @param start the lower bound of the range of query_ transactions
	 * @param end the upper bound of the range of query_ transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching query_ transactions
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Transaction> findByPCId(String pcId, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PCID;
			finderArgs = new Object[] { pcId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_PCID;
			finderArgs = new Object[] { pcId, start, end, orderByComparator };
		}

		List<Query_Transaction> list = (List<Query_Transaction>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Query_Transaction query_Transaction : list) {
				if (!Validator.equals(pcId, query_Transaction.getPcId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_QUERY_TRANSACTION_WHERE);

			boolean bindPcId = false;

			if (pcId == null) {
				query.append(_FINDER_COLUMN_PCID_PCID_1);
			}
			else if (pcId.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_PCID_PCID_3);
			}
			else {
				bindPcId = true;

				query.append(_FINDER_COLUMN_PCID_PCID_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(Query_TransactionModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindPcId) {
					qPos.add(pcId);
				}

				if (!pagination) {
					list = (List<Query_Transaction>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Query_Transaction>(list);
				}
				else {
					list = (List<Query_Transaction>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first query_ transaction in the ordered set where pcId = &#63;.
	 *
	 * @param pcId the pc ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching query_ transaction
	 * @throws com.jioc.query.NoSuchQuery_TransactionException if a matching query_ transaction could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Transaction findByPCId_First(String pcId,
		OrderByComparator orderByComparator)
		throws NoSuchQuery_TransactionException, SystemException {
		Query_Transaction query_Transaction = fetchByPCId_First(pcId,
				orderByComparator);

		if (query_Transaction != null) {
			return query_Transaction;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("pcId=");
		msg.append(pcId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchQuery_TransactionException(msg.toString());
	}

	/**
	 * Returns the first query_ transaction in the ordered set where pcId = &#63;.
	 *
	 * @param pcId the pc ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching query_ transaction, or <code>null</code> if a matching query_ transaction could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Transaction fetchByPCId_First(String pcId,
		OrderByComparator orderByComparator) throws SystemException {
		List<Query_Transaction> list = findByPCId(pcId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last query_ transaction in the ordered set where pcId = &#63;.
	 *
	 * @param pcId the pc ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching query_ transaction
	 * @throws com.jioc.query.NoSuchQuery_TransactionException if a matching query_ transaction could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Transaction findByPCId_Last(String pcId,
		OrderByComparator orderByComparator)
		throws NoSuchQuery_TransactionException, SystemException {
		Query_Transaction query_Transaction = fetchByPCId_Last(pcId,
				orderByComparator);

		if (query_Transaction != null) {
			return query_Transaction;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("pcId=");
		msg.append(pcId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchQuery_TransactionException(msg.toString());
	}

	/**
	 * Returns the last query_ transaction in the ordered set where pcId = &#63;.
	 *
	 * @param pcId the pc ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching query_ transaction, or <code>null</code> if a matching query_ transaction could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Transaction fetchByPCId_Last(String pcId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByPCId(pcId);

		if (count == 0) {
			return null;
		}

		List<Query_Transaction> list = findByPCId(pcId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the query_ transactions before and after the current query_ transaction in the ordered set where pcId = &#63;.
	 *
	 * @param queryId the primary key of the current query_ transaction
	 * @param pcId the pc ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next query_ transaction
	 * @throws com.jioc.query.NoSuchQuery_TransactionException if a query_ transaction with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Transaction[] findByPCId_PrevAndNext(long queryId,
		String pcId, OrderByComparator orderByComparator)
		throws NoSuchQuery_TransactionException, SystemException {
		Query_Transaction query_Transaction = findByPrimaryKey(queryId);

		Session session = null;

		try {
			session = openSession();

			Query_Transaction[] array = new Query_TransactionImpl[3];

			array[0] = getByPCId_PrevAndNext(session, query_Transaction, pcId,
					orderByComparator, true);

			array[1] = query_Transaction;

			array[2] = getByPCId_PrevAndNext(session, query_Transaction, pcId,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Query_Transaction getByPCId_PrevAndNext(Session session,
		Query_Transaction query_Transaction, String pcId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_QUERY_TRANSACTION_WHERE);

		boolean bindPcId = false;

		if (pcId == null) {
			query.append(_FINDER_COLUMN_PCID_PCID_1);
		}
		else if (pcId.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_PCID_PCID_3);
		}
		else {
			bindPcId = true;

			query.append(_FINDER_COLUMN_PCID_PCID_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(Query_TransactionModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindPcId) {
			qPos.add(pcId);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(query_Transaction);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Query_Transaction> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the query_ transactions where pcId = &#63; from the database.
	 *
	 * @param pcId the pc ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByPCId(String pcId) throws SystemException {
		for (Query_Transaction query_Transaction : findByPCId(pcId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(query_Transaction);
		}
	}

	/**
	 * Returns the number of query_ transactions where pcId = &#63;.
	 *
	 * @param pcId the pc ID
	 * @return the number of matching query_ transactions
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByPCId(String pcId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_PCID;

		Object[] finderArgs = new Object[] { pcId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_QUERY_TRANSACTION_WHERE);

			boolean bindPcId = false;

			if (pcId == null) {
				query.append(_FINDER_COLUMN_PCID_PCID_1);
			}
			else if (pcId.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_PCID_PCID_3);
			}
			else {
				bindPcId = true;

				query.append(_FINDER_COLUMN_PCID_PCID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindPcId) {
					qPos.add(pcId);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_PCID_PCID_1 = "query_Transaction.pcId IS NULL";
	private static final String _FINDER_COLUMN_PCID_PCID_2 = "query_Transaction.pcId = ?";
	private static final String _FINDER_COLUMN_PCID_PCID_3 = "(query_Transaction.pcId IS NULL OR query_Transaction.pcId = '')";

	public Query_TransactionPersistenceImpl() {
		setModelClass(Query_Transaction.class);
	}

	/**
	 * Caches the query_ transaction in the entity cache if it is enabled.
	 *
	 * @param query_Transaction the query_ transaction
	 */
	@Override
	public void cacheResult(Query_Transaction query_Transaction) {
		EntityCacheUtil.putResult(Query_TransactionModelImpl.ENTITY_CACHE_ENABLED,
			Query_TransactionImpl.class, query_Transaction.getPrimaryKey(),
			query_Transaction);

		query_Transaction.resetOriginalValues();
	}

	/**
	 * Caches the query_ transactions in the entity cache if it is enabled.
	 *
	 * @param query_Transactions the query_ transactions
	 */
	@Override
	public void cacheResult(List<Query_Transaction> query_Transactions) {
		for (Query_Transaction query_Transaction : query_Transactions) {
			if (EntityCacheUtil.getResult(
						Query_TransactionModelImpl.ENTITY_CACHE_ENABLED,
						Query_TransactionImpl.class,
						query_Transaction.getPrimaryKey()) == null) {
				cacheResult(query_Transaction);
			}
			else {
				query_Transaction.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all query_ transactions.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(Query_TransactionImpl.class.getName());
		}

		EntityCacheUtil.clearCache(Query_TransactionImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the query_ transaction.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(Query_Transaction query_Transaction) {
		EntityCacheUtil.removeResult(Query_TransactionModelImpl.ENTITY_CACHE_ENABLED,
			Query_TransactionImpl.class, query_Transaction.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<Query_Transaction> query_Transactions) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (Query_Transaction query_Transaction : query_Transactions) {
			EntityCacheUtil.removeResult(Query_TransactionModelImpl.ENTITY_CACHE_ENABLED,
				Query_TransactionImpl.class, query_Transaction.getPrimaryKey());
		}
	}

	/**
	 * Creates a new query_ transaction with the primary key. Does not add the query_ transaction to the database.
	 *
	 * @param queryId the primary key for the new query_ transaction
	 * @return the new query_ transaction
	 */
	@Override
	public Query_Transaction create(long queryId) {
		Query_Transaction query_Transaction = new Query_TransactionImpl();

		query_Transaction.setNew(true);
		query_Transaction.setPrimaryKey(queryId);

		return query_Transaction;
	}

	/**
	 * Removes the query_ transaction with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param queryId the primary key of the query_ transaction
	 * @return the query_ transaction that was removed
	 * @throws com.jioc.query.NoSuchQuery_TransactionException if a query_ transaction with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Transaction remove(long queryId)
		throws NoSuchQuery_TransactionException, SystemException {
		return remove((Serializable)queryId);
	}

	/**
	 * Removes the query_ transaction with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the query_ transaction
	 * @return the query_ transaction that was removed
	 * @throws com.jioc.query.NoSuchQuery_TransactionException if a query_ transaction with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Transaction remove(Serializable primaryKey)
		throws NoSuchQuery_TransactionException, SystemException {
		Session session = null;

		try {
			session = openSession();

			Query_Transaction query_Transaction = (Query_Transaction)session.get(Query_TransactionImpl.class,
					primaryKey);

			if (query_Transaction == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchQuery_TransactionException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(query_Transaction);
		}
		catch (NoSuchQuery_TransactionException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected Query_Transaction removeImpl(Query_Transaction query_Transaction)
		throws SystemException {
		query_Transaction = toUnwrappedModel(query_Transaction);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(query_Transaction)) {
				query_Transaction = (Query_Transaction)session.get(Query_TransactionImpl.class,
						query_Transaction.getPrimaryKeyObj());
			}

			if (query_Transaction != null) {
				session.delete(query_Transaction);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (query_Transaction != null) {
			clearCache(query_Transaction);
		}

		return query_Transaction;
	}

	@Override
	public Query_Transaction updateImpl(
		com.jioc.query.model.Query_Transaction query_Transaction)
		throws SystemException {
		query_Transaction = toUnwrappedModel(query_Transaction);

		boolean isNew = query_Transaction.isNew();

		Query_TransactionModelImpl query_TransactionModelImpl = (Query_TransactionModelImpl)query_Transaction;

		Session session = null;

		try {
			session = openSession();

			if (query_Transaction.isNew()) {
				session.save(query_Transaction);

				query_Transaction.setNew(false);
			}
			else {
				session.merge(query_Transaction);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !Query_TransactionModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((query_TransactionModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_RAISEDBYID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						query_TransactionModelImpl.getOriginalRaisedById()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_RAISEDBYID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_RAISEDBYID,
					args);

				args = new Object[] { query_TransactionModelImpl.getRaisedById() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_RAISEDBYID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_RAISEDBYID,
					args);
			}

			if ((query_TransactionModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PCID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						query_TransactionModelImpl.getOriginalPcId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_PCID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PCID,
					args);

				args = new Object[] { query_TransactionModelImpl.getPcId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_PCID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PCID,
					args);
			}
		}

		EntityCacheUtil.putResult(Query_TransactionModelImpl.ENTITY_CACHE_ENABLED,
			Query_TransactionImpl.class, query_Transaction.getPrimaryKey(),
			query_Transaction);

		return query_Transaction;
	}

	protected Query_Transaction toUnwrappedModel(
		Query_Transaction query_Transaction) {
		if (query_Transaction instanceof Query_TransactionImpl) {
			return query_Transaction;
		}

		Query_TransactionImpl query_TransactionImpl = new Query_TransactionImpl();

		query_TransactionImpl.setNew(query_Transaction.isNew());
		query_TransactionImpl.setPrimaryKey(query_Transaction.getPrimaryKey());

		query_TransactionImpl.setQueryId(query_Transaction.getQueryId());
		query_TransactionImpl.setCaseNo(query_Transaction.getCaseNo());
		query_TransactionImpl.setDescription(query_Transaction.getDescription());
		query_TransactionImpl.setRaisedTimestamp(query_Transaction.getRaisedTimestamp());
		query_TransactionImpl.setRaisedById(query_Transaction.getRaisedById());
		query_TransactionImpl.setToDisplay(query_Transaction.getToDisplay());
		query_TransactionImpl.setOrn_no(query_Transaction.getOrn_no());
		query_TransactionImpl.setCaf_no(query_Transaction.getCaf_no());
		query_TransactionImpl.setCustomer_MSISDN(query_Transaction.getCustomer_MSISDN());
		query_TransactionImpl.setAmt_request(query_Transaction.getAmt_request());
		query_TransactionImpl.setAmt_done(query_Transaction.getAmt_done());
		query_TransactionImpl.setRaised_by_email(query_Transaction.getRaised_by_email());
		query_TransactionImpl.setPcId(query_Transaction.getPcId());
		query_TransactionImpl.setAck(query_Transaction.getAck());
		query_TransactionImpl.setSource(query_Transaction.getSource());
		query_TransactionImpl.setAck_timestamp(query_Transaction.getAck_timestamp());
		query_TransactionImpl.setAssignment_group(query_Transaction.getAssignment_group());
		query_TransactionImpl.setISACTIVE(query_Transaction.getISACTIVE());

		return query_TransactionImpl;
	}

	/**
	 * Returns the query_ transaction with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the query_ transaction
	 * @return the query_ transaction
	 * @throws com.jioc.query.NoSuchQuery_TransactionException if a query_ transaction with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Transaction findByPrimaryKey(Serializable primaryKey)
		throws NoSuchQuery_TransactionException, SystemException {
		Query_Transaction query_Transaction = fetchByPrimaryKey(primaryKey);

		if (query_Transaction == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchQuery_TransactionException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return query_Transaction;
	}

	/**
	 * Returns the query_ transaction with the primary key or throws a {@link com.jioc.query.NoSuchQuery_TransactionException} if it could not be found.
	 *
	 * @param queryId the primary key of the query_ transaction
	 * @return the query_ transaction
	 * @throws com.jioc.query.NoSuchQuery_TransactionException if a query_ transaction with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Transaction findByPrimaryKey(long queryId)
		throws NoSuchQuery_TransactionException, SystemException {
		return findByPrimaryKey((Serializable)queryId);
	}

	/**
	 * Returns the query_ transaction with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the query_ transaction
	 * @return the query_ transaction, or <code>null</code> if a query_ transaction with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Transaction fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		Query_Transaction query_Transaction = (Query_Transaction)EntityCacheUtil.getResult(Query_TransactionModelImpl.ENTITY_CACHE_ENABLED,
				Query_TransactionImpl.class, primaryKey);

		if (query_Transaction == _nullQuery_Transaction) {
			return null;
		}

		if (query_Transaction == null) {
			Session session = null;

			try {
				session = openSession();

				query_Transaction = (Query_Transaction)session.get(Query_TransactionImpl.class,
						primaryKey);

				if (query_Transaction != null) {
					cacheResult(query_Transaction);
				}
				else {
					EntityCacheUtil.putResult(Query_TransactionModelImpl.ENTITY_CACHE_ENABLED,
						Query_TransactionImpl.class, primaryKey,
						_nullQuery_Transaction);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(Query_TransactionModelImpl.ENTITY_CACHE_ENABLED,
					Query_TransactionImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return query_Transaction;
	}

	/**
	 * Returns the query_ transaction with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param queryId the primary key of the query_ transaction
	 * @return the query_ transaction, or <code>null</code> if a query_ transaction with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Transaction fetchByPrimaryKey(long queryId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)queryId);
	}

	/**
	 * Returns all the query_ transactions.
	 *
	 * @return the query_ transactions
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Transaction> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the query_ transactions.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of query_ transactions
	 * @param end the upper bound of the range of query_ transactions (not inclusive)
	 * @return the range of query_ transactions
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Transaction> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the query_ transactions.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of query_ transactions
	 * @param end the upper bound of the range of query_ transactions (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of query_ transactions
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Transaction> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<Query_Transaction> list = (List<Query_Transaction>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_QUERY_TRANSACTION);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_QUERY_TRANSACTION;

				if (pagination) {
					sql = sql.concat(Query_TransactionModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<Query_Transaction>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Query_Transaction>(list);
				}
				else {
					list = (List<Query_Transaction>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the query_ transactions from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (Query_Transaction query_Transaction : findAll()) {
			remove(query_Transaction);
		}
	}

	/**
	 * Returns the number of query_ transactions.
	 *
	 * @return the number of query_ transactions
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_QUERY_TRANSACTION);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the query_ transaction persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.jioc.query.model.Query_Transaction")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<Query_Transaction>> listenersList = new ArrayList<ModelListener<Query_Transaction>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<Query_Transaction>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(Query_TransactionImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_QUERY_TRANSACTION = "SELECT query_Transaction FROM Query_Transaction query_Transaction";
	private static final String _SQL_SELECT_QUERY_TRANSACTION_WHERE = "SELECT query_Transaction FROM Query_Transaction query_Transaction WHERE ";
	private static final String _SQL_COUNT_QUERY_TRANSACTION = "SELECT COUNT(query_Transaction) FROM Query_Transaction query_Transaction";
	private static final String _SQL_COUNT_QUERY_TRANSACTION_WHERE = "SELECT COUNT(query_Transaction) FROM Query_Transaction query_Transaction WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "query_Transaction.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No Query_Transaction exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No Query_Transaction exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(Query_TransactionPersistenceImpl.class);
	private static Query_Transaction _nullQuery_Transaction = new Query_TransactionImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<Query_Transaction> toCacheModel() {
				return _nullQuery_TransactionCacheModel;
			}
		};

	private static CacheModel<Query_Transaction> _nullQuery_TransactionCacheModel =
		new CacheModel<Query_Transaction>() {
			@Override
			public Query_Transaction toEntityModel() {
				return _nullQuery_Transaction;
			}
		};
}