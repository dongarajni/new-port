/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model.impl;

import com.jioc.query.model.OC_JOB_FUNCTION_MST;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing OC_JOB_FUNCTION_MST in entity cache.
 *
 * @author shantaram.chavan
 * @see OC_JOB_FUNCTION_MST
 * @generated
 */
public class OC_JOB_FUNCTION_MSTCacheModel implements CacheModel<OC_JOB_FUNCTION_MST>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{OC_JOB_FUNCTION_ID=");
		sb.append(OC_JOB_FUNCTION_ID);
		sb.append(", FUNCTIONAL_AREA=");
		sb.append(FUNCTIONAL_AREA);
		sb.append(", JOB=");
		sb.append(JOB);
		sb.append(", OC=");
		sb.append(OC);
		sb.append(", SUB_FUNCTIONAL_AREA=");
		sb.append(SUB_FUNCTIONAL_AREA);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public OC_JOB_FUNCTION_MST toEntityModel() {
		OC_JOB_FUNCTION_MSTImpl oc_job_function_mstImpl = new OC_JOB_FUNCTION_MSTImpl();

		oc_job_function_mstImpl.setOC_JOB_FUNCTION_ID(OC_JOB_FUNCTION_ID);

		if (FUNCTIONAL_AREA == null) {
			oc_job_function_mstImpl.setFUNCTIONAL_AREA(StringPool.BLANK);
		}
		else {
			oc_job_function_mstImpl.setFUNCTIONAL_AREA(FUNCTIONAL_AREA);
		}

		if (JOB == null) {
			oc_job_function_mstImpl.setJOB(StringPool.BLANK);
		}
		else {
			oc_job_function_mstImpl.setJOB(JOB);
		}

		if (OC == null) {
			oc_job_function_mstImpl.setOC(StringPool.BLANK);
		}
		else {
			oc_job_function_mstImpl.setOC(OC);
		}

		if (SUB_FUNCTIONAL_AREA == null) {
			oc_job_function_mstImpl.setSUB_FUNCTIONAL_AREA(StringPool.BLANK);
		}
		else {
			oc_job_function_mstImpl.setSUB_FUNCTIONAL_AREA(SUB_FUNCTIONAL_AREA);
		}

		oc_job_function_mstImpl.resetOriginalValues();

		return oc_job_function_mstImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		OC_JOB_FUNCTION_ID = objectInput.readLong();
		FUNCTIONAL_AREA = objectInput.readUTF();
		JOB = objectInput.readUTF();
		OC = objectInput.readUTF();
		SUB_FUNCTIONAL_AREA = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(OC_JOB_FUNCTION_ID);

		if (FUNCTIONAL_AREA == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(FUNCTIONAL_AREA);
		}

		if (JOB == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(JOB);
		}

		if (OC == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(OC);
		}

		if (SUB_FUNCTIONAL_AREA == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(SUB_FUNCTIONAL_AREA);
		}
	}

	public long OC_JOB_FUNCTION_ID;
	public String FUNCTIONAL_AREA;
	public String JOB;
	public String OC;
	public String SUB_FUNCTIONAL_AREA;
}