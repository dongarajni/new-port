/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model.impl;

import com.jioc.query.model.QUERY_MOD_DEFAULTS;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing QUERY_MOD_DEFAULTS in entity cache.
 *
 * @author shantaram.chavan
 * @see QUERY_MOD_DEFAULTS
 * @generated
 */
public class QUERY_MOD_DEFAULTSCacheModel implements CacheModel<QUERY_MOD_DEFAULTS>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(15);

		sb.append("{QUERY_MOD_DEFAULTS_ID=");
		sb.append(QUERY_MOD_DEFAULTS_ID);
		sb.append(", CURR_VAL=");
		sb.append(CURR_VAL);
		sb.append(", NEW_VAL=");
		sb.append(NEW_VAL);
		sb.append(", IS_ACTIVE=");
		sb.append(IS_ACTIVE);
		sb.append(", UPDATED_TIMESTAMP=");
		sb.append(UPDATED_TIMESTAMP);
		sb.append(", TYPE=");
		sb.append(TYPE);
		sb.append(", CURR_LEVEL=");
		sb.append(CURR_LEVEL);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public QUERY_MOD_DEFAULTS toEntityModel() {
		QUERY_MOD_DEFAULTSImpl query_mod_defaultsImpl = new QUERY_MOD_DEFAULTSImpl();

		query_mod_defaultsImpl.setQUERY_MOD_DEFAULTS_ID(QUERY_MOD_DEFAULTS_ID);

		if (CURR_VAL == null) {
			query_mod_defaultsImpl.setCURR_VAL(StringPool.BLANK);
		}
		else {
			query_mod_defaultsImpl.setCURR_VAL(CURR_VAL);
		}

		if (NEW_VAL == null) {
			query_mod_defaultsImpl.setNEW_VAL(StringPool.BLANK);
		}
		else {
			query_mod_defaultsImpl.setNEW_VAL(NEW_VAL);
		}

		query_mod_defaultsImpl.setIS_ACTIVE(IS_ACTIVE);

		if (UPDATED_TIMESTAMP == Long.MIN_VALUE) {
			query_mod_defaultsImpl.setUPDATED_TIMESTAMP(null);
		}
		else {
			query_mod_defaultsImpl.setUPDATED_TIMESTAMP(new Date(
					UPDATED_TIMESTAMP));
		}

		if (TYPE == null) {
			query_mod_defaultsImpl.setTYPE(StringPool.BLANK);
		}
		else {
			query_mod_defaultsImpl.setTYPE(TYPE);
		}

		query_mod_defaultsImpl.setCURR_LEVEL(CURR_LEVEL);

		query_mod_defaultsImpl.resetOriginalValues();

		return query_mod_defaultsImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		QUERY_MOD_DEFAULTS_ID = objectInput.readInt();
		CURR_VAL = objectInput.readUTF();
		NEW_VAL = objectInput.readUTF();
		IS_ACTIVE = objectInput.readInt();
		UPDATED_TIMESTAMP = objectInput.readLong();
		TYPE = objectInput.readUTF();
		CURR_LEVEL = objectInput.readInt();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeInt(QUERY_MOD_DEFAULTS_ID);

		if (CURR_VAL == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(CURR_VAL);
		}

		if (NEW_VAL == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(NEW_VAL);
		}

		objectOutput.writeInt(IS_ACTIVE);
		objectOutput.writeLong(UPDATED_TIMESTAMP);

		if (TYPE == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(TYPE);
		}

		objectOutput.writeInt(CURR_LEVEL);
	}

	public int QUERY_MOD_DEFAULTS_ID;
	public String CURR_VAL;
	public String NEW_VAL;
	public int IS_ACTIVE;
	public long UPDATED_TIMESTAMP;
	public String TYPE;
	public int CURR_LEVEL;
}