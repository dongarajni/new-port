/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model.impl;

import com.jioc.query.model.CASE_RES_MST;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing CASE_RES_MST in entity cache.
 *
 * @author shantaram.chavan
 * @see CASE_RES_MST
 * @generated
 */
public class CASE_RES_MSTCacheModel implements CacheModel<CASE_RES_MST>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{CASE_RES_ID=");
		sb.append(CASE_RES_ID);
		sb.append(", CASE_RES_NAME=");
		sb.append(CASE_RES_NAME);
		sb.append(", IS_ACTIVE=");
		sb.append(IS_ACTIVE);
		sb.append(", OC=");
		sb.append(OC);
		sb.append(", UPDATED_TIMESTAMP=");
		sb.append(UPDATED_TIMESTAMP);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public CASE_RES_MST toEntityModel() {
		CASE_RES_MSTImpl case_res_mstImpl = new CASE_RES_MSTImpl();

		case_res_mstImpl.setCASE_RES_ID(CASE_RES_ID);

		if (CASE_RES_NAME == null) {
			case_res_mstImpl.setCASE_RES_NAME(StringPool.BLANK);
		}
		else {
			case_res_mstImpl.setCASE_RES_NAME(CASE_RES_NAME);
		}

		case_res_mstImpl.setIS_ACTIVE(IS_ACTIVE);

		if (OC == null) {
			case_res_mstImpl.setOC(StringPool.BLANK);
		}
		else {
			case_res_mstImpl.setOC(OC);
		}

		if (UPDATED_TIMESTAMP == Long.MIN_VALUE) {
			case_res_mstImpl.setUPDATED_TIMESTAMP(null);
		}
		else {
			case_res_mstImpl.setUPDATED_TIMESTAMP(new Date(UPDATED_TIMESTAMP));
		}

		case_res_mstImpl.resetOriginalValues();

		return case_res_mstImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		CASE_RES_ID = objectInput.readLong();
		CASE_RES_NAME = objectInput.readUTF();
		IS_ACTIVE = objectInput.readInt();
		OC = objectInput.readUTF();
		UPDATED_TIMESTAMP = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(CASE_RES_ID);

		if (CASE_RES_NAME == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(CASE_RES_NAME);
		}

		objectOutput.writeInt(IS_ACTIVE);

		if (OC == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(OC);
		}

		objectOutput.writeLong(UPDATED_TIMESTAMP);
	}

	public long CASE_RES_ID;
	public String CASE_RES_NAME;
	public int IS_ACTIVE;
	public String OC;
	public long UPDATED_TIMESTAMP;
}