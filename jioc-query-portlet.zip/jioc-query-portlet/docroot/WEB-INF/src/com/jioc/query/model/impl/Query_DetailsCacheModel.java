/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model.impl;

import com.jioc.query.model.Query_Details;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing Query_Details in entity cache.
 *
 * @author shantaram.chavan
 * @see Query_Details
 * @generated
 */
public class Query_DetailsCacheModel implements CacheModel<Query_Details>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(35);

		sb.append("{queryDetailsId=");
		sb.append(queryDetailsId);
		sb.append(", queryId=");
		sb.append(queryId);
		sb.append(", updatedTimestamp=");
		sb.append(updatedTimestamp);
		sb.append(", updatedBy=");
		sb.append(updatedBy);
		sb.append(", assignedTo=");
		sb.append(assignedTo);
		sb.append(", action=");
		sb.append(action);
		sb.append(", status=");
		sb.append(status);
		sb.append(", state=");
		sb.append(state);
		sb.append(", region=");
		sb.append(region);
		sb.append(", oc=");
		sb.append(oc);
		sb.append(", queueLevel=");
		sb.append(queueLevel);
		sb.append(", comment=");
		sb.append(comment);
		sb.append(", category=");
		sb.append(category);
		sb.append(", subCategory=");
		sb.append(subCategory);
		sb.append(", caseResolution=");
		sb.append(caseResolution);
		sb.append(", is_closed=");
		sb.append(is_closed);
		sb.append(", closed_date=");
		sb.append(closed_date);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Query_Details toEntityModel() {
		Query_DetailsImpl query_DetailsImpl = new Query_DetailsImpl();

		query_DetailsImpl.setQueryDetailsId(queryDetailsId);
		query_DetailsImpl.setQueryId(queryId);

		if (updatedTimestamp == Long.MIN_VALUE) {
			query_DetailsImpl.setUpdatedTimestamp(null);
		}
		else {
			query_DetailsImpl.setUpdatedTimestamp(new Date(updatedTimestamp));
		}

		query_DetailsImpl.setUpdatedBy(updatedBy);
		query_DetailsImpl.setAssignedTo(assignedTo);

		if (action == null) {
			query_DetailsImpl.setAction(StringPool.BLANK);
		}
		else {
			query_DetailsImpl.setAction(action);
		}

		if (status == null) {
			query_DetailsImpl.setStatus(StringPool.BLANK);
		}
		else {
			query_DetailsImpl.setStatus(status);
		}

		if (state == null) {
			query_DetailsImpl.setState(StringPool.BLANK);
		}
		else {
			query_DetailsImpl.setState(state);
		}

		if (region == null) {
			query_DetailsImpl.setRegion(StringPool.BLANK);
		}
		else {
			query_DetailsImpl.setRegion(region);
		}

		if (oc == null) {
			query_DetailsImpl.setOc(StringPool.BLANK);
		}
		else {
			query_DetailsImpl.setOc(oc);
		}

		query_DetailsImpl.setQueueLevel(queueLevel);

		if (comment == null) {
			query_DetailsImpl.setComment(StringPool.BLANK);
		}
		else {
			query_DetailsImpl.setComment(comment);
		}

		query_DetailsImpl.setCategory(category);
		query_DetailsImpl.setSubCategory(subCategory);
		query_DetailsImpl.setCaseResolution(caseResolution);
		query_DetailsImpl.setIs_closed(is_closed);

		if (closed_date == Long.MIN_VALUE) {
			query_DetailsImpl.setClosed_date(null);
		}
		else {
			query_DetailsImpl.setClosed_date(new Date(closed_date));
		}

		query_DetailsImpl.resetOriginalValues();

		return query_DetailsImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		queryDetailsId = objectInput.readLong();
		queryId = objectInput.readLong();
		updatedTimestamp = objectInput.readLong();
		updatedBy = objectInput.readLong();
		assignedTo = objectInput.readLong();
		action = objectInput.readUTF();
		status = objectInput.readUTF();
		state = objectInput.readUTF();
		region = objectInput.readUTF();
		oc = objectInput.readUTF();
		queueLevel = objectInput.readInt();
		comment = objectInput.readUTF();
		category = objectInput.readLong();
		subCategory = objectInput.readLong();
		caseResolution = objectInput.readLong();
		is_closed = objectInput.readInt();
		closed_date = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(queryDetailsId);
		objectOutput.writeLong(queryId);
		objectOutput.writeLong(updatedTimestamp);
		objectOutput.writeLong(updatedBy);
		objectOutput.writeLong(assignedTo);

		if (action == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(action);
		}

		if (status == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(status);
		}

		if (state == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(state);
		}

		if (region == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(region);
		}

		if (oc == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(oc);
		}

		objectOutput.writeInt(queueLevel);

		if (comment == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(comment);
		}

		objectOutput.writeLong(category);
		objectOutput.writeLong(subCategory);
		objectOutput.writeLong(caseResolution);
		objectOutput.writeInt(is_closed);
		objectOutput.writeLong(closed_date);
	}

	public long queryDetailsId;
	public long queryId;
	public long updatedTimestamp;
	public long updatedBy;
	public long assignedTo;
	public String action;
	public String status;
	public String state;
	public String region;
	public String oc;
	public int queueLevel;
	public String comment;
	public long category;
	public long subCategory;
	public long caseResolution;
	public int is_closed;
	public long closed_date;
}