package com.jioc.query.ws.controller;

import com.jioc.beans.PushTicketRequestBean;
import com.jioc.beans.PushTicketResponseBean;
import com.jioc.beans.PushTicketResponseErrorBean;
import com.jioc.beans.QueryBean;
import com.jioc.controller.QueryHelper;
import com.jioc.util.QueryConstants;
import com.jioc.util.Utility;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.util.portlet.PortletProps;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

@Path(value = "/ticket")
public class TicketController {
	
	private static Log LOGGER = LogFactoryUtil.getLog(TicketController.class.getName());
	
	@POST
	@Path("/pushTicket")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public PushTicketResponseBean pushTicket(@Context HttpServletRequest req,   PushTicketRequestBean request) {
		PushTicketResponseBean response = null;		
		LOGGER.info("Header "+req.getHeader("X-API-Key"));
		LOGGER.info("IP : "+req.getRemoteAddr());
		LOGGER.info("hostname : "+req.getRemoteHost());
		
		try{
			if(Utility.allowUnauthorisedWSAccess(QueryConstants.SERVICE_NAME_PUSH_TICKET) || (Utility.validateWSKey(QueryConstants.SERVICE_NAME_PUSH_TICKET, req.getHeader("X-API-Key")) && Utility.validateAllowedIP4WS(QueryConstants.SERVICE_NAME_PUSH_TICKET, req.getRemoteAddr()))){
				if(Validator.isNotNull(request) && Validator.isNotNull(request.getTicketDetails())){
					LOGGER.info(new StringBuilder("Create query REST request received pc_id:").append(request.getTicketDetails().getTicketId()).append(" emailId:").append(request.getTicketDetails().getOwnerEmailAddress()).append(" source:").append(request.getTicketDetails().getOrigin()).append(" description:").append(request.getTicketDetails().getDescription()));
					if(Validator.isNotNull(request.getTicketDetails().getOrigin()) && QueryConstants.QUERY_SOURCE_PARTNER_CENTRAL.equalsIgnoreCase(request.getTicketDetails().getOrigin())){
						request.getTicketDetails().setOrigin(QueryConstants.QUERY_SOURCE_PC);
					}
					QueryBean queryBean = QueryHelper.raiseQueryExt(request.getTicketDetails().getTicketId(), request.getTicketDetails().getOwnerEmailAddress(), request.getTicketDetails().getOrigin(), request.getTicketDetails().getDescription());
					response = createResponseJson(queryBean);
					LOGGER.info("Create query REST response:"+response.toString());
				}else{
					LOGGER.info("Empty service input");
				}
			}else{
				QueryBean queryBean = new QueryBean();
				LOGGER.info("Unauthorised access");
				queryBean.setServiceStatus(QueryConstants.SERVICE_STATUS_FAILURE);
				queryBean.setServiceErrCode(PortletProps.get(QueryConstants.SERVICE_ERR_CODE_UNAUTHORISED_ACCESS));
				queryBean.setServiceErrMsg(PortletProps.get(QueryConstants.SERVICE_ERR_MSG_UNAUTHORISED_ACCESS));
				response = createResponseJson(queryBean);
			}
			
		}catch(Exception e){
			LOGGER.error("Exception while processing request");
		}
		
		return response;
	}
	
	private static PushTicketResponseBean createResponseJson(QueryBean queryBean){
		PushTicketResponseBean response = new PushTicketResponseBean();
		List<PushTicketResponseErrorBean> errors = new ArrayList<PushTicketResponseErrorBean>();
		PushTicketResponseErrorBean error = new PushTicketResponseErrorBean();
		
		response.setNativeTicketId(queryBean.getPcId());
		if(QueryConstants.SERVICE_STATUS_SUCCESS.equalsIgnoreCase(queryBean.getServiceStatus())){
			response.setCaseId(queryBean.getIncidentId());
			response.setMessage("Transaction Successfull");
			response.setSuccess("true");
		}else{
			response.setCaseId("");
			response.setMessage("");
			response.setSuccess("false");
			error.setCode(queryBean.getServiceErrCode());
			error.setReason(queryBean.getServiceErrMsg());
			error.setDetails("");
			errors.add(error);
		}
		response.setErrors(errors);
		return response;
	}
}
