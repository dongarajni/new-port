/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model.impl;

import com.jioc.query.model.Emp_User_Mapping;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing Emp_User_Mapping in entity cache.
 *
 * @author shantaram.chavan
 * @see Emp_User_Mapping
 * @generated
 */
public class Emp_User_MappingCacheModel implements CacheModel<Emp_User_Mapping>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{userId=");
		sb.append(userId);
		sb.append(", empId=");
		sb.append(empId);
		sb.append(", emailId=");
		sb.append(emailId);
		sb.append(", domainId=");
		sb.append(domainId);
		sb.append(", samlFederationId=");
		sb.append(samlFederationId);
		sb.append(", status=");
		sb.append(status);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Emp_User_Mapping toEntityModel() {
		Emp_User_MappingImpl emp_User_MappingImpl = new Emp_User_MappingImpl();

		emp_User_MappingImpl.setUserId(userId);

		if (empId == null) {
			emp_User_MappingImpl.setEmpId(StringPool.BLANK);
		}
		else {
			emp_User_MappingImpl.setEmpId(empId);
		}

		if (emailId == null) {
			emp_User_MappingImpl.setEmailId(StringPool.BLANK);
		}
		else {
			emp_User_MappingImpl.setEmailId(emailId);
		}

		if (domainId == null) {
			emp_User_MappingImpl.setDomainId(StringPool.BLANK);
		}
		else {
			emp_User_MappingImpl.setDomainId(domainId);
		}

		if (samlFederationId == null) {
			emp_User_MappingImpl.setSamlFederationId(StringPool.BLANK);
		}
		else {
			emp_User_MappingImpl.setSamlFederationId(samlFederationId);
		}

		emp_User_MappingImpl.setStatus(status);

		emp_User_MappingImpl.resetOriginalValues();

		return emp_User_MappingImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		userId = objectInput.readLong();
		empId = objectInput.readUTF();
		emailId = objectInput.readUTF();
		domainId = objectInput.readUTF();
		samlFederationId = objectInput.readUTF();
		status = objectInput.readInt();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(userId);

		if (empId == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(empId);
		}

		if (emailId == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(emailId);
		}

		if (domainId == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(domainId);
		}

		if (samlFederationId == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(samlFederationId);
		}

		objectOutput.writeInt(status);
	}

	public long userId;
	public String empId;
	public String emailId;
	public String domainId;
	public String samlFederationId;
	public int status;
}