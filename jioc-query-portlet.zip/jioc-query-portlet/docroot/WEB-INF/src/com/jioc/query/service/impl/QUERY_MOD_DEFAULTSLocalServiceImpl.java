/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.impl;

import com.jioc.query.model.QUERY_MOD_DEFAULTS;
import com.jioc.query.service.base.QUERY_MOD_DEFAULTSLocalServiceBaseImpl;
import com.jioc.util.QueryConstants;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.List;

/**
 * The implementation of the q u e r y_ m o d_ d e f a u l t s local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jioc.query.service.QUERY_MOD_DEFAULTSLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author shantaram.chavan
 * @see com.jioc.query.service.base.QUERY_MOD_DEFAULTSLocalServiceBaseImpl
 * @see com.jioc.query.service.QUERY_MOD_DEFAULTSLocalServiceUtil
 */
public class QUERY_MOD_DEFAULTSLocalServiceImpl extends QUERY_MOD_DEFAULTSLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.jioc.query.service.QUERY_MOD_DEFAULTSLocalServiceUtil} to access the q u e r y_ m o d_ d e f a u l t s local service.
	 */
	
	private static Log LOGGER = LogFactoryUtil.getLog(QUERY_MOD_DEFAULTSLocalServiceImpl.class.getName());
	
	public QUERY_MOD_DEFAULTS findQueryModDefaultsByCurrType(String type, String currVal, int queueLevel){
		try {
			List<QUERY_MOD_DEFAULTS> queryModDefaultsList = query_mod_defaultsPersistence.findByCurrType (type, currVal, QueryConstants.QUERY_MOD_DEFAULTS_ACTIVE, queueLevel);
			if(Validator.isNotNull(queryModDefaultsList) && queryModDefaultsList.size() > 0){
				return queryModDefaultsList.get(0);
			}
		} catch (SystemException e) {
			LOGGER.error("Exception while fetching queryModDefaults" + e.getMessage());
		}
		
		
		return null;
	}
}