/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.impl;

import com.jioc.query.model.RESOLVER_DEFAULTS;
import com.jioc.query.service.base.RESOLVER_DEFAULTSLocalServiceBaseImpl;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.Validator;

import java.util.List;

/**
 * The implementation of the r e s o l v e r_ d e f a u l t s local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jioc.query.service.RESOLVER_DEFAULTSLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author shantaram.chavan
 * @see com.jioc.query.service.base.RESOLVER_DEFAULTSLocalServiceBaseImpl
 * @see com.jioc.query.service.RESOLVER_DEFAULTSLocalServiceUtil
 */
public class RESOLVER_DEFAULTSLocalServiceImpl
	extends RESOLVER_DEFAULTSLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.jioc.query.service.RESOLVER_DEFAULTSLocalServiceUtil} to access the r e s o l v e r_ d e f a u l t s local service.
	 */
	
	public RESOLVER_DEFAULTS findResolverDefaults(String type, String value){
		try {
			List<RESOLVER_DEFAULTS> resolverDefaults4OCList = resolver_defaultsPersistence.findByTypeValue(type, value); 
			if(Validator.isNotNull(resolverDefaults4OCList) && resolverDefaults4OCList.size() > 0){
				return resolverDefaults4OCList.get(0);
			}
		} catch (SystemException e) {
			e.printStackTrace();
		}
		
		return null;
	}
}