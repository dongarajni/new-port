/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model.impl;

import com.jioc.query.model.RESOLVER_LEVEL_MST;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing RESOLVER_LEVEL_MST in entity cache.
 *
 * @author shantaram.chavan
 * @see RESOLVER_LEVEL_MST
 * @generated
 */
public class RESOLVER_LEVEL_MSTCacheModel implements CacheModel<RESOLVER_LEVEL_MST>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(7);

		sb.append("{LEVEL_ID=");
		sb.append(LEVEL_ID);
		sb.append(", LEVEL_NAME=");
		sb.append(LEVEL_NAME);
		sb.append(", RESOLVER_LEVEL=");
		sb.append(RESOLVER_LEVEL);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public RESOLVER_LEVEL_MST toEntityModel() {
		RESOLVER_LEVEL_MSTImpl resolver_level_mstImpl = new RESOLVER_LEVEL_MSTImpl();

		resolver_level_mstImpl.setLEVEL_ID(LEVEL_ID);

		if (LEVEL_NAME == null) {
			resolver_level_mstImpl.setLEVEL_NAME(StringPool.BLANK);
		}
		else {
			resolver_level_mstImpl.setLEVEL_NAME(LEVEL_NAME);
		}

		resolver_level_mstImpl.setRESOLVER_LEVEL(RESOLVER_LEVEL);

		resolver_level_mstImpl.resetOriginalValues();

		return resolver_level_mstImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		LEVEL_ID = objectInput.readLong();
		LEVEL_NAME = objectInput.readUTF();
		RESOLVER_LEVEL = objectInput.readInt();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(LEVEL_ID);

		if (LEVEL_NAME == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(LEVEL_NAME);
		}

		objectOutput.writeInt(RESOLVER_LEVEL);
	}

	public long LEVEL_ID;
	public String LEVEL_NAME;
	public int RESOLVER_LEVEL;
}