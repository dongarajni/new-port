/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model.impl;

import com.jioc.query.model.Query_Attachments;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing Query_Attachments in entity cache.
 *
 * @author shantaram.chavan
 * @see Query_Attachments
 * @generated
 */
public class Query_AttachmentsCacheModel implements CacheModel<Query_Attachments>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{AttachmentId=");
		sb.append(AttachmentId);
		sb.append(", fileEntryId=");
		sb.append(fileEntryId);
		sb.append(", updatedBy=");
		sb.append(updatedBy);
		sb.append(", updatedTimestamp=");
		sb.append(updatedTimestamp);
		sb.append(", queryId=");
		sb.append(queryId);
		sb.append(", file_name=");
		sb.append(file_name);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Query_Attachments toEntityModel() {
		Query_AttachmentsImpl query_AttachmentsImpl = new Query_AttachmentsImpl();

		query_AttachmentsImpl.setAttachmentId(AttachmentId);
		query_AttachmentsImpl.setFileEntryId(fileEntryId);
		query_AttachmentsImpl.setUpdatedBy(updatedBy);

		if (updatedTimestamp == Long.MIN_VALUE) {
			query_AttachmentsImpl.setUpdatedTimestamp(null);
		}
		else {
			query_AttachmentsImpl.setUpdatedTimestamp(new Date(updatedTimestamp));
		}

		query_AttachmentsImpl.setQueryId(queryId);

		if (file_name == null) {
			query_AttachmentsImpl.setFile_name(StringPool.BLANK);
		}
		else {
			query_AttachmentsImpl.setFile_name(file_name);
		}

		query_AttachmentsImpl.resetOriginalValues();

		return query_AttachmentsImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		AttachmentId = objectInput.readLong();
		fileEntryId = objectInput.readLong();
		updatedBy = objectInput.readLong();
		updatedTimestamp = objectInput.readLong();
		queryId = objectInput.readLong();
		file_name = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(AttachmentId);
		objectOutput.writeLong(fileEntryId);
		objectOutput.writeLong(updatedBy);
		objectOutput.writeLong(updatedTimestamp);
		objectOutput.writeLong(queryId);

		if (file_name == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(file_name);
		}
	}

	public long AttachmentId;
	public long fileEntryId;
	public long updatedBy;
	public long updatedTimestamp;
	public long queryId;
	public String file_name;
}