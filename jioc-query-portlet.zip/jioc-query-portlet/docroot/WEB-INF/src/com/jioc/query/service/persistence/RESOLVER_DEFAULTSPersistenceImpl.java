/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.NoSuchRESOLVER_DEFAULTSException;
import com.jioc.query.model.RESOLVER_DEFAULTS;
import com.jioc.query.model.impl.RESOLVER_DEFAULTSImpl;
import com.jioc.query.model.impl.RESOLVER_DEFAULTSModelImpl;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the r e s o l v e r_ d e f a u l t s service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see RESOLVER_DEFAULTSPersistence
 * @see RESOLVER_DEFAULTSUtil
 * @generated
 */
public class RESOLVER_DEFAULTSPersistenceImpl extends BasePersistenceImpl<RESOLVER_DEFAULTS>
	implements RESOLVER_DEFAULTSPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link RESOLVER_DEFAULTSUtil} to access the r e s o l v e r_ d e f a u l t s persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = RESOLVER_DEFAULTSImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(RESOLVER_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			RESOLVER_DEFAULTSModelImpl.FINDER_CACHE_ENABLED,
			RESOLVER_DEFAULTSImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(RESOLVER_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			RESOLVER_DEFAULTSModelImpl.FINDER_CACHE_ENABLED,
			RESOLVER_DEFAULTSImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(RESOLVER_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			RESOLVER_DEFAULTSModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_TYPEVALUE =
		new FinderPath(RESOLVER_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			RESOLVER_DEFAULTSModelImpl.FINDER_CACHE_ENABLED,
			RESOLVER_DEFAULTSImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByTypeValue",
			new String[] {
				String.class.getName(), String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TYPEVALUE =
		new FinderPath(RESOLVER_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			RESOLVER_DEFAULTSModelImpl.FINDER_CACHE_ENABLED,
			RESOLVER_DEFAULTSImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByTypeValue",
			new String[] { String.class.getName(), String.class.getName() },
			RESOLVER_DEFAULTSModelImpl.TYPE_COLUMN_BITMASK |
			RESOLVER_DEFAULTSModelImpl.VALUE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_TYPEVALUE = new FinderPath(RESOLVER_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			RESOLVER_DEFAULTSModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByTypeValue",
			new String[] { String.class.getName(), String.class.getName() });

	/**
	 * Returns all the r e s o l v e r_ d e f a u l t ses where TYPE = &#63; and VALUE = &#63;.
	 *
	 * @param TYPE the t y p e
	 * @param VALUE the v a l u e
	 * @return the matching r e s o l v e r_ d e f a u l t ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RESOLVER_DEFAULTS> findByTypeValue(String TYPE, String VALUE)
		throws SystemException {
		return findByTypeValue(TYPE, VALUE, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the r e s o l v e r_ d e f a u l t ses where TYPE = &#63; and VALUE = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.RESOLVER_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param TYPE the t y p e
	 * @param VALUE the v a l u e
	 * @param start the lower bound of the range of r e s o l v e r_ d e f a u l t ses
	 * @param end the upper bound of the range of r e s o l v e r_ d e f a u l t ses (not inclusive)
	 * @return the range of matching r e s o l v e r_ d e f a u l t ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RESOLVER_DEFAULTS> findByTypeValue(String TYPE, String VALUE,
		int start, int end) throws SystemException {
		return findByTypeValue(TYPE, VALUE, start, end, null);
	}

	/**
	 * Returns an ordered range of all the r e s o l v e r_ d e f a u l t ses where TYPE = &#63; and VALUE = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.RESOLVER_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param TYPE the t y p e
	 * @param VALUE the v a l u e
	 * @param start the lower bound of the range of r e s o l v e r_ d e f a u l t ses
	 * @param end the upper bound of the range of r e s o l v e r_ d e f a u l t ses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching r e s o l v e r_ d e f a u l t ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RESOLVER_DEFAULTS> findByTypeValue(String TYPE, String VALUE,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TYPEVALUE;
			finderArgs = new Object[] { TYPE, VALUE };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_TYPEVALUE;
			finderArgs = new Object[] { TYPE, VALUE, start, end, orderByComparator };
		}

		List<RESOLVER_DEFAULTS> list = (List<RESOLVER_DEFAULTS>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (RESOLVER_DEFAULTS resolver_defaults : list) {
				if (!Validator.equals(TYPE, resolver_defaults.getTYPE()) ||
						!Validator.equals(VALUE, resolver_defaults.getVALUE())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_RESOLVER_DEFAULTS_WHERE);

			boolean bindTYPE = false;

			if (TYPE == null) {
				query.append(_FINDER_COLUMN_TYPEVALUE_TYPE_1);
			}
			else if (TYPE.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_TYPEVALUE_TYPE_3);
			}
			else {
				bindTYPE = true;

				query.append(_FINDER_COLUMN_TYPEVALUE_TYPE_2);
			}

			boolean bindVALUE = false;

			if (VALUE == null) {
				query.append(_FINDER_COLUMN_TYPEVALUE_VALUE_1);
			}
			else if (VALUE.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_TYPEVALUE_VALUE_3);
			}
			else {
				bindVALUE = true;

				query.append(_FINDER_COLUMN_TYPEVALUE_VALUE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(RESOLVER_DEFAULTSModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindTYPE) {
					qPos.add(TYPE.toLowerCase());
				}

				if (bindVALUE) {
					qPos.add(VALUE.toLowerCase());
				}

				if (!pagination) {
					list = (List<RESOLVER_DEFAULTS>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<RESOLVER_DEFAULTS>(list);
				}
				else {
					list = (List<RESOLVER_DEFAULTS>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first r e s o l v e r_ d e f a u l t s in the ordered set where TYPE = &#63; and VALUE = &#63;.
	 *
	 * @param TYPE the t y p e
	 * @param VALUE the v a l u e
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching r e s o l v e r_ d e f a u l t s
	 * @throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException if a matching r e s o l v e r_ d e f a u l t s could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RESOLVER_DEFAULTS findByTypeValue_First(String TYPE, String VALUE,
		OrderByComparator orderByComparator)
		throws NoSuchRESOLVER_DEFAULTSException, SystemException {
		RESOLVER_DEFAULTS resolver_defaults = fetchByTypeValue_First(TYPE,
				VALUE, orderByComparator);

		if (resolver_defaults != null) {
			return resolver_defaults;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("TYPE=");
		msg.append(TYPE);

		msg.append(", VALUE=");
		msg.append(VALUE);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchRESOLVER_DEFAULTSException(msg.toString());
	}

	/**
	 * Returns the first r e s o l v e r_ d e f a u l t s in the ordered set where TYPE = &#63; and VALUE = &#63;.
	 *
	 * @param TYPE the t y p e
	 * @param VALUE the v a l u e
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching r e s o l v e r_ d e f a u l t s, or <code>null</code> if a matching r e s o l v e r_ d e f a u l t s could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RESOLVER_DEFAULTS fetchByTypeValue_First(String TYPE, String VALUE,
		OrderByComparator orderByComparator) throws SystemException {
		List<RESOLVER_DEFAULTS> list = findByTypeValue(TYPE, VALUE, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last r e s o l v e r_ d e f a u l t s in the ordered set where TYPE = &#63; and VALUE = &#63;.
	 *
	 * @param TYPE the t y p e
	 * @param VALUE the v a l u e
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching r e s o l v e r_ d e f a u l t s
	 * @throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException if a matching r e s o l v e r_ d e f a u l t s could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RESOLVER_DEFAULTS findByTypeValue_Last(String TYPE, String VALUE,
		OrderByComparator orderByComparator)
		throws NoSuchRESOLVER_DEFAULTSException, SystemException {
		RESOLVER_DEFAULTS resolver_defaults = fetchByTypeValue_Last(TYPE,
				VALUE, orderByComparator);

		if (resolver_defaults != null) {
			return resolver_defaults;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("TYPE=");
		msg.append(TYPE);

		msg.append(", VALUE=");
		msg.append(VALUE);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchRESOLVER_DEFAULTSException(msg.toString());
	}

	/**
	 * Returns the last r e s o l v e r_ d e f a u l t s in the ordered set where TYPE = &#63; and VALUE = &#63;.
	 *
	 * @param TYPE the t y p e
	 * @param VALUE the v a l u e
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching r e s o l v e r_ d e f a u l t s, or <code>null</code> if a matching r e s o l v e r_ d e f a u l t s could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RESOLVER_DEFAULTS fetchByTypeValue_Last(String TYPE, String VALUE,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByTypeValue(TYPE, VALUE);

		if (count == 0) {
			return null;
		}

		List<RESOLVER_DEFAULTS> list = findByTypeValue(TYPE, VALUE, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the r e s o l v e r_ d e f a u l t ses before and after the current r e s o l v e r_ d e f a u l t s in the ordered set where TYPE = &#63; and VALUE = &#63;.
	 *
	 * @param DEFAULT_ID the primary key of the current r e s o l v e r_ d e f a u l t s
	 * @param TYPE the t y p e
	 * @param VALUE the v a l u e
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next r e s o l v e r_ d e f a u l t s
	 * @throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException if a r e s o l v e r_ d e f a u l t s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RESOLVER_DEFAULTS[] findByTypeValue_PrevAndNext(long DEFAULT_ID,
		String TYPE, String VALUE, OrderByComparator orderByComparator)
		throws NoSuchRESOLVER_DEFAULTSException, SystemException {
		RESOLVER_DEFAULTS resolver_defaults = findByPrimaryKey(DEFAULT_ID);

		Session session = null;

		try {
			session = openSession();

			RESOLVER_DEFAULTS[] array = new RESOLVER_DEFAULTSImpl[3];

			array[0] = getByTypeValue_PrevAndNext(session, resolver_defaults,
					TYPE, VALUE, orderByComparator, true);

			array[1] = resolver_defaults;

			array[2] = getByTypeValue_PrevAndNext(session, resolver_defaults,
					TYPE, VALUE, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected RESOLVER_DEFAULTS getByTypeValue_PrevAndNext(Session session,
		RESOLVER_DEFAULTS resolver_defaults, String TYPE, String VALUE,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_RESOLVER_DEFAULTS_WHERE);

		boolean bindTYPE = false;

		if (TYPE == null) {
			query.append(_FINDER_COLUMN_TYPEVALUE_TYPE_1);
		}
		else if (TYPE.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_TYPEVALUE_TYPE_3);
		}
		else {
			bindTYPE = true;

			query.append(_FINDER_COLUMN_TYPEVALUE_TYPE_2);
		}

		boolean bindVALUE = false;

		if (VALUE == null) {
			query.append(_FINDER_COLUMN_TYPEVALUE_VALUE_1);
		}
		else if (VALUE.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_TYPEVALUE_VALUE_3);
		}
		else {
			bindVALUE = true;

			query.append(_FINDER_COLUMN_TYPEVALUE_VALUE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(RESOLVER_DEFAULTSModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindTYPE) {
			qPos.add(TYPE.toLowerCase());
		}

		if (bindVALUE) {
			qPos.add(VALUE.toLowerCase());
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(resolver_defaults);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<RESOLVER_DEFAULTS> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the r e s o l v e r_ d e f a u l t ses where TYPE = &#63; and VALUE = &#63; from the database.
	 *
	 * @param TYPE the t y p e
	 * @param VALUE the v a l u e
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByTypeValue(String TYPE, String VALUE)
		throws SystemException {
		for (RESOLVER_DEFAULTS resolver_defaults : findByTypeValue(TYPE, VALUE,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(resolver_defaults);
		}
	}

	/**
	 * Returns the number of r e s o l v e r_ d e f a u l t ses where TYPE = &#63; and VALUE = &#63;.
	 *
	 * @param TYPE the t y p e
	 * @param VALUE the v a l u e
	 * @return the number of matching r e s o l v e r_ d e f a u l t ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByTypeValue(String TYPE, String VALUE)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_TYPEVALUE;

		Object[] finderArgs = new Object[] { TYPE, VALUE };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_RESOLVER_DEFAULTS_WHERE);

			boolean bindTYPE = false;

			if (TYPE == null) {
				query.append(_FINDER_COLUMN_TYPEVALUE_TYPE_1);
			}
			else if (TYPE.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_TYPEVALUE_TYPE_3);
			}
			else {
				bindTYPE = true;

				query.append(_FINDER_COLUMN_TYPEVALUE_TYPE_2);
			}

			boolean bindVALUE = false;

			if (VALUE == null) {
				query.append(_FINDER_COLUMN_TYPEVALUE_VALUE_1);
			}
			else if (VALUE.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_TYPEVALUE_VALUE_3);
			}
			else {
				bindVALUE = true;

				query.append(_FINDER_COLUMN_TYPEVALUE_VALUE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindTYPE) {
					qPos.add(TYPE.toLowerCase());
				}

				if (bindVALUE) {
					qPos.add(VALUE.toLowerCase());
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_TYPEVALUE_TYPE_1 = "resolver_defaults.TYPE IS NULL AND ";
	private static final String _FINDER_COLUMN_TYPEVALUE_TYPE_2 = "lower(resolver_defaults.TYPE) = ? AND ";
	private static final String _FINDER_COLUMN_TYPEVALUE_TYPE_3 = "(resolver_defaults.TYPE IS NULL OR resolver_defaults.TYPE = '') AND ";
	private static final String _FINDER_COLUMN_TYPEVALUE_VALUE_1 = "resolver_defaults.VALUE IS NULL";
	private static final String _FINDER_COLUMN_TYPEVALUE_VALUE_2 = "lower(resolver_defaults.VALUE) = ?";
	private static final String _FINDER_COLUMN_TYPEVALUE_VALUE_3 = "(resolver_defaults.VALUE IS NULL OR resolver_defaults.VALUE = '')";

	public RESOLVER_DEFAULTSPersistenceImpl() {
		setModelClass(RESOLVER_DEFAULTS.class);
	}

	/**
	 * Caches the r e s o l v e r_ d e f a u l t s in the entity cache if it is enabled.
	 *
	 * @param resolver_defaults the r e s o l v e r_ d e f a u l t s
	 */
	@Override
	public void cacheResult(RESOLVER_DEFAULTS resolver_defaults) {
		EntityCacheUtil.putResult(RESOLVER_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			RESOLVER_DEFAULTSImpl.class, resolver_defaults.getPrimaryKey(),
			resolver_defaults);

		resolver_defaults.resetOriginalValues();
	}

	/**
	 * Caches the r e s o l v e r_ d e f a u l t ses in the entity cache if it is enabled.
	 *
	 * @param resolver_defaultses the r e s o l v e r_ d e f a u l t ses
	 */
	@Override
	public void cacheResult(List<RESOLVER_DEFAULTS> resolver_defaultses) {
		for (RESOLVER_DEFAULTS resolver_defaults : resolver_defaultses) {
			if (EntityCacheUtil.getResult(
						RESOLVER_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
						RESOLVER_DEFAULTSImpl.class,
						resolver_defaults.getPrimaryKey()) == null) {
				cacheResult(resolver_defaults);
			}
			else {
				resolver_defaults.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all r e s o l v e r_ d e f a u l t ses.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(RESOLVER_DEFAULTSImpl.class.getName());
		}

		EntityCacheUtil.clearCache(RESOLVER_DEFAULTSImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the r e s o l v e r_ d e f a u l t s.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(RESOLVER_DEFAULTS resolver_defaults) {
		EntityCacheUtil.removeResult(RESOLVER_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			RESOLVER_DEFAULTSImpl.class, resolver_defaults.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<RESOLVER_DEFAULTS> resolver_defaultses) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (RESOLVER_DEFAULTS resolver_defaults : resolver_defaultses) {
			EntityCacheUtil.removeResult(RESOLVER_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
				RESOLVER_DEFAULTSImpl.class, resolver_defaults.getPrimaryKey());
		}
	}

	/**
	 * Creates a new r e s o l v e r_ d e f a u l t s with the primary key. Does not add the r e s o l v e r_ d e f a u l t s to the database.
	 *
	 * @param DEFAULT_ID the primary key for the new r e s o l v e r_ d e f a u l t s
	 * @return the new r e s o l v e r_ d e f a u l t s
	 */
	@Override
	public RESOLVER_DEFAULTS create(long DEFAULT_ID) {
		RESOLVER_DEFAULTS resolver_defaults = new RESOLVER_DEFAULTSImpl();

		resolver_defaults.setNew(true);
		resolver_defaults.setPrimaryKey(DEFAULT_ID);

		return resolver_defaults;
	}

	/**
	 * Removes the r e s o l v e r_ d e f a u l t s with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param DEFAULT_ID the primary key of the r e s o l v e r_ d e f a u l t s
	 * @return the r e s o l v e r_ d e f a u l t s that was removed
	 * @throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException if a r e s o l v e r_ d e f a u l t s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RESOLVER_DEFAULTS remove(long DEFAULT_ID)
		throws NoSuchRESOLVER_DEFAULTSException, SystemException {
		return remove((Serializable)DEFAULT_ID);
	}

	/**
	 * Removes the r e s o l v e r_ d e f a u l t s with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the r e s o l v e r_ d e f a u l t s
	 * @return the r e s o l v e r_ d e f a u l t s that was removed
	 * @throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException if a r e s o l v e r_ d e f a u l t s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RESOLVER_DEFAULTS remove(Serializable primaryKey)
		throws NoSuchRESOLVER_DEFAULTSException, SystemException {
		Session session = null;

		try {
			session = openSession();

			RESOLVER_DEFAULTS resolver_defaults = (RESOLVER_DEFAULTS)session.get(RESOLVER_DEFAULTSImpl.class,
					primaryKey);

			if (resolver_defaults == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchRESOLVER_DEFAULTSException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(resolver_defaults);
		}
		catch (NoSuchRESOLVER_DEFAULTSException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected RESOLVER_DEFAULTS removeImpl(RESOLVER_DEFAULTS resolver_defaults)
		throws SystemException {
		resolver_defaults = toUnwrappedModel(resolver_defaults);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(resolver_defaults)) {
				resolver_defaults = (RESOLVER_DEFAULTS)session.get(RESOLVER_DEFAULTSImpl.class,
						resolver_defaults.getPrimaryKeyObj());
			}

			if (resolver_defaults != null) {
				session.delete(resolver_defaults);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (resolver_defaults != null) {
			clearCache(resolver_defaults);
		}

		return resolver_defaults;
	}

	@Override
	public RESOLVER_DEFAULTS updateImpl(
		com.jioc.query.model.RESOLVER_DEFAULTS resolver_defaults)
		throws SystemException {
		resolver_defaults = toUnwrappedModel(resolver_defaults);

		boolean isNew = resolver_defaults.isNew();

		RESOLVER_DEFAULTSModelImpl resolver_defaultsModelImpl = (RESOLVER_DEFAULTSModelImpl)resolver_defaults;

		Session session = null;

		try {
			session = openSession();

			if (resolver_defaults.isNew()) {
				session.save(resolver_defaults);

				resolver_defaults.setNew(false);
			}
			else {
				session.merge(resolver_defaults);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !RESOLVER_DEFAULTSModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((resolver_defaultsModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TYPEVALUE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						resolver_defaultsModelImpl.getOriginalTYPE(),
						resolver_defaultsModelImpl.getOriginalVALUE()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TYPEVALUE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TYPEVALUE,
					args);

				args = new Object[] {
						resolver_defaultsModelImpl.getTYPE(),
						resolver_defaultsModelImpl.getVALUE()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TYPEVALUE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_TYPEVALUE,
					args);
			}
		}

		EntityCacheUtil.putResult(RESOLVER_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
			RESOLVER_DEFAULTSImpl.class, resolver_defaults.getPrimaryKey(),
			resolver_defaults);

		return resolver_defaults;
	}

	protected RESOLVER_DEFAULTS toUnwrappedModel(
		RESOLVER_DEFAULTS resolver_defaults) {
		if (resolver_defaults instanceof RESOLVER_DEFAULTSImpl) {
			return resolver_defaults;
		}

		RESOLVER_DEFAULTSImpl resolver_defaultsImpl = new RESOLVER_DEFAULTSImpl();

		resolver_defaultsImpl.setNew(resolver_defaults.isNew());
		resolver_defaultsImpl.setPrimaryKey(resolver_defaults.getPrimaryKey());

		resolver_defaultsImpl.setDEFAULT_ID(resolver_defaults.getDEFAULT_ID());
		resolver_defaultsImpl.setRESOLVER_LEVEL_ID(resolver_defaults.getRESOLVER_LEVEL_ID());
		resolver_defaultsImpl.setTYPE(resolver_defaults.getTYPE());
		resolver_defaultsImpl.setVALUE(resolver_defaults.getVALUE());
		resolver_defaultsImpl.setTO_DISPLAY(resolver_defaults.getTO_DISPLAY());

		return resolver_defaultsImpl;
	}

	/**
	 * Returns the r e s o l v e r_ d e f a u l t s with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the r e s o l v e r_ d e f a u l t s
	 * @return the r e s o l v e r_ d e f a u l t s
	 * @throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException if a r e s o l v e r_ d e f a u l t s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RESOLVER_DEFAULTS findByPrimaryKey(Serializable primaryKey)
		throws NoSuchRESOLVER_DEFAULTSException, SystemException {
		RESOLVER_DEFAULTS resolver_defaults = fetchByPrimaryKey(primaryKey);

		if (resolver_defaults == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchRESOLVER_DEFAULTSException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return resolver_defaults;
	}

	/**
	 * Returns the r e s o l v e r_ d e f a u l t s with the primary key or throws a {@link com.jioc.query.NoSuchRESOLVER_DEFAULTSException} if it could not be found.
	 *
	 * @param DEFAULT_ID the primary key of the r e s o l v e r_ d e f a u l t s
	 * @return the r e s o l v e r_ d e f a u l t s
	 * @throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException if a r e s o l v e r_ d e f a u l t s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RESOLVER_DEFAULTS findByPrimaryKey(long DEFAULT_ID)
		throws NoSuchRESOLVER_DEFAULTSException, SystemException {
		return findByPrimaryKey((Serializable)DEFAULT_ID);
	}

	/**
	 * Returns the r e s o l v e r_ d e f a u l t s with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the r e s o l v e r_ d e f a u l t s
	 * @return the r e s o l v e r_ d e f a u l t s, or <code>null</code> if a r e s o l v e r_ d e f a u l t s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RESOLVER_DEFAULTS fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		RESOLVER_DEFAULTS resolver_defaults = (RESOLVER_DEFAULTS)EntityCacheUtil.getResult(RESOLVER_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
				RESOLVER_DEFAULTSImpl.class, primaryKey);

		if (resolver_defaults == _nullRESOLVER_DEFAULTS) {
			return null;
		}

		if (resolver_defaults == null) {
			Session session = null;

			try {
				session = openSession();

				resolver_defaults = (RESOLVER_DEFAULTS)session.get(RESOLVER_DEFAULTSImpl.class,
						primaryKey);

				if (resolver_defaults != null) {
					cacheResult(resolver_defaults);
				}
				else {
					EntityCacheUtil.putResult(RESOLVER_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
						RESOLVER_DEFAULTSImpl.class, primaryKey,
						_nullRESOLVER_DEFAULTS);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(RESOLVER_DEFAULTSModelImpl.ENTITY_CACHE_ENABLED,
					RESOLVER_DEFAULTSImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return resolver_defaults;
	}

	/**
	 * Returns the r e s o l v e r_ d e f a u l t s with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param DEFAULT_ID the primary key of the r e s o l v e r_ d e f a u l t s
	 * @return the r e s o l v e r_ d e f a u l t s, or <code>null</code> if a r e s o l v e r_ d e f a u l t s with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public RESOLVER_DEFAULTS fetchByPrimaryKey(long DEFAULT_ID)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)DEFAULT_ID);
	}

	/**
	 * Returns all the r e s o l v e r_ d e f a u l t ses.
	 *
	 * @return the r e s o l v e r_ d e f a u l t ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RESOLVER_DEFAULTS> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the r e s o l v e r_ d e f a u l t ses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.RESOLVER_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of r e s o l v e r_ d e f a u l t ses
	 * @param end the upper bound of the range of r e s o l v e r_ d e f a u l t ses (not inclusive)
	 * @return the range of r e s o l v e r_ d e f a u l t ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RESOLVER_DEFAULTS> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the r e s o l v e r_ d e f a u l t ses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.RESOLVER_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of r e s o l v e r_ d e f a u l t ses
	 * @param end the upper bound of the range of r e s o l v e r_ d e f a u l t ses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of r e s o l v e r_ d e f a u l t ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<RESOLVER_DEFAULTS> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<RESOLVER_DEFAULTS> list = (List<RESOLVER_DEFAULTS>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_RESOLVER_DEFAULTS);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_RESOLVER_DEFAULTS;

				if (pagination) {
					sql = sql.concat(RESOLVER_DEFAULTSModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<RESOLVER_DEFAULTS>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<RESOLVER_DEFAULTS>(list);
				}
				else {
					list = (List<RESOLVER_DEFAULTS>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the r e s o l v e r_ d e f a u l t ses from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (RESOLVER_DEFAULTS resolver_defaults : findAll()) {
			remove(resolver_defaults);
		}
	}

	/**
	 * Returns the number of r e s o l v e r_ d e f a u l t ses.
	 *
	 * @return the number of r e s o l v e r_ d e f a u l t ses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_RESOLVER_DEFAULTS);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the r e s o l v e r_ d e f a u l t s persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.jioc.query.model.RESOLVER_DEFAULTS")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<RESOLVER_DEFAULTS>> listenersList = new ArrayList<ModelListener<RESOLVER_DEFAULTS>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<RESOLVER_DEFAULTS>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(RESOLVER_DEFAULTSImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_RESOLVER_DEFAULTS = "SELECT resolver_defaults FROM RESOLVER_DEFAULTS resolver_defaults";
	private static final String _SQL_SELECT_RESOLVER_DEFAULTS_WHERE = "SELECT resolver_defaults FROM RESOLVER_DEFAULTS resolver_defaults WHERE ";
	private static final String _SQL_COUNT_RESOLVER_DEFAULTS = "SELECT COUNT(resolver_defaults) FROM RESOLVER_DEFAULTS resolver_defaults";
	private static final String _SQL_COUNT_RESOLVER_DEFAULTS_WHERE = "SELECT COUNT(resolver_defaults) FROM RESOLVER_DEFAULTS resolver_defaults WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "resolver_defaults.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No RESOLVER_DEFAULTS exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No RESOLVER_DEFAULTS exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(RESOLVER_DEFAULTSPersistenceImpl.class);
	private static RESOLVER_DEFAULTS _nullRESOLVER_DEFAULTS = new RESOLVER_DEFAULTSImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<RESOLVER_DEFAULTS> toCacheModel() {
				return _nullRESOLVER_DEFAULTSCacheModel;
			}
		};

	private static CacheModel<RESOLVER_DEFAULTS> _nullRESOLVER_DEFAULTSCacheModel =
		new CacheModel<RESOLVER_DEFAULTS>() {
			@Override
			public RESOLVER_DEFAULTS toEntityModel() {
				return _nullRESOLVER_DEFAULTS;
			}
		};
}