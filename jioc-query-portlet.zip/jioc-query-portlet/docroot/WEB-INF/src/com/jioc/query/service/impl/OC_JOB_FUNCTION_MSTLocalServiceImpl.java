/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.impl;

import com.jioc.query.model.OC_JOB_FUNCTION_MST;
import com.jioc.query.service.base.OC_JOB_FUNCTION_MSTLocalServiceBaseImpl;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;

import java.util.List;

import org.apache.log4j.spi.LoggerFactory;

/**
 * The implementation of the o c_ j o b_ f u n c t i o n_ m s t local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jioc.query.service.OC_JOB_FUNCTION_MSTLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author shantaram.chavan
 * @see com.jioc.query.service.base.OC_JOB_FUNCTION_MSTLocalServiceBaseImpl
 * @see com.jioc.query.service.OC_JOB_FUNCTION_MSTLocalServiceUtil
 */
public class OC_JOB_FUNCTION_MSTLocalServiceImpl extends OC_JOB_FUNCTION_MSTLocalServiceBaseImpl {
	
	Log LOGGER = LogFactoryUtil.getLog(OC_JOB_FUNCTION_MSTLocalServiceImpl.class.getName());
	
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.jioc.query.service.OC_JOB_FUNCTION_MSTLocalServiceUtil} to access the o c_ j o b_ f u n c t i o n_ m s t local service.
	 */
	
	public List<OC_JOB_FUNCTION_MST> findOcByAreaJobFunction(String area, String job, String subFunctionalArea){
		try{
			return oc_job_function_mstPersistence.findByAreaJobFunction(area, job, subFunctionalArea);
		}catch(Exception e){
			LOGGER.error("Exception while fetching oc by area, job and subFunctionalArea " + e.getMessage());
		}
		return null;
	}
}