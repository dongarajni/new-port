/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.impl;

import com.jioc.query.model.Emp_User_Mapping;
import com.jioc.query.service.base.Emp_User_MappingLocalServiceBaseImpl;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.Validator;

import java.util.List;

/**
 * The implementation of the emp_ user_ mapping local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jioc.query.service.Emp_User_MappingLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author shantaram.chavan
 * @see com.jioc.query.service.base.Emp_User_MappingLocalServiceBaseImpl
 * @see com.jioc.query.service.Emp_User_MappingLocalServiceUtil
 */
public class Emp_User_MappingLocalServiceImpl
	extends Emp_User_MappingLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.jioc.query.service.Emp_User_MappingLocalServiceUtil} to access the emp_ user_ mapping local service.
	 */
	
	public Emp_User_Mapping findEmpUserMappingByEmpId(String empId){
		try {
			List<Emp_User_Mapping> empUserMappingList = emp_User_MappingPersistence.findByEmpId(empId);
			if(Validator.isNotNull(empUserMappingList) && empUserMappingList.size() > 0){
				return empUserMappingList.get(0);
			}
			 
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public Emp_User_Mapping findEmpUserMappingByEmailId(String emailId){
		try {
			List<Emp_User_Mapping> empUserMappingList = emp_User_MappingPersistence.findByEmailId(emailId);
			if(Validator.isNotNull(empUserMappingList) && empUserMappingList.size() > 0){
				return empUserMappingList.get(0);
			}
			 
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
}