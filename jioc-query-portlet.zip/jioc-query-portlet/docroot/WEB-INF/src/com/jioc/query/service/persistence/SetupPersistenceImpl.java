/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.NoSuchSetupException;
import com.jioc.query.model.Setup;
import com.jioc.query.model.impl.SetupImpl;
import com.jioc.query.model.impl.SetupModelImpl;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the setup service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see SetupPersistence
 * @see SetupUtil
 * @generated
 */
public class SetupPersistenceImpl extends BasePersistenceImpl<Setup>
	implements SetupPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link SetupUtil} to access the setup persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = SetupImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(SetupModelImpl.ENTITY_CACHE_ENABLED,
			SetupModelImpl.FINDER_CACHE_ENABLED, SetupImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(SetupModelImpl.ENTITY_CACHE_ENABLED,
			SetupModelImpl.FINDER_CACHE_ENABLED, SetupImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(SetupModelImpl.ENTITY_CACHE_ENABLED,
			SetupModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_KEY = new FinderPath(SetupModelImpl.ENTITY_CACHE_ENABLED,
			SetupModelImpl.FINDER_CACHE_ENABLED, SetupImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBykey",
			new String[] {
				String.class.getName(), Integer.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_KEY = new FinderPath(SetupModelImpl.ENTITY_CACHE_ENABLED,
			SetupModelImpl.FINDER_CACHE_ENABLED, SetupImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBykey",
			new String[] { String.class.getName(), Integer.class.getName() },
			SetupModelImpl.KEY_COLUMN_BITMASK |
			SetupModelImpl.STATUS_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_KEY = new FinderPath(SetupModelImpl.ENTITY_CACHE_ENABLED,
			SetupModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBykey",
			new String[] { String.class.getName(), Integer.class.getName() });

	/**
	 * Returns all the setups where key = &#63; and status = &#63;.
	 *
	 * @param key the key
	 * @param status the status
	 * @return the matching setups
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Setup> findBykey(String key, int status)
		throws SystemException {
		return findBykey(key, status, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the setups where key = &#63; and status = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.SetupModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param key the key
	 * @param status the status
	 * @param start the lower bound of the range of setups
	 * @param end the upper bound of the range of setups (not inclusive)
	 * @return the range of matching setups
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Setup> findBykey(String key, int status, int start, int end)
		throws SystemException {
		return findBykey(key, status, start, end, null);
	}

	/**
	 * Returns an ordered range of all the setups where key = &#63; and status = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.SetupModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param key the key
	 * @param status the status
	 * @param start the lower bound of the range of setups
	 * @param end the upper bound of the range of setups (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching setups
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Setup> findBykey(String key, int status, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_KEY;
			finderArgs = new Object[] { key, status };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_KEY;
			finderArgs = new Object[] { key, status, start, end, orderByComparator };
		}

		List<Setup> list = (List<Setup>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Setup setup : list) {
				if (!Validator.equals(key, setup.getKey()) ||
						(status != setup.getStatus())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_SETUP_WHERE);

			boolean bindKey = false;

			if (key == null) {
				query.append(_FINDER_COLUMN_KEY_KEY_1);
			}
			else if (key.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_KEY_KEY_3);
			}
			else {
				bindKey = true;

				query.append(_FINDER_COLUMN_KEY_KEY_2);
			}

			query.append(_FINDER_COLUMN_KEY_STATUS_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(SetupModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindKey) {
					qPos.add(key);
				}

				qPos.add(status);

				if (!pagination) {
					list = (List<Setup>)QueryUtil.list(q, getDialect(), start,
							end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Setup>(list);
				}
				else {
					list = (List<Setup>)QueryUtil.list(q, getDialect(), start,
							end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first setup in the ordered set where key = &#63; and status = &#63;.
	 *
	 * @param key the key
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching setup
	 * @throws com.jioc.query.NoSuchSetupException if a matching setup could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Setup findBykey_First(String key, int status,
		OrderByComparator orderByComparator)
		throws NoSuchSetupException, SystemException {
		Setup setup = fetchBykey_First(key, status, orderByComparator);

		if (setup != null) {
			return setup;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("key=");
		msg.append(key);

		msg.append(", status=");
		msg.append(status);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSetupException(msg.toString());
	}

	/**
	 * Returns the first setup in the ordered set where key = &#63; and status = &#63;.
	 *
	 * @param key the key
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching setup, or <code>null</code> if a matching setup could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Setup fetchBykey_First(String key, int status,
		OrderByComparator orderByComparator) throws SystemException {
		List<Setup> list = findBykey(key, status, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last setup in the ordered set where key = &#63; and status = &#63;.
	 *
	 * @param key the key
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching setup
	 * @throws com.jioc.query.NoSuchSetupException if a matching setup could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Setup findBykey_Last(String key, int status,
		OrderByComparator orderByComparator)
		throws NoSuchSetupException, SystemException {
		Setup setup = fetchBykey_Last(key, status, orderByComparator);

		if (setup != null) {
			return setup;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("key=");
		msg.append(key);

		msg.append(", status=");
		msg.append(status);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchSetupException(msg.toString());
	}

	/**
	 * Returns the last setup in the ordered set where key = &#63; and status = &#63;.
	 *
	 * @param key the key
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching setup, or <code>null</code> if a matching setup could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Setup fetchBykey_Last(String key, int status,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countBykey(key, status);

		if (count == 0) {
			return null;
		}

		List<Setup> list = findBykey(key, status, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the setups before and after the current setup in the ordered set where key = &#63; and status = &#63;.
	 *
	 * @param setup_id the primary key of the current setup
	 * @param key the key
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next setup
	 * @throws com.jioc.query.NoSuchSetupException if a setup with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Setup[] findBykey_PrevAndNext(long setup_id, String key, int status,
		OrderByComparator orderByComparator)
		throws NoSuchSetupException, SystemException {
		Setup setup = findByPrimaryKey(setup_id);

		Session session = null;

		try {
			session = openSession();

			Setup[] array = new SetupImpl[3];

			array[0] = getBykey_PrevAndNext(session, setup, key, status,
					orderByComparator, true);

			array[1] = setup;

			array[2] = getBykey_PrevAndNext(session, setup, key, status,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Setup getBykey_PrevAndNext(Session session, Setup setup,
		String key, int status, OrderByComparator orderByComparator,
		boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_SETUP_WHERE);

		boolean bindKey = false;

		if (key == null) {
			query.append(_FINDER_COLUMN_KEY_KEY_1);
		}
		else if (key.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_KEY_KEY_3);
		}
		else {
			bindKey = true;

			query.append(_FINDER_COLUMN_KEY_KEY_2);
		}

		query.append(_FINDER_COLUMN_KEY_STATUS_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(SetupModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindKey) {
			qPos.add(key);
		}

		qPos.add(status);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(setup);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Setup> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the setups where key = &#63; and status = &#63; from the database.
	 *
	 * @param key the key
	 * @param status the status
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeBykey(String key, int status) throws SystemException {
		for (Setup setup : findBykey(key, status, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(setup);
		}
	}

	/**
	 * Returns the number of setups where key = &#63; and status = &#63;.
	 *
	 * @param key the key
	 * @param status the status
	 * @return the number of matching setups
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countBykey(String key, int status) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_KEY;

		Object[] finderArgs = new Object[] { key, status };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_SETUP_WHERE);

			boolean bindKey = false;

			if (key == null) {
				query.append(_FINDER_COLUMN_KEY_KEY_1);
			}
			else if (key.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_KEY_KEY_3);
			}
			else {
				bindKey = true;

				query.append(_FINDER_COLUMN_KEY_KEY_2);
			}

			query.append(_FINDER_COLUMN_KEY_STATUS_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindKey) {
					qPos.add(key);
				}

				qPos.add(status);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_KEY_KEY_1 = "setup.key IS NULL AND ";
	private static final String _FINDER_COLUMN_KEY_KEY_2 = "setup.key = ? AND ";
	private static final String _FINDER_COLUMN_KEY_KEY_3 = "(setup.key IS NULL OR setup.key = '') AND ";
	private static final String _FINDER_COLUMN_KEY_STATUS_2 = "setup.status = ?";

	public SetupPersistenceImpl() {
		setModelClass(Setup.class);
	}

	/**
	 * Caches the setup in the entity cache if it is enabled.
	 *
	 * @param setup the setup
	 */
	@Override
	public void cacheResult(Setup setup) {
		EntityCacheUtil.putResult(SetupModelImpl.ENTITY_CACHE_ENABLED,
			SetupImpl.class, setup.getPrimaryKey(), setup);

		setup.resetOriginalValues();
	}

	/**
	 * Caches the setups in the entity cache if it is enabled.
	 *
	 * @param setups the setups
	 */
	@Override
	public void cacheResult(List<Setup> setups) {
		for (Setup setup : setups) {
			if (EntityCacheUtil.getResult(SetupModelImpl.ENTITY_CACHE_ENABLED,
						SetupImpl.class, setup.getPrimaryKey()) == null) {
				cacheResult(setup);
			}
			else {
				setup.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all setups.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(SetupImpl.class.getName());
		}

		EntityCacheUtil.clearCache(SetupImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the setup.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(Setup setup) {
		EntityCacheUtil.removeResult(SetupModelImpl.ENTITY_CACHE_ENABLED,
			SetupImpl.class, setup.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<Setup> setups) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (Setup setup : setups) {
			EntityCacheUtil.removeResult(SetupModelImpl.ENTITY_CACHE_ENABLED,
				SetupImpl.class, setup.getPrimaryKey());
		}
	}

	/**
	 * Creates a new setup with the primary key. Does not add the setup to the database.
	 *
	 * @param setup_id the primary key for the new setup
	 * @return the new setup
	 */
	@Override
	public Setup create(long setup_id) {
		Setup setup = new SetupImpl();

		setup.setNew(true);
		setup.setPrimaryKey(setup_id);

		return setup;
	}

	/**
	 * Removes the setup with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param setup_id the primary key of the setup
	 * @return the setup that was removed
	 * @throws com.jioc.query.NoSuchSetupException if a setup with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Setup remove(long setup_id)
		throws NoSuchSetupException, SystemException {
		return remove((Serializable)setup_id);
	}

	/**
	 * Removes the setup with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the setup
	 * @return the setup that was removed
	 * @throws com.jioc.query.NoSuchSetupException if a setup with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Setup remove(Serializable primaryKey)
		throws NoSuchSetupException, SystemException {
		Session session = null;

		try {
			session = openSession();

			Setup setup = (Setup)session.get(SetupImpl.class, primaryKey);

			if (setup == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchSetupException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(setup);
		}
		catch (NoSuchSetupException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected Setup removeImpl(Setup setup) throws SystemException {
		setup = toUnwrappedModel(setup);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(setup)) {
				setup = (Setup)session.get(SetupImpl.class,
						setup.getPrimaryKeyObj());
			}

			if (setup != null) {
				session.delete(setup);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (setup != null) {
			clearCache(setup);
		}

		return setup;
	}

	@Override
	public Setup updateImpl(com.jioc.query.model.Setup setup)
		throws SystemException {
		setup = toUnwrappedModel(setup);

		boolean isNew = setup.isNew();

		SetupModelImpl setupModelImpl = (SetupModelImpl)setup;

		Session session = null;

		try {
			session = openSession();

			if (setup.isNew()) {
				session.save(setup);

				setup.setNew(false);
			}
			else {
				session.merge(setup);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !SetupModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((setupModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_KEY.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						setupModelImpl.getOriginalKey(),
						setupModelImpl.getOriginalStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_KEY, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_KEY,
					args);

				args = new Object[] {
						setupModelImpl.getKey(), setupModelImpl.getStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_KEY, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_KEY,
					args);
			}
		}

		EntityCacheUtil.putResult(SetupModelImpl.ENTITY_CACHE_ENABLED,
			SetupImpl.class, setup.getPrimaryKey(), setup);

		return setup;
	}

	protected Setup toUnwrappedModel(Setup setup) {
		if (setup instanceof SetupImpl) {
			return setup;
		}

		SetupImpl setupImpl = new SetupImpl();

		setupImpl.setNew(setup.isNew());
		setupImpl.setPrimaryKey(setup.getPrimaryKey());

		setupImpl.setSetup_id(setup.getSetup_id());
		setupImpl.setKey(setup.getKey());
		setupImpl.setVal1(setup.getVal1());
		setupImpl.setVal2(setup.getVal2());
		setupImpl.setStatus(setup.getStatus());
		setupImpl.setUpdated_timestamp(setup.getUpdated_timestamp());

		return setupImpl;
	}

	/**
	 * Returns the setup with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the setup
	 * @return the setup
	 * @throws com.jioc.query.NoSuchSetupException if a setup with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Setup findByPrimaryKey(Serializable primaryKey)
		throws NoSuchSetupException, SystemException {
		Setup setup = fetchByPrimaryKey(primaryKey);

		if (setup == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchSetupException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return setup;
	}

	/**
	 * Returns the setup with the primary key or throws a {@link com.jioc.query.NoSuchSetupException} if it could not be found.
	 *
	 * @param setup_id the primary key of the setup
	 * @return the setup
	 * @throws com.jioc.query.NoSuchSetupException if a setup with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Setup findByPrimaryKey(long setup_id)
		throws NoSuchSetupException, SystemException {
		return findByPrimaryKey((Serializable)setup_id);
	}

	/**
	 * Returns the setup with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the setup
	 * @return the setup, or <code>null</code> if a setup with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Setup fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		Setup setup = (Setup)EntityCacheUtil.getResult(SetupModelImpl.ENTITY_CACHE_ENABLED,
				SetupImpl.class, primaryKey);

		if (setup == _nullSetup) {
			return null;
		}

		if (setup == null) {
			Session session = null;

			try {
				session = openSession();

				setup = (Setup)session.get(SetupImpl.class, primaryKey);

				if (setup != null) {
					cacheResult(setup);
				}
				else {
					EntityCacheUtil.putResult(SetupModelImpl.ENTITY_CACHE_ENABLED,
						SetupImpl.class, primaryKey, _nullSetup);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(SetupModelImpl.ENTITY_CACHE_ENABLED,
					SetupImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return setup;
	}

	/**
	 * Returns the setup with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param setup_id the primary key of the setup
	 * @return the setup, or <code>null</code> if a setup with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Setup fetchByPrimaryKey(long setup_id) throws SystemException {
		return fetchByPrimaryKey((Serializable)setup_id);
	}

	/**
	 * Returns all the setups.
	 *
	 * @return the setups
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Setup> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the setups.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.SetupModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of setups
	 * @param end the upper bound of the range of setups (not inclusive)
	 * @return the range of setups
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Setup> findAll(int start, int end) throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the setups.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.SetupModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of setups
	 * @param end the upper bound of the range of setups (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of setups
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Setup> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<Setup> list = (List<Setup>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_SETUP);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_SETUP;

				if (pagination) {
					sql = sql.concat(SetupModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<Setup>)QueryUtil.list(q, getDialect(), start,
							end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Setup>(list);
				}
				else {
					list = (List<Setup>)QueryUtil.list(q, getDialect(), start,
							end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the setups from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (Setup setup : findAll()) {
			remove(setup);
		}
	}

	/**
	 * Returns the number of setups.
	 *
	 * @return the number of setups
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_SETUP);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	protected Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	/**
	 * Initializes the setup persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.jioc.query.model.Setup")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<Setup>> listenersList = new ArrayList<ModelListener<Setup>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<Setup>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(SetupImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_SETUP = "SELECT setup FROM Setup setup";
	private static final String _SQL_SELECT_SETUP_WHERE = "SELECT setup FROM Setup setup WHERE ";
	private static final String _SQL_COUNT_SETUP = "SELECT COUNT(setup) FROM Setup setup";
	private static final String _SQL_COUNT_SETUP_WHERE = "SELECT COUNT(setup) FROM Setup setup WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "setup.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No Setup exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No Setup exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(SetupPersistenceImpl.class);
	private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
				"key"
			});
	private static Setup _nullSetup = new SetupImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<Setup> toCacheModel() {
				return _nullSetupCacheModel;
			}
		};

	private static CacheModel<Setup> _nullSetupCacheModel = new CacheModel<Setup>() {
			@Override
			public Setup toEntityModel() {
				return _nullSetup;
			}
		};
}