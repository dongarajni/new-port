/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.impl;

import com.jioc.query.service.base.Query_Add_Param_OCLocalServiceBaseImpl;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.SQLQuery;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.util.Validator;

import java.util.List;

/**
 * The implementation of the query_ add_ param_ o c local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jioc.query.service.Query_Add_Param_OCLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author shantaram.chavan
 * @see com.jioc.query.service.base.Query_Add_Param_OCLocalServiceBaseImpl
 * @see com.jioc.query.service.Query_Add_Param_OCLocalServiceUtil
 */
public class Query_Add_Param_OCLocalServiceImpl
	extends Query_Add_Param_OCLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.jioc.query.service.Query_Add_Param_OCLocalServiceUtil} to access the query_ add_ param_ o c local service.
	 */
	
	public boolean enableAddParam(String oc){
		boolean enableAddParam = false;
		try {
			Session session =  query_Add_Param_OCPersistence.openSession(); 
			SQLQuery query = session.createSQLQuery("select * from jioc_query_add_param_oc where status=1 and upper(oc)=upper(?)");
			QueryPos pos = QueryPos.getInstance(query);
			pos.add(oc);
			List<Object[]> ocList = query.list();
			if(Validator.isNotNull(ocList) && ocList.size() > 0){
				enableAddParam = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return enableAddParam;
	}
}