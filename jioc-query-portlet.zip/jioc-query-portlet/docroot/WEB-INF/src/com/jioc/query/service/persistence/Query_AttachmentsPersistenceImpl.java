/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.NoSuchQuery_AttachmentsException;
import com.jioc.query.model.Query_Attachments;
import com.jioc.query.model.impl.Query_AttachmentsImpl;
import com.jioc.query.model.impl.Query_AttachmentsModelImpl;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the query_ attachments service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see Query_AttachmentsPersistence
 * @see Query_AttachmentsUtil
 * @generated
 */
public class Query_AttachmentsPersistenceImpl extends BasePersistenceImpl<Query_Attachments>
	implements Query_AttachmentsPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link Query_AttachmentsUtil} to access the query_ attachments persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = Query_AttachmentsImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(Query_AttachmentsModelImpl.ENTITY_CACHE_ENABLED,
			Query_AttachmentsModelImpl.FINDER_CACHE_ENABLED,
			Query_AttachmentsImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(Query_AttachmentsModelImpl.ENTITY_CACHE_ENABLED,
			Query_AttachmentsModelImpl.FINDER_CACHE_ENABLED,
			Query_AttachmentsImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(Query_AttachmentsModelImpl.ENTITY_CACHE_ENABLED,
			Query_AttachmentsModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_QUERYID = new FinderPath(Query_AttachmentsModelImpl.ENTITY_CACHE_ENABLED,
			Query_AttachmentsModelImpl.FINDER_CACHE_ENABLED,
			Query_AttachmentsImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByQueryId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_QUERYID =
		new FinderPath(Query_AttachmentsModelImpl.ENTITY_CACHE_ENABLED,
			Query_AttachmentsModelImpl.FINDER_CACHE_ENABLED,
			Query_AttachmentsImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByQueryId",
			new String[] { Long.class.getName() },
			Query_AttachmentsModelImpl.QUERYID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_QUERYID = new FinderPath(Query_AttachmentsModelImpl.ENTITY_CACHE_ENABLED,
			Query_AttachmentsModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByQueryId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the query_ attachmentses where queryId = &#63;.
	 *
	 * @param queryId the query ID
	 * @return the matching query_ attachmentses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Attachments> findByQueryId(long queryId)
		throws SystemException {
		return findByQueryId(queryId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the query_ attachmentses where queryId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_AttachmentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param queryId the query ID
	 * @param start the lower bound of the range of query_ attachmentses
	 * @param end the upper bound of the range of query_ attachmentses (not inclusive)
	 * @return the range of matching query_ attachmentses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Attachments> findByQueryId(long queryId, int start,
		int end) throws SystemException {
		return findByQueryId(queryId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the query_ attachmentses where queryId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_AttachmentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param queryId the query ID
	 * @param start the lower bound of the range of query_ attachmentses
	 * @param end the upper bound of the range of query_ attachmentses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching query_ attachmentses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Attachments> findByQueryId(long queryId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_QUERYID;
			finderArgs = new Object[] { queryId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_QUERYID;
			finderArgs = new Object[] { queryId, start, end, orderByComparator };
		}

		List<Query_Attachments> list = (List<Query_Attachments>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (Query_Attachments query_Attachments : list) {
				if ((queryId != query_Attachments.getQueryId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_QUERY_ATTACHMENTS_WHERE);

			query.append(_FINDER_COLUMN_QUERYID_QUERYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(Query_AttachmentsModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(queryId);

				if (!pagination) {
					list = (List<Query_Attachments>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Query_Attachments>(list);
				}
				else {
					list = (List<Query_Attachments>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first query_ attachments in the ordered set where queryId = &#63;.
	 *
	 * @param queryId the query ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching query_ attachments
	 * @throws com.jioc.query.NoSuchQuery_AttachmentsException if a matching query_ attachments could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Attachments findByQueryId_First(long queryId,
		OrderByComparator orderByComparator)
		throws NoSuchQuery_AttachmentsException, SystemException {
		Query_Attachments query_Attachments = fetchByQueryId_First(queryId,
				orderByComparator);

		if (query_Attachments != null) {
			return query_Attachments;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("queryId=");
		msg.append(queryId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchQuery_AttachmentsException(msg.toString());
	}

	/**
	 * Returns the first query_ attachments in the ordered set where queryId = &#63;.
	 *
	 * @param queryId the query ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching query_ attachments, or <code>null</code> if a matching query_ attachments could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Attachments fetchByQueryId_First(long queryId,
		OrderByComparator orderByComparator) throws SystemException {
		List<Query_Attachments> list = findByQueryId(queryId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last query_ attachments in the ordered set where queryId = &#63;.
	 *
	 * @param queryId the query ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching query_ attachments
	 * @throws com.jioc.query.NoSuchQuery_AttachmentsException if a matching query_ attachments could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Attachments findByQueryId_Last(long queryId,
		OrderByComparator orderByComparator)
		throws NoSuchQuery_AttachmentsException, SystemException {
		Query_Attachments query_Attachments = fetchByQueryId_Last(queryId,
				orderByComparator);

		if (query_Attachments != null) {
			return query_Attachments;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("queryId=");
		msg.append(queryId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchQuery_AttachmentsException(msg.toString());
	}

	/**
	 * Returns the last query_ attachments in the ordered set where queryId = &#63;.
	 *
	 * @param queryId the query ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching query_ attachments, or <code>null</code> if a matching query_ attachments could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Attachments fetchByQueryId_Last(long queryId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByQueryId(queryId);

		if (count == 0) {
			return null;
		}

		List<Query_Attachments> list = findByQueryId(queryId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the query_ attachmentses before and after the current query_ attachments in the ordered set where queryId = &#63;.
	 *
	 * @param AttachmentId the primary key of the current query_ attachments
	 * @param queryId the query ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next query_ attachments
	 * @throws com.jioc.query.NoSuchQuery_AttachmentsException if a query_ attachments with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Attachments[] findByQueryId_PrevAndNext(long AttachmentId,
		long queryId, OrderByComparator orderByComparator)
		throws NoSuchQuery_AttachmentsException, SystemException {
		Query_Attachments query_Attachments = findByPrimaryKey(AttachmentId);

		Session session = null;

		try {
			session = openSession();

			Query_Attachments[] array = new Query_AttachmentsImpl[3];

			array[0] = getByQueryId_PrevAndNext(session, query_Attachments,
					queryId, orderByComparator, true);

			array[1] = query_Attachments;

			array[2] = getByQueryId_PrevAndNext(session, query_Attachments,
					queryId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected Query_Attachments getByQueryId_PrevAndNext(Session session,
		Query_Attachments query_Attachments, long queryId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_QUERY_ATTACHMENTS_WHERE);

		query.append(_FINDER_COLUMN_QUERYID_QUERYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(Query_AttachmentsModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(queryId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(query_Attachments);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<Query_Attachments> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the query_ attachmentses where queryId = &#63; from the database.
	 *
	 * @param queryId the query ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByQueryId(long queryId) throws SystemException {
		for (Query_Attachments query_Attachments : findByQueryId(queryId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(query_Attachments);
		}
	}

	/**
	 * Returns the number of query_ attachmentses where queryId = &#63;.
	 *
	 * @param queryId the query ID
	 * @return the number of matching query_ attachmentses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByQueryId(long queryId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_QUERYID;

		Object[] finderArgs = new Object[] { queryId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_QUERY_ATTACHMENTS_WHERE);

			query.append(_FINDER_COLUMN_QUERYID_QUERYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(queryId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_QUERYID_QUERYID_2 = "query_Attachments.queryId = ?";
	public static final FinderPath FINDER_PATH_FETCH_BY_QUERYBYQUERYIDANDFILEENTRYID =
		new FinderPath(Query_AttachmentsModelImpl.ENTITY_CACHE_ENABLED,
			Query_AttachmentsModelImpl.FINDER_CACHE_ENABLED,
			Query_AttachmentsImpl.class, FINDER_CLASS_NAME_ENTITY,
			"fetchByQueryByQueryIdAndFileEntryId",
			new String[] { Long.class.getName(), Long.class.getName() },
			Query_AttachmentsModelImpl.QUERYID_COLUMN_BITMASK |
			Query_AttachmentsModelImpl.FILEENTRYID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_QUERYBYQUERYIDANDFILEENTRYID =
		new FinderPath(Query_AttachmentsModelImpl.ENTITY_CACHE_ENABLED,
			Query_AttachmentsModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByQueryByQueryIdAndFileEntryId",
			new String[] { Long.class.getName(), Long.class.getName() });

	/**
	 * Returns the query_ attachments where queryId = &#63; and fileEntryId = &#63; or throws a {@link com.jioc.query.NoSuchQuery_AttachmentsException} if it could not be found.
	 *
	 * @param queryId the query ID
	 * @param fileEntryId the file entry ID
	 * @return the matching query_ attachments
	 * @throws com.jioc.query.NoSuchQuery_AttachmentsException if a matching query_ attachments could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Attachments findByQueryByQueryIdAndFileEntryId(long queryId,
		long fileEntryId)
		throws NoSuchQuery_AttachmentsException, SystemException {
		Query_Attachments query_Attachments = fetchByQueryByQueryIdAndFileEntryId(queryId,
				fileEntryId);

		if (query_Attachments == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("queryId=");
			msg.append(queryId);

			msg.append(", fileEntryId=");
			msg.append(fileEntryId);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchQuery_AttachmentsException(msg.toString());
		}

		return query_Attachments;
	}

	/**
	 * Returns the query_ attachments where queryId = &#63; and fileEntryId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param queryId the query ID
	 * @param fileEntryId the file entry ID
	 * @return the matching query_ attachments, or <code>null</code> if a matching query_ attachments could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Attachments fetchByQueryByQueryIdAndFileEntryId(long queryId,
		long fileEntryId) throws SystemException {
		return fetchByQueryByQueryIdAndFileEntryId(queryId, fileEntryId, true);
	}

	/**
	 * Returns the query_ attachments where queryId = &#63; and fileEntryId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param queryId the query ID
	 * @param fileEntryId the file entry ID
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching query_ attachments, or <code>null</code> if a matching query_ attachments could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Attachments fetchByQueryByQueryIdAndFileEntryId(long queryId,
		long fileEntryId, boolean retrieveFromCache) throws SystemException {
		Object[] finderArgs = new Object[] { queryId, fileEntryId };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_QUERYBYQUERYIDANDFILEENTRYID,
					finderArgs, this);
		}

		if (result instanceof Query_Attachments) {
			Query_Attachments query_Attachments = (Query_Attachments)result;

			if ((queryId != query_Attachments.getQueryId()) ||
					(fileEntryId != query_Attachments.getFileEntryId())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_QUERY_ATTACHMENTS_WHERE);

			query.append(_FINDER_COLUMN_QUERYBYQUERYIDANDFILEENTRYID_QUERYID_2);

			query.append(_FINDER_COLUMN_QUERYBYQUERYIDANDFILEENTRYID_FILEENTRYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(queryId);

				qPos.add(fileEntryId);

				List<Query_Attachments> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_QUERYBYQUERYIDANDFILEENTRYID,
						finderArgs, list);
				}
				else {
					if ((list.size() > 1) && _log.isWarnEnabled()) {
						_log.warn(
							"Query_AttachmentsPersistenceImpl.fetchByQueryByQueryIdAndFileEntryId(long, long, boolean) with parameters (" +
							StringUtil.merge(finderArgs) +
							") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
					}

					Query_Attachments query_Attachments = list.get(0);

					result = query_Attachments;

					cacheResult(query_Attachments);

					if ((query_Attachments.getQueryId() != queryId) ||
							(query_Attachments.getFileEntryId() != fileEntryId)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_QUERYBYQUERYIDANDFILEENTRYID,
							finderArgs, query_Attachments);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_QUERYBYQUERYIDANDFILEENTRYID,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (Query_Attachments)result;
		}
	}

	/**
	 * Removes the query_ attachments where queryId = &#63; and fileEntryId = &#63; from the database.
	 *
	 * @param queryId the query ID
	 * @param fileEntryId the file entry ID
	 * @return the query_ attachments that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Attachments removeByQueryByQueryIdAndFileEntryId(
		long queryId, long fileEntryId)
		throws NoSuchQuery_AttachmentsException, SystemException {
		Query_Attachments query_Attachments = findByQueryByQueryIdAndFileEntryId(queryId,
				fileEntryId);

		return remove(query_Attachments);
	}

	/**
	 * Returns the number of query_ attachmentses where queryId = &#63; and fileEntryId = &#63;.
	 *
	 * @param queryId the query ID
	 * @param fileEntryId the file entry ID
	 * @return the number of matching query_ attachmentses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByQueryByQueryIdAndFileEntryId(long queryId,
		long fileEntryId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_QUERYBYQUERYIDANDFILEENTRYID;

		Object[] finderArgs = new Object[] { queryId, fileEntryId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_QUERY_ATTACHMENTS_WHERE);

			query.append(_FINDER_COLUMN_QUERYBYQUERYIDANDFILEENTRYID_QUERYID_2);

			query.append(_FINDER_COLUMN_QUERYBYQUERYIDANDFILEENTRYID_FILEENTRYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(queryId);

				qPos.add(fileEntryId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_QUERYBYQUERYIDANDFILEENTRYID_QUERYID_2 =
		"query_Attachments.queryId = ? AND ";
	private static final String _FINDER_COLUMN_QUERYBYQUERYIDANDFILEENTRYID_FILEENTRYID_2 =
		"query_Attachments.fileEntryId = ?";

	public Query_AttachmentsPersistenceImpl() {
		setModelClass(Query_Attachments.class);
	}

	/**
	 * Caches the query_ attachments in the entity cache if it is enabled.
	 *
	 * @param query_Attachments the query_ attachments
	 */
	@Override
	public void cacheResult(Query_Attachments query_Attachments) {
		EntityCacheUtil.putResult(Query_AttachmentsModelImpl.ENTITY_CACHE_ENABLED,
			Query_AttachmentsImpl.class, query_Attachments.getPrimaryKey(),
			query_Attachments);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_QUERYBYQUERYIDANDFILEENTRYID,
			new Object[] {
				query_Attachments.getQueryId(),
				query_Attachments.getFileEntryId()
			}, query_Attachments);

		query_Attachments.resetOriginalValues();
	}

	/**
	 * Caches the query_ attachmentses in the entity cache if it is enabled.
	 *
	 * @param query_Attachmentses the query_ attachmentses
	 */
	@Override
	public void cacheResult(List<Query_Attachments> query_Attachmentses) {
		for (Query_Attachments query_Attachments : query_Attachmentses) {
			if (EntityCacheUtil.getResult(
						Query_AttachmentsModelImpl.ENTITY_CACHE_ENABLED,
						Query_AttachmentsImpl.class,
						query_Attachments.getPrimaryKey()) == null) {
				cacheResult(query_Attachments);
			}
			else {
				query_Attachments.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all query_ attachmentses.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(Query_AttachmentsImpl.class.getName());
		}

		EntityCacheUtil.clearCache(Query_AttachmentsImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the query_ attachments.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(Query_Attachments query_Attachments) {
		EntityCacheUtil.removeResult(Query_AttachmentsModelImpl.ENTITY_CACHE_ENABLED,
			Query_AttachmentsImpl.class, query_Attachments.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache(query_Attachments);
	}

	@Override
	public void clearCache(List<Query_Attachments> query_Attachmentses) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (Query_Attachments query_Attachments : query_Attachmentses) {
			EntityCacheUtil.removeResult(Query_AttachmentsModelImpl.ENTITY_CACHE_ENABLED,
				Query_AttachmentsImpl.class, query_Attachments.getPrimaryKey());

			clearUniqueFindersCache(query_Attachments);
		}
	}

	protected void cacheUniqueFindersCache(Query_Attachments query_Attachments) {
		if (query_Attachments.isNew()) {
			Object[] args = new Object[] {
					query_Attachments.getQueryId(),
					query_Attachments.getFileEntryId()
				};

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_QUERYBYQUERYIDANDFILEENTRYID,
				args, Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_QUERYBYQUERYIDANDFILEENTRYID,
				args, query_Attachments);
		}
		else {
			Query_AttachmentsModelImpl query_AttachmentsModelImpl = (Query_AttachmentsModelImpl)query_Attachments;

			if ((query_AttachmentsModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_QUERYBYQUERYIDANDFILEENTRYID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						query_Attachments.getQueryId(),
						query_Attachments.getFileEntryId()
					};

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_QUERYBYQUERYIDANDFILEENTRYID,
					args, Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_QUERYBYQUERYIDANDFILEENTRYID,
					args, query_Attachments);
			}
		}
	}

	protected void clearUniqueFindersCache(Query_Attachments query_Attachments) {
		Query_AttachmentsModelImpl query_AttachmentsModelImpl = (Query_AttachmentsModelImpl)query_Attachments;

		Object[] args = new Object[] {
				query_Attachments.getQueryId(),
				query_Attachments.getFileEntryId()
			};

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_QUERYBYQUERYIDANDFILEENTRYID,
			args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_QUERYBYQUERYIDANDFILEENTRYID,
			args);

		if ((query_AttachmentsModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_QUERYBYQUERYIDANDFILEENTRYID.getColumnBitmask()) != 0) {
			args = new Object[] {
					query_AttachmentsModelImpl.getOriginalQueryId(),
					query_AttachmentsModelImpl.getOriginalFileEntryId()
				};

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_QUERYBYQUERYIDANDFILEENTRYID,
				args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_QUERYBYQUERYIDANDFILEENTRYID,
				args);
		}
	}

	/**
	 * Creates a new query_ attachments with the primary key. Does not add the query_ attachments to the database.
	 *
	 * @param AttachmentId the primary key for the new query_ attachments
	 * @return the new query_ attachments
	 */
	@Override
	public Query_Attachments create(long AttachmentId) {
		Query_Attachments query_Attachments = new Query_AttachmentsImpl();

		query_Attachments.setNew(true);
		query_Attachments.setPrimaryKey(AttachmentId);

		return query_Attachments;
	}

	/**
	 * Removes the query_ attachments with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param AttachmentId the primary key of the query_ attachments
	 * @return the query_ attachments that was removed
	 * @throws com.jioc.query.NoSuchQuery_AttachmentsException if a query_ attachments with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Attachments remove(long AttachmentId)
		throws NoSuchQuery_AttachmentsException, SystemException {
		return remove((Serializable)AttachmentId);
	}

	/**
	 * Removes the query_ attachments with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the query_ attachments
	 * @return the query_ attachments that was removed
	 * @throws com.jioc.query.NoSuchQuery_AttachmentsException if a query_ attachments with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Attachments remove(Serializable primaryKey)
		throws NoSuchQuery_AttachmentsException, SystemException {
		Session session = null;

		try {
			session = openSession();

			Query_Attachments query_Attachments = (Query_Attachments)session.get(Query_AttachmentsImpl.class,
					primaryKey);

			if (query_Attachments == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchQuery_AttachmentsException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(query_Attachments);
		}
		catch (NoSuchQuery_AttachmentsException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected Query_Attachments removeImpl(Query_Attachments query_Attachments)
		throws SystemException {
		query_Attachments = toUnwrappedModel(query_Attachments);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(query_Attachments)) {
				query_Attachments = (Query_Attachments)session.get(Query_AttachmentsImpl.class,
						query_Attachments.getPrimaryKeyObj());
			}

			if (query_Attachments != null) {
				session.delete(query_Attachments);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (query_Attachments != null) {
			clearCache(query_Attachments);
		}

		return query_Attachments;
	}

	@Override
	public Query_Attachments updateImpl(
		com.jioc.query.model.Query_Attachments query_Attachments)
		throws SystemException {
		query_Attachments = toUnwrappedModel(query_Attachments);

		boolean isNew = query_Attachments.isNew();

		Query_AttachmentsModelImpl query_AttachmentsModelImpl = (Query_AttachmentsModelImpl)query_Attachments;

		Session session = null;

		try {
			session = openSession();

			if (query_Attachments.isNew()) {
				session.save(query_Attachments);

				query_Attachments.setNew(false);
			}
			else {
				session.merge(query_Attachments);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !Query_AttachmentsModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((query_AttachmentsModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_QUERYID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						query_AttachmentsModelImpl.getOriginalQueryId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_QUERYID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_QUERYID,
					args);

				args = new Object[] { query_AttachmentsModelImpl.getQueryId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_QUERYID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_QUERYID,
					args);
			}
		}

		EntityCacheUtil.putResult(Query_AttachmentsModelImpl.ENTITY_CACHE_ENABLED,
			Query_AttachmentsImpl.class, query_Attachments.getPrimaryKey(),
			query_Attachments);

		clearUniqueFindersCache(query_Attachments);
		cacheUniqueFindersCache(query_Attachments);

		return query_Attachments;
	}

	protected Query_Attachments toUnwrappedModel(
		Query_Attachments query_Attachments) {
		if (query_Attachments instanceof Query_AttachmentsImpl) {
			return query_Attachments;
		}

		Query_AttachmentsImpl query_AttachmentsImpl = new Query_AttachmentsImpl();

		query_AttachmentsImpl.setNew(query_Attachments.isNew());
		query_AttachmentsImpl.setPrimaryKey(query_Attachments.getPrimaryKey());

		query_AttachmentsImpl.setAttachmentId(query_Attachments.getAttachmentId());
		query_AttachmentsImpl.setFileEntryId(query_Attachments.getFileEntryId());
		query_AttachmentsImpl.setUpdatedBy(query_Attachments.getUpdatedBy());
		query_AttachmentsImpl.setUpdatedTimestamp(query_Attachments.getUpdatedTimestamp());
		query_AttachmentsImpl.setQueryId(query_Attachments.getQueryId());
		query_AttachmentsImpl.setFile_name(query_Attachments.getFile_name());

		return query_AttachmentsImpl;
	}

	/**
	 * Returns the query_ attachments with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the query_ attachments
	 * @return the query_ attachments
	 * @throws com.jioc.query.NoSuchQuery_AttachmentsException if a query_ attachments with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Attachments findByPrimaryKey(Serializable primaryKey)
		throws NoSuchQuery_AttachmentsException, SystemException {
		Query_Attachments query_Attachments = fetchByPrimaryKey(primaryKey);

		if (query_Attachments == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchQuery_AttachmentsException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return query_Attachments;
	}

	/**
	 * Returns the query_ attachments with the primary key or throws a {@link com.jioc.query.NoSuchQuery_AttachmentsException} if it could not be found.
	 *
	 * @param AttachmentId the primary key of the query_ attachments
	 * @return the query_ attachments
	 * @throws com.jioc.query.NoSuchQuery_AttachmentsException if a query_ attachments with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Attachments findByPrimaryKey(long AttachmentId)
		throws NoSuchQuery_AttachmentsException, SystemException {
		return findByPrimaryKey((Serializable)AttachmentId);
	}

	/**
	 * Returns the query_ attachments with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the query_ attachments
	 * @return the query_ attachments, or <code>null</code> if a query_ attachments with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Attachments fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		Query_Attachments query_Attachments = (Query_Attachments)EntityCacheUtil.getResult(Query_AttachmentsModelImpl.ENTITY_CACHE_ENABLED,
				Query_AttachmentsImpl.class, primaryKey);

		if (query_Attachments == _nullQuery_Attachments) {
			return null;
		}

		if (query_Attachments == null) {
			Session session = null;

			try {
				session = openSession();

				query_Attachments = (Query_Attachments)session.get(Query_AttachmentsImpl.class,
						primaryKey);

				if (query_Attachments != null) {
					cacheResult(query_Attachments);
				}
				else {
					EntityCacheUtil.putResult(Query_AttachmentsModelImpl.ENTITY_CACHE_ENABLED,
						Query_AttachmentsImpl.class, primaryKey,
						_nullQuery_Attachments);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(Query_AttachmentsModelImpl.ENTITY_CACHE_ENABLED,
					Query_AttachmentsImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return query_Attachments;
	}

	/**
	 * Returns the query_ attachments with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param AttachmentId the primary key of the query_ attachments
	 * @return the query_ attachments, or <code>null</code> if a query_ attachments with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public Query_Attachments fetchByPrimaryKey(long AttachmentId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)AttachmentId);
	}

	/**
	 * Returns all the query_ attachmentses.
	 *
	 * @return the query_ attachmentses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Attachments> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the query_ attachmentses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_AttachmentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of query_ attachmentses
	 * @param end the upper bound of the range of query_ attachmentses (not inclusive)
	 * @return the range of query_ attachmentses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Attachments> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the query_ attachmentses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_AttachmentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of query_ attachmentses
	 * @param end the upper bound of the range of query_ attachmentses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of query_ attachmentses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<Query_Attachments> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<Query_Attachments> list = (List<Query_Attachments>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_QUERY_ATTACHMENTS);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_QUERY_ATTACHMENTS;

				if (pagination) {
					sql = sql.concat(Query_AttachmentsModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<Query_Attachments>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<Query_Attachments>(list);
				}
				else {
					list = (List<Query_Attachments>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the query_ attachmentses from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (Query_Attachments query_Attachments : findAll()) {
			remove(query_Attachments);
		}
	}

	/**
	 * Returns the number of query_ attachmentses.
	 *
	 * @return the number of query_ attachmentses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_QUERY_ATTACHMENTS);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the query_ attachments persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.jioc.query.model.Query_Attachments")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<Query_Attachments>> listenersList = new ArrayList<ModelListener<Query_Attachments>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<Query_Attachments>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(Query_AttachmentsImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_QUERY_ATTACHMENTS = "SELECT query_Attachments FROM Query_Attachments query_Attachments";
	private static final String _SQL_SELECT_QUERY_ATTACHMENTS_WHERE = "SELECT query_Attachments FROM Query_Attachments query_Attachments WHERE ";
	private static final String _SQL_COUNT_QUERY_ATTACHMENTS = "SELECT COUNT(query_Attachments) FROM Query_Attachments query_Attachments";
	private static final String _SQL_COUNT_QUERY_ATTACHMENTS_WHERE = "SELECT COUNT(query_Attachments) FROM Query_Attachments query_Attachments WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "query_Attachments.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No Query_Attachments exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No Query_Attachments exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(Query_AttachmentsPersistenceImpl.class);
	private static Query_Attachments _nullQuery_Attachments = new Query_AttachmentsImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<Query_Attachments> toCacheModel() {
				return _nullQuery_AttachmentsCacheModel;
			}
		};

	private static CacheModel<Query_Attachments> _nullQuery_AttachmentsCacheModel =
		new CacheModel<Query_Attachments>() {
			@Override
			public Query_Attachments toEntityModel() {
				return _nullQuery_Attachments;
			}
		};
}