/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model.impl;

import com.jioc.query.model.OC_SUB_CAT_MST;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing OC_SUB_CAT_MST in entity cache.
 *
 * @author shantaram.chavan
 * @see OC_SUB_CAT_MST
 * @generated
 */
public class OC_SUB_CAT_MSTCacheModel implements CacheModel<OC_SUB_CAT_MST>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{SUB_CAT_ID=");
		sb.append(SUB_CAT_ID);
		sb.append(", CAT_ID=");
		sb.append(CAT_ID);
		sb.append(", IS_ACTIVE=");
		sb.append(IS_ACTIVE);
		sb.append(", SUB_CAT_NAME=");
		sb.append(SUB_CAT_NAME);
		sb.append(", UPDATED_TIMESTAMP=");
		sb.append(UPDATED_TIMESTAMP);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public OC_SUB_CAT_MST toEntityModel() {
		OC_SUB_CAT_MSTImpl oc_sub_cat_mstImpl = new OC_SUB_CAT_MSTImpl();

		oc_sub_cat_mstImpl.setSUB_CAT_ID(SUB_CAT_ID);
		oc_sub_cat_mstImpl.setCAT_ID(CAT_ID);
		oc_sub_cat_mstImpl.setIS_ACTIVE(IS_ACTIVE);

		if (SUB_CAT_NAME == null) {
			oc_sub_cat_mstImpl.setSUB_CAT_NAME(StringPool.BLANK);
		}
		else {
			oc_sub_cat_mstImpl.setSUB_CAT_NAME(SUB_CAT_NAME);
		}

		if (UPDATED_TIMESTAMP == Long.MIN_VALUE) {
			oc_sub_cat_mstImpl.setUPDATED_TIMESTAMP(null);
		}
		else {
			oc_sub_cat_mstImpl.setUPDATED_TIMESTAMP(new Date(UPDATED_TIMESTAMP));
		}

		oc_sub_cat_mstImpl.resetOriginalValues();

		return oc_sub_cat_mstImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		SUB_CAT_ID = objectInput.readLong();
		CAT_ID = objectInput.readLong();
		IS_ACTIVE = objectInput.readInt();
		SUB_CAT_NAME = objectInput.readUTF();
		UPDATED_TIMESTAMP = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(SUB_CAT_ID);
		objectOutput.writeLong(CAT_ID);
		objectOutput.writeInt(IS_ACTIVE);

		if (SUB_CAT_NAME == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(SUB_CAT_NAME);
		}

		objectOutput.writeLong(UPDATED_TIMESTAMP);
	}

	public long SUB_CAT_ID;
	public long CAT_ID;
	public int IS_ACTIVE;
	public String SUB_CAT_NAME;
	public long UPDATED_TIMESTAMP;
}