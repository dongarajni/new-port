/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.impl;

import com.jioc.query.model.Query_Transaction;
import com.jioc.query.service.base.Query_TransactionLocalServiceBaseImpl;
import com.jioc.util.QueryConstants;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.SQLQuery;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.util.portlet.PortletProps;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * The implementation of the query_ transaction local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jioc.query.service.Query_TransactionLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author shantaram.chavan
 * @see com.jioc.query.service.base.Query_TransactionLocalServiceBaseImpl
 * @see com.jioc.query.service.Query_TransactionLocalServiceUtil
 */
public class Query_TransactionLocalServiceImpl extends Query_TransactionLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.jioc.query.service.Query_TransactionLocalServiceUtil} to access the query_ transaction local service.
	 */
	
	private static Log LOGGER = LogFactoryUtil.getLog(Query_TransactionLocalServiceImpl.class.getName());
	
	public List<Object[]> findQueryTransactionByRaisedById(long raisedById){
		try {
			//return query_TransactionPersistence.findByRaisedById(raisedById);
			
			Session session = query_TransactionPersistence.openSession(); 
			SQLQuery query = session.createSQLQuery("select * from jioc_query_transaction qt inner join (select qd.* from jioc_query_details qd inner join (select queryId, max(updatedTimestamp) as updatedTimestamp from jioc_query_details group by queryId) qdu on qd.queryId = qdu.queryId and qd.updatedTimestamp = qdu.updatedTimestamp) qdup on qt.queryId = qdup.queryId where qt.raisedById=? order by qt.raisedtimestamp desc"); 
			QueryPos pos = QueryPos.getInstance(query); 
			pos.add(raisedById); 
			return query.list();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public List<Object[]> findQueryTransactionByRaisedByIdAndDate(long raisedById, String fromDate, String toDate){
		try {
			//return query_TransactionPersistence.findByRaisedById(raisedById);
			String queryStr = null;
			boolean ignoreDate = false;
			if(Validator.isNull(fromDate) || Validator.isNull(toDate) || "".equals(fromDate) || "".equals(toDate)){
				ignoreDate = true;
			}
			
			//System.out.println("raisedById:"+raisedById+" fromDate:"+fromDate+" toDate:"+toDate);
			
			
			if(ignoreDate){
				queryStr = "select qt.queryid, caseno, description, raisedtimestamp, querydetailsid, assignedto, status, action from jioc_query_transaction qt inner join (select qd.* from jioc_query_details qd inner join (select queryId, max(updatedTimestamp) as updatedTimestamp from jioc_query_details group by queryId) qdu on qd.queryId = qdu.queryId and qd.updatedTimestamp = qdu.updatedTimestamp) qdup on qt.queryId = qdup.queryId where qt.raisedById=? and qt.isactive=1 order by qt.raisedtimestamp desc";
			}else{
				SimpleDateFormat inputFormat = new SimpleDateFormat(PortletProps.get(QueryConstants.PROP_COMMON_DATE_FORMAT_INPUT));
				SimpleDateFormat outputFormat = new SimpleDateFormat(PortletProps.get(QueryConstants.PROP_COMMON_DATE_FORMAT_OUTPUT));
				
				fromDate = outputFormat.format(inputFormat.parse(fromDate));
				toDate = outputFormat.format(inputFormat.parse(toDate));
				
				queryStr = "select qt.queryid, caseno, description, raisedtimestamp, querydetailsid, assignedto, status, action from jioc_query_transaction qt inner join (select qd.* from jioc_query_details qd inner join (select queryId, max(updatedTimestamp) as updatedTimestamp from jioc_query_details group by queryId) qdu on qd.queryId = qdu.queryId and qd.updatedTimestamp = qdu.updatedTimestamp) qdup on qt.queryId = qdup.queryId where qt.raisedById=? and qt.isactive=1 and ((to_char(qt.raisedTimestamp,'dd-mm-yy')>=? and to_char(qt.raisedTimestamp,'dd-mm-yy')<=?) or (to_char(qt.raisedTimestamp,'dd-mm-yy')=? or to_char(qt.raisedTimestamp,'dd-mm-yy')=?)) order by qt.raisedtimestamp desc";
			}
			
			Session session = query_TransactionPersistence.openSession(); 
			SQLQuery query = session.createSQLQuery(queryStr); 
			QueryPos pos = QueryPos.getInstance(query); 
			pos.add(raisedById);
			if(!ignoreDate){
				pos.add(fromDate);
				pos.add(toDate);
				pos.add(fromDate);
				pos.add(toDate);
			}
			return query.list();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public List<Object[]> findQueryTransactionByRaisedByIdStatusAndDate(long raisedById, String status, String fromDate, String toDate){
		try {
			String queryStr = null;
			boolean ignoreDate = false;
			if(Validator.isNull(fromDate) || Validator.isNull(toDate) || "".equals(fromDate) || "".equals(toDate)){
				ignoreDate = true;
			}
			//System.out.println("fromDate:"+fromDate+" toDate:"+toDate+" ignoreDate:"+ignoreDate);
			
			if(ignoreDate){
				//queryStr = "select * from jioc_query_transaction qt inner join (select qd.* from jioc_query_details qd inner join (select queryId, max(updatedTimestamp) as updatedTimestamp from jioc_query_details group by queryId) qdu on qd.queryId = qdu.queryId and qd.updatedTimestamp = qdu.updatedTimestamp where qd.status=?) qdup on qt.queryId = qdup.queryId where qt.raisedById=?";
				queryStr = "select qt.queryid, caseno, description, raisedtimestamp, querydetailsid, assignedto, status, action from jioc_query_transaction qt inner join (select qd.* from jioc_query_details qd inner join (select queryId, max(updatedTimestamp) as updatedTimestamp from jioc_query_details group by queryId) qdu on qd.queryId = qdu.queryId and qd.updatedTimestamp = qdu.updatedTimestamp where qd.status=?) qdup on qt.queryId = qdup.queryId where qt.raisedById=? and qt.isactive=1 order by qt.raisedtimestamp desc";
			}else{
				//queryStr = "select * from jioc_query_transaction qt inner join (select qd.* from jioc_query_details qd inner join (select queryId, max(updatedTimestamp) as updatedTimestamp from jioc_query_details group by queryId) qdu on qd.queryId = qdu.queryId and qd.updatedTimestamp = qdu.updatedTimestamp where qd.status=?) qdup on qt.queryId = qdup.queryId where qt.raisedById=? and qt.raisedTimestamp>=? and qt.raisedTimestamp<=?";
				SimpleDateFormat inputFormat = new SimpleDateFormat(PortletProps.get(QueryConstants.PROP_COMMON_DATE_FORMAT_INPUT));
				SimpleDateFormat outputFormat = new SimpleDateFormat(PortletProps.get(QueryConstants.PROP_COMMON_DATE_FORMAT_OUTPUT));
				
				fromDate = outputFormat.format(inputFormat.parse(fromDate));
				toDate = outputFormat.format(inputFormat.parse(toDate));
				
				//queryStr = "select qt.queryid, caseno, description, raisedtimestamp, querydetailsid, assignedto, status, action from jioc_query_transaction qt inner join (select qd.* from jioc_query_details qd inner join (select queryId, max(updatedTimestamp) as updatedTimestamp from jioc_query_details group by queryId) qdu on qd.queryId = qdu.queryId and qd.updatedTimestamp = qdu.updatedTimestamp where qd.status=?) qdup on qt.queryId = qdup.queryId where qt.raisedById=? and qt.raisedTimestamp>=? and qt.raisedTimestamp<=?";
				queryStr = "select qt.queryid, caseno, description, raisedtimestamp, querydetailsid, assignedto, status, action from jioc_query_transaction qt inner join (select qd.* from jioc_query_details qd inner join (select queryId, max(updatedTimestamp) as updatedTimestamp from jioc_query_details group by queryId) qdu on qd.queryId = qdu.queryId and qd.updatedTimestamp = qdu.updatedTimestamp where qd.status=?) qdup on qt.queryId = qdup.queryId where qt.raisedById=? and qt.isactive=1 and ((to_char(qt.raisedTimestamp,'dd-mm-yy')>=? and to_char(qt.raisedTimestamp,'dd-mm-yy')<=?) or (to_char(qt.raisedTimestamp,'dd-mm-yy')=? or to_char(qt.raisedTimestamp,'dd-mm-yy')=?)) order by qt.raisedtimestamp desc";
			}
			
			Session session = query_TransactionPersistence.openSession(); 
			SQLQuery query = session.createSQLQuery(queryStr); 
			QueryPos pos = QueryPos.getInstance(query);
			pos.add(status);
			pos.add(raisedById);
			if(!ignoreDate){
				pos.add(fromDate);
				pos.add(toDate);
				pos.add(fromDate);
				pos.add(toDate);
			}
			return query.list();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public List<Object[]> findQueryTransactionByRaisedByIdActionAndDate(long raisedById, String action, String fromDate, String toDate){
		try {
			String queryStr = null;
			boolean ignoreDate = false;
			if(Validator.isNull(fromDate) || Validator.isNull(toDate) || "".equals(fromDate) || "".equals(toDate)){
				ignoreDate = true;
			}
			//System.out.println("fromDate:"+fromDate+" toDate:"+toDate+" ignoreDate:"+ignoreDate);
			
			if(ignoreDate){
				//queryStr = "select * from jioc_query_transaction qt inner join (select qd.* from jioc_query_details qd inner join (select queryId, max(updatedTimestamp) as updatedTimestamp from jioc_query_details group by queryId) qdu on qd.queryId = qdu.queryId and qd.updatedTimestamp = qdu.updatedTimestamp where qd.status=?) qdup on qt.queryId = qdup.queryId where qt.raisedById=?";
				queryStr = "select qt.queryid, caseno, description, raisedtimestamp, querydetailsid, assignedto, status, action from jioc_query_transaction qt inner join (select qd.* from jioc_query_details qd inner join (select queryId, max(updatedTimestamp) as updatedTimestamp from jioc_query_details group by queryId) qdu on qd.queryId = qdu.queryId and qd.updatedTimestamp = qdu.updatedTimestamp where qd.action=?) qdup on qt.queryId = qdup.queryId where qt.raisedById=? and qt.isactive=1 order by qt.raisedtimestamp desc";
			}else{
				//queryStr = "select * from jioc_query_transaction qt inner join (select qd.* from jioc_query_details qd inner join (select queryId, max(updatedTimestamp) as updatedTimestamp from jioc_query_details group by queryId) qdu on qd.queryId = qdu.queryId and qd.updatedTimestamp = qdu.updatedTimestamp where qd.status=?) qdup on qt.queryId = qdup.queryId where qt.raisedById=? and qt.raisedTimestamp>=? and qt.raisedTimestamp<=?";
				SimpleDateFormat inputFormat = new SimpleDateFormat(PortletProps.get(QueryConstants.PROP_COMMON_DATE_FORMAT_INPUT));
				SimpleDateFormat outputFormat = new SimpleDateFormat(PortletProps.get(QueryConstants.PROP_COMMON_DATE_FORMAT_OUTPUT));
				
				fromDate = outputFormat.format(inputFormat.parse(fromDate));
				toDate = outputFormat.format(inputFormat.parse(toDate));
				
				//queryStr = "select qt.queryid, caseno, description, raisedtimestamp, querydetailsid, assignedto, status, action from jioc_query_transaction qt inner join (select qd.* from jioc_query_details qd inner join (select queryId, max(updatedTimestamp) as updatedTimestamp from jioc_query_details group by queryId) qdu on qd.queryId = qdu.queryId and qd.updatedTimestamp = qdu.updatedTimestamp where qd.status=?) qdup on qt.queryId = qdup.queryId where qt.raisedById=? and qt.raisedTimestamp>=? and qt.raisedTimestamp<=?";
				queryStr = "select qt.queryid, caseno, description, raisedtimestamp, querydetailsid, assignedto, status, action from jioc_query_transaction qt inner join (select qd.* from jioc_query_details qd inner join (select queryId, max(updatedTimestamp) as updatedTimestamp from jioc_query_details group by queryId) qdu on qd.queryId = qdu.queryId and qd.updatedTimestamp = qdu.updatedTimestamp where qd.action=?) qdup on qt.queryId = qdup.queryId where qt.raisedById=? and qt.isactive=1 and ((to_char(qt.raisedTimestamp,'dd-mm-yy')>=? and to_char(qt.raisedTimestamp,'dd-mm-yy')<=?) or (to_char(qt.raisedTimestamp,'dd-mm-yy')=? or to_char(qt.raisedTimestamp,'dd-mm-yy')=?)) order by qt.raisedtimestamp desc";
			}
			
			Session session = query_TransactionPersistence.openSession(); 
			SQLQuery query = session.createSQLQuery(queryStr); 
			QueryPos pos = QueryPos.getInstance(query);
			pos.add(action);
			pos.add(raisedById);
			if(!ignoreDate){
				pos.add(fromDate);
				pos.add(toDate);
				pos.add(fromDate);
				pos.add(toDate);
			}
			return query.list();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public List<Object[]> findQueryTransactionByRaisedByIdStatus(long raisedById, String status){
		try {
			Session session = query_TransactionPersistence.openSession(); 
			SQLQuery query = session.createSQLQuery("select qt.queryid, caseno, description, raisedtimestamp, querydetailsid, assignedto, status, action from jioc_query_transaction qt inner join (select qd.* from jioc_query_details qd inner join (select queryId, max(updatedTimestamp) as updatedTimestamp from jioc_query_details group by queryId) qdu on qd.queryId = qdu.queryId and qd.updatedTimestamp = qdu.updatedTimestamp where qd.status=?) qdup on qt.queryId = qdup.queryId where qt.raisedById=? and qt.isactive=1 order by qt.raisedtimestamp desc"); 
			QueryPos pos = QueryPos.getInstance(query);
			pos.add(status);
			pos.add(raisedById);
			return query.list();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public Query_Transaction findQueryTransactionByPCId(String pcId){
		List<Query_Transaction> queryTransactionList = null;
		
		try{
			queryTransactionList = query_TransactionPersistence.findByPCId(pcId);
			if(Validator.isNotNull(queryTransactionList) && queryTransactionList.size() > 0){
				return queryTransactionList.get(0);
			}
			
		}catch(Exception e){
			LOGGER.error("Exception while finding QueryTransaction by PCId " + e.getMessage());
		}
		
		return null;
	}
	
	public List<Object[]> getCaseResolutionComments(long queryId){
		try {
			Session session = query_TransactionPersistence.openSession(); 
			//SQLQuery query = session.createSQLQuery("select a.queryid, b.comment_ as Resolution_Text, max(updatedtimestamp) as Upd_Time from jioc_query_transaction a left join jioc_query_details b on a.queryid = b.queryid where a.queryid=? and action = 'RESOLVE' group by a.queryid, b.comment_");
			//SQLQuery query = session.createSQLQuery("select a.queryid, action, b.comment_ as Resolution_Text, max(updatedtimestamp) as Upd_Time from jioc_query_transaction a left join jioc_query_details b on a.queryid = b.queryid where a.queryid = ? and action in ('RESOLVE' , 'REOPEN', 'ESCALATE') group by a.queryid, action, b.comment_");
			SQLQuery query = session.createSQLQuery("select queryid, action, comment_ as Resolution_Text, max(updatedtimestamp) as Upd_Time from jioc_query_details a where queryid = ? and action in ('RESOLVE' , 'REOPEN', 'ESCALATE') and updatedtimestamp in (select max(updatedtimestamp) as Upd_Time from jioc_query_details b where a.queryid = b.queryid group by b.queryid, b.action) group by queryid, action, comment_");
			QueryPos pos = QueryPos.getInstance(query);
			pos.add(queryId);
			return query.list();
			
		} catch (Exception e) {
			LOGGER.error("Exception while fetching case resolution comments " + e.getMessage());
		}
		
		return null;
	}
}