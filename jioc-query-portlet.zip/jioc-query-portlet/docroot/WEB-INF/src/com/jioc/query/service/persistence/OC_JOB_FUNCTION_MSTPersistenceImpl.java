/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException;
import com.jioc.query.model.OC_JOB_FUNCTION_MST;
import com.jioc.query.model.impl.OC_JOB_FUNCTION_MSTImpl;
import com.jioc.query.model.impl.OC_JOB_FUNCTION_MSTModelImpl;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the o c_ j o b_ f u n c t i o n_ m s t service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see OC_JOB_FUNCTION_MSTPersistence
 * @see OC_JOB_FUNCTION_MSTUtil
 * @generated
 */
public class OC_JOB_FUNCTION_MSTPersistenceImpl extends BasePersistenceImpl<OC_JOB_FUNCTION_MST>
	implements OC_JOB_FUNCTION_MSTPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link OC_JOB_FUNCTION_MSTUtil} to access the o c_ j o b_ f u n c t i o n_ m s t persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = OC_JOB_FUNCTION_MSTImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(OC_JOB_FUNCTION_MSTModelImpl.ENTITY_CACHE_ENABLED,
			OC_JOB_FUNCTION_MSTModelImpl.FINDER_CACHE_ENABLED,
			OC_JOB_FUNCTION_MSTImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(OC_JOB_FUNCTION_MSTModelImpl.ENTITY_CACHE_ENABLED,
			OC_JOB_FUNCTION_MSTModelImpl.FINDER_CACHE_ENABLED,
			OC_JOB_FUNCTION_MSTImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(OC_JOB_FUNCTION_MSTModelImpl.ENTITY_CACHE_ENABLED,
			OC_JOB_FUNCTION_MSTModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_AREAJOBFUNCTION =
		new FinderPath(OC_JOB_FUNCTION_MSTModelImpl.ENTITY_CACHE_ENABLED,
			OC_JOB_FUNCTION_MSTModelImpl.FINDER_CACHE_ENABLED,
			OC_JOB_FUNCTION_MSTImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByAreaJobFunction",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_AREAJOBFUNCTION =
		new FinderPath(OC_JOB_FUNCTION_MSTModelImpl.ENTITY_CACHE_ENABLED,
			OC_JOB_FUNCTION_MSTModelImpl.FINDER_CACHE_ENABLED,
			OC_JOB_FUNCTION_MSTImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByAreaJobFunction",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName()
			},
			OC_JOB_FUNCTION_MSTModelImpl.FUNCTIONAL_AREA_COLUMN_BITMASK |
			OC_JOB_FUNCTION_MSTModelImpl.JOB_COLUMN_BITMASK |
			OC_JOB_FUNCTION_MSTModelImpl.SUB_FUNCTIONAL_AREA_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_AREAJOBFUNCTION = new FinderPath(OC_JOB_FUNCTION_MSTModelImpl.ENTITY_CACHE_ENABLED,
			OC_JOB_FUNCTION_MSTModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByAreaJobFunction",
			new String[] {
				String.class.getName(), String.class.getName(),
				String.class.getName()
			});

	/**
	 * Returns all the o c_ j o b_ f u n c t i o n_ m s ts where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	 *
	 * @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	 * @param JOB the j o b
	 * @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	 * @return the matching o c_ j o b_ f u n c t i o n_ m s ts
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<OC_JOB_FUNCTION_MST> findByAreaJobFunction(
		String FUNCTIONAL_AREA, String JOB, String SUB_FUNCTIONAL_AREA)
		throws SystemException {
		return findByAreaJobFunction(FUNCTIONAL_AREA, JOB, SUB_FUNCTIONAL_AREA,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the o c_ j o b_ f u n c t i o n_ m s ts where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.OC_JOB_FUNCTION_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	 * @param JOB the j o b
	 * @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	 * @param start the lower bound of the range of o c_ j o b_ f u n c t i o n_ m s ts
	 * @param end the upper bound of the range of o c_ j o b_ f u n c t i o n_ m s ts (not inclusive)
	 * @return the range of matching o c_ j o b_ f u n c t i o n_ m s ts
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<OC_JOB_FUNCTION_MST> findByAreaJobFunction(
		String FUNCTIONAL_AREA, String JOB, String SUB_FUNCTIONAL_AREA,
		int start, int end) throws SystemException {
		return findByAreaJobFunction(FUNCTIONAL_AREA, JOB, SUB_FUNCTIONAL_AREA,
			start, end, null);
	}

	/**
	 * Returns an ordered range of all the o c_ j o b_ f u n c t i o n_ m s ts where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.OC_JOB_FUNCTION_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	 * @param JOB the j o b
	 * @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	 * @param start the lower bound of the range of o c_ j o b_ f u n c t i o n_ m s ts
	 * @param end the upper bound of the range of o c_ j o b_ f u n c t i o n_ m s ts (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching o c_ j o b_ f u n c t i o n_ m s ts
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<OC_JOB_FUNCTION_MST> findByAreaJobFunction(
		String FUNCTIONAL_AREA, String JOB, String SUB_FUNCTIONAL_AREA,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_AREAJOBFUNCTION;
			finderArgs = new Object[] { FUNCTIONAL_AREA, JOB, SUB_FUNCTIONAL_AREA };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_AREAJOBFUNCTION;
			finderArgs = new Object[] {
					FUNCTIONAL_AREA, JOB, SUB_FUNCTIONAL_AREA,
					
					start, end, orderByComparator
				};
		}

		List<OC_JOB_FUNCTION_MST> list = (List<OC_JOB_FUNCTION_MST>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (OC_JOB_FUNCTION_MST oc_job_function_mst : list) {
				if (!Validator.equals(FUNCTIONAL_AREA,
							oc_job_function_mst.getFUNCTIONAL_AREA()) ||
						!Validator.equals(JOB, oc_job_function_mst.getJOB()) ||
						!Validator.equals(SUB_FUNCTIONAL_AREA,
							oc_job_function_mst.getSUB_FUNCTIONAL_AREA())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(5 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(5);
			}

			query.append(_SQL_SELECT_OC_JOB_FUNCTION_MST_WHERE);

			boolean bindFUNCTIONAL_AREA = false;

			if (FUNCTIONAL_AREA == null) {
				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_FUNCTIONAL_AREA_1);
			}
			else if (FUNCTIONAL_AREA.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_FUNCTIONAL_AREA_3);
			}
			else {
				bindFUNCTIONAL_AREA = true;

				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_FUNCTIONAL_AREA_2);
			}

			boolean bindJOB = false;

			if (JOB == null) {
				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_JOB_1);
			}
			else if (JOB.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_JOB_3);
			}
			else {
				bindJOB = true;

				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_JOB_2);
			}

			boolean bindSUB_FUNCTIONAL_AREA = false;

			if (SUB_FUNCTIONAL_AREA == null) {
				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_SUB_FUNCTIONAL_AREA_1);
			}
			else if (SUB_FUNCTIONAL_AREA.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_SUB_FUNCTIONAL_AREA_3);
			}
			else {
				bindSUB_FUNCTIONAL_AREA = true;

				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_SUB_FUNCTIONAL_AREA_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(OC_JOB_FUNCTION_MSTModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindFUNCTIONAL_AREA) {
					qPos.add(FUNCTIONAL_AREA);
				}

				if (bindJOB) {
					qPos.add(JOB);
				}

				if (bindSUB_FUNCTIONAL_AREA) {
					qPos.add(SUB_FUNCTIONAL_AREA);
				}

				if (!pagination) {
					list = (List<OC_JOB_FUNCTION_MST>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<OC_JOB_FUNCTION_MST>(list);
				}
				else {
					list = (List<OC_JOB_FUNCTION_MST>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first o c_ j o b_ f u n c t i o n_ m s t in the ordered set where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	 *
	 * @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	 * @param JOB the j o b
	 * @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching o c_ j o b_ f u n c t i o n_ m s t
	 * @throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException if a matching o c_ j o b_ f u n c t i o n_ m s t could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OC_JOB_FUNCTION_MST findByAreaJobFunction_First(
		String FUNCTIONAL_AREA, String JOB, String SUB_FUNCTIONAL_AREA,
		OrderByComparator orderByComparator)
		throws NoSuchOC_JOB_FUNCTION_MSTException, SystemException {
		OC_JOB_FUNCTION_MST oc_job_function_mst = fetchByAreaJobFunction_First(FUNCTIONAL_AREA,
				JOB, SUB_FUNCTIONAL_AREA, orderByComparator);

		if (oc_job_function_mst != null) {
			return oc_job_function_mst;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("FUNCTIONAL_AREA=");
		msg.append(FUNCTIONAL_AREA);

		msg.append(", JOB=");
		msg.append(JOB);

		msg.append(", SUB_FUNCTIONAL_AREA=");
		msg.append(SUB_FUNCTIONAL_AREA);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchOC_JOB_FUNCTION_MSTException(msg.toString());
	}

	/**
	 * Returns the first o c_ j o b_ f u n c t i o n_ m s t in the ordered set where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	 *
	 * @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	 * @param JOB the j o b
	 * @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching o c_ j o b_ f u n c t i o n_ m s t, or <code>null</code> if a matching o c_ j o b_ f u n c t i o n_ m s t could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OC_JOB_FUNCTION_MST fetchByAreaJobFunction_First(
		String FUNCTIONAL_AREA, String JOB, String SUB_FUNCTIONAL_AREA,
		OrderByComparator orderByComparator) throws SystemException {
		List<OC_JOB_FUNCTION_MST> list = findByAreaJobFunction(FUNCTIONAL_AREA,
				JOB, SUB_FUNCTIONAL_AREA, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last o c_ j o b_ f u n c t i o n_ m s t in the ordered set where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	 *
	 * @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	 * @param JOB the j o b
	 * @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching o c_ j o b_ f u n c t i o n_ m s t
	 * @throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException if a matching o c_ j o b_ f u n c t i o n_ m s t could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OC_JOB_FUNCTION_MST findByAreaJobFunction_Last(
		String FUNCTIONAL_AREA, String JOB, String SUB_FUNCTIONAL_AREA,
		OrderByComparator orderByComparator)
		throws NoSuchOC_JOB_FUNCTION_MSTException, SystemException {
		OC_JOB_FUNCTION_MST oc_job_function_mst = fetchByAreaJobFunction_Last(FUNCTIONAL_AREA,
				JOB, SUB_FUNCTIONAL_AREA, orderByComparator);

		if (oc_job_function_mst != null) {
			return oc_job_function_mst;
		}

		StringBundler msg = new StringBundler(8);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("FUNCTIONAL_AREA=");
		msg.append(FUNCTIONAL_AREA);

		msg.append(", JOB=");
		msg.append(JOB);

		msg.append(", SUB_FUNCTIONAL_AREA=");
		msg.append(SUB_FUNCTIONAL_AREA);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchOC_JOB_FUNCTION_MSTException(msg.toString());
	}

	/**
	 * Returns the last o c_ j o b_ f u n c t i o n_ m s t in the ordered set where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	 *
	 * @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	 * @param JOB the j o b
	 * @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching o c_ j o b_ f u n c t i o n_ m s t, or <code>null</code> if a matching o c_ j o b_ f u n c t i o n_ m s t could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OC_JOB_FUNCTION_MST fetchByAreaJobFunction_Last(
		String FUNCTIONAL_AREA, String JOB, String SUB_FUNCTIONAL_AREA,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByAreaJobFunction(FUNCTIONAL_AREA, JOB,
				SUB_FUNCTIONAL_AREA);

		if (count == 0) {
			return null;
		}

		List<OC_JOB_FUNCTION_MST> list = findByAreaJobFunction(FUNCTIONAL_AREA,
				JOB, SUB_FUNCTIONAL_AREA, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the o c_ j o b_ f u n c t i o n_ m s ts before and after the current o c_ j o b_ f u n c t i o n_ m s t in the ordered set where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	 *
	 * @param OC_JOB_FUNCTION_ID the primary key of the current o c_ j o b_ f u n c t i o n_ m s t
	 * @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	 * @param JOB the j o b
	 * @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next o c_ j o b_ f u n c t i o n_ m s t
	 * @throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException if a o c_ j o b_ f u n c t i o n_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OC_JOB_FUNCTION_MST[] findByAreaJobFunction_PrevAndNext(
		long OC_JOB_FUNCTION_ID, String FUNCTIONAL_AREA, String JOB,
		String SUB_FUNCTIONAL_AREA, OrderByComparator orderByComparator)
		throws NoSuchOC_JOB_FUNCTION_MSTException, SystemException {
		OC_JOB_FUNCTION_MST oc_job_function_mst = findByPrimaryKey(OC_JOB_FUNCTION_ID);

		Session session = null;

		try {
			session = openSession();

			OC_JOB_FUNCTION_MST[] array = new OC_JOB_FUNCTION_MSTImpl[3];

			array[0] = getByAreaJobFunction_PrevAndNext(session,
					oc_job_function_mst, FUNCTIONAL_AREA, JOB,
					SUB_FUNCTIONAL_AREA, orderByComparator, true);

			array[1] = oc_job_function_mst;

			array[2] = getByAreaJobFunction_PrevAndNext(session,
					oc_job_function_mst, FUNCTIONAL_AREA, JOB,
					SUB_FUNCTIONAL_AREA, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected OC_JOB_FUNCTION_MST getByAreaJobFunction_PrevAndNext(
		Session session, OC_JOB_FUNCTION_MST oc_job_function_mst,
		String FUNCTIONAL_AREA, String JOB, String SUB_FUNCTIONAL_AREA,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_OC_JOB_FUNCTION_MST_WHERE);

		boolean bindFUNCTIONAL_AREA = false;

		if (FUNCTIONAL_AREA == null) {
			query.append(_FINDER_COLUMN_AREAJOBFUNCTION_FUNCTIONAL_AREA_1);
		}
		else if (FUNCTIONAL_AREA.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_AREAJOBFUNCTION_FUNCTIONAL_AREA_3);
		}
		else {
			bindFUNCTIONAL_AREA = true;

			query.append(_FINDER_COLUMN_AREAJOBFUNCTION_FUNCTIONAL_AREA_2);
		}

		boolean bindJOB = false;

		if (JOB == null) {
			query.append(_FINDER_COLUMN_AREAJOBFUNCTION_JOB_1);
		}
		else if (JOB.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_AREAJOBFUNCTION_JOB_3);
		}
		else {
			bindJOB = true;

			query.append(_FINDER_COLUMN_AREAJOBFUNCTION_JOB_2);
		}

		boolean bindSUB_FUNCTIONAL_AREA = false;

		if (SUB_FUNCTIONAL_AREA == null) {
			query.append(_FINDER_COLUMN_AREAJOBFUNCTION_SUB_FUNCTIONAL_AREA_1);
		}
		else if (SUB_FUNCTIONAL_AREA.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_AREAJOBFUNCTION_SUB_FUNCTIONAL_AREA_3);
		}
		else {
			bindSUB_FUNCTIONAL_AREA = true;

			query.append(_FINDER_COLUMN_AREAJOBFUNCTION_SUB_FUNCTIONAL_AREA_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(OC_JOB_FUNCTION_MSTModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindFUNCTIONAL_AREA) {
			qPos.add(FUNCTIONAL_AREA);
		}

		if (bindJOB) {
			qPos.add(JOB);
		}

		if (bindSUB_FUNCTIONAL_AREA) {
			qPos.add(SUB_FUNCTIONAL_AREA);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(oc_job_function_mst);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<OC_JOB_FUNCTION_MST> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the o c_ j o b_ f u n c t i o n_ m s ts where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63; from the database.
	 *
	 * @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	 * @param JOB the j o b
	 * @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByAreaJobFunction(String FUNCTIONAL_AREA, String JOB,
		String SUB_FUNCTIONAL_AREA) throws SystemException {
		for (OC_JOB_FUNCTION_MST oc_job_function_mst : findByAreaJobFunction(
				FUNCTIONAL_AREA, JOB, SUB_FUNCTIONAL_AREA, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(oc_job_function_mst);
		}
	}

	/**
	 * Returns the number of o c_ j o b_ f u n c t i o n_ m s ts where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	 *
	 * @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	 * @param JOB the j o b
	 * @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	 * @return the number of matching o c_ j o b_ f u n c t i o n_ m s ts
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByAreaJobFunction(String FUNCTIONAL_AREA, String JOB,
		String SUB_FUNCTIONAL_AREA) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_AREAJOBFUNCTION;

		Object[] finderArgs = new Object[] {
				FUNCTIONAL_AREA, JOB, SUB_FUNCTIONAL_AREA
			};

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_OC_JOB_FUNCTION_MST_WHERE);

			boolean bindFUNCTIONAL_AREA = false;

			if (FUNCTIONAL_AREA == null) {
				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_FUNCTIONAL_AREA_1);
			}
			else if (FUNCTIONAL_AREA.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_FUNCTIONAL_AREA_3);
			}
			else {
				bindFUNCTIONAL_AREA = true;

				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_FUNCTIONAL_AREA_2);
			}

			boolean bindJOB = false;

			if (JOB == null) {
				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_JOB_1);
			}
			else if (JOB.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_JOB_3);
			}
			else {
				bindJOB = true;

				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_JOB_2);
			}

			boolean bindSUB_FUNCTIONAL_AREA = false;

			if (SUB_FUNCTIONAL_AREA == null) {
				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_SUB_FUNCTIONAL_AREA_1);
			}
			else if (SUB_FUNCTIONAL_AREA.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_SUB_FUNCTIONAL_AREA_3);
			}
			else {
				bindSUB_FUNCTIONAL_AREA = true;

				query.append(_FINDER_COLUMN_AREAJOBFUNCTION_SUB_FUNCTIONAL_AREA_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindFUNCTIONAL_AREA) {
					qPos.add(FUNCTIONAL_AREA);
				}

				if (bindJOB) {
					qPos.add(JOB);
				}

				if (bindSUB_FUNCTIONAL_AREA) {
					qPos.add(SUB_FUNCTIONAL_AREA);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AREAJOBFUNCTION_FUNCTIONAL_AREA_1 =
		"oc_job_function_mst.FUNCTIONAL_AREA IS NULL AND ";
	private static final String _FINDER_COLUMN_AREAJOBFUNCTION_FUNCTIONAL_AREA_2 =
		"oc_job_function_mst.FUNCTIONAL_AREA = ? AND ";
	private static final String _FINDER_COLUMN_AREAJOBFUNCTION_FUNCTIONAL_AREA_3 =
		"(oc_job_function_mst.FUNCTIONAL_AREA IS NULL OR oc_job_function_mst.FUNCTIONAL_AREA = '') AND ";
	private static final String _FINDER_COLUMN_AREAJOBFUNCTION_JOB_1 = "oc_job_function_mst.JOB IS NULL AND ";
	private static final String _FINDER_COLUMN_AREAJOBFUNCTION_JOB_2 = "oc_job_function_mst.JOB = ? AND ";
	private static final String _FINDER_COLUMN_AREAJOBFUNCTION_JOB_3 = "(oc_job_function_mst.JOB IS NULL OR oc_job_function_mst.JOB = '') AND ";
	private static final String _FINDER_COLUMN_AREAJOBFUNCTION_SUB_FUNCTIONAL_AREA_1 =
		"oc_job_function_mst.SUB_FUNCTIONAL_AREA IS NULL";
	private static final String _FINDER_COLUMN_AREAJOBFUNCTION_SUB_FUNCTIONAL_AREA_2 =
		"oc_job_function_mst.SUB_FUNCTIONAL_AREA = ?";
	private static final String _FINDER_COLUMN_AREAJOBFUNCTION_SUB_FUNCTIONAL_AREA_3 =
		"(oc_job_function_mst.SUB_FUNCTIONAL_AREA IS NULL OR oc_job_function_mst.SUB_FUNCTIONAL_AREA = '')";

	public OC_JOB_FUNCTION_MSTPersistenceImpl() {
		setModelClass(OC_JOB_FUNCTION_MST.class);
	}

	/**
	 * Caches the o c_ j o b_ f u n c t i o n_ m s t in the entity cache if it is enabled.
	 *
	 * @param oc_job_function_mst the o c_ j o b_ f u n c t i o n_ m s t
	 */
	@Override
	public void cacheResult(OC_JOB_FUNCTION_MST oc_job_function_mst) {
		EntityCacheUtil.putResult(OC_JOB_FUNCTION_MSTModelImpl.ENTITY_CACHE_ENABLED,
			OC_JOB_FUNCTION_MSTImpl.class, oc_job_function_mst.getPrimaryKey(),
			oc_job_function_mst);

		oc_job_function_mst.resetOriginalValues();
	}

	/**
	 * Caches the o c_ j o b_ f u n c t i o n_ m s ts in the entity cache if it is enabled.
	 *
	 * @param oc_job_function_msts the o c_ j o b_ f u n c t i o n_ m s ts
	 */
	@Override
	public void cacheResult(List<OC_JOB_FUNCTION_MST> oc_job_function_msts) {
		for (OC_JOB_FUNCTION_MST oc_job_function_mst : oc_job_function_msts) {
			if (EntityCacheUtil.getResult(
						OC_JOB_FUNCTION_MSTModelImpl.ENTITY_CACHE_ENABLED,
						OC_JOB_FUNCTION_MSTImpl.class,
						oc_job_function_mst.getPrimaryKey()) == null) {
				cacheResult(oc_job_function_mst);
			}
			else {
				oc_job_function_mst.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all o c_ j o b_ f u n c t i o n_ m s ts.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(OC_JOB_FUNCTION_MSTImpl.class.getName());
		}

		EntityCacheUtil.clearCache(OC_JOB_FUNCTION_MSTImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the o c_ j o b_ f u n c t i o n_ m s t.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(OC_JOB_FUNCTION_MST oc_job_function_mst) {
		EntityCacheUtil.removeResult(OC_JOB_FUNCTION_MSTModelImpl.ENTITY_CACHE_ENABLED,
			OC_JOB_FUNCTION_MSTImpl.class, oc_job_function_mst.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<OC_JOB_FUNCTION_MST> oc_job_function_msts) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (OC_JOB_FUNCTION_MST oc_job_function_mst : oc_job_function_msts) {
			EntityCacheUtil.removeResult(OC_JOB_FUNCTION_MSTModelImpl.ENTITY_CACHE_ENABLED,
				OC_JOB_FUNCTION_MSTImpl.class,
				oc_job_function_mst.getPrimaryKey());
		}
	}

	/**
	 * Creates a new o c_ j o b_ f u n c t i o n_ m s t with the primary key. Does not add the o c_ j o b_ f u n c t i o n_ m s t to the database.
	 *
	 * @param OC_JOB_FUNCTION_ID the primary key for the new o c_ j o b_ f u n c t i o n_ m s t
	 * @return the new o c_ j o b_ f u n c t i o n_ m s t
	 */
	@Override
	public OC_JOB_FUNCTION_MST create(long OC_JOB_FUNCTION_ID) {
		OC_JOB_FUNCTION_MST oc_job_function_mst = new OC_JOB_FUNCTION_MSTImpl();

		oc_job_function_mst.setNew(true);
		oc_job_function_mst.setPrimaryKey(OC_JOB_FUNCTION_ID);

		return oc_job_function_mst;
	}

	/**
	 * Removes the o c_ j o b_ f u n c t i o n_ m s t with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param OC_JOB_FUNCTION_ID the primary key of the o c_ j o b_ f u n c t i o n_ m s t
	 * @return the o c_ j o b_ f u n c t i o n_ m s t that was removed
	 * @throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException if a o c_ j o b_ f u n c t i o n_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OC_JOB_FUNCTION_MST remove(long OC_JOB_FUNCTION_ID)
		throws NoSuchOC_JOB_FUNCTION_MSTException, SystemException {
		return remove((Serializable)OC_JOB_FUNCTION_ID);
	}

	/**
	 * Removes the o c_ j o b_ f u n c t i o n_ m s t with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the o c_ j o b_ f u n c t i o n_ m s t
	 * @return the o c_ j o b_ f u n c t i o n_ m s t that was removed
	 * @throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException if a o c_ j o b_ f u n c t i o n_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OC_JOB_FUNCTION_MST remove(Serializable primaryKey)
		throws NoSuchOC_JOB_FUNCTION_MSTException, SystemException {
		Session session = null;

		try {
			session = openSession();

			OC_JOB_FUNCTION_MST oc_job_function_mst = (OC_JOB_FUNCTION_MST)session.get(OC_JOB_FUNCTION_MSTImpl.class,
					primaryKey);

			if (oc_job_function_mst == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchOC_JOB_FUNCTION_MSTException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(oc_job_function_mst);
		}
		catch (NoSuchOC_JOB_FUNCTION_MSTException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected OC_JOB_FUNCTION_MST removeImpl(
		OC_JOB_FUNCTION_MST oc_job_function_mst) throws SystemException {
		oc_job_function_mst = toUnwrappedModel(oc_job_function_mst);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(oc_job_function_mst)) {
				oc_job_function_mst = (OC_JOB_FUNCTION_MST)session.get(OC_JOB_FUNCTION_MSTImpl.class,
						oc_job_function_mst.getPrimaryKeyObj());
			}

			if (oc_job_function_mst != null) {
				session.delete(oc_job_function_mst);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (oc_job_function_mst != null) {
			clearCache(oc_job_function_mst);
		}

		return oc_job_function_mst;
	}

	@Override
	public OC_JOB_FUNCTION_MST updateImpl(
		com.jioc.query.model.OC_JOB_FUNCTION_MST oc_job_function_mst)
		throws SystemException {
		oc_job_function_mst = toUnwrappedModel(oc_job_function_mst);

		boolean isNew = oc_job_function_mst.isNew();

		OC_JOB_FUNCTION_MSTModelImpl oc_job_function_mstModelImpl = (OC_JOB_FUNCTION_MSTModelImpl)oc_job_function_mst;

		Session session = null;

		try {
			session = openSession();

			if (oc_job_function_mst.isNew()) {
				session.save(oc_job_function_mst);

				oc_job_function_mst.setNew(false);
			}
			else {
				session.merge(oc_job_function_mst);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !OC_JOB_FUNCTION_MSTModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((oc_job_function_mstModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_AREAJOBFUNCTION.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						oc_job_function_mstModelImpl.getOriginalFUNCTIONAL_AREA(),
						oc_job_function_mstModelImpl.getOriginalJOB(),
						oc_job_function_mstModelImpl.getOriginalSUB_FUNCTIONAL_AREA()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_AREAJOBFUNCTION,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_AREAJOBFUNCTION,
					args);

				args = new Object[] {
						oc_job_function_mstModelImpl.getFUNCTIONAL_AREA(),
						oc_job_function_mstModelImpl.getJOB(),
						oc_job_function_mstModelImpl.getSUB_FUNCTIONAL_AREA()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_AREAJOBFUNCTION,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_AREAJOBFUNCTION,
					args);
			}
		}

		EntityCacheUtil.putResult(OC_JOB_FUNCTION_MSTModelImpl.ENTITY_CACHE_ENABLED,
			OC_JOB_FUNCTION_MSTImpl.class, oc_job_function_mst.getPrimaryKey(),
			oc_job_function_mst);

		return oc_job_function_mst;
	}

	protected OC_JOB_FUNCTION_MST toUnwrappedModel(
		OC_JOB_FUNCTION_MST oc_job_function_mst) {
		if (oc_job_function_mst instanceof OC_JOB_FUNCTION_MSTImpl) {
			return oc_job_function_mst;
		}

		OC_JOB_FUNCTION_MSTImpl oc_job_function_mstImpl = new OC_JOB_FUNCTION_MSTImpl();

		oc_job_function_mstImpl.setNew(oc_job_function_mst.isNew());
		oc_job_function_mstImpl.setPrimaryKey(oc_job_function_mst.getPrimaryKey());

		oc_job_function_mstImpl.setOC_JOB_FUNCTION_ID(oc_job_function_mst.getOC_JOB_FUNCTION_ID());
		oc_job_function_mstImpl.setFUNCTIONAL_AREA(oc_job_function_mst.getFUNCTIONAL_AREA());
		oc_job_function_mstImpl.setJOB(oc_job_function_mst.getJOB());
		oc_job_function_mstImpl.setOC(oc_job_function_mst.getOC());
		oc_job_function_mstImpl.setSUB_FUNCTIONAL_AREA(oc_job_function_mst.getSUB_FUNCTIONAL_AREA());

		return oc_job_function_mstImpl;
	}

	/**
	 * Returns the o c_ j o b_ f u n c t i o n_ m s t with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the o c_ j o b_ f u n c t i o n_ m s t
	 * @return the o c_ j o b_ f u n c t i o n_ m s t
	 * @throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException if a o c_ j o b_ f u n c t i o n_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OC_JOB_FUNCTION_MST findByPrimaryKey(Serializable primaryKey)
		throws NoSuchOC_JOB_FUNCTION_MSTException, SystemException {
		OC_JOB_FUNCTION_MST oc_job_function_mst = fetchByPrimaryKey(primaryKey);

		if (oc_job_function_mst == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchOC_JOB_FUNCTION_MSTException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return oc_job_function_mst;
	}

	/**
	 * Returns the o c_ j o b_ f u n c t i o n_ m s t with the primary key or throws a {@link com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException} if it could not be found.
	 *
	 * @param OC_JOB_FUNCTION_ID the primary key of the o c_ j o b_ f u n c t i o n_ m s t
	 * @return the o c_ j o b_ f u n c t i o n_ m s t
	 * @throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException if a o c_ j o b_ f u n c t i o n_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OC_JOB_FUNCTION_MST findByPrimaryKey(long OC_JOB_FUNCTION_ID)
		throws NoSuchOC_JOB_FUNCTION_MSTException, SystemException {
		return findByPrimaryKey((Serializable)OC_JOB_FUNCTION_ID);
	}

	/**
	 * Returns the o c_ j o b_ f u n c t i o n_ m s t with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the o c_ j o b_ f u n c t i o n_ m s t
	 * @return the o c_ j o b_ f u n c t i o n_ m s t, or <code>null</code> if a o c_ j o b_ f u n c t i o n_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OC_JOB_FUNCTION_MST fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		OC_JOB_FUNCTION_MST oc_job_function_mst = (OC_JOB_FUNCTION_MST)EntityCacheUtil.getResult(OC_JOB_FUNCTION_MSTModelImpl.ENTITY_CACHE_ENABLED,
				OC_JOB_FUNCTION_MSTImpl.class, primaryKey);

		if (oc_job_function_mst == _nullOC_JOB_FUNCTION_MST) {
			return null;
		}

		if (oc_job_function_mst == null) {
			Session session = null;

			try {
				session = openSession();

				oc_job_function_mst = (OC_JOB_FUNCTION_MST)session.get(OC_JOB_FUNCTION_MSTImpl.class,
						primaryKey);

				if (oc_job_function_mst != null) {
					cacheResult(oc_job_function_mst);
				}
				else {
					EntityCacheUtil.putResult(OC_JOB_FUNCTION_MSTModelImpl.ENTITY_CACHE_ENABLED,
						OC_JOB_FUNCTION_MSTImpl.class, primaryKey,
						_nullOC_JOB_FUNCTION_MST);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(OC_JOB_FUNCTION_MSTModelImpl.ENTITY_CACHE_ENABLED,
					OC_JOB_FUNCTION_MSTImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return oc_job_function_mst;
	}

	/**
	 * Returns the o c_ j o b_ f u n c t i o n_ m s t with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param OC_JOB_FUNCTION_ID the primary key of the o c_ j o b_ f u n c t i o n_ m s t
	 * @return the o c_ j o b_ f u n c t i o n_ m s t, or <code>null</code> if a o c_ j o b_ f u n c t i o n_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OC_JOB_FUNCTION_MST fetchByPrimaryKey(long OC_JOB_FUNCTION_ID)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)OC_JOB_FUNCTION_ID);
	}

	/**
	 * Returns all the o c_ j o b_ f u n c t i o n_ m s ts.
	 *
	 * @return the o c_ j o b_ f u n c t i o n_ m s ts
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<OC_JOB_FUNCTION_MST> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the o c_ j o b_ f u n c t i o n_ m s ts.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.OC_JOB_FUNCTION_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of o c_ j o b_ f u n c t i o n_ m s ts
	 * @param end the upper bound of the range of o c_ j o b_ f u n c t i o n_ m s ts (not inclusive)
	 * @return the range of o c_ j o b_ f u n c t i o n_ m s ts
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<OC_JOB_FUNCTION_MST> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the o c_ j o b_ f u n c t i o n_ m s ts.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.OC_JOB_FUNCTION_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of o c_ j o b_ f u n c t i o n_ m s ts
	 * @param end the upper bound of the range of o c_ j o b_ f u n c t i o n_ m s ts (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of o c_ j o b_ f u n c t i o n_ m s ts
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<OC_JOB_FUNCTION_MST> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<OC_JOB_FUNCTION_MST> list = (List<OC_JOB_FUNCTION_MST>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_OC_JOB_FUNCTION_MST);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_OC_JOB_FUNCTION_MST;

				if (pagination) {
					sql = sql.concat(OC_JOB_FUNCTION_MSTModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<OC_JOB_FUNCTION_MST>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<OC_JOB_FUNCTION_MST>(list);
				}
				else {
					list = (List<OC_JOB_FUNCTION_MST>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the o c_ j o b_ f u n c t i o n_ m s ts from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (OC_JOB_FUNCTION_MST oc_job_function_mst : findAll()) {
			remove(oc_job_function_mst);
		}
	}

	/**
	 * Returns the number of o c_ j o b_ f u n c t i o n_ m s ts.
	 *
	 * @return the number of o c_ j o b_ f u n c t i o n_ m s ts
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_OC_JOB_FUNCTION_MST);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the o c_ j o b_ f u n c t i o n_ m s t persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.jioc.query.model.OC_JOB_FUNCTION_MST")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<OC_JOB_FUNCTION_MST>> listenersList = new ArrayList<ModelListener<OC_JOB_FUNCTION_MST>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<OC_JOB_FUNCTION_MST>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(OC_JOB_FUNCTION_MSTImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_OC_JOB_FUNCTION_MST = "SELECT oc_job_function_mst FROM OC_JOB_FUNCTION_MST oc_job_function_mst";
	private static final String _SQL_SELECT_OC_JOB_FUNCTION_MST_WHERE = "SELECT oc_job_function_mst FROM OC_JOB_FUNCTION_MST oc_job_function_mst WHERE ";
	private static final String _SQL_COUNT_OC_JOB_FUNCTION_MST = "SELECT COUNT(oc_job_function_mst) FROM OC_JOB_FUNCTION_MST oc_job_function_mst";
	private static final String _SQL_COUNT_OC_JOB_FUNCTION_MST_WHERE = "SELECT COUNT(oc_job_function_mst) FROM OC_JOB_FUNCTION_MST oc_job_function_mst WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "oc_job_function_mst.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No OC_JOB_FUNCTION_MST exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No OC_JOB_FUNCTION_MST exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(OC_JOB_FUNCTION_MSTPersistenceImpl.class);
	private static OC_JOB_FUNCTION_MST _nullOC_JOB_FUNCTION_MST = new OC_JOB_FUNCTION_MSTImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<OC_JOB_FUNCTION_MST> toCacheModel() {
				return _nullOC_JOB_FUNCTION_MSTCacheModel;
			}
		};

	private static CacheModel<OC_JOB_FUNCTION_MST> _nullOC_JOB_FUNCTION_MSTCacheModel =
		new CacheModel<OC_JOB_FUNCTION_MST>() {
			@Override
			public OC_JOB_FUNCTION_MST toEntityModel() {
				return _nullOC_JOB_FUNCTION_MST;
			}
		};
}