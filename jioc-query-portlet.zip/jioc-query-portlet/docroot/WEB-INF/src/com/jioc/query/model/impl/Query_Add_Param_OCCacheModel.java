/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model.impl;

import com.jioc.query.model.Query_Add_Param_OC;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing Query_Add_Param_OC in entity cache.
 *
 * @author shantaram.chavan
 * @see Query_Add_Param_OC
 * @generated
 */
public class Query_Add_Param_OCCacheModel implements CacheModel<Query_Add_Param_OC>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(9);

		sb.append("{queryAddParamOCId=");
		sb.append(queryAddParamOCId);
		sb.append(", OC=");
		sb.append(OC);
		sb.append(", status=");
		sb.append(status);
		sb.append(", updatedTimestamp=");
		sb.append(updatedTimestamp);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Query_Add_Param_OC toEntityModel() {
		Query_Add_Param_OCImpl query_Add_Param_OCImpl = new Query_Add_Param_OCImpl();

		query_Add_Param_OCImpl.setQueryAddParamOCId(queryAddParamOCId);

		if (OC == null) {
			query_Add_Param_OCImpl.setOC(StringPool.BLANK);
		}
		else {
			query_Add_Param_OCImpl.setOC(OC);
		}

		query_Add_Param_OCImpl.setStatus(status);

		if (updatedTimestamp == Long.MIN_VALUE) {
			query_Add_Param_OCImpl.setUpdatedTimestamp(null);
		}
		else {
			query_Add_Param_OCImpl.setUpdatedTimestamp(new Date(
					updatedTimestamp));
		}

		query_Add_Param_OCImpl.resetOriginalValues();

		return query_Add_Param_OCImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		queryAddParamOCId = objectInput.readLong();
		OC = objectInput.readUTF();
		status = objectInput.readInt();
		updatedTimestamp = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(queryAddParamOCId);

		if (OC == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(OC);
		}

		objectOutput.writeInt(status);
		objectOutput.writeLong(updatedTimestamp);
	}

	public long queryAddParamOCId;
	public String OC;
	public int status;
	public long updatedTimestamp;
}