/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.impl;

import com.jioc.query.model.EMP_DETAILS;
import com.jioc.query.model.Emp_User_Mapping;
import com.jioc.query.model.impl.EMP_DETAILSImpl;
import com.jioc.query.service.EMP_DETAILSLocalServiceUtil;
import com.jioc.query.service.base.EMP_DETAILSLocalServiceBaseImpl;
import com.jioc.query.service.persistence.EMP_DETAILSFinderImpl;
import com.jioc.query.service.persistence.EMP_DETAILSFinderUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.Junction;
import com.liferay.portal.kernel.dao.orm.OrderFactoryUtil;
import com.liferay.portal.kernel.dao.orm.ProjectionFactoryUtil;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.dao.orm.SQLQuery;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.OrderByComparatorFactoryUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * The implementation of the e m p_ d e t a i l s local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jioc.query.service.EMP_DETAILSLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author shantaram.chavan
 * @see com.jioc.query.service.base.EMP_DETAILSLocalServiceBaseImpl
 * @see com.jioc.query.service.EMP_DETAILSLocalServiceUtil
 */
public class EMP_DETAILSLocalServiceImpl extends EMP_DETAILSLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.jioc.query.service.EMP_DETAILSLocalServiceUtil} to access the e m p_ d e t a i l s local service.
	 */
	
	public EMP_DETAILS findEmpDetailsById(String empId){
		try {
			List<EMP_DETAILS> empDetails = emp_detailsPersistence.findByEMP_ID(empId);
			if(Validator.isNotNull(empDetails) && empDetails.size() > 0){
				return empDetails.get(0);
			}
		} catch (SystemException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public List<Object[]> getDistinctArea(){
		try {
			Session session = emp_detailsPersistence.openSession(); 
			SQLQuery query = session.createSQLQuery("select distinct(area) from JIOC_EMP_DETAILS order by area");
			return query.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public List<Object[]> getDistinctJoRegion(){
		try {
			Session session = emp_detailsPersistence.openSession(); 
			SQLQuery query = session.createSQLQuery("select distinct(JO_REGION) from JIOC_EMP_DETAILS order by JO_REGION");
			return query.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	public List<Object[]> getDistinctJioCenter(){
		try {
			Session session = emp_detailsPersistence.openSession(); 
			SQLQuery query = session.createSQLQuery("select distinct(JIO_CENTER) from JIOC_EMP_DETAILS order by JIO_CENTER");
			return query.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public List<Object[]> getDistinctJob(){
		try {
			Session session = emp_detailsPersistence.openSession(); 
			SQLQuery query = session.createSQLQuery("select distinct(JOB) from JIOC_EMP_DETAILS where department in (select OC from jioc_taskocdetails) order by JOB");
			return query.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public List<Object[]> getDistinctJoType(){
		try {
			Session session = emp_detailsPersistence.openSession(); 
			SQLQuery query = session.createSQLQuery("select distinct(JO_TYPE) from jioc_emp_details order by JO_TYPE asc");
			return query.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public List<Object[]> getDistinctRole(){
		try {
			Session session = emp_detailsPersistence.openSession(); 
			SQLQuery query = session.createSQLQuery("select distinct(JOB) from jioc_emp_details order by JOB asc");
			return query.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public List<Object[]> getDistinctOC(){
		try {
			Session session = emp_detailsPersistence.openSession(); 
			SQLQuery query = session.createSQLQuery("select distinct(DEPARTMENT) from jioc_emp_details order by DEPARTMENT asc");
			return query.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public List<Object[]> searchUserByNameOrEmpIdInOC(String searchKey, String oc){
		try {
			searchKey = "%"+searchKey+"%";
			System.out.println("searchKey**=="+searchKey);
			Session session = query_DetailsPersistence.openSession(); 
			SQLQuery query = session.createSQLQuery("select ed.FULL_NAME, ed.EMP_ID, eum.userId from jioc_emp_details ed inner join jioc_emp_user_mapping eum on ed.EMP_ID = eum.empId where ed.DEPARTMENT='"+oc+"' and ( upper(ed.EMP_ID) like '"+searchKey+"' or upper(ed.FULL_NAME) like '"+searchKey+"')");
			//System.out.println("query==="+"select ed.FULL_NAME, ed.EMP_ID, eum.userId from jioc_emp_details ed inner join jioc_emp_user_mapping eum on ed.EMP_ID = eum.empId where ed.DEPARTMENT="+oc+" and ( upper(ed.EMP_ID) like '"+searchKey+"' or upper(ed.FULL_NAME) like '"+searchKey+"')");
			return query.list();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public EMP_DETAILS getEmpDetailsByUserId(long userId){
		try {
			Emp_User_Mapping empUserMapping = emp_User_MappingPersistence.fetchByPrimaryKey(userId);
			if(Validator.isNotNull(empUserMapping)){
				List<EMP_DETAILS> empDetails = emp_detailsPersistence.findByEMP_ID(empUserMapping.getEmpId());
				if(Validator.isNotNull(empDetails) && empDetails.size() > 0){
					return empDetails.get(0);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public boolean isEmpExists(String empId, String domainId, String emailId){
		boolean isEmpExists = false;
		List<Object[]> empDetailsList = null;
		
		try {
			Session session = emp_detailsPersistence.openSession(); 
			SQLQuery query = session.createSQLQuery("select * from jioc_emp_details where emp_id=? or employee_domain_id=? or email=?");
			QueryPos pos = QueryPos.getInstance(query);
			pos.add(empId);
			pos.add(domainId);
			pos.add(emailId);
			empDetailsList = query.list();
			if(Validator.isNotNull(empDetailsList) && empDetailsList.size() > 0){
				isEmpExists = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return isEmpExists;
	}
	
	public long getResolverByRR(String region, String state, String oc, String jioType, int resolverLevel){
		long resolverUserId = 0;
		
		try {
			//SQLQuery query = session.createSQLQuery("{call PROC_GET_RR_USERID (?,?,?,?,?, @resolverId)}");
			
			resolverUserId = EMP_DETAILSFinderUtil.findResolverByRR(region, state, oc, jioType, resolverLevel);
			
			
			System.out.println("resolverUserId:"+resolverUserId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return resolverUserId;
	}
	
	public void updateEmployeeDetails(){
		try {
			//SQLQuery query = session.createSQLQuery("{call PROC_GET_RR_USERID (?,?,?,?,?, @resolverId)}");
			EMP_DETAILSFinderUtil.updateEmpDetails();
			//System.out.println("resolverUserId:"+resolverUserId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//return resolverUserId;
	}
	
	public List<Object[]> fetchEmpByDomainId(String domainId){
		
		try {
			Session session = emp_detailsPersistence.openSession(); 
			SQLQuery query = session.createSQLQuery("select emp_id, department, email, emp_group, employee_domain_id, employment_status, first_name, last_name, saml_federation_id, job from jioc_emp_details where upper(EMPLOYEE_DOMAIN_ID)=upper(?)");
			QueryPos pos = QueryPos.getInstance(query);
			pos.add(domainId);
			
			return query.list();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public List<EMP_DETAILS> getsearchAssignees(String region, String circle, String area, String center,String job){
		return EMP_DETAILSFinderUtil.searchAssignees(region, circle, area, center,job);
		
	}
	
	public List<String> getSearchJobByAreaCircleRegionJioCenterAndOC(String region, String circle, String area, String center){
		return EMP_DETAILSFinderUtil.getSearchJobByAreaCircleRegionJioCenterAndOc(region, circle, area, center);
		
	}
	
	public List<String> getSearchCircleByRegion(String region) throws SystemException{
		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil. forClass(EMP_DETAILS.class);
		dynamicQuery.setProjection(ProjectionFactoryUtil.distinct(ProjectionFactoryUtil.property("R4G_STATE")));
		Junction junction = RestrictionsFactoryUtil.conjunction();
		junction.add(RestrictionsFactoryUtil.eq("JO_REGION", region));
		dynamicQuery.add(junction);
		dynamicQuery.addOrder(OrderFactoryUtil.asc("R4G_STATE"));
		return this.emp_detailsLocalService.dynamicQuery(dynamicQuery);
	}
	
	public List<String> getSearchAreaByCircleRegion(String circle, String region) throws SystemException{
		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil. forClass(EMP_DETAILS.class);
		dynamicQuery.setProjection(ProjectionFactoryUtil.distinct(ProjectionFactoryUtil.property("AREA")));
		Junction junction = RestrictionsFactoryUtil.conjunction();
		junction.add(RestrictionsFactoryUtil.eq("JO_REGION", region));
		junction.add(RestrictionsFactoryUtil.eq("R4G_STATE", circle));
		dynamicQuery.add(junction);
		dynamicQuery.addOrder(OrderFactoryUtil.asc("AREA"));
		return this.emp_detailsLocalService.dynamicQuery(dynamicQuery);
	}
	
	public List<String> getSearchJioCenterByAreaCircleRegion(String circle, String region,String area) throws SystemException{
		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil. forClass(EMP_DETAILS.class);
		dynamicQuery.setProjection(ProjectionFactoryUtil.distinct(ProjectionFactoryUtil.property("JIO_CENTER")));
		Junction junction = RestrictionsFactoryUtil.conjunction();
		junction.add(RestrictionsFactoryUtil.eq("JO_REGION", region));
		junction.add(RestrictionsFactoryUtil.eq("R4G_STATE", circle));
		junction.add(RestrictionsFactoryUtil.eq("AREA", area));
		dynamicQuery.add(junction);
		dynamicQuery.addOrder(OrderFactoryUtil.asc("JIO_CENTER"));
		return this.emp_detailsLocalService.dynamicQuery(dynamicQuery);
	}
	
	public List<String> getSearchJobByAreaCircleRegionJioCenter(String circle, String region,String area,String jioCenter) throws SystemException{
		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil. forClass(EMP_DETAILS.class);
		dynamicQuery.setProjection(ProjectionFactoryUtil.distinct(ProjectionFactoryUtil.property("JOB")));
		Junction junction = RestrictionsFactoryUtil.conjunction();
		junction.add(RestrictionsFactoryUtil.eq("JO_REGION", region));
		junction.add(RestrictionsFactoryUtil.eq("R4G_STATE", circle));
		junction.add(RestrictionsFactoryUtil.eq("AREA", area));
		junction.add(RestrictionsFactoryUtil.eq("JIO_CENTER", jioCenter));
		dynamicQuery.add(junction);
		dynamicQuery.addOrder(OrderFactoryUtil.asc("JOB"));
		return this.emp_detailsLocalService.dynamicQuery(dynamicQuery);
	}
	
	public List<Object[]> findEmpDetails4Prov(){
		//List<EMP_DETAILS> empDetailsList = null;
		try {
			/*java.util.Date todaysDate = new java.util.Date();
			todaysDate.setHours(12);
			todaysDate.setMinutes(0);
			todaysDate.setSeconds(0);*/
			/*java.util.Date nowDate = new java.util.Date();
			java.util.Date todaysDate = new java.util.Date(nowDate.getYear(), nowDate.getMonth(), nowDate.getDate(), 0, 0, 0);
			System.out.println("date:"+todaysDate);
			empDetailsList = emp_detailsPersistence.findByDATE_OF_JOINING(todaysDate);*/
			
			Session session = emp_detailsPersistence.openSession();
			//SQLQuery query = session.createSQLQuery("select emp_id, email, employee_domain_id, employment_status, first_name, last_name, saml_federation_id, b.screenname  from jioc_emp_details a left join user_ b on upper(a.employee_domain_id) = upper(b.screenname) where employment_status = 3 and emp_group = 'JO' and b.screenname is null and employee_domain_id is not null");
			SQLQuery query = session.createSQLQuery("select emp_id, email, employee_domain_id, employment_status, first_name, last_name, saml_federation_id, b.screenname, job, department, jo_region from jioc_emp_details a left join user_ b on upper(a.employee_domain_id) = upper(b.screenname) where employment_status = 3 and b.screenname is null and employee_domain_id is not null");
			
			return query.list();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}}