/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model.impl;

import com.jioc.query.model.Setup;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing Setup in entity cache.
 *
 * @author shantaram.chavan
 * @see Setup
 * @generated
 */
public class SetupCacheModel implements CacheModel<Setup>, Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{setup_id=");
		sb.append(setup_id);
		sb.append(", key=");
		sb.append(key);
		sb.append(", val1=");
		sb.append(val1);
		sb.append(", val2=");
		sb.append(val2);
		sb.append(", status=");
		sb.append(status);
		sb.append(", updated_timestamp=");
		sb.append(updated_timestamp);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Setup toEntityModel() {
		SetupImpl setupImpl = new SetupImpl();

		setupImpl.setSetup_id(setup_id);

		if (key == null) {
			setupImpl.setKey(StringPool.BLANK);
		}
		else {
			setupImpl.setKey(key);
		}

		if (val1 == null) {
			setupImpl.setVal1(StringPool.BLANK);
		}
		else {
			setupImpl.setVal1(val1);
		}

		if (val2 == null) {
			setupImpl.setVal2(StringPool.BLANK);
		}
		else {
			setupImpl.setVal2(val2);
		}

		setupImpl.setStatus(status);

		if (updated_timestamp == Long.MIN_VALUE) {
			setupImpl.setUpdated_timestamp(null);
		}
		else {
			setupImpl.setUpdated_timestamp(new Date(updated_timestamp));
		}

		setupImpl.resetOriginalValues();

		return setupImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		setup_id = objectInput.readLong();
		key = objectInput.readUTF();
		val1 = objectInput.readUTF();
		val2 = objectInput.readUTF();
		status = objectInput.readInt();
		updated_timestamp = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(setup_id);

		if (key == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(key);
		}

		if (val1 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(val1);
		}

		if (val2 == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(val2);
		}

		objectOutput.writeInt(status);
		objectOutput.writeLong(updated_timestamp);
	}

	public long setup_id;
	public String key;
	public String val1;
	public String val2;
	public int status;
	public long updated_timestamp;
}