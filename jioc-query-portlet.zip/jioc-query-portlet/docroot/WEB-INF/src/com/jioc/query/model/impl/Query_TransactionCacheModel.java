/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model.impl;

import com.jioc.query.model.Query_Transaction;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing Query_Transaction in entity cache.
 *
 * @author shantaram.chavan
 * @see Query_Transaction
 * @generated
 */
public class Query_TransactionCacheModel implements CacheModel<Query_Transaction>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(37);

		sb.append("{queryId=");
		sb.append(queryId);
		sb.append(", caseNo=");
		sb.append(caseNo);
		sb.append(", description=");
		sb.append(description);
		sb.append(", raisedTimestamp=");
		sb.append(raisedTimestamp);
		sb.append(", raisedById=");
		sb.append(raisedById);
		sb.append(", toDisplay=");
		sb.append(toDisplay);
		sb.append(", orn_no=");
		sb.append(orn_no);
		sb.append(", caf_no=");
		sb.append(caf_no);
		sb.append(", customer_MSISDN=");
		sb.append(customer_MSISDN);
		sb.append(", amt_request=");
		sb.append(amt_request);
		sb.append(", amt_done=");
		sb.append(amt_done);
		sb.append(", raised_by_email=");
		sb.append(raised_by_email);
		sb.append(", pcId=");
		sb.append(pcId);
		sb.append(", ack=");
		sb.append(ack);
		sb.append(", source=");
		sb.append(source);
		sb.append(", ack_timestamp=");
		sb.append(ack_timestamp);
		sb.append(", assignment_group=");
		sb.append(assignment_group);
		sb.append(", ISACTIVE=");
		sb.append(ISACTIVE);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Query_Transaction toEntityModel() {
		Query_TransactionImpl query_TransactionImpl = new Query_TransactionImpl();

		query_TransactionImpl.setQueryId(queryId);

		if (caseNo == null) {
			query_TransactionImpl.setCaseNo(StringPool.BLANK);
		}
		else {
			query_TransactionImpl.setCaseNo(caseNo);
		}

		if (description == null) {
			query_TransactionImpl.setDescription(StringPool.BLANK);
		}
		else {
			query_TransactionImpl.setDescription(description);
		}

		if (raisedTimestamp == Long.MIN_VALUE) {
			query_TransactionImpl.setRaisedTimestamp(null);
		}
		else {
			query_TransactionImpl.setRaisedTimestamp(new Date(raisedTimestamp));
		}

		query_TransactionImpl.setRaisedById(raisedById);
		query_TransactionImpl.setToDisplay(toDisplay);

		if (orn_no == null) {
			query_TransactionImpl.setOrn_no(StringPool.BLANK);
		}
		else {
			query_TransactionImpl.setOrn_no(orn_no);
		}

		if (caf_no == null) {
			query_TransactionImpl.setCaf_no(StringPool.BLANK);
		}
		else {
			query_TransactionImpl.setCaf_no(caf_no);
		}

		if (customer_MSISDN == null) {
			query_TransactionImpl.setCustomer_MSISDN(StringPool.BLANK);
		}
		else {
			query_TransactionImpl.setCustomer_MSISDN(customer_MSISDN);
		}

		query_TransactionImpl.setAmt_request(amt_request);
		query_TransactionImpl.setAmt_done(amt_done);

		if (raised_by_email == null) {
			query_TransactionImpl.setRaised_by_email(StringPool.BLANK);
		}
		else {
			query_TransactionImpl.setRaised_by_email(raised_by_email);
		}

		if (pcId == null) {
			query_TransactionImpl.setPcId(StringPool.BLANK);
		}
		else {
			query_TransactionImpl.setPcId(pcId);
		}

		query_TransactionImpl.setAck(ack);

		if (source == null) {
			query_TransactionImpl.setSource(StringPool.BLANK);
		}
		else {
			query_TransactionImpl.setSource(source);
		}

		if (ack_timestamp == Long.MIN_VALUE) {
			query_TransactionImpl.setAck_timestamp(null);
		}
		else {
			query_TransactionImpl.setAck_timestamp(new Date(ack_timestamp));
		}

		if (assignment_group == null) {
			query_TransactionImpl.setAssignment_group(StringPool.BLANK);
		}
		else {
			query_TransactionImpl.setAssignment_group(assignment_group);
		}

		query_TransactionImpl.setISACTIVE(ISACTIVE);

		query_TransactionImpl.resetOriginalValues();

		return query_TransactionImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		queryId = objectInput.readLong();
		caseNo = objectInput.readUTF();
		description = objectInput.readUTF();
		raisedTimestamp = objectInput.readLong();
		raisedById = objectInput.readLong();
		toDisplay = objectInput.readInt();
		orn_no = objectInput.readUTF();
		caf_no = objectInput.readUTF();
		customer_MSISDN = objectInput.readUTF();
		amt_request = objectInput.readLong();
		amt_done = objectInput.readLong();
		raised_by_email = objectInput.readUTF();
		pcId = objectInput.readUTF();
		ack = objectInput.readInt();
		source = objectInput.readUTF();
		ack_timestamp = objectInput.readLong();
		assignment_group = objectInput.readUTF();
		ISACTIVE = objectInput.readInt();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(queryId);

		if (caseNo == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(caseNo);
		}

		if (description == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(description);
		}

		objectOutput.writeLong(raisedTimestamp);
		objectOutput.writeLong(raisedById);
		objectOutput.writeInt(toDisplay);

		if (orn_no == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(orn_no);
		}

		if (caf_no == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(caf_no);
		}

		if (customer_MSISDN == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(customer_MSISDN);
		}

		objectOutput.writeLong(amt_request);
		objectOutput.writeLong(amt_done);

		if (raised_by_email == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(raised_by_email);
		}

		if (pcId == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(pcId);
		}

		objectOutput.writeInt(ack);

		if (source == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(source);
		}

		objectOutput.writeLong(ack_timestamp);

		if (assignment_group == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(assignment_group);
		}

		objectOutput.writeInt(ISACTIVE);
	}

	public long queryId;
	public String caseNo;
	public String description;
	public long raisedTimestamp;
	public long raisedById;
	public int toDisplay;
	public String orn_no;
	public String caf_no;
	public String customer_MSISDN;
	public long amt_request;
	public long amt_done;
	public String raised_by_email;
	public String pcId;
	public int ack;
	public String source;
	public long ack_timestamp;
	public String assignment_group;
	public int ISACTIVE;
}