/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.NoSuchOC_CAT_MSTException;
import com.jioc.query.model.OC_CAT_MST;
import com.jioc.query.model.impl.OC_CAT_MSTImpl;
import com.jioc.query.model.impl.OC_CAT_MSTModelImpl;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the o c_ c a t_ m s t service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see OC_CAT_MSTPersistence
 * @see OC_CAT_MSTUtil
 * @generated
 */
public class OC_CAT_MSTPersistenceImpl extends BasePersistenceImpl<OC_CAT_MST>
	implements OC_CAT_MSTPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link OC_CAT_MSTUtil} to access the o c_ c a t_ m s t persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = OC_CAT_MSTImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(OC_CAT_MSTModelImpl.ENTITY_CACHE_ENABLED,
			OC_CAT_MSTModelImpl.FINDER_CACHE_ENABLED, OC_CAT_MSTImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(OC_CAT_MSTModelImpl.ENTITY_CACHE_ENABLED,
			OC_CAT_MSTModelImpl.FINDER_CACHE_ENABLED, OC_CAT_MSTImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(OC_CAT_MSTModelImpl.ENTITY_CACHE_ENABLED,
			OC_CAT_MSTModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);

	public OC_CAT_MSTPersistenceImpl() {
		setModelClass(OC_CAT_MST.class);
	}

	/**
	 * Caches the o c_ c a t_ m s t in the entity cache if it is enabled.
	 *
	 * @param oc_cat_mst the o c_ c a t_ m s t
	 */
	@Override
	public void cacheResult(OC_CAT_MST oc_cat_mst) {
		EntityCacheUtil.putResult(OC_CAT_MSTModelImpl.ENTITY_CACHE_ENABLED,
			OC_CAT_MSTImpl.class, oc_cat_mst.getPrimaryKey(), oc_cat_mst);

		oc_cat_mst.resetOriginalValues();
	}

	/**
	 * Caches the o c_ c a t_ m s ts in the entity cache if it is enabled.
	 *
	 * @param oc_cat_msts the o c_ c a t_ m s ts
	 */
	@Override
	public void cacheResult(List<OC_CAT_MST> oc_cat_msts) {
		for (OC_CAT_MST oc_cat_mst : oc_cat_msts) {
			if (EntityCacheUtil.getResult(
						OC_CAT_MSTModelImpl.ENTITY_CACHE_ENABLED,
						OC_CAT_MSTImpl.class, oc_cat_mst.getPrimaryKey()) == null) {
				cacheResult(oc_cat_mst);
			}
			else {
				oc_cat_mst.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all o c_ c a t_ m s ts.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(OC_CAT_MSTImpl.class.getName());
		}

		EntityCacheUtil.clearCache(OC_CAT_MSTImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the o c_ c a t_ m s t.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(OC_CAT_MST oc_cat_mst) {
		EntityCacheUtil.removeResult(OC_CAT_MSTModelImpl.ENTITY_CACHE_ENABLED,
			OC_CAT_MSTImpl.class, oc_cat_mst.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<OC_CAT_MST> oc_cat_msts) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (OC_CAT_MST oc_cat_mst : oc_cat_msts) {
			EntityCacheUtil.removeResult(OC_CAT_MSTModelImpl.ENTITY_CACHE_ENABLED,
				OC_CAT_MSTImpl.class, oc_cat_mst.getPrimaryKey());
		}
	}

	/**
	 * Creates a new o c_ c a t_ m s t with the primary key. Does not add the o c_ c a t_ m s t to the database.
	 *
	 * @param CAT_ID the primary key for the new o c_ c a t_ m s t
	 * @return the new o c_ c a t_ m s t
	 */
	@Override
	public OC_CAT_MST create(long CAT_ID) {
		OC_CAT_MST oc_cat_mst = new OC_CAT_MSTImpl();

		oc_cat_mst.setNew(true);
		oc_cat_mst.setPrimaryKey(CAT_ID);

		return oc_cat_mst;
	}

	/**
	 * Removes the o c_ c a t_ m s t with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param CAT_ID the primary key of the o c_ c a t_ m s t
	 * @return the o c_ c a t_ m s t that was removed
	 * @throws com.jioc.query.NoSuchOC_CAT_MSTException if a o c_ c a t_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OC_CAT_MST remove(long CAT_ID)
		throws NoSuchOC_CAT_MSTException, SystemException {
		return remove((Serializable)CAT_ID);
	}

	/**
	 * Removes the o c_ c a t_ m s t with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the o c_ c a t_ m s t
	 * @return the o c_ c a t_ m s t that was removed
	 * @throws com.jioc.query.NoSuchOC_CAT_MSTException if a o c_ c a t_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OC_CAT_MST remove(Serializable primaryKey)
		throws NoSuchOC_CAT_MSTException, SystemException {
		Session session = null;

		try {
			session = openSession();

			OC_CAT_MST oc_cat_mst = (OC_CAT_MST)session.get(OC_CAT_MSTImpl.class,
					primaryKey);

			if (oc_cat_mst == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchOC_CAT_MSTException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(oc_cat_mst);
		}
		catch (NoSuchOC_CAT_MSTException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected OC_CAT_MST removeImpl(OC_CAT_MST oc_cat_mst)
		throws SystemException {
		oc_cat_mst = toUnwrappedModel(oc_cat_mst);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(oc_cat_mst)) {
				oc_cat_mst = (OC_CAT_MST)session.get(OC_CAT_MSTImpl.class,
						oc_cat_mst.getPrimaryKeyObj());
			}

			if (oc_cat_mst != null) {
				session.delete(oc_cat_mst);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (oc_cat_mst != null) {
			clearCache(oc_cat_mst);
		}

		return oc_cat_mst;
	}

	@Override
	public OC_CAT_MST updateImpl(com.jioc.query.model.OC_CAT_MST oc_cat_mst)
		throws SystemException {
		oc_cat_mst = toUnwrappedModel(oc_cat_mst);

		boolean isNew = oc_cat_mst.isNew();

		Session session = null;

		try {
			session = openSession();

			if (oc_cat_mst.isNew()) {
				session.save(oc_cat_mst);

				oc_cat_mst.setNew(false);
			}
			else {
				session.merge(oc_cat_mst);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		EntityCacheUtil.putResult(OC_CAT_MSTModelImpl.ENTITY_CACHE_ENABLED,
			OC_CAT_MSTImpl.class, oc_cat_mst.getPrimaryKey(), oc_cat_mst);

		return oc_cat_mst;
	}

	protected OC_CAT_MST toUnwrappedModel(OC_CAT_MST oc_cat_mst) {
		if (oc_cat_mst instanceof OC_CAT_MSTImpl) {
			return oc_cat_mst;
		}

		OC_CAT_MSTImpl oc_cat_mstImpl = new OC_CAT_MSTImpl();

		oc_cat_mstImpl.setNew(oc_cat_mst.isNew());
		oc_cat_mstImpl.setPrimaryKey(oc_cat_mst.getPrimaryKey());

		oc_cat_mstImpl.setCAT_ID(oc_cat_mst.getCAT_ID());
		oc_cat_mstImpl.setCAT_NAME(oc_cat_mst.getCAT_NAME());
		oc_cat_mstImpl.setHPSM_GROUP(oc_cat_mst.getHPSM_GROUP());
		oc_cat_mstImpl.setIS_ACTIVE(oc_cat_mst.getIS_ACTIVE());
		oc_cat_mstImpl.setOC(oc_cat_mst.getOC());
		oc_cat_mstImpl.setRESOLVER_LEVEL(oc_cat_mst.getRESOLVER_LEVEL());
		oc_cat_mstImpl.setUPDATED_TIMESTAMP(oc_cat_mst.getUPDATED_TIMESTAMP());

		return oc_cat_mstImpl;
	}

	/**
	 * Returns the o c_ c a t_ m s t with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the o c_ c a t_ m s t
	 * @return the o c_ c a t_ m s t
	 * @throws com.jioc.query.NoSuchOC_CAT_MSTException if a o c_ c a t_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OC_CAT_MST findByPrimaryKey(Serializable primaryKey)
		throws NoSuchOC_CAT_MSTException, SystemException {
		OC_CAT_MST oc_cat_mst = fetchByPrimaryKey(primaryKey);

		if (oc_cat_mst == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchOC_CAT_MSTException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return oc_cat_mst;
	}

	/**
	 * Returns the o c_ c a t_ m s t with the primary key or throws a {@link com.jioc.query.NoSuchOC_CAT_MSTException} if it could not be found.
	 *
	 * @param CAT_ID the primary key of the o c_ c a t_ m s t
	 * @return the o c_ c a t_ m s t
	 * @throws com.jioc.query.NoSuchOC_CAT_MSTException if a o c_ c a t_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OC_CAT_MST findByPrimaryKey(long CAT_ID)
		throws NoSuchOC_CAT_MSTException, SystemException {
		return findByPrimaryKey((Serializable)CAT_ID);
	}

	/**
	 * Returns the o c_ c a t_ m s t with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the o c_ c a t_ m s t
	 * @return the o c_ c a t_ m s t, or <code>null</code> if a o c_ c a t_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OC_CAT_MST fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		OC_CAT_MST oc_cat_mst = (OC_CAT_MST)EntityCacheUtil.getResult(OC_CAT_MSTModelImpl.ENTITY_CACHE_ENABLED,
				OC_CAT_MSTImpl.class, primaryKey);

		if (oc_cat_mst == _nullOC_CAT_MST) {
			return null;
		}

		if (oc_cat_mst == null) {
			Session session = null;

			try {
				session = openSession();

				oc_cat_mst = (OC_CAT_MST)session.get(OC_CAT_MSTImpl.class,
						primaryKey);

				if (oc_cat_mst != null) {
					cacheResult(oc_cat_mst);
				}
				else {
					EntityCacheUtil.putResult(OC_CAT_MSTModelImpl.ENTITY_CACHE_ENABLED,
						OC_CAT_MSTImpl.class, primaryKey, _nullOC_CAT_MST);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(OC_CAT_MSTModelImpl.ENTITY_CACHE_ENABLED,
					OC_CAT_MSTImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return oc_cat_mst;
	}

	/**
	 * Returns the o c_ c a t_ m s t with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param CAT_ID the primary key of the o c_ c a t_ m s t
	 * @return the o c_ c a t_ m s t, or <code>null</code> if a o c_ c a t_ m s t with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public OC_CAT_MST fetchByPrimaryKey(long CAT_ID) throws SystemException {
		return fetchByPrimaryKey((Serializable)CAT_ID);
	}

	/**
	 * Returns all the o c_ c a t_ m s ts.
	 *
	 * @return the o c_ c a t_ m s ts
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<OC_CAT_MST> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the o c_ c a t_ m s ts.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.OC_CAT_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of o c_ c a t_ m s ts
	 * @param end the upper bound of the range of o c_ c a t_ m s ts (not inclusive)
	 * @return the range of o c_ c a t_ m s ts
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<OC_CAT_MST> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the o c_ c a t_ m s ts.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.OC_CAT_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of o c_ c a t_ m s ts
	 * @param end the upper bound of the range of o c_ c a t_ m s ts (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of o c_ c a t_ m s ts
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<OC_CAT_MST> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<OC_CAT_MST> list = (List<OC_CAT_MST>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_OC_CAT_MST);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_OC_CAT_MST;

				if (pagination) {
					sql = sql.concat(OC_CAT_MSTModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<OC_CAT_MST>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<OC_CAT_MST>(list);
				}
				else {
					list = (List<OC_CAT_MST>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the o c_ c a t_ m s ts from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (OC_CAT_MST oc_cat_mst : findAll()) {
			remove(oc_cat_mst);
		}
	}

	/**
	 * Returns the number of o c_ c a t_ m s ts.
	 *
	 * @return the number of o c_ c a t_ m s ts
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_OC_CAT_MST);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the o c_ c a t_ m s t persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.jioc.query.model.OC_CAT_MST")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<OC_CAT_MST>> listenersList = new ArrayList<ModelListener<OC_CAT_MST>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<OC_CAT_MST>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(OC_CAT_MSTImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_OC_CAT_MST = "SELECT oc_cat_mst FROM OC_CAT_MST oc_cat_mst";
	private static final String _SQL_COUNT_OC_CAT_MST = "SELECT COUNT(oc_cat_mst) FROM OC_CAT_MST oc_cat_mst";
	private static final String _ORDER_BY_ENTITY_ALIAS = "oc_cat_mst.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No OC_CAT_MST exists with the primary key ";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(OC_CAT_MSTPersistenceImpl.class);
	private static OC_CAT_MST _nullOC_CAT_MST = new OC_CAT_MSTImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<OC_CAT_MST> toCacheModel() {
				return _nullOC_CAT_MSTCacheModel;
			}
		};

	private static CacheModel<OC_CAT_MST> _nullOC_CAT_MSTCacheModel = new CacheModel<OC_CAT_MST>() {
			@Override
			public OC_CAT_MST toEntityModel() {
				return _nullOC_CAT_MST;
			}
		};
}