/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model.impl;

import com.jioc.query.model.OC_CAT_MST;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing OC_CAT_MST in entity cache.
 *
 * @author shantaram.chavan
 * @see OC_CAT_MST
 * @generated
 */
public class OC_CAT_MSTCacheModel implements CacheModel<OC_CAT_MST>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(15);

		sb.append("{CAT_ID=");
		sb.append(CAT_ID);
		sb.append(", CAT_NAME=");
		sb.append(CAT_NAME);
		sb.append(", HPSM_GROUP=");
		sb.append(HPSM_GROUP);
		sb.append(", IS_ACTIVE=");
		sb.append(IS_ACTIVE);
		sb.append(", OC=");
		sb.append(OC);
		sb.append(", RESOLVER_LEVEL=");
		sb.append(RESOLVER_LEVEL);
		sb.append(", UPDATED_TIMESTAMP=");
		sb.append(UPDATED_TIMESTAMP);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public OC_CAT_MST toEntityModel() {
		OC_CAT_MSTImpl oc_cat_mstImpl = new OC_CAT_MSTImpl();

		oc_cat_mstImpl.setCAT_ID(CAT_ID);

		if (CAT_NAME == null) {
			oc_cat_mstImpl.setCAT_NAME(StringPool.BLANK);
		}
		else {
			oc_cat_mstImpl.setCAT_NAME(CAT_NAME);
		}

		if (HPSM_GROUP == null) {
			oc_cat_mstImpl.setHPSM_GROUP(StringPool.BLANK);
		}
		else {
			oc_cat_mstImpl.setHPSM_GROUP(HPSM_GROUP);
		}

		oc_cat_mstImpl.setIS_ACTIVE(IS_ACTIVE);

		if (OC == null) {
			oc_cat_mstImpl.setOC(StringPool.BLANK);
		}
		else {
			oc_cat_mstImpl.setOC(OC);
		}

		oc_cat_mstImpl.setRESOLVER_LEVEL(RESOLVER_LEVEL);

		if (UPDATED_TIMESTAMP == Long.MIN_VALUE) {
			oc_cat_mstImpl.setUPDATED_TIMESTAMP(null);
		}
		else {
			oc_cat_mstImpl.setUPDATED_TIMESTAMP(new Date(UPDATED_TIMESTAMP));
		}

		oc_cat_mstImpl.resetOriginalValues();

		return oc_cat_mstImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		CAT_ID = objectInput.readLong();
		CAT_NAME = objectInput.readUTF();
		HPSM_GROUP = objectInput.readUTF();
		IS_ACTIVE = objectInput.readInt();
		OC = objectInput.readUTF();
		RESOLVER_LEVEL = objectInput.readInt();
		UPDATED_TIMESTAMP = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(CAT_ID);

		if (CAT_NAME == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(CAT_NAME);
		}

		if (HPSM_GROUP == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(HPSM_GROUP);
		}

		objectOutput.writeInt(IS_ACTIVE);

		if (OC == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(OC);
		}

		objectOutput.writeInt(RESOLVER_LEVEL);
		objectOutput.writeLong(UPDATED_TIMESTAMP);
	}

	public long CAT_ID;
	public String CAT_NAME;
	public String HPSM_GROUP;
	public int IS_ACTIVE;
	public String OC;
	public int RESOLVER_LEVEL;
	public long UPDATED_TIMESTAMP;
}