
package com.jioc.hpsm;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.jioc.hpsm package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _JioCentralKeysTypeCallID_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "CallID");
    private final static QName _JioCentralInstanceTypeKnowledgeCandidate_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "KnowledgeCandidate");
    private final static QName _JioCentralInstanceTypeOpenTime_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "OpenTime");
    private final static QName _JioCentralInstanceTypeContactLastName_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ContactLastName");
    private final static QName _JioCentralInstanceTypeSiteCategory_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "SiteCategory");
    private final static QName _JioCentralInstanceTypeAffectedService_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "AffectedService");
    private final static QName _JioCentralInstanceTypeCallOwner_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "CallOwner");
    private final static QName _JioCentralInstanceTypeNotifyBy_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "NotifyBy");
    private final static QName _JioCentralInstanceTypeArea_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Area");
    private final static QName _JioCentralInstanceTypeCauseCode_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "CauseCode");
    private final static QName _JioCentralInstanceTypeUrgency_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Urgency");
    private final static QName _JioCentralInstanceTypeFailedEntitlement_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "FailedEntitlement");
    private final static QName _JioCentralInstanceTypeSubscriptionItem_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "subscriptionItem");
    private final static QName _JioCentralInstanceTypeTotalLossOfService_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "TotalLossOfService");
    private final static QName _JioCentralInstanceTypeProblemType_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ProblemType");
    private final static QName _JioCentralInstanceTypeReportedByExtension_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ReportedByExtension");
    private final static QName _JioCentralInstanceTypeServiceRecipient_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ServiceRecipient");
    private final static QName _JioCentralInstanceTypeReportedByPhone_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ReportedByPhone");
    private final static QName _JioCentralInstanceTypeSLAAgreementID_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "SLAAgreementID");
    private final static QName _JioCentralInstanceTypeCallerDepartment_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "CallerDepartment");
    private final static QName _JioCentralInstanceTypeNeededByTime_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "needed.by.time");
    private final static QName _JioCentralInstanceTypeContactFirstName_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ContactFirstName");
    private final static QName _JioCentralInstanceTypeAffectedCI_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "AffectedCI");
    private final static QName _JioCentralInstanceTypeAttachments_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "attachments");
    private final static QName _JioCentralInstanceTypeOpenedBy_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "OpenedBy");
    private final static QName _JioCentralInstanceTypeNextSLABreach_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "NextSLABreach");
    private final static QName _JioCentralInstanceTypeReportedByFax_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ReportedByFax");
    private final static QName _JioCentralInstanceTypeCompany_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Company");
    private final static QName _JioCentralInstanceTypeServiceContract_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ServiceContract");
    private final static QName _JioCentralInstanceTypeCloseTime_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "CloseTime");
    private final static QName _JioCentralInstanceTypeCallerLocation_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "CallerLocation");
    private final static QName _JioCentralInstanceTypeApprovalStatus_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "approval.status");
    private final static QName _JioCentralInstanceTypeSubarea_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Subarea");
    private final static QName _JioCentralInstanceTypeClosedBy_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ClosedBy");
    private final static QName _JioCentralInstanceTypeCategory_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Category");
    private final static QName _JioCentralInstanceTypeStatus_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Status");
    private final static QName _JioCentralInstanceTypeReportedByContact_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ReportedByContact");
    private final static QName _JioCentralInstanceTypeEnteredByESS_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "EnteredByESS");
    private final static QName _JioCentralInstanceTypeFolder_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "folder");
    private final static QName _JioCentralInstanceTypeReportedByDifferentContact_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ReportedByDifferentContact");
    private final static QName _JioCentralInstanceTypeContactTimeZone_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ContactTimeZone");
    private final static QName _JioCentralInstanceTypeClosureCode_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ClosureCode");
    private final static QName _JioCentralInstanceTypeLocationFullName_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "LocationFullName");
    private final static QName _JioCentralInstanceTypeImpact_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Impact");
    private final static QName _JioCentralInstanceTypeContactEmail_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ContactEmail");
    private final static QName _JioCentralInstanceTypeSLABreached_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "SLABreached");
    private final static QName _JioCentralInstanceTypeContact_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Contact");
    private final static QName _JioCentralInstanceTypeUpdateTime_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "UpdateTime");
    private final static QName _JioCentralInstanceTypeLocation_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Location");
    private final static QName _JioCentralInstanceTypePriority_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Priority");
    private final static QName _JioCentralInstanceTypeTitle_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Title");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.jioc.hpsm
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link JioCentralInstanceType }
     * 
     */
    public JioCentralInstanceType createJioCentralInstanceType() {
        return new JioCentralInstanceType();
    }

    /**
     * Create an instance of {@link RetrieveJioCentralRequest }
     * 
     */
    public RetrieveJioCentralRequest createRetrieveJioCentralRequest() {
        return new RetrieveJioCentralRequest();
    }

    /**
     * Create an instance of {@link JioCentralModelType }
     * 
     */
    public JioCentralModelType createJioCentralModelType() {
        return new JioCentralModelType();
    }

    /**
     * Create an instance of {@link RetrieveJioCentralResponse }
     * 
     */
    public RetrieveJioCentralResponse createRetrieveJioCentralResponse() {
        return new RetrieveJioCentralResponse();
    }

    /**
     * Create an instance of {@link MessagesType }
     * 
     */
    public MessagesType createMessagesType() {
        return new MessagesType();
    }

    /**
     * Create an instance of {@link CreateJioCentralRequest }
     * 
     */
    public CreateJioCentralRequest createCreateJioCentralRequest() {
        return new CreateJioCentralRequest();
    }

    /**
     * Create an instance of {@link RetrieveJioCentralListRequest }
     * 
     */
    public RetrieveJioCentralListRequest createRetrieveJioCentralListRequest() {
        return new RetrieveJioCentralListRequest();
    }

    /**
     * Create an instance of {@link JioCentralKeysType }
     * 
     */
    public JioCentralKeysType createJioCentralKeysType() {
        return new JioCentralKeysType();
    }

    /**
     * Create an instance of {@link RetrieveJioCentralKeysListResponse }
     * 
     */
    public RetrieveJioCentralKeysListResponse createRetrieveJioCentralKeysListResponse() {
        return new RetrieveJioCentralKeysListResponse();
    }

    /**
     * Create an instance of {@link CloseJioCentralResponse }
     * 
     */
    public CloseJioCentralResponse createCloseJioCentralResponse() {
        return new CloseJioCentralResponse();
    }

    /**
     * Create an instance of {@link RetrieveJioCentralListResponse }
     * 
     */
    public RetrieveJioCentralListResponse createRetrieveJioCentralListResponse() {
        return new RetrieveJioCentralListResponse();
    }

    /**
     * Create an instance of {@link RetrieveJioCentralKeysListRequest }
     * 
     */
    public RetrieveJioCentralKeysListRequest createRetrieveJioCentralKeysListRequest() {
        return new RetrieveJioCentralKeysListRequest();
    }

    /**
     * Create an instance of {@link UpdateJioCentralRequest }
     * 
     */
    public UpdateJioCentralRequest createUpdateJioCentralRequest() {
        return new UpdateJioCentralRequest();
    }

    /**
     * Create an instance of {@link UpdateJioCentralResponse }
     * 
     */
    public UpdateJioCentralResponse createUpdateJioCentralResponse() {
        return new UpdateJioCentralResponse();
    }

    /**
     * Create an instance of {@link CreateJioCentralResponse }
     * 
     */
    public CreateJioCentralResponse createCreateJioCentralResponse() {
        return new CreateJioCentralResponse();
    }

    /**
     * Create an instance of {@link CloseJioCentralRequest }
     * 
     */
    public CloseJioCentralRequest createCloseJioCentralRequest() {
        return new CloseJioCentralRequest();
    }

    /**
     * Create an instance of {@link ArrayType }
     * 
     */
    public ArrayType createArrayType() {
        return new ArrayType();
    }

    /**
     * Create an instance of {@link DurationType }
     * 
     */
    public DurationType createDurationType() {
        return new DurationType();
    }

    /**
     * Create an instance of {@link Base64Type }
     * 
     */
    public Base64Type createBase64Type() {
        return new Base64Type();
    }

    /**
     * Create an instance of {@link ShortType }
     * 
     */
    public ShortType createShortType() {
        return new ShortType();
    }

    /**
     * Create an instance of {@link ByteType }
     * 
     */
    public ByteType createByteType() {
        return new ByteType();
    }

    /**
     * Create an instance of {@link LongType }
     * 
     */
    public LongType createLongType() {
        return new LongType();
    }

    /**
     * Create an instance of {@link DecimalType }
     * 
     */
    public DecimalType createDecimalType() {
        return new DecimalType();
    }

    /**
     * Create an instance of {@link AttachmentsType }
     * 
     */
    public AttachmentsType createAttachmentsType() {
        return new AttachmentsType();
    }

    /**
     * Create an instance of {@link StringType }
     * 
     */
    public StringType createStringType() {
        return new StringType();
    }

    /**
     * Create an instance of {@link FloatType }
     * 
     */
    public FloatType createFloatType() {
        return new FloatType();
    }

    /**
     * Create an instance of {@link DateTimeType }
     * 
     */
    public DateTimeType createDateTimeType() {
        return new DateTimeType();
    }

    /**
     * Create an instance of {@link TimeType }
     * 
     */
    public TimeType createTimeType() {
        return new TimeType();
    }

    /**
     * Create an instance of {@link StructureType }
     * 
     */
    public StructureType createStructureType() {
        return new StructureType();
    }

    /**
     * Create an instance of {@link IntType }
     * 
     */
    public IntType createIntType() {
        return new IntType();
    }

    /**
     * Create an instance of {@link DoubleType }
     * 
     */
    public DoubleType createDoubleType() {
        return new DoubleType();
    }

    /**
     * Create an instance of {@link DateType }
     * 
     */
    public DateType createDateType() {
        return new DateType();
    }

    /**
     * Create an instance of {@link MessageType }
     * 
     */
    public MessageType createMessageType() {
        return new MessageType();
    }

    /**
     * Create an instance of {@link BooleanType }
     * 
     */
    public BooleanType createBooleanType() {
        return new BooleanType();
    }

    /**
     * Create an instance of {@link AttachmentType }
     * 
     */
    public AttachmentType createAttachmentType() {
        return new AttachmentType();
    }

    /**
     * Create an instance of {@link JioCentralInstanceType.Description }
     * 
     */
    public JioCentralInstanceType.Description createJioCentralInstanceTypeDescription() {
        return new JioCentralInstanceType.Description();
    }

    /**
     * Create an instance of {@link JioCentralInstanceType.Solution }
     * 
     */
    public JioCentralInstanceType.Solution createJioCentralInstanceTypeSolution() {
        return new JioCentralInstanceType.Solution();
    }

    /**
     * Create an instance of {@link JioCentralInstanceType.Assignment }
     * 
     */
    public JioCentralInstanceType.Assignment createJioCentralInstanceTypeAssignment() {
        return new JioCentralInstanceType.Assignment();
    }

    /**
     * Create an instance of {@link JioCentralInstanceType.Update }
     * 
     */
    public JioCentralInstanceType.Update createJioCentralInstanceTypeUpdate() {
        return new JioCentralInstanceType.Update();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "CallID", scope = JioCentralKeysType.class)
    public JAXBElement<StringType> createJioCentralKeysTypeCallID(StringType value) {
        return new JAXBElement<StringType>(_JioCentralKeysTypeCallID_QNAME, StringType.class, JioCentralKeysType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BooleanType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "KnowledgeCandidate", scope = JioCentralInstanceType.class)
    public JAXBElement<BooleanType> createJioCentralInstanceTypeKnowledgeCandidate(BooleanType value) {
        return new JAXBElement<BooleanType>(_JioCentralInstanceTypeKnowledgeCandidate_QNAME, BooleanType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "OpenTime", scope = JioCentralInstanceType.class)
    public JAXBElement<DateTimeType> createJioCentralInstanceTypeOpenTime(DateTimeType value) {
        return new JAXBElement<DateTimeType>(_JioCentralInstanceTypeOpenTime_QNAME, DateTimeType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ContactLastName", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeContactLastName(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeContactLastName_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "SiteCategory", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeSiteCategory(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeSiteCategory_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "AffectedService", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeAffectedService(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeAffectedService_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "CallOwner", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeCallOwner(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeCallOwner_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "NotifyBy", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeNotifyBy(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeNotifyBy_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Area", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeArea(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeArea_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "CauseCode", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeCauseCode(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeCauseCode_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Urgency", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeUrgency(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeUrgency_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BooleanType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "FailedEntitlement", scope = JioCentralInstanceType.class)
    public JAXBElement<BooleanType> createJioCentralInstanceTypeFailedEntitlement(BooleanType value) {
        return new JAXBElement<BooleanType>(_JioCentralInstanceTypeFailedEntitlement_QNAME, BooleanType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "subscriptionItem", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeSubscriptionItem(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeSubscriptionItem_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BooleanType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "TotalLossOfService", scope = JioCentralInstanceType.class)
    public JAXBElement<BooleanType> createJioCentralInstanceTypeTotalLossOfService(BooleanType value) {
        return new JAXBElement<BooleanType>(_JioCentralInstanceTypeTotalLossOfService_QNAME, BooleanType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ProblemType", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeProblemType(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeProblemType_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ReportedByExtension", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeReportedByExtension(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeReportedByExtension_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ServiceRecipient", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeServiceRecipient(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeServiceRecipient_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ReportedByPhone", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeReportedByPhone(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeReportedByPhone_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IntType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "SLAAgreementID", scope = JioCentralInstanceType.class)
    public JAXBElement<IntType> createJioCentralInstanceTypeSLAAgreementID(IntType value) {
        return new JAXBElement<IntType>(_JioCentralInstanceTypeSLAAgreementID_QNAME, IntType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "CallerDepartment", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeCallerDepartment(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeCallerDepartment_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "needed.by.time", scope = JioCentralInstanceType.class)
    public JAXBElement<DateTimeType> createJioCentralInstanceTypeNeededByTime(DateTimeType value) {
        return new JAXBElement<DateTimeType>(_JioCentralInstanceTypeNeededByTime_QNAME, DateTimeType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ContactFirstName", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeContactFirstName(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeContactFirstName_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "AffectedCI", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeAffectedCI(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeAffectedCI_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AttachmentsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "attachments", scope = JioCentralInstanceType.class)
    public JAXBElement<AttachmentsType> createJioCentralInstanceTypeAttachments(AttachmentsType value) {
        return new JAXBElement<AttachmentsType>(_JioCentralInstanceTypeAttachments_QNAME, AttachmentsType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "OpenedBy", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeOpenedBy(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeOpenedBy_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "NextSLABreach", scope = JioCentralInstanceType.class)
    public JAXBElement<DateTimeType> createJioCentralInstanceTypeNextSLABreach(DateTimeType value) {
        return new JAXBElement<DateTimeType>(_JioCentralInstanceTypeNextSLABreach_QNAME, DateTimeType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ReportedByFax", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeReportedByFax(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeReportedByFax_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Company", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeCompany(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeCompany_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IntType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ServiceContract", scope = JioCentralInstanceType.class)
    public JAXBElement<IntType> createJioCentralInstanceTypeServiceContract(IntType value) {
        return new JAXBElement<IntType>(_JioCentralInstanceTypeServiceContract_QNAME, IntType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "CloseTime", scope = JioCentralInstanceType.class)
    public JAXBElement<DateTimeType> createJioCentralInstanceTypeCloseTime(DateTimeType value) {
        return new JAXBElement<DateTimeType>(_JioCentralInstanceTypeCloseTime_QNAME, DateTimeType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "CallerLocation", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeCallerLocation(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeCallerLocation_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "approval.status", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeApprovalStatus(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeApprovalStatus_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Subarea", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeSubarea(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeSubarea_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ClosedBy", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeClosedBy(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeClosedBy_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Category", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeCategory(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeCategory_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Status", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeStatus(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeStatus_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ReportedByContact", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeReportedByContact(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeReportedByContact_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BooleanType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "EnteredByESS", scope = JioCentralInstanceType.class)
    public JAXBElement<BooleanType> createJioCentralInstanceTypeEnteredByESS(BooleanType value) {
        return new JAXBElement<BooleanType>(_JioCentralInstanceTypeEnteredByESS_QNAME, BooleanType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "folder", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeFolder(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeFolder_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BooleanType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ReportedByDifferentContact", scope = JioCentralInstanceType.class)
    public JAXBElement<BooleanType> createJioCentralInstanceTypeReportedByDifferentContact(BooleanType value) {
        return new JAXBElement<BooleanType>(_JioCentralInstanceTypeReportedByDifferentContact_QNAME, BooleanType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ContactTimeZone", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeContactTimeZone(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeContactTimeZone_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "CallID", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeCallID(StringType value) {
        return new JAXBElement<StringType>(_JioCentralKeysTypeCallID_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ClosureCode", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeClosureCode(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeClosureCode_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "LocationFullName", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeLocationFullName(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeLocationFullName_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Impact", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeImpact(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeImpact_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ContactEmail", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeContactEmail(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeContactEmail_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BooleanType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "SLABreached", scope = JioCentralInstanceType.class)
    public JAXBElement<BooleanType> createJioCentralInstanceTypeSLABreached(BooleanType value) {
        return new JAXBElement<BooleanType>(_JioCentralInstanceTypeSLABreached_QNAME, BooleanType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Contact", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeContact(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeContact_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "UpdateTime", scope = JioCentralInstanceType.class)
    public JAXBElement<DateTimeType> createJioCentralInstanceTypeUpdateTime(DateTimeType value) {
        return new JAXBElement<DateTimeType>(_JioCentralInstanceTypeUpdateTime_QNAME, DateTimeType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Location", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeLocation(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeLocation_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Priority", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypePriority(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypePriority_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Title", scope = JioCentralInstanceType.class)
    public JAXBElement<StringType> createJioCentralInstanceTypeTitle(StringType value) {
        return new JAXBElement<StringType>(_JioCentralInstanceTypeTitle_QNAME, StringType.class, JioCentralInstanceType.class, value);
    }

}
