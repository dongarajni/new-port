
package com.jioc.hpsm.inc;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for JioCentralIncInstanceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JioCentralIncInstanceType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IncidentID" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="Category" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="OpenTime" type="{http://servicecenter.peregrine.com/PWS/Common}DateTimeType" minOccurs="0"/>
 *         &lt;element name="OpenedBy" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="Severity" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="UpdatedTime" type="{http://servicecenter.peregrine.com/PWS/Common}DateTimeType" minOccurs="0"/>
 *         &lt;element name="PrimaryAssignmentGroup" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ClosedTime" type="{http://servicecenter.peregrine.com/PWS/Common}DateTimeType" minOccurs="0"/>
 *         &lt;element name="ClosedBy" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ClosureCode" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="AffectedItem" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="IncidentDescription" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://servicecenter.peregrine.com/PWS/Common}ArrayType">
 *                 &lt;sequence>
 *                   &lt;element name="IncidentDescription" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Resolution" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://servicecenter.peregrine.com/PWS/Common}ArrayType">
 *                 &lt;sequence>
 *                   &lt;element name="Resolution" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="DownTimeEnd" type="{http://servicecenter.peregrine.com/PWS/Common}DateTimeType" minOccurs="0"/>
 *         &lt;element name="AssigneeName" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="Contact" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="JournalUpdates" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://servicecenter.peregrine.com/PWS/Common}ArrayType">
 *                 &lt;sequence>
 *                   &lt;element name="JournalUpdates" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="AlertStatus" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ContactLastName" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ContactFirstName" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="Company" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="BriefDescription" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="TicketOwner" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="UpdatedBy" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="IMTicketStatus" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="Subcategory" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="SLAAgreementID" type="{http://servicecenter.peregrine.com/PWS/Common}DecimalType" minOccurs="0"/>
 *         &lt;element name="SiteCategory" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ProductType" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ProblemType" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ResolutionFixType" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ResolvedBy" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ResolvedTime" type="{http://servicecenter.peregrine.com/PWS/Common}DateTimeType" minOccurs="0"/>
 *         &lt;element name="UserPriority" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="Location" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="Solution" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://servicecenter.peregrine.com/PWS/Common}ArrayType">
 *                 &lt;sequence>
 *                   &lt;element name="Solution" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="InitialImpact" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="folder" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="Service" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="CauseCode" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="attachments" type="{http://servicecenter.peregrine.com/PWS/Common}AttachmentsType" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="query" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="uniquequery" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="recordid" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="updatecounter" type="{http://www.w3.org/2001/XMLSchema}long" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "JioCentralIncInstanceType", namespace = "http://servicecenter.peregrine.com/PWS", propOrder = {
    "incidentID",
    "category",
    "openTime",
    "openedBy",
    "severity",
    "updatedTime",
    "primaryAssignmentGroup",
    "closedTime",
    "closedBy",
    "closureCode",
    "affectedItem",
    "incidentDescription",
    "resolution",
    "downTimeEnd",
    "assigneeName",
    "contact",
    "journalUpdates",
    "alertStatus",
    "contactLastName",
    "contactFirstName",
    "company",
    "briefDescription",
    "ticketOwner",
    "updatedBy",
    "imTicketStatus",
    "subcategory",
    "slaAgreementID",
    "siteCategory",
    "productType",
    "problemType",
    "resolutionFixType",
    "resolvedBy",
    "resolvedTime",
    "userPriority",
    "location",
    "solution",
    "initialImpact",
    "folder",
    "service",
    "causeCode",
    "attachments"
})
public class JioCentralIncInstanceType {

    @XmlElementRef(name = "IncidentID", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> incidentID;
    @XmlElementRef(name = "Category", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> category;
    @XmlElementRef(name = "OpenTime", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<DateTimeType> openTime;
    @XmlElementRef(name = "OpenedBy", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> openedBy;
    @XmlElementRef(name = "Severity", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> severity;
    @XmlElementRef(name = "UpdatedTime", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<DateTimeType> updatedTime;
    @XmlElementRef(name = "PrimaryAssignmentGroup", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> primaryAssignmentGroup;
    @XmlElementRef(name = "ClosedTime", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<DateTimeType> closedTime;
    @XmlElementRef(name = "ClosedBy", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> closedBy;
    @XmlElementRef(name = "ClosureCode", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> closureCode;
    @XmlElementRef(name = "AffectedItem", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> affectedItem;
    @XmlElement(name = "IncidentDescription")
    protected JioCentralIncInstanceType.IncidentDescription incidentDescription;
    @XmlElement(name = "Resolution")
    protected JioCentralIncInstanceType.Resolution resolution;
    @XmlElementRef(name = "DownTimeEnd", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<DateTimeType> downTimeEnd;
    @XmlElementRef(name = "AssigneeName", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> assigneeName;
    @XmlElementRef(name = "Contact", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> contact;
    @XmlElement(name = "JournalUpdates")
    protected JioCentralIncInstanceType.JournalUpdates journalUpdates;
    @XmlElementRef(name = "AlertStatus", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> alertStatus;
    @XmlElementRef(name = "ContactLastName", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> contactLastName;
    @XmlElementRef(name = "ContactFirstName", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> contactFirstName;
    @XmlElementRef(name = "Company", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> company;
    @XmlElementRef(name = "BriefDescription", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> briefDescription;
    @XmlElementRef(name = "TicketOwner", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> ticketOwner;
    @XmlElementRef(name = "UpdatedBy", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> updatedBy;
    @XmlElementRef(name = "IMTicketStatus", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> imTicketStatus;
    @XmlElementRef(name = "Subcategory", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> subcategory;
    @XmlElementRef(name = "SLAAgreementID", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<DecimalType> slaAgreementID;
    @XmlElementRef(name = "SiteCategory", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> siteCategory;
    @XmlElementRef(name = "ProductType", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> productType;
    @XmlElementRef(name = "ProblemType", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> problemType;
    @XmlElementRef(name = "ResolutionFixType", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> resolutionFixType;
    @XmlElementRef(name = "ResolvedBy", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> resolvedBy;
    @XmlElementRef(name = "ResolvedTime", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<DateTimeType> resolvedTime;
    @XmlElementRef(name = "UserPriority", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> userPriority;
    @XmlElementRef(name = "Location", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> location;
    @XmlElement(name = "Solution")
    protected JioCentralIncInstanceType.Solution solution;
    @XmlElementRef(name = "InitialImpact", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> initialImpact;
    @XmlElementRef(name = "folder", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> folder;
    @XmlElementRef(name = "Service", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> service;
    @XmlElementRef(name = "CauseCode", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> causeCode;
    @XmlElementRef(name = "attachments", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<AttachmentsType> attachments;
    @XmlAttribute(name = "query")
    protected String query;
    @XmlAttribute(name = "uniquequery")
    protected String uniquequery;
    @XmlAttribute(name = "recordid")
    protected String recordid;
    @XmlAttribute(name = "updatecounter")
    protected Long updatecounter;

    /**
     * Gets the value of the incidentID property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getIncidentID() {
        return incidentID;
    }

    /**
     * Sets the value of the incidentID property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setIncidentID(JAXBElement<StringType> value) {
        this.incidentID = value;
    }

    /**
     * Gets the value of the category property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getCategory() {
        return category;
    }

    /**
     * Sets the value of the category property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setCategory(JAXBElement<StringType> value) {
        this.category = value;
    }

    /**
     * Gets the value of the openTime property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public JAXBElement<DateTimeType> getOpenTime() {
        return openTime;
    }

    /**
     * Sets the value of the openTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public void setOpenTime(JAXBElement<DateTimeType> value) {
        this.openTime = value;
    }

    /**
     * Gets the value of the openedBy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getOpenedBy() {
        return openedBy;
    }

    /**
     * Sets the value of the openedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setOpenedBy(JAXBElement<StringType> value) {
        this.openedBy = value;
    }

    /**
     * Gets the value of the severity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getSeverity() {
        return severity;
    }

    /**
     * Sets the value of the severity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setSeverity(JAXBElement<StringType> value) {
        this.severity = value;
    }

    /**
     * Gets the value of the updatedTime property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public JAXBElement<DateTimeType> getUpdatedTime() {
        return updatedTime;
    }

    /**
     * Sets the value of the updatedTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public void setUpdatedTime(JAXBElement<DateTimeType> value) {
        this.updatedTime = value;
    }

    /**
     * Gets the value of the primaryAssignmentGroup property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getPrimaryAssignmentGroup() {
        return primaryAssignmentGroup;
    }

    /**
     * Sets the value of the primaryAssignmentGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setPrimaryAssignmentGroup(JAXBElement<StringType> value) {
        this.primaryAssignmentGroup = value;
    }

    /**
     * Gets the value of the closedTime property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public JAXBElement<DateTimeType> getClosedTime() {
        return closedTime;
    }

    /**
     * Sets the value of the closedTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public void setClosedTime(JAXBElement<DateTimeType> value) {
        this.closedTime = value;
    }

    /**
     * Gets the value of the closedBy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getClosedBy() {
        return closedBy;
    }

    /**
     * Sets the value of the closedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setClosedBy(JAXBElement<StringType> value) {
        this.closedBy = value;
    }

    /**
     * Gets the value of the closureCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getClosureCode() {
        return closureCode;
    }

    /**
     * Sets the value of the closureCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setClosureCode(JAXBElement<StringType> value) {
        this.closureCode = value;
    }

    /**
     * Gets the value of the affectedItem property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getAffectedItem() {
        return affectedItem;
    }

    /**
     * Sets the value of the affectedItem property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setAffectedItem(JAXBElement<StringType> value) {
        this.affectedItem = value;
    }

    /**
     * Gets the value of the incidentDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JioCentralIncInstanceType.IncidentDescription }
     *     
     */
    public JioCentralIncInstanceType.IncidentDescription getIncidentDescription() {
        return incidentDescription;
    }

    /**
     * Sets the value of the incidentDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JioCentralIncInstanceType.IncidentDescription }
     *     
     */
    public void setIncidentDescription(JioCentralIncInstanceType.IncidentDescription value) {
        this.incidentDescription = value;
    }

    /**
     * Gets the value of the resolution property.
     * 
     * @return
     *     possible object is
     *     {@link JioCentralIncInstanceType.Resolution }
     *     
     */
    public JioCentralIncInstanceType.Resolution getResolution() {
        return resolution;
    }

    /**
     * Sets the value of the resolution property.
     * 
     * @param value
     *     allowed object is
     *     {@link JioCentralIncInstanceType.Resolution }
     *     
     */
    public void setResolution(JioCentralIncInstanceType.Resolution value) {
        this.resolution = value;
    }

    /**
     * Gets the value of the downTimeEnd property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public JAXBElement<DateTimeType> getDownTimeEnd() {
        return downTimeEnd;
    }

    /**
     * Sets the value of the downTimeEnd property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public void setDownTimeEnd(JAXBElement<DateTimeType> value) {
        this.downTimeEnd = value;
    }

    /**
     * Gets the value of the assigneeName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getAssigneeName() {
        return assigneeName;
    }

    /**
     * Sets the value of the assigneeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setAssigneeName(JAXBElement<StringType> value) {
        this.assigneeName = value;
    }

    /**
     * Gets the value of the contact property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getContact() {
        return contact;
    }

    /**
     * Sets the value of the contact property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setContact(JAXBElement<StringType> value) {
        this.contact = value;
    }

    /**
     * Gets the value of the journalUpdates property.
     * 
     * @return
     *     possible object is
     *     {@link JioCentralIncInstanceType.JournalUpdates }
     *     
     */
    public JioCentralIncInstanceType.JournalUpdates getJournalUpdates() {
        return journalUpdates;
    }

    /**
     * Sets the value of the journalUpdates property.
     * 
     * @param value
     *     allowed object is
     *     {@link JioCentralIncInstanceType.JournalUpdates }
     *     
     */
    public void setJournalUpdates(JioCentralIncInstanceType.JournalUpdates value) {
        this.journalUpdates = value;
    }

    /**
     * Gets the value of the alertStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getAlertStatus() {
        return alertStatus;
    }

    /**
     * Sets the value of the alertStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setAlertStatus(JAXBElement<StringType> value) {
        this.alertStatus = value;
    }

    /**
     * Gets the value of the contactLastName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getContactLastName() {
        return contactLastName;
    }

    /**
     * Sets the value of the contactLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setContactLastName(JAXBElement<StringType> value) {
        this.contactLastName = value;
    }

    /**
     * Gets the value of the contactFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getContactFirstName() {
        return contactFirstName;
    }

    /**
     * Sets the value of the contactFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setContactFirstName(JAXBElement<StringType> value) {
        this.contactFirstName = value;
    }

    /**
     * Gets the value of the company property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getCompany() {
        return company;
    }

    /**
     * Sets the value of the company property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setCompany(JAXBElement<StringType> value) {
        this.company = value;
    }

    /**
     * Gets the value of the briefDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getBriefDescription() {
        return briefDescription;
    }

    /**
     * Sets the value of the briefDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setBriefDescription(JAXBElement<StringType> value) {
        this.briefDescription = value;
    }

    /**
     * Gets the value of the ticketOwner property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getTicketOwner() {
        return ticketOwner;
    }

    /**
     * Sets the value of the ticketOwner property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setTicketOwner(JAXBElement<StringType> value) {
        this.ticketOwner = value;
    }

    /**
     * Gets the value of the updatedBy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getUpdatedBy() {
        return updatedBy;
    }

    /**
     * Sets the value of the updatedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setUpdatedBy(JAXBElement<StringType> value) {
        this.updatedBy = value;
    }

    /**
     * Gets the value of the imTicketStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getIMTicketStatus() {
        return imTicketStatus;
    }

    /**
     * Sets the value of the imTicketStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setIMTicketStatus(JAXBElement<StringType> value) {
        this.imTicketStatus = value;
    }

    /**
     * Gets the value of the subcategory property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getSubcategory() {
        return subcategory;
    }

    /**
     * Sets the value of the subcategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setSubcategory(JAXBElement<StringType> value) {
        this.subcategory = value;
    }

    /**
     * Gets the value of the slaAgreementID property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link DecimalType }{@code >}
     *     
     */
    public JAXBElement<DecimalType> getSLAAgreementID() {
        return slaAgreementID;
    }

    /**
     * Sets the value of the slaAgreementID property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link DecimalType }{@code >}
     *     
     */
    public void setSLAAgreementID(JAXBElement<DecimalType> value) {
        this.slaAgreementID = value;
    }

    /**
     * Gets the value of the siteCategory property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getSiteCategory() {
        return siteCategory;
    }

    /**
     * Sets the value of the siteCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setSiteCategory(JAXBElement<StringType> value) {
        this.siteCategory = value;
    }

    /**
     * Gets the value of the productType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getProductType() {
        return productType;
    }

    /**
     * Sets the value of the productType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setProductType(JAXBElement<StringType> value) {
        this.productType = value;
    }

    /**
     * Gets the value of the problemType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getProblemType() {
        return problemType;
    }

    /**
     * Sets the value of the problemType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setProblemType(JAXBElement<StringType> value) {
        this.problemType = value;
    }

    /**
     * Gets the value of the resolutionFixType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getResolutionFixType() {
        return resolutionFixType;
    }

    /**
     * Sets the value of the resolutionFixType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setResolutionFixType(JAXBElement<StringType> value) {
        this.resolutionFixType = value;
    }

    /**
     * Gets the value of the resolvedBy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getResolvedBy() {
        return resolvedBy;
    }

    /**
     * Sets the value of the resolvedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setResolvedBy(JAXBElement<StringType> value) {
        this.resolvedBy = value;
    }

    /**
     * Gets the value of the resolvedTime property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public JAXBElement<DateTimeType> getResolvedTime() {
        return resolvedTime;
    }

    /**
     * Sets the value of the resolvedTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public void setResolvedTime(JAXBElement<DateTimeType> value) {
        this.resolvedTime = value;
    }

    /**
     * Gets the value of the userPriority property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getUserPriority() {
        return userPriority;
    }

    /**
     * Sets the value of the userPriority property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setUserPriority(JAXBElement<StringType> value) {
        this.userPriority = value;
    }

    /**
     * Gets the value of the location property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setLocation(JAXBElement<StringType> value) {
        this.location = value;
    }

    /**
     * Gets the value of the solution property.
     * 
     * @return
     *     possible object is
     *     {@link JioCentralIncInstanceType.Solution }
     *     
     */
    public JioCentralIncInstanceType.Solution getSolution() {
        return solution;
    }

    /**
     * Sets the value of the solution property.
     * 
     * @param value
     *     allowed object is
     *     {@link JioCentralIncInstanceType.Solution }
     *     
     */
    public void setSolution(JioCentralIncInstanceType.Solution value) {
        this.solution = value;
    }

    /**
     * Gets the value of the initialImpact property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getInitialImpact() {
        return initialImpact;
    }

    /**
     * Sets the value of the initialImpact property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setInitialImpact(JAXBElement<StringType> value) {
        this.initialImpact = value;
    }

    /**
     * Gets the value of the folder property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getFolder() {
        return folder;
    }

    /**
     * Sets the value of the folder property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setFolder(JAXBElement<StringType> value) {
        this.folder = value;
    }

    /**
     * Gets the value of the service property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getService() {
        return service;
    }

    /**
     * Sets the value of the service property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setService(JAXBElement<StringType> value) {
        this.service = value;
    }

    /**
     * Gets the value of the causeCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getCauseCode() {
        return causeCode;
    }

    /**
     * Sets the value of the causeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setCauseCode(JAXBElement<StringType> value) {
        this.causeCode = value;
    }

    /**
     * Gets the value of the attachments property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AttachmentsType }{@code >}
     *     
     */
    public JAXBElement<AttachmentsType> getAttachments() {
        return attachments;
    }

    /**
     * Sets the value of the attachments property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AttachmentsType }{@code >}
     *     
     */
    public void setAttachments(JAXBElement<AttachmentsType> value) {
        this.attachments = value;
    }

    /**
     * Gets the value of the query property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuery() {
        return query;
    }

    /**
     * Sets the value of the query property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuery(String value) {
        this.query = value;
    }

    /**
     * Gets the value of the uniquequery property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUniquequery() {
        return uniquequery;
    }

    /**
     * Sets the value of the uniquequery property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUniquequery(String value) {
        this.uniquequery = value;
    }

    /**
     * Gets the value of the recordid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecordid() {
        return recordid;
    }

    /**
     * Sets the value of the recordid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecordid(String value) {
        this.recordid = value;
    }

    /**
     * Gets the value of the updatecounter property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getUpdatecounter() {
        return updatecounter;
    }

    /**
     * Sets the value of the updatecounter property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setUpdatecounter(Long value) {
        this.updatecounter = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://servicecenter.peregrine.com/PWS/Common}ArrayType">
     *       &lt;sequence>
     *         &lt;element name="IncidentDescription" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "incidentDescription"
    })
    public static class IncidentDescription
        extends ArrayType
    {

        @XmlElement(name = "IncidentDescription", namespace = "http://servicecenter.peregrine.com/PWS")
        protected List<StringType> incidentDescription;

        /**
         * Gets the value of the incidentDescription property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the incidentDescription property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getIncidentDescription().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StringType }
         * 
         * 
         */
        public List<StringType> getIncidentDescription() {
            if (incidentDescription == null) {
                incidentDescription = new ArrayList<StringType>();
            }
            return this.incidentDescription;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://servicecenter.peregrine.com/PWS/Common}ArrayType">
     *       &lt;sequence>
     *         &lt;element name="JournalUpdates" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "journalUpdates"
    })
    public static class JournalUpdates
        extends ArrayType
    {

        @XmlElement(name = "JournalUpdates", namespace = "http://servicecenter.peregrine.com/PWS")
        protected List<StringType> journalUpdates;

        /**
         * Gets the value of the journalUpdates property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the journalUpdates property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getJournalUpdates().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StringType }
         * 
         * 
         */
        public List<StringType> getJournalUpdates() {
            if (journalUpdates == null) {
                journalUpdates = new ArrayList<StringType>();
            }
            return this.journalUpdates;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://servicecenter.peregrine.com/PWS/Common}ArrayType">
     *       &lt;sequence>
     *         &lt;element name="Resolution" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "resolution"
    })
    public static class Resolution
        extends ArrayType
    {

        @XmlElement(name = "Resolution", namespace = "http://servicecenter.peregrine.com/PWS")
        protected List<StringType> resolution;

        /**
         * Gets the value of the resolution property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the resolution property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getResolution().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StringType }
         * 
         * 
         */
        public List<StringType> getResolution() {
            if (resolution == null) {
                resolution = new ArrayList<StringType>();
            }
            return this.resolution;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://servicecenter.peregrine.com/PWS/Common}ArrayType">
     *       &lt;sequence>
     *         &lt;element name="Solution" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "solution"
    })
    public static class Solution
        extends ArrayType
    {

        @XmlElement(name = "Solution", namespace = "http://servicecenter.peregrine.com/PWS")
        protected List<StringType> solution;

        /**
         * Gets the value of the solution property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the solution property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getSolution().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StringType }
         * 
         * 
         */
        public List<StringType> getSolution() {
            if (solution == null) {
                solution = new ArrayList<StringType>();
            }
            return this.solution;
        }

    }

}
