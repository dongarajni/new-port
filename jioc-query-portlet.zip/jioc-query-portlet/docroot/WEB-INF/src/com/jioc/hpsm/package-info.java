@javax.xml.bind.annotation.XmlSchema(namespace = "http://servicecenter.peregrine.com/PWS/Common", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.jioc.hpsm;
