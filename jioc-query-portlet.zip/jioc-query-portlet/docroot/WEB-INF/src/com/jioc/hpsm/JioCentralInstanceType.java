
package com.jioc.hpsm;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for JioCentralInstanceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JioCentralInstanceType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CallID" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ServiceRecipient" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="Urgency" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="OpenTime" type="{http://servicecenter.peregrine.com/PWS/Common}DateTimeType" minOccurs="0"/>
 *         &lt;element name="UpdateTime" type="{http://servicecenter.peregrine.com/PWS/Common}DateTimeType" minOccurs="0"/>
 *         &lt;element name="OpenedBy" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="Description" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://servicecenter.peregrine.com/PWS/Common}ArrayType">
 *                 &lt;sequence>
 *                   &lt;element name="Description" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="AffectedService" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="CallOwner" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="Status" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="NotifyBy" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="Solution" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://servicecenter.peregrine.com/PWS/Common}ArrayType">
 *                 &lt;sequence>
 *                   &lt;element name="Solution" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Assignment" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://servicecenter.peregrine.com/PWS/Common}ArrayType">
 *                 &lt;sequence>
 *                   &lt;element name="Assignment" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Category" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="CallerDepartment" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="CallerLocation" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="CloseTime" type="{http://servicecenter.peregrine.com/PWS/Common}DateTimeType" minOccurs="0"/>
 *         &lt;element name="ClosedBy" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="KnowledgeCandidate" type="{http://servicecenter.peregrine.com/PWS/Common}BooleanType" minOccurs="0"/>
 *         &lt;element name="SLAAgreementID" type="{http://servicecenter.peregrine.com/PWS/Common}IntType" minOccurs="0"/>
 *         &lt;element name="Priority" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ServiceContract" type="{http://servicecenter.peregrine.com/PWS/Common}IntType" minOccurs="0"/>
 *         &lt;element name="SiteCategory" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="TotalLossOfService" type="{http://servicecenter.peregrine.com/PWS/Common}BooleanType" minOccurs="0"/>
 *         &lt;element name="Area" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="Subarea" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ProblemType" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="FailedEntitlement" type="{http://servicecenter.peregrine.com/PWS/Common}BooleanType" minOccurs="0"/>
 *         &lt;element name="Location" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="CauseCode" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ClosureCode" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="Company" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ReportedByContact" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ReportedByDifferentContact" type="{http://servicecenter.peregrine.com/PWS/Common}BooleanType" minOccurs="0"/>
 *         &lt;element name="ReportedByPhone" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ReportedByExtension" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ReportedByFax" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ContactEmail" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="LocationFullName" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ContactFirstName" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ContactLastName" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="ContactTimeZone" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="EnteredByESS" type="{http://servicecenter.peregrine.com/PWS/Common}BooleanType" minOccurs="0"/>
 *         &lt;element name="SLABreached" type="{http://servicecenter.peregrine.com/PWS/Common}BooleanType" minOccurs="0"/>
 *         &lt;element name="NextSLABreach" type="{http://servicecenter.peregrine.com/PWS/Common}DateTimeType" minOccurs="0"/>
 *         &lt;element name="Contact" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="Update" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://servicecenter.peregrine.com/PWS/Common}ArrayType">
 *                 &lt;sequence>
 *                   &lt;element name="Update" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Impact" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="needed.by.time" type="{http://servicecenter.peregrine.com/PWS/Common}DateTimeType" minOccurs="0"/>
 *         &lt;element name="approval.status" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="folder" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="subscriptionItem" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="AffectedCI" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="Title" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" minOccurs="0"/>
 *         &lt;element name="attachments" type="{http://servicecenter.peregrine.com/PWS/Common}AttachmentsType" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="query" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="uniquequery" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="recordid" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="updatecounter" type="{http://www.w3.org/2001/XMLSchema}long" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "JioCentralInstanceType", namespace = "http://servicecenter.peregrine.com/PWS", propOrder = {
    "callID",
    "serviceRecipient",
    "urgency",
    "openTime",
    "updateTime",
    "openedBy",
    "description",
    "affectedService",
    "callOwner",
    "status",
    "notifyBy",
    "solution",
    "assignment",
    "category",
    "callerDepartment",
    "callerLocation",
    "closeTime",
    "closedBy",
    "knowledgeCandidate",
    "slaAgreementID",
    "priority",
    "serviceContract",
    "siteCategory",
    "totalLossOfService",
    "area",
    "subarea",
    "problemType",
    "failedEntitlement",
    "location",
    "causeCode",
    "closureCode",
    "company",
    "reportedByContact",
    "reportedByDifferentContact",
    "reportedByPhone",
    "reportedByExtension",
    "reportedByFax",
    "contactEmail",
    "locationFullName",
    "contactFirstName",
    "contactLastName",
    "contactTimeZone",
    "enteredByESS",
    "slaBreached",
    "nextSLABreach",
    "contact",
    "update",
    "impact",
    "neededByTime",
    "approvalStatus",
    "folder",
    "subscriptionItem",
    "affectedCI",
    "title",
    "attachments"
})
public class JioCentralInstanceType {

    @XmlElementRef(name = "CallID", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> callID;
    @XmlElementRef(name = "ServiceRecipient", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> serviceRecipient;
    @XmlElementRef(name = "Urgency", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> urgency;
    @XmlElementRef(name = "OpenTime", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<DateTimeType> openTime;
    @XmlElementRef(name = "UpdateTime", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<DateTimeType> updateTime;
    @XmlElementRef(name = "OpenedBy", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> openedBy;
    @XmlElement(name = "Description")
    protected JioCentralInstanceType.Description description;
    @XmlElementRef(name = "AffectedService", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> affectedService;
    @XmlElementRef(name = "CallOwner", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> callOwner;
    @XmlElementRef(name = "Status", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> status;
    @XmlElementRef(name = "NotifyBy", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> notifyBy;
    @XmlElement(name = "Solution")
    protected JioCentralInstanceType.Solution solution;
    @XmlElement(name = "Assignment")
    protected JioCentralInstanceType.Assignment assignment;
    @XmlElementRef(name = "Category", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> category;
    @XmlElementRef(name = "CallerDepartment", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> callerDepartment;
    @XmlElementRef(name = "CallerLocation", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> callerLocation;
    @XmlElementRef(name = "CloseTime", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<DateTimeType> closeTime;
    @XmlElementRef(name = "ClosedBy", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> closedBy;
    @XmlElementRef(name = "KnowledgeCandidate", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<BooleanType> knowledgeCandidate;
    @XmlElementRef(name = "SLAAgreementID", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<IntType> slaAgreementID;
    @XmlElementRef(name = "Priority", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> priority;
    @XmlElementRef(name = "ServiceContract", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<IntType> serviceContract;
    @XmlElementRef(name = "SiteCategory", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> siteCategory;
    @XmlElementRef(name = "TotalLossOfService", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<BooleanType> totalLossOfService;
    @XmlElementRef(name = "Area", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> area;
    @XmlElementRef(name = "Subarea", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> subarea;
    @XmlElementRef(name = "ProblemType", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> problemType;
    @XmlElementRef(name = "FailedEntitlement", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<BooleanType> failedEntitlement;
    @XmlElementRef(name = "Location", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> location;
    @XmlElementRef(name = "CauseCode", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> causeCode;
    @XmlElementRef(name = "ClosureCode", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> closureCode;
    @XmlElementRef(name = "Company", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> company;
    @XmlElementRef(name = "ReportedByContact", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> reportedByContact;
    @XmlElementRef(name = "ReportedByDifferentContact", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<BooleanType> reportedByDifferentContact;
    @XmlElementRef(name = "ReportedByPhone", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> reportedByPhone;
    @XmlElementRef(name = "ReportedByExtension", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> reportedByExtension;
    @XmlElementRef(name = "ReportedByFax", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> reportedByFax;
    @XmlElementRef(name = "ContactEmail", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> contactEmail;
    @XmlElementRef(name = "LocationFullName", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> locationFullName;
    @XmlElementRef(name = "ContactFirstName", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> contactFirstName;
    @XmlElementRef(name = "ContactLastName", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> contactLastName;
    @XmlElementRef(name = "ContactTimeZone", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> contactTimeZone;
    @XmlElementRef(name = "EnteredByESS", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<BooleanType> enteredByESS;
    @XmlElementRef(name = "SLABreached", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<BooleanType> slaBreached;
    @XmlElementRef(name = "NextSLABreach", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<DateTimeType> nextSLABreach;
    @XmlElementRef(name = "Contact", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> contact;
    @XmlElement(name = "Update")
    protected JioCentralInstanceType.Update update;
    @XmlElementRef(name = "Impact", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> impact;
    @XmlElementRef(name = "needed.by.time", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<DateTimeType> neededByTime;
    @XmlElementRef(name = "approval.status", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> approvalStatus;
    @XmlElementRef(name = "folder", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> folder;
    @XmlElementRef(name = "subscriptionItem", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> subscriptionItem;
    @XmlElementRef(name = "AffectedCI", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> affectedCI;
    @XmlElementRef(name = "Title", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<StringType> title;
    @XmlElementRef(name = "attachments", namespace = "http://servicecenter.peregrine.com/PWS", type = JAXBElement.class, required = false)
    protected JAXBElement<AttachmentsType> attachments;
    @XmlAttribute(name = "query")
    protected String query;
    @XmlAttribute(name = "uniquequery")
    protected String uniquequery;
    @XmlAttribute(name = "recordid")
    protected String recordid;
    @XmlAttribute(name = "updatecounter")
    protected Long updatecounter;

    /**
     * Gets the value of the callID property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getCallID() {
        return callID;
    }

    /**
     * Sets the value of the callID property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setCallID(JAXBElement<StringType> value) {
        this.callID = value;
    }

    /**
     * Gets the value of the serviceRecipient property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getServiceRecipient() {
        return serviceRecipient;
    }

    /**
     * Sets the value of the serviceRecipient property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setServiceRecipient(JAXBElement<StringType> value) {
        this.serviceRecipient = value;
    }

    /**
     * Gets the value of the urgency property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getUrgency() {
        return urgency;
    }

    /**
     * Sets the value of the urgency property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setUrgency(JAXBElement<StringType> value) {
        this.urgency = value;
    }

    /**
     * Gets the value of the openTime property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public JAXBElement<DateTimeType> getOpenTime() {
        return openTime;
    }

    /**
     * Sets the value of the openTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public void setOpenTime(JAXBElement<DateTimeType> value) {
        this.openTime = value;
    }

    /**
     * Gets the value of the updateTime property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public JAXBElement<DateTimeType> getUpdateTime() {
        return updateTime;
    }

    /**
     * Sets the value of the updateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public void setUpdateTime(JAXBElement<DateTimeType> value) {
        this.updateTime = value;
    }

    /**
     * Gets the value of the openedBy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getOpenedBy() {
        return openedBy;
    }

    /**
     * Sets the value of the openedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setOpenedBy(JAXBElement<StringType> value) {
        this.openedBy = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JioCentralInstanceType.Description }
     *     
     */
    public JioCentralInstanceType.Description getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JioCentralInstanceType.Description }
     *     
     */
    public void setDescription(JioCentralInstanceType.Description value) {
        this.description = value;
    }

    /**
     * Gets the value of the affectedService property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getAffectedService() {
        return affectedService;
    }

    /**
     * Sets the value of the affectedService property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setAffectedService(JAXBElement<StringType> value) {
        this.affectedService = value;
    }

    /**
     * Gets the value of the callOwner property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getCallOwner() {
        return callOwner;
    }

    /**
     * Sets the value of the callOwner property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setCallOwner(JAXBElement<StringType> value) {
        this.callOwner = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setStatus(JAXBElement<StringType> value) {
        this.status = value;
    }

    /**
     * Gets the value of the notifyBy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getNotifyBy() {
        return notifyBy;
    }

    /**
     * Sets the value of the notifyBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setNotifyBy(JAXBElement<StringType> value) {
        this.notifyBy = value;
    }

    /**
     * Gets the value of the solution property.
     * 
     * @return
     *     possible object is
     *     {@link JioCentralInstanceType.Solution }
     *     
     */
    public JioCentralInstanceType.Solution getSolution() {
        return solution;
    }

    /**
     * Sets the value of the solution property.
     * 
     * @param value
     *     allowed object is
     *     {@link JioCentralInstanceType.Solution }
     *     
     */
    public void setSolution(JioCentralInstanceType.Solution value) {
        this.solution = value;
    }

    /**
     * Gets the value of the assignment property.
     * 
     * @return
     *     possible object is
     *     {@link JioCentralInstanceType.Assignment }
     *     
     */
    public JioCentralInstanceType.Assignment getAssignment() {
        return assignment;
    }

    /**
     * Sets the value of the assignment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JioCentralInstanceType.Assignment }
     *     
     */
    public void setAssignment(JioCentralInstanceType.Assignment value) {
        this.assignment = value;
    }

    /**
     * Gets the value of the category property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getCategory() {
        return category;
    }

    /**
     * Sets the value of the category property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setCategory(JAXBElement<StringType> value) {
        this.category = value;
    }

    /**
     * Gets the value of the callerDepartment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getCallerDepartment() {
        return callerDepartment;
    }

    /**
     * Sets the value of the callerDepartment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setCallerDepartment(JAXBElement<StringType> value) {
        this.callerDepartment = value;
    }

    /**
     * Gets the value of the callerLocation property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getCallerLocation() {
        return callerLocation;
    }

    /**
     * Sets the value of the callerLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setCallerLocation(JAXBElement<StringType> value) {
        this.callerLocation = value;
    }

    /**
     * Gets the value of the closeTime property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public JAXBElement<DateTimeType> getCloseTime() {
        return closeTime;
    }

    /**
     * Sets the value of the closeTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public void setCloseTime(JAXBElement<DateTimeType> value) {
        this.closeTime = value;
    }

    /**
     * Gets the value of the closedBy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getClosedBy() {
        return closedBy;
    }

    /**
     * Sets the value of the closedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setClosedBy(JAXBElement<StringType> value) {
        this.closedBy = value;
    }

    /**
     * Gets the value of the knowledgeCandidate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BooleanType }{@code >}
     *     
     */
    public JAXBElement<BooleanType> getKnowledgeCandidate() {
        return knowledgeCandidate;
    }

    /**
     * Sets the value of the knowledgeCandidate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BooleanType }{@code >}
     *     
     */
    public void setKnowledgeCandidate(JAXBElement<BooleanType> value) {
        this.knowledgeCandidate = value;
    }

    /**
     * Gets the value of the slaAgreementID property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link IntType }{@code >}
     *     
     */
    public JAXBElement<IntType> getSLAAgreementID() {
        return slaAgreementID;
    }

    /**
     * Sets the value of the slaAgreementID property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link IntType }{@code >}
     *     
     */
    public void setSLAAgreementID(JAXBElement<IntType> value) {
        this.slaAgreementID = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setPriority(JAXBElement<StringType> value) {
        this.priority = value;
    }

    /**
     * Gets the value of the serviceContract property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link IntType }{@code >}
     *     
     */
    public JAXBElement<IntType> getServiceContract() {
        return serviceContract;
    }

    /**
     * Sets the value of the serviceContract property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link IntType }{@code >}
     *     
     */
    public void setServiceContract(JAXBElement<IntType> value) {
        this.serviceContract = value;
    }

    /**
     * Gets the value of the siteCategory property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getSiteCategory() {
        return siteCategory;
    }

    /**
     * Sets the value of the siteCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setSiteCategory(JAXBElement<StringType> value) {
        this.siteCategory = value;
    }

    /**
     * Gets the value of the totalLossOfService property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BooleanType }{@code >}
     *     
     */
    public JAXBElement<BooleanType> getTotalLossOfService() {
        return totalLossOfService;
    }

    /**
     * Sets the value of the totalLossOfService property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BooleanType }{@code >}
     *     
     */
    public void setTotalLossOfService(JAXBElement<BooleanType> value) {
        this.totalLossOfService = value;
    }

    /**
     * Gets the value of the area property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getArea() {
        return area;
    }

    /**
     * Sets the value of the area property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setArea(JAXBElement<StringType> value) {
        this.area = value;
    }

    /**
     * Gets the value of the subarea property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getSubarea() {
        return subarea;
    }

    /**
     * Sets the value of the subarea property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setSubarea(JAXBElement<StringType> value) {
        this.subarea = value;
    }

    /**
     * Gets the value of the problemType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getProblemType() {
        return problemType;
    }

    /**
     * Sets the value of the problemType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setProblemType(JAXBElement<StringType> value) {
        this.problemType = value;
    }

    /**
     * Gets the value of the failedEntitlement property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BooleanType }{@code >}
     *     
     */
    public JAXBElement<BooleanType> getFailedEntitlement() {
        return failedEntitlement;
    }

    /**
     * Sets the value of the failedEntitlement property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BooleanType }{@code >}
     *     
     */
    public void setFailedEntitlement(JAXBElement<BooleanType> value) {
        this.failedEntitlement = value;
    }

    /**
     * Gets the value of the location property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setLocation(JAXBElement<StringType> value) {
        this.location = value;
    }

    /**
     * Gets the value of the causeCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getCauseCode() {
        return causeCode;
    }

    /**
     * Sets the value of the causeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setCauseCode(JAXBElement<StringType> value) {
        this.causeCode = value;
    }

    /**
     * Gets the value of the closureCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getClosureCode() {
        return closureCode;
    }

    /**
     * Sets the value of the closureCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setClosureCode(JAXBElement<StringType> value) {
        this.closureCode = value;
    }

    /**
     * Gets the value of the company property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getCompany() {
        return company;
    }

    /**
     * Sets the value of the company property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setCompany(JAXBElement<StringType> value) {
        this.company = value;
    }

    /**
     * Gets the value of the reportedByContact property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getReportedByContact() {
        return reportedByContact;
    }

    /**
     * Sets the value of the reportedByContact property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setReportedByContact(JAXBElement<StringType> value) {
        this.reportedByContact = value;
    }

    /**
     * Gets the value of the reportedByDifferentContact property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BooleanType }{@code >}
     *     
     */
    public JAXBElement<BooleanType> getReportedByDifferentContact() {
        return reportedByDifferentContact;
    }

    /**
     * Sets the value of the reportedByDifferentContact property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BooleanType }{@code >}
     *     
     */
    public void setReportedByDifferentContact(JAXBElement<BooleanType> value) {
        this.reportedByDifferentContact = value;
    }

    /**
     * Gets the value of the reportedByPhone property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getReportedByPhone() {
        return reportedByPhone;
    }

    /**
     * Sets the value of the reportedByPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setReportedByPhone(JAXBElement<StringType> value) {
        this.reportedByPhone = value;
    }

    /**
     * Gets the value of the reportedByExtension property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getReportedByExtension() {
        return reportedByExtension;
    }

    /**
     * Sets the value of the reportedByExtension property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setReportedByExtension(JAXBElement<StringType> value) {
        this.reportedByExtension = value;
    }

    /**
     * Gets the value of the reportedByFax property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getReportedByFax() {
        return reportedByFax;
    }

    /**
     * Sets the value of the reportedByFax property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setReportedByFax(JAXBElement<StringType> value) {
        this.reportedByFax = value;
    }

    /**
     * Gets the value of the contactEmail property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getContactEmail() {
        return contactEmail;
    }

    /**
     * Sets the value of the contactEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setContactEmail(JAXBElement<StringType> value) {
        this.contactEmail = value;
    }

    /**
     * Gets the value of the locationFullName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getLocationFullName() {
        return locationFullName;
    }

    /**
     * Sets the value of the locationFullName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setLocationFullName(JAXBElement<StringType> value) {
        this.locationFullName = value;
    }

    /**
     * Gets the value of the contactFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getContactFirstName() {
        return contactFirstName;
    }

    /**
     * Sets the value of the contactFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setContactFirstName(JAXBElement<StringType> value) {
        this.contactFirstName = value;
    }

    /**
     * Gets the value of the contactLastName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getContactLastName() {
        return contactLastName;
    }

    /**
     * Sets the value of the contactLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setContactLastName(JAXBElement<StringType> value) {
        this.contactLastName = value;
    }

    /**
     * Gets the value of the contactTimeZone property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getContactTimeZone() {
        return contactTimeZone;
    }

    /**
     * Sets the value of the contactTimeZone property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setContactTimeZone(JAXBElement<StringType> value) {
        this.contactTimeZone = value;
    }

    /**
     * Gets the value of the enteredByESS property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BooleanType }{@code >}
     *     
     */
    public JAXBElement<BooleanType> getEnteredByESS() {
        return enteredByESS;
    }

    /**
     * Sets the value of the enteredByESS property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BooleanType }{@code >}
     *     
     */
    public void setEnteredByESS(JAXBElement<BooleanType> value) {
        this.enteredByESS = value;
    }

    /**
     * Gets the value of the slaBreached property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BooleanType }{@code >}
     *     
     */
    public JAXBElement<BooleanType> getSLABreached() {
        return slaBreached;
    }

    /**
     * Sets the value of the slaBreached property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BooleanType }{@code >}
     *     
     */
    public void setSLABreached(JAXBElement<BooleanType> value) {
        this.slaBreached = value;
    }

    /**
     * Gets the value of the nextSLABreach property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public JAXBElement<DateTimeType> getNextSLABreach() {
        return nextSLABreach;
    }

    /**
     * Sets the value of the nextSLABreach property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public void setNextSLABreach(JAXBElement<DateTimeType> value) {
        this.nextSLABreach = value;
    }

    /**
     * Gets the value of the contact property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getContact() {
        return contact;
    }

    /**
     * Sets the value of the contact property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setContact(JAXBElement<StringType> value) {
        this.contact = value;
    }

    /**
     * Gets the value of the update property.
     * 
     * @return
     *     possible object is
     *     {@link JioCentralInstanceType.Update }
     *     
     */
    public JioCentralInstanceType.Update getUpdate() {
        return update;
    }

    /**
     * Sets the value of the update property.
     * 
     * @param value
     *     allowed object is
     *     {@link JioCentralInstanceType.Update }
     *     
     */
    public void setUpdate(JioCentralInstanceType.Update value) {
        this.update = value;
    }

    /**
     * Gets the value of the impact property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getImpact() {
        return impact;
    }

    /**
     * Sets the value of the impact property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setImpact(JAXBElement<StringType> value) {
        this.impact = value;
    }

    /**
     * Gets the value of the neededByTime property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public JAXBElement<DateTimeType> getNeededByTime() {
        return neededByTime;
    }

    /**
     * Sets the value of the neededByTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}
     *     
     */
    public void setNeededByTime(JAXBElement<DateTimeType> value) {
        this.neededByTime = value;
    }

    /**
     * Gets the value of the approvalStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getApprovalStatus() {
        return approvalStatus;
    }

    /**
     * Sets the value of the approvalStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setApprovalStatus(JAXBElement<StringType> value) {
        this.approvalStatus = value;
    }

    /**
     * Gets the value of the folder property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getFolder() {
        return folder;
    }

    /**
     * Sets the value of the folder property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setFolder(JAXBElement<StringType> value) {
        this.folder = value;
    }

    /**
     * Gets the value of the subscriptionItem property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getSubscriptionItem() {
        return subscriptionItem;
    }

    /**
     * Sets the value of the subscriptionItem property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setSubscriptionItem(JAXBElement<StringType> value) {
        this.subscriptionItem = value;
    }

    /**
     * Gets the value of the affectedCI property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getAffectedCI() {
        return affectedCI;
    }

    /**
     * Sets the value of the affectedCI property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setAffectedCI(JAXBElement<StringType> value) {
        this.affectedCI = value;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public JAXBElement<StringType> getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link StringType }{@code >}
     *     
     */
    public void setTitle(JAXBElement<StringType> value) {
        this.title = value;
    }

    /**
     * Gets the value of the attachments property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AttachmentsType }{@code >}
     *     
     */
    public JAXBElement<AttachmentsType> getAttachments() {
        return attachments;
    }

    /**
     * Sets the value of the attachments property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AttachmentsType }{@code >}
     *     
     */
    public void setAttachments(JAXBElement<AttachmentsType> value) {
        this.attachments = value;
    }

    /**
     * Gets the value of the query property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuery() {
        return query;
    }

    /**
     * Sets the value of the query property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuery(String value) {
        this.query = value;
    }

    /**
     * Gets the value of the uniquequery property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUniquequery() {
        return uniquequery;
    }

    /**
     * Sets the value of the uniquequery property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUniquequery(String value) {
        this.uniquequery = value;
    }

    /**
     * Gets the value of the recordid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecordid() {
        return recordid;
    }

    /**
     * Sets the value of the recordid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecordid(String value) {
        this.recordid = value;
    }

    /**
     * Gets the value of the updatecounter property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getUpdatecounter() {
        return updatecounter;
    }

    /**
     * Sets the value of the updatecounter property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setUpdatecounter(Long value) {
        this.updatecounter = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://servicecenter.peregrine.com/PWS/Common}ArrayType">
     *       &lt;sequence>
     *         &lt;element name="Assignment" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "assignment"
    })
    public static class Assignment
        extends ArrayType
    {

        @XmlElement(name = "Assignment", namespace = "http://servicecenter.peregrine.com/PWS")
        protected List<StringType> assignment;

        /**
         * Gets the value of the assignment property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the assignment property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getAssignment().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StringType }
         * 
         * 
         */
        public List<StringType> getAssignment() {
            if (assignment == null) {
                assignment = new ArrayList<StringType>();
            }
            return this.assignment;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://servicecenter.peregrine.com/PWS/Common}ArrayType">
     *       &lt;sequence>
     *         &lt;element name="Description" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "description"
    })
    public static class Description
        extends ArrayType
    {

        @XmlElement(name = "Description", namespace = "http://servicecenter.peregrine.com/PWS")
        protected List<StringType> description;

        /**
         * Gets the value of the description property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the description property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDescription().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StringType }
         * 
         * 
         */
        public List<StringType> getDescription() {
            if (description == null) {
                description = new ArrayList<StringType>();
            }
            return this.description;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://servicecenter.peregrine.com/PWS/Common}ArrayType">
     *       &lt;sequence>
     *         &lt;element name="Solution" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "solution"
    })
    public static class Solution
        extends ArrayType
    {

        @XmlElement(name = "Solution", namespace = "http://servicecenter.peregrine.com/PWS")
        protected List<StringType> solution;

        /**
         * Gets the value of the solution property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the solution property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getSolution().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StringType }
         * 
         * 
         */
        public List<StringType> getSolution() {
            if (solution == null) {
                solution = new ArrayList<StringType>();
            }
            return this.solution;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://servicecenter.peregrine.com/PWS/Common}ArrayType">
     *       &lt;sequence>
     *         &lt;element name="Update" type="{http://servicecenter.peregrine.com/PWS/Common}StringType" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "update"
    })
    public static class Update
        extends ArrayType
    {

        @XmlElement(name = "Update", namespace = "http://servicecenter.peregrine.com/PWS")
        protected List<StringType> update;

        /**
         * Gets the value of the update property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the update property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getUpdate().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link StringType }
         * 
         * 
         */
        public List<StringType> getUpdate() {
            if (update == null) {
                update = new ArrayList<StringType>();
            }
            return this.update;
        }

    }

}
