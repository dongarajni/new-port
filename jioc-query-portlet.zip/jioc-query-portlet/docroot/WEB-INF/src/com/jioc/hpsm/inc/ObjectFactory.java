
package com.jioc.hpsm.inc;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.jioc.hpsm.inc package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _JioCentralIncInstanceTypeSeverity_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Severity");
    private final static QName _JioCentralIncInstanceTypeTicketOwner_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "TicketOwner");
    private final static QName _JioCentralIncInstanceTypeIncidentID_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "IncidentID");
    private final static QName _JioCentralIncInstanceTypeContactFirstName_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ContactFirstName");
    private final static QName _JioCentralIncInstanceTypeUserPriority_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "UserPriority");
    private final static QName _JioCentralIncInstanceTypeOpenTime_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "OpenTime");
    private final static QName _JioCentralIncInstanceTypeContactLastName_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ContactLastName");
    private final static QName _JioCentralIncInstanceTypeProductType_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ProductType");
    private final static QName _JioCentralIncInstanceTypeAttachments_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "attachments");
    private final static QName _JioCentralIncInstanceTypeSiteCategory_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "SiteCategory");
    private final static QName _JioCentralIncInstanceTypeOpenedBy_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "OpenedBy");
    private final static QName _JioCentralIncInstanceTypeUpdatedBy_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "UpdatedBy");
    private final static QName _JioCentralIncInstanceTypeCompany_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Company");
    private final static QName _JioCentralIncInstanceTypeService_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Service");
    private final static QName _JioCentralIncInstanceTypeClosedTime_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ClosedTime");
    private final static QName _JioCentralIncInstanceTypeCauseCode_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "CauseCode");
    private final static QName _JioCentralIncInstanceTypeSubcategory_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Subcategory");
    private final static QName _JioCentralIncInstanceTypeClosedBy_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ClosedBy");
    private final static QName _JioCentralIncInstanceTypeCategory_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Category");
    private final static QName _JioCentralIncInstanceTypeFolder_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "folder");
    private final static QName _JioCentralIncInstanceTypeBriefDescription_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "BriefDescription");
    private final static QName _JioCentralIncInstanceTypeIMTicketStatus_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "IMTicketStatus");
    private final static QName _JioCentralIncInstanceTypeResolvedTime_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ResolvedTime");
    private final static QName _JioCentralIncInstanceTypeAssigneeName_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "AssigneeName");
    private final static QName _JioCentralIncInstanceTypeResolvedBy_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ResolvedBy");
    private final static QName _JioCentralIncInstanceTypeResolutionFixType_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ResolutionFixType");
    private final static QName _JioCentralIncInstanceTypeAffectedItem_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "AffectedItem");
    private final static QName _JioCentralIncInstanceTypePrimaryAssignmentGroup_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "PrimaryAssignmentGroup");
    private final static QName _JioCentralIncInstanceTypeProblemType_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ProblemType");
    private final static QName _JioCentralIncInstanceTypeAlertStatus_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "AlertStatus");
    private final static QName _JioCentralIncInstanceTypeDownTimeEnd_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "DownTimeEnd");
    private final static QName _JioCentralIncInstanceTypeClosureCode_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "ClosureCode");
    private final static QName _JioCentralIncInstanceTypeContact_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Contact");
    private final static QName _JioCentralIncInstanceTypeSLAAgreementID_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "SLAAgreementID");
    private final static QName _JioCentralIncInstanceTypeLocation_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "Location");
    private final static QName _JioCentralIncInstanceTypeUpdatedTime_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "UpdatedTime");
    private final static QName _JioCentralIncInstanceTypeInitialImpact_QNAME = new QName("http://servicecenter.peregrine.com/PWS", "InitialImpact");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.jioc.hpsm.inc
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link JioCentralIncInstanceType }
     * 
     */
    public JioCentralIncInstanceType createJioCentralIncInstanceType() {
        return new JioCentralIncInstanceType();
    }

    /**
     * Create an instance of {@link CreateJioCentralIncResponse }
     * 
     */
    public CreateJioCentralIncResponse createCreateJioCentralIncResponse() {
        return new CreateJioCentralIncResponse();
    }

    /**
     * Create an instance of {@link JioCentralIncModelType }
     * 
     */
    public JioCentralIncModelType createJioCentralIncModelType() {
        return new JioCentralIncModelType();
    }

    /**
     * Create an instance of {@link MessagesType }
     * 
     */
    public MessagesType createMessagesType() {
        return new MessagesType();
    }

    /**
     * Create an instance of {@link RetrieveJioCentralIncListResponse }
     * 
     */
    public RetrieveJioCentralIncListResponse createRetrieveJioCentralIncListResponse() {
        return new RetrieveJioCentralIncListResponse();
    }

    /**
     * Create an instance of {@link RetrieveJioCentralIncResponse }
     * 
     */
    public RetrieveJioCentralIncResponse createRetrieveJioCentralIncResponse() {
        return new RetrieveJioCentralIncResponse();
    }

    /**
     * Create an instance of {@link ResolveJioCentralIncResponse }
     * 
     */
    public ResolveJioCentralIncResponse createResolveJioCentralIncResponse() {
        return new ResolveJioCentralIncResponse();
    }

    /**
     * Create an instance of {@link CreateJioCentralIncRequest }
     * 
     */
    public CreateJioCentralIncRequest createCreateJioCentralIncRequest() {
        return new CreateJioCentralIncRequest();
    }

    /**
     * Create an instance of {@link RetrieveJioCentralIncListRequest }
     * 
     */
    public RetrieveJioCentralIncListRequest createRetrieveJioCentralIncListRequest() {
        return new RetrieveJioCentralIncListRequest();
    }

    /**
     * Create an instance of {@link JioCentralIncKeysType }
     * 
     */
    public JioCentralIncKeysType createJioCentralIncKeysType() {
        return new JioCentralIncKeysType();
    }

    /**
     * Create an instance of {@link RetrieveJioCentralIncRequest }
     * 
     */
    public RetrieveJioCentralIncRequest createRetrieveJioCentralIncRequest() {
        return new RetrieveJioCentralIncRequest();
    }

    /**
     * Create an instance of {@link ResolveJioCentralIncRequest }
     * 
     */
    public ResolveJioCentralIncRequest createResolveJioCentralIncRequest() {
        return new ResolveJioCentralIncRequest();
    }

    /**
     * Create an instance of {@link CloseJioCentralIncRequest }
     * 
     */
    public CloseJioCentralIncRequest createCloseJioCentralIncRequest() {
        return new CloseJioCentralIncRequest();
    }

    /**
     * Create an instance of {@link RetrieveJioCentralIncKeysListRequest }
     * 
     */
    public RetrieveJioCentralIncKeysListRequest createRetrieveJioCentralIncKeysListRequest() {
        return new RetrieveJioCentralIncKeysListRequest();
    }

    /**
     * Create an instance of {@link UpdateJioCentralIncResponse }
     * 
     */
    public UpdateJioCentralIncResponse createUpdateJioCentralIncResponse() {
        return new UpdateJioCentralIncResponse();
    }

    /**
     * Create an instance of {@link RetrieveJioCentralIncKeysListResponse }
     * 
     */
    public RetrieveJioCentralIncKeysListResponse createRetrieveJioCentralIncKeysListResponse() {
        return new RetrieveJioCentralIncKeysListResponse();
    }

    /**
     * Create an instance of {@link UpdateJioCentralIncRequest }
     * 
     */
    public UpdateJioCentralIncRequest createUpdateJioCentralIncRequest() {
        return new UpdateJioCentralIncRequest();
    }

    /**
     * Create an instance of {@link CloseJioCentralIncResponse }
     * 
     */
    public CloseJioCentralIncResponse createCloseJioCentralIncResponse() {
        return new CloseJioCentralIncResponse();
    }

    /**
     * Create an instance of {@link ArrayType }
     * 
     */
    public ArrayType createArrayType() {
        return new ArrayType();
    }

    /**
     * Create an instance of {@link DurationType }
     * 
     */
    public DurationType createDurationType() {
        return new DurationType();
    }

    /**
     * Create an instance of {@link Base64Type }
     * 
     */
    public Base64Type createBase64Type() {
        return new Base64Type();
    }

    /**
     * Create an instance of {@link ShortType }
     * 
     */
    public ShortType createShortType() {
        return new ShortType();
    }

    /**
     * Create an instance of {@link ByteType }
     * 
     */
    public ByteType createByteType() {
        return new ByteType();
    }

    /**
     * Create an instance of {@link LongType }
     * 
     */
    public LongType createLongType() {
        return new LongType();
    }

    /**
     * Create an instance of {@link DecimalType }
     * 
     */
    public DecimalType createDecimalType() {
        return new DecimalType();
    }

    /**
     * Create an instance of {@link AttachmentsType }
     * 
     */
    public AttachmentsType createAttachmentsType() {
        return new AttachmentsType();
    }

    /**
     * Create an instance of {@link StringType }
     * 
     */
    public StringType createStringType() {
        return new StringType();
    }

    /**
     * Create an instance of {@link FloatType }
     * 
     */
    public FloatType createFloatType() {
        return new FloatType();
    }

    /**
     * Create an instance of {@link DateTimeType }
     * 
     */
    public DateTimeType createDateTimeType() {
        return new DateTimeType();
    }

    /**
     * Create an instance of {@link TimeType }
     * 
     */
    public TimeType createTimeType() {
        return new TimeType();
    }

    /**
     * Create an instance of {@link StructureType }
     * 
     */
    public StructureType createStructureType() {
        return new StructureType();
    }

    /**
     * Create an instance of {@link IntType }
     * 
     */
    public IntType createIntType() {
        return new IntType();
    }

    /**
     * Create an instance of {@link DoubleType }
     * 
     */
    public DoubleType createDoubleType() {
        return new DoubleType();
    }

    /**
     * Create an instance of {@link DateType }
     * 
     */
    public DateType createDateType() {
        return new DateType();
    }

    /**
     * Create an instance of {@link MessageType }
     * 
     */
    public MessageType createMessageType() {
        return new MessageType();
    }

    /**
     * Create an instance of {@link BooleanType }
     * 
     */
    public BooleanType createBooleanType() {
        return new BooleanType();
    }

    /**
     * Create an instance of {@link AttachmentType }
     * 
     */
    public AttachmentType createAttachmentType() {
        return new AttachmentType();
    }

    /**
     * Create an instance of {@link JioCentralIncInstanceType.IncidentDescription }
     * 
     */
    public JioCentralIncInstanceType.IncidentDescription createJioCentralIncInstanceTypeIncidentDescription() {
        return new JioCentralIncInstanceType.IncidentDescription();
    }

    /**
     * Create an instance of {@link JioCentralIncInstanceType.Resolution }
     * 
     */
    public JioCentralIncInstanceType.Resolution createJioCentralIncInstanceTypeResolution() {
        return new JioCentralIncInstanceType.Resolution();
    }

    /**
     * Create an instance of {@link JioCentralIncInstanceType.JournalUpdates }
     * 
     */
    public JioCentralIncInstanceType.JournalUpdates createJioCentralIncInstanceTypeJournalUpdates() {
        return new JioCentralIncInstanceType.JournalUpdates();
    }

    /**
     * Create an instance of {@link JioCentralIncInstanceType.Solution }
     * 
     */
    public JioCentralIncInstanceType.Solution createJioCentralIncInstanceTypeSolution() {
        return new JioCentralIncInstanceType.Solution();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Severity", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeSeverity(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeSeverity_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "TicketOwner", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeTicketOwner(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeTicketOwner_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "IncidentID", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeIncidentID(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeIncidentID_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ContactFirstName", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeContactFirstName(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeContactFirstName_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "UserPriority", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeUserPriority(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeUserPriority_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "OpenTime", scope = JioCentralIncInstanceType.class)
    public JAXBElement<DateTimeType> createJioCentralIncInstanceTypeOpenTime(DateTimeType value) {
        return new JAXBElement<DateTimeType>(_JioCentralIncInstanceTypeOpenTime_QNAME, DateTimeType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ContactLastName", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeContactLastName(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeContactLastName_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ProductType", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeProductType(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeProductType_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AttachmentsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "attachments", scope = JioCentralIncInstanceType.class)
    public JAXBElement<AttachmentsType> createJioCentralIncInstanceTypeAttachments(AttachmentsType value) {
        return new JAXBElement<AttachmentsType>(_JioCentralIncInstanceTypeAttachments_QNAME, AttachmentsType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "SiteCategory", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeSiteCategory(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeSiteCategory_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "OpenedBy", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeOpenedBy(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeOpenedBy_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "UpdatedBy", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeUpdatedBy(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeUpdatedBy_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Company", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeCompany(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeCompany_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Service", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeService(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeService_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ClosedTime", scope = JioCentralIncInstanceType.class)
    public JAXBElement<DateTimeType> createJioCentralIncInstanceTypeClosedTime(DateTimeType value) {
        return new JAXBElement<DateTimeType>(_JioCentralIncInstanceTypeClosedTime_QNAME, DateTimeType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "CauseCode", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeCauseCode(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeCauseCode_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Subcategory", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeSubcategory(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeSubcategory_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ClosedBy", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeClosedBy(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeClosedBy_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Category", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeCategory(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeCategory_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "folder", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeFolder(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeFolder_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "BriefDescription", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeBriefDescription(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeBriefDescription_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "IMTicketStatus", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeIMTicketStatus(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeIMTicketStatus_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ResolvedTime", scope = JioCentralIncInstanceType.class)
    public JAXBElement<DateTimeType> createJioCentralIncInstanceTypeResolvedTime(DateTimeType value) {
        return new JAXBElement<DateTimeType>(_JioCentralIncInstanceTypeResolvedTime_QNAME, DateTimeType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "AssigneeName", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeAssigneeName(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeAssigneeName_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ResolvedBy", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeResolvedBy(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeResolvedBy_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ResolutionFixType", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeResolutionFixType(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeResolutionFixType_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "AffectedItem", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeAffectedItem(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeAffectedItem_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "PrimaryAssignmentGroup", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypePrimaryAssignmentGroup(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypePrimaryAssignmentGroup_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ProblemType", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeProblemType(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeProblemType_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "AlertStatus", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeAlertStatus(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeAlertStatus_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "DownTimeEnd", scope = JioCentralIncInstanceType.class)
    public JAXBElement<DateTimeType> createJioCentralIncInstanceTypeDownTimeEnd(DateTimeType value) {
        return new JAXBElement<DateTimeType>(_JioCentralIncInstanceTypeDownTimeEnd_QNAME, DateTimeType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "ClosureCode", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeClosureCode(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeClosureCode_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Contact", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeContact(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeContact_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DecimalType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "SLAAgreementID", scope = JioCentralIncInstanceType.class)
    public JAXBElement<DecimalType> createJioCentralIncInstanceTypeSLAAgreementID(DecimalType value) {
        return new JAXBElement<DecimalType>(_JioCentralIncInstanceTypeSLAAgreementID_QNAME, DecimalType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "Location", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeLocation(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeLocation_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DateTimeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "UpdatedTime", scope = JioCentralIncInstanceType.class)
    public JAXBElement<DateTimeType> createJioCentralIncInstanceTypeUpdatedTime(DateTimeType value) {
        return new JAXBElement<DateTimeType>(_JioCentralIncInstanceTypeUpdatedTime_QNAME, DateTimeType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "InitialImpact", scope = JioCentralIncInstanceType.class)
    public JAXBElement<StringType> createJioCentralIncInstanceTypeInitialImpact(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeInitialImpact_QNAME, StringType.class, JioCentralIncInstanceType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicecenter.peregrine.com/PWS", name = "IncidentID", scope = JioCentralIncKeysType.class)
    public JAXBElement<StringType> createJioCentralIncKeysTypeIncidentID(StringType value) {
        return new JAXBElement<StringType>(_JioCentralIncInstanceTypeIncidentID_QNAME, StringType.class, JioCentralIncKeysType.class, value);
    }

}
