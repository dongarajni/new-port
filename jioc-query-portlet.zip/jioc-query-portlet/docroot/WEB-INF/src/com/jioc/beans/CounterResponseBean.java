package com.jioc.beans;

public class CounterResponseBean {
	private long counter;
	private String errorCode;
	private String errorMsg;
	private String success;
	
	
	public long getCounter() {
		return counter;
	}
	public void setCounter(long counter) {
		this.counter = counter;
	}
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getSuccess() {
		return success;
	}
	public void setSuccess(String success) {
		this.success = success;
	}
	@Override
	public String toString() {
		return "CounterDetails [Counter=" + counter
				+ ", errorMsg=" + errorMsg + ", errorCode=" + errorCode + ", success="
				+ success + "]";
	}
	
}
