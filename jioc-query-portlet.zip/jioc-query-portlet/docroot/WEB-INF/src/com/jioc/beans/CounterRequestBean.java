package com.jioc.beans;

import org.codehaus.jackson.annotate.JsonProperty;

public class CounterRequestBean {
	@JsonProperty("counterDetails")
	CounterDetails counterDetails;

	public CounterDetails getCounterDetails() {
		return counterDetails;
	}

	public void setCounterDetails(CounterDetails counterDetails) {
		this.counterDetails = counterDetails;
	}

	
}
