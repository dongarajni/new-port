package com.jioc.beans;

import java.util.List;

public class PushTicketResponseBean {

	private String nativeTicketId;
	private String message;
	private String caseId;
	private String success;
	private List<PushTicketResponseErrorBean> errors;
	
	public String getNativeTicketId() {
		return nativeTicketId;
	}
	public void setNativeTicketId(String nativeTicketId) {
		this.nativeTicketId = nativeTicketId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getSuccess() {
		return success;
	}
	public void setSuccess(String success) {
		this.success = success;
	}
	public List<PushTicketResponseErrorBean> getErrors() {
		return errors;
	}
	public void setErrors(List<PushTicketResponseErrorBean> errors) {
		this.errors = errors;
	}
	@Override
	public String toString() {
		return "PushTicketResponseModal [nativeTicketId=" + nativeTicketId
				+ ", message=" + message + ", caseId=" + caseId + ", success="
				+ success + "]";
	}
}




