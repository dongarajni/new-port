package com.jioc.beans;

import com.jioc.hpsm.BooleanType;
import com.jioc.hpsm.JioCentralInstanceType.Assignment;
import com.jioc.hpsm.JioCentralInstanceType.Description;
import com.jioc.hpsm.JioCentralInstanceType.Update;
import com.jioc.hpsm.ObjectFactory;
import com.jioc.hpsm.StringType;

import javax.xml.bind.JAXBElement;

public class CreateJioCentralRequestBean {
	private JAXBElement<StringType> category;
	private JAXBElement<StringType> siteCategory;
	private JAXBElement<StringType> area;
	private JAXBElement<StringType> subarea;
	private JAXBElement<StringType> serviceRecipient;
	private JAXBElement<StringType> urgency;
	private JAXBElement<StringType> openedBy;
	private JAXBElement<StringType> affectedService;
	private JAXBElement<StringType> notifyBy;
	private Assignment assignment;
	private JAXBElement<StringType> priority;
	private JAXBElement<BooleanType> enteredByESS;
	private JAXBElement<StringType> impact;
	private Description description;
	private JAXBElement<StringType> title;
	private JAXBElement<StringType> callerDepartment;
	private JAXBElement<StringType> callerLocation;
	private JAXBElement<StringType> problemType;
	private JAXBElement<StringType> company;
	private JAXBElement<StringType> contactEmail;
	private JAXBElement<StringType> locationFullName;
	private JAXBElement<StringType> contactLastName;
	private JAXBElement<StringType> callId;
	
	private JAXBElement<StringType> contact;
	private Update update;
	private JAXBElement<StringType> location;
	private JAXBElement<StringType> contactFirstName;
	
	
	public CreateJioCentralRequestBean(ObjectFactory objectFactory){
		category = objectFactory.createJioCentralInstanceTypeCategory(objectFactory.createStringType());
		siteCategory = objectFactory.createJioCentralInstanceTypeSiteCategory(objectFactory.createStringType());
		area = objectFactory.createJioCentralInstanceTypeArea(objectFactory.createStringType());
		subarea = objectFactory.createJioCentralInstanceTypeSubarea(objectFactory.createStringType());
		serviceRecipient = objectFactory.createJioCentralInstanceTypeServiceRecipient(objectFactory.createStringType());
		urgency = objectFactory.createJioCentralInstanceTypeUrgency(objectFactory.createStringType());
		openedBy = objectFactory.createJioCentralInstanceTypeOpenedBy(objectFactory.createStringType());
		affectedService = objectFactory.createJioCentralInstanceTypeAffectedService(objectFactory.createStringType());
		notifyBy = objectFactory.createJioCentralInstanceTypeNotifyBy(objectFactory.createStringType());
		assignment = objectFactory.createJioCentralInstanceTypeAssignment();
		assignment.getAssignment().add(objectFactory.createStringType());
		priority = objectFactory.createJioCentralInstanceTypePriority(objectFactory.createStringType());
		enteredByESS = objectFactory.createJioCentralInstanceTypeEnteredByESS(objectFactory.createBooleanType());
		impact = objectFactory.createJioCentralInstanceTypeImpact(objectFactory.createStringType());
		description = objectFactory.createJioCentralInstanceTypeDescription();
		description.getDescription().add(objectFactory.createStringType());
		title = objectFactory.createJioCentralInstanceTypeTitle(objectFactory.createStringType());
		callerDepartment = objectFactory.createJioCentralInstanceTypeCallerDepartment(objectFactory.createStringType());
		callerLocation = objectFactory.createJioCentralInstanceTypeCallerLocation(objectFactory.createStringType());
		problemType = objectFactory.createJioCentralInstanceTypeProblemType(objectFactory.createStringType());
		company = objectFactory.createJioCentralInstanceTypeCompany(objectFactory.createStringType());
		contactEmail = objectFactory.createJioCentralInstanceTypeContactEmail(objectFactory.createStringType());
		locationFullName = objectFactory.createJioCentralInstanceTypeLocationFullName(objectFactory.createStringType());
		contactLastName = objectFactory.createJioCentralInstanceTypeContactLastName(objectFactory.createStringType());
		callId = objectFactory.createJioCentralInstanceTypeCallID(objectFactory.createStringType());
		
		contact = objectFactory.createJioCentralInstanceTypeContact(objectFactory.createStringType());
		update = objectFactory.createJioCentralInstanceTypeUpdate();
		update.getUpdate().add(objectFactory.createStringType());
		location = objectFactory.createJioCentralInstanceTypeLocation(objectFactory.createStringType());
		contactFirstName = objectFactory.createJioCentralInstanceTypeContactFirstName(objectFactory.createStringType());
	}

	public JAXBElement<StringType> getCategory() {
		return category;
	}

	public JAXBElement<StringType> getArea() {
		return area;
	}

	public JAXBElement<StringType> getSubarea() {
		return subarea;
	}

	public JAXBElement<StringType> getServiceRecipient() {
		return serviceRecipient;
	}

	public JAXBElement<StringType> getUrgency() {
		return urgency;
	}

	public JAXBElement<StringType> getOpenedBy() {
		return openedBy;
	}

	public JAXBElement<StringType> getAffectedService() {
		return affectedService;
	}

	public JAXBElement<StringType> getNotifyBy() {
		return notifyBy;
	}

	public Assignment getAssignment() {
		return assignment;
	}

	public JAXBElement<StringType> getPriority() {
		return priority;
	}

	public JAXBElement<BooleanType> getEnteredByESS() {
		return enteredByESS;
	}

	public JAXBElement<StringType> getImpact() {
		return impact;
	}

	public Description getDescription() {
		return description;
	}

	public JAXBElement<StringType> getTitle() {
		return title;
	}

	public JAXBElement<StringType> getCallerDepartment() {
		return callerDepartment;
	}

	public JAXBElement<StringType> getCallerLocation() {
		return callerLocation;
	}

	public JAXBElement<StringType> getProblemType() {
		return problemType;
	}

	public JAXBElement<StringType> getCompany() {
		return company;
	}

	public JAXBElement<StringType> getContactEmail() {
		return contactEmail;
	}

	public JAXBElement<StringType> getLocationFullName() {
		return locationFullName;
	}

	public JAXBElement<StringType> getContactLastName() {
		return contactLastName;
	}

	public JAXBElement<StringType> getCallId() {
		return callId;
	}

	public JAXBElement<StringType> getSiteCategory() {
		return siteCategory;
	}

	public JAXBElement<StringType> getContact() {
		return contact;
	}

	public Update getUpdate() {
		return update;
	}

	public JAXBElement<StringType> getLocation() {
		return location;
	}

	public JAXBElement<StringType> getContactFirstName() {
		return contactFirstName;
	}

	
	
	
	
}

