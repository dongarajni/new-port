package com.jioc.beans;

import com.jioc.hpsm.inc.AttachmentsType;
import com.jioc.hpsm.inc.BooleanType;
import com.jioc.hpsm.inc.DateTimeType;

import java.sql.Timestamp;
import com.jioc.hpsm.inc.JioCentralIncInstanceType.IncidentDescription;
import com.jioc.hpsm.inc.JioCentralIncInstanceType.JournalUpdates;
import com.jioc.hpsm.inc.JioCentralIncInstanceType.Resolution;
import com.jioc.hpsm.inc.JioCentralIncInstanceType.Solution;
import com.jioc.hpsm.inc.ObjectFactory;
import com.jioc.hpsm.inc.StringType;

import java.util.Date;

import javax.xml.bind.JAXBElement;

public class CreateJioCentralIncRequestBean {
	private JAXBElement<StringType> incidentID;
	private JAXBElement<StringType> category;
	private JAXBElement<DateTimeType> openTime;	
	private JAXBElement<StringType> openedBy;
	private JAXBElement<StringType> severity;
	private JAXBElement<DateTimeType> updatedTime;
	private JAXBElement<StringType> primaryAssignmentGroup;
	private JAXBElement<StringType> closedTime;
	private JAXBElement<StringType> closedBy;
	private JAXBElement<StringType> closureCode;
	private JAXBElement<StringType> affectedItem;
	private IncidentDescription incidentDescription;
	private Resolution resolution;
	private JAXBElement<StringType> assigneeName;
	private JAXBElement<StringType> contact;
	private JournalUpdates journalUpdates;
	private JAXBElement<StringType> alertStatus;
	private JAXBElement<StringType> contactLastName;
	private JAXBElement<StringType> contactFirstName;
	private JAXBElement<StringType> company;
	private JAXBElement<StringType> briefDescription;
	private JAXBElement<StringType> ticketOwner;
	private JAXBElement<StringType> updatedBy;
	private JAXBElement<StringType> IMTicketStatus;
	private JAXBElement<StringType> subcategory;
	private JAXBElement<StringType> sLAAgreementID;
	private JAXBElement<StringType> siteCategory;
	private JAXBElement<StringType> productType;
	private JAXBElement<StringType> problemType;
	private JAXBElement<StringType> resolutionFixType;
	private JAXBElement<StringType> userPriority;
	private JAXBElement<StringType> location;
	private Solution solution;
	private JAXBElement<StringType> initialImpact;
	private JAXBElement<StringType> folder;
	private JAXBElement<StringType> Service;
	private AttachmentsType attachmentsType;
	
	
	public CreateJioCentralIncRequestBean(ObjectFactory objectFactory) {
		incidentID = objectFactory.createJioCentralIncInstanceTypeIncidentID(objectFactory.createStringType());
		category = objectFactory.createJioCentralIncInstanceTypeCategory(objectFactory.createStringType());
		openTime = objectFactory.createJioCentralIncInstanceTypeOpenTime(objectFactory.createDateTimeType());
		openedBy = objectFactory.createJioCentralIncInstanceTypeOpenedBy(objectFactory.createStringType());
		severity = objectFactory.createJioCentralIncInstanceTypeSeverity(objectFactory.createStringType());
		updatedTime = objectFactory.createJioCentralIncInstanceTypeUpdatedTime(objectFactory.createDateTimeType());
		primaryAssignmentGroup = objectFactory.createJioCentralIncInstanceTypePrimaryAssignmentGroup(objectFactory.createStringType());
	//	closedTime = objectFactory.createJioCentralIncInstanceTypeClosedTime(objectFactory.createStringType());
		closedBy = objectFactory.createJioCentralIncInstanceTypeClosedBy(objectFactory.createStringType());
		closureCode = objectFactory.createJioCentralIncInstanceTypeClosureCode(objectFactory.createStringType());
		affectedItem = objectFactory.createJioCentralIncInstanceTypeAffectedItem(objectFactory.createStringType());
		incidentDescription = objectFactory.createJioCentralIncInstanceTypeIncidentDescription();
		incidentDescription.getIncidentDescription().add(objectFactory.createStringType());
		resolution = objectFactory.createJioCentralIncInstanceTypeResolution();
		assigneeName = objectFactory.createJioCentralIncInstanceTypeAssigneeName(objectFactory.createStringType()); 
		contact = objectFactory.createJioCentralIncInstanceTypeContact(objectFactory.createStringType());
		
		
		briefDescription = objectFactory.createJioCentralIncInstanceTypeBriefDescription(objectFactory.createStringType());
		updatedBy = objectFactory.createJioCentralIncInstanceTypeUpdatedBy(objectFactory.createStringType());
		subcategory= objectFactory.createJioCentralIncInstanceTypeSubcategory(objectFactory.createStringType());
		productType= objectFactory.createJioCentralIncInstanceTypeProductType(objectFactory.createStringType());
		userPriority= objectFactory.createJioCentralIncInstanceTypeUserPriority(objectFactory.createStringType());
		initialImpact=objectFactory.createJioCentralIncInstanceTypeInitialImpact(objectFactory.createStringType());
		Service=objectFactory.createJioCentralIncInstanceTypeService(objectFactory.createStringType());
		
		
		journalUpdates = objectFactory.createJioCentralIncInstanceTypeJournalUpdates();
		journalUpdates.getJournalUpdates().add(objectFactory.createStringType());
		alertStatus = objectFactory.createJioCentralIncInstanceTypeAlertStatus(objectFactory.createStringType());
		contactLastName=objectFactory.createJioCentralIncInstanceTypeContactLastName(objectFactory.createStringType());  
		contactFirstName = objectFactory.createJioCentralIncInstanceTypeContactFirstName(objectFactory.createStringType());
		company = objectFactory.createJioCentralIncInstanceTypeCompany(objectFactory.createStringType());
		ticketOwner=objectFactory.createJioCentralIncInstanceTypeTicketOwner(objectFactory.createStringType());
		IMTicketStatus=objectFactory.createJioCentralIncInstanceTypeIMTicketStatus(objectFactory.createStringType());
	//	sLAAgreementID=objectFactory.createJioCentralIncInstanceTypeSLAAgreementID(objectFactory.createStringType());
		//problemType = objectFactory.createJioCentralInstanceTypeProblemType(objectFactory.createStringType());
		resolutionFixType=objectFactory.createJioCentralIncInstanceTypeResolutionFixType(objectFactory.createStringType());
		location=objectFactory.createJioCentralIncInstanceTypeLocation(objectFactory.createStringType());
		//solution=objectFactory.createJioCentralIncInstanceTypeSolution(objectFactory.createStringType());
		folder=objectFactory.createJioCentralIncInstanceTypeFolder(objectFactory.createStringType());
		//attachmentsType=objectFactory.createJioCentralIncInstanceTypeAttachments(objectFactory.createStringType());
	}
	
	public JAXBElement<StringType> getIncidentID() {
		return incidentID;
	}

	public void setIncidentID(JAXBElement<StringType> incidentID) {
		this.incidentID = incidentID;
	}

	public JAXBElement<StringType> getCategory() {
		return category;
	}

	public void setCategory(JAXBElement<StringType> category) {
		this.category = category;
	}

	

	public JAXBElement<DateTimeType> getOpenTime() {
		return openTime;
	}
	public void setOpenTime(JAXBElement<DateTimeType> openTime) {
		this.openTime = openTime;
	}
	public JAXBElement<StringType> getOpenedBy() {
		return openedBy;
	}

	public void setOpenedBy(JAXBElement<StringType> openedBy) {
		this.openedBy = openedBy;
	}

	public JAXBElement<StringType> getSeverity() {
		return severity;
	}

	public void setSeverity(JAXBElement<StringType> severity) {
		this.severity = severity;
	}

	

	public JAXBElement<DateTimeType> getUpdatedTime() {
		return updatedTime;
	}
	public void setUpdatedTime(JAXBElement<DateTimeType> updatedTime) {
		this.updatedTime = updatedTime;
	}
	public JAXBElement<StringType> getPrimaryAssignmentGroup() {
		return primaryAssignmentGroup;
	}

	public void setPrimaryAssignmentGroup(JAXBElement<StringType> primaryAssignmentGroup) {
		this.primaryAssignmentGroup = primaryAssignmentGroup;
	}

	public JAXBElement<StringType> getClosedTime() {
		return closedTime;
	}

	public void setClosedTime(JAXBElement<StringType> closedTime) {
		this.closedTime = closedTime;
	}

	public JAXBElement<StringType> getClosedBy() {
		return closedBy;
	}

	public void setClosedBy(JAXBElement<StringType> closedBy) {
		this.closedBy = closedBy;
	}

	public JAXBElement<StringType> getClosureCode() {
		return closureCode;
	}

	public void setClosureCode(JAXBElement<StringType> closureCode) {
		this.closureCode = closureCode;
	}

	public JAXBElement<StringType> getAffectedItem() {
		return affectedItem;
	}

	public void setAffectedItem(JAXBElement<StringType> affectedItem) {
		this.affectedItem = affectedItem;
	}

	public IncidentDescription getIncidentDescription() {
		return incidentDescription;
	}

	public void setIncidentDescription(IncidentDescription incidentDescription) {
		this.incidentDescription = incidentDescription;
	}

	public Resolution getResolution() {
		return resolution;
	}

	public void setResolution(Resolution resolution) {
		this.resolution = resolution;
	}

	public JAXBElement<StringType> getAssigneeName() {
		return assigneeName;
	}

	public void setAssigneeName(JAXBElement<StringType> assigneeName) {
		this.assigneeName = assigneeName;
	}

	public JAXBElement<StringType> getContact() {
		return contact;
	}

	public void setContact(JAXBElement<StringType> contact) {
		this.contact = contact;
	}

	public JournalUpdates getJournalUpdates() {
		return journalUpdates;
	}

	public void setJournalUpdates(JournalUpdates journalUpdates) {
		this.journalUpdates = journalUpdates;
	}

	public JAXBElement<StringType> getAlertStatus() {
		return alertStatus;
	}

	public void setAlertStatus(JAXBElement<StringType> alertStatus) {
		this.alertStatus = alertStatus;
	}

	public JAXBElement<StringType> getContactLastName() {
		return contactLastName;
	}

	public void setContactLastName(JAXBElement<StringType> contactLastName) {
		this.contactLastName = contactLastName;
	}

	public JAXBElement<StringType> getContactFirstName() {
		return contactFirstName;
	}

	public void setContactFirstName(JAXBElement<StringType> contactFirstName) {
		this.contactFirstName = contactFirstName;
	}

	public JAXBElement<StringType> getCompany() {
		return company;
	}

	public void setCompany(JAXBElement<StringType> company) {
		this.company = company;
	}

	public JAXBElement<StringType> getBriefDescription() {
		return briefDescription;
	}

	public void setBriefDescription(JAXBElement<StringType> briefDescription) {
		this.briefDescription = briefDescription;
	}

	public JAXBElement<StringType> getTicketOwner() {
		return ticketOwner;
	}

	public void setTicketOwner(JAXBElement<StringType> ticketOwner) {
		this.ticketOwner = ticketOwner;
	}

	public JAXBElement<StringType> getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(JAXBElement<StringType> updatedBy) {
		this.updatedBy = updatedBy;
	}

	public JAXBElement<StringType> getIMTicketStatus() {
		return IMTicketStatus;
	}

	public void setIMTicketStatus(JAXBElement<StringType> iMTicketStatus) {
		IMTicketStatus = iMTicketStatus;
	}

	public JAXBElement<StringType> getSubcategory() {
		return subcategory;
	}

	public void setSubcategory(JAXBElement<StringType> subcategory) {
		this.subcategory = subcategory;
	}

	public JAXBElement<StringType> getsLAAgreementID() {
		return sLAAgreementID;
	}

	public void setsLAAgreementID(JAXBElement<StringType> sLAAgreementID) {
		this.sLAAgreementID = sLAAgreementID;
	}

	public JAXBElement<StringType> getSiteCategory() {
		return siteCategory;
	}

	public void setSiteCategory(JAXBElement<StringType> siteCategory) {
		this.siteCategory = siteCategory;
	}

	public JAXBElement<StringType> getProductType() {
		return productType;
	}

	public void setProductType(JAXBElement<StringType> productType) {
		this.productType = productType;
	}

	public JAXBElement<StringType> getProblemType() {
		return problemType;
	}

	public void setProblemType(JAXBElement<StringType> problemType) {
		this.problemType = problemType;
	}

	public JAXBElement<StringType> getResolutionFixType() {
		return resolutionFixType;
	}

	public void setResolutionFixType(JAXBElement<StringType> resolutionFixType) {
		this.resolutionFixType = resolutionFixType;
	}

	public JAXBElement<StringType> getUserPriority() {
		return userPriority;
	}

	public void setUserPriority(JAXBElement<StringType> userPriority) {
		this.userPriority = userPriority;
	}

	public JAXBElement<StringType> getLocation() {
		return location;
	}

	public void setLocation(JAXBElement<StringType> location) {
		this.location = location;
	}

	public Solution getSolution() {
		return solution;
	}

	public void setSolution(Solution solution) {
		this.solution = solution;
	}

	public JAXBElement<StringType> getInitialImpact() {
		return initialImpact;
	}

	public void setInitialImpact(JAXBElement<StringType> initialImpact) {
		this.initialImpact = initialImpact;
	}

	public JAXBElement<StringType> getFolder() {
		return folder;
	}

	public void setFolder(JAXBElement<StringType> folder) {
		this.folder = folder;
	}

	public JAXBElement<StringType> getService() {
		return Service;
	}

	public void setService(JAXBElement<StringType> service) {
		Service = service;
	}

	public AttachmentsType getAttachmentsType() {
		return attachmentsType;
	}

	public void setAttachmentsType(AttachmentsType attachmentsType) {
		this.attachmentsType = attachmentsType;
	}


}

