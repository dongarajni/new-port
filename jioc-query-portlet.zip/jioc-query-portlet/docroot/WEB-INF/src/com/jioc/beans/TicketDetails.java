package com.jioc.beans;

import org.codehaus.jackson.annotate.JsonProperty;

public class TicketDetails {

	@JsonProperty("ticketId")
	private String ticketId;
	
	@JsonProperty("ownerEmailAddress")
	private String ownerEmailAddress;
	
	@JsonProperty("origin")
	private String origin;
	
	@JsonProperty("description")
	private String description;
	
	@JsonProperty("status")
	private String status;
	
	public String getTicketId() {
		return ticketId;
	}
	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}
	
	public String getOwnerEmailAddress() {
		return ownerEmailAddress;
	}
	public void setOwnerEmailAddress(String ownerEmailAddress) {
		this.ownerEmailAddress = ownerEmailAddress;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String toString() {
		return "PushTicketRequestModal [ticketId=" + ticketId
				+ ", ownerEmailAddress=" + ownerEmailAddress + ", origin="
				+ origin + ", description=" + description + ", status="
				+ status + "]";
	}
}
