package com.jioc.beans;

import com.liferay.portal.model.User;

import java.util.Date;

public class QueryBean {
	private User user;
	private String queryDescription;
	private String source;
	private String empId;
	private String samlFederationId;
	private String empMobile;
	private String serviceErrCode;
	private String serviceStatus;
	private String serviceErrMsg;
	private String incidentId;
	private long queryId;
	private String pcId;
	
	private Date raisedTimestamp;
	private long assignedTo;
	private String assignedToName;
	private String assignedToEmail;
	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getQueryDescription() {
		return queryDescription;
	}
	public void setQueryDescription(String queryDescription) {
		this.queryDescription = queryDescription;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getServiceStatus() {
		return serviceStatus;
	}
	public void setServiceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	public String getServiceErrMsg() {
		return serviceErrMsg;
	}
	public void setServiceErrMsg(String serviceErrMsg) {
		this.serviceErrMsg = serviceErrMsg;
	}
	public String getIncidentId() {
		return incidentId;
	}
	public void setIncidentId(String incidentId) {
		this.incidentId = incidentId;
	}
	public long getQueryId() {
		return queryId;
	}
	public void setQueryId(long queryId) {
		this.queryId = queryId;
	}
	public String getPcId() {
		return pcId;
	}
	public void setPcId(String pcId) {
		this.pcId = pcId;
	}
	public String getServiceErrCode() {
		return serviceErrCode;
	}
	public void setServiceErrCode(String serviceErrCode) {
		this.serviceErrCode = serviceErrCode;
	}
	public Date getRaisedTimestamp() {
		return raisedTimestamp;
	}
	public void setRaisedTimestamp(Date raisedTimestamp) {
		this.raisedTimestamp = raisedTimestamp;
	}
	public long getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(long assignedTo) {
		this.assignedTo = assignedTo;
	}
	public String getAssignedToName() {
		return assignedToName;
	}
	public void setAssignedToName(String assignedToName) {
		this.assignedToName = assignedToName;
	}
	public String getAssignedToEmail() {
		return assignedToEmail;
	}
	public void setAssignedToEmail(String assignedToEmail) {
		this.assignedToEmail = assignedToEmail;
	}
	public String getSamlFederationId() {
		return samlFederationId;
	}
	public void setSamlFederationId(String samlFederationId) {
		this.samlFederationId = samlFederationId;
	}
	public String getEmpMobile() {
		return empMobile;
	}
	public void setEmpMobile(String empMobile) {
		this.empMobile = empMobile;
	}
	
	
	
}
