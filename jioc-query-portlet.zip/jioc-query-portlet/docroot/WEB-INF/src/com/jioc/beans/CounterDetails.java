package com.jioc.beans;

import org.codehaus.jackson.annotate.JsonProperty;

public class CounterDetails {
	@JsonProperty("name")
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
