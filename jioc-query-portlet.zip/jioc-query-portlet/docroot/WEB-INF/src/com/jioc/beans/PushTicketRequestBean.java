package com.jioc.beans;

import org.codehaus.jackson.annotate.JsonProperty;

public class PushTicketRequestBean {
	
	@JsonProperty("ticketDetails")
	TicketDetails ticketDetails;

	public TicketDetails getTicketDetails() {
		return ticketDetails;
	}

	public void setTicketDetails(TicketDetails ticketDetails) {
		this.ticketDetails = ticketDetails;
	}
	
}
