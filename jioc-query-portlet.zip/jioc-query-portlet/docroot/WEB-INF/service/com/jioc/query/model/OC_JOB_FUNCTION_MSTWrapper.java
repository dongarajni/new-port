/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link OC_JOB_FUNCTION_MST}.
 * </p>
 *
 * @author shantaram.chavan
 * @see OC_JOB_FUNCTION_MST
 * @generated
 */
public class OC_JOB_FUNCTION_MSTWrapper implements OC_JOB_FUNCTION_MST,
	ModelWrapper<OC_JOB_FUNCTION_MST> {
	public OC_JOB_FUNCTION_MSTWrapper(OC_JOB_FUNCTION_MST oc_job_function_mst) {
		_oc_job_function_mst = oc_job_function_mst;
	}

	@Override
	public Class<?> getModelClass() {
		return OC_JOB_FUNCTION_MST.class;
	}

	@Override
	public String getModelClassName() {
		return OC_JOB_FUNCTION_MST.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("OC_JOB_FUNCTION_ID", getOC_JOB_FUNCTION_ID());
		attributes.put("FUNCTIONAL_AREA", getFUNCTIONAL_AREA());
		attributes.put("JOB", getJOB());
		attributes.put("OC", getOC());
		attributes.put("SUB_FUNCTIONAL_AREA", getSUB_FUNCTIONAL_AREA());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long OC_JOB_FUNCTION_ID = (Long)attributes.get("OC_JOB_FUNCTION_ID");

		if (OC_JOB_FUNCTION_ID != null) {
			setOC_JOB_FUNCTION_ID(OC_JOB_FUNCTION_ID);
		}

		String FUNCTIONAL_AREA = (String)attributes.get("FUNCTIONAL_AREA");

		if (FUNCTIONAL_AREA != null) {
			setFUNCTIONAL_AREA(FUNCTIONAL_AREA);
		}

		String JOB = (String)attributes.get("JOB");

		if (JOB != null) {
			setJOB(JOB);
		}

		String OC = (String)attributes.get("OC");

		if (OC != null) {
			setOC(OC);
		}

		String SUB_FUNCTIONAL_AREA = (String)attributes.get(
				"SUB_FUNCTIONAL_AREA");

		if (SUB_FUNCTIONAL_AREA != null) {
			setSUB_FUNCTIONAL_AREA(SUB_FUNCTIONAL_AREA);
		}
	}

	/**
	* Returns the primary key of this o c_ j o b_ f u n c t i o n_ m s t.
	*
	* @return the primary key of this o c_ j o b_ f u n c t i o n_ m s t
	*/
	@Override
	public long getPrimaryKey() {
		return _oc_job_function_mst.getPrimaryKey();
	}

	/**
	* Sets the primary key of this o c_ j o b_ f u n c t i o n_ m s t.
	*
	* @param primaryKey the primary key of this o c_ j o b_ f u n c t i o n_ m s t
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_oc_job_function_mst.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the o c_ j o b_ f u n c t i o n_ i d of this o c_ j o b_ f u n c t i o n_ m s t.
	*
	* @return the o c_ j o b_ f u n c t i o n_ i d of this o c_ j o b_ f u n c t i o n_ m s t
	*/
	@Override
	public long getOC_JOB_FUNCTION_ID() {
		return _oc_job_function_mst.getOC_JOB_FUNCTION_ID();
	}

	/**
	* Sets the o c_ j o b_ f u n c t i o n_ i d of this o c_ j o b_ f u n c t i o n_ m s t.
	*
	* @param OC_JOB_FUNCTION_ID the o c_ j o b_ f u n c t i o n_ i d of this o c_ j o b_ f u n c t i o n_ m s t
	*/
	@Override
	public void setOC_JOB_FUNCTION_ID(long OC_JOB_FUNCTION_ID) {
		_oc_job_function_mst.setOC_JOB_FUNCTION_ID(OC_JOB_FUNCTION_ID);
	}

	/**
	* Returns the f u n c t i o n a l_ a r e a of this o c_ j o b_ f u n c t i o n_ m s t.
	*
	* @return the f u n c t i o n a l_ a r e a of this o c_ j o b_ f u n c t i o n_ m s t
	*/
	@Override
	public java.lang.String getFUNCTIONAL_AREA() {
		return _oc_job_function_mst.getFUNCTIONAL_AREA();
	}

	/**
	* Sets the f u n c t i o n a l_ a r e a of this o c_ j o b_ f u n c t i o n_ m s t.
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a of this o c_ j o b_ f u n c t i o n_ m s t
	*/
	@Override
	public void setFUNCTIONAL_AREA(java.lang.String FUNCTIONAL_AREA) {
		_oc_job_function_mst.setFUNCTIONAL_AREA(FUNCTIONAL_AREA);
	}

	/**
	* Returns the j o b of this o c_ j o b_ f u n c t i o n_ m s t.
	*
	* @return the j o b of this o c_ j o b_ f u n c t i o n_ m s t
	*/
	@Override
	public java.lang.String getJOB() {
		return _oc_job_function_mst.getJOB();
	}

	/**
	* Sets the j o b of this o c_ j o b_ f u n c t i o n_ m s t.
	*
	* @param JOB the j o b of this o c_ j o b_ f u n c t i o n_ m s t
	*/
	@Override
	public void setJOB(java.lang.String JOB) {
		_oc_job_function_mst.setJOB(JOB);
	}

	/**
	* Returns the o c of this o c_ j o b_ f u n c t i o n_ m s t.
	*
	* @return the o c of this o c_ j o b_ f u n c t i o n_ m s t
	*/
	@Override
	public java.lang.String getOC() {
		return _oc_job_function_mst.getOC();
	}

	/**
	* Sets the o c of this o c_ j o b_ f u n c t i o n_ m s t.
	*
	* @param OC the o c of this o c_ j o b_ f u n c t i o n_ m s t
	*/
	@Override
	public void setOC(java.lang.String OC) {
		_oc_job_function_mst.setOC(OC);
	}

	/**
	* Returns the s u b_ f u n c t i o n a l_ a r e a of this o c_ j o b_ f u n c t i o n_ m s t.
	*
	* @return the s u b_ f u n c t i o n a l_ a r e a of this o c_ j o b_ f u n c t i o n_ m s t
	*/
	@Override
	public java.lang.String getSUB_FUNCTIONAL_AREA() {
		return _oc_job_function_mst.getSUB_FUNCTIONAL_AREA();
	}

	/**
	* Sets the s u b_ f u n c t i o n a l_ a r e a of this o c_ j o b_ f u n c t i o n_ m s t.
	*
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a of this o c_ j o b_ f u n c t i o n_ m s t
	*/
	@Override
	public void setSUB_FUNCTIONAL_AREA(java.lang.String SUB_FUNCTIONAL_AREA) {
		_oc_job_function_mst.setSUB_FUNCTIONAL_AREA(SUB_FUNCTIONAL_AREA);
	}

	@Override
	public boolean isNew() {
		return _oc_job_function_mst.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_oc_job_function_mst.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _oc_job_function_mst.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_oc_job_function_mst.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _oc_job_function_mst.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _oc_job_function_mst.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_oc_job_function_mst.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _oc_job_function_mst.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_oc_job_function_mst.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_oc_job_function_mst.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_oc_job_function_mst.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new OC_JOB_FUNCTION_MSTWrapper((OC_JOB_FUNCTION_MST)_oc_job_function_mst.clone());
	}

	@Override
	public int compareTo(
		com.jioc.query.model.OC_JOB_FUNCTION_MST oc_job_function_mst) {
		return _oc_job_function_mst.compareTo(oc_job_function_mst);
	}

	@Override
	public int hashCode() {
		return _oc_job_function_mst.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jioc.query.model.OC_JOB_FUNCTION_MST> toCacheModel() {
		return _oc_job_function_mst.toCacheModel();
	}

	@Override
	public com.jioc.query.model.OC_JOB_FUNCTION_MST toEscapedModel() {
		return new OC_JOB_FUNCTION_MSTWrapper(_oc_job_function_mst.toEscapedModel());
	}

	@Override
	public com.jioc.query.model.OC_JOB_FUNCTION_MST toUnescapedModel() {
		return new OC_JOB_FUNCTION_MSTWrapper(_oc_job_function_mst.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _oc_job_function_mst.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _oc_job_function_mst.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_oc_job_function_mst.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof OC_JOB_FUNCTION_MSTWrapper)) {
			return false;
		}

		OC_JOB_FUNCTION_MSTWrapper oc_job_function_mstWrapper = (OC_JOB_FUNCTION_MSTWrapper)obj;

		if (Validator.equals(_oc_job_function_mst,
					oc_job_function_mstWrapper._oc_job_function_mst)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public OC_JOB_FUNCTION_MST getWrappedOC_JOB_FUNCTION_MST() {
		return _oc_job_function_mst;
	}

	@Override
	public OC_JOB_FUNCTION_MST getWrappedModel() {
		return _oc_job_function_mst;
	}

	@Override
	public void resetOriginalValues() {
		_oc_job_function_mst.resetOriginalValues();
	}

	private OC_JOB_FUNCTION_MST _oc_job_function_mst;
}