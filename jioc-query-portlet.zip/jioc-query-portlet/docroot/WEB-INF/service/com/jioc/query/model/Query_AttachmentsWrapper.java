/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Query_Attachments}.
 * </p>
 *
 * @author shantaram.chavan
 * @see Query_Attachments
 * @generated
 */
public class Query_AttachmentsWrapper implements Query_Attachments,
	ModelWrapper<Query_Attachments> {
	public Query_AttachmentsWrapper(Query_Attachments query_Attachments) {
		_query_Attachments = query_Attachments;
	}

	@Override
	public Class<?> getModelClass() {
		return Query_Attachments.class;
	}

	@Override
	public String getModelClassName() {
		return Query_Attachments.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("AttachmentId", getAttachmentId());
		attributes.put("fileEntryId", getFileEntryId());
		attributes.put("updatedBy", getUpdatedBy());
		attributes.put("updatedTimestamp", getUpdatedTimestamp());
		attributes.put("queryId", getQueryId());
		attributes.put("file_name", getFile_name());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long AttachmentId = (Long)attributes.get("AttachmentId");

		if (AttachmentId != null) {
			setAttachmentId(AttachmentId);
		}

		Long fileEntryId = (Long)attributes.get("fileEntryId");

		if (fileEntryId != null) {
			setFileEntryId(fileEntryId);
		}

		Long updatedBy = (Long)attributes.get("updatedBy");

		if (updatedBy != null) {
			setUpdatedBy(updatedBy);
		}

		Date updatedTimestamp = (Date)attributes.get("updatedTimestamp");

		if (updatedTimestamp != null) {
			setUpdatedTimestamp(updatedTimestamp);
		}

		Long queryId = (Long)attributes.get("queryId");

		if (queryId != null) {
			setQueryId(queryId);
		}

		String file_name = (String)attributes.get("file_name");

		if (file_name != null) {
			setFile_name(file_name);
		}
	}

	/**
	* Returns the primary key of this query_ attachments.
	*
	* @return the primary key of this query_ attachments
	*/
	@Override
	public long getPrimaryKey() {
		return _query_Attachments.getPrimaryKey();
	}

	/**
	* Sets the primary key of this query_ attachments.
	*
	* @param primaryKey the primary key of this query_ attachments
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_query_Attachments.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the attachment ID of this query_ attachments.
	*
	* @return the attachment ID of this query_ attachments
	*/
	@Override
	public long getAttachmentId() {
		return _query_Attachments.getAttachmentId();
	}

	/**
	* Sets the attachment ID of this query_ attachments.
	*
	* @param AttachmentId the attachment ID of this query_ attachments
	*/
	@Override
	public void setAttachmentId(long AttachmentId) {
		_query_Attachments.setAttachmentId(AttachmentId);
	}

	/**
	* Returns the file entry ID of this query_ attachments.
	*
	* @return the file entry ID of this query_ attachments
	*/
	@Override
	public long getFileEntryId() {
		return _query_Attachments.getFileEntryId();
	}

	/**
	* Sets the file entry ID of this query_ attachments.
	*
	* @param fileEntryId the file entry ID of this query_ attachments
	*/
	@Override
	public void setFileEntryId(long fileEntryId) {
		_query_Attachments.setFileEntryId(fileEntryId);
	}

	/**
	* Returns the updated by of this query_ attachments.
	*
	* @return the updated by of this query_ attachments
	*/
	@Override
	public long getUpdatedBy() {
		return _query_Attachments.getUpdatedBy();
	}

	/**
	* Sets the updated by of this query_ attachments.
	*
	* @param updatedBy the updated by of this query_ attachments
	*/
	@Override
	public void setUpdatedBy(long updatedBy) {
		_query_Attachments.setUpdatedBy(updatedBy);
	}

	/**
	* Returns the updated timestamp of this query_ attachments.
	*
	* @return the updated timestamp of this query_ attachments
	*/
	@Override
	public java.util.Date getUpdatedTimestamp() {
		return _query_Attachments.getUpdatedTimestamp();
	}

	/**
	* Sets the updated timestamp of this query_ attachments.
	*
	* @param updatedTimestamp the updated timestamp of this query_ attachments
	*/
	@Override
	public void setUpdatedTimestamp(java.util.Date updatedTimestamp) {
		_query_Attachments.setUpdatedTimestamp(updatedTimestamp);
	}

	/**
	* Returns the query ID of this query_ attachments.
	*
	* @return the query ID of this query_ attachments
	*/
	@Override
	public long getQueryId() {
		return _query_Attachments.getQueryId();
	}

	/**
	* Sets the query ID of this query_ attachments.
	*
	* @param queryId the query ID of this query_ attachments
	*/
	@Override
	public void setQueryId(long queryId) {
		_query_Attachments.setQueryId(queryId);
	}

	/**
	* Returns the file_name of this query_ attachments.
	*
	* @return the file_name of this query_ attachments
	*/
	@Override
	public java.lang.String getFile_name() {
		return _query_Attachments.getFile_name();
	}

	/**
	* Sets the file_name of this query_ attachments.
	*
	* @param file_name the file_name of this query_ attachments
	*/
	@Override
	public void setFile_name(java.lang.String file_name) {
		_query_Attachments.setFile_name(file_name);
	}

	@Override
	public boolean isNew() {
		return _query_Attachments.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_query_Attachments.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _query_Attachments.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_query_Attachments.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _query_Attachments.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _query_Attachments.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_query_Attachments.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _query_Attachments.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_query_Attachments.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_query_Attachments.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_query_Attachments.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new Query_AttachmentsWrapper((Query_Attachments)_query_Attachments.clone());
	}

	@Override
	public int compareTo(
		com.jioc.query.model.Query_Attachments query_Attachments) {
		return _query_Attachments.compareTo(query_Attachments);
	}

	@Override
	public int hashCode() {
		return _query_Attachments.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jioc.query.model.Query_Attachments> toCacheModel() {
		return _query_Attachments.toCacheModel();
	}

	@Override
	public com.jioc.query.model.Query_Attachments toEscapedModel() {
		return new Query_AttachmentsWrapper(_query_Attachments.toEscapedModel());
	}

	@Override
	public com.jioc.query.model.Query_Attachments toUnescapedModel() {
		return new Query_AttachmentsWrapper(_query_Attachments.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _query_Attachments.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _query_Attachments.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_query_Attachments.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof Query_AttachmentsWrapper)) {
			return false;
		}

		Query_AttachmentsWrapper query_AttachmentsWrapper = (Query_AttachmentsWrapper)obj;

		if (Validator.equals(_query_Attachments,
					query_AttachmentsWrapper._query_Attachments)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public Query_Attachments getWrappedQuery_Attachments() {
		return _query_Attachments;
	}

	@Override
	public Query_Attachments getWrappedModel() {
		return _query_Attachments;
	}

	@Override
	public void resetOriginalValues() {
		_query_Attachments.resetOriginalValues();
	}

	private Query_Attachments _query_Attachments;
}