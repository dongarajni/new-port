/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Query_Add_Param_OC}.
 * </p>
 *
 * @author shantaram.chavan
 * @see Query_Add_Param_OC
 * @generated
 */
public class Query_Add_Param_OCWrapper implements Query_Add_Param_OC,
	ModelWrapper<Query_Add_Param_OC> {
	public Query_Add_Param_OCWrapper(Query_Add_Param_OC query_Add_Param_OC) {
		_query_Add_Param_OC = query_Add_Param_OC;
	}

	@Override
	public Class<?> getModelClass() {
		return Query_Add_Param_OC.class;
	}

	@Override
	public String getModelClassName() {
		return Query_Add_Param_OC.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("queryAddParamOCId", getQueryAddParamOCId());
		attributes.put("OC", getOC());
		attributes.put("status", getStatus());
		attributes.put("updatedTimestamp", getUpdatedTimestamp());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long queryAddParamOCId = (Long)attributes.get("queryAddParamOCId");

		if (queryAddParamOCId != null) {
			setQueryAddParamOCId(queryAddParamOCId);
		}

		String OC = (String)attributes.get("OC");

		if (OC != null) {
			setOC(OC);
		}

		Integer status = (Integer)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		Date updatedTimestamp = (Date)attributes.get("updatedTimestamp");

		if (updatedTimestamp != null) {
			setUpdatedTimestamp(updatedTimestamp);
		}
	}

	/**
	* Returns the primary key of this query_ add_ param_ o c.
	*
	* @return the primary key of this query_ add_ param_ o c
	*/
	@Override
	public long getPrimaryKey() {
		return _query_Add_Param_OC.getPrimaryKey();
	}

	/**
	* Sets the primary key of this query_ add_ param_ o c.
	*
	* @param primaryKey the primary key of this query_ add_ param_ o c
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_query_Add_Param_OC.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the query add param o c ID of this query_ add_ param_ o c.
	*
	* @return the query add param o c ID of this query_ add_ param_ o c
	*/
	@Override
	public long getQueryAddParamOCId() {
		return _query_Add_Param_OC.getQueryAddParamOCId();
	}

	/**
	* Sets the query add param o c ID of this query_ add_ param_ o c.
	*
	* @param queryAddParamOCId the query add param o c ID of this query_ add_ param_ o c
	*/
	@Override
	public void setQueryAddParamOCId(long queryAddParamOCId) {
		_query_Add_Param_OC.setQueryAddParamOCId(queryAddParamOCId);
	}

	/**
	* Returns the o c of this query_ add_ param_ o c.
	*
	* @return the o c of this query_ add_ param_ o c
	*/
	@Override
	public java.lang.String getOC() {
		return _query_Add_Param_OC.getOC();
	}

	/**
	* Sets the o c of this query_ add_ param_ o c.
	*
	* @param OC the o c of this query_ add_ param_ o c
	*/
	@Override
	public void setOC(java.lang.String OC) {
		_query_Add_Param_OC.setOC(OC);
	}

	/**
	* Returns the status of this query_ add_ param_ o c.
	*
	* @return the status of this query_ add_ param_ o c
	*/
	@Override
	public int getStatus() {
		return _query_Add_Param_OC.getStatus();
	}

	/**
	* Sets the status of this query_ add_ param_ o c.
	*
	* @param status the status of this query_ add_ param_ o c
	*/
	@Override
	public void setStatus(int status) {
		_query_Add_Param_OC.setStatus(status);
	}

	/**
	* Returns the updated timestamp of this query_ add_ param_ o c.
	*
	* @return the updated timestamp of this query_ add_ param_ o c
	*/
	@Override
	public java.util.Date getUpdatedTimestamp() {
		return _query_Add_Param_OC.getUpdatedTimestamp();
	}

	/**
	* Sets the updated timestamp of this query_ add_ param_ o c.
	*
	* @param updatedTimestamp the updated timestamp of this query_ add_ param_ o c
	*/
	@Override
	public void setUpdatedTimestamp(java.util.Date updatedTimestamp) {
		_query_Add_Param_OC.setUpdatedTimestamp(updatedTimestamp);
	}

	@Override
	public boolean isNew() {
		return _query_Add_Param_OC.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_query_Add_Param_OC.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _query_Add_Param_OC.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_query_Add_Param_OC.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _query_Add_Param_OC.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _query_Add_Param_OC.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_query_Add_Param_OC.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _query_Add_Param_OC.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_query_Add_Param_OC.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_query_Add_Param_OC.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_query_Add_Param_OC.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new Query_Add_Param_OCWrapper((Query_Add_Param_OC)_query_Add_Param_OC.clone());
	}

	@Override
	public int compareTo(
		com.jioc.query.model.Query_Add_Param_OC query_Add_Param_OC) {
		return _query_Add_Param_OC.compareTo(query_Add_Param_OC);
	}

	@Override
	public int hashCode() {
		return _query_Add_Param_OC.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jioc.query.model.Query_Add_Param_OC> toCacheModel() {
		return _query_Add_Param_OC.toCacheModel();
	}

	@Override
	public com.jioc.query.model.Query_Add_Param_OC toEscapedModel() {
		return new Query_Add_Param_OCWrapper(_query_Add_Param_OC.toEscapedModel());
	}

	@Override
	public com.jioc.query.model.Query_Add_Param_OC toUnescapedModel() {
		return new Query_Add_Param_OCWrapper(_query_Add_Param_OC.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _query_Add_Param_OC.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _query_Add_Param_OC.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_query_Add_Param_OC.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof Query_Add_Param_OCWrapper)) {
			return false;
		}

		Query_Add_Param_OCWrapper query_Add_Param_OCWrapper = (Query_Add_Param_OCWrapper)obj;

		if (Validator.equals(_query_Add_Param_OC,
					query_Add_Param_OCWrapper._query_Add_Param_OC)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public Query_Add_Param_OC getWrappedQuery_Add_Param_OC() {
		return _query_Add_Param_OC;
	}

	@Override
	public Query_Add_Param_OC getWrappedModel() {
		return _query_Add_Param_OC;
	}

	@Override
	public void resetOriginalValues() {
		_query_Add_Param_OC.resetOriginalValues();
	}

	private Query_Add_Param_OC _query_Add_Param_OC;
}