/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.jioc.query.service.ClpSerializer;
import com.jioc.query.service.Query_Add_Param_OCLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author shantaram.chavan
 */
public class Query_Add_Param_OCClp extends BaseModelImpl<Query_Add_Param_OC>
	implements Query_Add_Param_OC {
	public Query_Add_Param_OCClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return Query_Add_Param_OC.class;
	}

	@Override
	public String getModelClassName() {
		return Query_Add_Param_OC.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _queryAddParamOCId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setQueryAddParamOCId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _queryAddParamOCId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("queryAddParamOCId", getQueryAddParamOCId());
		attributes.put("OC", getOC());
		attributes.put("status", getStatus());
		attributes.put("updatedTimestamp", getUpdatedTimestamp());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long queryAddParamOCId = (Long)attributes.get("queryAddParamOCId");

		if (queryAddParamOCId != null) {
			setQueryAddParamOCId(queryAddParamOCId);
		}

		String OC = (String)attributes.get("OC");

		if (OC != null) {
			setOC(OC);
		}

		Integer status = (Integer)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		Date updatedTimestamp = (Date)attributes.get("updatedTimestamp");

		if (updatedTimestamp != null) {
			setUpdatedTimestamp(updatedTimestamp);
		}
	}

	@Override
	public long getQueryAddParamOCId() {
		return _queryAddParamOCId;
	}

	@Override
	public void setQueryAddParamOCId(long queryAddParamOCId) {
		_queryAddParamOCId = queryAddParamOCId;

		if (_query_Add_Param_OCRemoteModel != null) {
			try {
				Class<?> clazz = _query_Add_Param_OCRemoteModel.getClass();

				Method method = clazz.getMethod("setQueryAddParamOCId",
						long.class);

				method.invoke(_query_Add_Param_OCRemoteModel, queryAddParamOCId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOC() {
		return _OC;
	}

	@Override
	public void setOC(String OC) {
		_OC = OC;

		if (_query_Add_Param_OCRemoteModel != null) {
			try {
				Class<?> clazz = _query_Add_Param_OCRemoteModel.getClass();

				Method method = clazz.getMethod("setOC", String.class);

				method.invoke(_query_Add_Param_OCRemoteModel, OC);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getStatus() {
		return _status;
	}

	@Override
	public void setStatus(int status) {
		_status = status;

		if (_query_Add_Param_OCRemoteModel != null) {
			try {
				Class<?> clazz = _query_Add_Param_OCRemoteModel.getClass();

				Method method = clazz.getMethod("setStatus", int.class);

				method.invoke(_query_Add_Param_OCRemoteModel, status);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getUpdatedTimestamp() {
		return _updatedTimestamp;
	}

	@Override
	public void setUpdatedTimestamp(Date updatedTimestamp) {
		_updatedTimestamp = updatedTimestamp;

		if (_query_Add_Param_OCRemoteModel != null) {
			try {
				Class<?> clazz = _query_Add_Param_OCRemoteModel.getClass();

				Method method = clazz.getMethod("setUpdatedTimestamp",
						Date.class);

				method.invoke(_query_Add_Param_OCRemoteModel, updatedTimestamp);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getQuery_Add_Param_OCRemoteModel() {
		return _query_Add_Param_OCRemoteModel;
	}

	public void setQuery_Add_Param_OCRemoteModel(
		BaseModel<?> query_Add_Param_OCRemoteModel) {
		_query_Add_Param_OCRemoteModel = query_Add_Param_OCRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _query_Add_Param_OCRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_query_Add_Param_OCRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			Query_Add_Param_OCLocalServiceUtil.addQuery_Add_Param_OC(this);
		}
		else {
			Query_Add_Param_OCLocalServiceUtil.updateQuery_Add_Param_OC(this);
		}
	}

	@Override
	public Query_Add_Param_OC toEscapedModel() {
		return (Query_Add_Param_OC)ProxyUtil.newProxyInstance(Query_Add_Param_OC.class.getClassLoader(),
			new Class[] { Query_Add_Param_OC.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		Query_Add_Param_OCClp clone = new Query_Add_Param_OCClp();

		clone.setQueryAddParamOCId(getQueryAddParamOCId());
		clone.setOC(getOC());
		clone.setStatus(getStatus());
		clone.setUpdatedTimestamp(getUpdatedTimestamp());

		return clone;
	}

	@Override
	public int compareTo(Query_Add_Param_OC query_Add_Param_OC) {
		long primaryKey = query_Add_Param_OC.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof Query_Add_Param_OCClp)) {
			return false;
		}

		Query_Add_Param_OCClp query_Add_Param_OC = (Query_Add_Param_OCClp)obj;

		long primaryKey = query_Add_Param_OC.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(9);

		sb.append("{queryAddParamOCId=");
		sb.append(getQueryAddParamOCId());
		sb.append(", OC=");
		sb.append(getOC());
		sb.append(", status=");
		sb.append(getStatus());
		sb.append(", updatedTimestamp=");
		sb.append(getUpdatedTimestamp());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(16);

		sb.append("<model><model-name>");
		sb.append("com.jioc.query.model.Query_Add_Param_OC");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>queryAddParamOCId</column-name><column-value><![CDATA[");
		sb.append(getQueryAddParamOCId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>OC</column-name><column-value><![CDATA[");
		sb.append(getOC());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>status</column-name><column-value><![CDATA[");
		sb.append(getStatus());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>updatedTimestamp</column-name><column-value><![CDATA[");
		sb.append(getUpdatedTimestamp());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _queryAddParamOCId;
	private String _OC;
	private int _status;
	private Date _updatedTimestamp;
	private BaseModel<?> _query_Add_Param_OCRemoteModel;
	private Class<?> _clpSerializerClass = com.jioc.query.service.ClpSerializer.class;
}