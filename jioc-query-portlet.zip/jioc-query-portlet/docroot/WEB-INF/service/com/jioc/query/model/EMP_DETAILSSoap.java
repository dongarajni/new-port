/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author shantaram.chavan
 * @generated
 */
public class EMP_DETAILSSoap implements Serializable {
	public static EMP_DETAILSSoap toSoapModel(EMP_DETAILS model) {
		EMP_DETAILSSoap soapModel = new EMP_DETAILSSoap();

		soapModel.setEMP_ID(model.getEMP_ID());
		soapModel.setAREA(model.getAREA());
		soapModel.setCADRE(model.getCADRE());
		soapModel.setCLIENT_ID(model.getCLIENT_ID());
		soapModel.setCOMPANY_CODE(model.getCOMPANY_CODE());
		soapModel.setCOMPANY_TEXT(model.getCOMPANY_TEXT());
		soapModel.setDATE_OF_BIRTH(model.getDATE_OF_BIRTH());
		soapModel.setDATE_OF_JOINING(model.getDATE_OF_JOINING());
		soapModel.setDATE_OF_LEAVE(model.getDATE_OF_LEAVE());
		soapModel.setDEPARTMENT(model.getDEPARTMENT());
		soapModel.setDESIGNATION_CODE(model.getDESIGNATION_CODE());
		soapModel.setDESIGNATION_TEXT(model.getDESIGNATION_TEXT());
		soapModel.setEMAIL(model.getEMAIL());
		soapModel.setEMP_GROUP(model.getEMP_GROUP());
		soapModel.setEMPLOYEE_DOMAIN_ID(model.getEMPLOYEE_DOMAIN_ID());
		soapModel.setEMPLOYMENT_STATUS(model.getEMPLOYMENT_STATUS());
		soapModel.setEMPLOYMENT_STATUS_TEXT(model.getEMPLOYMENT_STATUS_TEXT());
		soapModel.setFIRST_NAME(model.getFIRST_NAME());
		soapModel.setFULL_NAME(model.getFULL_NAME());
		soapModel.setGENDER_TEXT(model.getGENDER_TEXT());
		soapModel.setHR_EMAIL(model.getHR_EMAIL());
		soapModel.setHR_EMP_CD(model.getHR_EMP_CD());
		soapModel.setHR_HEAD_EMPCD(model.getHR_HEAD_EMPCD());
		soapModel.setHR_HEAD_NAME(model.getHR_HEAD_NAME());
		soapModel.setHR_NAME(model.getHR_NAME());
		soapModel.setJIO_CENTER(model.getJIO_CENTER());
		soapModel.setJIO_ID(model.getJIO_ID());
		soapModel.setJO_REGION(model.getJO_REGION());
		soapModel.setJO_TYPE(model.getJO_TYPE());
		soapModel.setJOB(model.getJOB());
		soapModel.setJOB_ROLE_CODE(model.getJOB_ROLE_CODE());
		soapModel.setL1_EMAIL_ID(model.getL1_EMAIL_ID());
		soapModel.setL1_EMPLOYEE_CODE(model.getL1_EMPLOYEE_CODE());
		soapModel.setL1_NAME(model.getL1_NAME());
		soapModel.setLAST_NAME(model.getLAST_NAME());
		soapModel.setLOCATION_CITY(model.getLOCATION_CITY());
		soapModel.setLOCATION_CODE(model.getLOCATION_CODE());
		soapModel.setLOCATION_COUNTRY(model.getLOCATION_COUNTRY());
		soapModel.setLOCATION_STATE(model.getLOCATION_STATE());
		soapModel.setLOCATION_TEXT(model.getLOCATION_TEXT());
		soapModel.setMOBILE_NO(model.getMOBILE_NO());
		soapModel.setOFFICE_NO(model.getOFFICE_NO());
		soapModel.setORG_UNIT(model.getORG_UNIT());
		soapModel.setORG_UNIT_TEXT(model.getORG_UNIT_TEXT());
		soapModel.setPERSONNEL_AREA_CODE(model.getPERSONNEL_AREA_CODE());
		soapModel.setR4G_STATE(model.getR4G_STATE());
		soapModel.setSAML_FEDERATION_ID(model.getSAML_FEDERATION_ID());
		soapModel.setSTORE_CODE(model.getSTORE_CODE());
		soapModel.setSUB_FUNCTIONAL_AREA(model.getSUB_FUNCTIONAL_AREA());
		soapModel.setTITLE(model.getTITLE());
		soapModel.setIS_RESOLVER(model.getIS_RESOLVER());
		soapModel.setRESOLVER_LEVEL(model.getRESOLVER_LEVEL());
		soapModel.setPERSONAL_AREA_TEXT(model.getPERSONAL_AREA_TEXT());
		soapModel.setFUNCTIONAL_AREA(model.getFUNCTIONAL_AREA());
		soapModel.setRESOLVER_STATUS(model.getRESOLVER_STATUS());

		return soapModel;
	}

	public static EMP_DETAILSSoap[] toSoapModels(EMP_DETAILS[] models) {
		EMP_DETAILSSoap[] soapModels = new EMP_DETAILSSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static EMP_DETAILSSoap[][] toSoapModels(EMP_DETAILS[][] models) {
		EMP_DETAILSSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new EMP_DETAILSSoap[models.length][models[0].length];
		}
		else {
			soapModels = new EMP_DETAILSSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static EMP_DETAILSSoap[] toSoapModels(List<EMP_DETAILS> models) {
		List<EMP_DETAILSSoap> soapModels = new ArrayList<EMP_DETAILSSoap>(models.size());

		for (EMP_DETAILS model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new EMP_DETAILSSoap[soapModels.size()]);
	}

	public EMP_DETAILSSoap() {
	}

	public String getPrimaryKey() {
		return _EMP_ID;
	}

	public void setPrimaryKey(String pk) {
		setEMP_ID(pk);
	}

	public String getEMP_ID() {
		return _EMP_ID;
	}

	public void setEMP_ID(String EMP_ID) {
		_EMP_ID = EMP_ID;
	}

	public String getAREA() {
		return _AREA;
	}

	public void setAREA(String AREA) {
		_AREA = AREA;
	}

	public String getCADRE() {
		return _CADRE;
	}

	public void setCADRE(String CADRE) {
		_CADRE = CADRE;
	}

	public String getCLIENT_ID() {
		return _CLIENT_ID;
	}

	public void setCLIENT_ID(String CLIENT_ID) {
		_CLIENT_ID = CLIENT_ID;
	}

	public String getCOMPANY_CODE() {
		return _COMPANY_CODE;
	}

	public void setCOMPANY_CODE(String COMPANY_CODE) {
		_COMPANY_CODE = COMPANY_CODE;
	}

	public String getCOMPANY_TEXT() {
		return _COMPANY_TEXT;
	}

	public void setCOMPANY_TEXT(String COMPANY_TEXT) {
		_COMPANY_TEXT = COMPANY_TEXT;
	}

	public Date getDATE_OF_BIRTH() {
		return _DATE_OF_BIRTH;
	}

	public void setDATE_OF_BIRTH(Date DATE_OF_BIRTH) {
		_DATE_OF_BIRTH = DATE_OF_BIRTH;
	}

	public Date getDATE_OF_JOINING() {
		return _DATE_OF_JOINING;
	}

	public void setDATE_OF_JOINING(Date DATE_OF_JOINING) {
		_DATE_OF_JOINING = DATE_OF_JOINING;
	}

	public Date getDATE_OF_LEAVE() {
		return _DATE_OF_LEAVE;
	}

	public void setDATE_OF_LEAVE(Date DATE_OF_LEAVE) {
		_DATE_OF_LEAVE = DATE_OF_LEAVE;
	}

	public String getDEPARTMENT() {
		return _DEPARTMENT;
	}

	public void setDEPARTMENT(String DEPARTMENT) {
		_DEPARTMENT = DEPARTMENT;
	}

	public String getDESIGNATION_CODE() {
		return _DESIGNATION_CODE;
	}

	public void setDESIGNATION_CODE(String DESIGNATION_CODE) {
		_DESIGNATION_CODE = DESIGNATION_CODE;
	}

	public String getDESIGNATION_TEXT() {
		return _DESIGNATION_TEXT;
	}

	public void setDESIGNATION_TEXT(String DESIGNATION_TEXT) {
		_DESIGNATION_TEXT = DESIGNATION_TEXT;
	}

	public String getEMAIL() {
		return _EMAIL;
	}

	public void setEMAIL(String EMAIL) {
		_EMAIL = EMAIL;
	}

	public String getEMP_GROUP() {
		return _EMP_GROUP;
	}

	public void setEMP_GROUP(String EMP_GROUP) {
		_EMP_GROUP = EMP_GROUP;
	}

	public String getEMPLOYEE_DOMAIN_ID() {
		return _EMPLOYEE_DOMAIN_ID;
	}

	public void setEMPLOYEE_DOMAIN_ID(String EMPLOYEE_DOMAIN_ID) {
		_EMPLOYEE_DOMAIN_ID = EMPLOYEE_DOMAIN_ID;
	}

	public String getEMPLOYMENT_STATUS() {
		return _EMPLOYMENT_STATUS;
	}

	public void setEMPLOYMENT_STATUS(String EMPLOYMENT_STATUS) {
		_EMPLOYMENT_STATUS = EMPLOYMENT_STATUS;
	}

	public String getEMPLOYMENT_STATUS_TEXT() {
		return _EMPLOYMENT_STATUS_TEXT;
	}

	public void setEMPLOYMENT_STATUS_TEXT(String EMPLOYMENT_STATUS_TEXT) {
		_EMPLOYMENT_STATUS_TEXT = EMPLOYMENT_STATUS_TEXT;
	}

	public String getFIRST_NAME() {
		return _FIRST_NAME;
	}

	public void setFIRST_NAME(String FIRST_NAME) {
		_FIRST_NAME = FIRST_NAME;
	}

	public String getFULL_NAME() {
		return _FULL_NAME;
	}

	public void setFULL_NAME(String FULL_NAME) {
		_FULL_NAME = FULL_NAME;
	}

	public String getGENDER_TEXT() {
		return _GENDER_TEXT;
	}

	public void setGENDER_TEXT(String GENDER_TEXT) {
		_GENDER_TEXT = GENDER_TEXT;
	}

	public String getHR_EMAIL() {
		return _HR_EMAIL;
	}

	public void setHR_EMAIL(String HR_EMAIL) {
		_HR_EMAIL = HR_EMAIL;
	}

	public String getHR_EMP_CD() {
		return _HR_EMP_CD;
	}

	public void setHR_EMP_CD(String HR_EMP_CD) {
		_HR_EMP_CD = HR_EMP_CD;
	}

	public String getHR_HEAD_EMPCD() {
		return _HR_HEAD_EMPCD;
	}

	public void setHR_HEAD_EMPCD(String HR_HEAD_EMPCD) {
		_HR_HEAD_EMPCD = HR_HEAD_EMPCD;
	}

	public String getHR_HEAD_NAME() {
		return _HR_HEAD_NAME;
	}

	public void setHR_HEAD_NAME(String HR_HEAD_NAME) {
		_HR_HEAD_NAME = HR_HEAD_NAME;
	}

	public String getHR_NAME() {
		return _HR_NAME;
	}

	public void setHR_NAME(String HR_NAME) {
		_HR_NAME = HR_NAME;
	}

	public String getJIO_CENTER() {
		return _JIO_CENTER;
	}

	public void setJIO_CENTER(String JIO_CENTER) {
		_JIO_CENTER = JIO_CENTER;
	}

	public String getJIO_ID() {
		return _JIO_ID;
	}

	public void setJIO_ID(String JIO_ID) {
		_JIO_ID = JIO_ID;
	}

	public String getJO_REGION() {
		return _JO_REGION;
	}

	public void setJO_REGION(String JO_REGION) {
		_JO_REGION = JO_REGION;
	}

	public String getJO_TYPE() {
		return _JO_TYPE;
	}

	public void setJO_TYPE(String JO_TYPE) {
		_JO_TYPE = JO_TYPE;
	}

	public String getJOB() {
		return _JOB;
	}

	public void setJOB(String JOB) {
		_JOB = JOB;
	}

	public String getJOB_ROLE_CODE() {
		return _JOB_ROLE_CODE;
	}

	public void setJOB_ROLE_CODE(String JOB_ROLE_CODE) {
		_JOB_ROLE_CODE = JOB_ROLE_CODE;
	}

	public String getL1_EMAIL_ID() {
		return _L1_EMAIL_ID;
	}

	public void setL1_EMAIL_ID(String L1_EMAIL_ID) {
		_L1_EMAIL_ID = L1_EMAIL_ID;
	}

	public String getL1_EMPLOYEE_CODE() {
		return _L1_EMPLOYEE_CODE;
	}

	public void setL1_EMPLOYEE_CODE(String L1_EMPLOYEE_CODE) {
		_L1_EMPLOYEE_CODE = L1_EMPLOYEE_CODE;
	}

	public String getL1_NAME() {
		return _L1_NAME;
	}

	public void setL1_NAME(String L1_NAME) {
		_L1_NAME = L1_NAME;
	}

	public String getLAST_NAME() {
		return _LAST_NAME;
	}

	public void setLAST_NAME(String LAST_NAME) {
		_LAST_NAME = LAST_NAME;
	}

	public String getLOCATION_CITY() {
		return _LOCATION_CITY;
	}

	public void setLOCATION_CITY(String LOCATION_CITY) {
		_LOCATION_CITY = LOCATION_CITY;
	}

	public String getLOCATION_CODE() {
		return _LOCATION_CODE;
	}

	public void setLOCATION_CODE(String LOCATION_CODE) {
		_LOCATION_CODE = LOCATION_CODE;
	}

	public String getLOCATION_COUNTRY() {
		return _LOCATION_COUNTRY;
	}

	public void setLOCATION_COUNTRY(String LOCATION_COUNTRY) {
		_LOCATION_COUNTRY = LOCATION_COUNTRY;
	}

	public String getLOCATION_STATE() {
		return _LOCATION_STATE;
	}

	public void setLOCATION_STATE(String LOCATION_STATE) {
		_LOCATION_STATE = LOCATION_STATE;
	}

	public String getLOCATION_TEXT() {
		return _LOCATION_TEXT;
	}

	public void setLOCATION_TEXT(String LOCATION_TEXT) {
		_LOCATION_TEXT = LOCATION_TEXT;
	}

	public String getMOBILE_NO() {
		return _MOBILE_NO;
	}

	public void setMOBILE_NO(String MOBILE_NO) {
		_MOBILE_NO = MOBILE_NO;
	}

	public String getOFFICE_NO() {
		return _OFFICE_NO;
	}

	public void setOFFICE_NO(String OFFICE_NO) {
		_OFFICE_NO = OFFICE_NO;
	}

	public String getORG_UNIT() {
		return _ORG_UNIT;
	}

	public void setORG_UNIT(String ORG_UNIT) {
		_ORG_UNIT = ORG_UNIT;
	}

	public String getORG_UNIT_TEXT() {
		return _ORG_UNIT_TEXT;
	}

	public void setORG_UNIT_TEXT(String ORG_UNIT_TEXT) {
		_ORG_UNIT_TEXT = ORG_UNIT_TEXT;
	}

	public String getPERSONNEL_AREA_CODE() {
		return _PERSONNEL_AREA_CODE;
	}

	public void setPERSONNEL_AREA_CODE(String PERSONNEL_AREA_CODE) {
		_PERSONNEL_AREA_CODE = PERSONNEL_AREA_CODE;
	}

	public String getR4G_STATE() {
		return _R4G_STATE;
	}

	public void setR4G_STATE(String R4G_STATE) {
		_R4G_STATE = R4G_STATE;
	}

	public String getSAML_FEDERATION_ID() {
		return _SAML_FEDERATION_ID;
	}

	public void setSAML_FEDERATION_ID(String SAML_FEDERATION_ID) {
		_SAML_FEDERATION_ID = SAML_FEDERATION_ID;
	}

	public String getSTORE_CODE() {
		return _STORE_CODE;
	}

	public void setSTORE_CODE(String STORE_CODE) {
		_STORE_CODE = STORE_CODE;
	}

	public String getSUB_FUNCTIONAL_AREA() {
		return _SUB_FUNCTIONAL_AREA;
	}

	public void setSUB_FUNCTIONAL_AREA(String SUB_FUNCTIONAL_AREA) {
		_SUB_FUNCTIONAL_AREA = SUB_FUNCTIONAL_AREA;
	}

	public String getTITLE() {
		return _TITLE;
	}

	public void setTITLE(String TITLE) {
		_TITLE = TITLE;
	}

	public int getIS_RESOLVER() {
		return _IS_RESOLVER;
	}

	public void setIS_RESOLVER(int IS_RESOLVER) {
		_IS_RESOLVER = IS_RESOLVER;
	}

	public int getRESOLVER_LEVEL() {
		return _RESOLVER_LEVEL;
	}

	public void setRESOLVER_LEVEL(int RESOLVER_LEVEL) {
		_RESOLVER_LEVEL = RESOLVER_LEVEL;
	}

	public String getPERSONAL_AREA_TEXT() {
		return _PERSONAL_AREA_TEXT;
	}

	public void setPERSONAL_AREA_TEXT(String PERSONAL_AREA_TEXT) {
		_PERSONAL_AREA_TEXT = PERSONAL_AREA_TEXT;
	}

	public String getFUNCTIONAL_AREA() {
		return _FUNCTIONAL_AREA;
	}

	public void setFUNCTIONAL_AREA(String FUNCTIONAL_AREA) {
		_FUNCTIONAL_AREA = FUNCTIONAL_AREA;
	}

	public int getRESOLVER_STATUS() {
		return _RESOLVER_STATUS;
	}

	public void setRESOLVER_STATUS(int RESOLVER_STATUS) {
		_RESOLVER_STATUS = RESOLVER_STATUS;
	}

	private String _EMP_ID;
	private String _AREA;
	private String _CADRE;
	private String _CLIENT_ID;
	private String _COMPANY_CODE;
	private String _COMPANY_TEXT;
	private Date _DATE_OF_BIRTH;
	private Date _DATE_OF_JOINING;
	private Date _DATE_OF_LEAVE;
	private String _DEPARTMENT;
	private String _DESIGNATION_CODE;
	private String _DESIGNATION_TEXT;
	private String _EMAIL;
	private String _EMP_GROUP;
	private String _EMPLOYEE_DOMAIN_ID;
	private String _EMPLOYMENT_STATUS;
	private String _EMPLOYMENT_STATUS_TEXT;
	private String _FIRST_NAME;
	private String _FULL_NAME;
	private String _GENDER_TEXT;
	private String _HR_EMAIL;
	private String _HR_EMP_CD;
	private String _HR_HEAD_EMPCD;
	private String _HR_HEAD_NAME;
	private String _HR_NAME;
	private String _JIO_CENTER;
	private String _JIO_ID;
	private String _JO_REGION;
	private String _JO_TYPE;
	private String _JOB;
	private String _JOB_ROLE_CODE;
	private String _L1_EMAIL_ID;
	private String _L1_EMPLOYEE_CODE;
	private String _L1_NAME;
	private String _LAST_NAME;
	private String _LOCATION_CITY;
	private String _LOCATION_CODE;
	private String _LOCATION_COUNTRY;
	private String _LOCATION_STATE;
	private String _LOCATION_TEXT;
	private String _MOBILE_NO;
	private String _OFFICE_NO;
	private String _ORG_UNIT;
	private String _ORG_UNIT_TEXT;
	private String _PERSONNEL_AREA_CODE;
	private String _R4G_STATE;
	private String _SAML_FEDERATION_ID;
	private String _STORE_CODE;
	private String _SUB_FUNCTIONAL_AREA;
	private String _TITLE;
	private int _IS_RESOLVER;
	private int _RESOLVER_LEVEL;
	private String _PERSONAL_AREA_TEXT;
	private String _FUNCTIONAL_AREA;
	private int _RESOLVER_STATUS;
}