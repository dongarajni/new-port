/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link EMP_DETAILS}.
 * </p>
 *
 * @author shantaram.chavan
 * @see EMP_DETAILS
 * @generated
 */
public class EMP_DETAILSWrapper implements EMP_DETAILS,
	ModelWrapper<EMP_DETAILS> {
	public EMP_DETAILSWrapper(EMP_DETAILS emp_details) {
		_emp_details = emp_details;
	}

	@Override
	public Class<?> getModelClass() {
		return EMP_DETAILS.class;
	}

	@Override
	public String getModelClassName() {
		return EMP_DETAILS.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("EMP_ID", getEMP_ID());
		attributes.put("AREA", getAREA());
		attributes.put("CADRE", getCADRE());
		attributes.put("CLIENT_ID", getCLIENT_ID());
		attributes.put("COMPANY_CODE", getCOMPANY_CODE());
		attributes.put("COMPANY_TEXT", getCOMPANY_TEXT());
		attributes.put("DATE_OF_BIRTH", getDATE_OF_BIRTH());
		attributes.put("DATE_OF_JOINING", getDATE_OF_JOINING());
		attributes.put("DATE_OF_LEAVE", getDATE_OF_LEAVE());
		attributes.put("DEPARTMENT", getDEPARTMENT());
		attributes.put("DESIGNATION_CODE", getDESIGNATION_CODE());
		attributes.put("DESIGNATION_TEXT", getDESIGNATION_TEXT());
		attributes.put("EMAIL", getEMAIL());
		attributes.put("EMP_GROUP", getEMP_GROUP());
		attributes.put("EMPLOYEE_DOMAIN_ID", getEMPLOYEE_DOMAIN_ID());
		attributes.put("EMPLOYMENT_STATUS", getEMPLOYMENT_STATUS());
		attributes.put("EMPLOYMENT_STATUS_TEXT", getEMPLOYMENT_STATUS_TEXT());
		attributes.put("FIRST_NAME", getFIRST_NAME());
		attributes.put("FULL_NAME", getFULL_NAME());
		attributes.put("GENDER_TEXT", getGENDER_TEXT());
		attributes.put("HR_EMAIL", getHR_EMAIL());
		attributes.put("HR_EMP_CD", getHR_EMP_CD());
		attributes.put("HR_HEAD_EMPCD", getHR_HEAD_EMPCD());
		attributes.put("HR_HEAD_NAME", getHR_HEAD_NAME());
		attributes.put("HR_NAME", getHR_NAME());
		attributes.put("JIO_CENTER", getJIO_CENTER());
		attributes.put("JIO_ID", getJIO_ID());
		attributes.put("JO_REGION", getJO_REGION());
		attributes.put("JO_TYPE", getJO_TYPE());
		attributes.put("JOB", getJOB());
		attributes.put("JOB_ROLE_CODE", getJOB_ROLE_CODE());
		attributes.put("L1_EMAIL_ID", getL1_EMAIL_ID());
		attributes.put("L1_EMPLOYEE_CODE", getL1_EMPLOYEE_CODE());
		attributes.put("L1_NAME", getL1_NAME());
		attributes.put("LAST_NAME", getLAST_NAME());
		attributes.put("LOCATION_CITY", getLOCATION_CITY());
		attributes.put("LOCATION_CODE", getLOCATION_CODE());
		attributes.put("LOCATION_COUNTRY", getLOCATION_COUNTRY());
		attributes.put("LOCATION_STATE", getLOCATION_STATE());
		attributes.put("LOCATION_TEXT", getLOCATION_TEXT());
		attributes.put("MOBILE_NO", getMOBILE_NO());
		attributes.put("OFFICE_NO", getOFFICE_NO());
		attributes.put("ORG_UNIT", getORG_UNIT());
		attributes.put("ORG_UNIT_TEXT", getORG_UNIT_TEXT());
		attributes.put("PERSONNEL_AREA_CODE", getPERSONNEL_AREA_CODE());
		attributes.put("R4G_STATE", getR4G_STATE());
		attributes.put("SAML_FEDERATION_ID", getSAML_FEDERATION_ID());
		attributes.put("STORE_CODE", getSTORE_CODE());
		attributes.put("SUB_FUNCTIONAL_AREA", getSUB_FUNCTIONAL_AREA());
		attributes.put("TITLE", getTITLE());
		attributes.put("IS_RESOLVER", getIS_RESOLVER());
		attributes.put("RESOLVER_LEVEL", getRESOLVER_LEVEL());
		attributes.put("PERSONAL_AREA_TEXT", getPERSONAL_AREA_TEXT());
		attributes.put("FUNCTIONAL_AREA", getFUNCTIONAL_AREA());
		attributes.put("RESOLVER_STATUS", getRESOLVER_STATUS());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String EMP_ID = (String)attributes.get("EMP_ID");

		if (EMP_ID != null) {
			setEMP_ID(EMP_ID);
		}

		String AREA = (String)attributes.get("AREA");

		if (AREA != null) {
			setAREA(AREA);
		}

		String CADRE = (String)attributes.get("CADRE");

		if (CADRE != null) {
			setCADRE(CADRE);
		}

		String CLIENT_ID = (String)attributes.get("CLIENT_ID");

		if (CLIENT_ID != null) {
			setCLIENT_ID(CLIENT_ID);
		}

		String COMPANY_CODE = (String)attributes.get("COMPANY_CODE");

		if (COMPANY_CODE != null) {
			setCOMPANY_CODE(COMPANY_CODE);
		}

		String COMPANY_TEXT = (String)attributes.get("COMPANY_TEXT");

		if (COMPANY_TEXT != null) {
			setCOMPANY_TEXT(COMPANY_TEXT);
		}

		Date DATE_OF_BIRTH = (Date)attributes.get("DATE_OF_BIRTH");

		if (DATE_OF_BIRTH != null) {
			setDATE_OF_BIRTH(DATE_OF_BIRTH);
		}

		Date DATE_OF_JOINING = (Date)attributes.get("DATE_OF_JOINING");

		if (DATE_OF_JOINING != null) {
			setDATE_OF_JOINING(DATE_OF_JOINING);
		}

		Date DATE_OF_LEAVE = (Date)attributes.get("DATE_OF_LEAVE");

		if (DATE_OF_LEAVE != null) {
			setDATE_OF_LEAVE(DATE_OF_LEAVE);
		}

		String DEPARTMENT = (String)attributes.get("DEPARTMENT");

		if (DEPARTMENT != null) {
			setDEPARTMENT(DEPARTMENT);
		}

		String DESIGNATION_CODE = (String)attributes.get("DESIGNATION_CODE");

		if (DESIGNATION_CODE != null) {
			setDESIGNATION_CODE(DESIGNATION_CODE);
		}

		String DESIGNATION_TEXT = (String)attributes.get("DESIGNATION_TEXT");

		if (DESIGNATION_TEXT != null) {
			setDESIGNATION_TEXT(DESIGNATION_TEXT);
		}

		String EMAIL = (String)attributes.get("EMAIL");

		if (EMAIL != null) {
			setEMAIL(EMAIL);
		}

		String EMP_GROUP = (String)attributes.get("EMP_GROUP");

		if (EMP_GROUP != null) {
			setEMP_GROUP(EMP_GROUP);
		}

		String EMPLOYEE_DOMAIN_ID = (String)attributes.get("EMPLOYEE_DOMAIN_ID");

		if (EMPLOYEE_DOMAIN_ID != null) {
			setEMPLOYEE_DOMAIN_ID(EMPLOYEE_DOMAIN_ID);
		}

		String EMPLOYMENT_STATUS = (String)attributes.get("EMPLOYMENT_STATUS");

		if (EMPLOYMENT_STATUS != null) {
			setEMPLOYMENT_STATUS(EMPLOYMENT_STATUS);
		}

		String EMPLOYMENT_STATUS_TEXT = (String)attributes.get(
				"EMPLOYMENT_STATUS_TEXT");

		if (EMPLOYMENT_STATUS_TEXT != null) {
			setEMPLOYMENT_STATUS_TEXT(EMPLOYMENT_STATUS_TEXT);
		}

		String FIRST_NAME = (String)attributes.get("FIRST_NAME");

		if (FIRST_NAME != null) {
			setFIRST_NAME(FIRST_NAME);
		}

		String FULL_NAME = (String)attributes.get("FULL_NAME");

		if (FULL_NAME != null) {
			setFULL_NAME(FULL_NAME);
		}

		String GENDER_TEXT = (String)attributes.get("GENDER_TEXT");

		if (GENDER_TEXT != null) {
			setGENDER_TEXT(GENDER_TEXT);
		}

		String HR_EMAIL = (String)attributes.get("HR_EMAIL");

		if (HR_EMAIL != null) {
			setHR_EMAIL(HR_EMAIL);
		}

		String HR_EMP_CD = (String)attributes.get("HR_EMP_CD");

		if (HR_EMP_CD != null) {
			setHR_EMP_CD(HR_EMP_CD);
		}

		String HR_HEAD_EMPCD = (String)attributes.get("HR_HEAD_EMPCD");

		if (HR_HEAD_EMPCD != null) {
			setHR_HEAD_EMPCD(HR_HEAD_EMPCD);
		}

		String HR_HEAD_NAME = (String)attributes.get("HR_HEAD_NAME");

		if (HR_HEAD_NAME != null) {
			setHR_HEAD_NAME(HR_HEAD_NAME);
		}

		String HR_NAME = (String)attributes.get("HR_NAME");

		if (HR_NAME != null) {
			setHR_NAME(HR_NAME);
		}

		String JIO_CENTER = (String)attributes.get("JIO_CENTER");

		if (JIO_CENTER != null) {
			setJIO_CENTER(JIO_CENTER);
		}

		String JIO_ID = (String)attributes.get("JIO_ID");

		if (JIO_ID != null) {
			setJIO_ID(JIO_ID);
		}

		String JO_REGION = (String)attributes.get("JO_REGION");

		if (JO_REGION != null) {
			setJO_REGION(JO_REGION);
		}

		String JO_TYPE = (String)attributes.get("JO_TYPE");

		if (JO_TYPE != null) {
			setJO_TYPE(JO_TYPE);
		}

		String JOB = (String)attributes.get("JOB");

		if (JOB != null) {
			setJOB(JOB);
		}

		String JOB_ROLE_CODE = (String)attributes.get("JOB_ROLE_CODE");

		if (JOB_ROLE_CODE != null) {
			setJOB_ROLE_CODE(JOB_ROLE_CODE);
		}

		String L1_EMAIL_ID = (String)attributes.get("L1_EMAIL_ID");

		if (L1_EMAIL_ID != null) {
			setL1_EMAIL_ID(L1_EMAIL_ID);
		}

		String L1_EMPLOYEE_CODE = (String)attributes.get("L1_EMPLOYEE_CODE");

		if (L1_EMPLOYEE_CODE != null) {
			setL1_EMPLOYEE_CODE(L1_EMPLOYEE_CODE);
		}

		String L1_NAME = (String)attributes.get("L1_NAME");

		if (L1_NAME != null) {
			setL1_NAME(L1_NAME);
		}

		String LAST_NAME = (String)attributes.get("LAST_NAME");

		if (LAST_NAME != null) {
			setLAST_NAME(LAST_NAME);
		}

		String LOCATION_CITY = (String)attributes.get("LOCATION_CITY");

		if (LOCATION_CITY != null) {
			setLOCATION_CITY(LOCATION_CITY);
		}

		String LOCATION_CODE = (String)attributes.get("LOCATION_CODE");

		if (LOCATION_CODE != null) {
			setLOCATION_CODE(LOCATION_CODE);
		}

		String LOCATION_COUNTRY = (String)attributes.get("LOCATION_COUNTRY");

		if (LOCATION_COUNTRY != null) {
			setLOCATION_COUNTRY(LOCATION_COUNTRY);
		}

		String LOCATION_STATE = (String)attributes.get("LOCATION_STATE");

		if (LOCATION_STATE != null) {
			setLOCATION_STATE(LOCATION_STATE);
		}

		String LOCATION_TEXT = (String)attributes.get("LOCATION_TEXT");

		if (LOCATION_TEXT != null) {
			setLOCATION_TEXT(LOCATION_TEXT);
		}

		String MOBILE_NO = (String)attributes.get("MOBILE_NO");

		if (MOBILE_NO != null) {
			setMOBILE_NO(MOBILE_NO);
		}

		String OFFICE_NO = (String)attributes.get("OFFICE_NO");

		if (OFFICE_NO != null) {
			setOFFICE_NO(OFFICE_NO);
		}

		String ORG_UNIT = (String)attributes.get("ORG_UNIT");

		if (ORG_UNIT != null) {
			setORG_UNIT(ORG_UNIT);
		}

		String ORG_UNIT_TEXT = (String)attributes.get("ORG_UNIT_TEXT");

		if (ORG_UNIT_TEXT != null) {
			setORG_UNIT_TEXT(ORG_UNIT_TEXT);
		}

		String PERSONNEL_AREA_CODE = (String)attributes.get(
				"PERSONNEL_AREA_CODE");

		if (PERSONNEL_AREA_CODE != null) {
			setPERSONNEL_AREA_CODE(PERSONNEL_AREA_CODE);
		}

		String R4G_STATE = (String)attributes.get("R4G_STATE");

		if (R4G_STATE != null) {
			setR4G_STATE(R4G_STATE);
		}

		String SAML_FEDERATION_ID = (String)attributes.get("SAML_FEDERATION_ID");

		if (SAML_FEDERATION_ID != null) {
			setSAML_FEDERATION_ID(SAML_FEDERATION_ID);
		}

		String STORE_CODE = (String)attributes.get("STORE_CODE");

		if (STORE_CODE != null) {
			setSTORE_CODE(STORE_CODE);
		}

		String SUB_FUNCTIONAL_AREA = (String)attributes.get(
				"SUB_FUNCTIONAL_AREA");

		if (SUB_FUNCTIONAL_AREA != null) {
			setSUB_FUNCTIONAL_AREA(SUB_FUNCTIONAL_AREA);
		}

		String TITLE = (String)attributes.get("TITLE");

		if (TITLE != null) {
			setTITLE(TITLE);
		}

		Integer IS_RESOLVER = (Integer)attributes.get("IS_RESOLVER");

		if (IS_RESOLVER != null) {
			setIS_RESOLVER(IS_RESOLVER);
		}

		Integer RESOLVER_LEVEL = (Integer)attributes.get("RESOLVER_LEVEL");

		if (RESOLVER_LEVEL != null) {
			setRESOLVER_LEVEL(RESOLVER_LEVEL);
		}

		String PERSONAL_AREA_TEXT = (String)attributes.get("PERSONAL_AREA_TEXT");

		if (PERSONAL_AREA_TEXT != null) {
			setPERSONAL_AREA_TEXT(PERSONAL_AREA_TEXT);
		}

		String FUNCTIONAL_AREA = (String)attributes.get("FUNCTIONAL_AREA");

		if (FUNCTIONAL_AREA != null) {
			setFUNCTIONAL_AREA(FUNCTIONAL_AREA);
		}

		Integer RESOLVER_STATUS = (Integer)attributes.get("RESOLVER_STATUS");

		if (RESOLVER_STATUS != null) {
			setRESOLVER_STATUS(RESOLVER_STATUS);
		}
	}

	/**
	* Returns the primary key of this e m p_ d e t a i l s.
	*
	* @return the primary key of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getPrimaryKey() {
		return _emp_details.getPrimaryKey();
	}

	/**
	* Sets the primary key of this e m p_ d e t a i l s.
	*
	* @param primaryKey the primary key of this e m p_ d e t a i l s
	*/
	@Override
	public void setPrimaryKey(java.lang.String primaryKey) {
		_emp_details.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the e m p_ i d of this e m p_ d e t a i l s.
	*
	* @return the e m p_ i d of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getEMP_ID() {
		return _emp_details.getEMP_ID();
	}

	/**
	* Sets the e m p_ i d of this e m p_ d e t a i l s.
	*
	* @param EMP_ID the e m p_ i d of this e m p_ d e t a i l s
	*/
	@Override
	public void setEMP_ID(java.lang.String EMP_ID) {
		_emp_details.setEMP_ID(EMP_ID);
	}

	/**
	* Returns the a r e a of this e m p_ d e t a i l s.
	*
	* @return the a r e a of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getAREA() {
		return _emp_details.getAREA();
	}

	/**
	* Sets the a r e a of this e m p_ d e t a i l s.
	*
	* @param AREA the a r e a of this e m p_ d e t a i l s
	*/
	@Override
	public void setAREA(java.lang.String AREA) {
		_emp_details.setAREA(AREA);
	}

	/**
	* Returns the c a d r e of this e m p_ d e t a i l s.
	*
	* @return the c a d r e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getCADRE() {
		return _emp_details.getCADRE();
	}

	/**
	* Sets the c a d r e of this e m p_ d e t a i l s.
	*
	* @param CADRE the c a d r e of this e m p_ d e t a i l s
	*/
	@Override
	public void setCADRE(java.lang.String CADRE) {
		_emp_details.setCADRE(CADRE);
	}

	/**
	* Returns the c l i e n t_ i d of this e m p_ d e t a i l s.
	*
	* @return the c l i e n t_ i d of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getCLIENT_ID() {
		return _emp_details.getCLIENT_ID();
	}

	/**
	* Sets the c l i e n t_ i d of this e m p_ d e t a i l s.
	*
	* @param CLIENT_ID the c l i e n t_ i d of this e m p_ d e t a i l s
	*/
	@Override
	public void setCLIENT_ID(java.lang.String CLIENT_ID) {
		_emp_details.setCLIENT_ID(CLIENT_ID);
	}

	/**
	* Returns the c o m p a n y_ c o d e of this e m p_ d e t a i l s.
	*
	* @return the c o m p a n y_ c o d e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getCOMPANY_CODE() {
		return _emp_details.getCOMPANY_CODE();
	}

	/**
	* Sets the c o m p a n y_ c o d e of this e m p_ d e t a i l s.
	*
	* @param COMPANY_CODE the c o m p a n y_ c o d e of this e m p_ d e t a i l s
	*/
	@Override
	public void setCOMPANY_CODE(java.lang.String COMPANY_CODE) {
		_emp_details.setCOMPANY_CODE(COMPANY_CODE);
	}

	/**
	* Returns the c o m p a n y_ t e x t of this e m p_ d e t a i l s.
	*
	* @return the c o m p a n y_ t e x t of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getCOMPANY_TEXT() {
		return _emp_details.getCOMPANY_TEXT();
	}

	/**
	* Sets the c o m p a n y_ t e x t of this e m p_ d e t a i l s.
	*
	* @param COMPANY_TEXT the c o m p a n y_ t e x t of this e m p_ d e t a i l s
	*/
	@Override
	public void setCOMPANY_TEXT(java.lang.String COMPANY_TEXT) {
		_emp_details.setCOMPANY_TEXT(COMPANY_TEXT);
	}

	/**
	* Returns the d a t e_ o f_ b i r t h of this e m p_ d e t a i l s.
	*
	* @return the d a t e_ o f_ b i r t h of this e m p_ d e t a i l s
	*/
	@Override
	public java.util.Date getDATE_OF_BIRTH() {
		return _emp_details.getDATE_OF_BIRTH();
	}

	/**
	* Sets the d a t e_ o f_ b i r t h of this e m p_ d e t a i l s.
	*
	* @param DATE_OF_BIRTH the d a t e_ o f_ b i r t h of this e m p_ d e t a i l s
	*/
	@Override
	public void setDATE_OF_BIRTH(java.util.Date DATE_OF_BIRTH) {
		_emp_details.setDATE_OF_BIRTH(DATE_OF_BIRTH);
	}

	/**
	* Returns the d a t e_ o f_ j o i n i n g of this e m p_ d e t a i l s.
	*
	* @return the d a t e_ o f_ j o i n i n g of this e m p_ d e t a i l s
	*/
	@Override
	public java.util.Date getDATE_OF_JOINING() {
		return _emp_details.getDATE_OF_JOINING();
	}

	/**
	* Sets the d a t e_ o f_ j o i n i n g of this e m p_ d e t a i l s.
	*
	* @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g of this e m p_ d e t a i l s
	*/
	@Override
	public void setDATE_OF_JOINING(java.util.Date DATE_OF_JOINING) {
		_emp_details.setDATE_OF_JOINING(DATE_OF_JOINING);
	}

	/**
	* Returns the d a t e_ o f_ l e a v e of this e m p_ d e t a i l s.
	*
	* @return the d a t e_ o f_ l e a v e of this e m p_ d e t a i l s
	*/
	@Override
	public java.util.Date getDATE_OF_LEAVE() {
		return _emp_details.getDATE_OF_LEAVE();
	}

	/**
	* Sets the d a t e_ o f_ l e a v e of this e m p_ d e t a i l s.
	*
	* @param DATE_OF_LEAVE the d a t e_ o f_ l e a v e of this e m p_ d e t a i l s
	*/
	@Override
	public void setDATE_OF_LEAVE(java.util.Date DATE_OF_LEAVE) {
		_emp_details.setDATE_OF_LEAVE(DATE_OF_LEAVE);
	}

	/**
	* Returns the d e p a r t m e n t of this e m p_ d e t a i l s.
	*
	* @return the d e p a r t m e n t of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getDEPARTMENT() {
		return _emp_details.getDEPARTMENT();
	}

	/**
	* Sets the d e p a r t m e n t of this e m p_ d e t a i l s.
	*
	* @param DEPARTMENT the d e p a r t m e n t of this e m p_ d e t a i l s
	*/
	@Override
	public void setDEPARTMENT(java.lang.String DEPARTMENT) {
		_emp_details.setDEPARTMENT(DEPARTMENT);
	}

	/**
	* Returns the d e s i g n a t i o n_ c o d e of this e m p_ d e t a i l s.
	*
	* @return the d e s i g n a t i o n_ c o d e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getDESIGNATION_CODE() {
		return _emp_details.getDESIGNATION_CODE();
	}

	/**
	* Sets the d e s i g n a t i o n_ c o d e of this e m p_ d e t a i l s.
	*
	* @param DESIGNATION_CODE the d e s i g n a t i o n_ c o d e of this e m p_ d e t a i l s
	*/
	@Override
	public void setDESIGNATION_CODE(java.lang.String DESIGNATION_CODE) {
		_emp_details.setDESIGNATION_CODE(DESIGNATION_CODE);
	}

	/**
	* Returns the d e s i g n a t i o n_ t e x t of this e m p_ d e t a i l s.
	*
	* @return the d e s i g n a t i o n_ t e x t of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getDESIGNATION_TEXT() {
		return _emp_details.getDESIGNATION_TEXT();
	}

	/**
	* Sets the d e s i g n a t i o n_ t e x t of this e m p_ d e t a i l s.
	*
	* @param DESIGNATION_TEXT the d e s i g n a t i o n_ t e x t of this e m p_ d e t a i l s
	*/
	@Override
	public void setDESIGNATION_TEXT(java.lang.String DESIGNATION_TEXT) {
		_emp_details.setDESIGNATION_TEXT(DESIGNATION_TEXT);
	}

	/**
	* Returns the e m a i l of this e m p_ d e t a i l s.
	*
	* @return the e m a i l of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getEMAIL() {
		return _emp_details.getEMAIL();
	}

	/**
	* Sets the e m a i l of this e m p_ d e t a i l s.
	*
	* @param EMAIL the e m a i l of this e m p_ d e t a i l s
	*/
	@Override
	public void setEMAIL(java.lang.String EMAIL) {
		_emp_details.setEMAIL(EMAIL);
	}

	/**
	* Returns the e m p_ g r o u p of this e m p_ d e t a i l s.
	*
	* @return the e m p_ g r o u p of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getEMP_GROUP() {
		return _emp_details.getEMP_GROUP();
	}

	/**
	* Sets the e m p_ g r o u p of this e m p_ d e t a i l s.
	*
	* @param EMP_GROUP the e m p_ g r o u p of this e m p_ d e t a i l s
	*/
	@Override
	public void setEMP_GROUP(java.lang.String EMP_GROUP) {
		_emp_details.setEMP_GROUP(EMP_GROUP);
	}

	/**
	* Returns the e m p l o y e e_ d o m a i n_ i d of this e m p_ d e t a i l s.
	*
	* @return the e m p l o y e e_ d o m a i n_ i d of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getEMPLOYEE_DOMAIN_ID() {
		return _emp_details.getEMPLOYEE_DOMAIN_ID();
	}

	/**
	* Sets the e m p l o y e e_ d o m a i n_ i d of this e m p_ d e t a i l s.
	*
	* @param EMPLOYEE_DOMAIN_ID the e m p l o y e e_ d o m a i n_ i d of this e m p_ d e t a i l s
	*/
	@Override
	public void setEMPLOYEE_DOMAIN_ID(java.lang.String EMPLOYEE_DOMAIN_ID) {
		_emp_details.setEMPLOYEE_DOMAIN_ID(EMPLOYEE_DOMAIN_ID);
	}

	/**
	* Returns the e m p l o y m e n t_ s t a t u s of this e m p_ d e t a i l s.
	*
	* @return the e m p l o y m e n t_ s t a t u s of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getEMPLOYMENT_STATUS() {
		return _emp_details.getEMPLOYMENT_STATUS();
	}

	/**
	* Sets the e m p l o y m e n t_ s t a t u s of this e m p_ d e t a i l s.
	*
	* @param EMPLOYMENT_STATUS the e m p l o y m e n t_ s t a t u s of this e m p_ d e t a i l s
	*/
	@Override
	public void setEMPLOYMENT_STATUS(java.lang.String EMPLOYMENT_STATUS) {
		_emp_details.setEMPLOYMENT_STATUS(EMPLOYMENT_STATUS);
	}

	/**
	* Returns the e m p l o y m e n t_ s t a t u s_ t e x t of this e m p_ d e t a i l s.
	*
	* @return the e m p l o y m e n t_ s t a t u s_ t e x t of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getEMPLOYMENT_STATUS_TEXT() {
		return _emp_details.getEMPLOYMENT_STATUS_TEXT();
	}

	/**
	* Sets the e m p l o y m e n t_ s t a t u s_ t e x t of this e m p_ d e t a i l s.
	*
	* @param EMPLOYMENT_STATUS_TEXT the e m p l o y m e n t_ s t a t u s_ t e x t of this e m p_ d e t a i l s
	*/
	@Override
	public void setEMPLOYMENT_STATUS_TEXT(
		java.lang.String EMPLOYMENT_STATUS_TEXT) {
		_emp_details.setEMPLOYMENT_STATUS_TEXT(EMPLOYMENT_STATUS_TEXT);
	}

	/**
	* Returns the f i r s t_ n a m e of this e m p_ d e t a i l s.
	*
	* @return the f i r s t_ n a m e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getFIRST_NAME() {
		return _emp_details.getFIRST_NAME();
	}

	/**
	* Sets the f i r s t_ n a m e of this e m p_ d e t a i l s.
	*
	* @param FIRST_NAME the f i r s t_ n a m e of this e m p_ d e t a i l s
	*/
	@Override
	public void setFIRST_NAME(java.lang.String FIRST_NAME) {
		_emp_details.setFIRST_NAME(FIRST_NAME);
	}

	/**
	* Returns the f u l l_ n a m e of this e m p_ d e t a i l s.
	*
	* @return the f u l l_ n a m e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getFULL_NAME() {
		return _emp_details.getFULL_NAME();
	}

	/**
	* Sets the f u l l_ n a m e of this e m p_ d e t a i l s.
	*
	* @param FULL_NAME the f u l l_ n a m e of this e m p_ d e t a i l s
	*/
	@Override
	public void setFULL_NAME(java.lang.String FULL_NAME) {
		_emp_details.setFULL_NAME(FULL_NAME);
	}

	/**
	* Returns the g e n d e r_ t e x t of this e m p_ d e t a i l s.
	*
	* @return the g e n d e r_ t e x t of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getGENDER_TEXT() {
		return _emp_details.getGENDER_TEXT();
	}

	/**
	* Sets the g e n d e r_ t e x t of this e m p_ d e t a i l s.
	*
	* @param GENDER_TEXT the g e n d e r_ t e x t of this e m p_ d e t a i l s
	*/
	@Override
	public void setGENDER_TEXT(java.lang.String GENDER_TEXT) {
		_emp_details.setGENDER_TEXT(GENDER_TEXT);
	}

	/**
	* Returns the h r_ e m a i l of this e m p_ d e t a i l s.
	*
	* @return the h r_ e m a i l of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getHR_EMAIL() {
		return _emp_details.getHR_EMAIL();
	}

	/**
	* Sets the h r_ e m a i l of this e m p_ d e t a i l s.
	*
	* @param HR_EMAIL the h r_ e m a i l of this e m p_ d e t a i l s
	*/
	@Override
	public void setHR_EMAIL(java.lang.String HR_EMAIL) {
		_emp_details.setHR_EMAIL(HR_EMAIL);
	}

	/**
	* Returns the h r_ e m p_ c d of this e m p_ d e t a i l s.
	*
	* @return the h r_ e m p_ c d of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getHR_EMP_CD() {
		return _emp_details.getHR_EMP_CD();
	}

	/**
	* Sets the h r_ e m p_ c d of this e m p_ d e t a i l s.
	*
	* @param HR_EMP_CD the h r_ e m p_ c d of this e m p_ d e t a i l s
	*/
	@Override
	public void setHR_EMP_CD(java.lang.String HR_EMP_CD) {
		_emp_details.setHR_EMP_CD(HR_EMP_CD);
	}

	/**
	* Returns the h r_ h e a d_ e m p c d of this e m p_ d e t a i l s.
	*
	* @return the h r_ h e a d_ e m p c d of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getHR_HEAD_EMPCD() {
		return _emp_details.getHR_HEAD_EMPCD();
	}

	/**
	* Sets the h r_ h e a d_ e m p c d of this e m p_ d e t a i l s.
	*
	* @param HR_HEAD_EMPCD the h r_ h e a d_ e m p c d of this e m p_ d e t a i l s
	*/
	@Override
	public void setHR_HEAD_EMPCD(java.lang.String HR_HEAD_EMPCD) {
		_emp_details.setHR_HEAD_EMPCD(HR_HEAD_EMPCD);
	}

	/**
	* Returns the h r_ h e a d_ n a m e of this e m p_ d e t a i l s.
	*
	* @return the h r_ h e a d_ n a m e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getHR_HEAD_NAME() {
		return _emp_details.getHR_HEAD_NAME();
	}

	/**
	* Sets the h r_ h e a d_ n a m e of this e m p_ d e t a i l s.
	*
	* @param HR_HEAD_NAME the h r_ h e a d_ n a m e of this e m p_ d e t a i l s
	*/
	@Override
	public void setHR_HEAD_NAME(java.lang.String HR_HEAD_NAME) {
		_emp_details.setHR_HEAD_NAME(HR_HEAD_NAME);
	}

	/**
	* Returns the h r_ n a m e of this e m p_ d e t a i l s.
	*
	* @return the h r_ n a m e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getHR_NAME() {
		return _emp_details.getHR_NAME();
	}

	/**
	* Sets the h r_ n a m e of this e m p_ d e t a i l s.
	*
	* @param HR_NAME the h r_ n a m e of this e m p_ d e t a i l s
	*/
	@Override
	public void setHR_NAME(java.lang.String HR_NAME) {
		_emp_details.setHR_NAME(HR_NAME);
	}

	/**
	* Returns the j i o_ c e n t e r of this e m p_ d e t a i l s.
	*
	* @return the j i o_ c e n t e r of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getJIO_CENTER() {
		return _emp_details.getJIO_CENTER();
	}

	/**
	* Sets the j i o_ c e n t e r of this e m p_ d e t a i l s.
	*
	* @param JIO_CENTER the j i o_ c e n t e r of this e m p_ d e t a i l s
	*/
	@Override
	public void setJIO_CENTER(java.lang.String JIO_CENTER) {
		_emp_details.setJIO_CENTER(JIO_CENTER);
	}

	/**
	* Returns the j i o_ i d of this e m p_ d e t a i l s.
	*
	* @return the j i o_ i d of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getJIO_ID() {
		return _emp_details.getJIO_ID();
	}

	/**
	* Sets the j i o_ i d of this e m p_ d e t a i l s.
	*
	* @param JIO_ID the j i o_ i d of this e m p_ d e t a i l s
	*/
	@Override
	public void setJIO_ID(java.lang.String JIO_ID) {
		_emp_details.setJIO_ID(JIO_ID);
	}

	/**
	* Returns the j o_ r e g i o n of this e m p_ d e t a i l s.
	*
	* @return the j o_ r e g i o n of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getJO_REGION() {
		return _emp_details.getJO_REGION();
	}

	/**
	* Sets the j o_ r e g i o n of this e m p_ d e t a i l s.
	*
	* @param JO_REGION the j o_ r e g i o n of this e m p_ d e t a i l s
	*/
	@Override
	public void setJO_REGION(java.lang.String JO_REGION) {
		_emp_details.setJO_REGION(JO_REGION);
	}

	/**
	* Returns the j o_ t y p e of this e m p_ d e t a i l s.
	*
	* @return the j o_ t y p e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getJO_TYPE() {
		return _emp_details.getJO_TYPE();
	}

	/**
	* Sets the j o_ t y p e of this e m p_ d e t a i l s.
	*
	* @param JO_TYPE the j o_ t y p e of this e m p_ d e t a i l s
	*/
	@Override
	public void setJO_TYPE(java.lang.String JO_TYPE) {
		_emp_details.setJO_TYPE(JO_TYPE);
	}

	/**
	* Returns the j o b of this e m p_ d e t a i l s.
	*
	* @return the j o b of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getJOB() {
		return _emp_details.getJOB();
	}

	/**
	* Sets the j o b of this e m p_ d e t a i l s.
	*
	* @param JOB the j o b of this e m p_ d e t a i l s
	*/
	@Override
	public void setJOB(java.lang.String JOB) {
		_emp_details.setJOB(JOB);
	}

	/**
	* Returns the j o b_ r o l e_ c o d e of this e m p_ d e t a i l s.
	*
	* @return the j o b_ r o l e_ c o d e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getJOB_ROLE_CODE() {
		return _emp_details.getJOB_ROLE_CODE();
	}

	/**
	* Sets the j o b_ r o l e_ c o d e of this e m p_ d e t a i l s.
	*
	* @param JOB_ROLE_CODE the j o b_ r o l e_ c o d e of this e m p_ d e t a i l s
	*/
	@Override
	public void setJOB_ROLE_CODE(java.lang.String JOB_ROLE_CODE) {
		_emp_details.setJOB_ROLE_CODE(JOB_ROLE_CODE);
	}

	/**
	* Returns the l1_ e m a i l_ i d of this e m p_ d e t a i l s.
	*
	* @return the l1_ e m a i l_ i d of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getL1_EMAIL_ID() {
		return _emp_details.getL1_EMAIL_ID();
	}

	/**
	* Sets the l1_ e m a i l_ i d of this e m p_ d e t a i l s.
	*
	* @param L1_EMAIL_ID the l1_ e m a i l_ i d of this e m p_ d e t a i l s
	*/
	@Override
	public void setL1_EMAIL_ID(java.lang.String L1_EMAIL_ID) {
		_emp_details.setL1_EMAIL_ID(L1_EMAIL_ID);
	}

	/**
	* Returns the l1_ e m p l o y e e_ c o d e of this e m p_ d e t a i l s.
	*
	* @return the l1_ e m p l o y e e_ c o d e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getL1_EMPLOYEE_CODE() {
		return _emp_details.getL1_EMPLOYEE_CODE();
	}

	/**
	* Sets the l1_ e m p l o y e e_ c o d e of this e m p_ d e t a i l s.
	*
	* @param L1_EMPLOYEE_CODE the l1_ e m p l o y e e_ c o d e of this e m p_ d e t a i l s
	*/
	@Override
	public void setL1_EMPLOYEE_CODE(java.lang.String L1_EMPLOYEE_CODE) {
		_emp_details.setL1_EMPLOYEE_CODE(L1_EMPLOYEE_CODE);
	}

	/**
	* Returns the l1_ n a m e of this e m p_ d e t a i l s.
	*
	* @return the l1_ n a m e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getL1_NAME() {
		return _emp_details.getL1_NAME();
	}

	/**
	* Sets the l1_ n a m e of this e m p_ d e t a i l s.
	*
	* @param L1_NAME the l1_ n a m e of this e m p_ d e t a i l s
	*/
	@Override
	public void setL1_NAME(java.lang.String L1_NAME) {
		_emp_details.setL1_NAME(L1_NAME);
	}

	/**
	* Returns the l a s t_ n a m e of this e m p_ d e t a i l s.
	*
	* @return the l a s t_ n a m e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getLAST_NAME() {
		return _emp_details.getLAST_NAME();
	}

	/**
	* Sets the l a s t_ n a m e of this e m p_ d e t a i l s.
	*
	* @param LAST_NAME the l a s t_ n a m e of this e m p_ d e t a i l s
	*/
	@Override
	public void setLAST_NAME(java.lang.String LAST_NAME) {
		_emp_details.setLAST_NAME(LAST_NAME);
	}

	/**
	* Returns the l o c a t i o n_ c i t y of this e m p_ d e t a i l s.
	*
	* @return the l o c a t i o n_ c i t y of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getLOCATION_CITY() {
		return _emp_details.getLOCATION_CITY();
	}

	/**
	* Sets the l o c a t i o n_ c i t y of this e m p_ d e t a i l s.
	*
	* @param LOCATION_CITY the l o c a t i o n_ c i t y of this e m p_ d e t a i l s
	*/
	@Override
	public void setLOCATION_CITY(java.lang.String LOCATION_CITY) {
		_emp_details.setLOCATION_CITY(LOCATION_CITY);
	}

	/**
	* Returns the l o c a t i o n_ c o d e of this e m p_ d e t a i l s.
	*
	* @return the l o c a t i o n_ c o d e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getLOCATION_CODE() {
		return _emp_details.getLOCATION_CODE();
	}

	/**
	* Sets the l o c a t i o n_ c o d e of this e m p_ d e t a i l s.
	*
	* @param LOCATION_CODE the l o c a t i o n_ c o d e of this e m p_ d e t a i l s
	*/
	@Override
	public void setLOCATION_CODE(java.lang.String LOCATION_CODE) {
		_emp_details.setLOCATION_CODE(LOCATION_CODE);
	}

	/**
	* Returns the l o c a t i o n_ c o u n t r y of this e m p_ d e t a i l s.
	*
	* @return the l o c a t i o n_ c o u n t r y of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getLOCATION_COUNTRY() {
		return _emp_details.getLOCATION_COUNTRY();
	}

	/**
	* Sets the l o c a t i o n_ c o u n t r y of this e m p_ d e t a i l s.
	*
	* @param LOCATION_COUNTRY the l o c a t i o n_ c o u n t r y of this e m p_ d e t a i l s
	*/
	@Override
	public void setLOCATION_COUNTRY(java.lang.String LOCATION_COUNTRY) {
		_emp_details.setLOCATION_COUNTRY(LOCATION_COUNTRY);
	}

	/**
	* Returns the l o c a t i o n_ s t a t e of this e m p_ d e t a i l s.
	*
	* @return the l o c a t i o n_ s t a t e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getLOCATION_STATE() {
		return _emp_details.getLOCATION_STATE();
	}

	/**
	* Sets the l o c a t i o n_ s t a t e of this e m p_ d e t a i l s.
	*
	* @param LOCATION_STATE the l o c a t i o n_ s t a t e of this e m p_ d e t a i l s
	*/
	@Override
	public void setLOCATION_STATE(java.lang.String LOCATION_STATE) {
		_emp_details.setLOCATION_STATE(LOCATION_STATE);
	}

	/**
	* Returns the l o c a t i o n_ t e x t of this e m p_ d e t a i l s.
	*
	* @return the l o c a t i o n_ t e x t of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getLOCATION_TEXT() {
		return _emp_details.getLOCATION_TEXT();
	}

	/**
	* Sets the l o c a t i o n_ t e x t of this e m p_ d e t a i l s.
	*
	* @param LOCATION_TEXT the l o c a t i o n_ t e x t of this e m p_ d e t a i l s
	*/
	@Override
	public void setLOCATION_TEXT(java.lang.String LOCATION_TEXT) {
		_emp_details.setLOCATION_TEXT(LOCATION_TEXT);
	}

	/**
	* Returns the m o b i l e_ n o of this e m p_ d e t a i l s.
	*
	* @return the m o b i l e_ n o of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getMOBILE_NO() {
		return _emp_details.getMOBILE_NO();
	}

	/**
	* Sets the m o b i l e_ n o of this e m p_ d e t a i l s.
	*
	* @param MOBILE_NO the m o b i l e_ n o of this e m p_ d e t a i l s
	*/
	@Override
	public void setMOBILE_NO(java.lang.String MOBILE_NO) {
		_emp_details.setMOBILE_NO(MOBILE_NO);
	}

	/**
	* Returns the o f f i c e_ n o of this e m p_ d e t a i l s.
	*
	* @return the o f f i c e_ n o of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getOFFICE_NO() {
		return _emp_details.getOFFICE_NO();
	}

	/**
	* Sets the o f f i c e_ n o of this e m p_ d e t a i l s.
	*
	* @param OFFICE_NO the o f f i c e_ n o of this e m p_ d e t a i l s
	*/
	@Override
	public void setOFFICE_NO(java.lang.String OFFICE_NO) {
		_emp_details.setOFFICE_NO(OFFICE_NO);
	}

	/**
	* Returns the o r g_ u n i t of this e m p_ d e t a i l s.
	*
	* @return the o r g_ u n i t of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getORG_UNIT() {
		return _emp_details.getORG_UNIT();
	}

	/**
	* Sets the o r g_ u n i t of this e m p_ d e t a i l s.
	*
	* @param ORG_UNIT the o r g_ u n i t of this e m p_ d e t a i l s
	*/
	@Override
	public void setORG_UNIT(java.lang.String ORG_UNIT) {
		_emp_details.setORG_UNIT(ORG_UNIT);
	}

	/**
	* Returns the o r g_ u n i t_ t e x t of this e m p_ d e t a i l s.
	*
	* @return the o r g_ u n i t_ t e x t of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getORG_UNIT_TEXT() {
		return _emp_details.getORG_UNIT_TEXT();
	}

	/**
	* Sets the o r g_ u n i t_ t e x t of this e m p_ d e t a i l s.
	*
	* @param ORG_UNIT_TEXT the o r g_ u n i t_ t e x t of this e m p_ d e t a i l s
	*/
	@Override
	public void setORG_UNIT_TEXT(java.lang.String ORG_UNIT_TEXT) {
		_emp_details.setORG_UNIT_TEXT(ORG_UNIT_TEXT);
	}

	/**
	* Returns the p e r s o n n e l_ a r e a_ c o d e of this e m p_ d e t a i l s.
	*
	* @return the p e r s o n n e l_ a r e a_ c o d e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getPERSONNEL_AREA_CODE() {
		return _emp_details.getPERSONNEL_AREA_CODE();
	}

	/**
	* Sets the p e r s o n n e l_ a r e a_ c o d e of this e m p_ d e t a i l s.
	*
	* @param PERSONNEL_AREA_CODE the p e r s o n n e l_ a r e a_ c o d e of this e m p_ d e t a i l s
	*/
	@Override
	public void setPERSONNEL_AREA_CODE(java.lang.String PERSONNEL_AREA_CODE) {
		_emp_details.setPERSONNEL_AREA_CODE(PERSONNEL_AREA_CODE);
	}

	/**
	* Returns the r4 g_ s t a t e of this e m p_ d e t a i l s.
	*
	* @return the r4 g_ s t a t e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getR4G_STATE() {
		return _emp_details.getR4G_STATE();
	}

	/**
	* Sets the r4 g_ s t a t e of this e m p_ d e t a i l s.
	*
	* @param R4G_STATE the r4 g_ s t a t e of this e m p_ d e t a i l s
	*/
	@Override
	public void setR4G_STATE(java.lang.String R4G_STATE) {
		_emp_details.setR4G_STATE(R4G_STATE);
	}

	/**
	* Returns the s a m l_ f e d e r a t i o n_ i d of this e m p_ d e t a i l s.
	*
	* @return the s a m l_ f e d e r a t i o n_ i d of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getSAML_FEDERATION_ID() {
		return _emp_details.getSAML_FEDERATION_ID();
	}

	/**
	* Sets the s a m l_ f e d e r a t i o n_ i d of this e m p_ d e t a i l s.
	*
	* @param SAML_FEDERATION_ID the s a m l_ f e d e r a t i o n_ i d of this e m p_ d e t a i l s
	*/
	@Override
	public void setSAML_FEDERATION_ID(java.lang.String SAML_FEDERATION_ID) {
		_emp_details.setSAML_FEDERATION_ID(SAML_FEDERATION_ID);
	}

	/**
	* Returns the s t o r e_ c o d e of this e m p_ d e t a i l s.
	*
	* @return the s t o r e_ c o d e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getSTORE_CODE() {
		return _emp_details.getSTORE_CODE();
	}

	/**
	* Sets the s t o r e_ c o d e of this e m p_ d e t a i l s.
	*
	* @param STORE_CODE the s t o r e_ c o d e of this e m p_ d e t a i l s
	*/
	@Override
	public void setSTORE_CODE(java.lang.String STORE_CODE) {
		_emp_details.setSTORE_CODE(STORE_CODE);
	}

	/**
	* Returns the s u b_ f u n c t i o n a l_ a r e a of this e m p_ d e t a i l s.
	*
	* @return the s u b_ f u n c t i o n a l_ a r e a of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getSUB_FUNCTIONAL_AREA() {
		return _emp_details.getSUB_FUNCTIONAL_AREA();
	}

	/**
	* Sets the s u b_ f u n c t i o n a l_ a r e a of this e m p_ d e t a i l s.
	*
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a of this e m p_ d e t a i l s
	*/
	@Override
	public void setSUB_FUNCTIONAL_AREA(java.lang.String SUB_FUNCTIONAL_AREA) {
		_emp_details.setSUB_FUNCTIONAL_AREA(SUB_FUNCTIONAL_AREA);
	}

	/**
	* Returns the t i t l e of this e m p_ d e t a i l s.
	*
	* @return the t i t l e of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getTITLE() {
		return _emp_details.getTITLE();
	}

	/**
	* Sets the t i t l e of this e m p_ d e t a i l s.
	*
	* @param TITLE the t i t l e of this e m p_ d e t a i l s
	*/
	@Override
	public void setTITLE(java.lang.String TITLE) {
		_emp_details.setTITLE(TITLE);
	}

	/**
	* Returns the i s_ r e s o l v e r of this e m p_ d e t a i l s.
	*
	* @return the i s_ r e s o l v e r of this e m p_ d e t a i l s
	*/
	@Override
	public int getIS_RESOLVER() {
		return _emp_details.getIS_RESOLVER();
	}

	/**
	* Sets the i s_ r e s o l v e r of this e m p_ d e t a i l s.
	*
	* @param IS_RESOLVER the i s_ r e s o l v e r of this e m p_ d e t a i l s
	*/
	@Override
	public void setIS_RESOLVER(int IS_RESOLVER) {
		_emp_details.setIS_RESOLVER(IS_RESOLVER);
	}

	/**
	* Returns the r e s o l v e r_ l e v e l of this e m p_ d e t a i l s.
	*
	* @return the r e s o l v e r_ l e v e l of this e m p_ d e t a i l s
	*/
	@Override
	public int getRESOLVER_LEVEL() {
		return _emp_details.getRESOLVER_LEVEL();
	}

	/**
	* Sets the r e s o l v e r_ l e v e l of this e m p_ d e t a i l s.
	*
	* @param RESOLVER_LEVEL the r e s o l v e r_ l e v e l of this e m p_ d e t a i l s
	*/
	@Override
	public void setRESOLVER_LEVEL(int RESOLVER_LEVEL) {
		_emp_details.setRESOLVER_LEVEL(RESOLVER_LEVEL);
	}

	/**
	* Returns the p e r s o n a l_ a r e a_ t e x t of this e m p_ d e t a i l s.
	*
	* @return the p e r s o n a l_ a r e a_ t e x t of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getPERSONAL_AREA_TEXT() {
		return _emp_details.getPERSONAL_AREA_TEXT();
	}

	/**
	* Sets the p e r s o n a l_ a r e a_ t e x t of this e m p_ d e t a i l s.
	*
	* @param PERSONAL_AREA_TEXT the p e r s o n a l_ a r e a_ t e x t of this e m p_ d e t a i l s
	*/
	@Override
	public void setPERSONAL_AREA_TEXT(java.lang.String PERSONAL_AREA_TEXT) {
		_emp_details.setPERSONAL_AREA_TEXT(PERSONAL_AREA_TEXT);
	}

	/**
	* Returns the f u n c t i o n a l_ a r e a of this e m p_ d e t a i l s.
	*
	* @return the f u n c t i o n a l_ a r e a of this e m p_ d e t a i l s
	*/
	@Override
	public java.lang.String getFUNCTIONAL_AREA() {
		return _emp_details.getFUNCTIONAL_AREA();
	}

	/**
	* Sets the f u n c t i o n a l_ a r e a of this e m p_ d e t a i l s.
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a of this e m p_ d e t a i l s
	*/
	@Override
	public void setFUNCTIONAL_AREA(java.lang.String FUNCTIONAL_AREA) {
		_emp_details.setFUNCTIONAL_AREA(FUNCTIONAL_AREA);
	}

	/**
	* Returns the r e s o l v e r_ s t a t u s of this e m p_ d e t a i l s.
	*
	* @return the r e s o l v e r_ s t a t u s of this e m p_ d e t a i l s
	*/
	@Override
	public int getRESOLVER_STATUS() {
		return _emp_details.getRESOLVER_STATUS();
	}

	/**
	* Sets the r e s o l v e r_ s t a t u s of this e m p_ d e t a i l s.
	*
	* @param RESOLVER_STATUS the r e s o l v e r_ s t a t u s of this e m p_ d e t a i l s
	*/
	@Override
	public void setRESOLVER_STATUS(int RESOLVER_STATUS) {
		_emp_details.setRESOLVER_STATUS(RESOLVER_STATUS);
	}

	@Override
	public boolean isNew() {
		return _emp_details.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_emp_details.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _emp_details.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_emp_details.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _emp_details.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _emp_details.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_emp_details.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _emp_details.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_emp_details.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_emp_details.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_emp_details.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new EMP_DETAILSWrapper((EMP_DETAILS)_emp_details.clone());
	}

	@Override
	public int compareTo(com.jioc.query.model.EMP_DETAILS emp_details) {
		return _emp_details.compareTo(emp_details);
	}

	@Override
	public int hashCode() {
		return _emp_details.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jioc.query.model.EMP_DETAILS> toCacheModel() {
		return _emp_details.toCacheModel();
	}

	@Override
	public com.jioc.query.model.EMP_DETAILS toEscapedModel() {
		return new EMP_DETAILSWrapper(_emp_details.toEscapedModel());
	}

	@Override
	public com.jioc.query.model.EMP_DETAILS toUnescapedModel() {
		return new EMP_DETAILSWrapper(_emp_details.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _emp_details.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _emp_details.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_emp_details.persist();
	}

	@Override
	public java.lang.String getUserName() {
		return _emp_details.getUserName();
	}

	@Override
	public void setUserName(java.lang.String userName) {
		_emp_details.setUserName(userName);
	}

	@Override
	public long getUserId() {
		return _emp_details.getUserId();
	}

	@Override
	public void setUserId(long userId) {
		_emp_details.setUserId(userId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof EMP_DETAILSWrapper)) {
			return false;
		}

		EMP_DETAILSWrapper emp_detailsWrapper = (EMP_DETAILSWrapper)obj;

		if (Validator.equals(_emp_details, emp_detailsWrapper._emp_details)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public EMP_DETAILS getWrappedEMP_DETAILS() {
		return _emp_details;
	}

	@Override
	public EMP_DETAILS getWrappedModel() {
		return _emp_details;
	}

	@Override
	public void resetOriginalValues() {
		_emp_details.resetOriginalValues();
	}

	private EMP_DETAILS _emp_details;
}