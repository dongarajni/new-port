/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.model.RESOLVER_DEFAULTS;

import com.liferay.portal.service.persistence.BasePersistence;

/**
 * The persistence interface for the r e s o l v e r_ d e f a u l t s service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see RESOLVER_DEFAULTSPersistenceImpl
 * @see RESOLVER_DEFAULTSUtil
 * @generated
 */
public interface RESOLVER_DEFAULTSPersistence extends BasePersistence<RESOLVER_DEFAULTS> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link RESOLVER_DEFAULTSUtil} to access the r e s o l v e r_ d e f a u l t s persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the r e s o l v e r_ d e f a u l t ses where TYPE = &#63; and VALUE = &#63;.
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @return the matching r e s o l v e r_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.RESOLVER_DEFAULTS> findByTypeValue(
		java.lang.String TYPE, java.lang.String VALUE)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the r e s o l v e r_ d e f a u l t ses where TYPE = &#63; and VALUE = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.RESOLVER_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @param start the lower bound of the range of r e s o l v e r_ d e f a u l t ses
	* @param end the upper bound of the range of r e s o l v e r_ d e f a u l t ses (not inclusive)
	* @return the range of matching r e s o l v e r_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.RESOLVER_DEFAULTS> findByTypeValue(
		java.lang.String TYPE, java.lang.String VALUE, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the r e s o l v e r_ d e f a u l t ses where TYPE = &#63; and VALUE = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.RESOLVER_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @param start the lower bound of the range of r e s o l v e r_ d e f a u l t ses
	* @param end the upper bound of the range of r e s o l v e r_ d e f a u l t ses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching r e s o l v e r_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.RESOLVER_DEFAULTS> findByTypeValue(
		java.lang.String TYPE, java.lang.String VALUE, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first r e s o l v e r_ d e f a u l t s in the ordered set where TYPE = &#63; and VALUE = &#63;.
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching r e s o l v e r_ d e f a u l t s
	* @throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException if a matching r e s o l v e r_ d e f a u l t s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.RESOLVER_DEFAULTS findByTypeValue_First(
		java.lang.String TYPE, java.lang.String VALUE,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first r e s o l v e r_ d e f a u l t s in the ordered set where TYPE = &#63; and VALUE = &#63;.
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching r e s o l v e r_ d e f a u l t s, or <code>null</code> if a matching r e s o l v e r_ d e f a u l t s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.RESOLVER_DEFAULTS fetchByTypeValue_First(
		java.lang.String TYPE, java.lang.String VALUE,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last r e s o l v e r_ d e f a u l t s in the ordered set where TYPE = &#63; and VALUE = &#63;.
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching r e s o l v e r_ d e f a u l t s
	* @throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException if a matching r e s o l v e r_ d e f a u l t s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.RESOLVER_DEFAULTS findByTypeValue_Last(
		java.lang.String TYPE, java.lang.String VALUE,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last r e s o l v e r_ d e f a u l t s in the ordered set where TYPE = &#63; and VALUE = &#63;.
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching r e s o l v e r_ d e f a u l t s, or <code>null</code> if a matching r e s o l v e r_ d e f a u l t s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.RESOLVER_DEFAULTS fetchByTypeValue_Last(
		java.lang.String TYPE, java.lang.String VALUE,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the r e s o l v e r_ d e f a u l t ses before and after the current r e s o l v e r_ d e f a u l t s in the ordered set where TYPE = &#63; and VALUE = &#63;.
	*
	* @param DEFAULT_ID the primary key of the current r e s o l v e r_ d e f a u l t s
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next r e s o l v e r_ d e f a u l t s
	* @throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException if a r e s o l v e r_ d e f a u l t s with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.RESOLVER_DEFAULTS[] findByTypeValue_PrevAndNext(
		long DEFAULT_ID, java.lang.String TYPE, java.lang.String VALUE,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the r e s o l v e r_ d e f a u l t ses where TYPE = &#63; and VALUE = &#63; from the database.
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @throws SystemException if a system exception occurred
	*/
	public void removeByTypeValue(java.lang.String TYPE, java.lang.String VALUE)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of r e s o l v e r_ d e f a u l t ses where TYPE = &#63; and VALUE = &#63;.
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @return the number of matching r e s o l v e r_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public int countByTypeValue(java.lang.String TYPE, java.lang.String VALUE)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the r e s o l v e r_ d e f a u l t s in the entity cache if it is enabled.
	*
	* @param resolver_defaults the r e s o l v e r_ d e f a u l t s
	*/
	public void cacheResult(
		com.jioc.query.model.RESOLVER_DEFAULTS resolver_defaults);

	/**
	* Caches the r e s o l v e r_ d e f a u l t ses in the entity cache if it is enabled.
	*
	* @param resolver_defaultses the r e s o l v e r_ d e f a u l t ses
	*/
	public void cacheResult(
		java.util.List<com.jioc.query.model.RESOLVER_DEFAULTS> resolver_defaultses);

	/**
	* Creates a new r e s o l v e r_ d e f a u l t s with the primary key. Does not add the r e s o l v e r_ d e f a u l t s to the database.
	*
	* @param DEFAULT_ID the primary key for the new r e s o l v e r_ d e f a u l t s
	* @return the new r e s o l v e r_ d e f a u l t s
	*/
	public com.jioc.query.model.RESOLVER_DEFAULTS create(long DEFAULT_ID);

	/**
	* Removes the r e s o l v e r_ d e f a u l t s with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param DEFAULT_ID the primary key of the r e s o l v e r_ d e f a u l t s
	* @return the r e s o l v e r_ d e f a u l t s that was removed
	* @throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException if a r e s o l v e r_ d e f a u l t s with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.RESOLVER_DEFAULTS remove(long DEFAULT_ID)
		throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException,
			com.liferay.portal.kernel.exception.SystemException;

	public com.jioc.query.model.RESOLVER_DEFAULTS updateImpl(
		com.jioc.query.model.RESOLVER_DEFAULTS resolver_defaults)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the r e s o l v e r_ d e f a u l t s with the primary key or throws a {@link com.jioc.query.NoSuchRESOLVER_DEFAULTSException} if it could not be found.
	*
	* @param DEFAULT_ID the primary key of the r e s o l v e r_ d e f a u l t s
	* @return the r e s o l v e r_ d e f a u l t s
	* @throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException if a r e s o l v e r_ d e f a u l t s with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.RESOLVER_DEFAULTS findByPrimaryKey(
		long DEFAULT_ID)
		throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the r e s o l v e r_ d e f a u l t s with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param DEFAULT_ID the primary key of the r e s o l v e r_ d e f a u l t s
	* @return the r e s o l v e r_ d e f a u l t s, or <code>null</code> if a r e s o l v e r_ d e f a u l t s with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.RESOLVER_DEFAULTS fetchByPrimaryKey(
		long DEFAULT_ID)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the r e s o l v e r_ d e f a u l t ses.
	*
	* @return the r e s o l v e r_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.RESOLVER_DEFAULTS> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the r e s o l v e r_ d e f a u l t ses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.RESOLVER_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of r e s o l v e r_ d e f a u l t ses
	* @param end the upper bound of the range of r e s o l v e r_ d e f a u l t ses (not inclusive)
	* @return the range of r e s o l v e r_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.RESOLVER_DEFAULTS> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the r e s o l v e r_ d e f a u l t ses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.RESOLVER_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of r e s o l v e r_ d e f a u l t ses
	* @param end the upper bound of the range of r e s o l v e r_ d e f a u l t ses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of r e s o l v e r_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.RESOLVER_DEFAULTS> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the r e s o l v e r_ d e f a u l t ses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of r e s o l v e r_ d e f a u l t ses.
	*
	* @return the number of r e s o l v e r_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}