/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.jioc.query.service.ClpSerializer;
import com.jioc.query.service.Query_DetailsLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.DateUtil;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author shantaram.chavan
 */
public class Query_DetailsClp extends BaseModelImpl<Query_Details>
	implements Query_Details {
	public Query_DetailsClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return Query_Details.class;
	}

	@Override
	public String getModelClassName() {
		return Query_Details.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _queryDetailsId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setQueryDetailsId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _queryDetailsId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("queryDetailsId", getQueryDetailsId());
		attributes.put("queryId", getQueryId());
		attributes.put("updatedTimestamp", getUpdatedTimestamp());
		attributes.put("updatedBy", getUpdatedBy());
		attributes.put("assignedTo", getAssignedTo());
		attributes.put("action", getAction());
		attributes.put("status", getStatus());
		attributes.put("state", getState());
		attributes.put("region", getRegion());
		attributes.put("oc", getOc());
		attributes.put("queueLevel", getQueueLevel());
		attributes.put("comment", getComment());
		attributes.put("category", getCategory());
		attributes.put("subCategory", getSubCategory());
		attributes.put("caseResolution", getCaseResolution());
		attributes.put("is_closed", getIs_closed());
		attributes.put("closed_date", getClosed_date());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long queryDetailsId = (Long)attributes.get("queryDetailsId");

		if (queryDetailsId != null) {
			setQueryDetailsId(queryDetailsId);
		}

		Long queryId = (Long)attributes.get("queryId");

		if (queryId != null) {
			setQueryId(queryId);
		}

		Date updatedTimestamp = (Date)attributes.get("updatedTimestamp");

		if (updatedTimestamp != null) {
			setUpdatedTimestamp(updatedTimestamp);
		}

		Long updatedBy = (Long)attributes.get("updatedBy");

		if (updatedBy != null) {
			setUpdatedBy(updatedBy);
		}

		Long assignedTo = (Long)attributes.get("assignedTo");

		if (assignedTo != null) {
			setAssignedTo(assignedTo);
		}

		String action = (String)attributes.get("action");

		if (action != null) {
			setAction(action);
		}

		String status = (String)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String state = (String)attributes.get("state");

		if (state != null) {
			setState(state);
		}

		String region = (String)attributes.get("region");

		if (region != null) {
			setRegion(region);
		}

		String oc = (String)attributes.get("oc");

		if (oc != null) {
			setOc(oc);
		}

		Integer queueLevel = (Integer)attributes.get("queueLevel");

		if (queueLevel != null) {
			setQueueLevel(queueLevel);
		}

		String comment = (String)attributes.get("comment");

		if (comment != null) {
			setComment(comment);
		}

		Long category = (Long)attributes.get("category");

		if (category != null) {
			setCategory(category);
		}

		Long subCategory = (Long)attributes.get("subCategory");

		if (subCategory != null) {
			setSubCategory(subCategory);
		}

		Long caseResolution = (Long)attributes.get("caseResolution");

		if (caseResolution != null) {
			setCaseResolution(caseResolution);
		}

		Integer is_closed = (Integer)attributes.get("is_closed");

		if (is_closed != null) {
			setIs_closed(is_closed);
		}

		Date closed_date = (Date)attributes.get("closed_date");

		if (closed_date != null) {
			setClosed_date(closed_date);
		}
	}

	@Override
	public long getQueryDetailsId() {
		return _queryDetailsId;
	}

	@Override
	public void setQueryDetailsId(long queryDetailsId) {
		_queryDetailsId = queryDetailsId;

		if (_query_DetailsRemoteModel != null) {
			try {
				Class<?> clazz = _query_DetailsRemoteModel.getClass();

				Method method = clazz.getMethod("setQueryDetailsId", long.class);

				method.invoke(_query_DetailsRemoteModel, queryDetailsId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getQueryId() {
		return _queryId;
	}

	@Override
	public void setQueryId(long queryId) {
		_queryId = queryId;

		if (_query_DetailsRemoteModel != null) {
			try {
				Class<?> clazz = _query_DetailsRemoteModel.getClass();

				Method method = clazz.getMethod("setQueryId", long.class);

				method.invoke(_query_DetailsRemoteModel, queryId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getUpdatedTimestamp() {
		return _updatedTimestamp;
	}

	@Override
	public void setUpdatedTimestamp(Date updatedTimestamp) {
		_updatedTimestamp = updatedTimestamp;

		if (_query_DetailsRemoteModel != null) {
			try {
				Class<?> clazz = _query_DetailsRemoteModel.getClass();

				Method method = clazz.getMethod("setUpdatedTimestamp",
						Date.class);

				method.invoke(_query_DetailsRemoteModel, updatedTimestamp);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getUpdatedBy() {
		return _updatedBy;
	}

	@Override
	public void setUpdatedBy(long updatedBy) {
		_updatedBy = updatedBy;

		if (_query_DetailsRemoteModel != null) {
			try {
				Class<?> clazz = _query_DetailsRemoteModel.getClass();

				Method method = clazz.getMethod("setUpdatedBy", long.class);

				method.invoke(_query_DetailsRemoteModel, updatedBy);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getAssignedTo() {
		return _assignedTo;
	}

	@Override
	public void setAssignedTo(long assignedTo) {
		_assignedTo = assignedTo;

		if (_query_DetailsRemoteModel != null) {
			try {
				Class<?> clazz = _query_DetailsRemoteModel.getClass();

				Method method = clazz.getMethod("setAssignedTo", long.class);

				method.invoke(_query_DetailsRemoteModel, assignedTo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAction() {
		return _action;
	}

	@Override
	public void setAction(String action) {
		_action = action;

		if (_query_DetailsRemoteModel != null) {
			try {
				Class<?> clazz = _query_DetailsRemoteModel.getClass();

				Method method = clazz.getMethod("setAction", String.class);

				method.invoke(_query_DetailsRemoteModel, action);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getStatus() {
		return _status;
	}

	@Override
	public void setStatus(String status) {
		_status = status;

		if (_query_DetailsRemoteModel != null) {
			try {
				Class<?> clazz = _query_DetailsRemoteModel.getClass();

				Method method = clazz.getMethod("setStatus", String.class);

				method.invoke(_query_DetailsRemoteModel, status);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getState() {
		return _state;
	}

	@Override
	public void setState(String state) {
		_state = state;

		if (_query_DetailsRemoteModel != null) {
			try {
				Class<?> clazz = _query_DetailsRemoteModel.getClass();

				Method method = clazz.getMethod("setState", String.class);

				method.invoke(_query_DetailsRemoteModel, state);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRegion() {
		return _region;
	}

	@Override
	public void setRegion(String region) {
		_region = region;

		if (_query_DetailsRemoteModel != null) {
			try {
				Class<?> clazz = _query_DetailsRemoteModel.getClass();

				Method method = clazz.getMethod("setRegion", String.class);

				method.invoke(_query_DetailsRemoteModel, region);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOc() {
		return _oc;
	}

	@Override
	public void setOc(String oc) {
		_oc = oc;

		if (_query_DetailsRemoteModel != null) {
			try {
				Class<?> clazz = _query_DetailsRemoteModel.getClass();

				Method method = clazz.getMethod("setOc", String.class);

				method.invoke(_query_DetailsRemoteModel, oc);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getQueueLevel() {
		return _queueLevel;
	}

	@Override
	public void setQueueLevel(int queueLevel) {
		_queueLevel = queueLevel;

		if (_query_DetailsRemoteModel != null) {
			try {
				Class<?> clazz = _query_DetailsRemoteModel.getClass();

				Method method = clazz.getMethod("setQueueLevel", int.class);

				method.invoke(_query_DetailsRemoteModel, queueLevel);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getComment() {
		return _comment;
	}

	@Override
	public void setComment(String comment) {
		_comment = comment;

		if (_query_DetailsRemoteModel != null) {
			try {
				Class<?> clazz = _query_DetailsRemoteModel.getClass();

				Method method = clazz.getMethod("setComment", String.class);

				method.invoke(_query_DetailsRemoteModel, comment);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getCategory() {
		return _category;
	}

	@Override
	public void setCategory(long category) {
		_category = category;

		if (_query_DetailsRemoteModel != null) {
			try {
				Class<?> clazz = _query_DetailsRemoteModel.getClass();

				Method method = clazz.getMethod("setCategory", long.class);

				method.invoke(_query_DetailsRemoteModel, category);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getSubCategory() {
		return _subCategory;
	}

	@Override
	public void setSubCategory(long subCategory) {
		_subCategory = subCategory;

		if (_query_DetailsRemoteModel != null) {
			try {
				Class<?> clazz = _query_DetailsRemoteModel.getClass();

				Method method = clazz.getMethod("setSubCategory", long.class);

				method.invoke(_query_DetailsRemoteModel, subCategory);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getCaseResolution() {
		return _caseResolution;
	}

	@Override
	public void setCaseResolution(long caseResolution) {
		_caseResolution = caseResolution;

		if (_query_DetailsRemoteModel != null) {
			try {
				Class<?> clazz = _query_DetailsRemoteModel.getClass();

				Method method = clazz.getMethod("setCaseResolution", long.class);

				method.invoke(_query_DetailsRemoteModel, caseResolution);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getIs_closed() {
		return _is_closed;
	}

	@Override
	public void setIs_closed(int is_closed) {
		_is_closed = is_closed;

		if (_query_DetailsRemoteModel != null) {
			try {
				Class<?> clazz = _query_DetailsRemoteModel.getClass();

				Method method = clazz.getMethod("setIs_closed", int.class);

				method.invoke(_query_DetailsRemoteModel, is_closed);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getClosed_date() {
		return _closed_date;
	}

	@Override
	public void setClosed_date(Date closed_date) {
		_closed_date = closed_date;

		if (_query_DetailsRemoteModel != null) {
			try {
				Class<?> clazz = _query_DetailsRemoteModel.getClass();

				Method method = clazz.getMethod("setClosed_date", Date.class);

				method.invoke(_query_DetailsRemoteModel, closed_date);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getQuery_DetailsRemoteModel() {
		return _query_DetailsRemoteModel;
	}

	public void setQuery_DetailsRemoteModel(
		BaseModel<?> query_DetailsRemoteModel) {
		_query_DetailsRemoteModel = query_DetailsRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _query_DetailsRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_query_DetailsRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			Query_DetailsLocalServiceUtil.addQuery_Details(this);
		}
		else {
			Query_DetailsLocalServiceUtil.updateQuery_Details(this);
		}
	}

	@Override
	public Query_Details toEscapedModel() {
		return (Query_Details)ProxyUtil.newProxyInstance(Query_Details.class.getClassLoader(),
			new Class[] { Query_Details.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		Query_DetailsClp clone = new Query_DetailsClp();

		clone.setQueryDetailsId(getQueryDetailsId());
		clone.setQueryId(getQueryId());
		clone.setUpdatedTimestamp(getUpdatedTimestamp());
		clone.setUpdatedBy(getUpdatedBy());
		clone.setAssignedTo(getAssignedTo());
		clone.setAction(getAction());
		clone.setStatus(getStatus());
		clone.setState(getState());
		clone.setRegion(getRegion());
		clone.setOc(getOc());
		clone.setQueueLevel(getQueueLevel());
		clone.setComment(getComment());
		clone.setCategory(getCategory());
		clone.setSubCategory(getSubCategory());
		clone.setCaseResolution(getCaseResolution());
		clone.setIs_closed(getIs_closed());
		clone.setClosed_date(getClosed_date());

		return clone;
	}

	@Override
	public int compareTo(Query_Details query_Details) {
		int value = 0;

		value = DateUtil.compareTo(getUpdatedTimestamp(),
				query_Details.getUpdatedTimestamp());

		if (value != 0) {
			return value;
		}

		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof Query_DetailsClp)) {
			return false;
		}

		Query_DetailsClp query_Details = (Query_DetailsClp)obj;

		long primaryKey = query_Details.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(35);

		sb.append("{queryDetailsId=");
		sb.append(getQueryDetailsId());
		sb.append(", queryId=");
		sb.append(getQueryId());
		sb.append(", updatedTimestamp=");
		sb.append(getUpdatedTimestamp());
		sb.append(", updatedBy=");
		sb.append(getUpdatedBy());
		sb.append(", assignedTo=");
		sb.append(getAssignedTo());
		sb.append(", action=");
		sb.append(getAction());
		sb.append(", status=");
		sb.append(getStatus());
		sb.append(", state=");
		sb.append(getState());
		sb.append(", region=");
		sb.append(getRegion());
		sb.append(", oc=");
		sb.append(getOc());
		sb.append(", queueLevel=");
		sb.append(getQueueLevel());
		sb.append(", comment=");
		sb.append(getComment());
		sb.append(", category=");
		sb.append(getCategory());
		sb.append(", subCategory=");
		sb.append(getSubCategory());
		sb.append(", caseResolution=");
		sb.append(getCaseResolution());
		sb.append(", is_closed=");
		sb.append(getIs_closed());
		sb.append(", closed_date=");
		sb.append(getClosed_date());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(55);

		sb.append("<model><model-name>");
		sb.append("com.jioc.query.model.Query_Details");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>queryDetailsId</column-name><column-value><![CDATA[");
		sb.append(getQueryDetailsId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>queryId</column-name><column-value><![CDATA[");
		sb.append(getQueryId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>updatedTimestamp</column-name><column-value><![CDATA[");
		sb.append(getUpdatedTimestamp());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>updatedBy</column-name><column-value><![CDATA[");
		sb.append(getUpdatedBy());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>assignedTo</column-name><column-value><![CDATA[");
		sb.append(getAssignedTo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>action</column-name><column-value><![CDATA[");
		sb.append(getAction());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>status</column-name><column-value><![CDATA[");
		sb.append(getStatus());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>state</column-name><column-value><![CDATA[");
		sb.append(getState());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>region</column-name><column-value><![CDATA[");
		sb.append(getRegion());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>oc</column-name><column-value><![CDATA[");
		sb.append(getOc());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>queueLevel</column-name><column-value><![CDATA[");
		sb.append(getQueueLevel());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>comment</column-name><column-value><![CDATA[");
		sb.append(getComment());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>category</column-name><column-value><![CDATA[");
		sb.append(getCategory());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>subCategory</column-name><column-value><![CDATA[");
		sb.append(getSubCategory());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>caseResolution</column-name><column-value><![CDATA[");
		sb.append(getCaseResolution());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>is_closed</column-name><column-value><![CDATA[");
		sb.append(getIs_closed());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>closed_date</column-name><column-value><![CDATA[");
		sb.append(getClosed_date());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _queryDetailsId;
	private long _queryId;
	private Date _updatedTimestamp;
	private long _updatedBy;
	private long _assignedTo;
	private String _action;
	private String _status;
	private String _state;
	private String _region;
	private String _oc;
	private int _queueLevel;
	private String _comment;
	private long _category;
	private long _subCategory;
	private long _caseResolution;
	private int _is_closed;
	private Date _closed_date;
	private BaseModel<?> _query_DetailsRemoteModel;
	private Class<?> _clpSerializerClass = com.jioc.query.service.ClpSerializer.class;
}