/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.jioc.query.service.ClpSerializer;
import com.jioc.query.service.OC_SUB_CAT_MSTLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author shantaram.chavan
 */
public class OC_SUB_CAT_MSTClp extends BaseModelImpl<OC_SUB_CAT_MST>
	implements OC_SUB_CAT_MST {
	public OC_SUB_CAT_MSTClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return OC_SUB_CAT_MST.class;
	}

	@Override
	public String getModelClassName() {
		return OC_SUB_CAT_MST.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _SUB_CAT_ID;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setSUB_CAT_ID(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _SUB_CAT_ID;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("SUB_CAT_ID", getSUB_CAT_ID());
		attributes.put("CAT_ID", getCAT_ID());
		attributes.put("IS_ACTIVE", getIS_ACTIVE());
		attributes.put("SUB_CAT_NAME", getSUB_CAT_NAME());
		attributes.put("UPDATED_TIMESTAMP", getUPDATED_TIMESTAMP());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long SUB_CAT_ID = (Long)attributes.get("SUB_CAT_ID");

		if (SUB_CAT_ID != null) {
			setSUB_CAT_ID(SUB_CAT_ID);
		}

		Long CAT_ID = (Long)attributes.get("CAT_ID");

		if (CAT_ID != null) {
			setCAT_ID(CAT_ID);
		}

		Integer IS_ACTIVE = (Integer)attributes.get("IS_ACTIVE");

		if (IS_ACTIVE != null) {
			setIS_ACTIVE(IS_ACTIVE);
		}

		String SUB_CAT_NAME = (String)attributes.get("SUB_CAT_NAME");

		if (SUB_CAT_NAME != null) {
			setSUB_CAT_NAME(SUB_CAT_NAME);
		}

		Date UPDATED_TIMESTAMP = (Date)attributes.get("UPDATED_TIMESTAMP");

		if (UPDATED_TIMESTAMP != null) {
			setUPDATED_TIMESTAMP(UPDATED_TIMESTAMP);
		}
	}

	@Override
	public long getSUB_CAT_ID() {
		return _SUB_CAT_ID;
	}

	@Override
	public void setSUB_CAT_ID(long SUB_CAT_ID) {
		_SUB_CAT_ID = SUB_CAT_ID;

		if (_oc_sub_cat_mstRemoteModel != null) {
			try {
				Class<?> clazz = _oc_sub_cat_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setSUB_CAT_ID", long.class);

				method.invoke(_oc_sub_cat_mstRemoteModel, SUB_CAT_ID);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getCAT_ID() {
		return _CAT_ID;
	}

	@Override
	public void setCAT_ID(long CAT_ID) {
		_CAT_ID = CAT_ID;

		if (_oc_sub_cat_mstRemoteModel != null) {
			try {
				Class<?> clazz = _oc_sub_cat_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setCAT_ID", long.class);

				method.invoke(_oc_sub_cat_mstRemoteModel, CAT_ID);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getIS_ACTIVE() {
		return _IS_ACTIVE;
	}

	@Override
	public void setIS_ACTIVE(int IS_ACTIVE) {
		_IS_ACTIVE = IS_ACTIVE;

		if (_oc_sub_cat_mstRemoteModel != null) {
			try {
				Class<?> clazz = _oc_sub_cat_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setIS_ACTIVE", int.class);

				method.invoke(_oc_sub_cat_mstRemoteModel, IS_ACTIVE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSUB_CAT_NAME() {
		return _SUB_CAT_NAME;
	}

	@Override
	public void setSUB_CAT_NAME(String SUB_CAT_NAME) {
		_SUB_CAT_NAME = SUB_CAT_NAME;

		if (_oc_sub_cat_mstRemoteModel != null) {
			try {
				Class<?> clazz = _oc_sub_cat_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setSUB_CAT_NAME", String.class);

				method.invoke(_oc_sub_cat_mstRemoteModel, SUB_CAT_NAME);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getUPDATED_TIMESTAMP() {
		return _UPDATED_TIMESTAMP;
	}

	@Override
	public void setUPDATED_TIMESTAMP(Date UPDATED_TIMESTAMP) {
		_UPDATED_TIMESTAMP = UPDATED_TIMESTAMP;

		if (_oc_sub_cat_mstRemoteModel != null) {
			try {
				Class<?> clazz = _oc_sub_cat_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setUPDATED_TIMESTAMP",
						Date.class);

				method.invoke(_oc_sub_cat_mstRemoteModel, UPDATED_TIMESTAMP);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getOC_SUB_CAT_MSTRemoteModel() {
		return _oc_sub_cat_mstRemoteModel;
	}

	public void setOC_SUB_CAT_MSTRemoteModel(
		BaseModel<?> oc_sub_cat_mstRemoteModel) {
		_oc_sub_cat_mstRemoteModel = oc_sub_cat_mstRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _oc_sub_cat_mstRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_oc_sub_cat_mstRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			OC_SUB_CAT_MSTLocalServiceUtil.addOC_SUB_CAT_MST(this);
		}
		else {
			OC_SUB_CAT_MSTLocalServiceUtil.updateOC_SUB_CAT_MST(this);
		}
	}

	@Override
	public OC_SUB_CAT_MST toEscapedModel() {
		return (OC_SUB_CAT_MST)ProxyUtil.newProxyInstance(OC_SUB_CAT_MST.class.getClassLoader(),
			new Class[] { OC_SUB_CAT_MST.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		OC_SUB_CAT_MSTClp clone = new OC_SUB_CAT_MSTClp();

		clone.setSUB_CAT_ID(getSUB_CAT_ID());
		clone.setCAT_ID(getCAT_ID());
		clone.setIS_ACTIVE(getIS_ACTIVE());
		clone.setSUB_CAT_NAME(getSUB_CAT_NAME());
		clone.setUPDATED_TIMESTAMP(getUPDATED_TIMESTAMP());

		return clone;
	}

	@Override
	public int compareTo(OC_SUB_CAT_MST oc_sub_cat_mst) {
		long primaryKey = oc_sub_cat_mst.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof OC_SUB_CAT_MSTClp)) {
			return false;
		}

		OC_SUB_CAT_MSTClp oc_sub_cat_mst = (OC_SUB_CAT_MSTClp)obj;

		long primaryKey = oc_sub_cat_mst.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{SUB_CAT_ID=");
		sb.append(getSUB_CAT_ID());
		sb.append(", CAT_ID=");
		sb.append(getCAT_ID());
		sb.append(", IS_ACTIVE=");
		sb.append(getIS_ACTIVE());
		sb.append(", SUB_CAT_NAME=");
		sb.append(getSUB_CAT_NAME());
		sb.append(", UPDATED_TIMESTAMP=");
		sb.append(getUPDATED_TIMESTAMP());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(19);

		sb.append("<model><model-name>");
		sb.append("com.jioc.query.model.OC_SUB_CAT_MST");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>SUB_CAT_ID</column-name><column-value><![CDATA[");
		sb.append(getSUB_CAT_ID());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>CAT_ID</column-name><column-value><![CDATA[");
		sb.append(getCAT_ID());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>IS_ACTIVE</column-name><column-value><![CDATA[");
		sb.append(getIS_ACTIVE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>SUB_CAT_NAME</column-name><column-value><![CDATA[");
		sb.append(getSUB_CAT_NAME());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>UPDATED_TIMESTAMP</column-name><column-value><![CDATA[");
		sb.append(getUPDATED_TIMESTAMP());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _SUB_CAT_ID;
	private long _CAT_ID;
	private int _IS_ACTIVE;
	private String _SUB_CAT_NAME;
	private Date _UPDATED_TIMESTAMP;
	private BaseModel<?> _oc_sub_cat_mstRemoteModel;
	private Class<?> _clpSerializerClass = com.jioc.query.service.ClpSerializer.class;
}