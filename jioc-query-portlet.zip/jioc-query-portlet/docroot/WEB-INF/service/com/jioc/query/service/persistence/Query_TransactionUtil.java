/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.model.Query_Transaction;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import java.util.List;

/**
 * The persistence utility for the query_ transaction service. This utility wraps {@link Query_TransactionPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see Query_TransactionPersistence
 * @see Query_TransactionPersistenceImpl
 * @generated
 */
public class Query_TransactionUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(Query_Transaction query_Transaction) {
		getPersistence().clearCache(query_Transaction);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<Query_Transaction> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<Query_Transaction> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<Query_Transaction> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static Query_Transaction update(Query_Transaction query_Transaction)
		throws SystemException {
		return getPersistence().update(query_Transaction);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static Query_Transaction update(
		Query_Transaction query_Transaction, ServiceContext serviceContext)
		throws SystemException {
		return getPersistence().update(query_Transaction, serviceContext);
	}

	/**
	* Returns all the query_ transactions where raisedById = &#63;.
	*
	* @param raisedById the raised by ID
	* @return the matching query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Transaction> findByRaisedById(
		long raisedById)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByRaisedById(raisedById);
	}

	/**
	* Returns a range of all the query_ transactions where raisedById = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param raisedById the raised by ID
	* @param start the lower bound of the range of query_ transactions
	* @param end the upper bound of the range of query_ transactions (not inclusive)
	* @return the range of matching query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Transaction> findByRaisedById(
		long raisedById, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByRaisedById(raisedById, start, end);
	}

	/**
	* Returns an ordered range of all the query_ transactions where raisedById = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param raisedById the raised by ID
	* @param start the lower bound of the range of query_ transactions
	* @param end the upper bound of the range of query_ transactions (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Transaction> findByRaisedById(
		long raisedById, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByRaisedById(raisedById, start, end, orderByComparator);
	}

	/**
	* Returns the first query_ transaction in the ordered set where raisedById = &#63;.
	*
	* @param raisedById the raised by ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching query_ transaction
	* @throws com.jioc.query.NoSuchQuery_TransactionException if a matching query_ transaction could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Transaction findByRaisedById_First(
		long raisedById,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQuery_TransactionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByRaisedById_First(raisedById, orderByComparator);
	}

	/**
	* Returns the first query_ transaction in the ordered set where raisedById = &#63;.
	*
	* @param raisedById the raised by ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching query_ transaction, or <code>null</code> if a matching query_ transaction could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Transaction fetchByRaisedById_First(
		long raisedById,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByRaisedById_First(raisedById, orderByComparator);
	}

	/**
	* Returns the last query_ transaction in the ordered set where raisedById = &#63;.
	*
	* @param raisedById the raised by ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching query_ transaction
	* @throws com.jioc.query.NoSuchQuery_TransactionException if a matching query_ transaction could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Transaction findByRaisedById_Last(
		long raisedById,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQuery_TransactionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByRaisedById_Last(raisedById, orderByComparator);
	}

	/**
	* Returns the last query_ transaction in the ordered set where raisedById = &#63;.
	*
	* @param raisedById the raised by ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching query_ transaction, or <code>null</code> if a matching query_ transaction could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Transaction fetchByRaisedById_Last(
		long raisedById,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByRaisedById_Last(raisedById, orderByComparator);
	}

	/**
	* Returns the query_ transactions before and after the current query_ transaction in the ordered set where raisedById = &#63;.
	*
	* @param queryId the primary key of the current query_ transaction
	* @param raisedById the raised by ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next query_ transaction
	* @throws com.jioc.query.NoSuchQuery_TransactionException if a query_ transaction with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Transaction[] findByRaisedById_PrevAndNext(
		long queryId, long raisedById,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQuery_TransactionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByRaisedById_PrevAndNext(queryId, raisedById,
			orderByComparator);
	}

	/**
	* Removes all the query_ transactions where raisedById = &#63; from the database.
	*
	* @param raisedById the raised by ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByRaisedById(long raisedById)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByRaisedById(raisedById);
	}

	/**
	* Returns the number of query_ transactions where raisedById = &#63;.
	*
	* @param raisedById the raised by ID
	* @return the number of matching query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public static int countByRaisedById(long raisedById)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByRaisedById(raisedById);
	}

	/**
	* Returns all the query_ transactions where pcId = &#63;.
	*
	* @param pcId the pc ID
	* @return the matching query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Transaction> findByPCId(
		java.lang.String pcId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPCId(pcId);
	}

	/**
	* Returns a range of all the query_ transactions where pcId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pcId the pc ID
	* @param start the lower bound of the range of query_ transactions
	* @param end the upper bound of the range of query_ transactions (not inclusive)
	* @return the range of matching query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Transaction> findByPCId(
		java.lang.String pcId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPCId(pcId, start, end);
	}

	/**
	* Returns an ordered range of all the query_ transactions where pcId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pcId the pc ID
	* @param start the lower bound of the range of query_ transactions
	* @param end the upper bound of the range of query_ transactions (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Transaction> findByPCId(
		java.lang.String pcId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPCId(pcId, start, end, orderByComparator);
	}

	/**
	* Returns the first query_ transaction in the ordered set where pcId = &#63;.
	*
	* @param pcId the pc ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching query_ transaction
	* @throws com.jioc.query.NoSuchQuery_TransactionException if a matching query_ transaction could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Transaction findByPCId_First(
		java.lang.String pcId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQuery_TransactionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPCId_First(pcId, orderByComparator);
	}

	/**
	* Returns the first query_ transaction in the ordered set where pcId = &#63;.
	*
	* @param pcId the pc ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching query_ transaction, or <code>null</code> if a matching query_ transaction could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Transaction fetchByPCId_First(
		java.lang.String pcId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPCId_First(pcId, orderByComparator);
	}

	/**
	* Returns the last query_ transaction in the ordered set where pcId = &#63;.
	*
	* @param pcId the pc ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching query_ transaction
	* @throws com.jioc.query.NoSuchQuery_TransactionException if a matching query_ transaction could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Transaction findByPCId_Last(
		java.lang.String pcId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQuery_TransactionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPCId_Last(pcId, orderByComparator);
	}

	/**
	* Returns the last query_ transaction in the ordered set where pcId = &#63;.
	*
	* @param pcId the pc ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching query_ transaction, or <code>null</code> if a matching query_ transaction could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Transaction fetchByPCId_Last(
		java.lang.String pcId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPCId_Last(pcId, orderByComparator);
	}

	/**
	* Returns the query_ transactions before and after the current query_ transaction in the ordered set where pcId = &#63;.
	*
	* @param queryId the primary key of the current query_ transaction
	* @param pcId the pc ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next query_ transaction
	* @throws com.jioc.query.NoSuchQuery_TransactionException if a query_ transaction with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Transaction[] findByPCId_PrevAndNext(
		long queryId, java.lang.String pcId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQuery_TransactionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByPCId_PrevAndNext(queryId, pcId, orderByComparator);
	}

	/**
	* Removes all the query_ transactions where pcId = &#63; from the database.
	*
	* @param pcId the pc ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByPCId(java.lang.String pcId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByPCId(pcId);
	}

	/**
	* Returns the number of query_ transactions where pcId = &#63;.
	*
	* @param pcId the pc ID
	* @return the number of matching query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public static int countByPCId(java.lang.String pcId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByPCId(pcId);
	}

	/**
	* Caches the query_ transaction in the entity cache if it is enabled.
	*
	* @param query_Transaction the query_ transaction
	*/
	public static void cacheResult(
		com.jioc.query.model.Query_Transaction query_Transaction) {
		getPersistence().cacheResult(query_Transaction);
	}

	/**
	* Caches the query_ transactions in the entity cache if it is enabled.
	*
	* @param query_Transactions the query_ transactions
	*/
	public static void cacheResult(
		java.util.List<com.jioc.query.model.Query_Transaction> query_Transactions) {
		getPersistence().cacheResult(query_Transactions);
	}

	/**
	* Creates a new query_ transaction with the primary key. Does not add the query_ transaction to the database.
	*
	* @param queryId the primary key for the new query_ transaction
	* @return the new query_ transaction
	*/
	public static com.jioc.query.model.Query_Transaction create(long queryId) {
		return getPersistence().create(queryId);
	}

	/**
	* Removes the query_ transaction with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param queryId the primary key of the query_ transaction
	* @return the query_ transaction that was removed
	* @throws com.jioc.query.NoSuchQuery_TransactionException if a query_ transaction with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Transaction remove(long queryId)
		throws com.jioc.query.NoSuchQuery_TransactionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().remove(queryId);
	}

	public static com.jioc.query.model.Query_Transaction updateImpl(
		com.jioc.query.model.Query_Transaction query_Transaction)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(query_Transaction);
	}

	/**
	* Returns the query_ transaction with the primary key or throws a {@link com.jioc.query.NoSuchQuery_TransactionException} if it could not be found.
	*
	* @param queryId the primary key of the query_ transaction
	* @return the query_ transaction
	* @throws com.jioc.query.NoSuchQuery_TransactionException if a query_ transaction with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Transaction findByPrimaryKey(
		long queryId)
		throws com.jioc.query.NoSuchQuery_TransactionException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPrimaryKey(queryId);
	}

	/**
	* Returns the query_ transaction with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param queryId the primary key of the query_ transaction
	* @return the query_ transaction, or <code>null</code> if a query_ transaction with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Transaction fetchByPrimaryKey(
		long queryId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(queryId);
	}

	/**
	* Returns all the query_ transactions.
	*
	* @return the query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Transaction> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the query_ transactions.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of query_ transactions
	* @param end the upper bound of the range of query_ transactions (not inclusive)
	* @return the range of query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Transaction> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the query_ transactions.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of query_ transactions
	* @param end the upper bound of the range of query_ transactions (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Transaction> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the query_ transactions from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of query_ transactions.
	*
	* @return the number of query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static Query_TransactionPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (Query_TransactionPersistence)PortletBeanLocatorUtil.locate(com.jioc.query.service.ClpSerializer.getServletContextName(),
					Query_TransactionPersistence.class.getName());

			ReferenceRegistry.registerReference(Query_TransactionUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(Query_TransactionPersistence persistence) {
	}

	private static Query_TransactionPersistence _persistence;
}