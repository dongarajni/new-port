/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link RESOLVER_LEVEL_MST}.
 * </p>
 *
 * @author shantaram.chavan
 * @see RESOLVER_LEVEL_MST
 * @generated
 */
public class RESOLVER_LEVEL_MSTWrapper implements RESOLVER_LEVEL_MST,
	ModelWrapper<RESOLVER_LEVEL_MST> {
	public RESOLVER_LEVEL_MSTWrapper(RESOLVER_LEVEL_MST resolver_level_mst) {
		_resolver_level_mst = resolver_level_mst;
	}

	@Override
	public Class<?> getModelClass() {
		return RESOLVER_LEVEL_MST.class;
	}

	@Override
	public String getModelClassName() {
		return RESOLVER_LEVEL_MST.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("LEVEL_ID", getLEVEL_ID());
		attributes.put("LEVEL_NAME", getLEVEL_NAME());
		attributes.put("RESOLVER_LEVEL", getRESOLVER_LEVEL());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long LEVEL_ID = (Long)attributes.get("LEVEL_ID");

		if (LEVEL_ID != null) {
			setLEVEL_ID(LEVEL_ID);
		}

		String LEVEL_NAME = (String)attributes.get("LEVEL_NAME");

		if (LEVEL_NAME != null) {
			setLEVEL_NAME(LEVEL_NAME);
		}

		Integer RESOLVER_LEVEL = (Integer)attributes.get("RESOLVER_LEVEL");

		if (RESOLVER_LEVEL != null) {
			setRESOLVER_LEVEL(RESOLVER_LEVEL);
		}
	}

	/**
	* Returns the primary key of this r e s o l v e r_ l e v e l_ m s t.
	*
	* @return the primary key of this r e s o l v e r_ l e v e l_ m s t
	*/
	@Override
	public long getPrimaryKey() {
		return _resolver_level_mst.getPrimaryKey();
	}

	/**
	* Sets the primary key of this r e s o l v e r_ l e v e l_ m s t.
	*
	* @param primaryKey the primary key of this r e s o l v e r_ l e v e l_ m s t
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_resolver_level_mst.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the l e v e l_ i d of this r e s o l v e r_ l e v e l_ m s t.
	*
	* @return the l e v e l_ i d of this r e s o l v e r_ l e v e l_ m s t
	*/
	@Override
	public long getLEVEL_ID() {
		return _resolver_level_mst.getLEVEL_ID();
	}

	/**
	* Sets the l e v e l_ i d of this r e s o l v e r_ l e v e l_ m s t.
	*
	* @param LEVEL_ID the l e v e l_ i d of this r e s o l v e r_ l e v e l_ m s t
	*/
	@Override
	public void setLEVEL_ID(long LEVEL_ID) {
		_resolver_level_mst.setLEVEL_ID(LEVEL_ID);
	}

	/**
	* Returns the l e v e l_ n a m e of this r e s o l v e r_ l e v e l_ m s t.
	*
	* @return the l e v e l_ n a m e of this r e s o l v e r_ l e v e l_ m s t
	*/
	@Override
	public java.lang.String getLEVEL_NAME() {
		return _resolver_level_mst.getLEVEL_NAME();
	}

	/**
	* Sets the l e v e l_ n a m e of this r e s o l v e r_ l e v e l_ m s t.
	*
	* @param LEVEL_NAME the l e v e l_ n a m e of this r e s o l v e r_ l e v e l_ m s t
	*/
	@Override
	public void setLEVEL_NAME(java.lang.String LEVEL_NAME) {
		_resolver_level_mst.setLEVEL_NAME(LEVEL_NAME);
	}

	/**
	* Returns the r e s o l v e r_ l e v e l of this r e s o l v e r_ l e v e l_ m s t.
	*
	* @return the r e s o l v e r_ l e v e l of this r e s o l v e r_ l e v e l_ m s t
	*/
	@Override
	public int getRESOLVER_LEVEL() {
		return _resolver_level_mst.getRESOLVER_LEVEL();
	}

	/**
	* Sets the r e s o l v e r_ l e v e l of this r e s o l v e r_ l e v e l_ m s t.
	*
	* @param RESOLVER_LEVEL the r e s o l v e r_ l e v e l of this r e s o l v e r_ l e v e l_ m s t
	*/
	@Override
	public void setRESOLVER_LEVEL(int RESOLVER_LEVEL) {
		_resolver_level_mst.setRESOLVER_LEVEL(RESOLVER_LEVEL);
	}

	@Override
	public boolean isNew() {
		return _resolver_level_mst.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_resolver_level_mst.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _resolver_level_mst.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_resolver_level_mst.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _resolver_level_mst.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _resolver_level_mst.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_resolver_level_mst.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _resolver_level_mst.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_resolver_level_mst.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_resolver_level_mst.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_resolver_level_mst.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new RESOLVER_LEVEL_MSTWrapper((RESOLVER_LEVEL_MST)_resolver_level_mst.clone());
	}

	@Override
	public int compareTo(
		com.jioc.query.model.RESOLVER_LEVEL_MST resolver_level_mst) {
		return _resolver_level_mst.compareTo(resolver_level_mst);
	}

	@Override
	public int hashCode() {
		return _resolver_level_mst.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jioc.query.model.RESOLVER_LEVEL_MST> toCacheModel() {
		return _resolver_level_mst.toCacheModel();
	}

	@Override
	public com.jioc.query.model.RESOLVER_LEVEL_MST toEscapedModel() {
		return new RESOLVER_LEVEL_MSTWrapper(_resolver_level_mst.toEscapedModel());
	}

	@Override
	public com.jioc.query.model.RESOLVER_LEVEL_MST toUnescapedModel() {
		return new RESOLVER_LEVEL_MSTWrapper(_resolver_level_mst.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _resolver_level_mst.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _resolver_level_mst.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_resolver_level_mst.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof RESOLVER_LEVEL_MSTWrapper)) {
			return false;
		}

		RESOLVER_LEVEL_MSTWrapper resolver_level_mstWrapper = (RESOLVER_LEVEL_MSTWrapper)obj;

		if (Validator.equals(_resolver_level_mst,
					resolver_level_mstWrapper._resolver_level_mst)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public RESOLVER_LEVEL_MST getWrappedRESOLVER_LEVEL_MST() {
		return _resolver_level_mst;
	}

	@Override
	public RESOLVER_LEVEL_MST getWrappedModel() {
		return _resolver_level_mst;
	}

	@Override
	public void resetOriginalValues() {
		_resolver_level_mst.resetOriginalValues();
	}

	private RESOLVER_LEVEL_MST _resolver_level_mst;
}