/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.model.Emp_User_Mapping;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import java.util.List;

/**
 * The persistence utility for the emp_ user_ mapping service. This utility wraps {@link Emp_User_MappingPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see Emp_User_MappingPersistence
 * @see Emp_User_MappingPersistenceImpl
 * @generated
 */
public class Emp_User_MappingUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(Emp_User_Mapping emp_User_Mapping) {
		getPersistence().clearCache(emp_User_Mapping);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<Emp_User_Mapping> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<Emp_User_Mapping> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<Emp_User_Mapping> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static Emp_User_Mapping update(Emp_User_Mapping emp_User_Mapping)
		throws SystemException {
		return getPersistence().update(emp_User_Mapping);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static Emp_User_Mapping update(Emp_User_Mapping emp_User_Mapping,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(emp_User_Mapping, serviceContext);
	}

	/**
	* Returns all the emp_ user_ mappings where empId = &#63;.
	*
	* @param empId the emp ID
	* @return the matching emp_ user_ mappings
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Emp_User_Mapping> findByEmpId(
		java.lang.String empId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByEmpId(empId);
	}

	/**
	* Returns a range of all the emp_ user_ mappings where empId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Emp_User_MappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param empId the emp ID
	* @param start the lower bound of the range of emp_ user_ mappings
	* @param end the upper bound of the range of emp_ user_ mappings (not inclusive)
	* @return the range of matching emp_ user_ mappings
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Emp_User_Mapping> findByEmpId(
		java.lang.String empId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByEmpId(empId, start, end);
	}

	/**
	* Returns an ordered range of all the emp_ user_ mappings where empId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Emp_User_MappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param empId the emp ID
	* @param start the lower bound of the range of emp_ user_ mappings
	* @param end the upper bound of the range of emp_ user_ mappings (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching emp_ user_ mappings
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Emp_User_Mapping> findByEmpId(
		java.lang.String empId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByEmpId(empId, start, end, orderByComparator);
	}

	/**
	* Returns the first emp_ user_ mapping in the ordered set where empId = &#63;.
	*
	* @param empId the emp ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching emp_ user_ mapping
	* @throws com.jioc.query.NoSuchEmp_User_MappingException if a matching emp_ user_ mapping could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Emp_User_Mapping findByEmpId_First(
		java.lang.String empId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchEmp_User_MappingException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByEmpId_First(empId, orderByComparator);
	}

	/**
	* Returns the first emp_ user_ mapping in the ordered set where empId = &#63;.
	*
	* @param empId the emp ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching emp_ user_ mapping, or <code>null</code> if a matching emp_ user_ mapping could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Emp_User_Mapping fetchByEmpId_First(
		java.lang.String empId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByEmpId_First(empId, orderByComparator);
	}

	/**
	* Returns the last emp_ user_ mapping in the ordered set where empId = &#63;.
	*
	* @param empId the emp ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching emp_ user_ mapping
	* @throws com.jioc.query.NoSuchEmp_User_MappingException if a matching emp_ user_ mapping could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Emp_User_Mapping findByEmpId_Last(
		java.lang.String empId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchEmp_User_MappingException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByEmpId_Last(empId, orderByComparator);
	}

	/**
	* Returns the last emp_ user_ mapping in the ordered set where empId = &#63;.
	*
	* @param empId the emp ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching emp_ user_ mapping, or <code>null</code> if a matching emp_ user_ mapping could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Emp_User_Mapping fetchByEmpId_Last(
		java.lang.String empId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByEmpId_Last(empId, orderByComparator);
	}

	/**
	* Returns the emp_ user_ mappings before and after the current emp_ user_ mapping in the ordered set where empId = &#63;.
	*
	* @param userId the primary key of the current emp_ user_ mapping
	* @param empId the emp ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next emp_ user_ mapping
	* @throws com.jioc.query.NoSuchEmp_User_MappingException if a emp_ user_ mapping with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Emp_User_Mapping[] findByEmpId_PrevAndNext(
		long userId, java.lang.String empId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchEmp_User_MappingException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByEmpId_PrevAndNext(userId, empId, orderByComparator);
	}

	/**
	* Removes all the emp_ user_ mappings where empId = &#63; from the database.
	*
	* @param empId the emp ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByEmpId(java.lang.String empId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByEmpId(empId);
	}

	/**
	* Returns the number of emp_ user_ mappings where empId = &#63;.
	*
	* @param empId the emp ID
	* @return the number of matching emp_ user_ mappings
	* @throws SystemException if a system exception occurred
	*/
	public static int countByEmpId(java.lang.String empId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByEmpId(empId);
	}

	/**
	* Returns all the emp_ user_ mappings where emailId = &#63;.
	*
	* @param emailId the email ID
	* @return the matching emp_ user_ mappings
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Emp_User_Mapping> findByEmailId(
		java.lang.String emailId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByEmailId(emailId);
	}

	/**
	* Returns a range of all the emp_ user_ mappings where emailId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Emp_User_MappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param emailId the email ID
	* @param start the lower bound of the range of emp_ user_ mappings
	* @param end the upper bound of the range of emp_ user_ mappings (not inclusive)
	* @return the range of matching emp_ user_ mappings
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Emp_User_Mapping> findByEmailId(
		java.lang.String emailId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByEmailId(emailId, start, end);
	}

	/**
	* Returns an ordered range of all the emp_ user_ mappings where emailId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Emp_User_MappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param emailId the email ID
	* @param start the lower bound of the range of emp_ user_ mappings
	* @param end the upper bound of the range of emp_ user_ mappings (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching emp_ user_ mappings
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Emp_User_Mapping> findByEmailId(
		java.lang.String emailId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByEmailId(emailId, start, end, orderByComparator);
	}

	/**
	* Returns the first emp_ user_ mapping in the ordered set where emailId = &#63;.
	*
	* @param emailId the email ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching emp_ user_ mapping
	* @throws com.jioc.query.NoSuchEmp_User_MappingException if a matching emp_ user_ mapping could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Emp_User_Mapping findByEmailId_First(
		java.lang.String emailId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchEmp_User_MappingException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByEmailId_First(emailId, orderByComparator);
	}

	/**
	* Returns the first emp_ user_ mapping in the ordered set where emailId = &#63;.
	*
	* @param emailId the email ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching emp_ user_ mapping, or <code>null</code> if a matching emp_ user_ mapping could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Emp_User_Mapping fetchByEmailId_First(
		java.lang.String emailId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByEmailId_First(emailId, orderByComparator);
	}

	/**
	* Returns the last emp_ user_ mapping in the ordered set where emailId = &#63;.
	*
	* @param emailId the email ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching emp_ user_ mapping
	* @throws com.jioc.query.NoSuchEmp_User_MappingException if a matching emp_ user_ mapping could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Emp_User_Mapping findByEmailId_Last(
		java.lang.String emailId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchEmp_User_MappingException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByEmailId_Last(emailId, orderByComparator);
	}

	/**
	* Returns the last emp_ user_ mapping in the ordered set where emailId = &#63;.
	*
	* @param emailId the email ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching emp_ user_ mapping, or <code>null</code> if a matching emp_ user_ mapping could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Emp_User_Mapping fetchByEmailId_Last(
		java.lang.String emailId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByEmailId_Last(emailId, orderByComparator);
	}

	/**
	* Returns the emp_ user_ mappings before and after the current emp_ user_ mapping in the ordered set where emailId = &#63;.
	*
	* @param userId the primary key of the current emp_ user_ mapping
	* @param emailId the email ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next emp_ user_ mapping
	* @throws com.jioc.query.NoSuchEmp_User_MappingException if a emp_ user_ mapping with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Emp_User_Mapping[] findByEmailId_PrevAndNext(
		long userId, java.lang.String emailId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchEmp_User_MappingException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByEmailId_PrevAndNext(userId, emailId, orderByComparator);
	}

	/**
	* Removes all the emp_ user_ mappings where emailId = &#63; from the database.
	*
	* @param emailId the email ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByEmailId(java.lang.String emailId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByEmailId(emailId);
	}

	/**
	* Returns the number of emp_ user_ mappings where emailId = &#63;.
	*
	* @param emailId the email ID
	* @return the number of matching emp_ user_ mappings
	* @throws SystemException if a system exception occurred
	*/
	public static int countByEmailId(java.lang.String emailId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByEmailId(emailId);
	}

	/**
	* Caches the emp_ user_ mapping in the entity cache if it is enabled.
	*
	* @param emp_User_Mapping the emp_ user_ mapping
	*/
	public static void cacheResult(
		com.jioc.query.model.Emp_User_Mapping emp_User_Mapping) {
		getPersistence().cacheResult(emp_User_Mapping);
	}

	/**
	* Caches the emp_ user_ mappings in the entity cache if it is enabled.
	*
	* @param emp_User_Mappings the emp_ user_ mappings
	*/
	public static void cacheResult(
		java.util.List<com.jioc.query.model.Emp_User_Mapping> emp_User_Mappings) {
		getPersistence().cacheResult(emp_User_Mappings);
	}

	/**
	* Creates a new emp_ user_ mapping with the primary key. Does not add the emp_ user_ mapping to the database.
	*
	* @param userId the primary key for the new emp_ user_ mapping
	* @return the new emp_ user_ mapping
	*/
	public static com.jioc.query.model.Emp_User_Mapping create(long userId) {
		return getPersistence().create(userId);
	}

	/**
	* Removes the emp_ user_ mapping with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param userId the primary key of the emp_ user_ mapping
	* @return the emp_ user_ mapping that was removed
	* @throws com.jioc.query.NoSuchEmp_User_MappingException if a emp_ user_ mapping with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Emp_User_Mapping remove(long userId)
		throws com.jioc.query.NoSuchEmp_User_MappingException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().remove(userId);
	}

	public static com.jioc.query.model.Emp_User_Mapping updateImpl(
		com.jioc.query.model.Emp_User_Mapping emp_User_Mapping)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(emp_User_Mapping);
	}

	/**
	* Returns the emp_ user_ mapping with the primary key or throws a {@link com.jioc.query.NoSuchEmp_User_MappingException} if it could not be found.
	*
	* @param userId the primary key of the emp_ user_ mapping
	* @return the emp_ user_ mapping
	* @throws com.jioc.query.NoSuchEmp_User_MappingException if a emp_ user_ mapping with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Emp_User_Mapping findByPrimaryKey(
		long userId)
		throws com.jioc.query.NoSuchEmp_User_MappingException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPrimaryKey(userId);
	}

	/**
	* Returns the emp_ user_ mapping with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param userId the primary key of the emp_ user_ mapping
	* @return the emp_ user_ mapping, or <code>null</code> if a emp_ user_ mapping with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Emp_User_Mapping fetchByPrimaryKey(
		long userId) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(userId);
	}

	/**
	* Returns all the emp_ user_ mappings.
	*
	* @return the emp_ user_ mappings
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Emp_User_Mapping> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the emp_ user_ mappings.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Emp_User_MappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of emp_ user_ mappings
	* @param end the upper bound of the range of emp_ user_ mappings (not inclusive)
	* @return the range of emp_ user_ mappings
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Emp_User_Mapping> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the emp_ user_ mappings.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Emp_User_MappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of emp_ user_ mappings
	* @param end the upper bound of the range of emp_ user_ mappings (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of emp_ user_ mappings
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Emp_User_Mapping> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the emp_ user_ mappings from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of emp_ user_ mappings.
	*
	* @return the number of emp_ user_ mappings
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static Emp_User_MappingPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (Emp_User_MappingPersistence)PortletBeanLocatorUtil.locate(com.jioc.query.service.ClpSerializer.getServletContextName(),
					Emp_User_MappingPersistence.class.getName());

			ReferenceRegistry.registerReference(Emp_User_MappingUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(Emp_User_MappingPersistence persistence) {
	}

	private static Emp_User_MappingPersistence _persistence;
}