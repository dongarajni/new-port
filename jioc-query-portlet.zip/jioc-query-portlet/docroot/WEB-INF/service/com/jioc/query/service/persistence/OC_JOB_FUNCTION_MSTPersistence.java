/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.model.OC_JOB_FUNCTION_MST;

import com.liferay.portal.service.persistence.BasePersistence;

/**
 * The persistence interface for the o c_ j o b_ f u n c t i o n_ m s t service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see OC_JOB_FUNCTION_MSTPersistenceImpl
 * @see OC_JOB_FUNCTION_MSTUtil
 * @generated
 */
public interface OC_JOB_FUNCTION_MSTPersistence extends BasePersistence<OC_JOB_FUNCTION_MST> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link OC_JOB_FUNCTION_MSTUtil} to access the o c_ j o b_ f u n c t i o n_ m s t persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the o c_ j o b_ f u n c t i o n_ m s ts where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @return the matching o c_ j o b_ f u n c t i o n_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.OC_JOB_FUNCTION_MST> findByAreaJobFunction(
		java.lang.String FUNCTIONAL_AREA, java.lang.String JOB,
		java.lang.String SUB_FUNCTIONAL_AREA)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the o c_ j o b_ f u n c t i o n_ m s ts where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.OC_JOB_FUNCTION_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @param start the lower bound of the range of o c_ j o b_ f u n c t i o n_ m s ts
	* @param end the upper bound of the range of o c_ j o b_ f u n c t i o n_ m s ts (not inclusive)
	* @return the range of matching o c_ j o b_ f u n c t i o n_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.OC_JOB_FUNCTION_MST> findByAreaJobFunction(
		java.lang.String FUNCTIONAL_AREA, java.lang.String JOB,
		java.lang.String SUB_FUNCTIONAL_AREA, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the o c_ j o b_ f u n c t i o n_ m s ts where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.OC_JOB_FUNCTION_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @param start the lower bound of the range of o c_ j o b_ f u n c t i o n_ m s ts
	* @param end the upper bound of the range of o c_ j o b_ f u n c t i o n_ m s ts (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching o c_ j o b_ f u n c t i o n_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.OC_JOB_FUNCTION_MST> findByAreaJobFunction(
		java.lang.String FUNCTIONAL_AREA, java.lang.String JOB,
		java.lang.String SUB_FUNCTIONAL_AREA, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first o c_ j o b_ f u n c t i o n_ m s t in the ordered set where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching o c_ j o b_ f u n c t i o n_ m s t
	* @throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException if a matching o c_ j o b_ f u n c t i o n_ m s t could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.OC_JOB_FUNCTION_MST findByAreaJobFunction_First(
		java.lang.String FUNCTIONAL_AREA, java.lang.String JOB,
		java.lang.String SUB_FUNCTIONAL_AREA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first o c_ j o b_ f u n c t i o n_ m s t in the ordered set where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching o c_ j o b_ f u n c t i o n_ m s t, or <code>null</code> if a matching o c_ j o b_ f u n c t i o n_ m s t could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.OC_JOB_FUNCTION_MST fetchByAreaJobFunction_First(
		java.lang.String FUNCTIONAL_AREA, java.lang.String JOB,
		java.lang.String SUB_FUNCTIONAL_AREA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last o c_ j o b_ f u n c t i o n_ m s t in the ordered set where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching o c_ j o b_ f u n c t i o n_ m s t
	* @throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException if a matching o c_ j o b_ f u n c t i o n_ m s t could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.OC_JOB_FUNCTION_MST findByAreaJobFunction_Last(
		java.lang.String FUNCTIONAL_AREA, java.lang.String JOB,
		java.lang.String SUB_FUNCTIONAL_AREA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last o c_ j o b_ f u n c t i o n_ m s t in the ordered set where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching o c_ j o b_ f u n c t i o n_ m s t, or <code>null</code> if a matching o c_ j o b_ f u n c t i o n_ m s t could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.OC_JOB_FUNCTION_MST fetchByAreaJobFunction_Last(
		java.lang.String FUNCTIONAL_AREA, java.lang.String JOB,
		java.lang.String SUB_FUNCTIONAL_AREA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the o c_ j o b_ f u n c t i o n_ m s ts before and after the current o c_ j o b_ f u n c t i o n_ m s t in the ordered set where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* @param OC_JOB_FUNCTION_ID the primary key of the current o c_ j o b_ f u n c t i o n_ m s t
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next o c_ j o b_ f u n c t i o n_ m s t
	* @throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException if a o c_ j o b_ f u n c t i o n_ m s t with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.OC_JOB_FUNCTION_MST[] findByAreaJobFunction_PrevAndNext(
		long OC_JOB_FUNCTION_ID, java.lang.String FUNCTIONAL_AREA,
		java.lang.String JOB, java.lang.String SUB_FUNCTIONAL_AREA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the o c_ j o b_ f u n c t i o n_ m s ts where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63; from the database.
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @throws SystemException if a system exception occurred
	*/
	public void removeByAreaJobFunction(java.lang.String FUNCTIONAL_AREA,
		java.lang.String JOB, java.lang.String SUB_FUNCTIONAL_AREA)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of o c_ j o b_ f u n c t i o n_ m s ts where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @return the number of matching o c_ j o b_ f u n c t i o n_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public int countByAreaJobFunction(java.lang.String FUNCTIONAL_AREA,
		java.lang.String JOB, java.lang.String SUB_FUNCTIONAL_AREA)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the o c_ j o b_ f u n c t i o n_ m s t in the entity cache if it is enabled.
	*
	* @param oc_job_function_mst the o c_ j o b_ f u n c t i o n_ m s t
	*/
	public void cacheResult(
		com.jioc.query.model.OC_JOB_FUNCTION_MST oc_job_function_mst);

	/**
	* Caches the o c_ j o b_ f u n c t i o n_ m s ts in the entity cache if it is enabled.
	*
	* @param oc_job_function_msts the o c_ j o b_ f u n c t i o n_ m s ts
	*/
	public void cacheResult(
		java.util.List<com.jioc.query.model.OC_JOB_FUNCTION_MST> oc_job_function_msts);

	/**
	* Creates a new o c_ j o b_ f u n c t i o n_ m s t with the primary key. Does not add the o c_ j o b_ f u n c t i o n_ m s t to the database.
	*
	* @param OC_JOB_FUNCTION_ID the primary key for the new o c_ j o b_ f u n c t i o n_ m s t
	* @return the new o c_ j o b_ f u n c t i o n_ m s t
	*/
	public com.jioc.query.model.OC_JOB_FUNCTION_MST create(
		long OC_JOB_FUNCTION_ID);

	/**
	* Removes the o c_ j o b_ f u n c t i o n_ m s t with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param OC_JOB_FUNCTION_ID the primary key of the o c_ j o b_ f u n c t i o n_ m s t
	* @return the o c_ j o b_ f u n c t i o n_ m s t that was removed
	* @throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException if a o c_ j o b_ f u n c t i o n_ m s t with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.OC_JOB_FUNCTION_MST remove(
		long OC_JOB_FUNCTION_ID)
		throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException,
			com.liferay.portal.kernel.exception.SystemException;

	public com.jioc.query.model.OC_JOB_FUNCTION_MST updateImpl(
		com.jioc.query.model.OC_JOB_FUNCTION_MST oc_job_function_mst)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the o c_ j o b_ f u n c t i o n_ m s t with the primary key or throws a {@link com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException} if it could not be found.
	*
	* @param OC_JOB_FUNCTION_ID the primary key of the o c_ j o b_ f u n c t i o n_ m s t
	* @return the o c_ j o b_ f u n c t i o n_ m s t
	* @throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException if a o c_ j o b_ f u n c t i o n_ m s t with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.OC_JOB_FUNCTION_MST findByPrimaryKey(
		long OC_JOB_FUNCTION_ID)
		throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the o c_ j o b_ f u n c t i o n_ m s t with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param OC_JOB_FUNCTION_ID the primary key of the o c_ j o b_ f u n c t i o n_ m s t
	* @return the o c_ j o b_ f u n c t i o n_ m s t, or <code>null</code> if a o c_ j o b_ f u n c t i o n_ m s t with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.OC_JOB_FUNCTION_MST fetchByPrimaryKey(
		long OC_JOB_FUNCTION_ID)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the o c_ j o b_ f u n c t i o n_ m s ts.
	*
	* @return the o c_ j o b_ f u n c t i o n_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.OC_JOB_FUNCTION_MST> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the o c_ j o b_ f u n c t i o n_ m s ts.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.OC_JOB_FUNCTION_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of o c_ j o b_ f u n c t i o n_ m s ts
	* @param end the upper bound of the range of o c_ j o b_ f u n c t i o n_ m s ts (not inclusive)
	* @return the range of o c_ j o b_ f u n c t i o n_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.OC_JOB_FUNCTION_MST> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the o c_ j o b_ f u n c t i o n_ m s ts.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.OC_JOB_FUNCTION_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of o c_ j o b_ f u n c t i o n_ m s ts
	* @param end the upper bound of the range of o c_ j o b_ f u n c t i o n_ m s ts (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of o c_ j o b_ f u n c t i o n_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.OC_JOB_FUNCTION_MST> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the o c_ j o b_ f u n c t i o n_ m s ts from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of o c_ j o b_ f u n c t i o n_ m s ts.
	*
	* @return the number of o c_ j o b_ f u n c t i o n_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}