/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link QUERY_MOD_DEFAULTS}.
 * </p>
 *
 * @author shantaram.chavan
 * @see QUERY_MOD_DEFAULTS
 * @generated
 */
public class QUERY_MOD_DEFAULTSWrapper implements QUERY_MOD_DEFAULTS,
	ModelWrapper<QUERY_MOD_DEFAULTS> {
	public QUERY_MOD_DEFAULTSWrapper(QUERY_MOD_DEFAULTS query_mod_defaults) {
		_query_mod_defaults = query_mod_defaults;
	}

	@Override
	public Class<?> getModelClass() {
		return QUERY_MOD_DEFAULTS.class;
	}

	@Override
	public String getModelClassName() {
		return QUERY_MOD_DEFAULTS.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("QUERY_MOD_DEFAULTS_ID", getQUERY_MOD_DEFAULTS_ID());
		attributes.put("CURR_VAL", getCURR_VAL());
		attributes.put("NEW_VAL", getNEW_VAL());
		attributes.put("IS_ACTIVE", getIS_ACTIVE());
		attributes.put("UPDATED_TIMESTAMP", getUPDATED_TIMESTAMP());
		attributes.put("TYPE", getTYPE());
		attributes.put("CURR_LEVEL", getCURR_LEVEL());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Integer QUERY_MOD_DEFAULTS_ID = (Integer)attributes.get(
				"QUERY_MOD_DEFAULTS_ID");

		if (QUERY_MOD_DEFAULTS_ID != null) {
			setQUERY_MOD_DEFAULTS_ID(QUERY_MOD_DEFAULTS_ID);
		}

		String CURR_VAL = (String)attributes.get("CURR_VAL");

		if (CURR_VAL != null) {
			setCURR_VAL(CURR_VAL);
		}

		String NEW_VAL = (String)attributes.get("NEW_VAL");

		if (NEW_VAL != null) {
			setNEW_VAL(NEW_VAL);
		}

		Integer IS_ACTIVE = (Integer)attributes.get("IS_ACTIVE");

		if (IS_ACTIVE != null) {
			setIS_ACTIVE(IS_ACTIVE);
		}

		Date UPDATED_TIMESTAMP = (Date)attributes.get("UPDATED_TIMESTAMP");

		if (UPDATED_TIMESTAMP != null) {
			setUPDATED_TIMESTAMP(UPDATED_TIMESTAMP);
		}

		String TYPE = (String)attributes.get("TYPE");

		if (TYPE != null) {
			setTYPE(TYPE);
		}

		Integer CURR_LEVEL = (Integer)attributes.get("CURR_LEVEL");

		if (CURR_LEVEL != null) {
			setCURR_LEVEL(CURR_LEVEL);
		}
	}

	/**
	* Returns the primary key of this q u e r y_ m o d_ d e f a u l t s.
	*
	* @return the primary key of this q u e r y_ m o d_ d e f a u l t s
	*/
	@Override
	public int getPrimaryKey() {
		return _query_mod_defaults.getPrimaryKey();
	}

	/**
	* Sets the primary key of this q u e r y_ m o d_ d e f a u l t s.
	*
	* @param primaryKey the primary key of this q u e r y_ m o d_ d e f a u l t s
	*/
	@Override
	public void setPrimaryKey(int primaryKey) {
		_query_mod_defaults.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the q u e r y_ m o d_ d e f a u l t s_ i d of this q u e r y_ m o d_ d e f a u l t s.
	*
	* @return the q u e r y_ m o d_ d e f a u l t s_ i d of this q u e r y_ m o d_ d e f a u l t s
	*/
	@Override
	public int getQUERY_MOD_DEFAULTS_ID() {
		return _query_mod_defaults.getQUERY_MOD_DEFAULTS_ID();
	}

	/**
	* Sets the q u e r y_ m o d_ d e f a u l t s_ i d of this q u e r y_ m o d_ d e f a u l t s.
	*
	* @param QUERY_MOD_DEFAULTS_ID the q u e r y_ m o d_ d e f a u l t s_ i d of this q u e r y_ m o d_ d e f a u l t s
	*/
	@Override
	public void setQUERY_MOD_DEFAULTS_ID(int QUERY_MOD_DEFAULTS_ID) {
		_query_mod_defaults.setQUERY_MOD_DEFAULTS_ID(QUERY_MOD_DEFAULTS_ID);
	}

	/**
	* Returns the c u r r_ v a l of this q u e r y_ m o d_ d e f a u l t s.
	*
	* @return the c u r r_ v a l of this q u e r y_ m o d_ d e f a u l t s
	*/
	@Override
	public java.lang.String getCURR_VAL() {
		return _query_mod_defaults.getCURR_VAL();
	}

	/**
	* Sets the c u r r_ v a l of this q u e r y_ m o d_ d e f a u l t s.
	*
	* @param CURR_VAL the c u r r_ v a l of this q u e r y_ m o d_ d e f a u l t s
	*/
	@Override
	public void setCURR_VAL(java.lang.String CURR_VAL) {
		_query_mod_defaults.setCURR_VAL(CURR_VAL);
	}

	/**
	* Returns the n e w_ v a l of this q u e r y_ m o d_ d e f a u l t s.
	*
	* @return the n e w_ v a l of this q u e r y_ m o d_ d e f a u l t s
	*/
	@Override
	public java.lang.String getNEW_VAL() {
		return _query_mod_defaults.getNEW_VAL();
	}

	/**
	* Sets the n e w_ v a l of this q u e r y_ m o d_ d e f a u l t s.
	*
	* @param NEW_VAL the n e w_ v a l of this q u e r y_ m o d_ d e f a u l t s
	*/
	@Override
	public void setNEW_VAL(java.lang.String NEW_VAL) {
		_query_mod_defaults.setNEW_VAL(NEW_VAL);
	}

	/**
	* Returns the i s_ a c t i v e of this q u e r y_ m o d_ d e f a u l t s.
	*
	* @return the i s_ a c t i v e of this q u e r y_ m o d_ d e f a u l t s
	*/
	@Override
	public int getIS_ACTIVE() {
		return _query_mod_defaults.getIS_ACTIVE();
	}

	/**
	* Sets the i s_ a c t i v e of this q u e r y_ m o d_ d e f a u l t s.
	*
	* @param IS_ACTIVE the i s_ a c t i v e of this q u e r y_ m o d_ d e f a u l t s
	*/
	@Override
	public void setIS_ACTIVE(int IS_ACTIVE) {
		_query_mod_defaults.setIS_ACTIVE(IS_ACTIVE);
	}

	/**
	* Returns the u p d a t e d_ t i m e s t a m p of this q u e r y_ m o d_ d e f a u l t s.
	*
	* @return the u p d a t e d_ t i m e s t a m p of this q u e r y_ m o d_ d e f a u l t s
	*/
	@Override
	public java.util.Date getUPDATED_TIMESTAMP() {
		return _query_mod_defaults.getUPDATED_TIMESTAMP();
	}

	/**
	* Sets the u p d a t e d_ t i m e s t a m p of this q u e r y_ m o d_ d e f a u l t s.
	*
	* @param UPDATED_TIMESTAMP the u p d a t e d_ t i m e s t a m p of this q u e r y_ m o d_ d e f a u l t s
	*/
	@Override
	public void setUPDATED_TIMESTAMP(java.util.Date UPDATED_TIMESTAMP) {
		_query_mod_defaults.setUPDATED_TIMESTAMP(UPDATED_TIMESTAMP);
	}

	/**
	* Returns the t y p e of this q u e r y_ m o d_ d e f a u l t s.
	*
	* @return the t y p e of this q u e r y_ m o d_ d e f a u l t s
	*/
	@Override
	public java.lang.String getTYPE() {
		return _query_mod_defaults.getTYPE();
	}

	/**
	* Sets the t y p e of this q u e r y_ m o d_ d e f a u l t s.
	*
	* @param TYPE the t y p e of this q u e r y_ m o d_ d e f a u l t s
	*/
	@Override
	public void setTYPE(java.lang.String TYPE) {
		_query_mod_defaults.setTYPE(TYPE);
	}

	/**
	* Returns the c u r r_ l e v e l of this q u e r y_ m o d_ d e f a u l t s.
	*
	* @return the c u r r_ l e v e l of this q u e r y_ m o d_ d e f a u l t s
	*/
	@Override
	public int getCURR_LEVEL() {
		return _query_mod_defaults.getCURR_LEVEL();
	}

	/**
	* Sets the c u r r_ l e v e l of this q u e r y_ m o d_ d e f a u l t s.
	*
	* @param CURR_LEVEL the c u r r_ l e v e l of this q u e r y_ m o d_ d e f a u l t s
	*/
	@Override
	public void setCURR_LEVEL(int CURR_LEVEL) {
		_query_mod_defaults.setCURR_LEVEL(CURR_LEVEL);
	}

	@Override
	public boolean isNew() {
		return _query_mod_defaults.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_query_mod_defaults.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _query_mod_defaults.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_query_mod_defaults.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _query_mod_defaults.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _query_mod_defaults.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_query_mod_defaults.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _query_mod_defaults.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_query_mod_defaults.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_query_mod_defaults.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_query_mod_defaults.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new QUERY_MOD_DEFAULTSWrapper((QUERY_MOD_DEFAULTS)_query_mod_defaults.clone());
	}

	@Override
	public int compareTo(
		com.jioc.query.model.QUERY_MOD_DEFAULTS query_mod_defaults) {
		return _query_mod_defaults.compareTo(query_mod_defaults);
	}

	@Override
	public int hashCode() {
		return _query_mod_defaults.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jioc.query.model.QUERY_MOD_DEFAULTS> toCacheModel() {
		return _query_mod_defaults.toCacheModel();
	}

	@Override
	public com.jioc.query.model.QUERY_MOD_DEFAULTS toEscapedModel() {
		return new QUERY_MOD_DEFAULTSWrapper(_query_mod_defaults.toEscapedModel());
	}

	@Override
	public com.jioc.query.model.QUERY_MOD_DEFAULTS toUnescapedModel() {
		return new QUERY_MOD_DEFAULTSWrapper(_query_mod_defaults.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _query_mod_defaults.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _query_mod_defaults.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_query_mod_defaults.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof QUERY_MOD_DEFAULTSWrapper)) {
			return false;
		}

		QUERY_MOD_DEFAULTSWrapper query_mod_defaultsWrapper = (QUERY_MOD_DEFAULTSWrapper)obj;

		if (Validator.equals(_query_mod_defaults,
					query_mod_defaultsWrapper._query_mod_defaults)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public QUERY_MOD_DEFAULTS getWrappedQUERY_MOD_DEFAULTS() {
		return _query_mod_defaults;
	}

	@Override
	public QUERY_MOD_DEFAULTS getWrappedModel() {
		return _query_mod_defaults;
	}

	@Override
	public void resetOriginalValues() {
		_query_mod_defaults.resetOriginalValues();
	}

	private QUERY_MOD_DEFAULTS _query_mod_defaults;
}