/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

/**
 * @author shantaram.chavan
 */
public interface EMP_DETAILSFinder {
	public long findResolverByRR(java.lang.String region,
		java.lang.String state, java.lang.String oc, java.lang.String jioType,
		int resolverLevel);

	public void updateEmpDetails();

	public java.util.List<com.jioc.query.model.EMP_DETAILS> searchAssignees(
		java.lang.String region, java.lang.String circle,
		java.lang.String area, java.lang.String center, java.lang.String job);

	public java.util.List<java.lang.String> getSearchJobByAreaCircleRegionJioCenterAndOc(
		java.lang.String region, java.lang.String circle,
		java.lang.String area, java.lang.String center);
}