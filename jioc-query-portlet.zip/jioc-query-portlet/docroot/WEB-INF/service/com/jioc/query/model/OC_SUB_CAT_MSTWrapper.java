/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link OC_SUB_CAT_MST}.
 * </p>
 *
 * @author shantaram.chavan
 * @see OC_SUB_CAT_MST
 * @generated
 */
public class OC_SUB_CAT_MSTWrapper implements OC_SUB_CAT_MST,
	ModelWrapper<OC_SUB_CAT_MST> {
	public OC_SUB_CAT_MSTWrapper(OC_SUB_CAT_MST oc_sub_cat_mst) {
		_oc_sub_cat_mst = oc_sub_cat_mst;
	}

	@Override
	public Class<?> getModelClass() {
		return OC_SUB_CAT_MST.class;
	}

	@Override
	public String getModelClassName() {
		return OC_SUB_CAT_MST.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("SUB_CAT_ID", getSUB_CAT_ID());
		attributes.put("CAT_ID", getCAT_ID());
		attributes.put("IS_ACTIVE", getIS_ACTIVE());
		attributes.put("SUB_CAT_NAME", getSUB_CAT_NAME());
		attributes.put("UPDATED_TIMESTAMP", getUPDATED_TIMESTAMP());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long SUB_CAT_ID = (Long)attributes.get("SUB_CAT_ID");

		if (SUB_CAT_ID != null) {
			setSUB_CAT_ID(SUB_CAT_ID);
		}

		Long CAT_ID = (Long)attributes.get("CAT_ID");

		if (CAT_ID != null) {
			setCAT_ID(CAT_ID);
		}

		Integer IS_ACTIVE = (Integer)attributes.get("IS_ACTIVE");

		if (IS_ACTIVE != null) {
			setIS_ACTIVE(IS_ACTIVE);
		}

		String SUB_CAT_NAME = (String)attributes.get("SUB_CAT_NAME");

		if (SUB_CAT_NAME != null) {
			setSUB_CAT_NAME(SUB_CAT_NAME);
		}

		Date UPDATED_TIMESTAMP = (Date)attributes.get("UPDATED_TIMESTAMP");

		if (UPDATED_TIMESTAMP != null) {
			setUPDATED_TIMESTAMP(UPDATED_TIMESTAMP);
		}
	}

	/**
	* Returns the primary key of this o c_ s u b_ c a t_ m s t.
	*
	* @return the primary key of this o c_ s u b_ c a t_ m s t
	*/
	@Override
	public long getPrimaryKey() {
		return _oc_sub_cat_mst.getPrimaryKey();
	}

	/**
	* Sets the primary key of this o c_ s u b_ c a t_ m s t.
	*
	* @param primaryKey the primary key of this o c_ s u b_ c a t_ m s t
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_oc_sub_cat_mst.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the s u b_ c a t_ i d of this o c_ s u b_ c a t_ m s t.
	*
	* @return the s u b_ c a t_ i d of this o c_ s u b_ c a t_ m s t
	*/
	@Override
	public long getSUB_CAT_ID() {
		return _oc_sub_cat_mst.getSUB_CAT_ID();
	}

	/**
	* Sets the s u b_ c a t_ i d of this o c_ s u b_ c a t_ m s t.
	*
	* @param SUB_CAT_ID the s u b_ c a t_ i d of this o c_ s u b_ c a t_ m s t
	*/
	@Override
	public void setSUB_CAT_ID(long SUB_CAT_ID) {
		_oc_sub_cat_mst.setSUB_CAT_ID(SUB_CAT_ID);
	}

	/**
	* Returns the c a t_ i d of this o c_ s u b_ c a t_ m s t.
	*
	* @return the c a t_ i d of this o c_ s u b_ c a t_ m s t
	*/
	@Override
	public long getCAT_ID() {
		return _oc_sub_cat_mst.getCAT_ID();
	}

	/**
	* Sets the c a t_ i d of this o c_ s u b_ c a t_ m s t.
	*
	* @param CAT_ID the c a t_ i d of this o c_ s u b_ c a t_ m s t
	*/
	@Override
	public void setCAT_ID(long CAT_ID) {
		_oc_sub_cat_mst.setCAT_ID(CAT_ID);
	}

	/**
	* Returns the i s_ a c t i v e of this o c_ s u b_ c a t_ m s t.
	*
	* @return the i s_ a c t i v e of this o c_ s u b_ c a t_ m s t
	*/
	@Override
	public int getIS_ACTIVE() {
		return _oc_sub_cat_mst.getIS_ACTIVE();
	}

	/**
	* Sets the i s_ a c t i v e of this o c_ s u b_ c a t_ m s t.
	*
	* @param IS_ACTIVE the i s_ a c t i v e of this o c_ s u b_ c a t_ m s t
	*/
	@Override
	public void setIS_ACTIVE(int IS_ACTIVE) {
		_oc_sub_cat_mst.setIS_ACTIVE(IS_ACTIVE);
	}

	/**
	* Returns the s u b_ c a t_ n a m e of this o c_ s u b_ c a t_ m s t.
	*
	* @return the s u b_ c a t_ n a m e of this o c_ s u b_ c a t_ m s t
	*/
	@Override
	public java.lang.String getSUB_CAT_NAME() {
		return _oc_sub_cat_mst.getSUB_CAT_NAME();
	}

	/**
	* Sets the s u b_ c a t_ n a m e of this o c_ s u b_ c a t_ m s t.
	*
	* @param SUB_CAT_NAME the s u b_ c a t_ n a m e of this o c_ s u b_ c a t_ m s t
	*/
	@Override
	public void setSUB_CAT_NAME(java.lang.String SUB_CAT_NAME) {
		_oc_sub_cat_mst.setSUB_CAT_NAME(SUB_CAT_NAME);
	}

	/**
	* Returns the u p d a t e d_ t i m e s t a m p of this o c_ s u b_ c a t_ m s t.
	*
	* @return the u p d a t e d_ t i m e s t a m p of this o c_ s u b_ c a t_ m s t
	*/
	@Override
	public java.util.Date getUPDATED_TIMESTAMP() {
		return _oc_sub_cat_mst.getUPDATED_TIMESTAMP();
	}

	/**
	* Sets the u p d a t e d_ t i m e s t a m p of this o c_ s u b_ c a t_ m s t.
	*
	* @param UPDATED_TIMESTAMP the u p d a t e d_ t i m e s t a m p of this o c_ s u b_ c a t_ m s t
	*/
	@Override
	public void setUPDATED_TIMESTAMP(java.util.Date UPDATED_TIMESTAMP) {
		_oc_sub_cat_mst.setUPDATED_TIMESTAMP(UPDATED_TIMESTAMP);
	}

	@Override
	public boolean isNew() {
		return _oc_sub_cat_mst.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_oc_sub_cat_mst.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _oc_sub_cat_mst.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_oc_sub_cat_mst.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _oc_sub_cat_mst.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _oc_sub_cat_mst.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_oc_sub_cat_mst.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _oc_sub_cat_mst.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_oc_sub_cat_mst.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_oc_sub_cat_mst.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_oc_sub_cat_mst.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new OC_SUB_CAT_MSTWrapper((OC_SUB_CAT_MST)_oc_sub_cat_mst.clone());
	}

	@Override
	public int compareTo(com.jioc.query.model.OC_SUB_CAT_MST oc_sub_cat_mst) {
		return _oc_sub_cat_mst.compareTo(oc_sub_cat_mst);
	}

	@Override
	public int hashCode() {
		return _oc_sub_cat_mst.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jioc.query.model.OC_SUB_CAT_MST> toCacheModel() {
		return _oc_sub_cat_mst.toCacheModel();
	}

	@Override
	public com.jioc.query.model.OC_SUB_CAT_MST toEscapedModel() {
		return new OC_SUB_CAT_MSTWrapper(_oc_sub_cat_mst.toEscapedModel());
	}

	@Override
	public com.jioc.query.model.OC_SUB_CAT_MST toUnescapedModel() {
		return new OC_SUB_CAT_MSTWrapper(_oc_sub_cat_mst.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _oc_sub_cat_mst.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _oc_sub_cat_mst.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_oc_sub_cat_mst.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof OC_SUB_CAT_MSTWrapper)) {
			return false;
		}

		OC_SUB_CAT_MSTWrapper oc_sub_cat_mstWrapper = (OC_SUB_CAT_MSTWrapper)obj;

		if (Validator.equals(_oc_sub_cat_mst,
					oc_sub_cat_mstWrapper._oc_sub_cat_mst)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public OC_SUB_CAT_MST getWrappedOC_SUB_CAT_MST() {
		return _oc_sub_cat_mst;
	}

	@Override
	public OC_SUB_CAT_MST getWrappedModel() {
		return _oc_sub_cat_mst;
	}

	@Override
	public void resetOriginalValues() {
		_oc_sub_cat_mst.resetOriginalValues();
	}

	private OC_SUB_CAT_MST _oc_sub_cat_mst;
}