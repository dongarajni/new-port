/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author shantaram.chavan
 * @generated
 */
public class Query_AttachmentsSoap implements Serializable {
	public static Query_AttachmentsSoap toSoapModel(Query_Attachments model) {
		Query_AttachmentsSoap soapModel = new Query_AttachmentsSoap();

		soapModel.setAttachmentId(model.getAttachmentId());
		soapModel.setFileEntryId(model.getFileEntryId());
		soapModel.setUpdatedBy(model.getUpdatedBy());
		soapModel.setUpdatedTimestamp(model.getUpdatedTimestamp());
		soapModel.setQueryId(model.getQueryId());
		soapModel.setFile_name(model.getFile_name());

		return soapModel;
	}

	public static Query_AttachmentsSoap[] toSoapModels(
		Query_Attachments[] models) {
		Query_AttachmentsSoap[] soapModels = new Query_AttachmentsSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static Query_AttachmentsSoap[][] toSoapModels(
		Query_Attachments[][] models) {
		Query_AttachmentsSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new Query_AttachmentsSoap[models.length][models[0].length];
		}
		else {
			soapModels = new Query_AttachmentsSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static Query_AttachmentsSoap[] toSoapModels(
		List<Query_Attachments> models) {
		List<Query_AttachmentsSoap> soapModels = new ArrayList<Query_AttachmentsSoap>(models.size());

		for (Query_Attachments model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new Query_AttachmentsSoap[soapModels.size()]);
	}

	public Query_AttachmentsSoap() {
	}

	public long getPrimaryKey() {
		return _AttachmentId;
	}

	public void setPrimaryKey(long pk) {
		setAttachmentId(pk);
	}

	public long getAttachmentId() {
		return _AttachmentId;
	}

	public void setAttachmentId(long AttachmentId) {
		_AttachmentId = AttachmentId;
	}

	public long getFileEntryId() {
		return _fileEntryId;
	}

	public void setFileEntryId(long fileEntryId) {
		_fileEntryId = fileEntryId;
	}

	public long getUpdatedBy() {
		return _updatedBy;
	}

	public void setUpdatedBy(long updatedBy) {
		_updatedBy = updatedBy;
	}

	public Date getUpdatedTimestamp() {
		return _updatedTimestamp;
	}

	public void setUpdatedTimestamp(Date updatedTimestamp) {
		_updatedTimestamp = updatedTimestamp;
	}

	public long getQueryId() {
		return _queryId;
	}

	public void setQueryId(long queryId) {
		_queryId = queryId;
	}

	public String getFile_name() {
		return _file_name;
	}

	public void setFile_name(String file_name) {
		_file_name = file_name;
	}

	private long _AttachmentId;
	private long _fileEntryId;
	private long _updatedBy;
	private Date _updatedTimestamp;
	private long _queryId;
	private String _file_name;
}