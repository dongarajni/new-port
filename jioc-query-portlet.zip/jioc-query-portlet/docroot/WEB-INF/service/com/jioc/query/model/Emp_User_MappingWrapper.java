/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Emp_User_Mapping}.
 * </p>
 *
 * @author shantaram.chavan
 * @see Emp_User_Mapping
 * @generated
 */
public class Emp_User_MappingWrapper implements Emp_User_Mapping,
	ModelWrapper<Emp_User_Mapping> {
	public Emp_User_MappingWrapper(Emp_User_Mapping emp_User_Mapping) {
		_emp_User_Mapping = emp_User_Mapping;
	}

	@Override
	public Class<?> getModelClass() {
		return Emp_User_Mapping.class;
	}

	@Override
	public String getModelClassName() {
		return Emp_User_Mapping.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("userId", getUserId());
		attributes.put("empId", getEmpId());
		attributes.put("emailId", getEmailId());
		attributes.put("domainId", getDomainId());
		attributes.put("samlFederationId", getSamlFederationId());
		attributes.put("status", getStatus());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String empId = (String)attributes.get("empId");

		if (empId != null) {
			setEmpId(empId);
		}

		String emailId = (String)attributes.get("emailId");

		if (emailId != null) {
			setEmailId(emailId);
		}

		String domainId = (String)attributes.get("domainId");

		if (domainId != null) {
			setDomainId(domainId);
		}

		String samlFederationId = (String)attributes.get("samlFederationId");

		if (samlFederationId != null) {
			setSamlFederationId(samlFederationId);
		}

		Integer status = (Integer)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}
	}

	/**
	* Returns the primary key of this emp_ user_ mapping.
	*
	* @return the primary key of this emp_ user_ mapping
	*/
	@Override
	public long getPrimaryKey() {
		return _emp_User_Mapping.getPrimaryKey();
	}

	/**
	* Sets the primary key of this emp_ user_ mapping.
	*
	* @param primaryKey the primary key of this emp_ user_ mapping
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_emp_User_Mapping.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the user ID of this emp_ user_ mapping.
	*
	* @return the user ID of this emp_ user_ mapping
	*/
	@Override
	public long getUserId() {
		return _emp_User_Mapping.getUserId();
	}

	/**
	* Sets the user ID of this emp_ user_ mapping.
	*
	* @param userId the user ID of this emp_ user_ mapping
	*/
	@Override
	public void setUserId(long userId) {
		_emp_User_Mapping.setUserId(userId);
	}

	/**
	* Returns the user uuid of this emp_ user_ mapping.
	*
	* @return the user uuid of this emp_ user_ mapping
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _emp_User_Mapping.getUserUuid();
	}

	/**
	* Sets the user uuid of this emp_ user_ mapping.
	*
	* @param userUuid the user uuid of this emp_ user_ mapping
	*/
	@Override
	public void setUserUuid(java.lang.String userUuid) {
		_emp_User_Mapping.setUserUuid(userUuid);
	}

	/**
	* Returns the emp ID of this emp_ user_ mapping.
	*
	* @return the emp ID of this emp_ user_ mapping
	*/
	@Override
	public java.lang.String getEmpId() {
		return _emp_User_Mapping.getEmpId();
	}

	/**
	* Sets the emp ID of this emp_ user_ mapping.
	*
	* @param empId the emp ID of this emp_ user_ mapping
	*/
	@Override
	public void setEmpId(java.lang.String empId) {
		_emp_User_Mapping.setEmpId(empId);
	}

	/**
	* Returns the email ID of this emp_ user_ mapping.
	*
	* @return the email ID of this emp_ user_ mapping
	*/
	@Override
	public java.lang.String getEmailId() {
		return _emp_User_Mapping.getEmailId();
	}

	/**
	* Sets the email ID of this emp_ user_ mapping.
	*
	* @param emailId the email ID of this emp_ user_ mapping
	*/
	@Override
	public void setEmailId(java.lang.String emailId) {
		_emp_User_Mapping.setEmailId(emailId);
	}

	/**
	* Returns the domain ID of this emp_ user_ mapping.
	*
	* @return the domain ID of this emp_ user_ mapping
	*/
	@Override
	public java.lang.String getDomainId() {
		return _emp_User_Mapping.getDomainId();
	}

	/**
	* Sets the domain ID of this emp_ user_ mapping.
	*
	* @param domainId the domain ID of this emp_ user_ mapping
	*/
	@Override
	public void setDomainId(java.lang.String domainId) {
		_emp_User_Mapping.setDomainId(domainId);
	}

	/**
	* Returns the saml federation ID of this emp_ user_ mapping.
	*
	* @return the saml federation ID of this emp_ user_ mapping
	*/
	@Override
	public java.lang.String getSamlFederationId() {
		return _emp_User_Mapping.getSamlFederationId();
	}

	/**
	* Sets the saml federation ID of this emp_ user_ mapping.
	*
	* @param samlFederationId the saml federation ID of this emp_ user_ mapping
	*/
	@Override
	public void setSamlFederationId(java.lang.String samlFederationId) {
		_emp_User_Mapping.setSamlFederationId(samlFederationId);
	}

	/**
	* Returns the status of this emp_ user_ mapping.
	*
	* @return the status of this emp_ user_ mapping
	*/
	@Override
	public int getStatus() {
		return _emp_User_Mapping.getStatus();
	}

	/**
	* Sets the status of this emp_ user_ mapping.
	*
	* @param status the status of this emp_ user_ mapping
	*/
	@Override
	public void setStatus(int status) {
		_emp_User_Mapping.setStatus(status);
	}

	@Override
	public boolean isNew() {
		return _emp_User_Mapping.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_emp_User_Mapping.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _emp_User_Mapping.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_emp_User_Mapping.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _emp_User_Mapping.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _emp_User_Mapping.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_emp_User_Mapping.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _emp_User_Mapping.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_emp_User_Mapping.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_emp_User_Mapping.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_emp_User_Mapping.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new Emp_User_MappingWrapper((Emp_User_Mapping)_emp_User_Mapping.clone());
	}

	@Override
	public int compareTo(com.jioc.query.model.Emp_User_Mapping emp_User_Mapping) {
		return _emp_User_Mapping.compareTo(emp_User_Mapping);
	}

	@Override
	public int hashCode() {
		return _emp_User_Mapping.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jioc.query.model.Emp_User_Mapping> toCacheModel() {
		return _emp_User_Mapping.toCacheModel();
	}

	@Override
	public com.jioc.query.model.Emp_User_Mapping toEscapedModel() {
		return new Emp_User_MappingWrapper(_emp_User_Mapping.toEscapedModel());
	}

	@Override
	public com.jioc.query.model.Emp_User_Mapping toUnescapedModel() {
		return new Emp_User_MappingWrapper(_emp_User_Mapping.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _emp_User_Mapping.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _emp_User_Mapping.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_emp_User_Mapping.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof Emp_User_MappingWrapper)) {
			return false;
		}

		Emp_User_MappingWrapper emp_User_MappingWrapper = (Emp_User_MappingWrapper)obj;

		if (Validator.equals(_emp_User_Mapping,
					emp_User_MappingWrapper._emp_User_Mapping)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public Emp_User_Mapping getWrappedEmp_User_Mapping() {
		return _emp_User_Mapping;
	}

	@Override
	public Emp_User_Mapping getWrappedModel() {
		return _emp_User_Mapping;
	}

	@Override
	public void resetOriginalValues() {
		_emp_User_Mapping.resetOriginalValues();
	}

	private Emp_User_Mapping _emp_User_Mapping;
}