/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.jioc.query.service.ClpSerializer;
import com.jioc.query.service.OC_CAT_MSTLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author shantaram.chavan
 */
public class OC_CAT_MSTClp extends BaseModelImpl<OC_CAT_MST>
	implements OC_CAT_MST {
	public OC_CAT_MSTClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return OC_CAT_MST.class;
	}

	@Override
	public String getModelClassName() {
		return OC_CAT_MST.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _CAT_ID;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setCAT_ID(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _CAT_ID;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("CAT_ID", getCAT_ID());
		attributes.put("CAT_NAME", getCAT_NAME());
		attributes.put("HPSM_GROUP", getHPSM_GROUP());
		attributes.put("IS_ACTIVE", getIS_ACTIVE());
		attributes.put("OC", getOC());
		attributes.put("RESOLVER_LEVEL", getRESOLVER_LEVEL());
		attributes.put("UPDATED_TIMESTAMP", getUPDATED_TIMESTAMP());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long CAT_ID = (Long)attributes.get("CAT_ID");

		if (CAT_ID != null) {
			setCAT_ID(CAT_ID);
		}

		String CAT_NAME = (String)attributes.get("CAT_NAME");

		if (CAT_NAME != null) {
			setCAT_NAME(CAT_NAME);
		}

		String HPSM_GROUP = (String)attributes.get("HPSM_GROUP");

		if (HPSM_GROUP != null) {
			setHPSM_GROUP(HPSM_GROUP);
		}

		Integer IS_ACTIVE = (Integer)attributes.get("IS_ACTIVE");

		if (IS_ACTIVE != null) {
			setIS_ACTIVE(IS_ACTIVE);
		}

		String OC = (String)attributes.get("OC");

		if (OC != null) {
			setOC(OC);
		}

		Integer RESOLVER_LEVEL = (Integer)attributes.get("RESOLVER_LEVEL");

		if (RESOLVER_LEVEL != null) {
			setRESOLVER_LEVEL(RESOLVER_LEVEL);
		}

		Date UPDATED_TIMESTAMP = (Date)attributes.get("UPDATED_TIMESTAMP");

		if (UPDATED_TIMESTAMP != null) {
			setUPDATED_TIMESTAMP(UPDATED_TIMESTAMP);
		}
	}

	@Override
	public long getCAT_ID() {
		return _CAT_ID;
	}

	@Override
	public void setCAT_ID(long CAT_ID) {
		_CAT_ID = CAT_ID;

		if (_oc_cat_mstRemoteModel != null) {
			try {
				Class<?> clazz = _oc_cat_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setCAT_ID", long.class);

				method.invoke(_oc_cat_mstRemoteModel, CAT_ID);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCAT_NAME() {
		return _CAT_NAME;
	}

	@Override
	public void setCAT_NAME(String CAT_NAME) {
		_CAT_NAME = CAT_NAME;

		if (_oc_cat_mstRemoteModel != null) {
			try {
				Class<?> clazz = _oc_cat_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setCAT_NAME", String.class);

				method.invoke(_oc_cat_mstRemoteModel, CAT_NAME);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getHPSM_GROUP() {
		return _HPSM_GROUP;
	}

	@Override
	public void setHPSM_GROUP(String HPSM_GROUP) {
		_HPSM_GROUP = HPSM_GROUP;

		if (_oc_cat_mstRemoteModel != null) {
			try {
				Class<?> clazz = _oc_cat_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setHPSM_GROUP", String.class);

				method.invoke(_oc_cat_mstRemoteModel, HPSM_GROUP);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getIS_ACTIVE() {
		return _IS_ACTIVE;
	}

	@Override
	public void setIS_ACTIVE(int IS_ACTIVE) {
		_IS_ACTIVE = IS_ACTIVE;

		if (_oc_cat_mstRemoteModel != null) {
			try {
				Class<?> clazz = _oc_cat_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setIS_ACTIVE", int.class);

				method.invoke(_oc_cat_mstRemoteModel, IS_ACTIVE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOC() {
		return _OC;
	}

	@Override
	public void setOC(String OC) {
		_OC = OC;

		if (_oc_cat_mstRemoteModel != null) {
			try {
				Class<?> clazz = _oc_cat_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setOC", String.class);

				method.invoke(_oc_cat_mstRemoteModel, OC);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getRESOLVER_LEVEL() {
		return _RESOLVER_LEVEL;
	}

	@Override
	public void setRESOLVER_LEVEL(int RESOLVER_LEVEL) {
		_RESOLVER_LEVEL = RESOLVER_LEVEL;

		if (_oc_cat_mstRemoteModel != null) {
			try {
				Class<?> clazz = _oc_cat_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setRESOLVER_LEVEL", int.class);

				method.invoke(_oc_cat_mstRemoteModel, RESOLVER_LEVEL);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getUPDATED_TIMESTAMP() {
		return _UPDATED_TIMESTAMP;
	}

	@Override
	public void setUPDATED_TIMESTAMP(Date UPDATED_TIMESTAMP) {
		_UPDATED_TIMESTAMP = UPDATED_TIMESTAMP;

		if (_oc_cat_mstRemoteModel != null) {
			try {
				Class<?> clazz = _oc_cat_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setUPDATED_TIMESTAMP",
						Date.class);

				method.invoke(_oc_cat_mstRemoteModel, UPDATED_TIMESTAMP);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getOC_CAT_MSTRemoteModel() {
		return _oc_cat_mstRemoteModel;
	}

	public void setOC_CAT_MSTRemoteModel(BaseModel<?> oc_cat_mstRemoteModel) {
		_oc_cat_mstRemoteModel = oc_cat_mstRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _oc_cat_mstRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_oc_cat_mstRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			OC_CAT_MSTLocalServiceUtil.addOC_CAT_MST(this);
		}
		else {
			OC_CAT_MSTLocalServiceUtil.updateOC_CAT_MST(this);
		}
	}

	@Override
	public OC_CAT_MST toEscapedModel() {
		return (OC_CAT_MST)ProxyUtil.newProxyInstance(OC_CAT_MST.class.getClassLoader(),
			new Class[] { OC_CAT_MST.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		OC_CAT_MSTClp clone = new OC_CAT_MSTClp();

		clone.setCAT_ID(getCAT_ID());
		clone.setCAT_NAME(getCAT_NAME());
		clone.setHPSM_GROUP(getHPSM_GROUP());
		clone.setIS_ACTIVE(getIS_ACTIVE());
		clone.setOC(getOC());
		clone.setRESOLVER_LEVEL(getRESOLVER_LEVEL());
		clone.setUPDATED_TIMESTAMP(getUPDATED_TIMESTAMP());

		return clone;
	}

	@Override
	public int compareTo(OC_CAT_MST oc_cat_mst) {
		long primaryKey = oc_cat_mst.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof OC_CAT_MSTClp)) {
			return false;
		}

		OC_CAT_MSTClp oc_cat_mst = (OC_CAT_MSTClp)obj;

		long primaryKey = oc_cat_mst.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(15);

		sb.append("{CAT_ID=");
		sb.append(getCAT_ID());
		sb.append(", CAT_NAME=");
		sb.append(getCAT_NAME());
		sb.append(", HPSM_GROUP=");
		sb.append(getHPSM_GROUP());
		sb.append(", IS_ACTIVE=");
		sb.append(getIS_ACTIVE());
		sb.append(", OC=");
		sb.append(getOC());
		sb.append(", RESOLVER_LEVEL=");
		sb.append(getRESOLVER_LEVEL());
		sb.append(", UPDATED_TIMESTAMP=");
		sb.append(getUPDATED_TIMESTAMP());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(25);

		sb.append("<model><model-name>");
		sb.append("com.jioc.query.model.OC_CAT_MST");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>CAT_ID</column-name><column-value><![CDATA[");
		sb.append(getCAT_ID());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>CAT_NAME</column-name><column-value><![CDATA[");
		sb.append(getCAT_NAME());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>HPSM_GROUP</column-name><column-value><![CDATA[");
		sb.append(getHPSM_GROUP());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>IS_ACTIVE</column-name><column-value><![CDATA[");
		sb.append(getIS_ACTIVE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>OC</column-name><column-value><![CDATA[");
		sb.append(getOC());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>RESOLVER_LEVEL</column-name><column-value><![CDATA[");
		sb.append(getRESOLVER_LEVEL());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>UPDATED_TIMESTAMP</column-name><column-value><![CDATA[");
		sb.append(getUPDATED_TIMESTAMP());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _CAT_ID;
	private String _CAT_NAME;
	private String _HPSM_GROUP;
	private int _IS_ACTIVE;
	private String _OC;
	private int _RESOLVER_LEVEL;
	private Date _UPDATED_TIMESTAMP;
	private BaseModel<?> _oc_cat_mstRemoteModel;
	private Class<?> _clpSerializerClass = com.jioc.query.service.ClpSerializer.class;
}