/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author shantaram.chavan
 * @generated
 */
public class Emp_User_MappingSoap implements Serializable {
	public static Emp_User_MappingSoap toSoapModel(Emp_User_Mapping model) {
		Emp_User_MappingSoap soapModel = new Emp_User_MappingSoap();

		soapModel.setUserId(model.getUserId());
		soapModel.setEmpId(model.getEmpId());
		soapModel.setEmailId(model.getEmailId());
		soapModel.setDomainId(model.getDomainId());
		soapModel.setSamlFederationId(model.getSamlFederationId());
		soapModel.setStatus(model.getStatus());

		return soapModel;
	}

	public static Emp_User_MappingSoap[] toSoapModels(Emp_User_Mapping[] models) {
		Emp_User_MappingSoap[] soapModels = new Emp_User_MappingSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static Emp_User_MappingSoap[][] toSoapModels(
		Emp_User_Mapping[][] models) {
		Emp_User_MappingSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new Emp_User_MappingSoap[models.length][models[0].length];
		}
		else {
			soapModels = new Emp_User_MappingSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static Emp_User_MappingSoap[] toSoapModels(
		List<Emp_User_Mapping> models) {
		List<Emp_User_MappingSoap> soapModels = new ArrayList<Emp_User_MappingSoap>(models.size());

		for (Emp_User_Mapping model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new Emp_User_MappingSoap[soapModels.size()]);
	}

	public Emp_User_MappingSoap() {
	}

	public long getPrimaryKey() {
		return _userId;
	}

	public void setPrimaryKey(long pk) {
		setUserId(pk);
	}

	public long getUserId() {
		return _userId;
	}

	public void setUserId(long userId) {
		_userId = userId;
	}

	public String getEmpId() {
		return _empId;
	}

	public void setEmpId(String empId) {
		_empId = empId;
	}

	public String getEmailId() {
		return _emailId;
	}

	public void setEmailId(String emailId) {
		_emailId = emailId;
	}

	public String getDomainId() {
		return _domainId;
	}

	public void setDomainId(String domainId) {
		_domainId = domainId;
	}

	public String getSamlFederationId() {
		return _samlFederationId;
	}

	public void setSamlFederationId(String samlFederationId) {
		_samlFederationId = samlFederationId;
	}

	public int getStatus() {
		return _status;
	}

	public void setStatus(int status) {
		_status = status;
	}

	private long _userId;
	private String _empId;
	private String _emailId;
	private String _domainId;
	private String _samlFederationId;
	private int _status;
}