/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author shantaram.chavan
 * @generated
 */
public class Query_Add_Param_OCSoap implements Serializable {
	public static Query_Add_Param_OCSoap toSoapModel(Query_Add_Param_OC model) {
		Query_Add_Param_OCSoap soapModel = new Query_Add_Param_OCSoap();

		soapModel.setQueryAddParamOCId(model.getQueryAddParamOCId());
		soapModel.setOC(model.getOC());
		soapModel.setStatus(model.getStatus());
		soapModel.setUpdatedTimestamp(model.getUpdatedTimestamp());

		return soapModel;
	}

	public static Query_Add_Param_OCSoap[] toSoapModels(
		Query_Add_Param_OC[] models) {
		Query_Add_Param_OCSoap[] soapModels = new Query_Add_Param_OCSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static Query_Add_Param_OCSoap[][] toSoapModels(
		Query_Add_Param_OC[][] models) {
		Query_Add_Param_OCSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new Query_Add_Param_OCSoap[models.length][models[0].length];
		}
		else {
			soapModels = new Query_Add_Param_OCSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static Query_Add_Param_OCSoap[] toSoapModels(
		List<Query_Add_Param_OC> models) {
		List<Query_Add_Param_OCSoap> soapModels = new ArrayList<Query_Add_Param_OCSoap>(models.size());

		for (Query_Add_Param_OC model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new Query_Add_Param_OCSoap[soapModels.size()]);
	}

	public Query_Add_Param_OCSoap() {
	}

	public long getPrimaryKey() {
		return _queryAddParamOCId;
	}

	public void setPrimaryKey(long pk) {
		setQueryAddParamOCId(pk);
	}

	public long getQueryAddParamOCId() {
		return _queryAddParamOCId;
	}

	public void setQueryAddParamOCId(long queryAddParamOCId) {
		_queryAddParamOCId = queryAddParamOCId;
	}

	public String getOC() {
		return _OC;
	}

	public void setOC(String OC) {
		_OC = OC;
	}

	public int getStatus() {
		return _status;
	}

	public void setStatus(int status) {
		_status = status;
	}

	public Date getUpdatedTimestamp() {
		return _updatedTimestamp;
	}

	public void setUpdatedTimestamp(Date updatedTimestamp) {
		_updatedTimestamp = updatedTimestamp;
	}

	private long _queryAddParamOCId;
	private String _OC;
	private int _status;
	private Date _updatedTimestamp;
}