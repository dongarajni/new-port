/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.jioc.query.service.ClpSerializer;
import com.jioc.query.service.Query_TransactionLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author shantaram.chavan
 */
public class Query_TransactionClp extends BaseModelImpl<Query_Transaction>
	implements Query_Transaction {
	public Query_TransactionClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return Query_Transaction.class;
	}

	@Override
	public String getModelClassName() {
		return Query_Transaction.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _queryId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setQueryId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _queryId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("queryId", getQueryId());
		attributes.put("caseNo", getCaseNo());
		attributes.put("description", getDescription());
		attributes.put("raisedTimestamp", getRaisedTimestamp());
		attributes.put("raisedById", getRaisedById());
		attributes.put("toDisplay", getToDisplay());
		attributes.put("orn_no", getOrn_no());
		attributes.put("caf_no", getCaf_no());
		attributes.put("customer_MSISDN", getCustomer_MSISDN());
		attributes.put("amt_request", getAmt_request());
		attributes.put("amt_done", getAmt_done());
		attributes.put("raised_by_email", getRaised_by_email());
		attributes.put("pcId", getPcId());
		attributes.put("ack", getAck());
		attributes.put("source", getSource());
		attributes.put("ack_timestamp", getAck_timestamp());
		attributes.put("assignment_group", getAssignment_group());
		attributes.put("ISACTIVE", getISACTIVE());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long queryId = (Long)attributes.get("queryId");

		if (queryId != null) {
			setQueryId(queryId);
		}

		String caseNo = (String)attributes.get("caseNo");

		if (caseNo != null) {
			setCaseNo(caseNo);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}

		Date raisedTimestamp = (Date)attributes.get("raisedTimestamp");

		if (raisedTimestamp != null) {
			setRaisedTimestamp(raisedTimestamp);
		}

		Long raisedById = (Long)attributes.get("raisedById");

		if (raisedById != null) {
			setRaisedById(raisedById);
		}

		Integer toDisplay = (Integer)attributes.get("toDisplay");

		if (toDisplay != null) {
			setToDisplay(toDisplay);
		}

		String orn_no = (String)attributes.get("orn_no");

		if (orn_no != null) {
			setOrn_no(orn_no);
		}

		String caf_no = (String)attributes.get("caf_no");

		if (caf_no != null) {
			setCaf_no(caf_no);
		}

		String customer_MSISDN = (String)attributes.get("customer_MSISDN");

		if (customer_MSISDN != null) {
			setCustomer_MSISDN(customer_MSISDN);
		}

		Long amt_request = (Long)attributes.get("amt_request");

		if (amt_request != null) {
			setAmt_request(amt_request);
		}

		Long amt_done = (Long)attributes.get("amt_done");

		if (amt_done != null) {
			setAmt_done(amt_done);
		}

		String raised_by_email = (String)attributes.get("raised_by_email");

		if (raised_by_email != null) {
			setRaised_by_email(raised_by_email);
		}

		String pcId = (String)attributes.get("pcId");

		if (pcId != null) {
			setPcId(pcId);
		}

		Integer ack = (Integer)attributes.get("ack");

		if (ack != null) {
			setAck(ack);
		}

		String source = (String)attributes.get("source");

		if (source != null) {
			setSource(source);
		}

		Date ack_timestamp = (Date)attributes.get("ack_timestamp");

		if (ack_timestamp != null) {
			setAck_timestamp(ack_timestamp);
		}

		String assignment_group = (String)attributes.get("assignment_group");

		if (assignment_group != null) {
			setAssignment_group(assignment_group);
		}

		Integer ISACTIVE = (Integer)attributes.get("ISACTIVE");

		if (ISACTIVE != null) {
			setISACTIVE(ISACTIVE);
		}
	}

	@Override
	public long getQueryId() {
		return _queryId;
	}

	@Override
	public void setQueryId(long queryId) {
		_queryId = queryId;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setQueryId", long.class);

				method.invoke(_query_TransactionRemoteModel, queryId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCaseNo() {
		return _caseNo;
	}

	@Override
	public void setCaseNo(String caseNo) {
		_caseNo = caseNo;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setCaseNo", String.class);

				method.invoke(_query_TransactionRemoteModel, caseNo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDescription() {
		return _description;
	}

	@Override
	public void setDescription(String description) {
		_description = description;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setDescription", String.class);

				method.invoke(_query_TransactionRemoteModel, description);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getRaisedTimestamp() {
		return _raisedTimestamp;
	}

	@Override
	public void setRaisedTimestamp(Date raisedTimestamp) {
		_raisedTimestamp = raisedTimestamp;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setRaisedTimestamp", Date.class);

				method.invoke(_query_TransactionRemoteModel, raisedTimestamp);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getRaisedById() {
		return _raisedById;
	}

	@Override
	public void setRaisedById(long raisedById) {
		_raisedById = raisedById;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setRaisedById", long.class);

				method.invoke(_query_TransactionRemoteModel, raisedById);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getToDisplay() {
		return _toDisplay;
	}

	@Override
	public void setToDisplay(int toDisplay) {
		_toDisplay = toDisplay;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setToDisplay", int.class);

				method.invoke(_query_TransactionRemoteModel, toDisplay);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOrn_no() {
		return _orn_no;
	}

	@Override
	public void setOrn_no(String orn_no) {
		_orn_no = orn_no;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setOrn_no", String.class);

				method.invoke(_query_TransactionRemoteModel, orn_no);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCaf_no() {
		return _caf_no;
	}

	@Override
	public void setCaf_no(String caf_no) {
		_caf_no = caf_no;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setCaf_no", String.class);

				method.invoke(_query_TransactionRemoteModel, caf_no);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCustomer_MSISDN() {
		return _customer_MSISDN;
	}

	@Override
	public void setCustomer_MSISDN(String customer_MSISDN) {
		_customer_MSISDN = customer_MSISDN;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setCustomer_MSISDN",
						String.class);

				method.invoke(_query_TransactionRemoteModel, customer_MSISDN);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getAmt_request() {
		return _amt_request;
	}

	@Override
	public void setAmt_request(long amt_request) {
		_amt_request = amt_request;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setAmt_request", long.class);

				method.invoke(_query_TransactionRemoteModel, amt_request);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getAmt_done() {
		return _amt_done;
	}

	@Override
	public void setAmt_done(long amt_done) {
		_amt_done = amt_done;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setAmt_done", long.class);

				method.invoke(_query_TransactionRemoteModel, amt_done);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRaised_by_email() {
		return _raised_by_email;
	}

	@Override
	public void setRaised_by_email(String raised_by_email) {
		_raised_by_email = raised_by_email;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setRaised_by_email",
						String.class);

				method.invoke(_query_TransactionRemoteModel, raised_by_email);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getPcId() {
		return _pcId;
	}

	@Override
	public void setPcId(String pcId) {
		_pcId = pcId;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setPcId", String.class);

				method.invoke(_query_TransactionRemoteModel, pcId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getAck() {
		return _ack;
	}

	@Override
	public void setAck(int ack) {
		_ack = ack;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setAck", int.class);

				method.invoke(_query_TransactionRemoteModel, ack);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSource() {
		return _source;
	}

	@Override
	public void setSource(String source) {
		_source = source;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setSource", String.class);

				method.invoke(_query_TransactionRemoteModel, source);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getAck_timestamp() {
		return _ack_timestamp;
	}

	@Override
	public void setAck_timestamp(Date ack_timestamp) {
		_ack_timestamp = ack_timestamp;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setAck_timestamp", Date.class);

				method.invoke(_query_TransactionRemoteModel, ack_timestamp);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAssignment_group() {
		return _assignment_group;
	}

	@Override
	public void setAssignment_group(String assignment_group) {
		_assignment_group = assignment_group;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setAssignment_group",
						String.class);

				method.invoke(_query_TransactionRemoteModel, assignment_group);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getISACTIVE() {
		return _ISACTIVE;
	}

	@Override
	public void setISACTIVE(int ISACTIVE) {
		_ISACTIVE = ISACTIVE;

		if (_query_TransactionRemoteModel != null) {
			try {
				Class<?> clazz = _query_TransactionRemoteModel.getClass();

				Method method = clazz.getMethod("setISACTIVE", int.class);

				method.invoke(_query_TransactionRemoteModel, ISACTIVE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getQuery_TransactionRemoteModel() {
		return _query_TransactionRemoteModel;
	}

	public void setQuery_TransactionRemoteModel(
		BaseModel<?> query_TransactionRemoteModel) {
		_query_TransactionRemoteModel = query_TransactionRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _query_TransactionRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_query_TransactionRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			Query_TransactionLocalServiceUtil.addQuery_Transaction(this);
		}
		else {
			Query_TransactionLocalServiceUtil.updateQuery_Transaction(this);
		}
	}

	@Override
	public Query_Transaction toEscapedModel() {
		return (Query_Transaction)ProxyUtil.newProxyInstance(Query_Transaction.class.getClassLoader(),
			new Class[] { Query_Transaction.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		Query_TransactionClp clone = new Query_TransactionClp();

		clone.setQueryId(getQueryId());
		clone.setCaseNo(getCaseNo());
		clone.setDescription(getDescription());
		clone.setRaisedTimestamp(getRaisedTimestamp());
		clone.setRaisedById(getRaisedById());
		clone.setToDisplay(getToDisplay());
		clone.setOrn_no(getOrn_no());
		clone.setCaf_no(getCaf_no());
		clone.setCustomer_MSISDN(getCustomer_MSISDN());
		clone.setAmt_request(getAmt_request());
		clone.setAmt_done(getAmt_done());
		clone.setRaised_by_email(getRaised_by_email());
		clone.setPcId(getPcId());
		clone.setAck(getAck());
		clone.setSource(getSource());
		clone.setAck_timestamp(getAck_timestamp());
		clone.setAssignment_group(getAssignment_group());
		clone.setISACTIVE(getISACTIVE());

		return clone;
	}

	@Override
	public int compareTo(Query_Transaction query_Transaction) {
		long primaryKey = query_Transaction.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof Query_TransactionClp)) {
			return false;
		}

		Query_TransactionClp query_Transaction = (Query_TransactionClp)obj;

		long primaryKey = query_Transaction.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(37);

		sb.append("{queryId=");
		sb.append(getQueryId());
		sb.append(", caseNo=");
		sb.append(getCaseNo());
		sb.append(", description=");
		sb.append(getDescription());
		sb.append(", raisedTimestamp=");
		sb.append(getRaisedTimestamp());
		sb.append(", raisedById=");
		sb.append(getRaisedById());
		sb.append(", toDisplay=");
		sb.append(getToDisplay());
		sb.append(", orn_no=");
		sb.append(getOrn_no());
		sb.append(", caf_no=");
		sb.append(getCaf_no());
		sb.append(", customer_MSISDN=");
		sb.append(getCustomer_MSISDN());
		sb.append(", amt_request=");
		sb.append(getAmt_request());
		sb.append(", amt_done=");
		sb.append(getAmt_done());
		sb.append(", raised_by_email=");
		sb.append(getRaised_by_email());
		sb.append(", pcId=");
		sb.append(getPcId());
		sb.append(", ack=");
		sb.append(getAck());
		sb.append(", source=");
		sb.append(getSource());
		sb.append(", ack_timestamp=");
		sb.append(getAck_timestamp());
		sb.append(", assignment_group=");
		sb.append(getAssignment_group());
		sb.append(", ISACTIVE=");
		sb.append(getISACTIVE());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(58);

		sb.append("<model><model-name>");
		sb.append("com.jioc.query.model.Query_Transaction");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>queryId</column-name><column-value><![CDATA[");
		sb.append(getQueryId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>caseNo</column-name><column-value><![CDATA[");
		sb.append(getCaseNo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>description</column-name><column-value><![CDATA[");
		sb.append(getDescription());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>raisedTimestamp</column-name><column-value><![CDATA[");
		sb.append(getRaisedTimestamp());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>raisedById</column-name><column-value><![CDATA[");
		sb.append(getRaisedById());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>toDisplay</column-name><column-value><![CDATA[");
		sb.append(getToDisplay());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>orn_no</column-name><column-value><![CDATA[");
		sb.append(getOrn_no());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>caf_no</column-name><column-value><![CDATA[");
		sb.append(getCaf_no());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>customer_MSISDN</column-name><column-value><![CDATA[");
		sb.append(getCustomer_MSISDN());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>amt_request</column-name><column-value><![CDATA[");
		sb.append(getAmt_request());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>amt_done</column-name><column-value><![CDATA[");
		sb.append(getAmt_done());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>raised_by_email</column-name><column-value><![CDATA[");
		sb.append(getRaised_by_email());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>pcId</column-name><column-value><![CDATA[");
		sb.append(getPcId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>ack</column-name><column-value><![CDATA[");
		sb.append(getAck());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>source</column-name><column-value><![CDATA[");
		sb.append(getSource());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>ack_timestamp</column-name><column-value><![CDATA[");
		sb.append(getAck_timestamp());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>assignment_group</column-name><column-value><![CDATA[");
		sb.append(getAssignment_group());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>ISACTIVE</column-name><column-value><![CDATA[");
		sb.append(getISACTIVE());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _queryId;
	private String _caseNo;
	private String _description;
	private Date _raisedTimestamp;
	private long _raisedById;
	private int _toDisplay;
	private String _orn_no;
	private String _caf_no;
	private String _customer_MSISDN;
	private long _amt_request;
	private long _amt_done;
	private String _raised_by_email;
	private String _pcId;
	private int _ack;
	private String _source;
	private Date _ack_timestamp;
	private String _assignment_group;
	private int _ISACTIVE;
	private BaseModel<?> _query_TransactionRemoteModel;
	private Class<?> _clpSerializerClass = com.jioc.query.service.ClpSerializer.class;
}