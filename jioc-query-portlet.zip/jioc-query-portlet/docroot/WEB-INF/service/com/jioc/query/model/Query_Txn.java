/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.liferay.portal.model.PersistedModel;

/**
 * The extended model interface for the Query_Txn service. Represents a row in the &quot;jioc_Query_Txn&quot; database table, with each column mapped to a property of this class.
 *
 * @author shantaram.chavan
 * @see Query_TxnModel
 * @see com.jioc.query.model.impl.Query_TxnImpl
 * @see com.jioc.query.model.impl.Query_TxnModelImpl
 * @generated
 */
public interface Query_Txn extends Query_TxnModel, PersistedModel {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this interface directly. Add methods to {@link com.jioc.query.model.impl.Query_TxnImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
	 */
}