/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.jioc.query.service.CASE_RES_MSTLocalServiceUtil;
import com.jioc.query.service.ClpSerializer;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author shantaram.chavan
 */
public class CASE_RES_MSTClp extends BaseModelImpl<CASE_RES_MST>
	implements CASE_RES_MST {
	public CASE_RES_MSTClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return CASE_RES_MST.class;
	}

	@Override
	public String getModelClassName() {
		return CASE_RES_MST.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _CASE_RES_ID;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setCASE_RES_ID(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _CASE_RES_ID;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("CASE_RES_ID", getCASE_RES_ID());
		attributes.put("CASE_RES_NAME", getCASE_RES_NAME());
		attributes.put("IS_ACTIVE", getIS_ACTIVE());
		attributes.put("OC", getOC());
		attributes.put("UPDATED_TIMESTAMP", getUPDATED_TIMESTAMP());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long CASE_RES_ID = (Long)attributes.get("CASE_RES_ID");

		if (CASE_RES_ID != null) {
			setCASE_RES_ID(CASE_RES_ID);
		}

		String CASE_RES_NAME = (String)attributes.get("CASE_RES_NAME");

		if (CASE_RES_NAME != null) {
			setCASE_RES_NAME(CASE_RES_NAME);
		}

		Integer IS_ACTIVE = (Integer)attributes.get("IS_ACTIVE");

		if (IS_ACTIVE != null) {
			setIS_ACTIVE(IS_ACTIVE);
		}

		String OC = (String)attributes.get("OC");

		if (OC != null) {
			setOC(OC);
		}

		Date UPDATED_TIMESTAMP = (Date)attributes.get("UPDATED_TIMESTAMP");

		if (UPDATED_TIMESTAMP != null) {
			setUPDATED_TIMESTAMP(UPDATED_TIMESTAMP);
		}
	}

	@Override
	public long getCASE_RES_ID() {
		return _CASE_RES_ID;
	}

	@Override
	public void setCASE_RES_ID(long CASE_RES_ID) {
		_CASE_RES_ID = CASE_RES_ID;

		if (_case_res_mstRemoteModel != null) {
			try {
				Class<?> clazz = _case_res_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setCASE_RES_ID", long.class);

				method.invoke(_case_res_mstRemoteModel, CASE_RES_ID);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCASE_RES_NAME() {
		return _CASE_RES_NAME;
	}

	@Override
	public void setCASE_RES_NAME(String CASE_RES_NAME) {
		_CASE_RES_NAME = CASE_RES_NAME;

		if (_case_res_mstRemoteModel != null) {
			try {
				Class<?> clazz = _case_res_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setCASE_RES_NAME", String.class);

				method.invoke(_case_res_mstRemoteModel, CASE_RES_NAME);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getIS_ACTIVE() {
		return _IS_ACTIVE;
	}

	@Override
	public void setIS_ACTIVE(int IS_ACTIVE) {
		_IS_ACTIVE = IS_ACTIVE;

		if (_case_res_mstRemoteModel != null) {
			try {
				Class<?> clazz = _case_res_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setIS_ACTIVE", int.class);

				method.invoke(_case_res_mstRemoteModel, IS_ACTIVE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOC() {
		return _OC;
	}

	@Override
	public void setOC(String OC) {
		_OC = OC;

		if (_case_res_mstRemoteModel != null) {
			try {
				Class<?> clazz = _case_res_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setOC", String.class);

				method.invoke(_case_res_mstRemoteModel, OC);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getUPDATED_TIMESTAMP() {
		return _UPDATED_TIMESTAMP;
	}

	@Override
	public void setUPDATED_TIMESTAMP(Date UPDATED_TIMESTAMP) {
		_UPDATED_TIMESTAMP = UPDATED_TIMESTAMP;

		if (_case_res_mstRemoteModel != null) {
			try {
				Class<?> clazz = _case_res_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setUPDATED_TIMESTAMP",
						Date.class);

				method.invoke(_case_res_mstRemoteModel, UPDATED_TIMESTAMP);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getCASE_RES_MSTRemoteModel() {
		return _case_res_mstRemoteModel;
	}

	public void setCASE_RES_MSTRemoteModel(BaseModel<?> case_res_mstRemoteModel) {
		_case_res_mstRemoteModel = case_res_mstRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _case_res_mstRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_case_res_mstRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			CASE_RES_MSTLocalServiceUtil.addCASE_RES_MST(this);
		}
		else {
			CASE_RES_MSTLocalServiceUtil.updateCASE_RES_MST(this);
		}
	}

	@Override
	public CASE_RES_MST toEscapedModel() {
		return (CASE_RES_MST)ProxyUtil.newProxyInstance(CASE_RES_MST.class.getClassLoader(),
			new Class[] { CASE_RES_MST.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		CASE_RES_MSTClp clone = new CASE_RES_MSTClp();

		clone.setCASE_RES_ID(getCASE_RES_ID());
		clone.setCASE_RES_NAME(getCASE_RES_NAME());
		clone.setIS_ACTIVE(getIS_ACTIVE());
		clone.setOC(getOC());
		clone.setUPDATED_TIMESTAMP(getUPDATED_TIMESTAMP());

		return clone;
	}

	@Override
	public int compareTo(CASE_RES_MST case_res_mst) {
		long primaryKey = case_res_mst.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof CASE_RES_MSTClp)) {
			return false;
		}

		CASE_RES_MSTClp case_res_mst = (CASE_RES_MSTClp)obj;

		long primaryKey = case_res_mst.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{CASE_RES_ID=");
		sb.append(getCASE_RES_ID());
		sb.append(", CASE_RES_NAME=");
		sb.append(getCASE_RES_NAME());
		sb.append(", IS_ACTIVE=");
		sb.append(getIS_ACTIVE());
		sb.append(", OC=");
		sb.append(getOC());
		sb.append(", UPDATED_TIMESTAMP=");
		sb.append(getUPDATED_TIMESTAMP());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(19);

		sb.append("<model><model-name>");
		sb.append("com.jioc.query.model.CASE_RES_MST");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>CASE_RES_ID</column-name><column-value><![CDATA[");
		sb.append(getCASE_RES_ID());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>CASE_RES_NAME</column-name><column-value><![CDATA[");
		sb.append(getCASE_RES_NAME());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>IS_ACTIVE</column-name><column-value><![CDATA[");
		sb.append(getIS_ACTIVE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>OC</column-name><column-value><![CDATA[");
		sb.append(getOC());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>UPDATED_TIMESTAMP</column-name><column-value><![CDATA[");
		sb.append(getUPDATED_TIMESTAMP());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _CASE_RES_ID;
	private String _CASE_RES_NAME;
	private int _IS_ACTIVE;
	private String _OC;
	private Date _UPDATED_TIMESTAMP;
	private BaseModel<?> _case_res_mstRemoteModel;
	private Class<?> _clpSerializerClass = com.jioc.query.service.ClpSerializer.class;
}