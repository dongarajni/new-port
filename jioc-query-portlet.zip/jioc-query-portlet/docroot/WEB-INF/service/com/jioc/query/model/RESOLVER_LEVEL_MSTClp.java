/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.jioc.query.service.ClpSerializer;
import com.jioc.query.service.RESOLVER_LEVEL_MSTLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author shantaram.chavan
 */
public class RESOLVER_LEVEL_MSTClp extends BaseModelImpl<RESOLVER_LEVEL_MST>
	implements RESOLVER_LEVEL_MST {
	public RESOLVER_LEVEL_MSTClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return RESOLVER_LEVEL_MST.class;
	}

	@Override
	public String getModelClassName() {
		return RESOLVER_LEVEL_MST.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _LEVEL_ID;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setLEVEL_ID(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _LEVEL_ID;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("LEVEL_ID", getLEVEL_ID());
		attributes.put("LEVEL_NAME", getLEVEL_NAME());
		attributes.put("RESOLVER_LEVEL", getRESOLVER_LEVEL());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long LEVEL_ID = (Long)attributes.get("LEVEL_ID");

		if (LEVEL_ID != null) {
			setLEVEL_ID(LEVEL_ID);
		}

		String LEVEL_NAME = (String)attributes.get("LEVEL_NAME");

		if (LEVEL_NAME != null) {
			setLEVEL_NAME(LEVEL_NAME);
		}

		Integer RESOLVER_LEVEL = (Integer)attributes.get("RESOLVER_LEVEL");

		if (RESOLVER_LEVEL != null) {
			setRESOLVER_LEVEL(RESOLVER_LEVEL);
		}
	}

	@Override
	public long getLEVEL_ID() {
		return _LEVEL_ID;
	}

	@Override
	public void setLEVEL_ID(long LEVEL_ID) {
		_LEVEL_ID = LEVEL_ID;

		if (_resolver_level_mstRemoteModel != null) {
			try {
				Class<?> clazz = _resolver_level_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setLEVEL_ID", long.class);

				method.invoke(_resolver_level_mstRemoteModel, LEVEL_ID);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getLEVEL_NAME() {
		return _LEVEL_NAME;
	}

	@Override
	public void setLEVEL_NAME(String LEVEL_NAME) {
		_LEVEL_NAME = LEVEL_NAME;

		if (_resolver_level_mstRemoteModel != null) {
			try {
				Class<?> clazz = _resolver_level_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setLEVEL_NAME", String.class);

				method.invoke(_resolver_level_mstRemoteModel, LEVEL_NAME);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getRESOLVER_LEVEL() {
		return _RESOLVER_LEVEL;
	}

	@Override
	public void setRESOLVER_LEVEL(int RESOLVER_LEVEL) {
		_RESOLVER_LEVEL = RESOLVER_LEVEL;

		if (_resolver_level_mstRemoteModel != null) {
			try {
				Class<?> clazz = _resolver_level_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setRESOLVER_LEVEL", int.class);

				method.invoke(_resolver_level_mstRemoteModel, RESOLVER_LEVEL);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getRESOLVER_LEVEL_MSTRemoteModel() {
		return _resolver_level_mstRemoteModel;
	}

	public void setRESOLVER_LEVEL_MSTRemoteModel(
		BaseModel<?> resolver_level_mstRemoteModel) {
		_resolver_level_mstRemoteModel = resolver_level_mstRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _resolver_level_mstRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_resolver_level_mstRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			RESOLVER_LEVEL_MSTLocalServiceUtil.addRESOLVER_LEVEL_MST(this);
		}
		else {
			RESOLVER_LEVEL_MSTLocalServiceUtil.updateRESOLVER_LEVEL_MST(this);
		}
	}

	@Override
	public RESOLVER_LEVEL_MST toEscapedModel() {
		return (RESOLVER_LEVEL_MST)ProxyUtil.newProxyInstance(RESOLVER_LEVEL_MST.class.getClassLoader(),
			new Class[] { RESOLVER_LEVEL_MST.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		RESOLVER_LEVEL_MSTClp clone = new RESOLVER_LEVEL_MSTClp();

		clone.setLEVEL_ID(getLEVEL_ID());
		clone.setLEVEL_NAME(getLEVEL_NAME());
		clone.setRESOLVER_LEVEL(getRESOLVER_LEVEL());

		return clone;
	}

	@Override
	public int compareTo(RESOLVER_LEVEL_MST resolver_level_mst) {
		long primaryKey = resolver_level_mst.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof RESOLVER_LEVEL_MSTClp)) {
			return false;
		}

		RESOLVER_LEVEL_MSTClp resolver_level_mst = (RESOLVER_LEVEL_MSTClp)obj;

		long primaryKey = resolver_level_mst.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(7);

		sb.append("{LEVEL_ID=");
		sb.append(getLEVEL_ID());
		sb.append(", LEVEL_NAME=");
		sb.append(getLEVEL_NAME());
		sb.append(", RESOLVER_LEVEL=");
		sb.append(getRESOLVER_LEVEL());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(13);

		sb.append("<model><model-name>");
		sb.append("com.jioc.query.model.RESOLVER_LEVEL_MST");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>LEVEL_ID</column-name><column-value><![CDATA[");
		sb.append(getLEVEL_ID());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>LEVEL_NAME</column-name><column-value><![CDATA[");
		sb.append(getLEVEL_NAME());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>RESOLVER_LEVEL</column-name><column-value><![CDATA[");
		sb.append(getRESOLVER_LEVEL());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _LEVEL_ID;
	private String _LEVEL_NAME;
	private int _RESOLVER_LEVEL;
	private BaseModel<?> _resolver_level_mstRemoteModel;
	private Class<?> _clpSerializerClass = com.jioc.query.service.ClpSerializer.class;
}