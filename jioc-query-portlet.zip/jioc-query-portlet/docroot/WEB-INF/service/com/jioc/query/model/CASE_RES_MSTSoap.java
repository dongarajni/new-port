/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author shantaram.chavan
 * @generated
 */
public class CASE_RES_MSTSoap implements Serializable {
	public static CASE_RES_MSTSoap toSoapModel(CASE_RES_MST model) {
		CASE_RES_MSTSoap soapModel = new CASE_RES_MSTSoap();

		soapModel.setCASE_RES_ID(model.getCASE_RES_ID());
		soapModel.setCASE_RES_NAME(model.getCASE_RES_NAME());
		soapModel.setIS_ACTIVE(model.getIS_ACTIVE());
		soapModel.setOC(model.getOC());
		soapModel.setUPDATED_TIMESTAMP(model.getUPDATED_TIMESTAMP());

		return soapModel;
	}

	public static CASE_RES_MSTSoap[] toSoapModels(CASE_RES_MST[] models) {
		CASE_RES_MSTSoap[] soapModels = new CASE_RES_MSTSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static CASE_RES_MSTSoap[][] toSoapModels(CASE_RES_MST[][] models) {
		CASE_RES_MSTSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new CASE_RES_MSTSoap[models.length][models[0].length];
		}
		else {
			soapModels = new CASE_RES_MSTSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static CASE_RES_MSTSoap[] toSoapModels(List<CASE_RES_MST> models) {
		List<CASE_RES_MSTSoap> soapModels = new ArrayList<CASE_RES_MSTSoap>(models.size());

		for (CASE_RES_MST model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new CASE_RES_MSTSoap[soapModels.size()]);
	}

	public CASE_RES_MSTSoap() {
	}

	public long getPrimaryKey() {
		return _CASE_RES_ID;
	}

	public void setPrimaryKey(long pk) {
		setCASE_RES_ID(pk);
	}

	public long getCASE_RES_ID() {
		return _CASE_RES_ID;
	}

	public void setCASE_RES_ID(long CASE_RES_ID) {
		_CASE_RES_ID = CASE_RES_ID;
	}

	public String getCASE_RES_NAME() {
		return _CASE_RES_NAME;
	}

	public void setCASE_RES_NAME(String CASE_RES_NAME) {
		_CASE_RES_NAME = CASE_RES_NAME;
	}

	public int getIS_ACTIVE() {
		return _IS_ACTIVE;
	}

	public void setIS_ACTIVE(int IS_ACTIVE) {
		_IS_ACTIVE = IS_ACTIVE;
	}

	public String getOC() {
		return _OC;
	}

	public void setOC(String OC) {
		_OC = OC;
	}

	public Date getUPDATED_TIMESTAMP() {
		return _UPDATED_TIMESTAMP;
	}

	public void setUPDATED_TIMESTAMP(Date UPDATED_TIMESTAMP) {
		_UPDATED_TIMESTAMP = UPDATED_TIMESTAMP;
	}

	private long _CASE_RES_ID;
	private String _CASE_RES_NAME;
	private int _IS_ACTIVE;
	private String _OC;
	private Date _UPDATED_TIMESTAMP;
}