/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableLocalService;

/**
 * Provides the local service utility for Query_Details. This utility wraps
 * {@link com.jioc.query.service.impl.Query_DetailsLocalServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author shantaram.chavan
 * @see Query_DetailsLocalService
 * @see com.jioc.query.service.base.Query_DetailsLocalServiceBaseImpl
 * @see com.jioc.query.service.impl.Query_DetailsLocalServiceImpl
 * @generated
 */
public class Query_DetailsLocalServiceUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to {@link com.jioc.query.service.impl.Query_DetailsLocalServiceImpl} and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	* Adds the query_ details to the database. Also notifies the appropriate model listeners.
	*
	* @param query_Details the query_ details
	* @return the query_ details that was added
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Details addQuery_Details(
		com.jioc.query.model.Query_Details query_Details)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().addQuery_Details(query_Details);
	}

	/**
	* Creates a new query_ details with the primary key. Does not add the query_ details to the database.
	*
	* @param queryDetailsId the primary key for the new query_ details
	* @return the new query_ details
	*/
	public static com.jioc.query.model.Query_Details createQuery_Details(
		long queryDetailsId) {
		return getService().createQuery_Details(queryDetailsId);
	}

	/**
	* Deletes the query_ details with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param queryDetailsId the primary key of the query_ details
	* @return the query_ details that was removed
	* @throws PortalException if a query_ details with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Details deleteQuery_Details(
		long queryDetailsId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteQuery_Details(queryDetailsId);
	}

	/**
	* Deletes the query_ details from the database. Also notifies the appropriate model listeners.
	*
	* @param query_Details the query_ details
	* @return the query_ details that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Details deleteQuery_Details(
		com.jioc.query.model.Query_Details query_Details)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteQuery_Details(query_Details);
	}

	public static com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_DetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_DetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static com.jioc.query.model.Query_Details fetchQuery_Details(
		long queryDetailsId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().fetchQuery_Details(queryDetailsId);
	}

	/**
	* Returns the query_ details with the primary key.
	*
	* @param queryDetailsId the primary key of the query_ details
	* @return the query_ details
	* @throws PortalException if a query_ details with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Details getQuery_Details(
		long queryDetailsId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getQuery_Details(queryDetailsId);
	}

	public static com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the query_ detailses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_DetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of query_ detailses
	* @param end the upper bound of the range of query_ detailses (not inclusive)
	* @return the range of query_ detailses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Details> getQuery_Detailses(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getQuery_Detailses(start, end);
	}

	/**
	* Returns the number of query_ detailses.
	*
	* @return the number of query_ detailses
	* @throws SystemException if a system exception occurred
	*/
	public static int getQuery_DetailsesCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getQuery_DetailsesCount();
	}

	/**
	* Updates the query_ details in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param query_Details the query_ details
	* @return the query_ details that was updated
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Details updateQuery_Details(
		com.jioc.query.model.Query_Details query_Details)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().updateQuery_Details(query_Details);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	public static java.lang.String getBeanIdentifier() {
		return getService().getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	public static void setBeanIdentifier(java.lang.String beanIdentifier) {
		getService().setBeanIdentifier(beanIdentifier);
	}

	public static java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return getService().invokeMethod(name, parameterTypes, arguments);
	}

	public static java.util.List<com.jioc.query.model.Query_Details> findQueryDetailsByQueryId(
		long queryId) {
		return getService().findQueryDetailsByQueryId(queryId);
	}

	public static java.util.List<java.lang.Object[]> findLatestQueryDetailsByQueryId(
		long queryId) {
		return getService().findLatestQueryDetailsByQueryId(queryId);
	}

	public static void clearService() {
		_service = null;
	}

	public static Query_DetailsLocalService getService() {
		if (_service == null) {
			InvokableLocalService invokableLocalService = (InvokableLocalService)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
					Query_DetailsLocalService.class.getName());

			if (invokableLocalService instanceof Query_DetailsLocalService) {
				_service = (Query_DetailsLocalService)invokableLocalService;
			}
			else {
				_service = new Query_DetailsLocalServiceClp(invokableLocalService);
			}

			ReferenceRegistry.registerReference(Query_DetailsLocalServiceUtil.class,
				"_service");
		}

		return _service;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setService(Query_DetailsLocalService service) {
	}

	private static Query_DetailsLocalService _service;
}