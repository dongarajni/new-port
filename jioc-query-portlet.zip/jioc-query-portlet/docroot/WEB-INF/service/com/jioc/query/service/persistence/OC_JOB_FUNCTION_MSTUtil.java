/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.model.OC_JOB_FUNCTION_MST;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import java.util.List;

/**
 * The persistence utility for the o c_ j o b_ f u n c t i o n_ m s t service. This utility wraps {@link OC_JOB_FUNCTION_MSTPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see OC_JOB_FUNCTION_MSTPersistence
 * @see OC_JOB_FUNCTION_MSTPersistenceImpl
 * @generated
 */
public class OC_JOB_FUNCTION_MSTUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(OC_JOB_FUNCTION_MST oc_job_function_mst) {
		getPersistence().clearCache(oc_job_function_mst);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<OC_JOB_FUNCTION_MST> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<OC_JOB_FUNCTION_MST> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<OC_JOB_FUNCTION_MST> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static OC_JOB_FUNCTION_MST update(
		OC_JOB_FUNCTION_MST oc_job_function_mst) throws SystemException {
		return getPersistence().update(oc_job_function_mst);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static OC_JOB_FUNCTION_MST update(
		OC_JOB_FUNCTION_MST oc_job_function_mst, ServiceContext serviceContext)
		throws SystemException {
		return getPersistence().update(oc_job_function_mst, serviceContext);
	}

	/**
	* Returns all the o c_ j o b_ f u n c t i o n_ m s ts where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @return the matching o c_ j o b_ f u n c t i o n_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.OC_JOB_FUNCTION_MST> findByAreaJobFunction(
		java.lang.String FUNCTIONAL_AREA, java.lang.String JOB,
		java.lang.String SUB_FUNCTIONAL_AREA)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAreaJobFunction(FUNCTIONAL_AREA, JOB,
			SUB_FUNCTIONAL_AREA);
	}

	/**
	* Returns a range of all the o c_ j o b_ f u n c t i o n_ m s ts where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.OC_JOB_FUNCTION_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @param start the lower bound of the range of o c_ j o b_ f u n c t i o n_ m s ts
	* @param end the upper bound of the range of o c_ j o b_ f u n c t i o n_ m s ts (not inclusive)
	* @return the range of matching o c_ j o b_ f u n c t i o n_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.OC_JOB_FUNCTION_MST> findByAreaJobFunction(
		java.lang.String FUNCTIONAL_AREA, java.lang.String JOB,
		java.lang.String SUB_FUNCTIONAL_AREA, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAreaJobFunction(FUNCTIONAL_AREA, JOB,
			SUB_FUNCTIONAL_AREA, start, end);
	}

	/**
	* Returns an ordered range of all the o c_ j o b_ f u n c t i o n_ m s ts where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.OC_JOB_FUNCTION_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @param start the lower bound of the range of o c_ j o b_ f u n c t i o n_ m s ts
	* @param end the upper bound of the range of o c_ j o b_ f u n c t i o n_ m s ts (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching o c_ j o b_ f u n c t i o n_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.OC_JOB_FUNCTION_MST> findByAreaJobFunction(
		java.lang.String FUNCTIONAL_AREA, java.lang.String JOB,
		java.lang.String SUB_FUNCTIONAL_AREA, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAreaJobFunction(FUNCTIONAL_AREA, JOB,
			SUB_FUNCTIONAL_AREA, start, end, orderByComparator);
	}

	/**
	* Returns the first o c_ j o b_ f u n c t i o n_ m s t in the ordered set where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching o c_ j o b_ f u n c t i o n_ m s t
	* @throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException if a matching o c_ j o b_ f u n c t i o n_ m s t could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.OC_JOB_FUNCTION_MST findByAreaJobFunction_First(
		java.lang.String FUNCTIONAL_AREA, java.lang.String JOB,
		java.lang.String SUB_FUNCTIONAL_AREA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAreaJobFunction_First(FUNCTIONAL_AREA, JOB,
			SUB_FUNCTIONAL_AREA, orderByComparator);
	}

	/**
	* Returns the first o c_ j o b_ f u n c t i o n_ m s t in the ordered set where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching o c_ j o b_ f u n c t i o n_ m s t, or <code>null</code> if a matching o c_ j o b_ f u n c t i o n_ m s t could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.OC_JOB_FUNCTION_MST fetchByAreaJobFunction_First(
		java.lang.String FUNCTIONAL_AREA, java.lang.String JOB,
		java.lang.String SUB_FUNCTIONAL_AREA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAreaJobFunction_First(FUNCTIONAL_AREA, JOB,
			SUB_FUNCTIONAL_AREA, orderByComparator);
	}

	/**
	* Returns the last o c_ j o b_ f u n c t i o n_ m s t in the ordered set where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching o c_ j o b_ f u n c t i o n_ m s t
	* @throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException if a matching o c_ j o b_ f u n c t i o n_ m s t could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.OC_JOB_FUNCTION_MST findByAreaJobFunction_Last(
		java.lang.String FUNCTIONAL_AREA, java.lang.String JOB,
		java.lang.String SUB_FUNCTIONAL_AREA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAreaJobFunction_Last(FUNCTIONAL_AREA, JOB,
			SUB_FUNCTIONAL_AREA, orderByComparator);
	}

	/**
	* Returns the last o c_ j o b_ f u n c t i o n_ m s t in the ordered set where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching o c_ j o b_ f u n c t i o n_ m s t, or <code>null</code> if a matching o c_ j o b_ f u n c t i o n_ m s t could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.OC_JOB_FUNCTION_MST fetchByAreaJobFunction_Last(
		java.lang.String FUNCTIONAL_AREA, java.lang.String JOB,
		java.lang.String SUB_FUNCTIONAL_AREA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAreaJobFunction_Last(FUNCTIONAL_AREA, JOB,
			SUB_FUNCTIONAL_AREA, orderByComparator);
	}

	/**
	* Returns the o c_ j o b_ f u n c t i o n_ m s ts before and after the current o c_ j o b_ f u n c t i o n_ m s t in the ordered set where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* @param OC_JOB_FUNCTION_ID the primary key of the current o c_ j o b_ f u n c t i o n_ m s t
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next o c_ j o b_ f u n c t i o n_ m s t
	* @throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException if a o c_ j o b_ f u n c t i o n_ m s t with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.OC_JOB_FUNCTION_MST[] findByAreaJobFunction_PrevAndNext(
		long OC_JOB_FUNCTION_ID, java.lang.String FUNCTIONAL_AREA,
		java.lang.String JOB, java.lang.String SUB_FUNCTIONAL_AREA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAreaJobFunction_PrevAndNext(OC_JOB_FUNCTION_ID,
			FUNCTIONAL_AREA, JOB, SUB_FUNCTIONAL_AREA, orderByComparator);
	}

	/**
	* Removes all the o c_ j o b_ f u n c t i o n_ m s ts where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63; from the database.
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByAreaJobFunction(
		java.lang.String FUNCTIONAL_AREA, java.lang.String JOB,
		java.lang.String SUB_FUNCTIONAL_AREA)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence()
			.removeByAreaJobFunction(FUNCTIONAL_AREA, JOB, SUB_FUNCTIONAL_AREA);
	}

	/**
	* Returns the number of o c_ j o b_ f u n c t i o n_ m s ts where FUNCTIONAL_AREA = &#63; and JOB = &#63; and SUB_FUNCTIONAL_AREA = &#63;.
	*
	* @param FUNCTIONAL_AREA the f u n c t i o n a l_ a r e a
	* @param JOB the j o b
	* @param SUB_FUNCTIONAL_AREA the s u b_ f u n c t i o n a l_ a r e a
	* @return the number of matching o c_ j o b_ f u n c t i o n_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public static int countByAreaJobFunction(java.lang.String FUNCTIONAL_AREA,
		java.lang.String JOB, java.lang.String SUB_FUNCTIONAL_AREA)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .countByAreaJobFunction(FUNCTIONAL_AREA, JOB,
			SUB_FUNCTIONAL_AREA);
	}

	/**
	* Caches the o c_ j o b_ f u n c t i o n_ m s t in the entity cache if it is enabled.
	*
	* @param oc_job_function_mst the o c_ j o b_ f u n c t i o n_ m s t
	*/
	public static void cacheResult(
		com.jioc.query.model.OC_JOB_FUNCTION_MST oc_job_function_mst) {
		getPersistence().cacheResult(oc_job_function_mst);
	}

	/**
	* Caches the o c_ j o b_ f u n c t i o n_ m s ts in the entity cache if it is enabled.
	*
	* @param oc_job_function_msts the o c_ j o b_ f u n c t i o n_ m s ts
	*/
	public static void cacheResult(
		java.util.List<com.jioc.query.model.OC_JOB_FUNCTION_MST> oc_job_function_msts) {
		getPersistence().cacheResult(oc_job_function_msts);
	}

	/**
	* Creates a new o c_ j o b_ f u n c t i o n_ m s t with the primary key. Does not add the o c_ j o b_ f u n c t i o n_ m s t to the database.
	*
	* @param OC_JOB_FUNCTION_ID the primary key for the new o c_ j o b_ f u n c t i o n_ m s t
	* @return the new o c_ j o b_ f u n c t i o n_ m s t
	*/
	public static com.jioc.query.model.OC_JOB_FUNCTION_MST create(
		long OC_JOB_FUNCTION_ID) {
		return getPersistence().create(OC_JOB_FUNCTION_ID);
	}

	/**
	* Removes the o c_ j o b_ f u n c t i o n_ m s t with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param OC_JOB_FUNCTION_ID the primary key of the o c_ j o b_ f u n c t i o n_ m s t
	* @return the o c_ j o b_ f u n c t i o n_ m s t that was removed
	* @throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException if a o c_ j o b_ f u n c t i o n_ m s t with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.OC_JOB_FUNCTION_MST remove(
		long OC_JOB_FUNCTION_ID)
		throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().remove(OC_JOB_FUNCTION_ID);
	}

	public static com.jioc.query.model.OC_JOB_FUNCTION_MST updateImpl(
		com.jioc.query.model.OC_JOB_FUNCTION_MST oc_job_function_mst)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(oc_job_function_mst);
	}

	/**
	* Returns the o c_ j o b_ f u n c t i o n_ m s t with the primary key or throws a {@link com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException} if it could not be found.
	*
	* @param OC_JOB_FUNCTION_ID the primary key of the o c_ j o b_ f u n c t i o n_ m s t
	* @return the o c_ j o b_ f u n c t i o n_ m s t
	* @throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException if a o c_ j o b_ f u n c t i o n_ m s t with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.OC_JOB_FUNCTION_MST findByPrimaryKey(
		long OC_JOB_FUNCTION_ID)
		throws com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPrimaryKey(OC_JOB_FUNCTION_ID);
	}

	/**
	* Returns the o c_ j o b_ f u n c t i o n_ m s t with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param OC_JOB_FUNCTION_ID the primary key of the o c_ j o b_ f u n c t i o n_ m s t
	* @return the o c_ j o b_ f u n c t i o n_ m s t, or <code>null</code> if a o c_ j o b_ f u n c t i o n_ m s t with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.OC_JOB_FUNCTION_MST fetchByPrimaryKey(
		long OC_JOB_FUNCTION_ID)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(OC_JOB_FUNCTION_ID);
	}

	/**
	* Returns all the o c_ j o b_ f u n c t i o n_ m s ts.
	*
	* @return the o c_ j o b_ f u n c t i o n_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.OC_JOB_FUNCTION_MST> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the o c_ j o b_ f u n c t i o n_ m s ts.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.OC_JOB_FUNCTION_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of o c_ j o b_ f u n c t i o n_ m s ts
	* @param end the upper bound of the range of o c_ j o b_ f u n c t i o n_ m s ts (not inclusive)
	* @return the range of o c_ j o b_ f u n c t i o n_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.OC_JOB_FUNCTION_MST> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the o c_ j o b_ f u n c t i o n_ m s ts.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.OC_JOB_FUNCTION_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of o c_ j o b_ f u n c t i o n_ m s ts
	* @param end the upper bound of the range of o c_ j o b_ f u n c t i o n_ m s ts (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of o c_ j o b_ f u n c t i o n_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.OC_JOB_FUNCTION_MST> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the o c_ j o b_ f u n c t i o n_ m s ts from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of o c_ j o b_ f u n c t i o n_ m s ts.
	*
	* @return the number of o c_ j o b_ f u n c t i o n_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static OC_JOB_FUNCTION_MSTPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (OC_JOB_FUNCTION_MSTPersistence)PortletBeanLocatorUtil.locate(com.jioc.query.service.ClpSerializer.getServletContextName(),
					OC_JOB_FUNCTION_MSTPersistence.class.getName());

			ReferenceRegistry.registerReference(OC_JOB_FUNCTION_MSTUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(OC_JOB_FUNCTION_MSTPersistence persistence) {
	}

	private static OC_JOB_FUNCTION_MSTPersistence _persistence;
}