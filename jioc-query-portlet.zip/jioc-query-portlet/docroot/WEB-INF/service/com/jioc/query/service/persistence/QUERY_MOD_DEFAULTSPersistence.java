/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.model.QUERY_MOD_DEFAULTS;

import com.liferay.portal.service.persistence.BasePersistence;

/**
 * The persistence interface for the q u e r y_ m o d_ d e f a u l t s service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see QUERY_MOD_DEFAULTSPersistenceImpl
 * @see QUERY_MOD_DEFAULTSUtil
 * @generated
 */
public interface QUERY_MOD_DEFAULTSPersistence extends BasePersistence<QUERY_MOD_DEFAULTS> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link QUERY_MOD_DEFAULTSUtil} to access the q u e r y_ m o d_ d e f a u l t s persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the q u e r y_ m o d_ d e f a u l t ses where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	*
	* @param TYPE the t y p e
	* @param CURR_VAL the c u r r_ v a l
	* @param IS_ACTIVE the i s_ a c t i v e
	* @param CURR_LEVEL the c u r r_ l e v e l
	* @return the matching q u e r y_ m o d_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.QUERY_MOD_DEFAULTS> findByCurrType(
		java.lang.String TYPE, java.lang.String CURR_VAL, int IS_ACTIVE,
		int CURR_LEVEL)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the q u e r y_ m o d_ d e f a u l t ses where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.QUERY_MOD_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param TYPE the t y p e
	* @param CURR_VAL the c u r r_ v a l
	* @param IS_ACTIVE the i s_ a c t i v e
	* @param CURR_LEVEL the c u r r_ l e v e l
	* @param start the lower bound of the range of q u e r y_ m o d_ d e f a u l t ses
	* @param end the upper bound of the range of q u e r y_ m o d_ d e f a u l t ses (not inclusive)
	* @return the range of matching q u e r y_ m o d_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.QUERY_MOD_DEFAULTS> findByCurrType(
		java.lang.String TYPE, java.lang.String CURR_VAL, int IS_ACTIVE,
		int CURR_LEVEL, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the q u e r y_ m o d_ d e f a u l t ses where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.QUERY_MOD_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param TYPE the t y p e
	* @param CURR_VAL the c u r r_ v a l
	* @param IS_ACTIVE the i s_ a c t i v e
	* @param CURR_LEVEL the c u r r_ l e v e l
	* @param start the lower bound of the range of q u e r y_ m o d_ d e f a u l t ses
	* @param end the upper bound of the range of q u e r y_ m o d_ d e f a u l t ses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching q u e r y_ m o d_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.QUERY_MOD_DEFAULTS> findByCurrType(
		java.lang.String TYPE, java.lang.String CURR_VAL, int IS_ACTIVE,
		int CURR_LEVEL, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first q u e r y_ m o d_ d e f a u l t s in the ordered set where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	*
	* @param TYPE the t y p e
	* @param CURR_VAL the c u r r_ v a l
	* @param IS_ACTIVE the i s_ a c t i v e
	* @param CURR_LEVEL the c u r r_ l e v e l
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching q u e r y_ m o d_ d e f a u l t s
	* @throws com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException if a matching q u e r y_ m o d_ d e f a u l t s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.QUERY_MOD_DEFAULTS findByCurrType_First(
		java.lang.String TYPE, java.lang.String CURR_VAL, int IS_ACTIVE,
		int CURR_LEVEL,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first q u e r y_ m o d_ d e f a u l t s in the ordered set where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	*
	* @param TYPE the t y p e
	* @param CURR_VAL the c u r r_ v a l
	* @param IS_ACTIVE the i s_ a c t i v e
	* @param CURR_LEVEL the c u r r_ l e v e l
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching q u e r y_ m o d_ d e f a u l t s, or <code>null</code> if a matching q u e r y_ m o d_ d e f a u l t s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.QUERY_MOD_DEFAULTS fetchByCurrType_First(
		java.lang.String TYPE, java.lang.String CURR_VAL, int IS_ACTIVE,
		int CURR_LEVEL,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last q u e r y_ m o d_ d e f a u l t s in the ordered set where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	*
	* @param TYPE the t y p e
	* @param CURR_VAL the c u r r_ v a l
	* @param IS_ACTIVE the i s_ a c t i v e
	* @param CURR_LEVEL the c u r r_ l e v e l
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching q u e r y_ m o d_ d e f a u l t s
	* @throws com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException if a matching q u e r y_ m o d_ d e f a u l t s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.QUERY_MOD_DEFAULTS findByCurrType_Last(
		java.lang.String TYPE, java.lang.String CURR_VAL, int IS_ACTIVE,
		int CURR_LEVEL,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last q u e r y_ m o d_ d e f a u l t s in the ordered set where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	*
	* @param TYPE the t y p e
	* @param CURR_VAL the c u r r_ v a l
	* @param IS_ACTIVE the i s_ a c t i v e
	* @param CURR_LEVEL the c u r r_ l e v e l
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching q u e r y_ m o d_ d e f a u l t s, or <code>null</code> if a matching q u e r y_ m o d_ d e f a u l t s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.QUERY_MOD_DEFAULTS fetchByCurrType_Last(
		java.lang.String TYPE, java.lang.String CURR_VAL, int IS_ACTIVE,
		int CURR_LEVEL,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the q u e r y_ m o d_ d e f a u l t ses before and after the current q u e r y_ m o d_ d e f a u l t s in the ordered set where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	*
	* @param QUERY_MOD_DEFAULTS_ID the primary key of the current q u e r y_ m o d_ d e f a u l t s
	* @param TYPE the t y p e
	* @param CURR_VAL the c u r r_ v a l
	* @param IS_ACTIVE the i s_ a c t i v e
	* @param CURR_LEVEL the c u r r_ l e v e l
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next q u e r y_ m o d_ d e f a u l t s
	* @throws com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException if a q u e r y_ m o d_ d e f a u l t s with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.QUERY_MOD_DEFAULTS[] findByCurrType_PrevAndNext(
		int QUERY_MOD_DEFAULTS_ID, java.lang.String TYPE,
		java.lang.String CURR_VAL, int IS_ACTIVE, int CURR_LEVEL,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the q u e r y_ m o d_ d e f a u l t ses where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63; from the database.
	*
	* @param TYPE the t y p e
	* @param CURR_VAL the c u r r_ v a l
	* @param IS_ACTIVE the i s_ a c t i v e
	* @param CURR_LEVEL the c u r r_ l e v e l
	* @throws SystemException if a system exception occurred
	*/
	public void removeByCurrType(java.lang.String TYPE,
		java.lang.String CURR_VAL, int IS_ACTIVE, int CURR_LEVEL)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of q u e r y_ m o d_ d e f a u l t ses where TYPE = &#63; and CURR_VAL = &#63; and IS_ACTIVE = &#63; and CURR_LEVEL = &#63;.
	*
	* @param TYPE the t y p e
	* @param CURR_VAL the c u r r_ v a l
	* @param IS_ACTIVE the i s_ a c t i v e
	* @param CURR_LEVEL the c u r r_ l e v e l
	* @return the number of matching q u e r y_ m o d_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public int countByCurrType(java.lang.String TYPE,
		java.lang.String CURR_VAL, int IS_ACTIVE, int CURR_LEVEL)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the q u e r y_ m o d_ d e f a u l t s in the entity cache if it is enabled.
	*
	* @param query_mod_defaults the q u e r y_ m o d_ d e f a u l t s
	*/
	public void cacheResult(
		com.jioc.query.model.QUERY_MOD_DEFAULTS query_mod_defaults);

	/**
	* Caches the q u e r y_ m o d_ d e f a u l t ses in the entity cache if it is enabled.
	*
	* @param query_mod_defaultses the q u e r y_ m o d_ d e f a u l t ses
	*/
	public void cacheResult(
		java.util.List<com.jioc.query.model.QUERY_MOD_DEFAULTS> query_mod_defaultses);

	/**
	* Creates a new q u e r y_ m o d_ d e f a u l t s with the primary key. Does not add the q u e r y_ m o d_ d e f a u l t s to the database.
	*
	* @param QUERY_MOD_DEFAULTS_ID the primary key for the new q u e r y_ m o d_ d e f a u l t s
	* @return the new q u e r y_ m o d_ d e f a u l t s
	*/
	public com.jioc.query.model.QUERY_MOD_DEFAULTS create(
		int QUERY_MOD_DEFAULTS_ID);

	/**
	* Removes the q u e r y_ m o d_ d e f a u l t s with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param QUERY_MOD_DEFAULTS_ID the primary key of the q u e r y_ m o d_ d e f a u l t s
	* @return the q u e r y_ m o d_ d e f a u l t s that was removed
	* @throws com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException if a q u e r y_ m o d_ d e f a u l t s with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.QUERY_MOD_DEFAULTS remove(
		int QUERY_MOD_DEFAULTS_ID)
		throws com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException,
			com.liferay.portal.kernel.exception.SystemException;

	public com.jioc.query.model.QUERY_MOD_DEFAULTS updateImpl(
		com.jioc.query.model.QUERY_MOD_DEFAULTS query_mod_defaults)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the q u e r y_ m o d_ d e f a u l t s with the primary key or throws a {@link com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException} if it could not be found.
	*
	* @param QUERY_MOD_DEFAULTS_ID the primary key of the q u e r y_ m o d_ d e f a u l t s
	* @return the q u e r y_ m o d_ d e f a u l t s
	* @throws com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException if a q u e r y_ m o d_ d e f a u l t s with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.QUERY_MOD_DEFAULTS findByPrimaryKey(
		int QUERY_MOD_DEFAULTS_ID)
		throws com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the q u e r y_ m o d_ d e f a u l t s with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param QUERY_MOD_DEFAULTS_ID the primary key of the q u e r y_ m o d_ d e f a u l t s
	* @return the q u e r y_ m o d_ d e f a u l t s, or <code>null</code> if a q u e r y_ m o d_ d e f a u l t s with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.QUERY_MOD_DEFAULTS fetchByPrimaryKey(
		int QUERY_MOD_DEFAULTS_ID)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the q u e r y_ m o d_ d e f a u l t ses.
	*
	* @return the q u e r y_ m o d_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.QUERY_MOD_DEFAULTS> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the q u e r y_ m o d_ d e f a u l t ses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.QUERY_MOD_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of q u e r y_ m o d_ d e f a u l t ses
	* @param end the upper bound of the range of q u e r y_ m o d_ d e f a u l t ses (not inclusive)
	* @return the range of q u e r y_ m o d_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.QUERY_MOD_DEFAULTS> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the q u e r y_ m o d_ d e f a u l t ses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.QUERY_MOD_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of q u e r y_ m o d_ d e f a u l t ses
	* @param end the upper bound of the range of q u e r y_ m o d_ d e f a u l t ses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of q u e r y_ m o d_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.QUERY_MOD_DEFAULTS> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the q u e r y_ m o d_ d e f a u l t ses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of q u e r y_ m o d_ d e f a u l t ses.
	*
	* @return the number of q u e r y_ m o d_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}