/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author shantaram.chavan
 * @generated
 */
public class Query_TransactionSoap implements Serializable {
	public static Query_TransactionSoap toSoapModel(Query_Transaction model) {
		Query_TransactionSoap soapModel = new Query_TransactionSoap();

		soapModel.setQueryId(model.getQueryId());
		soapModel.setCaseNo(model.getCaseNo());
		soapModel.setDescription(model.getDescription());
		soapModel.setRaisedTimestamp(model.getRaisedTimestamp());
		soapModel.setRaisedById(model.getRaisedById());
		soapModel.setToDisplay(model.getToDisplay());
		soapModel.setOrn_no(model.getOrn_no());
		soapModel.setCaf_no(model.getCaf_no());
		soapModel.setCustomer_MSISDN(model.getCustomer_MSISDN());
		soapModel.setAmt_request(model.getAmt_request());
		soapModel.setAmt_done(model.getAmt_done());
		soapModel.setRaised_by_email(model.getRaised_by_email());
		soapModel.setPcId(model.getPcId());
		soapModel.setAck(model.getAck());
		soapModel.setSource(model.getSource());
		soapModel.setAck_timestamp(model.getAck_timestamp());
		soapModel.setAssignment_group(model.getAssignment_group());
		soapModel.setISACTIVE(model.getISACTIVE());

		return soapModel;
	}

	public static Query_TransactionSoap[] toSoapModels(
		Query_Transaction[] models) {
		Query_TransactionSoap[] soapModels = new Query_TransactionSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static Query_TransactionSoap[][] toSoapModels(
		Query_Transaction[][] models) {
		Query_TransactionSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new Query_TransactionSoap[models.length][models[0].length];
		}
		else {
			soapModels = new Query_TransactionSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static Query_TransactionSoap[] toSoapModels(
		List<Query_Transaction> models) {
		List<Query_TransactionSoap> soapModels = new ArrayList<Query_TransactionSoap>(models.size());

		for (Query_Transaction model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new Query_TransactionSoap[soapModels.size()]);
	}

	public Query_TransactionSoap() {
	}

	public long getPrimaryKey() {
		return _queryId;
	}

	public void setPrimaryKey(long pk) {
		setQueryId(pk);
	}

	public long getQueryId() {
		return _queryId;
	}

	public void setQueryId(long queryId) {
		_queryId = queryId;
	}

	public String getCaseNo() {
		return _caseNo;
	}

	public void setCaseNo(String caseNo) {
		_caseNo = caseNo;
	}

	public String getDescription() {
		return _description;
	}

	public void setDescription(String description) {
		_description = description;
	}

	public Date getRaisedTimestamp() {
		return _raisedTimestamp;
	}

	public void setRaisedTimestamp(Date raisedTimestamp) {
		_raisedTimestamp = raisedTimestamp;
	}

	public long getRaisedById() {
		return _raisedById;
	}

	public void setRaisedById(long raisedById) {
		_raisedById = raisedById;
	}

	public int getToDisplay() {
		return _toDisplay;
	}

	public void setToDisplay(int toDisplay) {
		_toDisplay = toDisplay;
	}

	public String getOrn_no() {
		return _orn_no;
	}

	public void setOrn_no(String orn_no) {
		_orn_no = orn_no;
	}

	public String getCaf_no() {
		return _caf_no;
	}

	public void setCaf_no(String caf_no) {
		_caf_no = caf_no;
	}

	public String getCustomer_MSISDN() {
		return _customer_MSISDN;
	}

	public void setCustomer_MSISDN(String customer_MSISDN) {
		_customer_MSISDN = customer_MSISDN;
	}

	public long getAmt_request() {
		return _amt_request;
	}

	public void setAmt_request(long amt_request) {
		_amt_request = amt_request;
	}

	public long getAmt_done() {
		return _amt_done;
	}

	public void setAmt_done(long amt_done) {
		_amt_done = amt_done;
	}

	public String getRaised_by_email() {
		return _raised_by_email;
	}

	public void setRaised_by_email(String raised_by_email) {
		_raised_by_email = raised_by_email;
	}

	public String getPcId() {
		return _pcId;
	}

	public void setPcId(String pcId) {
		_pcId = pcId;
	}

	public int getAck() {
		return _ack;
	}

	public void setAck(int ack) {
		_ack = ack;
	}

	public String getSource() {
		return _source;
	}

	public void setSource(String source) {
		_source = source;
	}

	public Date getAck_timestamp() {
		return _ack_timestamp;
	}

	public void setAck_timestamp(Date ack_timestamp) {
		_ack_timestamp = ack_timestamp;
	}

	public String getAssignment_group() {
		return _assignment_group;
	}

	public void setAssignment_group(String assignment_group) {
		_assignment_group = assignment_group;
	}

	public int getISACTIVE() {
		return _ISACTIVE;
	}

	public void setISACTIVE(int ISACTIVE) {
		_ISACTIVE = ISACTIVE;
	}

	private long _queryId;
	private String _caseNo;
	private String _description;
	private Date _raisedTimestamp;
	private long _raisedById;
	private int _toDisplay;
	private String _orn_no;
	private String _caf_no;
	private String _customer_MSISDN;
	private long _amt_request;
	private long _amt_done;
	private String _raised_by_email;
	private String _pcId;
	private int _ack;
	private String _source;
	private Date _ack_timestamp;
	private String _assignment_group;
	private int _ISACTIVE;
}