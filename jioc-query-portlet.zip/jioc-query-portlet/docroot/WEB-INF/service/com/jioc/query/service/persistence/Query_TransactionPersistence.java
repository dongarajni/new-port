/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.model.Query_Transaction;

import com.liferay.portal.service.persistence.BasePersistence;

/**
 * The persistence interface for the query_ transaction service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see Query_TransactionPersistenceImpl
 * @see Query_TransactionUtil
 * @generated
 */
public interface Query_TransactionPersistence extends BasePersistence<Query_Transaction> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link Query_TransactionUtil} to access the query_ transaction persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the query_ transactions where raisedById = &#63;.
	*
	* @param raisedById the raised by ID
	* @return the matching query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.Query_Transaction> findByRaisedById(
		long raisedById)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the query_ transactions where raisedById = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param raisedById the raised by ID
	* @param start the lower bound of the range of query_ transactions
	* @param end the upper bound of the range of query_ transactions (not inclusive)
	* @return the range of matching query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.Query_Transaction> findByRaisedById(
		long raisedById, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the query_ transactions where raisedById = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param raisedById the raised by ID
	* @param start the lower bound of the range of query_ transactions
	* @param end the upper bound of the range of query_ transactions (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.Query_Transaction> findByRaisedById(
		long raisedById, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first query_ transaction in the ordered set where raisedById = &#63;.
	*
	* @param raisedById the raised by ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching query_ transaction
	* @throws com.jioc.query.NoSuchQuery_TransactionException if a matching query_ transaction could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.Query_Transaction findByRaisedById_First(
		long raisedById,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQuery_TransactionException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first query_ transaction in the ordered set where raisedById = &#63;.
	*
	* @param raisedById the raised by ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching query_ transaction, or <code>null</code> if a matching query_ transaction could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.Query_Transaction fetchByRaisedById_First(
		long raisedById,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last query_ transaction in the ordered set where raisedById = &#63;.
	*
	* @param raisedById the raised by ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching query_ transaction
	* @throws com.jioc.query.NoSuchQuery_TransactionException if a matching query_ transaction could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.Query_Transaction findByRaisedById_Last(
		long raisedById,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQuery_TransactionException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last query_ transaction in the ordered set where raisedById = &#63;.
	*
	* @param raisedById the raised by ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching query_ transaction, or <code>null</code> if a matching query_ transaction could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.Query_Transaction fetchByRaisedById_Last(
		long raisedById,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the query_ transactions before and after the current query_ transaction in the ordered set where raisedById = &#63;.
	*
	* @param queryId the primary key of the current query_ transaction
	* @param raisedById the raised by ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next query_ transaction
	* @throws com.jioc.query.NoSuchQuery_TransactionException if a query_ transaction with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.Query_Transaction[] findByRaisedById_PrevAndNext(
		long queryId, long raisedById,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQuery_TransactionException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the query_ transactions where raisedById = &#63; from the database.
	*
	* @param raisedById the raised by ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByRaisedById(long raisedById)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of query_ transactions where raisedById = &#63;.
	*
	* @param raisedById the raised by ID
	* @return the number of matching query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public int countByRaisedById(long raisedById)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the query_ transactions where pcId = &#63;.
	*
	* @param pcId the pc ID
	* @return the matching query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.Query_Transaction> findByPCId(
		java.lang.String pcId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the query_ transactions where pcId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pcId the pc ID
	* @param start the lower bound of the range of query_ transactions
	* @param end the upper bound of the range of query_ transactions (not inclusive)
	* @return the range of matching query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.Query_Transaction> findByPCId(
		java.lang.String pcId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the query_ transactions where pcId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pcId the pc ID
	* @param start the lower bound of the range of query_ transactions
	* @param end the upper bound of the range of query_ transactions (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.Query_Transaction> findByPCId(
		java.lang.String pcId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first query_ transaction in the ordered set where pcId = &#63;.
	*
	* @param pcId the pc ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching query_ transaction
	* @throws com.jioc.query.NoSuchQuery_TransactionException if a matching query_ transaction could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.Query_Transaction findByPCId_First(
		java.lang.String pcId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQuery_TransactionException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first query_ transaction in the ordered set where pcId = &#63;.
	*
	* @param pcId the pc ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching query_ transaction, or <code>null</code> if a matching query_ transaction could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.Query_Transaction fetchByPCId_First(
		java.lang.String pcId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last query_ transaction in the ordered set where pcId = &#63;.
	*
	* @param pcId the pc ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching query_ transaction
	* @throws com.jioc.query.NoSuchQuery_TransactionException if a matching query_ transaction could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.Query_Transaction findByPCId_Last(
		java.lang.String pcId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQuery_TransactionException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last query_ transaction in the ordered set where pcId = &#63;.
	*
	* @param pcId the pc ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching query_ transaction, or <code>null</code> if a matching query_ transaction could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.Query_Transaction fetchByPCId_Last(
		java.lang.String pcId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the query_ transactions before and after the current query_ transaction in the ordered set where pcId = &#63;.
	*
	* @param queryId the primary key of the current query_ transaction
	* @param pcId the pc ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next query_ transaction
	* @throws com.jioc.query.NoSuchQuery_TransactionException if a query_ transaction with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.Query_Transaction[] findByPCId_PrevAndNext(
		long queryId, java.lang.String pcId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQuery_TransactionException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the query_ transactions where pcId = &#63; from the database.
	*
	* @param pcId the pc ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByPCId(java.lang.String pcId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of query_ transactions where pcId = &#63;.
	*
	* @param pcId the pc ID
	* @return the number of matching query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public int countByPCId(java.lang.String pcId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the query_ transaction in the entity cache if it is enabled.
	*
	* @param query_Transaction the query_ transaction
	*/
	public void cacheResult(
		com.jioc.query.model.Query_Transaction query_Transaction);

	/**
	* Caches the query_ transactions in the entity cache if it is enabled.
	*
	* @param query_Transactions the query_ transactions
	*/
	public void cacheResult(
		java.util.List<com.jioc.query.model.Query_Transaction> query_Transactions);

	/**
	* Creates a new query_ transaction with the primary key. Does not add the query_ transaction to the database.
	*
	* @param queryId the primary key for the new query_ transaction
	* @return the new query_ transaction
	*/
	public com.jioc.query.model.Query_Transaction create(long queryId);

	/**
	* Removes the query_ transaction with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param queryId the primary key of the query_ transaction
	* @return the query_ transaction that was removed
	* @throws com.jioc.query.NoSuchQuery_TransactionException if a query_ transaction with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.Query_Transaction remove(long queryId)
		throws com.jioc.query.NoSuchQuery_TransactionException,
			com.liferay.portal.kernel.exception.SystemException;

	public com.jioc.query.model.Query_Transaction updateImpl(
		com.jioc.query.model.Query_Transaction query_Transaction)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the query_ transaction with the primary key or throws a {@link com.jioc.query.NoSuchQuery_TransactionException} if it could not be found.
	*
	* @param queryId the primary key of the query_ transaction
	* @return the query_ transaction
	* @throws com.jioc.query.NoSuchQuery_TransactionException if a query_ transaction with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.Query_Transaction findByPrimaryKey(long queryId)
		throws com.jioc.query.NoSuchQuery_TransactionException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the query_ transaction with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param queryId the primary key of the query_ transaction
	* @return the query_ transaction, or <code>null</code> if a query_ transaction with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.Query_Transaction fetchByPrimaryKey(
		long queryId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the query_ transactions.
	*
	* @return the query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.Query_Transaction> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the query_ transactions.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of query_ transactions
	* @param end the upper bound of the range of query_ transactions (not inclusive)
	* @return the range of query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.Query_Transaction> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the query_ transactions.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TransactionModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of query_ transactions
	* @param end the upper bound of the range of query_ transactions (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.Query_Transaction> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the query_ transactions from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of query_ transactions.
	*
	* @return the number of query_ transactions
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}