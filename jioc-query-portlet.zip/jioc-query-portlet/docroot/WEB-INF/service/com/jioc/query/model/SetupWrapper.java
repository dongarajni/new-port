/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Setup}.
 * </p>
 *
 * @author shantaram.chavan
 * @see Setup
 * @generated
 */
public class SetupWrapper implements Setup, ModelWrapper<Setup> {
	public SetupWrapper(Setup setup) {
		_setup = setup;
	}

	@Override
	public Class<?> getModelClass() {
		return Setup.class;
	}

	@Override
	public String getModelClassName() {
		return Setup.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("setup_id", getSetup_id());
		attributes.put("key", getKey());
		attributes.put("val1", getVal1());
		attributes.put("val2", getVal2());
		attributes.put("status", getStatus());
		attributes.put("updated_timestamp", getUpdated_timestamp());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long setup_id = (Long)attributes.get("setup_id");

		if (setup_id != null) {
			setSetup_id(setup_id);
		}

		String key = (String)attributes.get("key");

		if (key != null) {
			setKey(key);
		}

		String val1 = (String)attributes.get("val1");

		if (val1 != null) {
			setVal1(val1);
		}

		String val2 = (String)attributes.get("val2");

		if (val2 != null) {
			setVal2(val2);
		}

		Integer status = (Integer)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		Date updated_timestamp = (Date)attributes.get("updated_timestamp");

		if (updated_timestamp != null) {
			setUpdated_timestamp(updated_timestamp);
		}
	}

	/**
	* Returns the primary key of this setup.
	*
	* @return the primary key of this setup
	*/
	@Override
	public long getPrimaryKey() {
		return _setup.getPrimaryKey();
	}

	/**
	* Sets the primary key of this setup.
	*
	* @param primaryKey the primary key of this setup
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_setup.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the setup_id of this setup.
	*
	* @return the setup_id of this setup
	*/
	@Override
	public long getSetup_id() {
		return _setup.getSetup_id();
	}

	/**
	* Sets the setup_id of this setup.
	*
	* @param setup_id the setup_id of this setup
	*/
	@Override
	public void setSetup_id(long setup_id) {
		_setup.setSetup_id(setup_id);
	}

	/**
	* Returns the key of this setup.
	*
	* @return the key of this setup
	*/
	@Override
	public java.lang.String getKey() {
		return _setup.getKey();
	}

	/**
	* Sets the key of this setup.
	*
	* @param key the key of this setup
	*/
	@Override
	public void setKey(java.lang.String key) {
		_setup.setKey(key);
	}

	/**
	* Returns the val1 of this setup.
	*
	* @return the val1 of this setup
	*/
	@Override
	public java.lang.String getVal1() {
		return _setup.getVal1();
	}

	/**
	* Sets the val1 of this setup.
	*
	* @param val1 the val1 of this setup
	*/
	@Override
	public void setVal1(java.lang.String val1) {
		_setup.setVal1(val1);
	}

	/**
	* Returns the val2 of this setup.
	*
	* @return the val2 of this setup
	*/
	@Override
	public java.lang.String getVal2() {
		return _setup.getVal2();
	}

	/**
	* Sets the val2 of this setup.
	*
	* @param val2 the val2 of this setup
	*/
	@Override
	public void setVal2(java.lang.String val2) {
		_setup.setVal2(val2);
	}

	/**
	* Returns the status of this setup.
	*
	* @return the status of this setup
	*/
	@Override
	public int getStatus() {
		return _setup.getStatus();
	}

	/**
	* Sets the status of this setup.
	*
	* @param status the status of this setup
	*/
	@Override
	public void setStatus(int status) {
		_setup.setStatus(status);
	}

	/**
	* Returns the updated_timestamp of this setup.
	*
	* @return the updated_timestamp of this setup
	*/
	@Override
	public java.util.Date getUpdated_timestamp() {
		return _setup.getUpdated_timestamp();
	}

	/**
	* Sets the updated_timestamp of this setup.
	*
	* @param updated_timestamp the updated_timestamp of this setup
	*/
	@Override
	public void setUpdated_timestamp(java.util.Date updated_timestamp) {
		_setup.setUpdated_timestamp(updated_timestamp);
	}

	@Override
	public boolean isNew() {
		return _setup.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_setup.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _setup.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_setup.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _setup.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _setup.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_setup.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _setup.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_setup.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_setup.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_setup.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new SetupWrapper((Setup)_setup.clone());
	}

	@Override
	public int compareTo(com.jioc.query.model.Setup setup) {
		return _setup.compareTo(setup);
	}

	@Override
	public int hashCode() {
		return _setup.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jioc.query.model.Setup> toCacheModel() {
		return _setup.toCacheModel();
	}

	@Override
	public com.jioc.query.model.Setup toEscapedModel() {
		return new SetupWrapper(_setup.toEscapedModel());
	}

	@Override
	public com.jioc.query.model.Setup toUnescapedModel() {
		return new SetupWrapper(_setup.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _setup.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _setup.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_setup.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof SetupWrapper)) {
			return false;
		}

		SetupWrapper setupWrapper = (SetupWrapper)obj;

		if (Validator.equals(_setup, setupWrapper._setup)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public Setup getWrappedSetup() {
		return _setup;
	}

	@Override
	public Setup getWrappedModel() {
		return _setup;
	}

	@Override
	public void resetOriginalValues() {
		_setup.resetOriginalValues();
	}

	private Setup _setup;
}