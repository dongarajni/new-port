/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Query_Transaction}.
 * </p>
 *
 * @author shantaram.chavan
 * @see Query_Transaction
 * @generated
 */
public class Query_TransactionWrapper implements Query_Transaction,
	ModelWrapper<Query_Transaction> {
	public Query_TransactionWrapper(Query_Transaction query_Transaction) {
		_query_Transaction = query_Transaction;
	}

	@Override
	public Class<?> getModelClass() {
		return Query_Transaction.class;
	}

	@Override
	public String getModelClassName() {
		return Query_Transaction.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("queryId", getQueryId());
		attributes.put("caseNo", getCaseNo());
		attributes.put("description", getDescription());
		attributes.put("raisedTimestamp", getRaisedTimestamp());
		attributes.put("raisedById", getRaisedById());
		attributes.put("toDisplay", getToDisplay());
		attributes.put("orn_no", getOrn_no());
		attributes.put("caf_no", getCaf_no());
		attributes.put("customer_MSISDN", getCustomer_MSISDN());
		attributes.put("amt_request", getAmt_request());
		attributes.put("amt_done", getAmt_done());
		attributes.put("raised_by_email", getRaised_by_email());
		attributes.put("pcId", getPcId());
		attributes.put("ack", getAck());
		attributes.put("source", getSource());
		attributes.put("ack_timestamp", getAck_timestamp());
		attributes.put("assignment_group", getAssignment_group());
		attributes.put("ISACTIVE", getISACTIVE());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long queryId = (Long)attributes.get("queryId");

		if (queryId != null) {
			setQueryId(queryId);
		}

		String caseNo = (String)attributes.get("caseNo");

		if (caseNo != null) {
			setCaseNo(caseNo);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}

		Date raisedTimestamp = (Date)attributes.get("raisedTimestamp");

		if (raisedTimestamp != null) {
			setRaisedTimestamp(raisedTimestamp);
		}

		Long raisedById = (Long)attributes.get("raisedById");

		if (raisedById != null) {
			setRaisedById(raisedById);
		}

		Integer toDisplay = (Integer)attributes.get("toDisplay");

		if (toDisplay != null) {
			setToDisplay(toDisplay);
		}

		String orn_no = (String)attributes.get("orn_no");

		if (orn_no != null) {
			setOrn_no(orn_no);
		}

		String caf_no = (String)attributes.get("caf_no");

		if (caf_no != null) {
			setCaf_no(caf_no);
		}

		String customer_MSISDN = (String)attributes.get("customer_MSISDN");

		if (customer_MSISDN != null) {
			setCustomer_MSISDN(customer_MSISDN);
		}

		Long amt_request = (Long)attributes.get("amt_request");

		if (amt_request != null) {
			setAmt_request(amt_request);
		}

		Long amt_done = (Long)attributes.get("amt_done");

		if (amt_done != null) {
			setAmt_done(amt_done);
		}

		String raised_by_email = (String)attributes.get("raised_by_email");

		if (raised_by_email != null) {
			setRaised_by_email(raised_by_email);
		}

		String pcId = (String)attributes.get("pcId");

		if (pcId != null) {
			setPcId(pcId);
		}

		Integer ack = (Integer)attributes.get("ack");

		if (ack != null) {
			setAck(ack);
		}

		String source = (String)attributes.get("source");

		if (source != null) {
			setSource(source);
		}

		Date ack_timestamp = (Date)attributes.get("ack_timestamp");

		if (ack_timestamp != null) {
			setAck_timestamp(ack_timestamp);
		}

		String assignment_group = (String)attributes.get("assignment_group");

		if (assignment_group != null) {
			setAssignment_group(assignment_group);
		}

		Integer ISACTIVE = (Integer)attributes.get("ISACTIVE");

		if (ISACTIVE != null) {
			setISACTIVE(ISACTIVE);
		}
	}

	/**
	* Returns the primary key of this query_ transaction.
	*
	* @return the primary key of this query_ transaction
	*/
	@Override
	public long getPrimaryKey() {
		return _query_Transaction.getPrimaryKey();
	}

	/**
	* Sets the primary key of this query_ transaction.
	*
	* @param primaryKey the primary key of this query_ transaction
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_query_Transaction.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the query ID of this query_ transaction.
	*
	* @return the query ID of this query_ transaction
	*/
	@Override
	public long getQueryId() {
		return _query_Transaction.getQueryId();
	}

	/**
	* Sets the query ID of this query_ transaction.
	*
	* @param queryId the query ID of this query_ transaction
	*/
	@Override
	public void setQueryId(long queryId) {
		_query_Transaction.setQueryId(queryId);
	}

	/**
	* Returns the case no of this query_ transaction.
	*
	* @return the case no of this query_ transaction
	*/
	@Override
	public java.lang.String getCaseNo() {
		return _query_Transaction.getCaseNo();
	}

	/**
	* Sets the case no of this query_ transaction.
	*
	* @param caseNo the case no of this query_ transaction
	*/
	@Override
	public void setCaseNo(java.lang.String caseNo) {
		_query_Transaction.setCaseNo(caseNo);
	}

	/**
	* Returns the description of this query_ transaction.
	*
	* @return the description of this query_ transaction
	*/
	@Override
	public java.lang.String getDescription() {
		return _query_Transaction.getDescription();
	}

	/**
	* Sets the description of this query_ transaction.
	*
	* @param description the description of this query_ transaction
	*/
	@Override
	public void setDescription(java.lang.String description) {
		_query_Transaction.setDescription(description);
	}

	/**
	* Returns the raised timestamp of this query_ transaction.
	*
	* @return the raised timestamp of this query_ transaction
	*/
	@Override
	public java.util.Date getRaisedTimestamp() {
		return _query_Transaction.getRaisedTimestamp();
	}

	/**
	* Sets the raised timestamp of this query_ transaction.
	*
	* @param raisedTimestamp the raised timestamp of this query_ transaction
	*/
	@Override
	public void setRaisedTimestamp(java.util.Date raisedTimestamp) {
		_query_Transaction.setRaisedTimestamp(raisedTimestamp);
	}

	/**
	* Returns the raised by ID of this query_ transaction.
	*
	* @return the raised by ID of this query_ transaction
	*/
	@Override
	public long getRaisedById() {
		return _query_Transaction.getRaisedById();
	}

	/**
	* Sets the raised by ID of this query_ transaction.
	*
	* @param raisedById the raised by ID of this query_ transaction
	*/
	@Override
	public void setRaisedById(long raisedById) {
		_query_Transaction.setRaisedById(raisedById);
	}

	/**
	* Returns the to display of this query_ transaction.
	*
	* @return the to display of this query_ transaction
	*/
	@Override
	public int getToDisplay() {
		return _query_Transaction.getToDisplay();
	}

	/**
	* Sets the to display of this query_ transaction.
	*
	* @param toDisplay the to display of this query_ transaction
	*/
	@Override
	public void setToDisplay(int toDisplay) {
		_query_Transaction.setToDisplay(toDisplay);
	}

	/**
	* Returns the orn_no of this query_ transaction.
	*
	* @return the orn_no of this query_ transaction
	*/
	@Override
	public java.lang.String getOrn_no() {
		return _query_Transaction.getOrn_no();
	}

	/**
	* Sets the orn_no of this query_ transaction.
	*
	* @param orn_no the orn_no of this query_ transaction
	*/
	@Override
	public void setOrn_no(java.lang.String orn_no) {
		_query_Transaction.setOrn_no(orn_no);
	}

	/**
	* Returns the caf_no of this query_ transaction.
	*
	* @return the caf_no of this query_ transaction
	*/
	@Override
	public java.lang.String getCaf_no() {
		return _query_Transaction.getCaf_no();
	}

	/**
	* Sets the caf_no of this query_ transaction.
	*
	* @param caf_no the caf_no of this query_ transaction
	*/
	@Override
	public void setCaf_no(java.lang.String caf_no) {
		_query_Transaction.setCaf_no(caf_no);
	}

	/**
	* Returns the customer_ m s i s d n of this query_ transaction.
	*
	* @return the customer_ m s i s d n of this query_ transaction
	*/
	@Override
	public java.lang.String getCustomer_MSISDN() {
		return _query_Transaction.getCustomer_MSISDN();
	}

	/**
	* Sets the customer_ m s i s d n of this query_ transaction.
	*
	* @param customer_MSISDN the customer_ m s i s d n of this query_ transaction
	*/
	@Override
	public void setCustomer_MSISDN(java.lang.String customer_MSISDN) {
		_query_Transaction.setCustomer_MSISDN(customer_MSISDN);
	}

	/**
	* Returns the amt_request of this query_ transaction.
	*
	* @return the amt_request of this query_ transaction
	*/
	@Override
	public long getAmt_request() {
		return _query_Transaction.getAmt_request();
	}

	/**
	* Sets the amt_request of this query_ transaction.
	*
	* @param amt_request the amt_request of this query_ transaction
	*/
	@Override
	public void setAmt_request(long amt_request) {
		_query_Transaction.setAmt_request(amt_request);
	}

	/**
	* Returns the amt_done of this query_ transaction.
	*
	* @return the amt_done of this query_ transaction
	*/
	@Override
	public long getAmt_done() {
		return _query_Transaction.getAmt_done();
	}

	/**
	* Sets the amt_done of this query_ transaction.
	*
	* @param amt_done the amt_done of this query_ transaction
	*/
	@Override
	public void setAmt_done(long amt_done) {
		_query_Transaction.setAmt_done(amt_done);
	}

	/**
	* Returns the raised_by_email of this query_ transaction.
	*
	* @return the raised_by_email of this query_ transaction
	*/
	@Override
	public java.lang.String getRaised_by_email() {
		return _query_Transaction.getRaised_by_email();
	}

	/**
	* Sets the raised_by_email of this query_ transaction.
	*
	* @param raised_by_email the raised_by_email of this query_ transaction
	*/
	@Override
	public void setRaised_by_email(java.lang.String raised_by_email) {
		_query_Transaction.setRaised_by_email(raised_by_email);
	}

	/**
	* Returns the pc ID of this query_ transaction.
	*
	* @return the pc ID of this query_ transaction
	*/
	@Override
	public java.lang.String getPcId() {
		return _query_Transaction.getPcId();
	}

	/**
	* Sets the pc ID of this query_ transaction.
	*
	* @param pcId the pc ID of this query_ transaction
	*/
	@Override
	public void setPcId(java.lang.String pcId) {
		_query_Transaction.setPcId(pcId);
	}

	/**
	* Returns the ack of this query_ transaction.
	*
	* @return the ack of this query_ transaction
	*/
	@Override
	public int getAck() {
		return _query_Transaction.getAck();
	}

	/**
	* Sets the ack of this query_ transaction.
	*
	* @param ack the ack of this query_ transaction
	*/
	@Override
	public void setAck(int ack) {
		_query_Transaction.setAck(ack);
	}

	/**
	* Returns the source of this query_ transaction.
	*
	* @return the source of this query_ transaction
	*/
	@Override
	public java.lang.String getSource() {
		return _query_Transaction.getSource();
	}

	/**
	* Sets the source of this query_ transaction.
	*
	* @param source the source of this query_ transaction
	*/
	@Override
	public void setSource(java.lang.String source) {
		_query_Transaction.setSource(source);
	}

	/**
	* Returns the ack_timestamp of this query_ transaction.
	*
	* @return the ack_timestamp of this query_ transaction
	*/
	@Override
	public java.util.Date getAck_timestamp() {
		return _query_Transaction.getAck_timestamp();
	}

	/**
	* Sets the ack_timestamp of this query_ transaction.
	*
	* @param ack_timestamp the ack_timestamp of this query_ transaction
	*/
	@Override
	public void setAck_timestamp(java.util.Date ack_timestamp) {
		_query_Transaction.setAck_timestamp(ack_timestamp);
	}

	/**
	* Returns the assignment_group of this query_ transaction.
	*
	* @return the assignment_group of this query_ transaction
	*/
	@Override
	public java.lang.String getAssignment_group() {
		return _query_Transaction.getAssignment_group();
	}

	/**
	* Sets the assignment_group of this query_ transaction.
	*
	* @param assignment_group the assignment_group of this query_ transaction
	*/
	@Override
	public void setAssignment_group(java.lang.String assignment_group) {
		_query_Transaction.setAssignment_group(assignment_group);
	}

	/**
	* Returns the i s a c t i v e of this query_ transaction.
	*
	* @return the i s a c t i v e of this query_ transaction
	*/
	@Override
	public int getISACTIVE() {
		return _query_Transaction.getISACTIVE();
	}

	/**
	* Sets the i s a c t i v e of this query_ transaction.
	*
	* @param ISACTIVE the i s a c t i v e of this query_ transaction
	*/
	@Override
	public void setISACTIVE(int ISACTIVE) {
		_query_Transaction.setISACTIVE(ISACTIVE);
	}

	@Override
	public boolean isNew() {
		return _query_Transaction.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_query_Transaction.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _query_Transaction.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_query_Transaction.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _query_Transaction.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _query_Transaction.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_query_Transaction.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _query_Transaction.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_query_Transaction.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_query_Transaction.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_query_Transaction.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new Query_TransactionWrapper((Query_Transaction)_query_Transaction.clone());
	}

	@Override
	public int compareTo(
		com.jioc.query.model.Query_Transaction query_Transaction) {
		return _query_Transaction.compareTo(query_Transaction);
	}

	@Override
	public int hashCode() {
		return _query_Transaction.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jioc.query.model.Query_Transaction> toCacheModel() {
		return _query_Transaction.toCacheModel();
	}

	@Override
	public com.jioc.query.model.Query_Transaction toEscapedModel() {
		return new Query_TransactionWrapper(_query_Transaction.toEscapedModel());
	}

	@Override
	public com.jioc.query.model.Query_Transaction toUnescapedModel() {
		return new Query_TransactionWrapper(_query_Transaction.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _query_Transaction.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _query_Transaction.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_query_Transaction.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof Query_TransactionWrapper)) {
			return false;
		}

		Query_TransactionWrapper query_TransactionWrapper = (Query_TransactionWrapper)obj;

		if (Validator.equals(_query_Transaction,
					query_TransactionWrapper._query_Transaction)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public Query_Transaction getWrappedQuery_Transaction() {
		return _query_Transaction;
	}

	@Override
	public Query_Transaction getWrappedModel() {
		return _query_Transaction;
	}

	@Override
	public void resetOriginalValues() {
		_query_Transaction.resetOriginalValues();
	}

	private Query_Transaction _query_Transaction;
}