/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.jioc.query.service.ClpSerializer;
import com.jioc.query.service.Query_AttachmentsLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author shantaram.chavan
 */
public class Query_AttachmentsClp extends BaseModelImpl<Query_Attachments>
	implements Query_Attachments {
	public Query_AttachmentsClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return Query_Attachments.class;
	}

	@Override
	public String getModelClassName() {
		return Query_Attachments.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _AttachmentId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setAttachmentId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _AttachmentId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("AttachmentId", getAttachmentId());
		attributes.put("fileEntryId", getFileEntryId());
		attributes.put("updatedBy", getUpdatedBy());
		attributes.put("updatedTimestamp", getUpdatedTimestamp());
		attributes.put("queryId", getQueryId());
		attributes.put("file_name", getFile_name());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long AttachmentId = (Long)attributes.get("AttachmentId");

		if (AttachmentId != null) {
			setAttachmentId(AttachmentId);
		}

		Long fileEntryId = (Long)attributes.get("fileEntryId");

		if (fileEntryId != null) {
			setFileEntryId(fileEntryId);
		}

		Long updatedBy = (Long)attributes.get("updatedBy");

		if (updatedBy != null) {
			setUpdatedBy(updatedBy);
		}

		Date updatedTimestamp = (Date)attributes.get("updatedTimestamp");

		if (updatedTimestamp != null) {
			setUpdatedTimestamp(updatedTimestamp);
		}

		Long queryId = (Long)attributes.get("queryId");

		if (queryId != null) {
			setQueryId(queryId);
		}

		String file_name = (String)attributes.get("file_name");

		if (file_name != null) {
			setFile_name(file_name);
		}
	}

	@Override
	public long getAttachmentId() {
		return _AttachmentId;
	}

	@Override
	public void setAttachmentId(long AttachmentId) {
		_AttachmentId = AttachmentId;

		if (_query_AttachmentsRemoteModel != null) {
			try {
				Class<?> clazz = _query_AttachmentsRemoteModel.getClass();

				Method method = clazz.getMethod("setAttachmentId", long.class);

				method.invoke(_query_AttachmentsRemoteModel, AttachmentId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getFileEntryId() {
		return _fileEntryId;
	}

	@Override
	public void setFileEntryId(long fileEntryId) {
		_fileEntryId = fileEntryId;

		if (_query_AttachmentsRemoteModel != null) {
			try {
				Class<?> clazz = _query_AttachmentsRemoteModel.getClass();

				Method method = clazz.getMethod("setFileEntryId", long.class);

				method.invoke(_query_AttachmentsRemoteModel, fileEntryId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getUpdatedBy() {
		return _updatedBy;
	}

	@Override
	public void setUpdatedBy(long updatedBy) {
		_updatedBy = updatedBy;

		if (_query_AttachmentsRemoteModel != null) {
			try {
				Class<?> clazz = _query_AttachmentsRemoteModel.getClass();

				Method method = clazz.getMethod("setUpdatedBy", long.class);

				method.invoke(_query_AttachmentsRemoteModel, updatedBy);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getUpdatedTimestamp() {
		return _updatedTimestamp;
	}

	@Override
	public void setUpdatedTimestamp(Date updatedTimestamp) {
		_updatedTimestamp = updatedTimestamp;

		if (_query_AttachmentsRemoteModel != null) {
			try {
				Class<?> clazz = _query_AttachmentsRemoteModel.getClass();

				Method method = clazz.getMethod("setUpdatedTimestamp",
						Date.class);

				method.invoke(_query_AttachmentsRemoteModel, updatedTimestamp);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getQueryId() {
		return _queryId;
	}

	@Override
	public void setQueryId(long queryId) {
		_queryId = queryId;

		if (_query_AttachmentsRemoteModel != null) {
			try {
				Class<?> clazz = _query_AttachmentsRemoteModel.getClass();

				Method method = clazz.getMethod("setQueryId", long.class);

				method.invoke(_query_AttachmentsRemoteModel, queryId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getFile_name() {
		return _file_name;
	}

	@Override
	public void setFile_name(String file_name) {
		_file_name = file_name;

		if (_query_AttachmentsRemoteModel != null) {
			try {
				Class<?> clazz = _query_AttachmentsRemoteModel.getClass();

				Method method = clazz.getMethod("setFile_name", String.class);

				method.invoke(_query_AttachmentsRemoteModel, file_name);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getQuery_AttachmentsRemoteModel() {
		return _query_AttachmentsRemoteModel;
	}

	public void setQuery_AttachmentsRemoteModel(
		BaseModel<?> query_AttachmentsRemoteModel) {
		_query_AttachmentsRemoteModel = query_AttachmentsRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _query_AttachmentsRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_query_AttachmentsRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			Query_AttachmentsLocalServiceUtil.addQuery_Attachments(this);
		}
		else {
			Query_AttachmentsLocalServiceUtil.updateQuery_Attachments(this);
		}
	}

	@Override
	public Query_Attachments toEscapedModel() {
		return (Query_Attachments)ProxyUtil.newProxyInstance(Query_Attachments.class.getClassLoader(),
			new Class[] { Query_Attachments.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		Query_AttachmentsClp clone = new Query_AttachmentsClp();

		clone.setAttachmentId(getAttachmentId());
		clone.setFileEntryId(getFileEntryId());
		clone.setUpdatedBy(getUpdatedBy());
		clone.setUpdatedTimestamp(getUpdatedTimestamp());
		clone.setQueryId(getQueryId());
		clone.setFile_name(getFile_name());

		return clone;
	}

	@Override
	public int compareTo(Query_Attachments query_Attachments) {
		long primaryKey = query_Attachments.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof Query_AttachmentsClp)) {
			return false;
		}

		Query_AttachmentsClp query_Attachments = (Query_AttachmentsClp)obj;

		long primaryKey = query_Attachments.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{AttachmentId=");
		sb.append(getAttachmentId());
		sb.append(", fileEntryId=");
		sb.append(getFileEntryId());
		sb.append(", updatedBy=");
		sb.append(getUpdatedBy());
		sb.append(", updatedTimestamp=");
		sb.append(getUpdatedTimestamp());
		sb.append(", queryId=");
		sb.append(getQueryId());
		sb.append(", file_name=");
		sb.append(getFile_name());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(22);

		sb.append("<model><model-name>");
		sb.append("com.jioc.query.model.Query_Attachments");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>AttachmentId</column-name><column-value><![CDATA[");
		sb.append(getAttachmentId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>fileEntryId</column-name><column-value><![CDATA[");
		sb.append(getFileEntryId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>updatedBy</column-name><column-value><![CDATA[");
		sb.append(getUpdatedBy());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>updatedTimestamp</column-name><column-value><![CDATA[");
		sb.append(getUpdatedTimestamp());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>queryId</column-name><column-value><![CDATA[");
		sb.append(getQueryId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>file_name</column-name><column-value><![CDATA[");
		sb.append(getFile_name());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _AttachmentId;
	private long _fileEntryId;
	private long _updatedBy;
	private Date _updatedTimestamp;
	private long _queryId;
	private String _file_name;
	private BaseModel<?> _query_AttachmentsRemoteModel;
	private Class<?> _clpSerializerClass = com.jioc.query.service.ClpSerializer.class;
}