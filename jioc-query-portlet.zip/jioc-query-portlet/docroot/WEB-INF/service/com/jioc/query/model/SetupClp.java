/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.jioc.query.service.ClpSerializer;
import com.jioc.query.service.SetupLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author shantaram.chavan
 */
public class SetupClp extends BaseModelImpl<Setup> implements Setup {
	public SetupClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return Setup.class;
	}

	@Override
	public String getModelClassName() {
		return Setup.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _setup_id;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setSetup_id(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _setup_id;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("setup_id", getSetup_id());
		attributes.put("key", getKey());
		attributes.put("val1", getVal1());
		attributes.put("val2", getVal2());
		attributes.put("status", getStatus());
		attributes.put("updated_timestamp", getUpdated_timestamp());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long setup_id = (Long)attributes.get("setup_id");

		if (setup_id != null) {
			setSetup_id(setup_id);
		}

		String key = (String)attributes.get("key");

		if (key != null) {
			setKey(key);
		}

		String val1 = (String)attributes.get("val1");

		if (val1 != null) {
			setVal1(val1);
		}

		String val2 = (String)attributes.get("val2");

		if (val2 != null) {
			setVal2(val2);
		}

		Integer status = (Integer)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		Date updated_timestamp = (Date)attributes.get("updated_timestamp");

		if (updated_timestamp != null) {
			setUpdated_timestamp(updated_timestamp);
		}
	}

	@Override
	public long getSetup_id() {
		return _setup_id;
	}

	@Override
	public void setSetup_id(long setup_id) {
		_setup_id = setup_id;

		if (_setupRemoteModel != null) {
			try {
				Class<?> clazz = _setupRemoteModel.getClass();

				Method method = clazz.getMethod("setSetup_id", long.class);

				method.invoke(_setupRemoteModel, setup_id);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getKey() {
		return _key;
	}

	@Override
	public void setKey(String key) {
		_key = key;

		if (_setupRemoteModel != null) {
			try {
				Class<?> clazz = _setupRemoteModel.getClass();

				Method method = clazz.getMethod("setKey", String.class);

				method.invoke(_setupRemoteModel, key);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getVal1() {
		return _val1;
	}

	@Override
	public void setVal1(String val1) {
		_val1 = val1;

		if (_setupRemoteModel != null) {
			try {
				Class<?> clazz = _setupRemoteModel.getClass();

				Method method = clazz.getMethod("setVal1", String.class);

				method.invoke(_setupRemoteModel, val1);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getVal2() {
		return _val2;
	}

	@Override
	public void setVal2(String val2) {
		_val2 = val2;

		if (_setupRemoteModel != null) {
			try {
				Class<?> clazz = _setupRemoteModel.getClass();

				Method method = clazz.getMethod("setVal2", String.class);

				method.invoke(_setupRemoteModel, val2);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getStatus() {
		return _status;
	}

	@Override
	public void setStatus(int status) {
		_status = status;

		if (_setupRemoteModel != null) {
			try {
				Class<?> clazz = _setupRemoteModel.getClass();

				Method method = clazz.getMethod("setStatus", int.class);

				method.invoke(_setupRemoteModel, status);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getUpdated_timestamp() {
		return _updated_timestamp;
	}

	@Override
	public void setUpdated_timestamp(Date updated_timestamp) {
		_updated_timestamp = updated_timestamp;

		if (_setupRemoteModel != null) {
			try {
				Class<?> clazz = _setupRemoteModel.getClass();

				Method method = clazz.getMethod("setUpdated_timestamp",
						Date.class);

				method.invoke(_setupRemoteModel, updated_timestamp);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getSetupRemoteModel() {
		return _setupRemoteModel;
	}

	public void setSetupRemoteModel(BaseModel<?> setupRemoteModel) {
		_setupRemoteModel = setupRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _setupRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_setupRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			SetupLocalServiceUtil.addSetup(this);
		}
		else {
			SetupLocalServiceUtil.updateSetup(this);
		}
	}

	@Override
	public Setup toEscapedModel() {
		return (Setup)ProxyUtil.newProxyInstance(Setup.class.getClassLoader(),
			new Class[] { Setup.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		SetupClp clone = new SetupClp();

		clone.setSetup_id(getSetup_id());
		clone.setKey(getKey());
		clone.setVal1(getVal1());
		clone.setVal2(getVal2());
		clone.setStatus(getStatus());
		clone.setUpdated_timestamp(getUpdated_timestamp());

		return clone;
	}

	@Override
	public int compareTo(Setup setup) {
		long primaryKey = setup.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof SetupClp)) {
			return false;
		}

		SetupClp setup = (SetupClp)obj;

		long primaryKey = setup.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{setup_id=");
		sb.append(getSetup_id());
		sb.append(", key=");
		sb.append(getKey());
		sb.append(", val1=");
		sb.append(getVal1());
		sb.append(", val2=");
		sb.append(getVal2());
		sb.append(", status=");
		sb.append(getStatus());
		sb.append(", updated_timestamp=");
		sb.append(getUpdated_timestamp());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(22);

		sb.append("<model><model-name>");
		sb.append("com.jioc.query.model.Setup");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>setup_id</column-name><column-value><![CDATA[");
		sb.append(getSetup_id());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>key</column-name><column-value><![CDATA[");
		sb.append(getKey());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>val1</column-name><column-value><![CDATA[");
		sb.append(getVal1());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>val2</column-name><column-value><![CDATA[");
		sb.append(getVal2());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>status</column-name><column-value><![CDATA[");
		sb.append(getStatus());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>updated_timestamp</column-name><column-value><![CDATA[");
		sb.append(getUpdated_timestamp());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _setup_id;
	private String _key;
	private String _val1;
	private String _val2;
	private int _status;
	private Date _updated_timestamp;
	private BaseModel<?> _setupRemoteModel;
	private Class<?> _clpSerializerClass = com.jioc.query.service.ClpSerializer.class;
}