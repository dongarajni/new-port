/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Article}.
 * </p>
 *
 * @author shantaram.chavan
 * @see Article
 * @generated
 */
public class ArticleWrapper implements Article, ModelWrapper<Article> {
	public ArticleWrapper(Article article) {
		_article = article;
	}

	@Override
	public Class<?> getModelClass() {
		return Article.class;
	}

	@Override
	public String getModelClassName() {
		return Article.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("articleId", getArticleId());
		attributes.put("title", getTitle());
		attributes.put("description", getDescription());
		attributes.put("createdBy", getCreatedBy());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long articleId = (Long)attributes.get("articleId");

		if (articleId != null) {
			setArticleId(articleId);
		}

		String title = (String)attributes.get("title");

		if (title != null) {
			setTitle(title);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}

		Long createdBy = (Long)attributes.get("createdBy");

		if (createdBy != null) {
			setCreatedBy(createdBy);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}
	}

	/**
	* Returns the primary key of this article.
	*
	* @return the primary key of this article
	*/
	@Override
	public long getPrimaryKey() {
		return _article.getPrimaryKey();
	}

	/**
	* Sets the primary key of this article.
	*
	* @param primaryKey the primary key of this article
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_article.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the article ID of this article.
	*
	* @return the article ID of this article
	*/
	@Override
	public long getArticleId() {
		return _article.getArticleId();
	}

	/**
	* Sets the article ID of this article.
	*
	* @param articleId the article ID of this article
	*/
	@Override
	public void setArticleId(long articleId) {
		_article.setArticleId(articleId);
	}

	/**
	* Returns the title of this article.
	*
	* @return the title of this article
	*/
	@Override
	public java.lang.String getTitle() {
		return _article.getTitle();
	}

	/**
	* Sets the title of this article.
	*
	* @param title the title of this article
	*/
	@Override
	public void setTitle(java.lang.String title) {
		_article.setTitle(title);
	}

	/**
	* Returns the description of this article.
	*
	* @return the description of this article
	*/
	@Override
	public java.lang.String getDescription() {
		return _article.getDescription();
	}

	/**
	* Sets the description of this article.
	*
	* @param description the description of this article
	*/
	@Override
	public void setDescription(java.lang.String description) {
		_article.setDescription(description);
	}

	/**
	* Returns the created by of this article.
	*
	* @return the created by of this article
	*/
	@Override
	public long getCreatedBy() {
		return _article.getCreatedBy();
	}

	/**
	* Sets the created by of this article.
	*
	* @param createdBy the created by of this article
	*/
	@Override
	public void setCreatedBy(long createdBy) {
		_article.setCreatedBy(createdBy);
	}

	/**
	* Returns the create date of this article.
	*
	* @return the create date of this article
	*/
	@Override
	public java.util.Date getCreateDate() {
		return _article.getCreateDate();
	}

	/**
	* Sets the create date of this article.
	*
	* @param createDate the create date of this article
	*/
	@Override
	public void setCreateDate(java.util.Date createDate) {
		_article.setCreateDate(createDate);
	}

	/**
	* Returns the modified date of this article.
	*
	* @return the modified date of this article
	*/
	@Override
	public java.util.Date getModifiedDate() {
		return _article.getModifiedDate();
	}

	/**
	* Sets the modified date of this article.
	*
	* @param modifiedDate the modified date of this article
	*/
	@Override
	public void setModifiedDate(java.util.Date modifiedDate) {
		_article.setModifiedDate(modifiedDate);
	}

	@Override
	public boolean isNew() {
		return _article.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_article.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _article.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_article.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _article.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _article.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_article.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _article.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_article.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_article.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_article.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new ArticleWrapper((Article)_article.clone());
	}

	@Override
	public int compareTo(com.jioc.query.model.Article article) {
		return _article.compareTo(article);
	}

	@Override
	public int hashCode() {
		return _article.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jioc.query.model.Article> toCacheModel() {
		return _article.toCacheModel();
	}

	@Override
	public com.jioc.query.model.Article toEscapedModel() {
		return new ArticleWrapper(_article.toEscapedModel());
	}

	@Override
	public com.jioc.query.model.Article toUnescapedModel() {
		return new ArticleWrapper(_article.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _article.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _article.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_article.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof ArticleWrapper)) {
			return false;
		}

		ArticleWrapper articleWrapper = (ArticleWrapper)obj;

		if (Validator.equals(_article, articleWrapper._article)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public Article getWrappedArticle() {
		return _article;
	}

	@Override
	public Article getWrappedModel() {
		return _article;
	}

	@Override
	public void resetOriginalValues() {
		_article.resetOriginalValues();
	}

	private Article _article;
}