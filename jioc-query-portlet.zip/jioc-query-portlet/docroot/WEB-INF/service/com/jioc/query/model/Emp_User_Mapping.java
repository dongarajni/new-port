/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.liferay.portal.model.PersistedModel;

/**
 * The extended model interface for the Emp_User_Mapping service. Represents a row in the &quot;jioc_Emp_User_Mapping&quot; database table, with each column mapped to a property of this class.
 *
 * @author shantaram.chavan
 * @see Emp_User_MappingModel
 * @see com.jioc.query.model.impl.Emp_User_MappingImpl
 * @see com.jioc.query.model.impl.Emp_User_MappingModelImpl
 * @generated
 */
public interface Emp_User_Mapping extends Emp_User_MappingModel, PersistedModel {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this interface directly. Add methods to {@link com.jioc.query.model.impl.Emp_User_MappingImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
	 */
}