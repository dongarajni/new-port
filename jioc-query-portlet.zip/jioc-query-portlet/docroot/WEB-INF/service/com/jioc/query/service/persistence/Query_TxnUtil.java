/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.model.Query_Txn;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import java.util.List;

/**
 * The persistence utility for the query_ txn service. This utility wraps {@link Query_TxnPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see Query_TxnPersistence
 * @see Query_TxnPersistenceImpl
 * @generated
 */
public class Query_TxnUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(Query_Txn query_Txn) {
		getPersistence().clearCache(query_Txn);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<Query_Txn> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<Query_Txn> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<Query_Txn> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static Query_Txn update(Query_Txn query_Txn)
		throws SystemException {
		return getPersistence().update(query_Txn);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static Query_Txn update(Query_Txn query_Txn,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(query_Txn, serviceContext);
	}

	/**
	* Caches the query_ txn in the entity cache if it is enabled.
	*
	* @param query_Txn the query_ txn
	*/
	public static void cacheResult(com.jioc.query.model.Query_Txn query_Txn) {
		getPersistence().cacheResult(query_Txn);
	}

	/**
	* Caches the query_ txns in the entity cache if it is enabled.
	*
	* @param query_Txns the query_ txns
	*/
	public static void cacheResult(
		java.util.List<com.jioc.query.model.Query_Txn> query_Txns) {
		getPersistence().cacheResult(query_Txns);
	}

	/**
	* Creates a new query_ txn with the primary key. Does not add the query_ txn to the database.
	*
	* @param queryId the primary key for the new query_ txn
	* @return the new query_ txn
	*/
	public static com.jioc.query.model.Query_Txn create(long queryId) {
		return getPersistence().create(queryId);
	}

	/**
	* Removes the query_ txn with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param queryId the primary key of the query_ txn
	* @return the query_ txn that was removed
	* @throws com.jioc.query.NoSuchQuery_TxnException if a query_ txn with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Txn remove(long queryId)
		throws com.jioc.query.NoSuchQuery_TxnException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().remove(queryId);
	}

	public static com.jioc.query.model.Query_Txn updateImpl(
		com.jioc.query.model.Query_Txn query_Txn)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(query_Txn);
	}

	/**
	* Returns the query_ txn with the primary key or throws a {@link com.jioc.query.NoSuchQuery_TxnException} if it could not be found.
	*
	* @param queryId the primary key of the query_ txn
	* @return the query_ txn
	* @throws com.jioc.query.NoSuchQuery_TxnException if a query_ txn with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Txn findByPrimaryKey(long queryId)
		throws com.jioc.query.NoSuchQuery_TxnException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPrimaryKey(queryId);
	}

	/**
	* Returns the query_ txn with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param queryId the primary key of the query_ txn
	* @return the query_ txn, or <code>null</code> if a query_ txn with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Txn fetchByPrimaryKey(long queryId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(queryId);
	}

	/**
	* Returns all the query_ txns.
	*
	* @return the query_ txns
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Txn> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the query_ txns.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TxnModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of query_ txns
	* @param end the upper bound of the range of query_ txns (not inclusive)
	* @return the range of query_ txns
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Txn> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the query_ txns.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TxnModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of query_ txns
	* @param end the upper bound of the range of query_ txns (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of query_ txns
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Txn> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the query_ txns from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of query_ txns.
	*
	* @return the number of query_ txns
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static Query_TxnPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (Query_TxnPersistence)PortletBeanLocatorUtil.locate(com.jioc.query.service.ClpSerializer.getServletContextName(),
					Query_TxnPersistence.class.getName());

			ReferenceRegistry.registerReference(Query_TxnUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(Query_TxnPersistence persistence) {
	}

	private static Query_TxnPersistence _persistence;
}