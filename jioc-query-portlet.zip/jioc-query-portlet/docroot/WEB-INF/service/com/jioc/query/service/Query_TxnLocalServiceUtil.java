/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableLocalService;

/**
 * Provides the local service utility for Query_Txn. This utility wraps
 * {@link com.jioc.query.service.impl.Query_TxnLocalServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author shantaram.chavan
 * @see Query_TxnLocalService
 * @see com.jioc.query.service.base.Query_TxnLocalServiceBaseImpl
 * @see com.jioc.query.service.impl.Query_TxnLocalServiceImpl
 * @generated
 */
public class Query_TxnLocalServiceUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to {@link com.jioc.query.service.impl.Query_TxnLocalServiceImpl} and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	* Adds the query_ txn to the database. Also notifies the appropriate model listeners.
	*
	* @param query_Txn the query_ txn
	* @return the query_ txn that was added
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Txn addQuery_Txn(
		com.jioc.query.model.Query_Txn query_Txn)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().addQuery_Txn(query_Txn);
	}

	/**
	* Creates a new query_ txn with the primary key. Does not add the query_ txn to the database.
	*
	* @param queryId the primary key for the new query_ txn
	* @return the new query_ txn
	*/
	public static com.jioc.query.model.Query_Txn createQuery_Txn(long queryId) {
		return getService().createQuery_Txn(queryId);
	}

	/**
	* Deletes the query_ txn with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param queryId the primary key of the query_ txn
	* @return the query_ txn that was removed
	* @throws PortalException if a query_ txn with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Txn deleteQuery_Txn(long queryId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteQuery_Txn(queryId);
	}

	/**
	* Deletes the query_ txn from the database. Also notifies the appropriate model listeners.
	*
	* @param query_Txn the query_ txn
	* @return the query_ txn that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Txn deleteQuery_Txn(
		com.jioc.query.model.Query_Txn query_Txn)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteQuery_Txn(query_Txn);
	}

	public static com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TxnModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TxnModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static com.jioc.query.model.Query_Txn fetchQuery_Txn(long queryId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().fetchQuery_Txn(queryId);
	}

	/**
	* Returns the query_ txn with the primary key.
	*
	* @param queryId the primary key of the query_ txn
	* @return the query_ txn
	* @throws PortalException if a query_ txn with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Txn getQuery_Txn(long queryId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getQuery_Txn(queryId);
	}

	public static com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the query_ txns.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_TxnModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of query_ txns
	* @param end the upper bound of the range of query_ txns (not inclusive)
	* @return the range of query_ txns
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Txn> getQuery_Txns(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getQuery_Txns(start, end);
	}

	/**
	* Returns the number of query_ txns.
	*
	* @return the number of query_ txns
	* @throws SystemException if a system exception occurred
	*/
	public static int getQuery_TxnsCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getQuery_TxnsCount();
	}

	/**
	* Updates the query_ txn in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param query_Txn the query_ txn
	* @return the query_ txn that was updated
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Txn updateQuery_Txn(
		com.jioc.query.model.Query_Txn query_Txn)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().updateQuery_Txn(query_Txn);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	public static java.lang.String getBeanIdentifier() {
		return getService().getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	public static void setBeanIdentifier(java.lang.String beanIdentifier) {
		getService().setBeanIdentifier(beanIdentifier);
	}

	public static java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return getService().invokeMethod(name, parameterTypes, arguments);
	}

	public static void clearService() {
		_service = null;
	}

	public static Query_TxnLocalService getService() {
		if (_service == null) {
			InvokableLocalService invokableLocalService = (InvokableLocalService)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
					Query_TxnLocalService.class.getName());

			if (invokableLocalService instanceof Query_TxnLocalService) {
				_service = (Query_TxnLocalService)invokableLocalService;
			}
			else {
				_service = new Query_TxnLocalServiceClp(invokableLocalService);
			}

			ReferenceRegistry.registerReference(Query_TxnLocalServiceUtil.class,
				"_service");
		}

		return _service;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setService(Query_TxnLocalService service) {
	}

	private static Query_TxnLocalService _service;
}