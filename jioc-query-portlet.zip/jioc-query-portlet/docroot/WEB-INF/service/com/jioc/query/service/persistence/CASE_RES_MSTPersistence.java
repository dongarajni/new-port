/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.model.CASE_RES_MST;

import com.liferay.portal.service.persistence.BasePersistence;

/**
 * The persistence interface for the c a s e_ r e s_ m s t service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see CASE_RES_MSTPersistenceImpl
 * @see CASE_RES_MSTUtil
 * @generated
 */
public interface CASE_RES_MSTPersistence extends BasePersistence<CASE_RES_MST> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link CASE_RES_MSTUtil} to access the c a s e_ r e s_ m s t persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Caches the c a s e_ r e s_ m s t in the entity cache if it is enabled.
	*
	* @param case_res_mst the c a s e_ r e s_ m s t
	*/
	public void cacheResult(com.jioc.query.model.CASE_RES_MST case_res_mst);

	/**
	* Caches the c a s e_ r e s_ m s ts in the entity cache if it is enabled.
	*
	* @param case_res_msts the c a s e_ r e s_ m s ts
	*/
	public void cacheResult(
		java.util.List<com.jioc.query.model.CASE_RES_MST> case_res_msts);

	/**
	* Creates a new c a s e_ r e s_ m s t with the primary key. Does not add the c a s e_ r e s_ m s t to the database.
	*
	* @param CASE_RES_ID the primary key for the new c a s e_ r e s_ m s t
	* @return the new c a s e_ r e s_ m s t
	*/
	public com.jioc.query.model.CASE_RES_MST create(long CASE_RES_ID);

	/**
	* Removes the c a s e_ r e s_ m s t with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param CASE_RES_ID the primary key of the c a s e_ r e s_ m s t
	* @return the c a s e_ r e s_ m s t that was removed
	* @throws com.jioc.query.NoSuchCASE_RES_MSTException if a c a s e_ r e s_ m s t with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.CASE_RES_MST remove(long CASE_RES_ID)
		throws com.jioc.query.NoSuchCASE_RES_MSTException,
			com.liferay.portal.kernel.exception.SystemException;

	public com.jioc.query.model.CASE_RES_MST updateImpl(
		com.jioc.query.model.CASE_RES_MST case_res_mst)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the c a s e_ r e s_ m s t with the primary key or throws a {@link com.jioc.query.NoSuchCASE_RES_MSTException} if it could not be found.
	*
	* @param CASE_RES_ID the primary key of the c a s e_ r e s_ m s t
	* @return the c a s e_ r e s_ m s t
	* @throws com.jioc.query.NoSuchCASE_RES_MSTException if a c a s e_ r e s_ m s t with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.CASE_RES_MST findByPrimaryKey(long CASE_RES_ID)
		throws com.jioc.query.NoSuchCASE_RES_MSTException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the c a s e_ r e s_ m s t with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param CASE_RES_ID the primary key of the c a s e_ r e s_ m s t
	* @return the c a s e_ r e s_ m s t, or <code>null</code> if a c a s e_ r e s_ m s t with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.CASE_RES_MST fetchByPrimaryKey(long CASE_RES_ID)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the c a s e_ r e s_ m s ts.
	*
	* @return the c a s e_ r e s_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.CASE_RES_MST> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the c a s e_ r e s_ m s ts.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.CASE_RES_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of c a s e_ r e s_ m s ts
	* @param end the upper bound of the range of c a s e_ r e s_ m s ts (not inclusive)
	* @return the range of c a s e_ r e s_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.CASE_RES_MST> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the c a s e_ r e s_ m s ts.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.CASE_RES_MSTModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of c a s e_ r e s_ m s ts
	* @param end the upper bound of the range of c a s e_ r e s_ m s ts (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of c a s e_ r e s_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.CASE_RES_MST> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the c a s e_ r e s_ m s ts from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of c a s e_ r e s_ m s ts.
	*
	* @return the number of c a s e_ r e s_ m s ts
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}