/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service;

import com.jioc.query.model.ArticleClp;
import com.jioc.query.model.CASE_RES_MSTClp;
import com.jioc.query.model.EMP_DETAILSClp;
import com.jioc.query.model.Emp_User_MappingClp;
import com.jioc.query.model.OC_CAT_MSTClp;
import com.jioc.query.model.OC_JOB_FUNCTION_MSTClp;
import com.jioc.query.model.OC_SUB_CAT_MSTClp;
import com.jioc.query.model.QUERY_MOD_DEFAULTSClp;
import com.jioc.query.model.Query_Add_Param_OCClp;
import com.jioc.query.model.Query_AttachmentsClp;
import com.jioc.query.model.Query_DetailsClp;
import com.jioc.query.model.Query_TransactionClp;
import com.jioc.query.model.RESOLVER_DEFAULTSClp;
import com.jioc.query.model.RESOLVER_LEVEL_MSTClp;
import com.jioc.query.model.SetupClp;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.io.unsync.UnsyncByteArrayInputStream;
import com.liferay.portal.kernel.io.unsync.UnsyncByteArrayOutputStream;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.ClassLoaderObjectInputStream;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.BaseModel;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import java.lang.reflect.Method;

import java.util.ArrayList;
import java.util.List;

/**
 * @author shantaram.chavan
 */
public class ClpSerializer {
	public static String getServletContextName() {
		if (Validator.isNotNull(_servletContextName)) {
			return _servletContextName;
		}

		synchronized (ClpSerializer.class) {
			if (Validator.isNotNull(_servletContextName)) {
				return _servletContextName;
			}

			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Class<?> portletPropsClass = classLoader.loadClass(
						"com.liferay.util.portlet.PortletProps");

				Method getMethod = portletPropsClass.getMethod("get",
						new Class<?>[] { String.class });

				String portletPropsServletContextName = (String)getMethod.invoke(null,
						"jioc-query-portlet-deployment-context");

				if (Validator.isNotNull(portletPropsServletContextName)) {
					_servletContextName = portletPropsServletContextName;
				}
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info(
						"Unable to locate deployment context from portlet properties");
				}
			}

			if (Validator.isNull(_servletContextName)) {
				try {
					String propsUtilServletContextName = PropsUtil.get(
							"jioc-query-portlet-deployment-context");

					if (Validator.isNotNull(propsUtilServletContextName)) {
						_servletContextName = propsUtilServletContextName;
					}
				}
				catch (Throwable t) {
					if (_log.isInfoEnabled()) {
						_log.info(
							"Unable to locate deployment context from portal properties");
					}
				}
			}

			if (Validator.isNull(_servletContextName)) {
				_servletContextName = "jioc-query-portlet";
			}

			return _servletContextName;
		}
	}

	public static Object translateInput(BaseModel<?> oldModel) {
		Class<?> oldModelClass = oldModel.getClass();

		String oldModelClassName = oldModelClass.getName();

		if (oldModelClassName.equals(ArticleClp.class.getName())) {
			return translateInputArticle(oldModel);
		}

		if (oldModelClassName.equals(CASE_RES_MSTClp.class.getName())) {
			return translateInputCASE_RES_MST(oldModel);
		}

		if (oldModelClassName.equals(EMP_DETAILSClp.class.getName())) {
			return translateInputEMP_DETAILS(oldModel);
		}

		if (oldModelClassName.equals(Emp_User_MappingClp.class.getName())) {
			return translateInputEmp_User_Mapping(oldModel);
		}

		if (oldModelClassName.equals(OC_CAT_MSTClp.class.getName())) {
			return translateInputOC_CAT_MST(oldModel);
		}

		if (oldModelClassName.equals(OC_JOB_FUNCTION_MSTClp.class.getName())) {
			return translateInputOC_JOB_FUNCTION_MST(oldModel);
		}

		if (oldModelClassName.equals(OC_SUB_CAT_MSTClp.class.getName())) {
			return translateInputOC_SUB_CAT_MST(oldModel);
		}

		if (oldModelClassName.equals(Query_Add_Param_OCClp.class.getName())) {
			return translateInputQuery_Add_Param_OC(oldModel);
		}

		if (oldModelClassName.equals(Query_AttachmentsClp.class.getName())) {
			return translateInputQuery_Attachments(oldModel);
		}

		if (oldModelClassName.equals(Query_DetailsClp.class.getName())) {
			return translateInputQuery_Details(oldModel);
		}

		if (oldModelClassName.equals(QUERY_MOD_DEFAULTSClp.class.getName())) {
			return translateInputQUERY_MOD_DEFAULTS(oldModel);
		}

		if (oldModelClassName.equals(Query_TransactionClp.class.getName())) {
			return translateInputQuery_Transaction(oldModel);
		}

		if (oldModelClassName.equals(RESOLVER_DEFAULTSClp.class.getName())) {
			return translateInputRESOLVER_DEFAULTS(oldModel);
		}

		if (oldModelClassName.equals(RESOLVER_LEVEL_MSTClp.class.getName())) {
			return translateInputRESOLVER_LEVEL_MST(oldModel);
		}

		if (oldModelClassName.equals(SetupClp.class.getName())) {
			return translateInputSetup(oldModel);
		}

		return oldModel;
	}

	public static Object translateInput(List<Object> oldList) {
		List<Object> newList = new ArrayList<Object>(oldList.size());

		for (int i = 0; i < oldList.size(); i++) {
			Object curObj = oldList.get(i);

			newList.add(translateInput(curObj));
		}

		return newList;
	}

	public static Object translateInputArticle(BaseModel<?> oldModel) {
		ArticleClp oldClpModel = (ArticleClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getArticleRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputCASE_RES_MST(BaseModel<?> oldModel) {
		CASE_RES_MSTClp oldClpModel = (CASE_RES_MSTClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getCASE_RES_MSTRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputEMP_DETAILS(BaseModel<?> oldModel) {
		EMP_DETAILSClp oldClpModel = (EMP_DETAILSClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getEMP_DETAILSRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputEmp_User_Mapping(BaseModel<?> oldModel) {
		Emp_User_MappingClp oldClpModel = (Emp_User_MappingClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getEmp_User_MappingRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputOC_CAT_MST(BaseModel<?> oldModel) {
		OC_CAT_MSTClp oldClpModel = (OC_CAT_MSTClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getOC_CAT_MSTRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputOC_JOB_FUNCTION_MST(
		BaseModel<?> oldModel) {
		OC_JOB_FUNCTION_MSTClp oldClpModel = (OC_JOB_FUNCTION_MSTClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getOC_JOB_FUNCTION_MSTRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputOC_SUB_CAT_MST(BaseModel<?> oldModel) {
		OC_SUB_CAT_MSTClp oldClpModel = (OC_SUB_CAT_MSTClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getOC_SUB_CAT_MSTRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputQuery_Add_Param_OC(BaseModel<?> oldModel) {
		Query_Add_Param_OCClp oldClpModel = (Query_Add_Param_OCClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getQuery_Add_Param_OCRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputQuery_Attachments(BaseModel<?> oldModel) {
		Query_AttachmentsClp oldClpModel = (Query_AttachmentsClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getQuery_AttachmentsRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputQuery_Details(BaseModel<?> oldModel) {
		Query_DetailsClp oldClpModel = (Query_DetailsClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getQuery_DetailsRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputQUERY_MOD_DEFAULTS(BaseModel<?> oldModel) {
		QUERY_MOD_DEFAULTSClp oldClpModel = (QUERY_MOD_DEFAULTSClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getQUERY_MOD_DEFAULTSRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputQuery_Transaction(BaseModel<?> oldModel) {
		Query_TransactionClp oldClpModel = (Query_TransactionClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getQuery_TransactionRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputRESOLVER_DEFAULTS(BaseModel<?> oldModel) {
		RESOLVER_DEFAULTSClp oldClpModel = (RESOLVER_DEFAULTSClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getRESOLVER_DEFAULTSRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputRESOLVER_LEVEL_MST(BaseModel<?> oldModel) {
		RESOLVER_LEVEL_MSTClp oldClpModel = (RESOLVER_LEVEL_MSTClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getRESOLVER_LEVEL_MSTRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputSetup(BaseModel<?> oldModel) {
		SetupClp oldClpModel = (SetupClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getSetupRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInput(Object obj) {
		if (obj instanceof BaseModel<?>) {
			return translateInput((BaseModel<?>)obj);
		}
		else if (obj instanceof List<?>) {
			return translateInput((List<Object>)obj);
		}
		else {
			return obj;
		}
	}

	public static Object translateOutput(BaseModel<?> oldModel) {
		Class<?> oldModelClass = oldModel.getClass();

		String oldModelClassName = oldModelClass.getName();

		if (oldModelClassName.equals("com.jioc.query.model.impl.ArticleImpl")) {
			return translateOutputArticle(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.jioc.query.model.impl.CASE_RES_MSTImpl")) {
			return translateOutputCASE_RES_MST(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.jioc.query.model.impl.EMP_DETAILSImpl")) {
			return translateOutputEMP_DETAILS(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.jioc.query.model.impl.Emp_User_MappingImpl")) {
			return translateOutputEmp_User_Mapping(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals("com.jioc.query.model.impl.OC_CAT_MSTImpl")) {
			return translateOutputOC_CAT_MST(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.jioc.query.model.impl.OC_JOB_FUNCTION_MSTImpl")) {
			return translateOutputOC_JOB_FUNCTION_MST(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.jioc.query.model.impl.OC_SUB_CAT_MSTImpl")) {
			return translateOutputOC_SUB_CAT_MST(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.jioc.query.model.impl.Query_Add_Param_OCImpl")) {
			return translateOutputQuery_Add_Param_OC(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.jioc.query.model.impl.Query_AttachmentsImpl")) {
			return translateOutputQuery_Attachments(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.jioc.query.model.impl.Query_DetailsImpl")) {
			return translateOutputQuery_Details(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.jioc.query.model.impl.QUERY_MOD_DEFAULTSImpl")) {
			return translateOutputQUERY_MOD_DEFAULTS(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.jioc.query.model.impl.Query_TransactionImpl")) {
			return translateOutputQuery_Transaction(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.jioc.query.model.impl.RESOLVER_DEFAULTSImpl")) {
			return translateOutputRESOLVER_DEFAULTS(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.jioc.query.model.impl.RESOLVER_LEVEL_MSTImpl")) {
			return translateOutputRESOLVER_LEVEL_MST(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals("com.jioc.query.model.impl.SetupImpl")) {
			return translateOutputSetup(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		return oldModel;
	}

	public static Object translateOutput(List<Object> oldList) {
		List<Object> newList = new ArrayList<Object>(oldList.size());

		for (int i = 0; i < oldList.size(); i++) {
			Object curObj = oldList.get(i);

			newList.add(translateOutput(curObj));
		}

		return newList;
	}

	public static Object translateOutput(Object obj) {
		if (obj instanceof BaseModel<?>) {
			return translateOutput((BaseModel<?>)obj);
		}
		else if (obj instanceof List<?>) {
			return translateOutput((List<Object>)obj);
		}
		else {
			return obj;
		}
	}

	public static Throwable translateThrowable(Throwable throwable) {
		if (_useReflectionToTranslateThrowable) {
			try {
				UnsyncByteArrayOutputStream unsyncByteArrayOutputStream = new UnsyncByteArrayOutputStream();
				ObjectOutputStream objectOutputStream = new ObjectOutputStream(unsyncByteArrayOutputStream);

				objectOutputStream.writeObject(throwable);

				objectOutputStream.flush();
				objectOutputStream.close();

				UnsyncByteArrayInputStream unsyncByteArrayInputStream = new UnsyncByteArrayInputStream(unsyncByteArrayOutputStream.unsafeGetByteArray(),
						0, unsyncByteArrayOutputStream.size());

				Thread currentThread = Thread.currentThread();

				ClassLoader contextClassLoader = currentThread.getContextClassLoader();

				ObjectInputStream objectInputStream = new ClassLoaderObjectInputStream(unsyncByteArrayInputStream,
						contextClassLoader);

				throwable = (Throwable)objectInputStream.readObject();

				objectInputStream.close();

				return throwable;
			}
			catch (SecurityException se) {
				if (_log.isInfoEnabled()) {
					_log.info("Do not use reflection to translate throwable");
				}

				_useReflectionToTranslateThrowable = false;
			}
			catch (Throwable throwable2) {
				_log.error(throwable2, throwable2);

				return throwable2;
			}
		}

		Class<?> clazz = throwable.getClass();

		String className = clazz.getName();

		if (className.equals(PortalException.class.getName())) {
			return new PortalException();
		}

		if (className.equals(SystemException.class.getName())) {
			return new SystemException();
		}

		if (className.equals("com.jioc.query.NoSuchArticleException")) {
			return new com.jioc.query.NoSuchArticleException();
		}

		if (className.equals("com.jioc.query.NoSuchCASE_RES_MSTException")) {
			return new com.jioc.query.NoSuchCASE_RES_MSTException();
		}

		if (className.equals("com.jioc.query.NoSuchEMP_DETAILSException")) {
			return new com.jioc.query.NoSuchEMP_DETAILSException();
		}

		if (className.equals("com.jioc.query.NoSuchEmp_User_MappingException")) {
			return new com.jioc.query.NoSuchEmp_User_MappingException();
		}

		if (className.equals("com.jioc.query.NoSuchOC_CAT_MSTException")) {
			return new com.jioc.query.NoSuchOC_CAT_MSTException();
		}

		if (className.equals(
					"com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException")) {
			return new com.jioc.query.NoSuchOC_JOB_FUNCTION_MSTException();
		}

		if (className.equals("com.jioc.query.NoSuchOC_SUB_CAT_MSTException")) {
			return new com.jioc.query.NoSuchOC_SUB_CAT_MSTException();
		}

		if (className.equals("com.jioc.query.NoSuchQuery_Add_Param_OCException")) {
			return new com.jioc.query.NoSuchQuery_Add_Param_OCException();
		}

		if (className.equals("com.jioc.query.NoSuchQuery_AttachmentsException")) {
			return new com.jioc.query.NoSuchQuery_AttachmentsException();
		}

		if (className.equals("com.jioc.query.NoSuchQuery_DetailsException")) {
			return new com.jioc.query.NoSuchQuery_DetailsException();
		}

		if (className.equals("com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException")) {
			return new com.jioc.query.NoSuchQUERY_MOD_DEFAULTSException();
		}

		if (className.equals("com.jioc.query.NoSuchQuery_TransactionException")) {
			return new com.jioc.query.NoSuchQuery_TransactionException();
		}

		if (className.equals("com.jioc.query.NoSuchRESOLVER_DEFAULTSException")) {
			return new com.jioc.query.NoSuchRESOLVER_DEFAULTSException();
		}

		if (className.equals("com.jioc.query.NoSuchRESOLVER_LEVEL_MSTException")) {
			return new com.jioc.query.NoSuchRESOLVER_LEVEL_MSTException();
		}

		if (className.equals("com.jioc.query.NoSuchSetupException")) {
			return new com.jioc.query.NoSuchSetupException();
		}

		return throwable;
	}

	public static Object translateOutputArticle(BaseModel<?> oldModel) {
		ArticleClp newModel = new ArticleClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setArticleRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputCASE_RES_MST(BaseModel<?> oldModel) {
		CASE_RES_MSTClp newModel = new CASE_RES_MSTClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setCASE_RES_MSTRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputEMP_DETAILS(BaseModel<?> oldModel) {
		EMP_DETAILSClp newModel = new EMP_DETAILSClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setEMP_DETAILSRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputEmp_User_Mapping(BaseModel<?> oldModel) {
		Emp_User_MappingClp newModel = new Emp_User_MappingClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setEmp_User_MappingRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputOC_CAT_MST(BaseModel<?> oldModel) {
		OC_CAT_MSTClp newModel = new OC_CAT_MSTClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setOC_CAT_MSTRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputOC_JOB_FUNCTION_MST(
		BaseModel<?> oldModel) {
		OC_JOB_FUNCTION_MSTClp newModel = new OC_JOB_FUNCTION_MSTClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setOC_JOB_FUNCTION_MSTRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputOC_SUB_CAT_MST(BaseModel<?> oldModel) {
		OC_SUB_CAT_MSTClp newModel = new OC_SUB_CAT_MSTClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setOC_SUB_CAT_MSTRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputQuery_Add_Param_OC(
		BaseModel<?> oldModel) {
		Query_Add_Param_OCClp newModel = new Query_Add_Param_OCClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setQuery_Add_Param_OCRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputQuery_Attachments(BaseModel<?> oldModel) {
		Query_AttachmentsClp newModel = new Query_AttachmentsClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setQuery_AttachmentsRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputQuery_Details(BaseModel<?> oldModel) {
		Query_DetailsClp newModel = new Query_DetailsClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setQuery_DetailsRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputQUERY_MOD_DEFAULTS(
		BaseModel<?> oldModel) {
		QUERY_MOD_DEFAULTSClp newModel = new QUERY_MOD_DEFAULTSClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setQUERY_MOD_DEFAULTSRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputQuery_Transaction(BaseModel<?> oldModel) {
		Query_TransactionClp newModel = new Query_TransactionClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setQuery_TransactionRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputRESOLVER_DEFAULTS(BaseModel<?> oldModel) {
		RESOLVER_DEFAULTSClp newModel = new RESOLVER_DEFAULTSClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setRESOLVER_DEFAULTSRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputRESOLVER_LEVEL_MST(
		BaseModel<?> oldModel) {
		RESOLVER_LEVEL_MSTClp newModel = new RESOLVER_LEVEL_MSTClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setRESOLVER_LEVEL_MSTRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputSetup(BaseModel<?> oldModel) {
		SetupClp newModel = new SetupClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setSetupRemoteModel(oldModel);

		return newModel;
	}

	private static Log _log = LogFactoryUtil.getLog(ClpSerializer.class);
	private static String _servletContextName;
	private static boolean _useReflectionToTranslateThrowable = true;
}