/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author shantaram.chavan
 * @generated
 */
public class RESOLVER_LEVEL_MSTSoap implements Serializable {
	public static RESOLVER_LEVEL_MSTSoap toSoapModel(RESOLVER_LEVEL_MST model) {
		RESOLVER_LEVEL_MSTSoap soapModel = new RESOLVER_LEVEL_MSTSoap();

		soapModel.setLEVEL_ID(model.getLEVEL_ID());
		soapModel.setLEVEL_NAME(model.getLEVEL_NAME());
		soapModel.setRESOLVER_LEVEL(model.getRESOLVER_LEVEL());

		return soapModel;
	}

	public static RESOLVER_LEVEL_MSTSoap[] toSoapModels(
		RESOLVER_LEVEL_MST[] models) {
		RESOLVER_LEVEL_MSTSoap[] soapModels = new RESOLVER_LEVEL_MSTSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static RESOLVER_LEVEL_MSTSoap[][] toSoapModels(
		RESOLVER_LEVEL_MST[][] models) {
		RESOLVER_LEVEL_MSTSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new RESOLVER_LEVEL_MSTSoap[models.length][models[0].length];
		}
		else {
			soapModels = new RESOLVER_LEVEL_MSTSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static RESOLVER_LEVEL_MSTSoap[] toSoapModels(
		List<RESOLVER_LEVEL_MST> models) {
		List<RESOLVER_LEVEL_MSTSoap> soapModels = new ArrayList<RESOLVER_LEVEL_MSTSoap>(models.size());

		for (RESOLVER_LEVEL_MST model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new RESOLVER_LEVEL_MSTSoap[soapModels.size()]);
	}

	public RESOLVER_LEVEL_MSTSoap() {
	}

	public long getPrimaryKey() {
		return _LEVEL_ID;
	}

	public void setPrimaryKey(long pk) {
		setLEVEL_ID(pk);
	}

	public long getLEVEL_ID() {
		return _LEVEL_ID;
	}

	public void setLEVEL_ID(long LEVEL_ID) {
		_LEVEL_ID = LEVEL_ID;
	}

	public String getLEVEL_NAME() {
		return _LEVEL_NAME;
	}

	public void setLEVEL_NAME(String LEVEL_NAME) {
		_LEVEL_NAME = LEVEL_NAME;
	}

	public int getRESOLVER_LEVEL() {
		return _RESOLVER_LEVEL;
	}

	public void setRESOLVER_LEVEL(int RESOLVER_LEVEL) {
		_RESOLVER_LEVEL = RESOLVER_LEVEL;
	}

	private long _LEVEL_ID;
	private String _LEVEL_NAME;
	private int _RESOLVER_LEVEL;
}