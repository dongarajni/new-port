/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author shantaram.chavan
 * @generated
 */
public class RESOLVER_DEFAULTSSoap implements Serializable {
	public static RESOLVER_DEFAULTSSoap toSoapModel(RESOLVER_DEFAULTS model) {
		RESOLVER_DEFAULTSSoap soapModel = new RESOLVER_DEFAULTSSoap();

		soapModel.setDEFAULT_ID(model.getDEFAULT_ID());
		soapModel.setRESOLVER_LEVEL_ID(model.getRESOLVER_LEVEL_ID());
		soapModel.setTYPE(model.getTYPE());
		soapModel.setVALUE(model.getVALUE());
		soapModel.setTO_DISPLAY(model.getTO_DISPLAY());

		return soapModel;
	}

	public static RESOLVER_DEFAULTSSoap[] toSoapModels(
		RESOLVER_DEFAULTS[] models) {
		RESOLVER_DEFAULTSSoap[] soapModels = new RESOLVER_DEFAULTSSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static RESOLVER_DEFAULTSSoap[][] toSoapModels(
		RESOLVER_DEFAULTS[][] models) {
		RESOLVER_DEFAULTSSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new RESOLVER_DEFAULTSSoap[models.length][models[0].length];
		}
		else {
			soapModels = new RESOLVER_DEFAULTSSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static RESOLVER_DEFAULTSSoap[] toSoapModels(
		List<RESOLVER_DEFAULTS> models) {
		List<RESOLVER_DEFAULTSSoap> soapModels = new ArrayList<RESOLVER_DEFAULTSSoap>(models.size());

		for (RESOLVER_DEFAULTS model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new RESOLVER_DEFAULTSSoap[soapModels.size()]);
	}

	public RESOLVER_DEFAULTSSoap() {
	}

	public long getPrimaryKey() {
		return _DEFAULT_ID;
	}

	public void setPrimaryKey(long pk) {
		setDEFAULT_ID(pk);
	}

	public long getDEFAULT_ID() {
		return _DEFAULT_ID;
	}

	public void setDEFAULT_ID(long DEFAULT_ID) {
		_DEFAULT_ID = DEFAULT_ID;
	}

	public long getRESOLVER_LEVEL_ID() {
		return _RESOLVER_LEVEL_ID;
	}

	public void setRESOLVER_LEVEL_ID(long RESOLVER_LEVEL_ID) {
		_RESOLVER_LEVEL_ID = RESOLVER_LEVEL_ID;
	}

	public String getTYPE() {
		return _TYPE;
	}

	public void setTYPE(String TYPE) {
		_TYPE = TYPE;
	}

	public String getVALUE() {
		return _VALUE;
	}

	public void setVALUE(String VALUE) {
		_VALUE = VALUE;
	}

	public int getTO_DISPLAY() {
		return _TO_DISPLAY;
	}

	public void setTO_DISPLAY(int TO_DISPLAY) {
		_TO_DISPLAY = TO_DISPLAY;
	}

	private long _DEFAULT_ID;
	private long _RESOLVER_LEVEL_ID;
	private String _TYPE;
	private String _VALUE;
	private int _TO_DISPLAY;
}