/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link Query_AttachmentsLocalService}.
 *
 * @author shantaram.chavan
 * @see Query_AttachmentsLocalService
 * @generated
 */
public class Query_AttachmentsLocalServiceWrapper
	implements Query_AttachmentsLocalService,
		ServiceWrapper<Query_AttachmentsLocalService> {
	public Query_AttachmentsLocalServiceWrapper(
		Query_AttachmentsLocalService query_AttachmentsLocalService) {
		_query_AttachmentsLocalService = query_AttachmentsLocalService;
	}

	/**
	* Adds the query_ attachments to the database. Also notifies the appropriate model listeners.
	*
	* @param query_Attachments the query_ attachments
	* @return the query_ attachments that was added
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.jioc.query.model.Query_Attachments addQuery_Attachments(
		com.jioc.query.model.Query_Attachments query_Attachments)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _query_AttachmentsLocalService.addQuery_Attachments(query_Attachments);
	}

	/**
	* Creates a new query_ attachments with the primary key. Does not add the query_ attachments to the database.
	*
	* @param AttachmentId the primary key for the new query_ attachments
	* @return the new query_ attachments
	*/
	@Override
	public com.jioc.query.model.Query_Attachments createQuery_Attachments(
		long AttachmentId) {
		return _query_AttachmentsLocalService.createQuery_Attachments(AttachmentId);
	}

	/**
	* Deletes the query_ attachments with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param AttachmentId the primary key of the query_ attachments
	* @return the query_ attachments that was removed
	* @throws PortalException if a query_ attachments with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.jioc.query.model.Query_Attachments deleteQuery_Attachments(
		long AttachmentId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _query_AttachmentsLocalService.deleteQuery_Attachments(AttachmentId);
	}

	/**
	* Deletes the query_ attachments from the database. Also notifies the appropriate model listeners.
	*
	* @param query_Attachments the query_ attachments
	* @return the query_ attachments that was removed
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.jioc.query.model.Query_Attachments deleteQuery_Attachments(
		com.jioc.query.model.Query_Attachments query_Attachments)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _query_AttachmentsLocalService.deleteQuery_Attachments(query_Attachments);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _query_AttachmentsLocalService.dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _query_AttachmentsLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_AttachmentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return _query_AttachmentsLocalService.dynamicQuery(dynamicQuery, start,
			end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_AttachmentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _query_AttachmentsLocalService.dynamicQuery(dynamicQuery, start,
			end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _query_AttachmentsLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _query_AttachmentsLocalService.dynamicQueryCount(dynamicQuery,
			projection);
	}

	@Override
	public com.jioc.query.model.Query_Attachments fetchQuery_Attachments(
		long AttachmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _query_AttachmentsLocalService.fetchQuery_Attachments(AttachmentId);
	}

	/**
	* Returns the query_ attachments with the primary key.
	*
	* @param AttachmentId the primary key of the query_ attachments
	* @return the query_ attachments
	* @throws PortalException if a query_ attachments with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.jioc.query.model.Query_Attachments getQuery_Attachments(
		long AttachmentId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _query_AttachmentsLocalService.getQuery_Attachments(AttachmentId);
	}

	@Override
	public com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _query_AttachmentsLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the query_ attachmentses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_AttachmentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of query_ attachmentses
	* @param end the upper bound of the range of query_ attachmentses (not inclusive)
	* @return the range of query_ attachmentses
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.jioc.query.model.Query_Attachments> getQuery_Attachmentses(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _query_AttachmentsLocalService.getQuery_Attachmentses(start, end);
	}

	/**
	* Returns the number of query_ attachmentses.
	*
	* @return the number of query_ attachmentses
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getQuery_AttachmentsesCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _query_AttachmentsLocalService.getQuery_AttachmentsesCount();
	}

	/**
	* Updates the query_ attachments in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param query_Attachments the query_ attachments
	* @return the query_ attachments that was updated
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.jioc.query.model.Query_Attachments updateQuery_Attachments(
		com.jioc.query.model.Query_Attachments query_Attachments)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _query_AttachmentsLocalService.updateQuery_Attachments(query_Attachments);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _query_AttachmentsLocalService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_query_AttachmentsLocalService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _query_AttachmentsLocalService.invokeMethod(name,
			parameterTypes, arguments);
	}

	@Override
	public java.util.List<com.jioc.query.model.Query_Attachments> findQueryAttachmentsByQueryId(
		long queryId) {
		return _query_AttachmentsLocalService.findQueryAttachmentsByQueryId(queryId);
	}

	@Override
	public com.jioc.query.model.Query_Attachments getQueryByQueryIdAndFileEntryId(
		long queryId, long fileEntryId)
		throws com.jioc.query.NoSuchQuery_AttachmentsException,
			com.liferay.portal.kernel.exception.SystemException {
		return _query_AttachmentsLocalService.getQueryByQueryIdAndFileEntryId(queryId,
			fileEntryId);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public Query_AttachmentsLocalService getWrappedQuery_AttachmentsLocalService() {
		return _query_AttachmentsLocalService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedQuery_AttachmentsLocalService(
		Query_AttachmentsLocalService query_AttachmentsLocalService) {
		_query_AttachmentsLocalService = query_AttachmentsLocalService;
	}

	@Override
	public Query_AttachmentsLocalService getWrappedService() {
		return _query_AttachmentsLocalService;
	}

	@Override
	public void setWrappedService(
		Query_AttachmentsLocalService query_AttachmentsLocalService) {
		_query_AttachmentsLocalService = query_AttachmentsLocalService;
	}

	private Query_AttachmentsLocalService _query_AttachmentsLocalService;
}