/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link RESOLVER_DEFAULTS}.
 * </p>
 *
 * @author shantaram.chavan
 * @see RESOLVER_DEFAULTS
 * @generated
 */
public class RESOLVER_DEFAULTSWrapper implements RESOLVER_DEFAULTS,
	ModelWrapper<RESOLVER_DEFAULTS> {
	public RESOLVER_DEFAULTSWrapper(RESOLVER_DEFAULTS resolver_defaults) {
		_resolver_defaults = resolver_defaults;
	}

	@Override
	public Class<?> getModelClass() {
		return RESOLVER_DEFAULTS.class;
	}

	@Override
	public String getModelClassName() {
		return RESOLVER_DEFAULTS.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("DEFAULT_ID", getDEFAULT_ID());
		attributes.put("RESOLVER_LEVEL_ID", getRESOLVER_LEVEL_ID());
		attributes.put("TYPE", getTYPE());
		attributes.put("VALUE", getVALUE());
		attributes.put("TO_DISPLAY", getTO_DISPLAY());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long DEFAULT_ID = (Long)attributes.get("DEFAULT_ID");

		if (DEFAULT_ID != null) {
			setDEFAULT_ID(DEFAULT_ID);
		}

		Long RESOLVER_LEVEL_ID = (Long)attributes.get("RESOLVER_LEVEL_ID");

		if (RESOLVER_LEVEL_ID != null) {
			setRESOLVER_LEVEL_ID(RESOLVER_LEVEL_ID);
		}

		String TYPE = (String)attributes.get("TYPE");

		if (TYPE != null) {
			setTYPE(TYPE);
		}

		String VALUE = (String)attributes.get("VALUE");

		if (VALUE != null) {
			setVALUE(VALUE);
		}

		Integer TO_DISPLAY = (Integer)attributes.get("TO_DISPLAY");

		if (TO_DISPLAY != null) {
			setTO_DISPLAY(TO_DISPLAY);
		}
	}

	/**
	* Returns the primary key of this r e s o l v e r_ d e f a u l t s.
	*
	* @return the primary key of this r e s o l v e r_ d e f a u l t s
	*/
	@Override
	public long getPrimaryKey() {
		return _resolver_defaults.getPrimaryKey();
	}

	/**
	* Sets the primary key of this r e s o l v e r_ d e f a u l t s.
	*
	* @param primaryKey the primary key of this r e s o l v e r_ d e f a u l t s
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_resolver_defaults.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the d e f a u l t_ i d of this r e s o l v e r_ d e f a u l t s.
	*
	* @return the d e f a u l t_ i d of this r e s o l v e r_ d e f a u l t s
	*/
	@Override
	public long getDEFAULT_ID() {
		return _resolver_defaults.getDEFAULT_ID();
	}

	/**
	* Sets the d e f a u l t_ i d of this r e s o l v e r_ d e f a u l t s.
	*
	* @param DEFAULT_ID the d e f a u l t_ i d of this r e s o l v e r_ d e f a u l t s
	*/
	@Override
	public void setDEFAULT_ID(long DEFAULT_ID) {
		_resolver_defaults.setDEFAULT_ID(DEFAULT_ID);
	}

	/**
	* Returns the r e s o l v e r_ l e v e l_ i d of this r e s o l v e r_ d e f a u l t s.
	*
	* @return the r e s o l v e r_ l e v e l_ i d of this r e s o l v e r_ d e f a u l t s
	*/
	@Override
	public long getRESOLVER_LEVEL_ID() {
		return _resolver_defaults.getRESOLVER_LEVEL_ID();
	}

	/**
	* Sets the r e s o l v e r_ l e v e l_ i d of this r e s o l v e r_ d e f a u l t s.
	*
	* @param RESOLVER_LEVEL_ID the r e s o l v e r_ l e v e l_ i d of this r e s o l v e r_ d e f a u l t s
	*/
	@Override
	public void setRESOLVER_LEVEL_ID(long RESOLVER_LEVEL_ID) {
		_resolver_defaults.setRESOLVER_LEVEL_ID(RESOLVER_LEVEL_ID);
	}

	/**
	* Returns the t y p e of this r e s o l v e r_ d e f a u l t s.
	*
	* @return the t y p e of this r e s o l v e r_ d e f a u l t s
	*/
	@Override
	public java.lang.String getTYPE() {
		return _resolver_defaults.getTYPE();
	}

	/**
	* Sets the t y p e of this r e s o l v e r_ d e f a u l t s.
	*
	* @param TYPE the t y p e of this r e s o l v e r_ d e f a u l t s
	*/
	@Override
	public void setTYPE(java.lang.String TYPE) {
		_resolver_defaults.setTYPE(TYPE);
	}

	/**
	* Returns the v a l u e of this r e s o l v e r_ d e f a u l t s.
	*
	* @return the v a l u e of this r e s o l v e r_ d e f a u l t s
	*/
	@Override
	public java.lang.String getVALUE() {
		return _resolver_defaults.getVALUE();
	}

	/**
	* Sets the v a l u e of this r e s o l v e r_ d e f a u l t s.
	*
	* @param VALUE the v a l u e of this r e s o l v e r_ d e f a u l t s
	*/
	@Override
	public void setVALUE(java.lang.String VALUE) {
		_resolver_defaults.setVALUE(VALUE);
	}

	/**
	* Returns the t o_ d i s p l a y of this r e s o l v e r_ d e f a u l t s.
	*
	* @return the t o_ d i s p l a y of this r e s o l v e r_ d e f a u l t s
	*/
	@Override
	public int getTO_DISPLAY() {
		return _resolver_defaults.getTO_DISPLAY();
	}

	/**
	* Sets the t o_ d i s p l a y of this r e s o l v e r_ d e f a u l t s.
	*
	* @param TO_DISPLAY the t o_ d i s p l a y of this r e s o l v e r_ d e f a u l t s
	*/
	@Override
	public void setTO_DISPLAY(int TO_DISPLAY) {
		_resolver_defaults.setTO_DISPLAY(TO_DISPLAY);
	}

	@Override
	public boolean isNew() {
		return _resolver_defaults.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_resolver_defaults.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _resolver_defaults.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_resolver_defaults.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _resolver_defaults.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _resolver_defaults.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_resolver_defaults.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _resolver_defaults.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_resolver_defaults.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_resolver_defaults.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_resolver_defaults.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new RESOLVER_DEFAULTSWrapper((RESOLVER_DEFAULTS)_resolver_defaults.clone());
	}

	@Override
	public int compareTo(
		com.jioc.query.model.RESOLVER_DEFAULTS resolver_defaults) {
		return _resolver_defaults.compareTo(resolver_defaults);
	}

	@Override
	public int hashCode() {
		return _resolver_defaults.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jioc.query.model.RESOLVER_DEFAULTS> toCacheModel() {
		return _resolver_defaults.toCacheModel();
	}

	@Override
	public com.jioc.query.model.RESOLVER_DEFAULTS toEscapedModel() {
		return new RESOLVER_DEFAULTSWrapper(_resolver_defaults.toEscapedModel());
	}

	@Override
	public com.jioc.query.model.RESOLVER_DEFAULTS toUnescapedModel() {
		return new RESOLVER_DEFAULTSWrapper(_resolver_defaults.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _resolver_defaults.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _resolver_defaults.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_resolver_defaults.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof RESOLVER_DEFAULTSWrapper)) {
			return false;
		}

		RESOLVER_DEFAULTSWrapper resolver_defaultsWrapper = (RESOLVER_DEFAULTSWrapper)obj;

		if (Validator.equals(_resolver_defaults,
					resolver_defaultsWrapper._resolver_defaults)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public RESOLVER_DEFAULTS getWrappedRESOLVER_DEFAULTS() {
		return _resolver_defaults;
	}

	@Override
	public RESOLVER_DEFAULTS getWrappedModel() {
		return _resolver_defaults;
	}

	@Override
	public void resetOriginalValues() {
		_resolver_defaults.resetOriginalValues();
	}

	private RESOLVER_DEFAULTS _resolver_defaults;
}