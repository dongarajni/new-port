/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author shantaram.chavan
 * @generated
 */
public class OC_JOB_FUNCTION_MSTSoap implements Serializable {
	public static OC_JOB_FUNCTION_MSTSoap toSoapModel(OC_JOB_FUNCTION_MST model) {
		OC_JOB_FUNCTION_MSTSoap soapModel = new OC_JOB_FUNCTION_MSTSoap();

		soapModel.setOC_JOB_FUNCTION_ID(model.getOC_JOB_FUNCTION_ID());
		soapModel.setFUNCTIONAL_AREA(model.getFUNCTIONAL_AREA());
		soapModel.setJOB(model.getJOB());
		soapModel.setOC(model.getOC());
		soapModel.setSUB_FUNCTIONAL_AREA(model.getSUB_FUNCTIONAL_AREA());

		return soapModel;
	}

	public static OC_JOB_FUNCTION_MSTSoap[] toSoapModels(
		OC_JOB_FUNCTION_MST[] models) {
		OC_JOB_FUNCTION_MSTSoap[] soapModels = new OC_JOB_FUNCTION_MSTSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static OC_JOB_FUNCTION_MSTSoap[][] toSoapModels(
		OC_JOB_FUNCTION_MST[][] models) {
		OC_JOB_FUNCTION_MSTSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new OC_JOB_FUNCTION_MSTSoap[models.length][models[0].length];
		}
		else {
			soapModels = new OC_JOB_FUNCTION_MSTSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static OC_JOB_FUNCTION_MSTSoap[] toSoapModels(
		List<OC_JOB_FUNCTION_MST> models) {
		List<OC_JOB_FUNCTION_MSTSoap> soapModels = new ArrayList<OC_JOB_FUNCTION_MSTSoap>(models.size());

		for (OC_JOB_FUNCTION_MST model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new OC_JOB_FUNCTION_MSTSoap[soapModels.size()]);
	}

	public OC_JOB_FUNCTION_MSTSoap() {
	}

	public long getPrimaryKey() {
		return _OC_JOB_FUNCTION_ID;
	}

	public void setPrimaryKey(long pk) {
		setOC_JOB_FUNCTION_ID(pk);
	}

	public long getOC_JOB_FUNCTION_ID() {
		return _OC_JOB_FUNCTION_ID;
	}

	public void setOC_JOB_FUNCTION_ID(long OC_JOB_FUNCTION_ID) {
		_OC_JOB_FUNCTION_ID = OC_JOB_FUNCTION_ID;
	}

	public String getFUNCTIONAL_AREA() {
		return _FUNCTIONAL_AREA;
	}

	public void setFUNCTIONAL_AREA(String FUNCTIONAL_AREA) {
		_FUNCTIONAL_AREA = FUNCTIONAL_AREA;
	}

	public String getJOB() {
		return _JOB;
	}

	public void setJOB(String JOB) {
		_JOB = JOB;
	}

	public String getOC() {
		return _OC;
	}

	public void setOC(String OC) {
		_OC = OC;
	}

	public String getSUB_FUNCTIONAL_AREA() {
		return _SUB_FUNCTIONAL_AREA;
	}

	public void setSUB_FUNCTIONAL_AREA(String SUB_FUNCTIONAL_AREA) {
		_SUB_FUNCTIONAL_AREA = SUB_FUNCTIONAL_AREA;
	}

	private long _OC_JOB_FUNCTION_ID;
	private String _FUNCTIONAL_AREA;
	private String _JOB;
	private String _OC;
	private String _SUB_FUNCTIONAL_AREA;
}