/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author shantaram.chavan
 * @generated
 */
public class QUERY_MOD_DEFAULTSSoap implements Serializable {
	public static QUERY_MOD_DEFAULTSSoap toSoapModel(QUERY_MOD_DEFAULTS model) {
		QUERY_MOD_DEFAULTSSoap soapModel = new QUERY_MOD_DEFAULTSSoap();

		soapModel.setQUERY_MOD_DEFAULTS_ID(model.getQUERY_MOD_DEFAULTS_ID());
		soapModel.setCURR_VAL(model.getCURR_VAL());
		soapModel.setNEW_VAL(model.getNEW_VAL());
		soapModel.setIS_ACTIVE(model.getIS_ACTIVE());
		soapModel.setUPDATED_TIMESTAMP(model.getUPDATED_TIMESTAMP());
		soapModel.setTYPE(model.getTYPE());
		soapModel.setCURR_LEVEL(model.getCURR_LEVEL());

		return soapModel;
	}

	public static QUERY_MOD_DEFAULTSSoap[] toSoapModels(
		QUERY_MOD_DEFAULTS[] models) {
		QUERY_MOD_DEFAULTSSoap[] soapModels = new QUERY_MOD_DEFAULTSSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static QUERY_MOD_DEFAULTSSoap[][] toSoapModels(
		QUERY_MOD_DEFAULTS[][] models) {
		QUERY_MOD_DEFAULTSSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new QUERY_MOD_DEFAULTSSoap[models.length][models[0].length];
		}
		else {
			soapModels = new QUERY_MOD_DEFAULTSSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static QUERY_MOD_DEFAULTSSoap[] toSoapModels(
		List<QUERY_MOD_DEFAULTS> models) {
		List<QUERY_MOD_DEFAULTSSoap> soapModels = new ArrayList<QUERY_MOD_DEFAULTSSoap>(models.size());

		for (QUERY_MOD_DEFAULTS model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new QUERY_MOD_DEFAULTSSoap[soapModels.size()]);
	}

	public QUERY_MOD_DEFAULTSSoap() {
	}

	public int getPrimaryKey() {
		return _QUERY_MOD_DEFAULTS_ID;
	}

	public void setPrimaryKey(int pk) {
		setQUERY_MOD_DEFAULTS_ID(pk);
	}

	public int getQUERY_MOD_DEFAULTS_ID() {
		return _QUERY_MOD_DEFAULTS_ID;
	}

	public void setQUERY_MOD_DEFAULTS_ID(int QUERY_MOD_DEFAULTS_ID) {
		_QUERY_MOD_DEFAULTS_ID = QUERY_MOD_DEFAULTS_ID;
	}

	public String getCURR_VAL() {
		return _CURR_VAL;
	}

	public void setCURR_VAL(String CURR_VAL) {
		_CURR_VAL = CURR_VAL;
	}

	public String getNEW_VAL() {
		return _NEW_VAL;
	}

	public void setNEW_VAL(String NEW_VAL) {
		_NEW_VAL = NEW_VAL;
	}

	public int getIS_ACTIVE() {
		return _IS_ACTIVE;
	}

	public void setIS_ACTIVE(int IS_ACTIVE) {
		_IS_ACTIVE = IS_ACTIVE;
	}

	public Date getUPDATED_TIMESTAMP() {
		return _UPDATED_TIMESTAMP;
	}

	public void setUPDATED_TIMESTAMP(Date UPDATED_TIMESTAMP) {
		_UPDATED_TIMESTAMP = UPDATED_TIMESTAMP;
	}

	public String getTYPE() {
		return _TYPE;
	}

	public void setTYPE(String TYPE) {
		_TYPE = TYPE;
	}

	public int getCURR_LEVEL() {
		return _CURR_LEVEL;
	}

	public void setCURR_LEVEL(int CURR_LEVEL) {
		_CURR_LEVEL = CURR_LEVEL;
	}

	private int _QUERY_MOD_DEFAULTS_ID;
	private String _CURR_VAL;
	private String _NEW_VAL;
	private int _IS_ACTIVE;
	private Date _UPDATED_TIMESTAMP;
	private String _TYPE;
	private int _CURR_LEVEL;
}