/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.model.EMP_DETAILS;

import com.liferay.portal.service.persistence.BasePersistence;

/**
 * The persistence interface for the e m p_ d e t a i l s service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see EMP_DETAILSPersistenceImpl
 * @see EMP_DETAILSUtil
 * @generated
 */
public interface EMP_DETAILSPersistence extends BasePersistence<EMP_DETAILS> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link EMP_DETAILSUtil} to access the e m p_ d e t a i l s persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the e m p_ d e t a i l ses where EMP_ID = &#63;.
	*
	* @param EMP_ID the e m p_ i d
	* @return the matching e m p_ d e t a i l ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.EMP_DETAILS> findByEMP_ID(
		java.lang.String EMP_ID)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the e m p_ d e t a i l ses where EMP_ID = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.EMP_DETAILSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param EMP_ID the e m p_ i d
	* @param start the lower bound of the range of e m p_ d e t a i l ses
	* @param end the upper bound of the range of e m p_ d e t a i l ses (not inclusive)
	* @return the range of matching e m p_ d e t a i l ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.EMP_DETAILS> findByEMP_ID(
		java.lang.String EMP_ID, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the e m p_ d e t a i l ses where EMP_ID = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.EMP_DETAILSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param EMP_ID the e m p_ i d
	* @param start the lower bound of the range of e m p_ d e t a i l ses
	* @param end the upper bound of the range of e m p_ d e t a i l ses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching e m p_ d e t a i l ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.EMP_DETAILS> findByEMP_ID(
		java.lang.String EMP_ID, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first e m p_ d e t a i l s in the ordered set where EMP_ID = &#63;.
	*
	* @param EMP_ID the e m p_ i d
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching e m p_ d e t a i l s
	* @throws com.jioc.query.NoSuchEMP_DETAILSException if a matching e m p_ d e t a i l s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.EMP_DETAILS findByEMP_ID_First(
		java.lang.String EMP_ID,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchEMP_DETAILSException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first e m p_ d e t a i l s in the ordered set where EMP_ID = &#63;.
	*
	* @param EMP_ID the e m p_ i d
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching e m p_ d e t a i l s, or <code>null</code> if a matching e m p_ d e t a i l s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.EMP_DETAILS fetchByEMP_ID_First(
		java.lang.String EMP_ID,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last e m p_ d e t a i l s in the ordered set where EMP_ID = &#63;.
	*
	* @param EMP_ID the e m p_ i d
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching e m p_ d e t a i l s
	* @throws com.jioc.query.NoSuchEMP_DETAILSException if a matching e m p_ d e t a i l s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.EMP_DETAILS findByEMP_ID_Last(
		java.lang.String EMP_ID,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchEMP_DETAILSException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last e m p_ d e t a i l s in the ordered set where EMP_ID = &#63;.
	*
	* @param EMP_ID the e m p_ i d
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching e m p_ d e t a i l s, or <code>null</code> if a matching e m p_ d e t a i l s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.EMP_DETAILS fetchByEMP_ID_Last(
		java.lang.String EMP_ID,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the e m p_ d e t a i l ses where EMP_ID = &#63; from the database.
	*
	* @param EMP_ID the e m p_ i d
	* @throws SystemException if a system exception occurred
	*/
	public void removeByEMP_ID(java.lang.String EMP_ID)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of e m p_ d e t a i l ses where EMP_ID = &#63;.
	*
	* @param EMP_ID the e m p_ i d
	* @return the number of matching e m p_ d e t a i l ses
	* @throws SystemException if a system exception occurred
	*/
	public int countByEMP_ID(java.lang.String EMP_ID)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the e m p_ d e t a i l ses where DATE_OF_JOINING = &#63;.
	*
	* @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	* @return the matching e m p_ d e t a i l ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.EMP_DETAILS> findByDATE_OF_JOINING(
		java.util.Date DATE_OF_JOINING)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the e m p_ d e t a i l ses where DATE_OF_JOINING = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.EMP_DETAILSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	* @param start the lower bound of the range of e m p_ d e t a i l ses
	* @param end the upper bound of the range of e m p_ d e t a i l ses (not inclusive)
	* @return the range of matching e m p_ d e t a i l ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.EMP_DETAILS> findByDATE_OF_JOINING(
		java.util.Date DATE_OF_JOINING, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the e m p_ d e t a i l ses where DATE_OF_JOINING = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.EMP_DETAILSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	* @param start the lower bound of the range of e m p_ d e t a i l ses
	* @param end the upper bound of the range of e m p_ d e t a i l ses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching e m p_ d e t a i l ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.EMP_DETAILS> findByDATE_OF_JOINING(
		java.util.Date DATE_OF_JOINING, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first e m p_ d e t a i l s in the ordered set where DATE_OF_JOINING = &#63;.
	*
	* @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching e m p_ d e t a i l s
	* @throws com.jioc.query.NoSuchEMP_DETAILSException if a matching e m p_ d e t a i l s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.EMP_DETAILS findByDATE_OF_JOINING_First(
		java.util.Date DATE_OF_JOINING,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchEMP_DETAILSException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first e m p_ d e t a i l s in the ordered set where DATE_OF_JOINING = &#63;.
	*
	* @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching e m p_ d e t a i l s, or <code>null</code> if a matching e m p_ d e t a i l s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.EMP_DETAILS fetchByDATE_OF_JOINING_First(
		java.util.Date DATE_OF_JOINING,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last e m p_ d e t a i l s in the ordered set where DATE_OF_JOINING = &#63;.
	*
	* @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching e m p_ d e t a i l s
	* @throws com.jioc.query.NoSuchEMP_DETAILSException if a matching e m p_ d e t a i l s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.EMP_DETAILS findByDATE_OF_JOINING_Last(
		java.util.Date DATE_OF_JOINING,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchEMP_DETAILSException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last e m p_ d e t a i l s in the ordered set where DATE_OF_JOINING = &#63;.
	*
	* @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching e m p_ d e t a i l s, or <code>null</code> if a matching e m p_ d e t a i l s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.EMP_DETAILS fetchByDATE_OF_JOINING_Last(
		java.util.Date DATE_OF_JOINING,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the e m p_ d e t a i l ses before and after the current e m p_ d e t a i l s in the ordered set where DATE_OF_JOINING = &#63;.
	*
	* @param EMP_ID the primary key of the current e m p_ d e t a i l s
	* @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next e m p_ d e t a i l s
	* @throws com.jioc.query.NoSuchEMP_DETAILSException if a e m p_ d e t a i l s with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.EMP_DETAILS[] findByDATE_OF_JOINING_PrevAndNext(
		java.lang.String EMP_ID, java.util.Date DATE_OF_JOINING,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchEMP_DETAILSException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the e m p_ d e t a i l ses where DATE_OF_JOINING = &#63; from the database.
	*
	* @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	* @throws SystemException if a system exception occurred
	*/
	public void removeByDATE_OF_JOINING(java.util.Date DATE_OF_JOINING)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of e m p_ d e t a i l ses where DATE_OF_JOINING = &#63;.
	*
	* @param DATE_OF_JOINING the d a t e_ o f_ j o i n i n g
	* @return the number of matching e m p_ d e t a i l ses
	* @throws SystemException if a system exception occurred
	*/
	public int countByDATE_OF_JOINING(java.util.Date DATE_OF_JOINING)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the e m p_ d e t a i l s in the entity cache if it is enabled.
	*
	* @param emp_details the e m p_ d e t a i l s
	*/
	public void cacheResult(com.jioc.query.model.EMP_DETAILS emp_details);

	/**
	* Caches the e m p_ d e t a i l ses in the entity cache if it is enabled.
	*
	* @param emp_detailses the e m p_ d e t a i l ses
	*/
	public void cacheResult(
		java.util.List<com.jioc.query.model.EMP_DETAILS> emp_detailses);

	/**
	* Creates a new e m p_ d e t a i l s with the primary key. Does not add the e m p_ d e t a i l s to the database.
	*
	* @param EMP_ID the primary key for the new e m p_ d e t a i l s
	* @return the new e m p_ d e t a i l s
	*/
	public com.jioc.query.model.EMP_DETAILS create(java.lang.String EMP_ID);

	/**
	* Removes the e m p_ d e t a i l s with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param EMP_ID the primary key of the e m p_ d e t a i l s
	* @return the e m p_ d e t a i l s that was removed
	* @throws com.jioc.query.NoSuchEMP_DETAILSException if a e m p_ d e t a i l s with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.EMP_DETAILS remove(java.lang.String EMP_ID)
		throws com.jioc.query.NoSuchEMP_DETAILSException,
			com.liferay.portal.kernel.exception.SystemException;

	public com.jioc.query.model.EMP_DETAILS updateImpl(
		com.jioc.query.model.EMP_DETAILS emp_details)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the e m p_ d e t a i l s with the primary key or throws a {@link com.jioc.query.NoSuchEMP_DETAILSException} if it could not be found.
	*
	* @param EMP_ID the primary key of the e m p_ d e t a i l s
	* @return the e m p_ d e t a i l s
	* @throws com.jioc.query.NoSuchEMP_DETAILSException if a e m p_ d e t a i l s with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.EMP_DETAILS findByPrimaryKey(
		java.lang.String EMP_ID)
		throws com.jioc.query.NoSuchEMP_DETAILSException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the e m p_ d e t a i l s with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param EMP_ID the primary key of the e m p_ d e t a i l s
	* @return the e m p_ d e t a i l s, or <code>null</code> if a e m p_ d e t a i l s with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.query.model.EMP_DETAILS fetchByPrimaryKey(
		java.lang.String EMP_ID)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the e m p_ d e t a i l ses.
	*
	* @return the e m p_ d e t a i l ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.EMP_DETAILS> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the e m p_ d e t a i l ses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.EMP_DETAILSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of e m p_ d e t a i l ses
	* @param end the upper bound of the range of e m p_ d e t a i l ses (not inclusive)
	* @return the range of e m p_ d e t a i l ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.EMP_DETAILS> findAll(int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the e m p_ d e t a i l ses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.EMP_DETAILSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of e m p_ d e t a i l ses
	* @param end the upper bound of the range of e m p_ d e t a i l ses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of e m p_ d e t a i l ses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.query.model.EMP_DETAILS> findAll(int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the e m p_ d e t a i l ses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of e m p_ d e t a i l ses.
	*
	* @return the number of e m p_ d e t a i l ses
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}