/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link Query_TransactionService}.
 *
 * @author shantaram.chavan
 * @see Query_TransactionService
 * @generated
 */
public class Query_TransactionServiceWrapper implements Query_TransactionService,
	ServiceWrapper<Query_TransactionService> {
	public Query_TransactionServiceWrapper(
		Query_TransactionService query_TransactionService) {
		_query_TransactionService = query_TransactionService;
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _query_TransactionService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_query_TransactionService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _query_TransactionService.invokeMethod(name, parameterTypes,
			arguments);
	}

	@Override
	public com.liferay.portal.kernel.json.JSONObject pushticket(
		java.lang.String ticketId, java.lang.String ownerEmailAddress,
		java.lang.String origin, java.lang.String description,
		java.lang.String status) {
		return _query_TransactionService.pushticket(ticketId,
			ownerEmailAddress, origin, description, status);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public Query_TransactionService getWrappedQuery_TransactionService() {
		return _query_TransactionService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedQuery_TransactionService(
		Query_TransactionService query_TransactionService) {
		_query_TransactionService = query_TransactionService;
	}

	@Override
	public Query_TransactionService getWrappedService() {
		return _query_TransactionService;
	}

	@Override
	public void setWrappedService(
		Query_TransactionService query_TransactionService) {
		_query_TransactionService = query_TransactionService;
	}

	private Query_TransactionService _query_TransactionService;
}