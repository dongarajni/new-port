/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Query_Txn}.
 * </p>
 *
 * @author shantaram.chavan
 * @see Query_Txn
 * @generated
 */
public class Query_TxnWrapper implements Query_Txn, ModelWrapper<Query_Txn> {
	public Query_TxnWrapper(Query_Txn query_Txn) {
		_query_Txn = query_Txn;
	}

	@Override
	public Class<?> getModelClass() {
		return Query_Txn.class;
	}

	@Override
	public String getModelClassName() {
		return Query_Txn.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("queryId", getQueryId());
		attributes.put("caseNo", getCaseNo());
		attributes.put("description", getDescription());
		attributes.put("raisedBy", getRaisedBy());
		attributes.put("raisedTimestamp", getRaisedTimestamp());
		attributes.put("lastUpdatedTimestamp", getLastUpdatedTimestamp());
		attributes.put("status", getStatus());
		attributes.put("oc", getOc());
		attributes.put("state", getState());
		attributes.put("region", getRegion());
		attributes.put("queueName", getQueueName());
		attributes.put("queueLevel", getQueueLevel());
		attributes.put("assignedTo", getAssignedTo());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long queryId = (Long)attributes.get("queryId");

		if (queryId != null) {
			setQueryId(queryId);
		}

		String caseNo = (String)attributes.get("caseNo");

		if (caseNo != null) {
			setCaseNo(caseNo);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}

		String raisedBy = (String)attributes.get("raisedBy");

		if (raisedBy != null) {
			setRaisedBy(raisedBy);
		}

		Date raisedTimestamp = (Date)attributes.get("raisedTimestamp");

		if (raisedTimestamp != null) {
			setRaisedTimestamp(raisedTimestamp);
		}

		Date lastUpdatedTimestamp = (Date)attributes.get("lastUpdatedTimestamp");

		if (lastUpdatedTimestamp != null) {
			setLastUpdatedTimestamp(lastUpdatedTimestamp);
		}

		String status = (String)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String oc = (String)attributes.get("oc");

		if (oc != null) {
			setOc(oc);
		}

		String state = (String)attributes.get("state");

		if (state != null) {
			setState(state);
		}

		String region = (String)attributes.get("region");

		if (region != null) {
			setRegion(region);
		}

		String queueName = (String)attributes.get("queueName");

		if (queueName != null) {
			setQueueName(queueName);
		}

		Integer queueLevel = (Integer)attributes.get("queueLevel");

		if (queueLevel != null) {
			setQueueLevel(queueLevel);
		}

		String assignedTo = (String)attributes.get("assignedTo");

		if (assignedTo != null) {
			setAssignedTo(assignedTo);
		}
	}

	/**
	* Returns the primary key of this query_ txn.
	*
	* @return the primary key of this query_ txn
	*/
	@Override
	public long getPrimaryKey() {
		return _query_Txn.getPrimaryKey();
	}

	/**
	* Sets the primary key of this query_ txn.
	*
	* @param primaryKey the primary key of this query_ txn
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_query_Txn.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the query ID of this query_ txn.
	*
	* @return the query ID of this query_ txn
	*/
	@Override
	public long getQueryId() {
		return _query_Txn.getQueryId();
	}

	/**
	* Sets the query ID of this query_ txn.
	*
	* @param queryId the query ID of this query_ txn
	*/
	@Override
	public void setQueryId(long queryId) {
		_query_Txn.setQueryId(queryId);
	}

	/**
	* Returns the case no of this query_ txn.
	*
	* @return the case no of this query_ txn
	*/
	@Override
	public java.lang.String getCaseNo() {
		return _query_Txn.getCaseNo();
	}

	/**
	* Sets the case no of this query_ txn.
	*
	* @param caseNo the case no of this query_ txn
	*/
	@Override
	public void setCaseNo(java.lang.String caseNo) {
		_query_Txn.setCaseNo(caseNo);
	}

	/**
	* Returns the description of this query_ txn.
	*
	* @return the description of this query_ txn
	*/
	@Override
	public java.lang.String getDescription() {
		return _query_Txn.getDescription();
	}

	/**
	* Sets the description of this query_ txn.
	*
	* @param description the description of this query_ txn
	*/
	@Override
	public void setDescription(java.lang.String description) {
		_query_Txn.setDescription(description);
	}

	/**
	* Returns the raised by of this query_ txn.
	*
	* @return the raised by of this query_ txn
	*/
	@Override
	public java.lang.String getRaisedBy() {
		return _query_Txn.getRaisedBy();
	}

	/**
	* Sets the raised by of this query_ txn.
	*
	* @param raisedBy the raised by of this query_ txn
	*/
	@Override
	public void setRaisedBy(java.lang.String raisedBy) {
		_query_Txn.setRaisedBy(raisedBy);
	}

	/**
	* Returns the raised timestamp of this query_ txn.
	*
	* @return the raised timestamp of this query_ txn
	*/
	@Override
	public java.util.Date getRaisedTimestamp() {
		return _query_Txn.getRaisedTimestamp();
	}

	/**
	* Sets the raised timestamp of this query_ txn.
	*
	* @param raisedTimestamp the raised timestamp of this query_ txn
	*/
	@Override
	public void setRaisedTimestamp(java.util.Date raisedTimestamp) {
		_query_Txn.setRaisedTimestamp(raisedTimestamp);
	}

	/**
	* Returns the last updated timestamp of this query_ txn.
	*
	* @return the last updated timestamp of this query_ txn
	*/
	@Override
	public java.util.Date getLastUpdatedTimestamp() {
		return _query_Txn.getLastUpdatedTimestamp();
	}

	/**
	* Sets the last updated timestamp of this query_ txn.
	*
	* @param lastUpdatedTimestamp the last updated timestamp of this query_ txn
	*/
	@Override
	public void setLastUpdatedTimestamp(java.util.Date lastUpdatedTimestamp) {
		_query_Txn.setLastUpdatedTimestamp(lastUpdatedTimestamp);
	}

	/**
	* Returns the status of this query_ txn.
	*
	* @return the status of this query_ txn
	*/
	@Override
	public java.lang.String getStatus() {
		return _query_Txn.getStatus();
	}

	/**
	* Sets the status of this query_ txn.
	*
	* @param status the status of this query_ txn
	*/
	@Override
	public void setStatus(java.lang.String status) {
		_query_Txn.setStatus(status);
	}

	/**
	* Returns the oc of this query_ txn.
	*
	* @return the oc of this query_ txn
	*/
	@Override
	public java.lang.String getOc() {
		return _query_Txn.getOc();
	}

	/**
	* Sets the oc of this query_ txn.
	*
	* @param oc the oc of this query_ txn
	*/
	@Override
	public void setOc(java.lang.String oc) {
		_query_Txn.setOc(oc);
	}

	/**
	* Returns the state of this query_ txn.
	*
	* @return the state of this query_ txn
	*/
	@Override
	public java.lang.String getState() {
		return _query_Txn.getState();
	}

	/**
	* Sets the state of this query_ txn.
	*
	* @param state the state of this query_ txn
	*/
	@Override
	public void setState(java.lang.String state) {
		_query_Txn.setState(state);
	}

	/**
	* Returns the region of this query_ txn.
	*
	* @return the region of this query_ txn
	*/
	@Override
	public java.lang.String getRegion() {
		return _query_Txn.getRegion();
	}

	/**
	* Sets the region of this query_ txn.
	*
	* @param region the region of this query_ txn
	*/
	@Override
	public void setRegion(java.lang.String region) {
		_query_Txn.setRegion(region);
	}

	/**
	* Returns the queue name of this query_ txn.
	*
	* @return the queue name of this query_ txn
	*/
	@Override
	public java.lang.String getQueueName() {
		return _query_Txn.getQueueName();
	}

	/**
	* Sets the queue name of this query_ txn.
	*
	* @param queueName the queue name of this query_ txn
	*/
	@Override
	public void setQueueName(java.lang.String queueName) {
		_query_Txn.setQueueName(queueName);
	}

	/**
	* Returns the queue level of this query_ txn.
	*
	* @return the queue level of this query_ txn
	*/
	@Override
	public int getQueueLevel() {
		return _query_Txn.getQueueLevel();
	}

	/**
	* Sets the queue level of this query_ txn.
	*
	* @param queueLevel the queue level of this query_ txn
	*/
	@Override
	public void setQueueLevel(int queueLevel) {
		_query_Txn.setQueueLevel(queueLevel);
	}

	/**
	* Returns the assigned to of this query_ txn.
	*
	* @return the assigned to of this query_ txn
	*/
	@Override
	public java.lang.String getAssignedTo() {
		return _query_Txn.getAssignedTo();
	}

	/**
	* Sets the assigned to of this query_ txn.
	*
	* @param assignedTo the assigned to of this query_ txn
	*/
	@Override
	public void setAssignedTo(java.lang.String assignedTo) {
		_query_Txn.setAssignedTo(assignedTo);
	}

	@Override
	public boolean isNew() {
		return _query_Txn.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_query_Txn.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _query_Txn.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_query_Txn.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _query_Txn.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _query_Txn.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_query_Txn.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _query_Txn.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_query_Txn.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_query_Txn.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_query_Txn.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new Query_TxnWrapper((Query_Txn)_query_Txn.clone());
	}

	@Override
	public int compareTo(com.jioc.query.model.Query_Txn query_Txn) {
		return _query_Txn.compareTo(query_Txn);
	}

	@Override
	public int hashCode() {
		return _query_Txn.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jioc.query.model.Query_Txn> toCacheModel() {
		return _query_Txn.toCacheModel();
	}

	@Override
	public com.jioc.query.model.Query_Txn toEscapedModel() {
		return new Query_TxnWrapper(_query_Txn.toEscapedModel());
	}

	@Override
	public com.jioc.query.model.Query_Txn toUnescapedModel() {
		return new Query_TxnWrapper(_query_Txn.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _query_Txn.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _query_Txn.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_query_Txn.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof Query_TxnWrapper)) {
			return false;
		}

		Query_TxnWrapper query_TxnWrapper = (Query_TxnWrapper)obj;

		if (Validator.equals(_query_Txn, query_TxnWrapper._query_Txn)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public Query_Txn getWrappedQuery_Txn() {
		return _query_Txn;
	}

	@Override
	public Query_Txn getWrappedModel() {
		return _query_Txn;
	}

	@Override
	public void resetOriginalValues() {
		_query_Txn.resetOriginalValues();
	}

	private Query_Txn _query_Txn;
}