/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.jioc.query.service.ClpSerializer;
import com.jioc.query.service.Query_TxnLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author shantaram.chavan
 */
public class Query_TxnClp extends BaseModelImpl<Query_Txn> implements Query_Txn {
	public Query_TxnClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return Query_Txn.class;
	}

	@Override
	public String getModelClassName() {
		return Query_Txn.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _queryId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setQueryId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _queryId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("queryId", getQueryId());
		attributes.put("caseNo", getCaseNo());
		attributes.put("description", getDescription());
		attributes.put("raisedBy", getRaisedBy());
		attributes.put("raisedTimestamp", getRaisedTimestamp());
		attributes.put("lastUpdatedTimestamp", getLastUpdatedTimestamp());
		attributes.put("status", getStatus());
		attributes.put("oc", getOc());
		attributes.put("state", getState());
		attributes.put("region", getRegion());
		attributes.put("queueName", getQueueName());
		attributes.put("queueLevel", getQueueLevel());
		attributes.put("assignedTo", getAssignedTo());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long queryId = (Long)attributes.get("queryId");

		if (queryId != null) {
			setQueryId(queryId);
		}

		String caseNo = (String)attributes.get("caseNo");

		if (caseNo != null) {
			setCaseNo(caseNo);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}

		String raisedBy = (String)attributes.get("raisedBy");

		if (raisedBy != null) {
			setRaisedBy(raisedBy);
		}

		Date raisedTimestamp = (Date)attributes.get("raisedTimestamp");

		if (raisedTimestamp != null) {
			setRaisedTimestamp(raisedTimestamp);
		}

		Date lastUpdatedTimestamp = (Date)attributes.get("lastUpdatedTimestamp");

		if (lastUpdatedTimestamp != null) {
			setLastUpdatedTimestamp(lastUpdatedTimestamp);
		}

		String status = (String)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String oc = (String)attributes.get("oc");

		if (oc != null) {
			setOc(oc);
		}

		String state = (String)attributes.get("state");

		if (state != null) {
			setState(state);
		}

		String region = (String)attributes.get("region");

		if (region != null) {
			setRegion(region);
		}

		String queueName = (String)attributes.get("queueName");

		if (queueName != null) {
			setQueueName(queueName);
		}

		Integer queueLevel = (Integer)attributes.get("queueLevel");

		if (queueLevel != null) {
			setQueueLevel(queueLevel);
		}

		String assignedTo = (String)attributes.get("assignedTo");

		if (assignedTo != null) {
			setAssignedTo(assignedTo);
		}
	}

	@Override
	public long getQueryId() {
		return _queryId;
	}

	@Override
	public void setQueryId(long queryId) {
		_queryId = queryId;

		if (_query_TxnRemoteModel != null) {
			try {
				Class<?> clazz = _query_TxnRemoteModel.getClass();

				Method method = clazz.getMethod("setQueryId", long.class);

				method.invoke(_query_TxnRemoteModel, queryId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCaseNo() {
		return _caseNo;
	}

	@Override
	public void setCaseNo(String caseNo) {
		_caseNo = caseNo;

		if (_query_TxnRemoteModel != null) {
			try {
				Class<?> clazz = _query_TxnRemoteModel.getClass();

				Method method = clazz.getMethod("setCaseNo", String.class);

				method.invoke(_query_TxnRemoteModel, caseNo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDescription() {
		return _description;
	}

	@Override
	public void setDescription(String description) {
		_description = description;

		if (_query_TxnRemoteModel != null) {
			try {
				Class<?> clazz = _query_TxnRemoteModel.getClass();

				Method method = clazz.getMethod("setDescription", String.class);

				method.invoke(_query_TxnRemoteModel, description);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRaisedBy() {
		return _raisedBy;
	}

	@Override
	public void setRaisedBy(String raisedBy) {
		_raisedBy = raisedBy;

		if (_query_TxnRemoteModel != null) {
			try {
				Class<?> clazz = _query_TxnRemoteModel.getClass();

				Method method = clazz.getMethod("setRaisedBy", String.class);

				method.invoke(_query_TxnRemoteModel, raisedBy);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getRaisedTimestamp() {
		return _raisedTimestamp;
	}

	@Override
	public void setRaisedTimestamp(Date raisedTimestamp) {
		_raisedTimestamp = raisedTimestamp;

		if (_query_TxnRemoteModel != null) {
			try {
				Class<?> clazz = _query_TxnRemoteModel.getClass();

				Method method = clazz.getMethod("setRaisedTimestamp", Date.class);

				method.invoke(_query_TxnRemoteModel, raisedTimestamp);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getLastUpdatedTimestamp() {
		return _lastUpdatedTimestamp;
	}

	@Override
	public void setLastUpdatedTimestamp(Date lastUpdatedTimestamp) {
		_lastUpdatedTimestamp = lastUpdatedTimestamp;

		if (_query_TxnRemoteModel != null) {
			try {
				Class<?> clazz = _query_TxnRemoteModel.getClass();

				Method method = clazz.getMethod("setLastUpdatedTimestamp",
						Date.class);

				method.invoke(_query_TxnRemoteModel, lastUpdatedTimestamp);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getStatus() {
		return _status;
	}

	@Override
	public void setStatus(String status) {
		_status = status;

		if (_query_TxnRemoteModel != null) {
			try {
				Class<?> clazz = _query_TxnRemoteModel.getClass();

				Method method = clazz.getMethod("setStatus", String.class);

				method.invoke(_query_TxnRemoteModel, status);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOc() {
		return _oc;
	}

	@Override
	public void setOc(String oc) {
		_oc = oc;

		if (_query_TxnRemoteModel != null) {
			try {
				Class<?> clazz = _query_TxnRemoteModel.getClass();

				Method method = clazz.getMethod("setOc", String.class);

				method.invoke(_query_TxnRemoteModel, oc);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getState() {
		return _state;
	}

	@Override
	public void setState(String state) {
		_state = state;

		if (_query_TxnRemoteModel != null) {
			try {
				Class<?> clazz = _query_TxnRemoteModel.getClass();

				Method method = clazz.getMethod("setState", String.class);

				method.invoke(_query_TxnRemoteModel, state);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRegion() {
		return _region;
	}

	@Override
	public void setRegion(String region) {
		_region = region;

		if (_query_TxnRemoteModel != null) {
			try {
				Class<?> clazz = _query_TxnRemoteModel.getClass();

				Method method = clazz.getMethod("setRegion", String.class);

				method.invoke(_query_TxnRemoteModel, region);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getQueueName() {
		return _queueName;
	}

	@Override
	public void setQueueName(String queueName) {
		_queueName = queueName;

		if (_query_TxnRemoteModel != null) {
			try {
				Class<?> clazz = _query_TxnRemoteModel.getClass();

				Method method = clazz.getMethod("setQueueName", String.class);

				method.invoke(_query_TxnRemoteModel, queueName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getQueueLevel() {
		return _queueLevel;
	}

	@Override
	public void setQueueLevel(int queueLevel) {
		_queueLevel = queueLevel;

		if (_query_TxnRemoteModel != null) {
			try {
				Class<?> clazz = _query_TxnRemoteModel.getClass();

				Method method = clazz.getMethod("setQueueLevel", int.class);

				method.invoke(_query_TxnRemoteModel, queueLevel);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAssignedTo() {
		return _assignedTo;
	}

	@Override
	public void setAssignedTo(String assignedTo) {
		_assignedTo = assignedTo;

		if (_query_TxnRemoteModel != null) {
			try {
				Class<?> clazz = _query_TxnRemoteModel.getClass();

				Method method = clazz.getMethod("setAssignedTo", String.class);

				method.invoke(_query_TxnRemoteModel, assignedTo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getQuery_TxnRemoteModel() {
		return _query_TxnRemoteModel;
	}

	public void setQuery_TxnRemoteModel(BaseModel<?> query_TxnRemoteModel) {
		_query_TxnRemoteModel = query_TxnRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _query_TxnRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_query_TxnRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			Query_TxnLocalServiceUtil.addQuery_Txn(this);
		}
		else {
			Query_TxnLocalServiceUtil.updateQuery_Txn(this);
		}
	}

	@Override
	public Query_Txn toEscapedModel() {
		return (Query_Txn)ProxyUtil.newProxyInstance(Query_Txn.class.getClassLoader(),
			new Class[] { Query_Txn.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		Query_TxnClp clone = new Query_TxnClp();

		clone.setQueryId(getQueryId());
		clone.setCaseNo(getCaseNo());
		clone.setDescription(getDescription());
		clone.setRaisedBy(getRaisedBy());
		clone.setRaisedTimestamp(getRaisedTimestamp());
		clone.setLastUpdatedTimestamp(getLastUpdatedTimestamp());
		clone.setStatus(getStatus());
		clone.setOc(getOc());
		clone.setState(getState());
		clone.setRegion(getRegion());
		clone.setQueueName(getQueueName());
		clone.setQueueLevel(getQueueLevel());
		clone.setAssignedTo(getAssignedTo());

		return clone;
	}

	@Override
	public int compareTo(Query_Txn query_Txn) {
		long primaryKey = query_Txn.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof Query_TxnClp)) {
			return false;
		}

		Query_TxnClp query_Txn = (Query_TxnClp)obj;

		long primaryKey = query_Txn.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(27);

		sb.append("{queryId=");
		sb.append(getQueryId());
		sb.append(", caseNo=");
		sb.append(getCaseNo());
		sb.append(", description=");
		sb.append(getDescription());
		sb.append(", raisedBy=");
		sb.append(getRaisedBy());
		sb.append(", raisedTimestamp=");
		sb.append(getRaisedTimestamp());
		sb.append(", lastUpdatedTimestamp=");
		sb.append(getLastUpdatedTimestamp());
		sb.append(", status=");
		sb.append(getStatus());
		sb.append(", oc=");
		sb.append(getOc());
		sb.append(", state=");
		sb.append(getState());
		sb.append(", region=");
		sb.append(getRegion());
		sb.append(", queueName=");
		sb.append(getQueueName());
		sb.append(", queueLevel=");
		sb.append(getQueueLevel());
		sb.append(", assignedTo=");
		sb.append(getAssignedTo());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(43);

		sb.append("<model><model-name>");
		sb.append("com.jioc.query.model.Query_Txn");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>queryId</column-name><column-value><![CDATA[");
		sb.append(getQueryId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>caseNo</column-name><column-value><![CDATA[");
		sb.append(getCaseNo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>description</column-name><column-value><![CDATA[");
		sb.append(getDescription());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>raisedBy</column-name><column-value><![CDATA[");
		sb.append(getRaisedBy());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>raisedTimestamp</column-name><column-value><![CDATA[");
		sb.append(getRaisedTimestamp());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>lastUpdatedTimestamp</column-name><column-value><![CDATA[");
		sb.append(getLastUpdatedTimestamp());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>status</column-name><column-value><![CDATA[");
		sb.append(getStatus());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>oc</column-name><column-value><![CDATA[");
		sb.append(getOc());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>state</column-name><column-value><![CDATA[");
		sb.append(getState());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>region</column-name><column-value><![CDATA[");
		sb.append(getRegion());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>queueName</column-name><column-value><![CDATA[");
		sb.append(getQueueName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>queueLevel</column-name><column-value><![CDATA[");
		sb.append(getQueueLevel());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>assignedTo</column-name><column-value><![CDATA[");
		sb.append(getAssignedTo());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _queryId;
	private String _caseNo;
	private String _description;
	private String _raisedBy;
	private Date _raisedTimestamp;
	private Date _lastUpdatedTimestamp;
	private String _status;
	private String _oc;
	private String _state;
	private String _region;
	private String _queueName;
	private int _queueLevel;
	private String _assignedTo;
	private BaseModel<?> _query_TxnRemoteModel;
	private Class<?> _clpSerializerClass = com.jioc.query.service.ClpSerializer.class;
}