/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.model.RESOLVER_DEFAULTS;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import java.util.List;

/**
 * The persistence utility for the r e s o l v e r_ d e f a u l t s service. This utility wraps {@link RESOLVER_DEFAULTSPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see RESOLVER_DEFAULTSPersistence
 * @see RESOLVER_DEFAULTSPersistenceImpl
 * @generated
 */
public class RESOLVER_DEFAULTSUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(RESOLVER_DEFAULTS resolver_defaults) {
		getPersistence().clearCache(resolver_defaults);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<RESOLVER_DEFAULTS> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<RESOLVER_DEFAULTS> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<RESOLVER_DEFAULTS> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static RESOLVER_DEFAULTS update(RESOLVER_DEFAULTS resolver_defaults)
		throws SystemException {
		return getPersistence().update(resolver_defaults);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static RESOLVER_DEFAULTS update(
		RESOLVER_DEFAULTS resolver_defaults, ServiceContext serviceContext)
		throws SystemException {
		return getPersistence().update(resolver_defaults, serviceContext);
	}

	/**
	* Returns all the r e s o l v e r_ d e f a u l t ses where TYPE = &#63; and VALUE = &#63;.
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @return the matching r e s o l v e r_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.RESOLVER_DEFAULTS> findByTypeValue(
		java.lang.String TYPE, java.lang.String VALUE)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByTypeValue(TYPE, VALUE);
	}

	/**
	* Returns a range of all the r e s o l v e r_ d e f a u l t ses where TYPE = &#63; and VALUE = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.RESOLVER_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @param start the lower bound of the range of r e s o l v e r_ d e f a u l t ses
	* @param end the upper bound of the range of r e s o l v e r_ d e f a u l t ses (not inclusive)
	* @return the range of matching r e s o l v e r_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.RESOLVER_DEFAULTS> findByTypeValue(
		java.lang.String TYPE, java.lang.String VALUE, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByTypeValue(TYPE, VALUE, start, end);
	}

	/**
	* Returns an ordered range of all the r e s o l v e r_ d e f a u l t ses where TYPE = &#63; and VALUE = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.RESOLVER_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @param start the lower bound of the range of r e s o l v e r_ d e f a u l t ses
	* @param end the upper bound of the range of r e s o l v e r_ d e f a u l t ses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching r e s o l v e r_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.RESOLVER_DEFAULTS> findByTypeValue(
		java.lang.String TYPE, java.lang.String VALUE, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByTypeValue(TYPE, VALUE, start, end, orderByComparator);
	}

	/**
	* Returns the first r e s o l v e r_ d e f a u l t s in the ordered set where TYPE = &#63; and VALUE = &#63;.
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching r e s o l v e r_ d e f a u l t s
	* @throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException if a matching r e s o l v e r_ d e f a u l t s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.RESOLVER_DEFAULTS findByTypeValue_First(
		java.lang.String TYPE, java.lang.String VALUE,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByTypeValue_First(TYPE, VALUE, orderByComparator);
	}

	/**
	* Returns the first r e s o l v e r_ d e f a u l t s in the ordered set where TYPE = &#63; and VALUE = &#63;.
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching r e s o l v e r_ d e f a u l t s, or <code>null</code> if a matching r e s o l v e r_ d e f a u l t s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.RESOLVER_DEFAULTS fetchByTypeValue_First(
		java.lang.String TYPE, java.lang.String VALUE,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByTypeValue_First(TYPE, VALUE, orderByComparator);
	}

	/**
	* Returns the last r e s o l v e r_ d e f a u l t s in the ordered set where TYPE = &#63; and VALUE = &#63;.
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching r e s o l v e r_ d e f a u l t s
	* @throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException if a matching r e s o l v e r_ d e f a u l t s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.RESOLVER_DEFAULTS findByTypeValue_Last(
		java.lang.String TYPE, java.lang.String VALUE,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByTypeValue_Last(TYPE, VALUE, orderByComparator);
	}

	/**
	* Returns the last r e s o l v e r_ d e f a u l t s in the ordered set where TYPE = &#63; and VALUE = &#63;.
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching r e s o l v e r_ d e f a u l t s, or <code>null</code> if a matching r e s o l v e r_ d e f a u l t s could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.RESOLVER_DEFAULTS fetchByTypeValue_Last(
		java.lang.String TYPE, java.lang.String VALUE,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByTypeValue_Last(TYPE, VALUE, orderByComparator);
	}

	/**
	* Returns the r e s o l v e r_ d e f a u l t ses before and after the current r e s o l v e r_ d e f a u l t s in the ordered set where TYPE = &#63; and VALUE = &#63;.
	*
	* @param DEFAULT_ID the primary key of the current r e s o l v e r_ d e f a u l t s
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next r e s o l v e r_ d e f a u l t s
	* @throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException if a r e s o l v e r_ d e f a u l t s with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.RESOLVER_DEFAULTS[] findByTypeValue_PrevAndNext(
		long DEFAULT_ID, java.lang.String TYPE, java.lang.String VALUE,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByTypeValue_PrevAndNext(DEFAULT_ID, TYPE, VALUE,
			orderByComparator);
	}

	/**
	* Removes all the r e s o l v e r_ d e f a u l t ses where TYPE = &#63; and VALUE = &#63; from the database.
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByTypeValue(java.lang.String TYPE,
		java.lang.String VALUE)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByTypeValue(TYPE, VALUE);
	}

	/**
	* Returns the number of r e s o l v e r_ d e f a u l t ses where TYPE = &#63; and VALUE = &#63;.
	*
	* @param TYPE the t y p e
	* @param VALUE the v a l u e
	* @return the number of matching r e s o l v e r_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public static int countByTypeValue(java.lang.String TYPE,
		java.lang.String VALUE)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByTypeValue(TYPE, VALUE);
	}

	/**
	* Caches the r e s o l v e r_ d e f a u l t s in the entity cache if it is enabled.
	*
	* @param resolver_defaults the r e s o l v e r_ d e f a u l t s
	*/
	public static void cacheResult(
		com.jioc.query.model.RESOLVER_DEFAULTS resolver_defaults) {
		getPersistence().cacheResult(resolver_defaults);
	}

	/**
	* Caches the r e s o l v e r_ d e f a u l t ses in the entity cache if it is enabled.
	*
	* @param resolver_defaultses the r e s o l v e r_ d e f a u l t ses
	*/
	public static void cacheResult(
		java.util.List<com.jioc.query.model.RESOLVER_DEFAULTS> resolver_defaultses) {
		getPersistence().cacheResult(resolver_defaultses);
	}

	/**
	* Creates a new r e s o l v e r_ d e f a u l t s with the primary key. Does not add the r e s o l v e r_ d e f a u l t s to the database.
	*
	* @param DEFAULT_ID the primary key for the new r e s o l v e r_ d e f a u l t s
	* @return the new r e s o l v e r_ d e f a u l t s
	*/
	public static com.jioc.query.model.RESOLVER_DEFAULTS create(long DEFAULT_ID) {
		return getPersistence().create(DEFAULT_ID);
	}

	/**
	* Removes the r e s o l v e r_ d e f a u l t s with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param DEFAULT_ID the primary key of the r e s o l v e r_ d e f a u l t s
	* @return the r e s o l v e r_ d e f a u l t s that was removed
	* @throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException if a r e s o l v e r_ d e f a u l t s with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.RESOLVER_DEFAULTS remove(long DEFAULT_ID)
		throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().remove(DEFAULT_ID);
	}

	public static com.jioc.query.model.RESOLVER_DEFAULTS updateImpl(
		com.jioc.query.model.RESOLVER_DEFAULTS resolver_defaults)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(resolver_defaults);
	}

	/**
	* Returns the r e s o l v e r_ d e f a u l t s with the primary key or throws a {@link com.jioc.query.NoSuchRESOLVER_DEFAULTSException} if it could not be found.
	*
	* @param DEFAULT_ID the primary key of the r e s o l v e r_ d e f a u l t s
	* @return the r e s o l v e r_ d e f a u l t s
	* @throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException if a r e s o l v e r_ d e f a u l t s with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.RESOLVER_DEFAULTS findByPrimaryKey(
		long DEFAULT_ID)
		throws com.jioc.query.NoSuchRESOLVER_DEFAULTSException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPrimaryKey(DEFAULT_ID);
	}

	/**
	* Returns the r e s o l v e r_ d e f a u l t s with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param DEFAULT_ID the primary key of the r e s o l v e r_ d e f a u l t s
	* @return the r e s o l v e r_ d e f a u l t s, or <code>null</code> if a r e s o l v e r_ d e f a u l t s with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.RESOLVER_DEFAULTS fetchByPrimaryKey(
		long DEFAULT_ID)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(DEFAULT_ID);
	}

	/**
	* Returns all the r e s o l v e r_ d e f a u l t ses.
	*
	* @return the r e s o l v e r_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.RESOLVER_DEFAULTS> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the r e s o l v e r_ d e f a u l t ses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.RESOLVER_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of r e s o l v e r_ d e f a u l t ses
	* @param end the upper bound of the range of r e s o l v e r_ d e f a u l t ses (not inclusive)
	* @return the range of r e s o l v e r_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.RESOLVER_DEFAULTS> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the r e s o l v e r_ d e f a u l t ses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.RESOLVER_DEFAULTSModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of r e s o l v e r_ d e f a u l t ses
	* @param end the upper bound of the range of r e s o l v e r_ d e f a u l t ses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of r e s o l v e r_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.RESOLVER_DEFAULTS> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the r e s o l v e r_ d e f a u l t ses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of r e s o l v e r_ d e f a u l t ses.
	*
	* @return the number of r e s o l v e r_ d e f a u l t ses
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static RESOLVER_DEFAULTSPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (RESOLVER_DEFAULTSPersistence)PortletBeanLocatorUtil.locate(com.jioc.query.service.ClpSerializer.getServletContextName(),
					RESOLVER_DEFAULTSPersistence.class.getName());

			ReferenceRegistry.registerReference(RESOLVER_DEFAULTSUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(RESOLVER_DEFAULTSPersistence persistence) {
	}

	private static RESOLVER_DEFAULTSPersistence _persistence;
}