/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.jioc.query.service.ClpSerializer;
import com.jioc.query.service.Emp_User_MappingLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author shantaram.chavan
 */
public class Emp_User_MappingClp extends BaseModelImpl<Emp_User_Mapping>
	implements Emp_User_Mapping {
	public Emp_User_MappingClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return Emp_User_Mapping.class;
	}

	@Override
	public String getModelClassName() {
		return Emp_User_Mapping.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _userId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setUserId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _userId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("userId", getUserId());
		attributes.put("empId", getEmpId());
		attributes.put("emailId", getEmailId());
		attributes.put("domainId", getDomainId());
		attributes.put("samlFederationId", getSamlFederationId());
		attributes.put("status", getStatus());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String empId = (String)attributes.get("empId");

		if (empId != null) {
			setEmpId(empId);
		}

		String emailId = (String)attributes.get("emailId");

		if (emailId != null) {
			setEmailId(emailId);
		}

		String domainId = (String)attributes.get("domainId");

		if (domainId != null) {
			setDomainId(domainId);
		}

		String samlFederationId = (String)attributes.get("samlFederationId");

		if (samlFederationId != null) {
			setSamlFederationId(samlFederationId);
		}

		Integer status = (Integer)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}
	}

	@Override
	public long getUserId() {
		return _userId;
	}

	@Override
	public void setUserId(long userId) {
		_userId = userId;

		if (_emp_User_MappingRemoteModel != null) {
			try {
				Class<?> clazz = _emp_User_MappingRemoteModel.getClass();

				Method method = clazz.getMethod("setUserId", long.class);

				method.invoke(_emp_User_MappingRemoteModel, userId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUserUuid() throws SystemException {
		return PortalUtil.getUserValue(getUserId(), "uuid", _userUuid);
	}

	@Override
	public void setUserUuid(String userUuid) {
		_userUuid = userUuid;
	}

	@Override
	public String getEmpId() {
		return _empId;
	}

	@Override
	public void setEmpId(String empId) {
		_empId = empId;

		if (_emp_User_MappingRemoteModel != null) {
			try {
				Class<?> clazz = _emp_User_MappingRemoteModel.getClass();

				Method method = clazz.getMethod("setEmpId", String.class);

				method.invoke(_emp_User_MappingRemoteModel, empId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEmailId() {
		return _emailId;
	}

	@Override
	public void setEmailId(String emailId) {
		_emailId = emailId;

		if (_emp_User_MappingRemoteModel != null) {
			try {
				Class<?> clazz = _emp_User_MappingRemoteModel.getClass();

				Method method = clazz.getMethod("setEmailId", String.class);

				method.invoke(_emp_User_MappingRemoteModel, emailId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDomainId() {
		return _domainId;
	}

	@Override
	public void setDomainId(String domainId) {
		_domainId = domainId;

		if (_emp_User_MappingRemoteModel != null) {
			try {
				Class<?> clazz = _emp_User_MappingRemoteModel.getClass();

				Method method = clazz.getMethod("setDomainId", String.class);

				method.invoke(_emp_User_MappingRemoteModel, domainId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSamlFederationId() {
		return _samlFederationId;
	}

	@Override
	public void setSamlFederationId(String samlFederationId) {
		_samlFederationId = samlFederationId;

		if (_emp_User_MappingRemoteModel != null) {
			try {
				Class<?> clazz = _emp_User_MappingRemoteModel.getClass();

				Method method = clazz.getMethod("setSamlFederationId",
						String.class);

				method.invoke(_emp_User_MappingRemoteModel, samlFederationId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getStatus() {
		return _status;
	}

	@Override
	public void setStatus(int status) {
		_status = status;

		if (_emp_User_MappingRemoteModel != null) {
			try {
				Class<?> clazz = _emp_User_MappingRemoteModel.getClass();

				Method method = clazz.getMethod("setStatus", int.class);

				method.invoke(_emp_User_MappingRemoteModel, status);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getEmp_User_MappingRemoteModel() {
		return _emp_User_MappingRemoteModel;
	}

	public void setEmp_User_MappingRemoteModel(
		BaseModel<?> emp_User_MappingRemoteModel) {
		_emp_User_MappingRemoteModel = emp_User_MappingRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _emp_User_MappingRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_emp_User_MappingRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			Emp_User_MappingLocalServiceUtil.addEmp_User_Mapping(this);
		}
		else {
			Emp_User_MappingLocalServiceUtil.updateEmp_User_Mapping(this);
		}
	}

	@Override
	public Emp_User_Mapping toEscapedModel() {
		return (Emp_User_Mapping)ProxyUtil.newProxyInstance(Emp_User_Mapping.class.getClassLoader(),
			new Class[] { Emp_User_Mapping.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		Emp_User_MappingClp clone = new Emp_User_MappingClp();

		clone.setUserId(getUserId());
		clone.setEmpId(getEmpId());
		clone.setEmailId(getEmailId());
		clone.setDomainId(getDomainId());
		clone.setSamlFederationId(getSamlFederationId());
		clone.setStatus(getStatus());

		return clone;
	}

	@Override
	public int compareTo(Emp_User_Mapping emp_User_Mapping) {
		long primaryKey = emp_User_Mapping.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof Emp_User_MappingClp)) {
			return false;
		}

		Emp_User_MappingClp emp_User_Mapping = (Emp_User_MappingClp)obj;

		long primaryKey = emp_User_Mapping.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{userId=");
		sb.append(getUserId());
		sb.append(", empId=");
		sb.append(getEmpId());
		sb.append(", emailId=");
		sb.append(getEmailId());
		sb.append(", domainId=");
		sb.append(getDomainId());
		sb.append(", samlFederationId=");
		sb.append(getSamlFederationId());
		sb.append(", status=");
		sb.append(getStatus());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(22);

		sb.append("<model><model-name>");
		sb.append("com.jioc.query.model.Emp_User_Mapping");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>userId</column-name><column-value><![CDATA[");
		sb.append(getUserId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>empId</column-name><column-value><![CDATA[");
		sb.append(getEmpId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>emailId</column-name><column-value><![CDATA[");
		sb.append(getEmailId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>domainId</column-name><column-value><![CDATA[");
		sb.append(getDomainId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>samlFederationId</column-name><column-value><![CDATA[");
		sb.append(getSamlFederationId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>status</column-name><column-value><![CDATA[");
		sb.append(getStatus());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _userId;
	private String _userUuid;
	private String _empId;
	private String _emailId;
	private String _domainId;
	private String _samlFederationId;
	private int _status;
	private BaseModel<?> _emp_User_MappingRemoteModel;
	private Class<?> _clpSerializerClass = com.jioc.query.service.ClpSerializer.class;
}