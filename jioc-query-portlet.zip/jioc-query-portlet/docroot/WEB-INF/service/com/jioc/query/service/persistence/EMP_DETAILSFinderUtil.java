/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;

/**
 * @author shantaram.chavan
 */
public class EMP_DETAILSFinderUtil {
	public static long findResolverByRR(java.lang.String region,
		java.lang.String state, java.lang.String oc, java.lang.String jioType,
		int resolverLevel) {
		return getFinder()
				   .findResolverByRR(region, state, oc, jioType, resolverLevel);
	}

	public static void updateEmpDetails() {
		getFinder().updateEmpDetails();
	}

	public static java.util.List<com.jioc.query.model.EMP_DETAILS> searchAssignees(
		java.lang.String region, java.lang.String circle,
		java.lang.String area, java.lang.String center, java.lang.String job) {
		return getFinder().searchAssignees(region, circle, area, center, job);
	}

	public static java.util.List<java.lang.String> getSearchJobByAreaCircleRegionJioCenterAndOc(
		java.lang.String region, java.lang.String circle,
		java.lang.String area, java.lang.String center) {
		return getFinder()
				   .getSearchJobByAreaCircleRegionJioCenterAndOc(region,
			circle, area, center);
	}

	public static EMP_DETAILSFinder getFinder() {
		if (_finder == null) {
			_finder = (EMP_DETAILSFinder)PortletBeanLocatorUtil.locate(com.jioc.query.service.ClpSerializer.getServletContextName(),
					EMP_DETAILSFinder.class.getName());

			ReferenceRegistry.registerReference(EMP_DETAILSFinderUtil.class,
				"_finder");
		}

		return _finder;
	}

	public void setFinder(EMP_DETAILSFinder finder) {
		_finder = finder;

		ReferenceRegistry.registerReference(EMP_DETAILSFinderUtil.class,
			"_finder");
	}

	private static EMP_DETAILSFinder _finder;
}