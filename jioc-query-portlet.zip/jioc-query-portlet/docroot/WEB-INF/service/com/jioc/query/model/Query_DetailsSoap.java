/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author shantaram.chavan
 * @generated
 */
public class Query_DetailsSoap implements Serializable {
	public static Query_DetailsSoap toSoapModel(Query_Details model) {
		Query_DetailsSoap soapModel = new Query_DetailsSoap();

		soapModel.setQueryDetailsId(model.getQueryDetailsId());
		soapModel.setQueryId(model.getQueryId());
		soapModel.setUpdatedTimestamp(model.getUpdatedTimestamp());
		soapModel.setUpdatedBy(model.getUpdatedBy());
		soapModel.setAssignedTo(model.getAssignedTo());
		soapModel.setAction(model.getAction());
		soapModel.setStatus(model.getStatus());
		soapModel.setState(model.getState());
		soapModel.setRegion(model.getRegion());
		soapModel.setOc(model.getOc());
		soapModel.setQueueLevel(model.getQueueLevel());
		soapModel.setComment(model.getComment());
		soapModel.setCategory(model.getCategory());
		soapModel.setSubCategory(model.getSubCategory());
		soapModel.setCaseResolution(model.getCaseResolution());
		soapModel.setIs_closed(model.getIs_closed());
		soapModel.setClosed_date(model.getClosed_date());

		return soapModel;
	}

	public static Query_DetailsSoap[] toSoapModels(Query_Details[] models) {
		Query_DetailsSoap[] soapModels = new Query_DetailsSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static Query_DetailsSoap[][] toSoapModels(Query_Details[][] models) {
		Query_DetailsSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new Query_DetailsSoap[models.length][models[0].length];
		}
		else {
			soapModels = new Query_DetailsSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static Query_DetailsSoap[] toSoapModels(List<Query_Details> models) {
		List<Query_DetailsSoap> soapModels = new ArrayList<Query_DetailsSoap>(models.size());

		for (Query_Details model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new Query_DetailsSoap[soapModels.size()]);
	}

	public Query_DetailsSoap() {
	}

	public long getPrimaryKey() {
		return _queryDetailsId;
	}

	public void setPrimaryKey(long pk) {
		setQueryDetailsId(pk);
	}

	public long getQueryDetailsId() {
		return _queryDetailsId;
	}

	public void setQueryDetailsId(long queryDetailsId) {
		_queryDetailsId = queryDetailsId;
	}

	public long getQueryId() {
		return _queryId;
	}

	public void setQueryId(long queryId) {
		_queryId = queryId;
	}

	public Date getUpdatedTimestamp() {
		return _updatedTimestamp;
	}

	public void setUpdatedTimestamp(Date updatedTimestamp) {
		_updatedTimestamp = updatedTimestamp;
	}

	public long getUpdatedBy() {
		return _updatedBy;
	}

	public void setUpdatedBy(long updatedBy) {
		_updatedBy = updatedBy;
	}

	public long getAssignedTo() {
		return _assignedTo;
	}

	public void setAssignedTo(long assignedTo) {
		_assignedTo = assignedTo;
	}

	public String getAction() {
		return _action;
	}

	public void setAction(String action) {
		_action = action;
	}

	public String getStatus() {
		return _status;
	}

	public void setStatus(String status) {
		_status = status;
	}

	public String getState() {
		return _state;
	}

	public void setState(String state) {
		_state = state;
	}

	public String getRegion() {
		return _region;
	}

	public void setRegion(String region) {
		_region = region;
	}

	public String getOc() {
		return _oc;
	}

	public void setOc(String oc) {
		_oc = oc;
	}

	public int getQueueLevel() {
		return _queueLevel;
	}

	public void setQueueLevel(int queueLevel) {
		_queueLevel = queueLevel;
	}

	public String getComment() {
		return _comment;
	}

	public void setComment(String comment) {
		_comment = comment;
	}

	public long getCategory() {
		return _category;
	}

	public void setCategory(long category) {
		_category = category;
	}

	public long getSubCategory() {
		return _subCategory;
	}

	public void setSubCategory(long subCategory) {
		_subCategory = subCategory;
	}

	public long getCaseResolution() {
		return _caseResolution;
	}

	public void setCaseResolution(long caseResolution) {
		_caseResolution = caseResolution;
	}

	public int getIs_closed() {
		return _is_closed;
	}

	public void setIs_closed(int is_closed) {
		_is_closed = is_closed;
	}

	public Date getClosed_date() {
		return _closed_date;
	}

	public void setClosed_date(Date closed_date) {
		_closed_date = closed_date;
	}

	private long _queryDetailsId;
	private long _queryId;
	private Date _updatedTimestamp;
	private long _updatedBy;
	private long _assignedTo;
	private String _action;
	private String _status;
	private String _state;
	private String _region;
	private String _oc;
	private int _queueLevel;
	private String _comment;
	private long _category;
	private long _subCategory;
	private long _caseResolution;
	private int _is_closed;
	private Date _closed_date;
}