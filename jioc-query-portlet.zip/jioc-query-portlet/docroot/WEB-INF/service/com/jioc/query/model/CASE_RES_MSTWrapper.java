/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link CASE_RES_MST}.
 * </p>
 *
 * @author shantaram.chavan
 * @see CASE_RES_MST
 * @generated
 */
public class CASE_RES_MSTWrapper implements CASE_RES_MST,
	ModelWrapper<CASE_RES_MST> {
	public CASE_RES_MSTWrapper(CASE_RES_MST case_res_mst) {
		_case_res_mst = case_res_mst;
	}

	@Override
	public Class<?> getModelClass() {
		return CASE_RES_MST.class;
	}

	@Override
	public String getModelClassName() {
		return CASE_RES_MST.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("CASE_RES_ID", getCASE_RES_ID());
		attributes.put("CASE_RES_NAME", getCASE_RES_NAME());
		attributes.put("IS_ACTIVE", getIS_ACTIVE());
		attributes.put("OC", getOC());
		attributes.put("UPDATED_TIMESTAMP", getUPDATED_TIMESTAMP());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long CASE_RES_ID = (Long)attributes.get("CASE_RES_ID");

		if (CASE_RES_ID != null) {
			setCASE_RES_ID(CASE_RES_ID);
		}

		String CASE_RES_NAME = (String)attributes.get("CASE_RES_NAME");

		if (CASE_RES_NAME != null) {
			setCASE_RES_NAME(CASE_RES_NAME);
		}

		Integer IS_ACTIVE = (Integer)attributes.get("IS_ACTIVE");

		if (IS_ACTIVE != null) {
			setIS_ACTIVE(IS_ACTIVE);
		}

		String OC = (String)attributes.get("OC");

		if (OC != null) {
			setOC(OC);
		}

		Date UPDATED_TIMESTAMP = (Date)attributes.get("UPDATED_TIMESTAMP");

		if (UPDATED_TIMESTAMP != null) {
			setUPDATED_TIMESTAMP(UPDATED_TIMESTAMP);
		}
	}

	/**
	* Returns the primary key of this c a s e_ r e s_ m s t.
	*
	* @return the primary key of this c a s e_ r e s_ m s t
	*/
	@Override
	public long getPrimaryKey() {
		return _case_res_mst.getPrimaryKey();
	}

	/**
	* Sets the primary key of this c a s e_ r e s_ m s t.
	*
	* @param primaryKey the primary key of this c a s e_ r e s_ m s t
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_case_res_mst.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the c a s e_ r e s_ i d of this c a s e_ r e s_ m s t.
	*
	* @return the c a s e_ r e s_ i d of this c a s e_ r e s_ m s t
	*/
	@Override
	public long getCASE_RES_ID() {
		return _case_res_mst.getCASE_RES_ID();
	}

	/**
	* Sets the c a s e_ r e s_ i d of this c a s e_ r e s_ m s t.
	*
	* @param CASE_RES_ID the c a s e_ r e s_ i d of this c a s e_ r e s_ m s t
	*/
	@Override
	public void setCASE_RES_ID(long CASE_RES_ID) {
		_case_res_mst.setCASE_RES_ID(CASE_RES_ID);
	}

	/**
	* Returns the c a s e_ r e s_ n a m e of this c a s e_ r e s_ m s t.
	*
	* @return the c a s e_ r e s_ n a m e of this c a s e_ r e s_ m s t
	*/
	@Override
	public java.lang.String getCASE_RES_NAME() {
		return _case_res_mst.getCASE_RES_NAME();
	}

	/**
	* Sets the c a s e_ r e s_ n a m e of this c a s e_ r e s_ m s t.
	*
	* @param CASE_RES_NAME the c a s e_ r e s_ n a m e of this c a s e_ r e s_ m s t
	*/
	@Override
	public void setCASE_RES_NAME(java.lang.String CASE_RES_NAME) {
		_case_res_mst.setCASE_RES_NAME(CASE_RES_NAME);
	}

	/**
	* Returns the i s_ a c t i v e of this c a s e_ r e s_ m s t.
	*
	* @return the i s_ a c t i v e of this c a s e_ r e s_ m s t
	*/
	@Override
	public int getIS_ACTIVE() {
		return _case_res_mst.getIS_ACTIVE();
	}

	/**
	* Sets the i s_ a c t i v e of this c a s e_ r e s_ m s t.
	*
	* @param IS_ACTIVE the i s_ a c t i v e of this c a s e_ r e s_ m s t
	*/
	@Override
	public void setIS_ACTIVE(int IS_ACTIVE) {
		_case_res_mst.setIS_ACTIVE(IS_ACTIVE);
	}

	/**
	* Returns the o c of this c a s e_ r e s_ m s t.
	*
	* @return the o c of this c a s e_ r e s_ m s t
	*/
	@Override
	public java.lang.String getOC() {
		return _case_res_mst.getOC();
	}

	/**
	* Sets the o c of this c a s e_ r e s_ m s t.
	*
	* @param OC the o c of this c a s e_ r e s_ m s t
	*/
	@Override
	public void setOC(java.lang.String OC) {
		_case_res_mst.setOC(OC);
	}

	/**
	* Returns the u p d a t e d_ t i m e s t a m p of this c a s e_ r e s_ m s t.
	*
	* @return the u p d a t e d_ t i m e s t a m p of this c a s e_ r e s_ m s t
	*/
	@Override
	public java.util.Date getUPDATED_TIMESTAMP() {
		return _case_res_mst.getUPDATED_TIMESTAMP();
	}

	/**
	* Sets the u p d a t e d_ t i m e s t a m p of this c a s e_ r e s_ m s t.
	*
	* @param UPDATED_TIMESTAMP the u p d a t e d_ t i m e s t a m p of this c a s e_ r e s_ m s t
	*/
	@Override
	public void setUPDATED_TIMESTAMP(java.util.Date UPDATED_TIMESTAMP) {
		_case_res_mst.setUPDATED_TIMESTAMP(UPDATED_TIMESTAMP);
	}

	@Override
	public boolean isNew() {
		return _case_res_mst.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_case_res_mst.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _case_res_mst.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_case_res_mst.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _case_res_mst.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _case_res_mst.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_case_res_mst.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _case_res_mst.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_case_res_mst.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_case_res_mst.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_case_res_mst.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new CASE_RES_MSTWrapper((CASE_RES_MST)_case_res_mst.clone());
	}

	@Override
	public int compareTo(com.jioc.query.model.CASE_RES_MST case_res_mst) {
		return _case_res_mst.compareTo(case_res_mst);
	}

	@Override
	public int hashCode() {
		return _case_res_mst.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jioc.query.model.CASE_RES_MST> toCacheModel() {
		return _case_res_mst.toCacheModel();
	}

	@Override
	public com.jioc.query.model.CASE_RES_MST toEscapedModel() {
		return new CASE_RES_MSTWrapper(_case_res_mst.toEscapedModel());
	}

	@Override
	public com.jioc.query.model.CASE_RES_MST toUnescapedModel() {
		return new CASE_RES_MSTWrapper(_case_res_mst.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _case_res_mst.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _case_res_mst.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_case_res_mst.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof CASE_RES_MSTWrapper)) {
			return false;
		}

		CASE_RES_MSTWrapper case_res_mstWrapper = (CASE_RES_MSTWrapper)obj;

		if (Validator.equals(_case_res_mst, case_res_mstWrapper._case_res_mst)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public CASE_RES_MST getWrappedCASE_RES_MST() {
		return _case_res_mst;
	}

	@Override
	public CASE_RES_MST getWrappedModel() {
		return _case_res_mst;
	}

	@Override
	public void resetOriginalValues() {
		_case_res_mst.resetOriginalValues();
	}

	private CASE_RES_MST _case_res_mst;
}