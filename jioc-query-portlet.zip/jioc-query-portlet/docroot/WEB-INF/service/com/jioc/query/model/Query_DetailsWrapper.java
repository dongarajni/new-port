/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Query_Details}.
 * </p>
 *
 * @author shantaram.chavan
 * @see Query_Details
 * @generated
 */
public class Query_DetailsWrapper implements Query_Details,
	ModelWrapper<Query_Details> {
	public Query_DetailsWrapper(Query_Details query_Details) {
		_query_Details = query_Details;
	}

	@Override
	public Class<?> getModelClass() {
		return Query_Details.class;
	}

	@Override
	public String getModelClassName() {
		return Query_Details.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("queryDetailsId", getQueryDetailsId());
		attributes.put("queryId", getQueryId());
		attributes.put("updatedTimestamp", getUpdatedTimestamp());
		attributes.put("updatedBy", getUpdatedBy());
		attributes.put("assignedTo", getAssignedTo());
		attributes.put("action", getAction());
		attributes.put("status", getStatus());
		attributes.put("state", getState());
		attributes.put("region", getRegion());
		attributes.put("oc", getOc());
		attributes.put("queueLevel", getQueueLevel());
		attributes.put("comment", getComment());
		attributes.put("category", getCategory());
		attributes.put("subCategory", getSubCategory());
		attributes.put("caseResolution", getCaseResolution());
		attributes.put("is_closed", getIs_closed());
		attributes.put("closed_date", getClosed_date());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long queryDetailsId = (Long)attributes.get("queryDetailsId");

		if (queryDetailsId != null) {
			setQueryDetailsId(queryDetailsId);
		}

		Long queryId = (Long)attributes.get("queryId");

		if (queryId != null) {
			setQueryId(queryId);
		}

		Date updatedTimestamp = (Date)attributes.get("updatedTimestamp");

		if (updatedTimestamp != null) {
			setUpdatedTimestamp(updatedTimestamp);
		}

		Long updatedBy = (Long)attributes.get("updatedBy");

		if (updatedBy != null) {
			setUpdatedBy(updatedBy);
		}

		Long assignedTo = (Long)attributes.get("assignedTo");

		if (assignedTo != null) {
			setAssignedTo(assignedTo);
		}

		String action = (String)attributes.get("action");

		if (action != null) {
			setAction(action);
		}

		String status = (String)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String state = (String)attributes.get("state");

		if (state != null) {
			setState(state);
		}

		String region = (String)attributes.get("region");

		if (region != null) {
			setRegion(region);
		}

		String oc = (String)attributes.get("oc");

		if (oc != null) {
			setOc(oc);
		}

		Integer queueLevel = (Integer)attributes.get("queueLevel");

		if (queueLevel != null) {
			setQueueLevel(queueLevel);
		}

		String comment = (String)attributes.get("comment");

		if (comment != null) {
			setComment(comment);
		}

		Long category = (Long)attributes.get("category");

		if (category != null) {
			setCategory(category);
		}

		Long subCategory = (Long)attributes.get("subCategory");

		if (subCategory != null) {
			setSubCategory(subCategory);
		}

		Long caseResolution = (Long)attributes.get("caseResolution");

		if (caseResolution != null) {
			setCaseResolution(caseResolution);
		}

		Integer is_closed = (Integer)attributes.get("is_closed");

		if (is_closed != null) {
			setIs_closed(is_closed);
		}

		Date closed_date = (Date)attributes.get("closed_date");

		if (closed_date != null) {
			setClosed_date(closed_date);
		}
	}

	/**
	* Returns the primary key of this query_ details.
	*
	* @return the primary key of this query_ details
	*/
	@Override
	public long getPrimaryKey() {
		return _query_Details.getPrimaryKey();
	}

	/**
	* Sets the primary key of this query_ details.
	*
	* @param primaryKey the primary key of this query_ details
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_query_Details.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the query details ID of this query_ details.
	*
	* @return the query details ID of this query_ details
	*/
	@Override
	public long getQueryDetailsId() {
		return _query_Details.getQueryDetailsId();
	}

	/**
	* Sets the query details ID of this query_ details.
	*
	* @param queryDetailsId the query details ID of this query_ details
	*/
	@Override
	public void setQueryDetailsId(long queryDetailsId) {
		_query_Details.setQueryDetailsId(queryDetailsId);
	}

	/**
	* Returns the query ID of this query_ details.
	*
	* @return the query ID of this query_ details
	*/
	@Override
	public long getQueryId() {
		return _query_Details.getQueryId();
	}

	/**
	* Sets the query ID of this query_ details.
	*
	* @param queryId the query ID of this query_ details
	*/
	@Override
	public void setQueryId(long queryId) {
		_query_Details.setQueryId(queryId);
	}

	/**
	* Returns the updated timestamp of this query_ details.
	*
	* @return the updated timestamp of this query_ details
	*/
	@Override
	public java.util.Date getUpdatedTimestamp() {
		return _query_Details.getUpdatedTimestamp();
	}

	/**
	* Sets the updated timestamp of this query_ details.
	*
	* @param updatedTimestamp the updated timestamp of this query_ details
	*/
	@Override
	public void setUpdatedTimestamp(java.util.Date updatedTimestamp) {
		_query_Details.setUpdatedTimestamp(updatedTimestamp);
	}

	/**
	* Returns the updated by of this query_ details.
	*
	* @return the updated by of this query_ details
	*/
	@Override
	public long getUpdatedBy() {
		return _query_Details.getUpdatedBy();
	}

	/**
	* Sets the updated by of this query_ details.
	*
	* @param updatedBy the updated by of this query_ details
	*/
	@Override
	public void setUpdatedBy(long updatedBy) {
		_query_Details.setUpdatedBy(updatedBy);
	}

	/**
	* Returns the assigned to of this query_ details.
	*
	* @return the assigned to of this query_ details
	*/
	@Override
	public long getAssignedTo() {
		return _query_Details.getAssignedTo();
	}

	/**
	* Sets the assigned to of this query_ details.
	*
	* @param assignedTo the assigned to of this query_ details
	*/
	@Override
	public void setAssignedTo(long assignedTo) {
		_query_Details.setAssignedTo(assignedTo);
	}

	/**
	* Returns the action of this query_ details.
	*
	* @return the action of this query_ details
	*/
	@Override
	public java.lang.String getAction() {
		return _query_Details.getAction();
	}

	/**
	* Sets the action of this query_ details.
	*
	* @param action the action of this query_ details
	*/
	@Override
	public void setAction(java.lang.String action) {
		_query_Details.setAction(action);
	}

	/**
	* Returns the status of this query_ details.
	*
	* @return the status of this query_ details
	*/
	@Override
	public java.lang.String getStatus() {
		return _query_Details.getStatus();
	}

	/**
	* Sets the status of this query_ details.
	*
	* @param status the status of this query_ details
	*/
	@Override
	public void setStatus(java.lang.String status) {
		_query_Details.setStatus(status);
	}

	/**
	* Returns the state of this query_ details.
	*
	* @return the state of this query_ details
	*/
	@Override
	public java.lang.String getState() {
		return _query_Details.getState();
	}

	/**
	* Sets the state of this query_ details.
	*
	* @param state the state of this query_ details
	*/
	@Override
	public void setState(java.lang.String state) {
		_query_Details.setState(state);
	}

	/**
	* Returns the region of this query_ details.
	*
	* @return the region of this query_ details
	*/
	@Override
	public java.lang.String getRegion() {
		return _query_Details.getRegion();
	}

	/**
	* Sets the region of this query_ details.
	*
	* @param region the region of this query_ details
	*/
	@Override
	public void setRegion(java.lang.String region) {
		_query_Details.setRegion(region);
	}

	/**
	* Returns the oc of this query_ details.
	*
	* @return the oc of this query_ details
	*/
	@Override
	public java.lang.String getOc() {
		return _query_Details.getOc();
	}

	/**
	* Sets the oc of this query_ details.
	*
	* @param oc the oc of this query_ details
	*/
	@Override
	public void setOc(java.lang.String oc) {
		_query_Details.setOc(oc);
	}

	/**
	* Returns the queue level of this query_ details.
	*
	* @return the queue level of this query_ details
	*/
	@Override
	public int getQueueLevel() {
		return _query_Details.getQueueLevel();
	}

	/**
	* Sets the queue level of this query_ details.
	*
	* @param queueLevel the queue level of this query_ details
	*/
	@Override
	public void setQueueLevel(int queueLevel) {
		_query_Details.setQueueLevel(queueLevel);
	}

	/**
	* Returns the comment of this query_ details.
	*
	* @return the comment of this query_ details
	*/
	@Override
	public java.lang.String getComment() {
		return _query_Details.getComment();
	}

	/**
	* Sets the comment of this query_ details.
	*
	* @param comment the comment of this query_ details
	*/
	@Override
	public void setComment(java.lang.String comment) {
		_query_Details.setComment(comment);
	}

	/**
	* Returns the category of this query_ details.
	*
	* @return the category of this query_ details
	*/
	@Override
	public long getCategory() {
		return _query_Details.getCategory();
	}

	/**
	* Sets the category of this query_ details.
	*
	* @param category the category of this query_ details
	*/
	@Override
	public void setCategory(long category) {
		_query_Details.setCategory(category);
	}

	/**
	* Returns the sub category of this query_ details.
	*
	* @return the sub category of this query_ details
	*/
	@Override
	public long getSubCategory() {
		return _query_Details.getSubCategory();
	}

	/**
	* Sets the sub category of this query_ details.
	*
	* @param subCategory the sub category of this query_ details
	*/
	@Override
	public void setSubCategory(long subCategory) {
		_query_Details.setSubCategory(subCategory);
	}

	/**
	* Returns the case resolution of this query_ details.
	*
	* @return the case resolution of this query_ details
	*/
	@Override
	public long getCaseResolution() {
		return _query_Details.getCaseResolution();
	}

	/**
	* Sets the case resolution of this query_ details.
	*
	* @param caseResolution the case resolution of this query_ details
	*/
	@Override
	public void setCaseResolution(long caseResolution) {
		_query_Details.setCaseResolution(caseResolution);
	}

	/**
	* Returns the is_closed of this query_ details.
	*
	* @return the is_closed of this query_ details
	*/
	@Override
	public int getIs_closed() {
		return _query_Details.getIs_closed();
	}

	/**
	* Sets the is_closed of this query_ details.
	*
	* @param is_closed the is_closed of this query_ details
	*/
	@Override
	public void setIs_closed(int is_closed) {
		_query_Details.setIs_closed(is_closed);
	}

	/**
	* Returns the closed_date of this query_ details.
	*
	* @return the closed_date of this query_ details
	*/
	@Override
	public java.util.Date getClosed_date() {
		return _query_Details.getClosed_date();
	}

	/**
	* Sets the closed_date of this query_ details.
	*
	* @param closed_date the closed_date of this query_ details
	*/
	@Override
	public void setClosed_date(java.util.Date closed_date) {
		_query_Details.setClosed_date(closed_date);
	}

	@Override
	public boolean isNew() {
		return _query_Details.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_query_Details.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _query_Details.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_query_Details.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _query_Details.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _query_Details.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_query_Details.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _query_Details.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_query_Details.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_query_Details.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_query_Details.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new Query_DetailsWrapper((Query_Details)_query_Details.clone());
	}

	@Override
	public int compareTo(com.jioc.query.model.Query_Details query_Details) {
		return _query_Details.compareTo(query_Details);
	}

	@Override
	public int hashCode() {
		return _query_Details.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jioc.query.model.Query_Details> toCacheModel() {
		return _query_Details.toCacheModel();
	}

	@Override
	public com.jioc.query.model.Query_Details toEscapedModel() {
		return new Query_DetailsWrapper(_query_Details.toEscapedModel());
	}

	@Override
	public com.jioc.query.model.Query_Details toUnescapedModel() {
		return new Query_DetailsWrapper(_query_Details.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _query_Details.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _query_Details.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_query_Details.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof Query_DetailsWrapper)) {
			return false;
		}

		Query_DetailsWrapper query_DetailsWrapper = (Query_DetailsWrapper)obj;

		if (Validator.equals(_query_Details, query_DetailsWrapper._query_Details)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public Query_Details getWrappedQuery_Details() {
		return _query_Details;
	}

	@Override
	public Query_Details getWrappedModel() {
		return _query_Details;
	}

	@Override
	public void resetOriginalValues() {
		_query_Details.resetOriginalValues();
	}

	private Query_Details _query_Details;
}