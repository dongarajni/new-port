/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.jioc.query.service.ClpSerializer;
import com.jioc.query.service.EMP_DETAILSLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author shantaram.chavan
 */
public class EMP_DETAILSClp extends BaseModelImpl<EMP_DETAILS>
	implements EMP_DETAILS {
	public EMP_DETAILSClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return EMP_DETAILS.class;
	}

	@Override
	public String getModelClassName() {
		return EMP_DETAILS.class.getName();
	}

	@Override
	public String getPrimaryKey() {
		return _EMP_ID;
	}

	@Override
	public void setPrimaryKey(String primaryKey) {
		setEMP_ID(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _EMP_ID;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey((String)primaryKeyObj);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("EMP_ID", getEMP_ID());
		attributes.put("AREA", getAREA());
		attributes.put("CADRE", getCADRE());
		attributes.put("CLIENT_ID", getCLIENT_ID());
		attributes.put("COMPANY_CODE", getCOMPANY_CODE());
		attributes.put("COMPANY_TEXT", getCOMPANY_TEXT());
		attributes.put("DATE_OF_BIRTH", getDATE_OF_BIRTH());
		attributes.put("DATE_OF_JOINING", getDATE_OF_JOINING());
		attributes.put("DATE_OF_LEAVE", getDATE_OF_LEAVE());
		attributes.put("DEPARTMENT", getDEPARTMENT());
		attributes.put("DESIGNATION_CODE", getDESIGNATION_CODE());
		attributes.put("DESIGNATION_TEXT", getDESIGNATION_TEXT());
		attributes.put("EMAIL", getEMAIL());
		attributes.put("EMP_GROUP", getEMP_GROUP());
		attributes.put("EMPLOYEE_DOMAIN_ID", getEMPLOYEE_DOMAIN_ID());
		attributes.put("EMPLOYMENT_STATUS", getEMPLOYMENT_STATUS());
		attributes.put("EMPLOYMENT_STATUS_TEXT", getEMPLOYMENT_STATUS_TEXT());
		attributes.put("FIRST_NAME", getFIRST_NAME());
		attributes.put("FULL_NAME", getFULL_NAME());
		attributes.put("GENDER_TEXT", getGENDER_TEXT());
		attributes.put("HR_EMAIL", getHR_EMAIL());
		attributes.put("HR_EMP_CD", getHR_EMP_CD());
		attributes.put("HR_HEAD_EMPCD", getHR_HEAD_EMPCD());
		attributes.put("HR_HEAD_NAME", getHR_HEAD_NAME());
		attributes.put("HR_NAME", getHR_NAME());
		attributes.put("JIO_CENTER", getJIO_CENTER());
		attributes.put("JIO_ID", getJIO_ID());
		attributes.put("JO_REGION", getJO_REGION());
		attributes.put("JO_TYPE", getJO_TYPE());
		attributes.put("JOB", getJOB());
		attributes.put("JOB_ROLE_CODE", getJOB_ROLE_CODE());
		attributes.put("L1_EMAIL_ID", getL1_EMAIL_ID());
		attributes.put("L1_EMPLOYEE_CODE", getL1_EMPLOYEE_CODE());
		attributes.put("L1_NAME", getL1_NAME());
		attributes.put("LAST_NAME", getLAST_NAME());
		attributes.put("LOCATION_CITY", getLOCATION_CITY());
		attributes.put("LOCATION_CODE", getLOCATION_CODE());
		attributes.put("LOCATION_COUNTRY", getLOCATION_COUNTRY());
		attributes.put("LOCATION_STATE", getLOCATION_STATE());
		attributes.put("LOCATION_TEXT", getLOCATION_TEXT());
		attributes.put("MOBILE_NO", getMOBILE_NO());
		attributes.put("OFFICE_NO", getOFFICE_NO());
		attributes.put("ORG_UNIT", getORG_UNIT());
		attributes.put("ORG_UNIT_TEXT", getORG_UNIT_TEXT());
		attributes.put("PERSONNEL_AREA_CODE", getPERSONNEL_AREA_CODE());
		attributes.put("R4G_STATE", getR4G_STATE());
		attributes.put("SAML_FEDERATION_ID", getSAML_FEDERATION_ID());
		attributes.put("STORE_CODE", getSTORE_CODE());
		attributes.put("SUB_FUNCTIONAL_AREA", getSUB_FUNCTIONAL_AREA());
		attributes.put("TITLE", getTITLE());
		attributes.put("IS_RESOLVER", getIS_RESOLVER());
		attributes.put("RESOLVER_LEVEL", getRESOLVER_LEVEL());
		attributes.put("PERSONAL_AREA_TEXT", getPERSONAL_AREA_TEXT());
		attributes.put("FUNCTIONAL_AREA", getFUNCTIONAL_AREA());
		attributes.put("RESOLVER_STATUS", getRESOLVER_STATUS());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String EMP_ID = (String)attributes.get("EMP_ID");

		if (EMP_ID != null) {
			setEMP_ID(EMP_ID);
		}

		String AREA = (String)attributes.get("AREA");

		if (AREA != null) {
			setAREA(AREA);
		}

		String CADRE = (String)attributes.get("CADRE");

		if (CADRE != null) {
			setCADRE(CADRE);
		}

		String CLIENT_ID = (String)attributes.get("CLIENT_ID");

		if (CLIENT_ID != null) {
			setCLIENT_ID(CLIENT_ID);
		}

		String COMPANY_CODE = (String)attributes.get("COMPANY_CODE");

		if (COMPANY_CODE != null) {
			setCOMPANY_CODE(COMPANY_CODE);
		}

		String COMPANY_TEXT = (String)attributes.get("COMPANY_TEXT");

		if (COMPANY_TEXT != null) {
			setCOMPANY_TEXT(COMPANY_TEXT);
		}

		Date DATE_OF_BIRTH = (Date)attributes.get("DATE_OF_BIRTH");

		if (DATE_OF_BIRTH != null) {
			setDATE_OF_BIRTH(DATE_OF_BIRTH);
		}

		Date DATE_OF_JOINING = (Date)attributes.get("DATE_OF_JOINING");

		if (DATE_OF_JOINING != null) {
			setDATE_OF_JOINING(DATE_OF_JOINING);
		}

		Date DATE_OF_LEAVE = (Date)attributes.get("DATE_OF_LEAVE");

		if (DATE_OF_LEAVE != null) {
			setDATE_OF_LEAVE(DATE_OF_LEAVE);
		}

		String DEPARTMENT = (String)attributes.get("DEPARTMENT");

		if (DEPARTMENT != null) {
			setDEPARTMENT(DEPARTMENT);
		}

		String DESIGNATION_CODE = (String)attributes.get("DESIGNATION_CODE");

		if (DESIGNATION_CODE != null) {
			setDESIGNATION_CODE(DESIGNATION_CODE);
		}

		String DESIGNATION_TEXT = (String)attributes.get("DESIGNATION_TEXT");

		if (DESIGNATION_TEXT != null) {
			setDESIGNATION_TEXT(DESIGNATION_TEXT);
		}

		String EMAIL = (String)attributes.get("EMAIL");

		if (EMAIL != null) {
			setEMAIL(EMAIL);
		}

		String EMP_GROUP = (String)attributes.get("EMP_GROUP");

		if (EMP_GROUP != null) {
			setEMP_GROUP(EMP_GROUP);
		}

		String EMPLOYEE_DOMAIN_ID = (String)attributes.get("EMPLOYEE_DOMAIN_ID");

		if (EMPLOYEE_DOMAIN_ID != null) {
			setEMPLOYEE_DOMAIN_ID(EMPLOYEE_DOMAIN_ID);
		}

		String EMPLOYMENT_STATUS = (String)attributes.get("EMPLOYMENT_STATUS");

		if (EMPLOYMENT_STATUS != null) {
			setEMPLOYMENT_STATUS(EMPLOYMENT_STATUS);
		}

		String EMPLOYMENT_STATUS_TEXT = (String)attributes.get(
				"EMPLOYMENT_STATUS_TEXT");

		if (EMPLOYMENT_STATUS_TEXT != null) {
			setEMPLOYMENT_STATUS_TEXT(EMPLOYMENT_STATUS_TEXT);
		}

		String FIRST_NAME = (String)attributes.get("FIRST_NAME");

		if (FIRST_NAME != null) {
			setFIRST_NAME(FIRST_NAME);
		}

		String FULL_NAME = (String)attributes.get("FULL_NAME");

		if (FULL_NAME != null) {
			setFULL_NAME(FULL_NAME);
		}

		String GENDER_TEXT = (String)attributes.get("GENDER_TEXT");

		if (GENDER_TEXT != null) {
			setGENDER_TEXT(GENDER_TEXT);
		}

		String HR_EMAIL = (String)attributes.get("HR_EMAIL");

		if (HR_EMAIL != null) {
			setHR_EMAIL(HR_EMAIL);
		}

		String HR_EMP_CD = (String)attributes.get("HR_EMP_CD");

		if (HR_EMP_CD != null) {
			setHR_EMP_CD(HR_EMP_CD);
		}

		String HR_HEAD_EMPCD = (String)attributes.get("HR_HEAD_EMPCD");

		if (HR_HEAD_EMPCD != null) {
			setHR_HEAD_EMPCD(HR_HEAD_EMPCD);
		}

		String HR_HEAD_NAME = (String)attributes.get("HR_HEAD_NAME");

		if (HR_HEAD_NAME != null) {
			setHR_HEAD_NAME(HR_HEAD_NAME);
		}

		String HR_NAME = (String)attributes.get("HR_NAME");

		if (HR_NAME != null) {
			setHR_NAME(HR_NAME);
		}

		String JIO_CENTER = (String)attributes.get("JIO_CENTER");

		if (JIO_CENTER != null) {
			setJIO_CENTER(JIO_CENTER);
		}

		String JIO_ID = (String)attributes.get("JIO_ID");

		if (JIO_ID != null) {
			setJIO_ID(JIO_ID);
		}

		String JO_REGION = (String)attributes.get("JO_REGION");

		if (JO_REGION != null) {
			setJO_REGION(JO_REGION);
		}

		String JO_TYPE = (String)attributes.get("JO_TYPE");

		if (JO_TYPE != null) {
			setJO_TYPE(JO_TYPE);
		}

		String JOB = (String)attributes.get("JOB");

		if (JOB != null) {
			setJOB(JOB);
		}

		String JOB_ROLE_CODE = (String)attributes.get("JOB_ROLE_CODE");

		if (JOB_ROLE_CODE != null) {
			setJOB_ROLE_CODE(JOB_ROLE_CODE);
		}

		String L1_EMAIL_ID = (String)attributes.get("L1_EMAIL_ID");

		if (L1_EMAIL_ID != null) {
			setL1_EMAIL_ID(L1_EMAIL_ID);
		}

		String L1_EMPLOYEE_CODE = (String)attributes.get("L1_EMPLOYEE_CODE");

		if (L1_EMPLOYEE_CODE != null) {
			setL1_EMPLOYEE_CODE(L1_EMPLOYEE_CODE);
		}

		String L1_NAME = (String)attributes.get("L1_NAME");

		if (L1_NAME != null) {
			setL1_NAME(L1_NAME);
		}

		String LAST_NAME = (String)attributes.get("LAST_NAME");

		if (LAST_NAME != null) {
			setLAST_NAME(LAST_NAME);
		}

		String LOCATION_CITY = (String)attributes.get("LOCATION_CITY");

		if (LOCATION_CITY != null) {
			setLOCATION_CITY(LOCATION_CITY);
		}

		String LOCATION_CODE = (String)attributes.get("LOCATION_CODE");

		if (LOCATION_CODE != null) {
			setLOCATION_CODE(LOCATION_CODE);
		}

		String LOCATION_COUNTRY = (String)attributes.get("LOCATION_COUNTRY");

		if (LOCATION_COUNTRY != null) {
			setLOCATION_COUNTRY(LOCATION_COUNTRY);
		}

		String LOCATION_STATE = (String)attributes.get("LOCATION_STATE");

		if (LOCATION_STATE != null) {
			setLOCATION_STATE(LOCATION_STATE);
		}

		String LOCATION_TEXT = (String)attributes.get("LOCATION_TEXT");

		if (LOCATION_TEXT != null) {
			setLOCATION_TEXT(LOCATION_TEXT);
		}

		String MOBILE_NO = (String)attributes.get("MOBILE_NO");

		if (MOBILE_NO != null) {
			setMOBILE_NO(MOBILE_NO);
		}

		String OFFICE_NO = (String)attributes.get("OFFICE_NO");

		if (OFFICE_NO != null) {
			setOFFICE_NO(OFFICE_NO);
		}

		String ORG_UNIT = (String)attributes.get("ORG_UNIT");

		if (ORG_UNIT != null) {
			setORG_UNIT(ORG_UNIT);
		}

		String ORG_UNIT_TEXT = (String)attributes.get("ORG_UNIT_TEXT");

		if (ORG_UNIT_TEXT != null) {
			setORG_UNIT_TEXT(ORG_UNIT_TEXT);
		}

		String PERSONNEL_AREA_CODE = (String)attributes.get(
				"PERSONNEL_AREA_CODE");

		if (PERSONNEL_AREA_CODE != null) {
			setPERSONNEL_AREA_CODE(PERSONNEL_AREA_CODE);
		}

		String R4G_STATE = (String)attributes.get("R4G_STATE");

		if (R4G_STATE != null) {
			setR4G_STATE(R4G_STATE);
		}

		String SAML_FEDERATION_ID = (String)attributes.get("SAML_FEDERATION_ID");

		if (SAML_FEDERATION_ID != null) {
			setSAML_FEDERATION_ID(SAML_FEDERATION_ID);
		}

		String STORE_CODE = (String)attributes.get("STORE_CODE");

		if (STORE_CODE != null) {
			setSTORE_CODE(STORE_CODE);
		}

		String SUB_FUNCTIONAL_AREA = (String)attributes.get(
				"SUB_FUNCTIONAL_AREA");

		if (SUB_FUNCTIONAL_AREA != null) {
			setSUB_FUNCTIONAL_AREA(SUB_FUNCTIONAL_AREA);
		}

		String TITLE = (String)attributes.get("TITLE");

		if (TITLE != null) {
			setTITLE(TITLE);
		}

		Integer IS_RESOLVER = (Integer)attributes.get("IS_RESOLVER");

		if (IS_RESOLVER != null) {
			setIS_RESOLVER(IS_RESOLVER);
		}

		Integer RESOLVER_LEVEL = (Integer)attributes.get("RESOLVER_LEVEL");

		if (RESOLVER_LEVEL != null) {
			setRESOLVER_LEVEL(RESOLVER_LEVEL);
		}

		String PERSONAL_AREA_TEXT = (String)attributes.get("PERSONAL_AREA_TEXT");

		if (PERSONAL_AREA_TEXT != null) {
			setPERSONAL_AREA_TEXT(PERSONAL_AREA_TEXT);
		}

		String FUNCTIONAL_AREA = (String)attributes.get("FUNCTIONAL_AREA");

		if (FUNCTIONAL_AREA != null) {
			setFUNCTIONAL_AREA(FUNCTIONAL_AREA);
		}

		Integer RESOLVER_STATUS = (Integer)attributes.get("RESOLVER_STATUS");

		if (RESOLVER_STATUS != null) {
			setRESOLVER_STATUS(RESOLVER_STATUS);
		}
	}

	@Override
	public String getEMP_ID() {
		return _EMP_ID;
	}

	@Override
	public void setEMP_ID(String EMP_ID) {
		_EMP_ID = EMP_ID;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setEMP_ID", String.class);

				method.invoke(_emp_detailsRemoteModel, EMP_ID);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAREA() {
		return _AREA;
	}

	@Override
	public void setAREA(String AREA) {
		_AREA = AREA;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setAREA", String.class);

				method.invoke(_emp_detailsRemoteModel, AREA);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCADRE() {
		return _CADRE;
	}

	@Override
	public void setCADRE(String CADRE) {
		_CADRE = CADRE;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setCADRE", String.class);

				method.invoke(_emp_detailsRemoteModel, CADRE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCLIENT_ID() {
		return _CLIENT_ID;
	}

	@Override
	public void setCLIENT_ID(String CLIENT_ID) {
		_CLIENT_ID = CLIENT_ID;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setCLIENT_ID", String.class);

				method.invoke(_emp_detailsRemoteModel, CLIENT_ID);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCOMPANY_CODE() {
		return _COMPANY_CODE;
	}

	@Override
	public void setCOMPANY_CODE(String COMPANY_CODE) {
		_COMPANY_CODE = COMPANY_CODE;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setCOMPANY_CODE", String.class);

				method.invoke(_emp_detailsRemoteModel, COMPANY_CODE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCOMPANY_TEXT() {
		return _COMPANY_TEXT;
	}

	@Override
	public void setCOMPANY_TEXT(String COMPANY_TEXT) {
		_COMPANY_TEXT = COMPANY_TEXT;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setCOMPANY_TEXT", String.class);

				method.invoke(_emp_detailsRemoteModel, COMPANY_TEXT);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getDATE_OF_BIRTH() {
		return _DATE_OF_BIRTH;
	}

	@Override
	public void setDATE_OF_BIRTH(Date DATE_OF_BIRTH) {
		_DATE_OF_BIRTH = DATE_OF_BIRTH;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setDATE_OF_BIRTH", Date.class);

				method.invoke(_emp_detailsRemoteModel, DATE_OF_BIRTH);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getDATE_OF_JOINING() {
		return _DATE_OF_JOINING;
	}

	@Override
	public void setDATE_OF_JOINING(Date DATE_OF_JOINING) {
		_DATE_OF_JOINING = DATE_OF_JOINING;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setDATE_OF_JOINING", Date.class);

				method.invoke(_emp_detailsRemoteModel, DATE_OF_JOINING);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getDATE_OF_LEAVE() {
		return _DATE_OF_LEAVE;
	}

	@Override
	public void setDATE_OF_LEAVE(Date DATE_OF_LEAVE) {
		_DATE_OF_LEAVE = DATE_OF_LEAVE;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setDATE_OF_LEAVE", Date.class);

				method.invoke(_emp_detailsRemoteModel, DATE_OF_LEAVE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDEPARTMENT() {
		return _DEPARTMENT;
	}

	@Override
	public void setDEPARTMENT(String DEPARTMENT) {
		_DEPARTMENT = DEPARTMENT;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setDEPARTMENT", String.class);

				method.invoke(_emp_detailsRemoteModel, DEPARTMENT);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDESIGNATION_CODE() {
		return _DESIGNATION_CODE;
	}

	@Override
	public void setDESIGNATION_CODE(String DESIGNATION_CODE) {
		_DESIGNATION_CODE = DESIGNATION_CODE;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setDESIGNATION_CODE",
						String.class);

				method.invoke(_emp_detailsRemoteModel, DESIGNATION_CODE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDESIGNATION_TEXT() {
		return _DESIGNATION_TEXT;
	}

	@Override
	public void setDESIGNATION_TEXT(String DESIGNATION_TEXT) {
		_DESIGNATION_TEXT = DESIGNATION_TEXT;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setDESIGNATION_TEXT",
						String.class);

				method.invoke(_emp_detailsRemoteModel, DESIGNATION_TEXT);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEMAIL() {
		return _EMAIL;
	}

	@Override
	public void setEMAIL(String EMAIL) {
		_EMAIL = EMAIL;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setEMAIL", String.class);

				method.invoke(_emp_detailsRemoteModel, EMAIL);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEMP_GROUP() {
		return _EMP_GROUP;
	}

	@Override
	public void setEMP_GROUP(String EMP_GROUP) {
		_EMP_GROUP = EMP_GROUP;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setEMP_GROUP", String.class);

				method.invoke(_emp_detailsRemoteModel, EMP_GROUP);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEMPLOYEE_DOMAIN_ID() {
		return _EMPLOYEE_DOMAIN_ID;
	}

	@Override
	public void setEMPLOYEE_DOMAIN_ID(String EMPLOYEE_DOMAIN_ID) {
		_EMPLOYEE_DOMAIN_ID = EMPLOYEE_DOMAIN_ID;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setEMPLOYEE_DOMAIN_ID",
						String.class);

				method.invoke(_emp_detailsRemoteModel, EMPLOYEE_DOMAIN_ID);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEMPLOYMENT_STATUS() {
		return _EMPLOYMENT_STATUS;
	}

	@Override
	public void setEMPLOYMENT_STATUS(String EMPLOYMENT_STATUS) {
		_EMPLOYMENT_STATUS = EMPLOYMENT_STATUS;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setEMPLOYMENT_STATUS",
						String.class);

				method.invoke(_emp_detailsRemoteModel, EMPLOYMENT_STATUS);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEMPLOYMENT_STATUS_TEXT() {
		return _EMPLOYMENT_STATUS_TEXT;
	}

	@Override
	public void setEMPLOYMENT_STATUS_TEXT(String EMPLOYMENT_STATUS_TEXT) {
		_EMPLOYMENT_STATUS_TEXT = EMPLOYMENT_STATUS_TEXT;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setEMPLOYMENT_STATUS_TEXT",
						String.class);

				method.invoke(_emp_detailsRemoteModel, EMPLOYMENT_STATUS_TEXT);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getFIRST_NAME() {
		return _FIRST_NAME;
	}

	@Override
	public void setFIRST_NAME(String FIRST_NAME) {
		_FIRST_NAME = FIRST_NAME;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setFIRST_NAME", String.class);

				method.invoke(_emp_detailsRemoteModel, FIRST_NAME);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getFULL_NAME() {
		return _FULL_NAME;
	}

	@Override
	public void setFULL_NAME(String FULL_NAME) {
		_FULL_NAME = FULL_NAME;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setFULL_NAME", String.class);

				method.invoke(_emp_detailsRemoteModel, FULL_NAME);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getGENDER_TEXT() {
		return _GENDER_TEXT;
	}

	@Override
	public void setGENDER_TEXT(String GENDER_TEXT) {
		_GENDER_TEXT = GENDER_TEXT;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setGENDER_TEXT", String.class);

				method.invoke(_emp_detailsRemoteModel, GENDER_TEXT);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getHR_EMAIL() {
		return _HR_EMAIL;
	}

	@Override
	public void setHR_EMAIL(String HR_EMAIL) {
		_HR_EMAIL = HR_EMAIL;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setHR_EMAIL", String.class);

				method.invoke(_emp_detailsRemoteModel, HR_EMAIL);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getHR_EMP_CD() {
		return _HR_EMP_CD;
	}

	@Override
	public void setHR_EMP_CD(String HR_EMP_CD) {
		_HR_EMP_CD = HR_EMP_CD;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setHR_EMP_CD", String.class);

				method.invoke(_emp_detailsRemoteModel, HR_EMP_CD);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getHR_HEAD_EMPCD() {
		return _HR_HEAD_EMPCD;
	}

	@Override
	public void setHR_HEAD_EMPCD(String HR_HEAD_EMPCD) {
		_HR_HEAD_EMPCD = HR_HEAD_EMPCD;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setHR_HEAD_EMPCD", String.class);

				method.invoke(_emp_detailsRemoteModel, HR_HEAD_EMPCD);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getHR_HEAD_NAME() {
		return _HR_HEAD_NAME;
	}

	@Override
	public void setHR_HEAD_NAME(String HR_HEAD_NAME) {
		_HR_HEAD_NAME = HR_HEAD_NAME;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setHR_HEAD_NAME", String.class);

				method.invoke(_emp_detailsRemoteModel, HR_HEAD_NAME);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getHR_NAME() {
		return _HR_NAME;
	}

	@Override
	public void setHR_NAME(String HR_NAME) {
		_HR_NAME = HR_NAME;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setHR_NAME", String.class);

				method.invoke(_emp_detailsRemoteModel, HR_NAME);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getJIO_CENTER() {
		return _JIO_CENTER;
	}

	@Override
	public void setJIO_CENTER(String JIO_CENTER) {
		_JIO_CENTER = JIO_CENTER;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setJIO_CENTER", String.class);

				method.invoke(_emp_detailsRemoteModel, JIO_CENTER);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getJIO_ID() {
		return _JIO_ID;
	}

	@Override
	public void setJIO_ID(String JIO_ID) {
		_JIO_ID = JIO_ID;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setJIO_ID", String.class);

				method.invoke(_emp_detailsRemoteModel, JIO_ID);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getJO_REGION() {
		return _JO_REGION;
	}

	@Override
	public void setJO_REGION(String JO_REGION) {
		_JO_REGION = JO_REGION;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setJO_REGION", String.class);

				method.invoke(_emp_detailsRemoteModel, JO_REGION);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getJO_TYPE() {
		return _JO_TYPE;
	}

	@Override
	public void setJO_TYPE(String JO_TYPE) {
		_JO_TYPE = JO_TYPE;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setJO_TYPE", String.class);

				method.invoke(_emp_detailsRemoteModel, JO_TYPE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getJOB() {
		return _JOB;
	}

	@Override
	public void setJOB(String JOB) {
		_JOB = JOB;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setJOB", String.class);

				method.invoke(_emp_detailsRemoteModel, JOB);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getJOB_ROLE_CODE() {
		return _JOB_ROLE_CODE;
	}

	@Override
	public void setJOB_ROLE_CODE(String JOB_ROLE_CODE) {
		_JOB_ROLE_CODE = JOB_ROLE_CODE;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setJOB_ROLE_CODE", String.class);

				method.invoke(_emp_detailsRemoteModel, JOB_ROLE_CODE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getL1_EMAIL_ID() {
		return _L1_EMAIL_ID;
	}

	@Override
	public void setL1_EMAIL_ID(String L1_EMAIL_ID) {
		_L1_EMAIL_ID = L1_EMAIL_ID;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setL1_EMAIL_ID", String.class);

				method.invoke(_emp_detailsRemoteModel, L1_EMAIL_ID);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getL1_EMPLOYEE_CODE() {
		return _L1_EMPLOYEE_CODE;
	}

	@Override
	public void setL1_EMPLOYEE_CODE(String L1_EMPLOYEE_CODE) {
		_L1_EMPLOYEE_CODE = L1_EMPLOYEE_CODE;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setL1_EMPLOYEE_CODE",
						String.class);

				method.invoke(_emp_detailsRemoteModel, L1_EMPLOYEE_CODE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getL1_NAME() {
		return _L1_NAME;
	}

	@Override
	public void setL1_NAME(String L1_NAME) {
		_L1_NAME = L1_NAME;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setL1_NAME", String.class);

				method.invoke(_emp_detailsRemoteModel, L1_NAME);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getLAST_NAME() {
		return _LAST_NAME;
	}

	@Override
	public void setLAST_NAME(String LAST_NAME) {
		_LAST_NAME = LAST_NAME;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setLAST_NAME", String.class);

				method.invoke(_emp_detailsRemoteModel, LAST_NAME);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getLOCATION_CITY() {
		return _LOCATION_CITY;
	}

	@Override
	public void setLOCATION_CITY(String LOCATION_CITY) {
		_LOCATION_CITY = LOCATION_CITY;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setLOCATION_CITY", String.class);

				method.invoke(_emp_detailsRemoteModel, LOCATION_CITY);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getLOCATION_CODE() {
		return _LOCATION_CODE;
	}

	@Override
	public void setLOCATION_CODE(String LOCATION_CODE) {
		_LOCATION_CODE = LOCATION_CODE;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setLOCATION_CODE", String.class);

				method.invoke(_emp_detailsRemoteModel, LOCATION_CODE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getLOCATION_COUNTRY() {
		return _LOCATION_COUNTRY;
	}

	@Override
	public void setLOCATION_COUNTRY(String LOCATION_COUNTRY) {
		_LOCATION_COUNTRY = LOCATION_COUNTRY;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setLOCATION_COUNTRY",
						String.class);

				method.invoke(_emp_detailsRemoteModel, LOCATION_COUNTRY);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getLOCATION_STATE() {
		return _LOCATION_STATE;
	}

	@Override
	public void setLOCATION_STATE(String LOCATION_STATE) {
		_LOCATION_STATE = LOCATION_STATE;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setLOCATION_STATE",
						String.class);

				method.invoke(_emp_detailsRemoteModel, LOCATION_STATE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getLOCATION_TEXT() {
		return _LOCATION_TEXT;
	}

	@Override
	public void setLOCATION_TEXT(String LOCATION_TEXT) {
		_LOCATION_TEXT = LOCATION_TEXT;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setLOCATION_TEXT", String.class);

				method.invoke(_emp_detailsRemoteModel, LOCATION_TEXT);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getMOBILE_NO() {
		return _MOBILE_NO;
	}

	@Override
	public void setMOBILE_NO(String MOBILE_NO) {
		_MOBILE_NO = MOBILE_NO;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setMOBILE_NO", String.class);

				method.invoke(_emp_detailsRemoteModel, MOBILE_NO);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOFFICE_NO() {
		return _OFFICE_NO;
	}

	@Override
	public void setOFFICE_NO(String OFFICE_NO) {
		_OFFICE_NO = OFFICE_NO;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setOFFICE_NO", String.class);

				method.invoke(_emp_detailsRemoteModel, OFFICE_NO);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getORG_UNIT() {
		return _ORG_UNIT;
	}

	@Override
	public void setORG_UNIT(String ORG_UNIT) {
		_ORG_UNIT = ORG_UNIT;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setORG_UNIT", String.class);

				method.invoke(_emp_detailsRemoteModel, ORG_UNIT);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getORG_UNIT_TEXT() {
		return _ORG_UNIT_TEXT;
	}

	@Override
	public void setORG_UNIT_TEXT(String ORG_UNIT_TEXT) {
		_ORG_UNIT_TEXT = ORG_UNIT_TEXT;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setORG_UNIT_TEXT", String.class);

				method.invoke(_emp_detailsRemoteModel, ORG_UNIT_TEXT);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getPERSONNEL_AREA_CODE() {
		return _PERSONNEL_AREA_CODE;
	}

	@Override
	public void setPERSONNEL_AREA_CODE(String PERSONNEL_AREA_CODE) {
		_PERSONNEL_AREA_CODE = PERSONNEL_AREA_CODE;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setPERSONNEL_AREA_CODE",
						String.class);

				method.invoke(_emp_detailsRemoteModel, PERSONNEL_AREA_CODE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getR4G_STATE() {
		return _R4G_STATE;
	}

	@Override
	public void setR4G_STATE(String R4G_STATE) {
		_R4G_STATE = R4G_STATE;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setR4G_STATE", String.class);

				method.invoke(_emp_detailsRemoteModel, R4G_STATE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSAML_FEDERATION_ID() {
		return _SAML_FEDERATION_ID;
	}

	@Override
	public void setSAML_FEDERATION_ID(String SAML_FEDERATION_ID) {
		_SAML_FEDERATION_ID = SAML_FEDERATION_ID;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setSAML_FEDERATION_ID",
						String.class);

				method.invoke(_emp_detailsRemoteModel, SAML_FEDERATION_ID);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSTORE_CODE() {
		return _STORE_CODE;
	}

	@Override
	public void setSTORE_CODE(String STORE_CODE) {
		_STORE_CODE = STORE_CODE;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setSTORE_CODE", String.class);

				method.invoke(_emp_detailsRemoteModel, STORE_CODE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSUB_FUNCTIONAL_AREA() {
		return _SUB_FUNCTIONAL_AREA;
	}

	@Override
	public void setSUB_FUNCTIONAL_AREA(String SUB_FUNCTIONAL_AREA) {
		_SUB_FUNCTIONAL_AREA = SUB_FUNCTIONAL_AREA;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setSUB_FUNCTIONAL_AREA",
						String.class);

				method.invoke(_emp_detailsRemoteModel, SUB_FUNCTIONAL_AREA);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTITLE() {
		return _TITLE;
	}

	@Override
	public void setTITLE(String TITLE) {
		_TITLE = TITLE;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setTITLE", String.class);

				method.invoke(_emp_detailsRemoteModel, TITLE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getIS_RESOLVER() {
		return _IS_RESOLVER;
	}

	@Override
	public void setIS_RESOLVER(int IS_RESOLVER) {
		_IS_RESOLVER = IS_RESOLVER;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setIS_RESOLVER", int.class);

				method.invoke(_emp_detailsRemoteModel, IS_RESOLVER);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getRESOLVER_LEVEL() {
		return _RESOLVER_LEVEL;
	}

	@Override
	public void setRESOLVER_LEVEL(int RESOLVER_LEVEL) {
		_RESOLVER_LEVEL = RESOLVER_LEVEL;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setRESOLVER_LEVEL", int.class);

				method.invoke(_emp_detailsRemoteModel, RESOLVER_LEVEL);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getPERSONAL_AREA_TEXT() {
		return _PERSONAL_AREA_TEXT;
	}

	@Override
	public void setPERSONAL_AREA_TEXT(String PERSONAL_AREA_TEXT) {
		_PERSONAL_AREA_TEXT = PERSONAL_AREA_TEXT;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setPERSONAL_AREA_TEXT",
						String.class);

				method.invoke(_emp_detailsRemoteModel, PERSONAL_AREA_TEXT);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getFUNCTIONAL_AREA() {
		return _FUNCTIONAL_AREA;
	}

	@Override
	public void setFUNCTIONAL_AREA(String FUNCTIONAL_AREA) {
		_FUNCTIONAL_AREA = FUNCTIONAL_AREA;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setFUNCTIONAL_AREA",
						String.class);

				method.invoke(_emp_detailsRemoteModel, FUNCTIONAL_AREA);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getRESOLVER_STATUS() {
		return _RESOLVER_STATUS;
	}

	@Override
	public void setRESOLVER_STATUS(int RESOLVER_STATUS) {
		_RESOLVER_STATUS = RESOLVER_STATUS;

		if (_emp_detailsRemoteModel != null) {
			try {
				Class<?> clazz = _emp_detailsRemoteModel.getClass();

				Method method = clazz.getMethod("setRESOLVER_STATUS", int.class);

				method.invoke(_emp_detailsRemoteModel, RESOLVER_STATUS);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public void setUserName(java.lang.String userName) {
		try {
			String methodName = "setUserName";

			Class<?>[] parameterTypes = new Class<?>[] { java.lang.String.class };

			Object[] parameterValues = new Object[] { userName };

			invokeOnRemoteModel(methodName, parameterTypes, parameterValues);
		}
		catch (Exception e) {
			throw new UnsupportedOperationException(e);
		}
	}

	@Override
	public long getUserId() {
		try {
			String methodName = "getUserId";

			Class<?>[] parameterTypes = new Class<?>[] {  };

			Object[] parameterValues = new Object[] {  };

			Long returnObj = (Long)invokeOnRemoteModel(methodName,
					parameterTypes, parameterValues);

			return returnObj;
		}
		catch (Exception e) {
			throw new UnsupportedOperationException(e);
		}
	}

	@Override
	public void setUserId(long userId) {
		try {
			String methodName = "setUserId";

			Class<?>[] parameterTypes = new Class<?>[] { long.class };

			Object[] parameterValues = new Object[] { userId };

			invokeOnRemoteModel(methodName, parameterTypes, parameterValues);
		}
		catch (Exception e) {
			throw new UnsupportedOperationException(e);
		}
	}

	@Override
	public java.lang.String getUserName() {
		try {
			String methodName = "getUserName";

			Class<?>[] parameterTypes = new Class<?>[] {  };

			Object[] parameterValues = new Object[] {  };

			java.lang.String returnObj = (java.lang.String)invokeOnRemoteModel(methodName,
					parameterTypes, parameterValues);

			return returnObj;
		}
		catch (Exception e) {
			throw new UnsupportedOperationException(e);
		}
	}

	public BaseModel<?> getEMP_DETAILSRemoteModel() {
		return _emp_detailsRemoteModel;
	}

	public void setEMP_DETAILSRemoteModel(BaseModel<?> emp_detailsRemoteModel) {
		_emp_detailsRemoteModel = emp_detailsRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _emp_detailsRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_emp_detailsRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			EMP_DETAILSLocalServiceUtil.addEMP_DETAILS(this);
		}
		else {
			EMP_DETAILSLocalServiceUtil.updateEMP_DETAILS(this);
		}
	}

	@Override
	public EMP_DETAILS toEscapedModel() {
		return (EMP_DETAILS)ProxyUtil.newProxyInstance(EMP_DETAILS.class.getClassLoader(),
			new Class[] { EMP_DETAILS.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		EMP_DETAILSClp clone = new EMP_DETAILSClp();

		clone.setEMP_ID(getEMP_ID());
		clone.setAREA(getAREA());
		clone.setCADRE(getCADRE());
		clone.setCLIENT_ID(getCLIENT_ID());
		clone.setCOMPANY_CODE(getCOMPANY_CODE());
		clone.setCOMPANY_TEXT(getCOMPANY_TEXT());
		clone.setDATE_OF_BIRTH(getDATE_OF_BIRTH());
		clone.setDATE_OF_JOINING(getDATE_OF_JOINING());
		clone.setDATE_OF_LEAVE(getDATE_OF_LEAVE());
		clone.setDEPARTMENT(getDEPARTMENT());
		clone.setDESIGNATION_CODE(getDESIGNATION_CODE());
		clone.setDESIGNATION_TEXT(getDESIGNATION_TEXT());
		clone.setEMAIL(getEMAIL());
		clone.setEMP_GROUP(getEMP_GROUP());
		clone.setEMPLOYEE_DOMAIN_ID(getEMPLOYEE_DOMAIN_ID());
		clone.setEMPLOYMENT_STATUS(getEMPLOYMENT_STATUS());
		clone.setEMPLOYMENT_STATUS_TEXT(getEMPLOYMENT_STATUS_TEXT());
		clone.setFIRST_NAME(getFIRST_NAME());
		clone.setFULL_NAME(getFULL_NAME());
		clone.setGENDER_TEXT(getGENDER_TEXT());
		clone.setHR_EMAIL(getHR_EMAIL());
		clone.setHR_EMP_CD(getHR_EMP_CD());
		clone.setHR_HEAD_EMPCD(getHR_HEAD_EMPCD());
		clone.setHR_HEAD_NAME(getHR_HEAD_NAME());
		clone.setHR_NAME(getHR_NAME());
		clone.setJIO_CENTER(getJIO_CENTER());
		clone.setJIO_ID(getJIO_ID());
		clone.setJO_REGION(getJO_REGION());
		clone.setJO_TYPE(getJO_TYPE());
		clone.setJOB(getJOB());
		clone.setJOB_ROLE_CODE(getJOB_ROLE_CODE());
		clone.setL1_EMAIL_ID(getL1_EMAIL_ID());
		clone.setL1_EMPLOYEE_CODE(getL1_EMPLOYEE_CODE());
		clone.setL1_NAME(getL1_NAME());
		clone.setLAST_NAME(getLAST_NAME());
		clone.setLOCATION_CITY(getLOCATION_CITY());
		clone.setLOCATION_CODE(getLOCATION_CODE());
		clone.setLOCATION_COUNTRY(getLOCATION_COUNTRY());
		clone.setLOCATION_STATE(getLOCATION_STATE());
		clone.setLOCATION_TEXT(getLOCATION_TEXT());
		clone.setMOBILE_NO(getMOBILE_NO());
		clone.setOFFICE_NO(getOFFICE_NO());
		clone.setORG_UNIT(getORG_UNIT());
		clone.setORG_UNIT_TEXT(getORG_UNIT_TEXT());
		clone.setPERSONNEL_AREA_CODE(getPERSONNEL_AREA_CODE());
		clone.setR4G_STATE(getR4G_STATE());
		clone.setSAML_FEDERATION_ID(getSAML_FEDERATION_ID());
		clone.setSTORE_CODE(getSTORE_CODE());
		clone.setSUB_FUNCTIONAL_AREA(getSUB_FUNCTIONAL_AREA());
		clone.setTITLE(getTITLE());
		clone.setIS_RESOLVER(getIS_RESOLVER());
		clone.setRESOLVER_LEVEL(getRESOLVER_LEVEL());
		clone.setPERSONAL_AREA_TEXT(getPERSONAL_AREA_TEXT());
		clone.setFUNCTIONAL_AREA(getFUNCTIONAL_AREA());
		clone.setRESOLVER_STATUS(getRESOLVER_STATUS());

		return clone;
	}

	@Override
	public int compareTo(EMP_DETAILS emp_details) {
		String primaryKey = emp_details.getPrimaryKey();

		return getPrimaryKey().compareTo(primaryKey);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof EMP_DETAILSClp)) {
			return false;
		}

		EMP_DETAILSClp emp_details = (EMP_DETAILSClp)obj;

		String primaryKey = emp_details.getPrimaryKey();

		if (getPrimaryKey().equals(primaryKey)) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return getPrimaryKey().hashCode();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(111);

		sb.append("{EMP_ID=");
		sb.append(getEMP_ID());
		sb.append(", AREA=");
		sb.append(getAREA());
		sb.append(", CADRE=");
		sb.append(getCADRE());
		sb.append(", CLIENT_ID=");
		sb.append(getCLIENT_ID());
		sb.append(", COMPANY_CODE=");
		sb.append(getCOMPANY_CODE());
		sb.append(", COMPANY_TEXT=");
		sb.append(getCOMPANY_TEXT());
		sb.append(", DATE_OF_BIRTH=");
		sb.append(getDATE_OF_BIRTH());
		sb.append(", DATE_OF_JOINING=");
		sb.append(getDATE_OF_JOINING());
		sb.append(", DATE_OF_LEAVE=");
		sb.append(getDATE_OF_LEAVE());
		sb.append(", DEPARTMENT=");
		sb.append(getDEPARTMENT());
		sb.append(", DESIGNATION_CODE=");
		sb.append(getDESIGNATION_CODE());
		sb.append(", DESIGNATION_TEXT=");
		sb.append(getDESIGNATION_TEXT());
		sb.append(", EMAIL=");
		sb.append(getEMAIL());
		sb.append(", EMP_GROUP=");
		sb.append(getEMP_GROUP());
		sb.append(", EMPLOYEE_DOMAIN_ID=");
		sb.append(getEMPLOYEE_DOMAIN_ID());
		sb.append(", EMPLOYMENT_STATUS=");
		sb.append(getEMPLOYMENT_STATUS());
		sb.append(", EMPLOYMENT_STATUS_TEXT=");
		sb.append(getEMPLOYMENT_STATUS_TEXT());
		sb.append(", FIRST_NAME=");
		sb.append(getFIRST_NAME());
		sb.append(", FULL_NAME=");
		sb.append(getFULL_NAME());
		sb.append(", GENDER_TEXT=");
		sb.append(getGENDER_TEXT());
		sb.append(", HR_EMAIL=");
		sb.append(getHR_EMAIL());
		sb.append(", HR_EMP_CD=");
		sb.append(getHR_EMP_CD());
		sb.append(", HR_HEAD_EMPCD=");
		sb.append(getHR_HEAD_EMPCD());
		sb.append(", HR_HEAD_NAME=");
		sb.append(getHR_HEAD_NAME());
		sb.append(", HR_NAME=");
		sb.append(getHR_NAME());
		sb.append(", JIO_CENTER=");
		sb.append(getJIO_CENTER());
		sb.append(", JIO_ID=");
		sb.append(getJIO_ID());
		sb.append(", JO_REGION=");
		sb.append(getJO_REGION());
		sb.append(", JO_TYPE=");
		sb.append(getJO_TYPE());
		sb.append(", JOB=");
		sb.append(getJOB());
		sb.append(", JOB_ROLE_CODE=");
		sb.append(getJOB_ROLE_CODE());
		sb.append(", L1_EMAIL_ID=");
		sb.append(getL1_EMAIL_ID());
		sb.append(", L1_EMPLOYEE_CODE=");
		sb.append(getL1_EMPLOYEE_CODE());
		sb.append(", L1_NAME=");
		sb.append(getL1_NAME());
		sb.append(", LAST_NAME=");
		sb.append(getLAST_NAME());
		sb.append(", LOCATION_CITY=");
		sb.append(getLOCATION_CITY());
		sb.append(", LOCATION_CODE=");
		sb.append(getLOCATION_CODE());
		sb.append(", LOCATION_COUNTRY=");
		sb.append(getLOCATION_COUNTRY());
		sb.append(", LOCATION_STATE=");
		sb.append(getLOCATION_STATE());
		sb.append(", LOCATION_TEXT=");
		sb.append(getLOCATION_TEXT());
		sb.append(", MOBILE_NO=");
		sb.append(getMOBILE_NO());
		sb.append(", OFFICE_NO=");
		sb.append(getOFFICE_NO());
		sb.append(", ORG_UNIT=");
		sb.append(getORG_UNIT());
		sb.append(", ORG_UNIT_TEXT=");
		sb.append(getORG_UNIT_TEXT());
		sb.append(", PERSONNEL_AREA_CODE=");
		sb.append(getPERSONNEL_AREA_CODE());
		sb.append(", R4G_STATE=");
		sb.append(getR4G_STATE());
		sb.append(", SAML_FEDERATION_ID=");
		sb.append(getSAML_FEDERATION_ID());
		sb.append(", STORE_CODE=");
		sb.append(getSTORE_CODE());
		sb.append(", SUB_FUNCTIONAL_AREA=");
		sb.append(getSUB_FUNCTIONAL_AREA());
		sb.append(", TITLE=");
		sb.append(getTITLE());
		sb.append(", IS_RESOLVER=");
		sb.append(getIS_RESOLVER());
		sb.append(", RESOLVER_LEVEL=");
		sb.append(getRESOLVER_LEVEL());
		sb.append(", PERSONAL_AREA_TEXT=");
		sb.append(getPERSONAL_AREA_TEXT());
		sb.append(", FUNCTIONAL_AREA=");
		sb.append(getFUNCTIONAL_AREA());
		sb.append(", RESOLVER_STATUS=");
		sb.append(getRESOLVER_STATUS());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(169);

		sb.append("<model><model-name>");
		sb.append("com.jioc.query.model.EMP_DETAILS");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>EMP_ID</column-name><column-value><![CDATA[");
		sb.append(getEMP_ID());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>AREA</column-name><column-value><![CDATA[");
		sb.append(getAREA());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>CADRE</column-name><column-value><![CDATA[");
		sb.append(getCADRE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>CLIENT_ID</column-name><column-value><![CDATA[");
		sb.append(getCLIENT_ID());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>COMPANY_CODE</column-name><column-value><![CDATA[");
		sb.append(getCOMPANY_CODE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>COMPANY_TEXT</column-name><column-value><![CDATA[");
		sb.append(getCOMPANY_TEXT());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>DATE_OF_BIRTH</column-name><column-value><![CDATA[");
		sb.append(getDATE_OF_BIRTH());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>DATE_OF_JOINING</column-name><column-value><![CDATA[");
		sb.append(getDATE_OF_JOINING());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>DATE_OF_LEAVE</column-name><column-value><![CDATA[");
		sb.append(getDATE_OF_LEAVE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>DEPARTMENT</column-name><column-value><![CDATA[");
		sb.append(getDEPARTMENT());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>DESIGNATION_CODE</column-name><column-value><![CDATA[");
		sb.append(getDESIGNATION_CODE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>DESIGNATION_TEXT</column-name><column-value><![CDATA[");
		sb.append(getDESIGNATION_TEXT());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>EMAIL</column-name><column-value><![CDATA[");
		sb.append(getEMAIL());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>EMP_GROUP</column-name><column-value><![CDATA[");
		sb.append(getEMP_GROUP());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>EMPLOYEE_DOMAIN_ID</column-name><column-value><![CDATA[");
		sb.append(getEMPLOYEE_DOMAIN_ID());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>EMPLOYMENT_STATUS</column-name><column-value><![CDATA[");
		sb.append(getEMPLOYMENT_STATUS());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>EMPLOYMENT_STATUS_TEXT</column-name><column-value><![CDATA[");
		sb.append(getEMPLOYMENT_STATUS_TEXT());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>FIRST_NAME</column-name><column-value><![CDATA[");
		sb.append(getFIRST_NAME());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>FULL_NAME</column-name><column-value><![CDATA[");
		sb.append(getFULL_NAME());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>GENDER_TEXT</column-name><column-value><![CDATA[");
		sb.append(getGENDER_TEXT());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>HR_EMAIL</column-name><column-value><![CDATA[");
		sb.append(getHR_EMAIL());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>HR_EMP_CD</column-name><column-value><![CDATA[");
		sb.append(getHR_EMP_CD());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>HR_HEAD_EMPCD</column-name><column-value><![CDATA[");
		sb.append(getHR_HEAD_EMPCD());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>HR_HEAD_NAME</column-name><column-value><![CDATA[");
		sb.append(getHR_HEAD_NAME());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>HR_NAME</column-name><column-value><![CDATA[");
		sb.append(getHR_NAME());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>JIO_CENTER</column-name><column-value><![CDATA[");
		sb.append(getJIO_CENTER());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>JIO_ID</column-name><column-value><![CDATA[");
		sb.append(getJIO_ID());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>JO_REGION</column-name><column-value><![CDATA[");
		sb.append(getJO_REGION());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>JO_TYPE</column-name><column-value><![CDATA[");
		sb.append(getJO_TYPE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>JOB</column-name><column-value><![CDATA[");
		sb.append(getJOB());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>JOB_ROLE_CODE</column-name><column-value><![CDATA[");
		sb.append(getJOB_ROLE_CODE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>L1_EMAIL_ID</column-name><column-value><![CDATA[");
		sb.append(getL1_EMAIL_ID());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>L1_EMPLOYEE_CODE</column-name><column-value><![CDATA[");
		sb.append(getL1_EMPLOYEE_CODE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>L1_NAME</column-name><column-value><![CDATA[");
		sb.append(getL1_NAME());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>LAST_NAME</column-name><column-value><![CDATA[");
		sb.append(getLAST_NAME());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>LOCATION_CITY</column-name><column-value><![CDATA[");
		sb.append(getLOCATION_CITY());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>LOCATION_CODE</column-name><column-value><![CDATA[");
		sb.append(getLOCATION_CODE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>LOCATION_COUNTRY</column-name><column-value><![CDATA[");
		sb.append(getLOCATION_COUNTRY());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>LOCATION_STATE</column-name><column-value><![CDATA[");
		sb.append(getLOCATION_STATE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>LOCATION_TEXT</column-name><column-value><![CDATA[");
		sb.append(getLOCATION_TEXT());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>MOBILE_NO</column-name><column-value><![CDATA[");
		sb.append(getMOBILE_NO());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>OFFICE_NO</column-name><column-value><![CDATA[");
		sb.append(getOFFICE_NO());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>ORG_UNIT</column-name><column-value><![CDATA[");
		sb.append(getORG_UNIT());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>ORG_UNIT_TEXT</column-name><column-value><![CDATA[");
		sb.append(getORG_UNIT_TEXT());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>PERSONNEL_AREA_CODE</column-name><column-value><![CDATA[");
		sb.append(getPERSONNEL_AREA_CODE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>R4G_STATE</column-name><column-value><![CDATA[");
		sb.append(getR4G_STATE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>SAML_FEDERATION_ID</column-name><column-value><![CDATA[");
		sb.append(getSAML_FEDERATION_ID());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>STORE_CODE</column-name><column-value><![CDATA[");
		sb.append(getSTORE_CODE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>SUB_FUNCTIONAL_AREA</column-name><column-value><![CDATA[");
		sb.append(getSUB_FUNCTIONAL_AREA());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>TITLE</column-name><column-value><![CDATA[");
		sb.append(getTITLE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>IS_RESOLVER</column-name><column-value><![CDATA[");
		sb.append(getIS_RESOLVER());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>RESOLVER_LEVEL</column-name><column-value><![CDATA[");
		sb.append(getRESOLVER_LEVEL());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>PERSONAL_AREA_TEXT</column-name><column-value><![CDATA[");
		sb.append(getPERSONAL_AREA_TEXT());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>FUNCTIONAL_AREA</column-name><column-value><![CDATA[");
		sb.append(getFUNCTIONAL_AREA());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>RESOLVER_STATUS</column-name><column-value><![CDATA[");
		sb.append(getRESOLVER_STATUS());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private String _EMP_ID;
	private String _AREA;
	private String _CADRE;
	private String _CLIENT_ID;
	private String _COMPANY_CODE;
	private String _COMPANY_TEXT;
	private Date _DATE_OF_BIRTH;
	private Date _DATE_OF_JOINING;
	private Date _DATE_OF_LEAVE;
	private String _DEPARTMENT;
	private String _DESIGNATION_CODE;
	private String _DESIGNATION_TEXT;
	private String _EMAIL;
	private String _EMP_GROUP;
	private String _EMPLOYEE_DOMAIN_ID;
	private String _EMPLOYMENT_STATUS;
	private String _EMPLOYMENT_STATUS_TEXT;
	private String _FIRST_NAME;
	private String _FULL_NAME;
	private String _GENDER_TEXT;
	private String _HR_EMAIL;
	private String _HR_EMP_CD;
	private String _HR_HEAD_EMPCD;
	private String _HR_HEAD_NAME;
	private String _HR_NAME;
	private String _JIO_CENTER;
	private String _JIO_ID;
	private String _JO_REGION;
	private String _JO_TYPE;
	private String _JOB;
	private String _JOB_ROLE_CODE;
	private String _L1_EMAIL_ID;
	private String _L1_EMPLOYEE_CODE;
	private String _L1_NAME;
	private String _LAST_NAME;
	private String _LOCATION_CITY;
	private String _LOCATION_CODE;
	private String _LOCATION_COUNTRY;
	private String _LOCATION_STATE;
	private String _LOCATION_TEXT;
	private String _MOBILE_NO;
	private String _OFFICE_NO;
	private String _ORG_UNIT;
	private String _ORG_UNIT_TEXT;
	private String _PERSONNEL_AREA_CODE;
	private String _R4G_STATE;
	private String _SAML_FEDERATION_ID;
	private String _STORE_CODE;
	private String _SUB_FUNCTIONAL_AREA;
	private String _TITLE;
	private int _IS_RESOLVER;
	private int _RESOLVER_LEVEL;
	private String _PERSONAL_AREA_TEXT;
	private String _FUNCTIONAL_AREA;
	private int _RESOLVER_STATUS;
	private BaseModel<?> _emp_detailsRemoteModel;
	private Class<?> _clpSerializerClass = com.jioc.query.service.ClpSerializer.class;
}