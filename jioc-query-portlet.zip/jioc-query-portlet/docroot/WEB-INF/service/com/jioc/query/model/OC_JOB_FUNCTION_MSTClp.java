/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.jioc.query.service.ClpSerializer;
import com.jioc.query.service.OC_JOB_FUNCTION_MSTLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author shantaram.chavan
 */
public class OC_JOB_FUNCTION_MSTClp extends BaseModelImpl<OC_JOB_FUNCTION_MST>
	implements OC_JOB_FUNCTION_MST {
	public OC_JOB_FUNCTION_MSTClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return OC_JOB_FUNCTION_MST.class;
	}

	@Override
	public String getModelClassName() {
		return OC_JOB_FUNCTION_MST.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _OC_JOB_FUNCTION_ID;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setOC_JOB_FUNCTION_ID(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _OC_JOB_FUNCTION_ID;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("OC_JOB_FUNCTION_ID", getOC_JOB_FUNCTION_ID());
		attributes.put("FUNCTIONAL_AREA", getFUNCTIONAL_AREA());
		attributes.put("JOB", getJOB());
		attributes.put("OC", getOC());
		attributes.put("SUB_FUNCTIONAL_AREA", getSUB_FUNCTIONAL_AREA());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long OC_JOB_FUNCTION_ID = (Long)attributes.get("OC_JOB_FUNCTION_ID");

		if (OC_JOB_FUNCTION_ID != null) {
			setOC_JOB_FUNCTION_ID(OC_JOB_FUNCTION_ID);
		}

		String FUNCTIONAL_AREA = (String)attributes.get("FUNCTIONAL_AREA");

		if (FUNCTIONAL_AREA != null) {
			setFUNCTIONAL_AREA(FUNCTIONAL_AREA);
		}

		String JOB = (String)attributes.get("JOB");

		if (JOB != null) {
			setJOB(JOB);
		}

		String OC = (String)attributes.get("OC");

		if (OC != null) {
			setOC(OC);
		}

		String SUB_FUNCTIONAL_AREA = (String)attributes.get(
				"SUB_FUNCTIONAL_AREA");

		if (SUB_FUNCTIONAL_AREA != null) {
			setSUB_FUNCTIONAL_AREA(SUB_FUNCTIONAL_AREA);
		}
	}

	@Override
	public long getOC_JOB_FUNCTION_ID() {
		return _OC_JOB_FUNCTION_ID;
	}

	@Override
	public void setOC_JOB_FUNCTION_ID(long OC_JOB_FUNCTION_ID) {
		_OC_JOB_FUNCTION_ID = OC_JOB_FUNCTION_ID;

		if (_oc_job_function_mstRemoteModel != null) {
			try {
				Class<?> clazz = _oc_job_function_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setOC_JOB_FUNCTION_ID",
						long.class);

				method.invoke(_oc_job_function_mstRemoteModel,
					OC_JOB_FUNCTION_ID);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getFUNCTIONAL_AREA() {
		return _FUNCTIONAL_AREA;
	}

	@Override
	public void setFUNCTIONAL_AREA(String FUNCTIONAL_AREA) {
		_FUNCTIONAL_AREA = FUNCTIONAL_AREA;

		if (_oc_job_function_mstRemoteModel != null) {
			try {
				Class<?> clazz = _oc_job_function_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setFUNCTIONAL_AREA",
						String.class);

				method.invoke(_oc_job_function_mstRemoteModel, FUNCTIONAL_AREA);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getJOB() {
		return _JOB;
	}

	@Override
	public void setJOB(String JOB) {
		_JOB = JOB;

		if (_oc_job_function_mstRemoteModel != null) {
			try {
				Class<?> clazz = _oc_job_function_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setJOB", String.class);

				method.invoke(_oc_job_function_mstRemoteModel, JOB);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getOC() {
		return _OC;
	}

	@Override
	public void setOC(String OC) {
		_OC = OC;

		if (_oc_job_function_mstRemoteModel != null) {
			try {
				Class<?> clazz = _oc_job_function_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setOC", String.class);

				method.invoke(_oc_job_function_mstRemoteModel, OC);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSUB_FUNCTIONAL_AREA() {
		return _SUB_FUNCTIONAL_AREA;
	}

	@Override
	public void setSUB_FUNCTIONAL_AREA(String SUB_FUNCTIONAL_AREA) {
		_SUB_FUNCTIONAL_AREA = SUB_FUNCTIONAL_AREA;

		if (_oc_job_function_mstRemoteModel != null) {
			try {
				Class<?> clazz = _oc_job_function_mstRemoteModel.getClass();

				Method method = clazz.getMethod("setSUB_FUNCTIONAL_AREA",
						String.class);

				method.invoke(_oc_job_function_mstRemoteModel,
					SUB_FUNCTIONAL_AREA);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getOC_JOB_FUNCTION_MSTRemoteModel() {
		return _oc_job_function_mstRemoteModel;
	}

	public void setOC_JOB_FUNCTION_MSTRemoteModel(
		BaseModel<?> oc_job_function_mstRemoteModel) {
		_oc_job_function_mstRemoteModel = oc_job_function_mstRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _oc_job_function_mstRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_oc_job_function_mstRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			OC_JOB_FUNCTION_MSTLocalServiceUtil.addOC_JOB_FUNCTION_MST(this);
		}
		else {
			OC_JOB_FUNCTION_MSTLocalServiceUtil.updateOC_JOB_FUNCTION_MST(this);
		}
	}

	@Override
	public OC_JOB_FUNCTION_MST toEscapedModel() {
		return (OC_JOB_FUNCTION_MST)ProxyUtil.newProxyInstance(OC_JOB_FUNCTION_MST.class.getClassLoader(),
			new Class[] { OC_JOB_FUNCTION_MST.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		OC_JOB_FUNCTION_MSTClp clone = new OC_JOB_FUNCTION_MSTClp();

		clone.setOC_JOB_FUNCTION_ID(getOC_JOB_FUNCTION_ID());
		clone.setFUNCTIONAL_AREA(getFUNCTIONAL_AREA());
		clone.setJOB(getJOB());
		clone.setOC(getOC());
		clone.setSUB_FUNCTIONAL_AREA(getSUB_FUNCTIONAL_AREA());

		return clone;
	}

	@Override
	public int compareTo(OC_JOB_FUNCTION_MST oc_job_function_mst) {
		long primaryKey = oc_job_function_mst.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof OC_JOB_FUNCTION_MSTClp)) {
			return false;
		}

		OC_JOB_FUNCTION_MSTClp oc_job_function_mst = (OC_JOB_FUNCTION_MSTClp)obj;

		long primaryKey = oc_job_function_mst.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{OC_JOB_FUNCTION_ID=");
		sb.append(getOC_JOB_FUNCTION_ID());
		sb.append(", FUNCTIONAL_AREA=");
		sb.append(getFUNCTIONAL_AREA());
		sb.append(", JOB=");
		sb.append(getJOB());
		sb.append(", OC=");
		sb.append(getOC());
		sb.append(", SUB_FUNCTIONAL_AREA=");
		sb.append(getSUB_FUNCTIONAL_AREA());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(19);

		sb.append("<model><model-name>");
		sb.append("com.jioc.query.model.OC_JOB_FUNCTION_MST");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>OC_JOB_FUNCTION_ID</column-name><column-value><![CDATA[");
		sb.append(getOC_JOB_FUNCTION_ID());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>FUNCTIONAL_AREA</column-name><column-value><![CDATA[");
		sb.append(getFUNCTIONAL_AREA());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>JOB</column-name><column-value><![CDATA[");
		sb.append(getJOB());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>OC</column-name><column-value><![CDATA[");
		sb.append(getOC());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>SUB_FUNCTIONAL_AREA</column-name><column-value><![CDATA[");
		sb.append(getSUB_FUNCTIONAL_AREA());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _OC_JOB_FUNCTION_ID;
	private String _FUNCTIONAL_AREA;
	private String _JOB;
	private String _OC;
	private String _SUB_FUNCTIONAL_AREA;
	private BaseModel<?> _oc_job_function_mstRemoteModel;
	private Class<?> _clpSerializerClass = com.jioc.query.service.ClpSerializer.class;
}