/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author shantaram.chavan
 * @generated
 */
public class OC_SUB_CAT_MSTSoap implements Serializable {
	public static OC_SUB_CAT_MSTSoap toSoapModel(OC_SUB_CAT_MST model) {
		OC_SUB_CAT_MSTSoap soapModel = new OC_SUB_CAT_MSTSoap();

		soapModel.setSUB_CAT_ID(model.getSUB_CAT_ID());
		soapModel.setCAT_ID(model.getCAT_ID());
		soapModel.setIS_ACTIVE(model.getIS_ACTIVE());
		soapModel.setSUB_CAT_NAME(model.getSUB_CAT_NAME());
		soapModel.setUPDATED_TIMESTAMP(model.getUPDATED_TIMESTAMP());

		return soapModel;
	}

	public static OC_SUB_CAT_MSTSoap[] toSoapModels(OC_SUB_CAT_MST[] models) {
		OC_SUB_CAT_MSTSoap[] soapModels = new OC_SUB_CAT_MSTSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static OC_SUB_CAT_MSTSoap[][] toSoapModels(OC_SUB_CAT_MST[][] models) {
		OC_SUB_CAT_MSTSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new OC_SUB_CAT_MSTSoap[models.length][models[0].length];
		}
		else {
			soapModels = new OC_SUB_CAT_MSTSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static OC_SUB_CAT_MSTSoap[] toSoapModels(List<OC_SUB_CAT_MST> models) {
		List<OC_SUB_CAT_MSTSoap> soapModels = new ArrayList<OC_SUB_CAT_MSTSoap>(models.size());

		for (OC_SUB_CAT_MST model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new OC_SUB_CAT_MSTSoap[soapModels.size()]);
	}

	public OC_SUB_CAT_MSTSoap() {
	}

	public long getPrimaryKey() {
		return _SUB_CAT_ID;
	}

	public void setPrimaryKey(long pk) {
		setSUB_CAT_ID(pk);
	}

	public long getSUB_CAT_ID() {
		return _SUB_CAT_ID;
	}

	public void setSUB_CAT_ID(long SUB_CAT_ID) {
		_SUB_CAT_ID = SUB_CAT_ID;
	}

	public long getCAT_ID() {
		return _CAT_ID;
	}

	public void setCAT_ID(long CAT_ID) {
		_CAT_ID = CAT_ID;
	}

	public int getIS_ACTIVE() {
		return _IS_ACTIVE;
	}

	public void setIS_ACTIVE(int IS_ACTIVE) {
		_IS_ACTIVE = IS_ACTIVE;
	}

	public String getSUB_CAT_NAME() {
		return _SUB_CAT_NAME;
	}

	public void setSUB_CAT_NAME(String SUB_CAT_NAME) {
		_SUB_CAT_NAME = SUB_CAT_NAME;
	}

	public Date getUPDATED_TIMESTAMP() {
		return _UPDATED_TIMESTAMP;
	}

	public void setUPDATED_TIMESTAMP(Date UPDATED_TIMESTAMP) {
		_UPDATED_TIMESTAMP = UPDATED_TIMESTAMP;
	}

	private long _SUB_CAT_ID;
	private long _CAT_ID;
	private int _IS_ACTIVE;
	private String _SUB_CAT_NAME;
	private Date _UPDATED_TIMESTAMP;
}