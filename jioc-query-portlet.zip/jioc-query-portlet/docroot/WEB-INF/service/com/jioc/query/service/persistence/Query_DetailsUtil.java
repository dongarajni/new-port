/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.persistence;

import com.jioc.query.model.Query_Details;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import java.util.List;

/**
 * The persistence utility for the query_ details service. This utility wraps {@link Query_DetailsPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author shantaram.chavan
 * @see Query_DetailsPersistence
 * @see Query_DetailsPersistenceImpl
 * @generated
 */
public class Query_DetailsUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(Query_Details query_Details) {
		getPersistence().clearCache(query_Details);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<Query_Details> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<Query_Details> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<Query_Details> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static Query_Details update(Query_Details query_Details)
		throws SystemException {
		return getPersistence().update(query_Details);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static Query_Details update(Query_Details query_Details,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(query_Details, serviceContext);
	}

	/**
	* Returns all the query_ detailses where queryId = &#63;.
	*
	* @param queryId the query ID
	* @return the matching query_ detailses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Details> findByQueryId(
		long queryId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByQueryId(queryId);
	}

	/**
	* Returns a range of all the query_ detailses where queryId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_DetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param queryId the query ID
	* @param start the lower bound of the range of query_ detailses
	* @param end the upper bound of the range of query_ detailses (not inclusive)
	* @return the range of matching query_ detailses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Details> findByQueryId(
		long queryId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByQueryId(queryId, start, end);
	}

	/**
	* Returns an ordered range of all the query_ detailses where queryId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_DetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param queryId the query ID
	* @param start the lower bound of the range of query_ detailses
	* @param end the upper bound of the range of query_ detailses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching query_ detailses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Details> findByQueryId(
		long queryId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByQueryId(queryId, start, end, orderByComparator);
	}

	/**
	* Returns the first query_ details in the ordered set where queryId = &#63;.
	*
	* @param queryId the query ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching query_ details
	* @throws com.jioc.query.NoSuchQuery_DetailsException if a matching query_ details could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Details findByQueryId_First(
		long queryId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQuery_DetailsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByQueryId_First(queryId, orderByComparator);
	}

	/**
	* Returns the first query_ details in the ordered set where queryId = &#63;.
	*
	* @param queryId the query ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching query_ details, or <code>null</code> if a matching query_ details could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Details fetchByQueryId_First(
		long queryId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByQueryId_First(queryId, orderByComparator);
	}

	/**
	* Returns the last query_ details in the ordered set where queryId = &#63;.
	*
	* @param queryId the query ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching query_ details
	* @throws com.jioc.query.NoSuchQuery_DetailsException if a matching query_ details could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Details findByQueryId_Last(
		long queryId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQuery_DetailsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByQueryId_Last(queryId, orderByComparator);
	}

	/**
	* Returns the last query_ details in the ordered set where queryId = &#63;.
	*
	* @param queryId the query ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching query_ details, or <code>null</code> if a matching query_ details could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Details fetchByQueryId_Last(
		long queryId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByQueryId_Last(queryId, orderByComparator);
	}

	/**
	* Returns the query_ detailses before and after the current query_ details in the ordered set where queryId = &#63;.
	*
	* @param queryDetailsId the primary key of the current query_ details
	* @param queryId the query ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next query_ details
	* @throws com.jioc.query.NoSuchQuery_DetailsException if a query_ details with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Details[] findByQueryId_PrevAndNext(
		long queryDetailsId, long queryId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.query.NoSuchQuery_DetailsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByQueryId_PrevAndNext(queryDetailsId, queryId,
			orderByComparator);
	}

	/**
	* Removes all the query_ detailses where queryId = &#63; from the database.
	*
	* @param queryId the query ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByQueryId(long queryId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByQueryId(queryId);
	}

	/**
	* Returns the number of query_ detailses where queryId = &#63;.
	*
	* @param queryId the query ID
	* @return the number of matching query_ detailses
	* @throws SystemException if a system exception occurred
	*/
	public static int countByQueryId(long queryId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByQueryId(queryId);
	}

	/**
	* Caches the query_ details in the entity cache if it is enabled.
	*
	* @param query_Details the query_ details
	*/
	public static void cacheResult(
		com.jioc.query.model.Query_Details query_Details) {
		getPersistence().cacheResult(query_Details);
	}

	/**
	* Caches the query_ detailses in the entity cache if it is enabled.
	*
	* @param query_Detailses the query_ detailses
	*/
	public static void cacheResult(
		java.util.List<com.jioc.query.model.Query_Details> query_Detailses) {
		getPersistence().cacheResult(query_Detailses);
	}

	/**
	* Creates a new query_ details with the primary key. Does not add the query_ details to the database.
	*
	* @param queryDetailsId the primary key for the new query_ details
	* @return the new query_ details
	*/
	public static com.jioc.query.model.Query_Details create(long queryDetailsId) {
		return getPersistence().create(queryDetailsId);
	}

	/**
	* Removes the query_ details with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param queryDetailsId the primary key of the query_ details
	* @return the query_ details that was removed
	* @throws com.jioc.query.NoSuchQuery_DetailsException if a query_ details with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Details remove(long queryDetailsId)
		throws com.jioc.query.NoSuchQuery_DetailsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().remove(queryDetailsId);
	}

	public static com.jioc.query.model.Query_Details updateImpl(
		com.jioc.query.model.Query_Details query_Details)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(query_Details);
	}

	/**
	* Returns the query_ details with the primary key or throws a {@link com.jioc.query.NoSuchQuery_DetailsException} if it could not be found.
	*
	* @param queryDetailsId the primary key of the query_ details
	* @return the query_ details
	* @throws com.jioc.query.NoSuchQuery_DetailsException if a query_ details with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Details findByPrimaryKey(
		long queryDetailsId)
		throws com.jioc.query.NoSuchQuery_DetailsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPrimaryKey(queryDetailsId);
	}

	/**
	* Returns the query_ details with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param queryDetailsId the primary key of the query_ details
	* @return the query_ details, or <code>null</code> if a query_ details with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.query.model.Query_Details fetchByPrimaryKey(
		long queryDetailsId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(queryDetailsId);
	}

	/**
	* Returns all the query_ detailses.
	*
	* @return the query_ detailses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Details> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the query_ detailses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_DetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of query_ detailses
	* @param end the upper bound of the range of query_ detailses (not inclusive)
	* @return the range of query_ detailses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Details> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the query_ detailses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.query.model.impl.Query_DetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of query_ detailses
	* @param end the upper bound of the range of query_ detailses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of query_ detailses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.query.model.Query_Details> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the query_ detailses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of query_ detailses.
	*
	* @return the number of query_ detailses
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static Query_DetailsPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (Query_DetailsPersistence)PortletBeanLocatorUtil.locate(com.jioc.query.service.ClpSerializer.getServletContextName(),
					Query_DetailsPersistence.class.getName());

			ReferenceRegistry.registerReference(Query_DetailsUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(Query_DetailsPersistence persistence) {
	}

	private static Query_DetailsPersistence _persistence;
}