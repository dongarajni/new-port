/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.jioc.query.service.ClpSerializer;
import com.jioc.query.service.RESOLVER_DEFAULTSLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author shantaram.chavan
 */
public class RESOLVER_DEFAULTSClp extends BaseModelImpl<RESOLVER_DEFAULTS>
	implements RESOLVER_DEFAULTS {
	public RESOLVER_DEFAULTSClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return RESOLVER_DEFAULTS.class;
	}

	@Override
	public String getModelClassName() {
		return RESOLVER_DEFAULTS.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _DEFAULT_ID;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setDEFAULT_ID(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _DEFAULT_ID;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("DEFAULT_ID", getDEFAULT_ID());
		attributes.put("RESOLVER_LEVEL_ID", getRESOLVER_LEVEL_ID());
		attributes.put("TYPE", getTYPE());
		attributes.put("VALUE", getVALUE());
		attributes.put("TO_DISPLAY", getTO_DISPLAY());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long DEFAULT_ID = (Long)attributes.get("DEFAULT_ID");

		if (DEFAULT_ID != null) {
			setDEFAULT_ID(DEFAULT_ID);
		}

		Long RESOLVER_LEVEL_ID = (Long)attributes.get("RESOLVER_LEVEL_ID");

		if (RESOLVER_LEVEL_ID != null) {
			setRESOLVER_LEVEL_ID(RESOLVER_LEVEL_ID);
		}

		String TYPE = (String)attributes.get("TYPE");

		if (TYPE != null) {
			setTYPE(TYPE);
		}

		String VALUE = (String)attributes.get("VALUE");

		if (VALUE != null) {
			setVALUE(VALUE);
		}

		Integer TO_DISPLAY = (Integer)attributes.get("TO_DISPLAY");

		if (TO_DISPLAY != null) {
			setTO_DISPLAY(TO_DISPLAY);
		}
	}

	@Override
	public long getDEFAULT_ID() {
		return _DEFAULT_ID;
	}

	@Override
	public void setDEFAULT_ID(long DEFAULT_ID) {
		_DEFAULT_ID = DEFAULT_ID;

		if (_resolver_defaultsRemoteModel != null) {
			try {
				Class<?> clazz = _resolver_defaultsRemoteModel.getClass();

				Method method = clazz.getMethod("setDEFAULT_ID", long.class);

				method.invoke(_resolver_defaultsRemoteModel, DEFAULT_ID);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getRESOLVER_LEVEL_ID() {
		return _RESOLVER_LEVEL_ID;
	}

	@Override
	public void setRESOLVER_LEVEL_ID(long RESOLVER_LEVEL_ID) {
		_RESOLVER_LEVEL_ID = RESOLVER_LEVEL_ID;

		if (_resolver_defaultsRemoteModel != null) {
			try {
				Class<?> clazz = _resolver_defaultsRemoteModel.getClass();

				Method method = clazz.getMethod("setRESOLVER_LEVEL_ID",
						long.class);

				method.invoke(_resolver_defaultsRemoteModel, RESOLVER_LEVEL_ID);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTYPE() {
		return _TYPE;
	}

	@Override
	public void setTYPE(String TYPE) {
		_TYPE = TYPE;

		if (_resolver_defaultsRemoteModel != null) {
			try {
				Class<?> clazz = _resolver_defaultsRemoteModel.getClass();

				Method method = clazz.getMethod("setTYPE", String.class);

				method.invoke(_resolver_defaultsRemoteModel, TYPE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getVALUE() {
		return _VALUE;
	}

	@Override
	public void setVALUE(String VALUE) {
		_VALUE = VALUE;

		if (_resolver_defaultsRemoteModel != null) {
			try {
				Class<?> clazz = _resolver_defaultsRemoteModel.getClass();

				Method method = clazz.getMethod("setVALUE", String.class);

				method.invoke(_resolver_defaultsRemoteModel, VALUE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getTO_DISPLAY() {
		return _TO_DISPLAY;
	}

	@Override
	public void setTO_DISPLAY(int TO_DISPLAY) {
		_TO_DISPLAY = TO_DISPLAY;

		if (_resolver_defaultsRemoteModel != null) {
			try {
				Class<?> clazz = _resolver_defaultsRemoteModel.getClass();

				Method method = clazz.getMethod("setTO_DISPLAY", int.class);

				method.invoke(_resolver_defaultsRemoteModel, TO_DISPLAY);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getRESOLVER_DEFAULTSRemoteModel() {
		return _resolver_defaultsRemoteModel;
	}

	public void setRESOLVER_DEFAULTSRemoteModel(
		BaseModel<?> resolver_defaultsRemoteModel) {
		_resolver_defaultsRemoteModel = resolver_defaultsRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _resolver_defaultsRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_resolver_defaultsRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			RESOLVER_DEFAULTSLocalServiceUtil.addRESOLVER_DEFAULTS(this);
		}
		else {
			RESOLVER_DEFAULTSLocalServiceUtil.updateRESOLVER_DEFAULTS(this);
		}
	}

	@Override
	public RESOLVER_DEFAULTS toEscapedModel() {
		return (RESOLVER_DEFAULTS)ProxyUtil.newProxyInstance(RESOLVER_DEFAULTS.class.getClassLoader(),
			new Class[] { RESOLVER_DEFAULTS.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		RESOLVER_DEFAULTSClp clone = new RESOLVER_DEFAULTSClp();

		clone.setDEFAULT_ID(getDEFAULT_ID());
		clone.setRESOLVER_LEVEL_ID(getRESOLVER_LEVEL_ID());
		clone.setTYPE(getTYPE());
		clone.setVALUE(getVALUE());
		clone.setTO_DISPLAY(getTO_DISPLAY());

		return clone;
	}

	@Override
	public int compareTo(RESOLVER_DEFAULTS resolver_defaults) {
		long primaryKey = resolver_defaults.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof RESOLVER_DEFAULTSClp)) {
			return false;
		}

		RESOLVER_DEFAULTSClp resolver_defaults = (RESOLVER_DEFAULTSClp)obj;

		long primaryKey = resolver_defaults.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(11);

		sb.append("{DEFAULT_ID=");
		sb.append(getDEFAULT_ID());
		sb.append(", RESOLVER_LEVEL_ID=");
		sb.append(getRESOLVER_LEVEL_ID());
		sb.append(", TYPE=");
		sb.append(getTYPE());
		sb.append(", VALUE=");
		sb.append(getVALUE());
		sb.append(", TO_DISPLAY=");
		sb.append(getTO_DISPLAY());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(19);

		sb.append("<model><model-name>");
		sb.append("com.jioc.query.model.RESOLVER_DEFAULTS");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>DEFAULT_ID</column-name><column-value><![CDATA[");
		sb.append(getDEFAULT_ID());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>RESOLVER_LEVEL_ID</column-name><column-value><![CDATA[");
		sb.append(getRESOLVER_LEVEL_ID());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>TYPE</column-name><column-value><![CDATA[");
		sb.append(getTYPE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>VALUE</column-name><column-value><![CDATA[");
		sb.append(getVALUE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>TO_DISPLAY</column-name><column-value><![CDATA[");
		sb.append(getTO_DISPLAY());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _DEFAULT_ID;
	private long _RESOLVER_LEVEL_ID;
	private String _TYPE;
	private String _VALUE;
	private int _TO_DISPLAY;
	private BaseModel<?> _resolver_defaultsRemoteModel;
	private Class<?> _clpSerializerClass = com.jioc.query.service.ClpSerializer.class;
}