/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import com.jioc.query.service.ClpSerializer;
import com.jioc.query.service.QUERY_MOD_DEFAULTSLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author shantaram.chavan
 */
public class QUERY_MOD_DEFAULTSClp extends BaseModelImpl<QUERY_MOD_DEFAULTS>
	implements QUERY_MOD_DEFAULTS {
	public QUERY_MOD_DEFAULTSClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return QUERY_MOD_DEFAULTS.class;
	}

	@Override
	public String getModelClassName() {
		return QUERY_MOD_DEFAULTS.class.getName();
	}

	@Override
	public int getPrimaryKey() {
		return _QUERY_MOD_DEFAULTS_ID;
	}

	@Override
	public void setPrimaryKey(int primaryKey) {
		setQUERY_MOD_DEFAULTS_ID(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _QUERY_MOD_DEFAULTS_ID;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Integer)primaryKeyObj).intValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("QUERY_MOD_DEFAULTS_ID", getQUERY_MOD_DEFAULTS_ID());
		attributes.put("CURR_VAL", getCURR_VAL());
		attributes.put("NEW_VAL", getNEW_VAL());
		attributes.put("IS_ACTIVE", getIS_ACTIVE());
		attributes.put("UPDATED_TIMESTAMP", getUPDATED_TIMESTAMP());
		attributes.put("TYPE", getTYPE());
		attributes.put("CURR_LEVEL", getCURR_LEVEL());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Integer QUERY_MOD_DEFAULTS_ID = (Integer)attributes.get(
				"QUERY_MOD_DEFAULTS_ID");

		if (QUERY_MOD_DEFAULTS_ID != null) {
			setQUERY_MOD_DEFAULTS_ID(QUERY_MOD_DEFAULTS_ID);
		}

		String CURR_VAL = (String)attributes.get("CURR_VAL");

		if (CURR_VAL != null) {
			setCURR_VAL(CURR_VAL);
		}

		String NEW_VAL = (String)attributes.get("NEW_VAL");

		if (NEW_VAL != null) {
			setNEW_VAL(NEW_VAL);
		}

		Integer IS_ACTIVE = (Integer)attributes.get("IS_ACTIVE");

		if (IS_ACTIVE != null) {
			setIS_ACTIVE(IS_ACTIVE);
		}

		Date UPDATED_TIMESTAMP = (Date)attributes.get("UPDATED_TIMESTAMP");

		if (UPDATED_TIMESTAMP != null) {
			setUPDATED_TIMESTAMP(UPDATED_TIMESTAMP);
		}

		String TYPE = (String)attributes.get("TYPE");

		if (TYPE != null) {
			setTYPE(TYPE);
		}

		Integer CURR_LEVEL = (Integer)attributes.get("CURR_LEVEL");

		if (CURR_LEVEL != null) {
			setCURR_LEVEL(CURR_LEVEL);
		}
	}

	@Override
	public int getQUERY_MOD_DEFAULTS_ID() {
		return _QUERY_MOD_DEFAULTS_ID;
	}

	@Override
	public void setQUERY_MOD_DEFAULTS_ID(int QUERY_MOD_DEFAULTS_ID) {
		_QUERY_MOD_DEFAULTS_ID = QUERY_MOD_DEFAULTS_ID;

		if (_query_mod_defaultsRemoteModel != null) {
			try {
				Class<?> clazz = _query_mod_defaultsRemoteModel.getClass();

				Method method = clazz.getMethod("setQUERY_MOD_DEFAULTS_ID",
						int.class);

				method.invoke(_query_mod_defaultsRemoteModel,
					QUERY_MOD_DEFAULTS_ID);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCURR_VAL() {
		return _CURR_VAL;
	}

	@Override
	public void setCURR_VAL(String CURR_VAL) {
		_CURR_VAL = CURR_VAL;

		if (_query_mod_defaultsRemoteModel != null) {
			try {
				Class<?> clazz = _query_mod_defaultsRemoteModel.getClass();

				Method method = clazz.getMethod("setCURR_VAL", String.class);

				method.invoke(_query_mod_defaultsRemoteModel, CURR_VAL);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNEW_VAL() {
		return _NEW_VAL;
	}

	@Override
	public void setNEW_VAL(String NEW_VAL) {
		_NEW_VAL = NEW_VAL;

		if (_query_mod_defaultsRemoteModel != null) {
			try {
				Class<?> clazz = _query_mod_defaultsRemoteModel.getClass();

				Method method = clazz.getMethod("setNEW_VAL", String.class);

				method.invoke(_query_mod_defaultsRemoteModel, NEW_VAL);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getIS_ACTIVE() {
		return _IS_ACTIVE;
	}

	@Override
	public void setIS_ACTIVE(int IS_ACTIVE) {
		_IS_ACTIVE = IS_ACTIVE;

		if (_query_mod_defaultsRemoteModel != null) {
			try {
				Class<?> clazz = _query_mod_defaultsRemoteModel.getClass();

				Method method = clazz.getMethod("setIS_ACTIVE", int.class);

				method.invoke(_query_mod_defaultsRemoteModel, IS_ACTIVE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getUPDATED_TIMESTAMP() {
		return _UPDATED_TIMESTAMP;
	}

	@Override
	public void setUPDATED_TIMESTAMP(Date UPDATED_TIMESTAMP) {
		_UPDATED_TIMESTAMP = UPDATED_TIMESTAMP;

		if (_query_mod_defaultsRemoteModel != null) {
			try {
				Class<?> clazz = _query_mod_defaultsRemoteModel.getClass();

				Method method = clazz.getMethod("setUPDATED_TIMESTAMP",
						Date.class);

				method.invoke(_query_mod_defaultsRemoteModel, UPDATED_TIMESTAMP);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTYPE() {
		return _TYPE;
	}

	@Override
	public void setTYPE(String TYPE) {
		_TYPE = TYPE;

		if (_query_mod_defaultsRemoteModel != null) {
			try {
				Class<?> clazz = _query_mod_defaultsRemoteModel.getClass();

				Method method = clazz.getMethod("setTYPE", String.class);

				method.invoke(_query_mod_defaultsRemoteModel, TYPE);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getCURR_LEVEL() {
		return _CURR_LEVEL;
	}

	@Override
	public void setCURR_LEVEL(int CURR_LEVEL) {
		_CURR_LEVEL = CURR_LEVEL;

		if (_query_mod_defaultsRemoteModel != null) {
			try {
				Class<?> clazz = _query_mod_defaultsRemoteModel.getClass();

				Method method = clazz.getMethod("setCURR_LEVEL", int.class);

				method.invoke(_query_mod_defaultsRemoteModel, CURR_LEVEL);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getQUERY_MOD_DEFAULTSRemoteModel() {
		return _query_mod_defaultsRemoteModel;
	}

	public void setQUERY_MOD_DEFAULTSRemoteModel(
		BaseModel<?> query_mod_defaultsRemoteModel) {
		_query_mod_defaultsRemoteModel = query_mod_defaultsRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _query_mod_defaultsRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_query_mod_defaultsRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			QUERY_MOD_DEFAULTSLocalServiceUtil.addQUERY_MOD_DEFAULTS(this);
		}
		else {
			QUERY_MOD_DEFAULTSLocalServiceUtil.updateQUERY_MOD_DEFAULTS(this);
		}
	}

	@Override
	public QUERY_MOD_DEFAULTS toEscapedModel() {
		return (QUERY_MOD_DEFAULTS)ProxyUtil.newProxyInstance(QUERY_MOD_DEFAULTS.class.getClassLoader(),
			new Class[] { QUERY_MOD_DEFAULTS.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		QUERY_MOD_DEFAULTSClp clone = new QUERY_MOD_DEFAULTSClp();

		clone.setQUERY_MOD_DEFAULTS_ID(getQUERY_MOD_DEFAULTS_ID());
		clone.setCURR_VAL(getCURR_VAL());
		clone.setNEW_VAL(getNEW_VAL());
		clone.setIS_ACTIVE(getIS_ACTIVE());
		clone.setUPDATED_TIMESTAMP(getUPDATED_TIMESTAMP());
		clone.setTYPE(getTYPE());
		clone.setCURR_LEVEL(getCURR_LEVEL());

		return clone;
	}

	@Override
	public int compareTo(QUERY_MOD_DEFAULTS query_mod_defaults) {
		int primaryKey = query_mod_defaults.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof QUERY_MOD_DEFAULTSClp)) {
			return false;
		}

		QUERY_MOD_DEFAULTSClp query_mod_defaults = (QUERY_MOD_DEFAULTSClp)obj;

		int primaryKey = query_mod_defaults.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(15);

		sb.append("{QUERY_MOD_DEFAULTS_ID=");
		sb.append(getQUERY_MOD_DEFAULTS_ID());
		sb.append(", CURR_VAL=");
		sb.append(getCURR_VAL());
		sb.append(", NEW_VAL=");
		sb.append(getNEW_VAL());
		sb.append(", IS_ACTIVE=");
		sb.append(getIS_ACTIVE());
		sb.append(", UPDATED_TIMESTAMP=");
		sb.append(getUPDATED_TIMESTAMP());
		sb.append(", TYPE=");
		sb.append(getTYPE());
		sb.append(", CURR_LEVEL=");
		sb.append(getCURR_LEVEL());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(25);

		sb.append("<model><model-name>");
		sb.append("com.jioc.query.model.QUERY_MOD_DEFAULTS");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>QUERY_MOD_DEFAULTS_ID</column-name><column-value><![CDATA[");
		sb.append(getQUERY_MOD_DEFAULTS_ID());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>CURR_VAL</column-name><column-value><![CDATA[");
		sb.append(getCURR_VAL());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>NEW_VAL</column-name><column-value><![CDATA[");
		sb.append(getNEW_VAL());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>IS_ACTIVE</column-name><column-value><![CDATA[");
		sb.append(getIS_ACTIVE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>UPDATED_TIMESTAMP</column-name><column-value><![CDATA[");
		sb.append(getUPDATED_TIMESTAMP());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>TYPE</column-name><column-value><![CDATA[");
		sb.append(getTYPE());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>CURR_LEVEL</column-name><column-value><![CDATA[");
		sb.append(getCURR_LEVEL());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private int _QUERY_MOD_DEFAULTS_ID;
	private String _CURR_VAL;
	private String _NEW_VAL;
	private int _IS_ACTIVE;
	private Date _UPDATED_TIMESTAMP;
	private String _TYPE;
	private int _CURR_LEVEL;
	private BaseModel<?> _query_mod_defaultsRemoteModel;
	private Class<?> _clpSerializerClass = com.jioc.query.service.ClpSerializer.class;
}