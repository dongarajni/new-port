/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author shantaram.chavan
 * @generated
 */
public class SetupSoap implements Serializable {
	public static SetupSoap toSoapModel(Setup model) {
		SetupSoap soapModel = new SetupSoap();

		soapModel.setSetup_id(model.getSetup_id());
		soapModel.setKey(model.getKey());
		soapModel.setVal1(model.getVal1());
		soapModel.setVal2(model.getVal2());
		soapModel.setStatus(model.getStatus());
		soapModel.setUpdated_timestamp(model.getUpdated_timestamp());

		return soapModel;
	}

	public static SetupSoap[] toSoapModels(Setup[] models) {
		SetupSoap[] soapModels = new SetupSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static SetupSoap[][] toSoapModels(Setup[][] models) {
		SetupSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new SetupSoap[models.length][models[0].length];
		}
		else {
			soapModels = new SetupSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static SetupSoap[] toSoapModels(List<Setup> models) {
		List<SetupSoap> soapModels = new ArrayList<SetupSoap>(models.size());

		for (Setup model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new SetupSoap[soapModels.size()]);
	}

	public SetupSoap() {
	}

	public long getPrimaryKey() {
		return _setup_id;
	}

	public void setPrimaryKey(long pk) {
		setSetup_id(pk);
	}

	public long getSetup_id() {
		return _setup_id;
	}

	public void setSetup_id(long setup_id) {
		_setup_id = setup_id;
	}

	public String getKey() {
		return _key;
	}

	public void setKey(String key) {
		_key = key;
	}

	public String getVal1() {
		return _val1;
	}

	public void setVal1(String val1) {
		_val1 = val1;
	}

	public String getVal2() {
		return _val2;
	}

	public void setVal2(String val2) {
		_val2 = val2;
	}

	public int getStatus() {
		return _status;
	}

	public void setStatus(int status) {
		_status = status;
	}

	public Date getUpdated_timestamp() {
		return _updated_timestamp;
	}

	public void setUpdated_timestamp(Date updated_timestamp) {
		_updated_timestamp = updated_timestamp;
	}

	private long _setup_id;
	private String _key;
	private String _val1;
	private String _val2;
	private int _status;
	private Date _updated_timestamp;
}