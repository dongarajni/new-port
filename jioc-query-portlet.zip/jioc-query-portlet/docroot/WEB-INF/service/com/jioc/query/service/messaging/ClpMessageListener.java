/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.query.service.messaging;

import com.jioc.query.service.ArticleLocalServiceUtil;
import com.jioc.query.service.CASE_RES_MSTLocalServiceUtil;
import com.jioc.query.service.ClpSerializer;
import com.jioc.query.service.EMP_DETAILSLocalServiceUtil;
import com.jioc.query.service.Emp_User_MappingLocalServiceUtil;
import com.jioc.query.service.OC_CAT_MSTLocalServiceUtil;
import com.jioc.query.service.OC_JOB_FUNCTION_MSTLocalServiceUtil;
import com.jioc.query.service.OC_SUB_CAT_MSTLocalServiceUtil;
import com.jioc.query.service.QUERY_MOD_DEFAULTSLocalServiceUtil;
import com.jioc.query.service.Query_Add_Param_OCLocalServiceUtil;
import com.jioc.query.service.Query_AttachmentsLocalServiceUtil;
import com.jioc.query.service.Query_DetailsLocalServiceUtil;
import com.jioc.query.service.Query_ResolutionLocalServiceUtil;
import com.jioc.query.service.Query_TransactionLocalServiceUtil;
import com.jioc.query.service.RESOLVER_DEFAULTSLocalServiceUtil;
import com.jioc.query.service.RESOLVER_LEVEL_MSTLocalServiceUtil;
import com.jioc.query.service.SetupLocalServiceUtil;

import com.liferay.portal.kernel.messaging.BaseMessageListener;
import com.liferay.portal.kernel.messaging.Message;

/**
 * @author shantaram.chavan
 */
public class ClpMessageListener extends BaseMessageListener {
	public static String getServletContextName() {
		return ClpSerializer.getServletContextName();
	}

	@Override
	protected void doReceive(Message message) throws Exception {
		String command = message.getString("command");
		String servletContextName = message.getString("servletContextName");

		if (command.equals("undeploy") &&
				servletContextName.equals(getServletContextName())) {
			ArticleLocalServiceUtil.clearService();

			CASE_RES_MSTLocalServiceUtil.clearService();

			EMP_DETAILSLocalServiceUtil.clearService();

			Emp_User_MappingLocalServiceUtil.clearService();

			OC_CAT_MSTLocalServiceUtil.clearService();

			OC_JOB_FUNCTION_MSTLocalServiceUtil.clearService();

			OC_SUB_CAT_MSTLocalServiceUtil.clearService();

			Query_Add_Param_OCLocalServiceUtil.clearService();

			Query_AttachmentsLocalServiceUtil.clearService();

			Query_DetailsLocalServiceUtil.clearService();

			QUERY_MOD_DEFAULTSLocalServiceUtil.clearService();

			Query_ResolutionLocalServiceUtil.clearService();

			Query_TransactionLocalServiceUtil.clearService();

			RESOLVER_DEFAULTSLocalServiceUtil.clearService();

			RESOLVER_LEVEL_MSTLocalServiceUtil.clearService();

			SetupLocalServiceUtil.clearService();
		}
	}
}