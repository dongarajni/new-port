/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link MessageUserGroup}.
 * </p>
 *
 * @author dewang.patel
 * @see MessageUserGroup
 * @generated
 */
public class MessageUserGroupWrapper implements MessageUserGroup,
	ModelWrapper<MessageUserGroup> {
	public MessageUserGroupWrapper(MessageUserGroup messageUserGroup) {
		_messageUserGroup = messageUserGroup;
	}

	@Override
	public Class<?> getModelClass() {
		return MessageUserGroup.class;
	}

	@Override
	public String getModelClassName() {
		return MessageUserGroup.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("pid", getPid());
		attributes.put("messageid", getMessageid());
		attributes.put("isgroup", getIsgroup());
		attributes.put("userorgrp_name", getUserorgrp_name());
		attributes.put("userorgrp_id", getUserorgrp_id());
		attributes.put("createdbyuserid", getCreatedbyuserid());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long pid = (Long)attributes.get("pid");

		if (pid != null) {
			setPid(pid);
		}

		Long messageid = (Long)attributes.get("messageid");

		if (messageid != null) {
			setMessageid(messageid);
		}

		Boolean isgroup = (Boolean)attributes.get("isgroup");

		if (isgroup != null) {
			setIsgroup(isgroup);
		}

		String userorgrp_name = (String)attributes.get("userorgrp_name");

		if (userorgrp_name != null) {
			setUserorgrp_name(userorgrp_name);
		}

		Long userorgrp_id = (Long)attributes.get("userorgrp_id");

		if (userorgrp_id != null) {
			setUserorgrp_id(userorgrp_id);
		}

		Long createdbyuserid = (Long)attributes.get("createdbyuserid");

		if (createdbyuserid != null) {
			setCreatedbyuserid(createdbyuserid);
		}
	}

	/**
	* Returns the primary key of this message user group.
	*
	* @return the primary key of this message user group
	*/
	@Override
	public long getPrimaryKey() {
		return _messageUserGroup.getPrimaryKey();
	}

	/**
	* Sets the primary key of this message user group.
	*
	* @param primaryKey the primary key of this message user group
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_messageUserGroup.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the pid of this message user group.
	*
	* @return the pid of this message user group
	*/
	@Override
	public long getPid() {
		return _messageUserGroup.getPid();
	}

	/**
	* Sets the pid of this message user group.
	*
	* @param pid the pid of this message user group
	*/
	@Override
	public void setPid(long pid) {
		_messageUserGroup.setPid(pid);
	}

	/**
	* Returns the messageid of this message user group.
	*
	* @return the messageid of this message user group
	*/
	@Override
	public long getMessageid() {
		return _messageUserGroup.getMessageid();
	}

	/**
	* Sets the messageid of this message user group.
	*
	* @param messageid the messageid of this message user group
	*/
	@Override
	public void setMessageid(long messageid) {
		_messageUserGroup.setMessageid(messageid);
	}

	/**
	* Returns the isgroup of this message user group.
	*
	* @return the isgroup of this message user group
	*/
	@Override
	public boolean getIsgroup() {
		return _messageUserGroup.getIsgroup();
	}

	/**
	* Returns <code>true</code> if this message user group is isgroup.
	*
	* @return <code>true</code> if this message user group is isgroup; <code>false</code> otherwise
	*/
	@Override
	public boolean isIsgroup() {
		return _messageUserGroup.isIsgroup();
	}

	/**
	* Sets whether this message user group is isgroup.
	*
	* @param isgroup the isgroup of this message user group
	*/
	@Override
	public void setIsgroup(boolean isgroup) {
		_messageUserGroup.setIsgroup(isgroup);
	}

	/**
	* Returns the userorgrp_name of this message user group.
	*
	* @return the userorgrp_name of this message user group
	*/
	@Override
	public java.lang.String getUserorgrp_name() {
		return _messageUserGroup.getUserorgrp_name();
	}

	/**
	* Sets the userorgrp_name of this message user group.
	*
	* @param userorgrp_name the userorgrp_name of this message user group
	*/
	@Override
	public void setUserorgrp_name(java.lang.String userorgrp_name) {
		_messageUserGroup.setUserorgrp_name(userorgrp_name);
	}

	/**
	* Returns the userorgrp_id of this message user group.
	*
	* @return the userorgrp_id of this message user group
	*/
	@Override
	public long getUserorgrp_id() {
		return _messageUserGroup.getUserorgrp_id();
	}

	/**
	* Sets the userorgrp_id of this message user group.
	*
	* @param userorgrp_id the userorgrp_id of this message user group
	*/
	@Override
	public void setUserorgrp_id(long userorgrp_id) {
		_messageUserGroup.setUserorgrp_id(userorgrp_id);
	}

	/**
	* Returns the createdbyuserid of this message user group.
	*
	* @return the createdbyuserid of this message user group
	*/
	@Override
	public long getCreatedbyuserid() {
		return _messageUserGroup.getCreatedbyuserid();
	}

	/**
	* Sets the createdbyuserid of this message user group.
	*
	* @param createdbyuserid the createdbyuserid of this message user group
	*/
	@Override
	public void setCreatedbyuserid(long createdbyuserid) {
		_messageUserGroup.setCreatedbyuserid(createdbyuserid);
	}

	@Override
	public boolean isNew() {
		return _messageUserGroup.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_messageUserGroup.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _messageUserGroup.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_messageUserGroup.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _messageUserGroup.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _messageUserGroup.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_messageUserGroup.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _messageUserGroup.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_messageUserGroup.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_messageUserGroup.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_messageUserGroup.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new MessageUserGroupWrapper((MessageUserGroup)_messageUserGroup.clone());
	}

	@Override
	public int compareTo(
		com.jio.central.services.custom.tables.model.MessageUserGroup messageUserGroup) {
		return _messageUserGroup.compareTo(messageUserGroup);
	}

	@Override
	public int hashCode() {
		return _messageUserGroup.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jio.central.services.custom.tables.model.MessageUserGroup> toCacheModel() {
		return _messageUserGroup.toCacheModel();
	}

	@Override
	public com.jio.central.services.custom.tables.model.MessageUserGroup toEscapedModel() {
		return new MessageUserGroupWrapper(_messageUserGroup.toEscapedModel());
	}

	@Override
	public com.jio.central.services.custom.tables.model.MessageUserGroup toUnescapedModel() {
		return new MessageUserGroupWrapper(_messageUserGroup.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _messageUserGroup.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _messageUserGroup.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_messageUserGroup.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof MessageUserGroupWrapper)) {
			return false;
		}

		MessageUserGroupWrapper messageUserGroupWrapper = (MessageUserGroupWrapper)obj;

		if (Validator.equals(_messageUserGroup,
					messageUserGroupWrapper._messageUserGroup)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public MessageUserGroup getWrappedMessageUserGroup() {
		return _messageUserGroup;
	}

	@Override
	public MessageUserGroup getWrappedModel() {
		return _messageUserGroup;
	}

	@Override
	public void resetOriginalValues() {
		_messageUserGroup.resetOriginalValues();
	}

	private MessageUserGroup _messageUserGroup;
}