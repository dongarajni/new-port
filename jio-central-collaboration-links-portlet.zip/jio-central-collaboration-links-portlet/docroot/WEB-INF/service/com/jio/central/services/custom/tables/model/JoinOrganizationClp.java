/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.model;

import com.jio.central.services.custom.tables.service.ClpSerializer;
import com.jio.central.services.custom.tables.service.JoinOrganizationLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author dewang.patel
 */
public class JoinOrganizationClp extends BaseModelImpl<JoinOrganization>
	implements JoinOrganization {
	public JoinOrganizationClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return JoinOrganization.class;
	}

	@Override
	public String getModelClassName() {
		return JoinOrganization.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _joinOrganizationId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setJoinOrganizationId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _joinOrganizationId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("joinOrganizationId", getJoinOrganizationId());
		attributes.put("joinOrganizationName", getJoinOrganizationName());
		attributes.put("description", getDescription());
		attributes.put("joinOrganizationStatus", getJoinOrganizationStatus());
		attributes.put("statusByUserId", getStatusByUserId());
		attributes.put("statusDate", getStatusDate());
		attributes.put("companyId", getCompanyId());
		attributes.put("groupId", getGroupId());
		attributes.put("userId", getUserId());
		attributes.put("organizaId", getOrganizaId());
		attributes.put("createDate", getCreateDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long joinOrganizationId = (Long)attributes.get("joinOrganizationId");

		if (joinOrganizationId != null) {
			setJoinOrganizationId(joinOrganizationId);
		}

		String joinOrganizationName = (String)attributes.get(
				"joinOrganizationName");

		if (joinOrganizationName != null) {
			setJoinOrganizationName(joinOrganizationName);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}

		Integer joinOrganizationStatus = (Integer)attributes.get(
				"joinOrganizationStatus");

		if (joinOrganizationStatus != null) {
			setJoinOrganizationStatus(joinOrganizationStatus);
		}

		Long statusByUserId = (Long)attributes.get("statusByUserId");

		if (statusByUserId != null) {
			setStatusByUserId(statusByUserId);
		}

		Date statusDate = (Date)attributes.get("statusDate");

		if (statusDate != null) {
			setStatusDate(statusDate);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		Long organizaId = (Long)attributes.get("organizaId");

		if (organizaId != null) {
			setOrganizaId(organizaId);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}
	}

	@Override
	public long getJoinOrganizationId() {
		return _joinOrganizationId;
	}

	@Override
	public void setJoinOrganizationId(long joinOrganizationId) {
		_joinOrganizationId = joinOrganizationId;

		if (_joinOrganizationRemoteModel != null) {
			try {
				Class<?> clazz = _joinOrganizationRemoteModel.getClass();

				Method method = clazz.getMethod("setJoinOrganizationId",
						long.class);

				method.invoke(_joinOrganizationRemoteModel, joinOrganizationId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getJoinOrganizationName() {
		return _joinOrganizationName;
	}

	@Override
	public void setJoinOrganizationName(String joinOrganizationName) {
		_joinOrganizationName = joinOrganizationName;

		if (_joinOrganizationRemoteModel != null) {
			try {
				Class<?> clazz = _joinOrganizationRemoteModel.getClass();

				Method method = clazz.getMethod("setJoinOrganizationName",
						String.class);

				method.invoke(_joinOrganizationRemoteModel, joinOrganizationName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDescription() {
		return _description;
	}

	@Override
	public void setDescription(String description) {
		_description = description;

		if (_joinOrganizationRemoteModel != null) {
			try {
				Class<?> clazz = _joinOrganizationRemoteModel.getClass();

				Method method = clazz.getMethod("setDescription", String.class);

				method.invoke(_joinOrganizationRemoteModel, description);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getJoinOrganizationStatus() {
		return _joinOrganizationStatus;
	}

	@Override
	public void setJoinOrganizationStatus(int joinOrganizationStatus) {
		_joinOrganizationStatus = joinOrganizationStatus;

		if (_joinOrganizationRemoteModel != null) {
			try {
				Class<?> clazz = _joinOrganizationRemoteModel.getClass();

				Method method = clazz.getMethod("setJoinOrganizationStatus",
						int.class);

				method.invoke(_joinOrganizationRemoteModel,
					joinOrganizationStatus);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getStatusByUserId() {
		return _statusByUserId;
	}

	@Override
	public void setStatusByUserId(long statusByUserId) {
		_statusByUserId = statusByUserId;

		if (_joinOrganizationRemoteModel != null) {
			try {
				Class<?> clazz = _joinOrganizationRemoteModel.getClass();

				Method method = clazz.getMethod("setStatusByUserId", long.class);

				method.invoke(_joinOrganizationRemoteModel, statusByUserId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getStatusByUserUuid() throws SystemException {
		return PortalUtil.getUserValue(getStatusByUserId(), "uuid",
			_statusByUserUuid);
	}

	@Override
	public void setStatusByUserUuid(String statusByUserUuid) {
		_statusByUserUuid = statusByUserUuid;
	}

	@Override
	public Date getStatusDate() {
		return _statusDate;
	}

	@Override
	public void setStatusDate(Date statusDate) {
		_statusDate = statusDate;

		if (_joinOrganizationRemoteModel != null) {
			try {
				Class<?> clazz = _joinOrganizationRemoteModel.getClass();

				Method method = clazz.getMethod("setStatusDate", Date.class);

				method.invoke(_joinOrganizationRemoteModel, statusDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getCompanyId() {
		return _companyId;
	}

	@Override
	public void setCompanyId(long companyId) {
		_companyId = companyId;

		if (_joinOrganizationRemoteModel != null) {
			try {
				Class<?> clazz = _joinOrganizationRemoteModel.getClass();

				Method method = clazz.getMethod("setCompanyId", long.class);

				method.invoke(_joinOrganizationRemoteModel, companyId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getGroupId() {
		return _groupId;
	}

	@Override
	public void setGroupId(long groupId) {
		_groupId = groupId;

		if (_joinOrganizationRemoteModel != null) {
			try {
				Class<?> clazz = _joinOrganizationRemoteModel.getClass();

				Method method = clazz.getMethod("setGroupId", long.class);

				method.invoke(_joinOrganizationRemoteModel, groupId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getUserId() {
		return _userId;
	}

	@Override
	public void setUserId(long userId) {
		_userId = userId;

		if (_joinOrganizationRemoteModel != null) {
			try {
				Class<?> clazz = _joinOrganizationRemoteModel.getClass();

				Method method = clazz.getMethod("setUserId", long.class);

				method.invoke(_joinOrganizationRemoteModel, userId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUserUuid() throws SystemException {
		return PortalUtil.getUserValue(getUserId(), "uuid", _userUuid);
	}

	@Override
	public void setUserUuid(String userUuid) {
		_userUuid = userUuid;
	}

	@Override
	public long getOrganizaId() {
		return _organizaId;
	}

	@Override
	public void setOrganizaId(long organizaId) {
		_organizaId = organizaId;

		if (_joinOrganizationRemoteModel != null) {
			try {
				Class<?> clazz = _joinOrganizationRemoteModel.getClass();

				Method method = clazz.getMethod("setOrganizaId", long.class);

				method.invoke(_joinOrganizationRemoteModel, organizaId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getCreateDate() {
		return _createDate;
	}

	@Override
	public void setCreateDate(Date createDate) {
		_createDate = createDate;

		if (_joinOrganizationRemoteModel != null) {
			try {
				Class<?> clazz = _joinOrganizationRemoteModel.getClass();

				Method method = clazz.getMethod("setCreateDate", Date.class);

				method.invoke(_joinOrganizationRemoteModel, createDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getJoinOrganizationRemoteModel() {
		return _joinOrganizationRemoteModel;
	}

	public void setJoinOrganizationRemoteModel(
		BaseModel<?> joinOrganizationRemoteModel) {
		_joinOrganizationRemoteModel = joinOrganizationRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _joinOrganizationRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_joinOrganizationRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			JoinOrganizationLocalServiceUtil.addJoinOrganization(this);
		}
		else {
			JoinOrganizationLocalServiceUtil.updateJoinOrganization(this);
		}
	}

	@Override
	public JoinOrganization toEscapedModel() {
		return (JoinOrganization)ProxyUtil.newProxyInstance(JoinOrganization.class.getClassLoader(),
			new Class[] { JoinOrganization.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		JoinOrganizationClp clone = new JoinOrganizationClp();

		clone.setJoinOrganizationId(getJoinOrganizationId());
		clone.setJoinOrganizationName(getJoinOrganizationName());
		clone.setDescription(getDescription());
		clone.setJoinOrganizationStatus(getJoinOrganizationStatus());
		clone.setStatusByUserId(getStatusByUserId());
		clone.setStatusDate(getStatusDate());
		clone.setCompanyId(getCompanyId());
		clone.setGroupId(getGroupId());
		clone.setUserId(getUserId());
		clone.setOrganizaId(getOrganizaId());
		clone.setCreateDate(getCreateDate());

		return clone;
	}

	@Override
	public int compareTo(JoinOrganization joinOrganization) {
		long primaryKey = joinOrganization.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof JoinOrganizationClp)) {
			return false;
		}

		JoinOrganizationClp joinOrganization = (JoinOrganizationClp)obj;

		long primaryKey = joinOrganization.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(23);

		sb.append("{joinOrganizationId=");
		sb.append(getJoinOrganizationId());
		sb.append(", joinOrganizationName=");
		sb.append(getJoinOrganizationName());
		sb.append(", description=");
		sb.append(getDescription());
		sb.append(", joinOrganizationStatus=");
		sb.append(getJoinOrganizationStatus());
		sb.append(", statusByUserId=");
		sb.append(getStatusByUserId());
		sb.append(", statusDate=");
		sb.append(getStatusDate());
		sb.append(", companyId=");
		sb.append(getCompanyId());
		sb.append(", groupId=");
		sb.append(getGroupId());
		sb.append(", userId=");
		sb.append(getUserId());
		sb.append(", organizaId=");
		sb.append(getOrganizaId());
		sb.append(", createDate=");
		sb.append(getCreateDate());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(37);

		sb.append("<model><model-name>");
		sb.append(
			"com.jio.central.services.custom.tables.model.JoinOrganization");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>joinOrganizationId</column-name><column-value><![CDATA[");
		sb.append(getJoinOrganizationId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>joinOrganizationName</column-name><column-value><![CDATA[");
		sb.append(getJoinOrganizationName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>description</column-name><column-value><![CDATA[");
		sb.append(getDescription());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>joinOrganizationStatus</column-name><column-value><![CDATA[");
		sb.append(getJoinOrganizationStatus());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>statusByUserId</column-name><column-value><![CDATA[");
		sb.append(getStatusByUserId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>statusDate</column-name><column-value><![CDATA[");
		sb.append(getStatusDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>companyId</column-name><column-value><![CDATA[");
		sb.append(getCompanyId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>groupId</column-name><column-value><![CDATA[");
		sb.append(getGroupId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userId</column-name><column-value><![CDATA[");
		sb.append(getUserId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>organizaId</column-name><column-value><![CDATA[");
		sb.append(getOrganizaId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>createDate</column-name><column-value><![CDATA[");
		sb.append(getCreateDate());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _joinOrganizationId;
	private String _joinOrganizationName;
	private String _description;
	private int _joinOrganizationStatus;
	private long _statusByUserId;
	private String _statusByUserUuid;
	private Date _statusDate;
	private long _companyId;
	private long _groupId;
	private long _userId;
	private String _userUuid;
	private long _organizaId;
	private Date _createDate;
	private BaseModel<?> _joinOrganizationRemoteModel;
	private Class<?> _clpSerializerClass = com.jio.central.services.custom.tables.service.ClpSerializer.class;
}