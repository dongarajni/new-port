/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableLocalService;

/**
 * Provides the local service utility for UserGroupAttributeMapping. This utility wraps
 * {@link com.jio.central.services.custom.tables.service.impl.UserGroupAttributeMappingLocalServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author dewang.patel
 * @see UserGroupAttributeMappingLocalService
 * @see com.jio.central.services.custom.tables.service.base.UserGroupAttributeMappingLocalServiceBaseImpl
 * @see com.jio.central.services.custom.tables.service.impl.UserGroupAttributeMappingLocalServiceImpl
 * @generated
 */
public class UserGroupAttributeMappingLocalServiceUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to {@link com.jio.central.services.custom.tables.service.impl.UserGroupAttributeMappingLocalServiceImpl} and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	* Adds the user group attribute mapping to the database. Also notifies the appropriate model listeners.
	*
	* @param userGroupAttributeMapping the user group attribute mapping
	* @return the user group attribute mapping that was added
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.central.services.custom.tables.model.UserGroupAttributeMapping addUserGroupAttributeMapping(
		com.jio.central.services.custom.tables.model.UserGroupAttributeMapping userGroupAttributeMapping)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .addUserGroupAttributeMapping(userGroupAttributeMapping);
	}

	/**
	* Creates a new user group attribute mapping with the primary key. Does not add the user group attribute mapping to the database.
	*
	* @param collaboration_usergroupid the primary key for the new user group attribute mapping
	* @return the new user group attribute mapping
	*/
	public static com.jio.central.services.custom.tables.model.UserGroupAttributeMapping createUserGroupAttributeMapping(
		long collaboration_usergroupid) {
		return getService()
				   .createUserGroupAttributeMapping(collaboration_usergroupid);
	}

	/**
	* Deletes the user group attribute mapping with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param collaboration_usergroupid the primary key of the user group attribute mapping
	* @return the user group attribute mapping that was removed
	* @throws PortalException if a user group attribute mapping with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.central.services.custom.tables.model.UserGroupAttributeMapping deleteUserGroupAttributeMapping(
		long collaboration_usergroupid)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .deleteUserGroupAttributeMapping(collaboration_usergroupid);
	}

	/**
	* Deletes the user group attribute mapping from the database. Also notifies the appropriate model listeners.
	*
	* @param userGroupAttributeMapping the user group attribute mapping
	* @return the user group attribute mapping that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.central.services.custom.tables.model.UserGroupAttributeMapping deleteUserGroupAttributeMapping(
		com.jio.central.services.custom.tables.model.UserGroupAttributeMapping userGroupAttributeMapping)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .deleteUserGroupAttributeMapping(userGroupAttributeMapping);
	}

	public static com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.UserGroupAttributeMappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.UserGroupAttributeMappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static com.jio.central.services.custom.tables.model.UserGroupAttributeMapping fetchUserGroupAttributeMapping(
		long collaboration_usergroupid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .fetchUserGroupAttributeMapping(collaboration_usergroupid);
	}

	/**
	* Returns the user group attribute mapping with the primary key.
	*
	* @param collaboration_usergroupid the primary key of the user group attribute mapping
	* @return the user group attribute mapping
	* @throws PortalException if a user group attribute mapping with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.central.services.custom.tables.model.UserGroupAttributeMapping getUserGroupAttributeMapping(
		long collaboration_usergroupid)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .getUserGroupAttributeMapping(collaboration_usergroupid);
	}

	public static com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the user group attribute mappings.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.UserGroupAttributeMappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of user group attribute mappings
	* @param end the upper bound of the range of user group attribute mappings (not inclusive)
	* @return the range of user group attribute mappings
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.central.services.custom.tables.model.UserGroupAttributeMapping> getUserGroupAttributeMappings(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getUserGroupAttributeMappings(start, end);
	}

	/**
	* Returns the number of user group attribute mappings.
	*
	* @return the number of user group attribute mappings
	* @throws SystemException if a system exception occurred
	*/
	public static int getUserGroupAttributeMappingsCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getUserGroupAttributeMappingsCount();
	}

	/**
	* Updates the user group attribute mapping in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param userGroupAttributeMapping the user group attribute mapping
	* @return the user group attribute mapping that was updated
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.central.services.custom.tables.model.UserGroupAttributeMapping updateUserGroupAttributeMapping(
		com.jio.central.services.custom.tables.model.UserGroupAttributeMapping userGroupAttributeMapping)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .updateUserGroupAttributeMapping(userGroupAttributeMapping);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	public static java.lang.String getBeanIdentifier() {
		return getService().getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	public static void setBeanIdentifier(java.lang.String beanIdentifier) {
		getService().setBeanIdentifier(beanIdentifier);
	}

	public static java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return getService().invokeMethod(name, parameterTypes, arguments);
	}

	public static void clearService() {
		_service = null;
	}

	public static UserGroupAttributeMappingLocalService getService() {
		if (_service == null) {
			InvokableLocalService invokableLocalService = (InvokableLocalService)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
					UserGroupAttributeMappingLocalService.class.getName());

			if (invokableLocalService instanceof UserGroupAttributeMappingLocalService) {
				_service = (UserGroupAttributeMappingLocalService)invokableLocalService;
			}
			else {
				_service = new UserGroupAttributeMappingLocalServiceClp(invokableLocalService);
			}

			ReferenceRegistry.registerReference(UserGroupAttributeMappingLocalServiceUtil.class,
				"_service");
		}

		return _service;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setService(UserGroupAttributeMappingLocalService service) {
	}

	private static UserGroupAttributeMappingLocalService _service;
}