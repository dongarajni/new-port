/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author dewang.patel
 * @generated
 */
public class UserGroupAttributeMappingSoap implements Serializable {
	public static UserGroupAttributeMappingSoap toSoapModel(
		UserGroupAttributeMapping model) {
		UserGroupAttributeMappingSoap soapModel = new UserGroupAttributeMappingSoap();

		soapModel.setCollaboration_usergroupid(model.getCollaboration_usergroupid());
		soapModel.setClasspk(model.getClasspk());
		soapModel.setUser_group_name(model.getUser_group_name());
		soapModel.setIsgroup(model.getIsgroup());

		return soapModel;
	}

	public static UserGroupAttributeMappingSoap[] toSoapModels(
		UserGroupAttributeMapping[] models) {
		UserGroupAttributeMappingSoap[] soapModels = new UserGroupAttributeMappingSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static UserGroupAttributeMappingSoap[][] toSoapModels(
		UserGroupAttributeMapping[][] models) {
		UserGroupAttributeMappingSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new UserGroupAttributeMappingSoap[models.length][models[0].length];
		}
		else {
			soapModels = new UserGroupAttributeMappingSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static UserGroupAttributeMappingSoap[] toSoapModels(
		List<UserGroupAttributeMapping> models) {
		List<UserGroupAttributeMappingSoap> soapModels = new ArrayList<UserGroupAttributeMappingSoap>(models.size());

		for (UserGroupAttributeMapping model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new UserGroupAttributeMappingSoap[soapModels.size()]);
	}

	public UserGroupAttributeMappingSoap() {
	}

	public long getPrimaryKey() {
		return _collaboration_usergroupid;
	}

	public void setPrimaryKey(long pk) {
		setCollaboration_usergroupid(pk);
	}

	public long getCollaboration_usergroupid() {
		return _collaboration_usergroupid;
	}

	public void setCollaboration_usergroupid(long collaboration_usergroupid) {
		_collaboration_usergroupid = collaboration_usergroupid;
	}

	public long getClasspk() {
		return _classpk;
	}

	public void setClasspk(long classpk) {
		_classpk = classpk;
	}

	public String getUser_group_name() {
		return _user_group_name;
	}

	public void setUser_group_name(String user_group_name) {
		_user_group_name = user_group_name;
	}

	public boolean getIsgroup() {
		return _isgroup;
	}

	public boolean isIsgroup() {
		return _isgroup;
	}

	public void setIsgroup(boolean isgroup) {
		_isgroup = isgroup;
	}

	private long _collaboration_usergroupid;
	private long _classpk;
	private String _user_group_name;
	private boolean _isgroup;
}