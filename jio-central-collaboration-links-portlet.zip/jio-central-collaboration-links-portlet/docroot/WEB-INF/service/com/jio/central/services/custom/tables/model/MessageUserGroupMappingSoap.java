/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author dewang.patel
 * @generated
 */
public class MessageUserGroupMappingSoap implements Serializable {
	public static MessageUserGroupMappingSoap toSoapModel(
		MessageUserGroupMapping model) {
		MessageUserGroupMappingSoap soapModel = new MessageUserGroupMappingSoap();

		soapModel.setMessage_relationid(model.getMessage_relationid());
		soapModel.setMessagepid(model.getMessagepid());
		soapModel.setCust_attributeid(model.getCust_attributeid());
		soapModel.setCreatedbyid(model.getCreatedbyid());

		return soapModel;
	}

	public static MessageUserGroupMappingSoap[] toSoapModels(
		MessageUserGroupMapping[] models) {
		MessageUserGroupMappingSoap[] soapModels = new MessageUserGroupMappingSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static MessageUserGroupMappingSoap[][] toSoapModels(
		MessageUserGroupMapping[][] models) {
		MessageUserGroupMappingSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new MessageUserGroupMappingSoap[models.length][models[0].length];
		}
		else {
			soapModels = new MessageUserGroupMappingSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static MessageUserGroupMappingSoap[] toSoapModels(
		List<MessageUserGroupMapping> models) {
		List<MessageUserGroupMappingSoap> soapModels = new ArrayList<MessageUserGroupMappingSoap>(models.size());

		for (MessageUserGroupMapping model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new MessageUserGroupMappingSoap[soapModels.size()]);
	}

	public MessageUserGroupMappingSoap() {
	}

	public long getPrimaryKey() {
		return _message_relationid;
	}

	public void setPrimaryKey(long pk) {
		setMessage_relationid(pk);
	}

	public long getMessage_relationid() {
		return _message_relationid;
	}

	public void setMessage_relationid(long message_relationid) {
		_message_relationid = message_relationid;
	}

	public long getMessagepid() {
		return _messagepid;
	}

	public void setMessagepid(long messagepid) {
		_messagepid = messagepid;
	}

	public long getCust_attributeid() {
		return _cust_attributeid;
	}

	public void setCust_attributeid(long cust_attributeid) {
		_cust_attributeid = cust_attributeid;
	}

	public long getCreatedbyid() {
		return _createdbyid;
	}

	public void setCreatedbyid(long createdbyid) {
		_createdbyid = createdbyid;
	}

	private long _message_relationid;
	private long _messagepid;
	private long _cust_attributeid;
	private long _createdbyid;
}