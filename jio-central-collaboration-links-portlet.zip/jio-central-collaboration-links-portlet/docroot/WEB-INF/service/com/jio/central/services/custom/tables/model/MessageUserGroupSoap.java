/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author dewang.patel
 * @generated
 */
public class MessageUserGroupSoap implements Serializable {
	public static MessageUserGroupSoap toSoapModel(MessageUserGroup model) {
		MessageUserGroupSoap soapModel = new MessageUserGroupSoap();

		soapModel.setPid(model.getPid());
		soapModel.setMessageid(model.getMessageid());
		soapModel.setIsgroup(model.getIsgroup());
		soapModel.setUserorgrp_name(model.getUserorgrp_name());
		soapModel.setUserorgrp_id(model.getUserorgrp_id());
		soapModel.setCreatedbyuserid(model.getCreatedbyuserid());

		return soapModel;
	}

	public static MessageUserGroupSoap[] toSoapModels(MessageUserGroup[] models) {
		MessageUserGroupSoap[] soapModels = new MessageUserGroupSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static MessageUserGroupSoap[][] toSoapModels(
		MessageUserGroup[][] models) {
		MessageUserGroupSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new MessageUserGroupSoap[models.length][models[0].length];
		}
		else {
			soapModels = new MessageUserGroupSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static MessageUserGroupSoap[] toSoapModels(
		List<MessageUserGroup> models) {
		List<MessageUserGroupSoap> soapModels = new ArrayList<MessageUserGroupSoap>(models.size());

		for (MessageUserGroup model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new MessageUserGroupSoap[soapModels.size()]);
	}

	public MessageUserGroupSoap() {
	}

	public long getPrimaryKey() {
		return _pid;
	}

	public void setPrimaryKey(long pk) {
		setPid(pk);
	}

	public long getPid() {
		return _pid;
	}

	public void setPid(long pid) {
		_pid = pid;
	}

	public long getMessageid() {
		return _messageid;
	}

	public void setMessageid(long messageid) {
		_messageid = messageid;
	}

	public boolean getIsgroup() {
		return _isgroup;
	}

	public boolean isIsgroup() {
		return _isgroup;
	}

	public void setIsgroup(boolean isgroup) {
		_isgroup = isgroup;
	}

	public String getUserorgrp_name() {
		return _userorgrp_name;
	}

	public void setUserorgrp_name(String userorgrp_name) {
		_userorgrp_name = userorgrp_name;
	}

	public long getUserorgrp_id() {
		return _userorgrp_id;
	}

	public void setUserorgrp_id(long userorgrp_id) {
		_userorgrp_id = userorgrp_id;
	}

	public long getCreatedbyuserid() {
		return _createdbyuserid;
	}

	public void setCreatedbyuserid(long createdbyuserid) {
		_createdbyuserid = createdbyuserid;
	}

	private long _pid;
	private long _messageid;
	private boolean _isgroup;
	private String _userorgrp_name;
	private long _userorgrp_id;
	private long _createdbyuserid;
}