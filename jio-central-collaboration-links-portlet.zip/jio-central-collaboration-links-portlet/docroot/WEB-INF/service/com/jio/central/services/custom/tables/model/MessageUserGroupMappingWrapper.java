/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link MessageUserGroupMapping}.
 * </p>
 *
 * @author dewang.patel
 * @see MessageUserGroupMapping
 * @generated
 */
public class MessageUserGroupMappingWrapper implements MessageUserGroupMapping,
	ModelWrapper<MessageUserGroupMapping> {
	public MessageUserGroupMappingWrapper(
		MessageUserGroupMapping messageUserGroupMapping) {
		_messageUserGroupMapping = messageUserGroupMapping;
	}

	@Override
	public Class<?> getModelClass() {
		return MessageUserGroupMapping.class;
	}

	@Override
	public String getModelClassName() {
		return MessageUserGroupMapping.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("message_relationid", getMessage_relationid());
		attributes.put("messagepid", getMessagepid());
		attributes.put("cust_attributeid", getCust_attributeid());
		attributes.put("createdbyid", getCreatedbyid());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long message_relationid = (Long)attributes.get("message_relationid");

		if (message_relationid != null) {
			setMessage_relationid(message_relationid);
		}

		Long messagepid = (Long)attributes.get("messagepid");

		if (messagepid != null) {
			setMessagepid(messagepid);
		}

		Long cust_attributeid = (Long)attributes.get("cust_attributeid");

		if (cust_attributeid != null) {
			setCust_attributeid(cust_attributeid);
		}

		Long createdbyid = (Long)attributes.get("createdbyid");

		if (createdbyid != null) {
			setCreatedbyid(createdbyid);
		}
	}

	/**
	* Returns the primary key of this message user group mapping.
	*
	* @return the primary key of this message user group mapping
	*/
	@Override
	public long getPrimaryKey() {
		return _messageUserGroupMapping.getPrimaryKey();
	}

	/**
	* Sets the primary key of this message user group mapping.
	*
	* @param primaryKey the primary key of this message user group mapping
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_messageUserGroupMapping.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the message_relationid of this message user group mapping.
	*
	* @return the message_relationid of this message user group mapping
	*/
	@Override
	public long getMessage_relationid() {
		return _messageUserGroupMapping.getMessage_relationid();
	}

	/**
	* Sets the message_relationid of this message user group mapping.
	*
	* @param message_relationid the message_relationid of this message user group mapping
	*/
	@Override
	public void setMessage_relationid(long message_relationid) {
		_messageUserGroupMapping.setMessage_relationid(message_relationid);
	}

	/**
	* Returns the messagepid of this message user group mapping.
	*
	* @return the messagepid of this message user group mapping
	*/
	@Override
	public long getMessagepid() {
		return _messageUserGroupMapping.getMessagepid();
	}

	/**
	* Sets the messagepid of this message user group mapping.
	*
	* @param messagepid the messagepid of this message user group mapping
	*/
	@Override
	public void setMessagepid(long messagepid) {
		_messageUserGroupMapping.setMessagepid(messagepid);
	}

	/**
	* Returns the cust_attributeid of this message user group mapping.
	*
	* @return the cust_attributeid of this message user group mapping
	*/
	@Override
	public long getCust_attributeid() {
		return _messageUserGroupMapping.getCust_attributeid();
	}

	/**
	* Sets the cust_attributeid of this message user group mapping.
	*
	* @param cust_attributeid the cust_attributeid of this message user group mapping
	*/
	@Override
	public void setCust_attributeid(long cust_attributeid) {
		_messageUserGroupMapping.setCust_attributeid(cust_attributeid);
	}

	/**
	* Returns the createdbyid of this message user group mapping.
	*
	* @return the createdbyid of this message user group mapping
	*/
	@Override
	public long getCreatedbyid() {
		return _messageUserGroupMapping.getCreatedbyid();
	}

	/**
	* Sets the createdbyid of this message user group mapping.
	*
	* @param createdbyid the createdbyid of this message user group mapping
	*/
	@Override
	public void setCreatedbyid(long createdbyid) {
		_messageUserGroupMapping.setCreatedbyid(createdbyid);
	}

	@Override
	public boolean isNew() {
		return _messageUserGroupMapping.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_messageUserGroupMapping.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _messageUserGroupMapping.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_messageUserGroupMapping.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _messageUserGroupMapping.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _messageUserGroupMapping.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_messageUserGroupMapping.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _messageUserGroupMapping.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_messageUserGroupMapping.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_messageUserGroupMapping.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_messageUserGroupMapping.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new MessageUserGroupMappingWrapper((MessageUserGroupMapping)_messageUserGroupMapping.clone());
	}

	@Override
	public int compareTo(
		com.jio.central.services.custom.tables.model.MessageUserGroupMapping messageUserGroupMapping) {
		return _messageUserGroupMapping.compareTo(messageUserGroupMapping);
	}

	@Override
	public int hashCode() {
		return _messageUserGroupMapping.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jio.central.services.custom.tables.model.MessageUserGroupMapping> toCacheModel() {
		return _messageUserGroupMapping.toCacheModel();
	}

	@Override
	public com.jio.central.services.custom.tables.model.MessageUserGroupMapping toEscapedModel() {
		return new MessageUserGroupMappingWrapper(_messageUserGroupMapping.toEscapedModel());
	}

	@Override
	public com.jio.central.services.custom.tables.model.MessageUserGroupMapping toUnescapedModel() {
		return new MessageUserGroupMappingWrapper(_messageUserGroupMapping.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _messageUserGroupMapping.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _messageUserGroupMapping.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_messageUserGroupMapping.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof MessageUserGroupMappingWrapper)) {
			return false;
		}

		MessageUserGroupMappingWrapper messageUserGroupMappingWrapper = (MessageUserGroupMappingWrapper)obj;

		if (Validator.equals(_messageUserGroupMapping,
					messageUserGroupMappingWrapper._messageUserGroupMapping)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public MessageUserGroupMapping getWrappedMessageUserGroupMapping() {
		return _messageUserGroupMapping;
	}

	@Override
	public MessageUserGroupMapping getWrappedModel() {
		return _messageUserGroupMapping;
	}

	@Override
	public void resetOriginalValues() {
		_messageUserGroupMapping.resetOriginalValues();
	}

	private MessageUserGroupMapping _messageUserGroupMapping;
}