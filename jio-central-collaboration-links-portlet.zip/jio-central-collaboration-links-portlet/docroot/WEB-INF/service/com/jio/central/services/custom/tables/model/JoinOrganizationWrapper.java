/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link JoinOrganization}.
 * </p>
 *
 * @author dewang.patel
 * @see JoinOrganization
 * @generated
 */
public class JoinOrganizationWrapper implements JoinOrganization,
	ModelWrapper<JoinOrganization> {
	public JoinOrganizationWrapper(JoinOrganization joinOrganization) {
		_joinOrganization = joinOrganization;
	}

	@Override
	public Class<?> getModelClass() {
		return JoinOrganization.class;
	}

	@Override
	public String getModelClassName() {
		return JoinOrganization.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("joinOrganizationId", getJoinOrganizationId());
		attributes.put("joinOrganizationName", getJoinOrganizationName());
		attributes.put("description", getDescription());
		attributes.put("joinOrganizationStatus", getJoinOrganizationStatus());
		attributes.put("statusByUserId", getStatusByUserId());
		attributes.put("statusDate", getStatusDate());
		attributes.put("companyId", getCompanyId());
		attributes.put("groupId", getGroupId());
		attributes.put("userId", getUserId());
		attributes.put("organizaId", getOrganizaId());
		attributes.put("createDate", getCreateDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long joinOrganizationId = (Long)attributes.get("joinOrganizationId");

		if (joinOrganizationId != null) {
			setJoinOrganizationId(joinOrganizationId);
		}

		String joinOrganizationName = (String)attributes.get(
				"joinOrganizationName");

		if (joinOrganizationName != null) {
			setJoinOrganizationName(joinOrganizationName);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}

		Integer joinOrganizationStatus = (Integer)attributes.get(
				"joinOrganizationStatus");

		if (joinOrganizationStatus != null) {
			setJoinOrganizationStatus(joinOrganizationStatus);
		}

		Long statusByUserId = (Long)attributes.get("statusByUserId");

		if (statusByUserId != null) {
			setStatusByUserId(statusByUserId);
		}

		Date statusDate = (Date)attributes.get("statusDate");

		if (statusDate != null) {
			setStatusDate(statusDate);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		Long organizaId = (Long)attributes.get("organizaId");

		if (organizaId != null) {
			setOrganizaId(organizaId);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}
	}

	/**
	* Returns the primary key of this join organization.
	*
	* @return the primary key of this join organization
	*/
	@Override
	public long getPrimaryKey() {
		return _joinOrganization.getPrimaryKey();
	}

	/**
	* Sets the primary key of this join organization.
	*
	* @param primaryKey the primary key of this join organization
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_joinOrganization.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the join organization ID of this join organization.
	*
	* @return the join organization ID of this join organization
	*/
	@Override
	public long getJoinOrganizationId() {
		return _joinOrganization.getJoinOrganizationId();
	}

	/**
	* Sets the join organization ID of this join organization.
	*
	* @param joinOrganizationId the join organization ID of this join organization
	*/
	@Override
	public void setJoinOrganizationId(long joinOrganizationId) {
		_joinOrganization.setJoinOrganizationId(joinOrganizationId);
	}

	/**
	* Returns the join organization name of this join organization.
	*
	* @return the join organization name of this join organization
	*/
	@Override
	public java.lang.String getJoinOrganizationName() {
		return _joinOrganization.getJoinOrganizationName();
	}

	/**
	* Sets the join organization name of this join organization.
	*
	* @param joinOrganizationName the join organization name of this join organization
	*/
	@Override
	public void setJoinOrganizationName(java.lang.String joinOrganizationName) {
		_joinOrganization.setJoinOrganizationName(joinOrganizationName);
	}

	/**
	* Returns the description of this join organization.
	*
	* @return the description of this join organization
	*/
	@Override
	public java.lang.String getDescription() {
		return _joinOrganization.getDescription();
	}

	/**
	* Sets the description of this join organization.
	*
	* @param description the description of this join organization
	*/
	@Override
	public void setDescription(java.lang.String description) {
		_joinOrganization.setDescription(description);
	}

	/**
	* Returns the join organization status of this join organization.
	*
	* @return the join organization status of this join organization
	*/
	@Override
	public int getJoinOrganizationStatus() {
		return _joinOrganization.getJoinOrganizationStatus();
	}

	/**
	* Sets the join organization status of this join organization.
	*
	* @param joinOrganizationStatus the join organization status of this join organization
	*/
	@Override
	public void setJoinOrganizationStatus(int joinOrganizationStatus) {
		_joinOrganization.setJoinOrganizationStatus(joinOrganizationStatus);
	}

	/**
	* Returns the status by user ID of this join organization.
	*
	* @return the status by user ID of this join organization
	*/
	@Override
	public long getStatusByUserId() {
		return _joinOrganization.getStatusByUserId();
	}

	/**
	* Sets the status by user ID of this join organization.
	*
	* @param statusByUserId the status by user ID of this join organization
	*/
	@Override
	public void setStatusByUserId(long statusByUserId) {
		_joinOrganization.setStatusByUserId(statusByUserId);
	}

	/**
	* Returns the status by user uuid of this join organization.
	*
	* @return the status by user uuid of this join organization
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getStatusByUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _joinOrganization.getStatusByUserUuid();
	}

	/**
	* Sets the status by user uuid of this join organization.
	*
	* @param statusByUserUuid the status by user uuid of this join organization
	*/
	@Override
	public void setStatusByUserUuid(java.lang.String statusByUserUuid) {
		_joinOrganization.setStatusByUserUuid(statusByUserUuid);
	}

	/**
	* Returns the status date of this join organization.
	*
	* @return the status date of this join organization
	*/
	@Override
	public java.util.Date getStatusDate() {
		return _joinOrganization.getStatusDate();
	}

	/**
	* Sets the status date of this join organization.
	*
	* @param statusDate the status date of this join organization
	*/
	@Override
	public void setStatusDate(java.util.Date statusDate) {
		_joinOrganization.setStatusDate(statusDate);
	}

	/**
	* Returns the company ID of this join organization.
	*
	* @return the company ID of this join organization
	*/
	@Override
	public long getCompanyId() {
		return _joinOrganization.getCompanyId();
	}

	/**
	* Sets the company ID of this join organization.
	*
	* @param companyId the company ID of this join organization
	*/
	@Override
	public void setCompanyId(long companyId) {
		_joinOrganization.setCompanyId(companyId);
	}

	/**
	* Returns the group ID of this join organization.
	*
	* @return the group ID of this join organization
	*/
	@Override
	public long getGroupId() {
		return _joinOrganization.getGroupId();
	}

	/**
	* Sets the group ID of this join organization.
	*
	* @param groupId the group ID of this join organization
	*/
	@Override
	public void setGroupId(long groupId) {
		_joinOrganization.setGroupId(groupId);
	}

	/**
	* Returns the user ID of this join organization.
	*
	* @return the user ID of this join organization
	*/
	@Override
	public long getUserId() {
		return _joinOrganization.getUserId();
	}

	/**
	* Sets the user ID of this join organization.
	*
	* @param userId the user ID of this join organization
	*/
	@Override
	public void setUserId(long userId) {
		_joinOrganization.setUserId(userId);
	}

	/**
	* Returns the user uuid of this join organization.
	*
	* @return the user uuid of this join organization
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _joinOrganization.getUserUuid();
	}

	/**
	* Sets the user uuid of this join organization.
	*
	* @param userUuid the user uuid of this join organization
	*/
	@Override
	public void setUserUuid(java.lang.String userUuid) {
		_joinOrganization.setUserUuid(userUuid);
	}

	/**
	* Returns the organiza ID of this join organization.
	*
	* @return the organiza ID of this join organization
	*/
	@Override
	public long getOrganizaId() {
		return _joinOrganization.getOrganizaId();
	}

	/**
	* Sets the organiza ID of this join organization.
	*
	* @param organizaId the organiza ID of this join organization
	*/
	@Override
	public void setOrganizaId(long organizaId) {
		_joinOrganization.setOrganizaId(organizaId);
	}

	/**
	* Returns the create date of this join organization.
	*
	* @return the create date of this join organization
	*/
	@Override
	public java.util.Date getCreateDate() {
		return _joinOrganization.getCreateDate();
	}

	/**
	* Sets the create date of this join organization.
	*
	* @param createDate the create date of this join organization
	*/
	@Override
	public void setCreateDate(java.util.Date createDate) {
		_joinOrganization.setCreateDate(createDate);
	}

	@Override
	public boolean isNew() {
		return _joinOrganization.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_joinOrganization.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _joinOrganization.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_joinOrganization.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _joinOrganization.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _joinOrganization.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_joinOrganization.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _joinOrganization.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_joinOrganization.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_joinOrganization.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_joinOrganization.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new JoinOrganizationWrapper((JoinOrganization)_joinOrganization.clone());
	}

	@Override
	public int compareTo(
		com.jio.central.services.custom.tables.model.JoinOrganization joinOrganization) {
		return _joinOrganization.compareTo(joinOrganization);
	}

	@Override
	public int hashCode() {
		return _joinOrganization.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jio.central.services.custom.tables.model.JoinOrganization> toCacheModel() {
		return _joinOrganization.toCacheModel();
	}

	@Override
	public com.jio.central.services.custom.tables.model.JoinOrganization toEscapedModel() {
		return new JoinOrganizationWrapper(_joinOrganization.toEscapedModel());
	}

	@Override
	public com.jio.central.services.custom.tables.model.JoinOrganization toUnescapedModel() {
		return new JoinOrganizationWrapper(_joinOrganization.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _joinOrganization.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _joinOrganization.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_joinOrganization.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof JoinOrganizationWrapper)) {
			return false;
		}

		JoinOrganizationWrapper joinOrganizationWrapper = (JoinOrganizationWrapper)obj;

		if (Validator.equals(_joinOrganization,
					joinOrganizationWrapper._joinOrganization)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public JoinOrganization getWrappedJoinOrganization() {
		return _joinOrganization;
	}

	@Override
	public JoinOrganization getWrappedModel() {
		return _joinOrganization;
	}

	@Override
	public void resetOriginalValues() {
		_joinOrganization.resetOriginalValues();
	}

	private JoinOrganization _joinOrganization;
}