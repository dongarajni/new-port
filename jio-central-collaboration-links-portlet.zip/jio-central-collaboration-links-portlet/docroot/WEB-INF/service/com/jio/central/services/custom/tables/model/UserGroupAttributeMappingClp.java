/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.model;

import com.jio.central.services.custom.tables.service.ClpSerializer;
import com.jio.central.services.custom.tables.service.UserGroupAttributeMappingLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author dewang.patel
 */
public class UserGroupAttributeMappingClp extends BaseModelImpl<UserGroupAttributeMapping>
	implements UserGroupAttributeMapping {
	public UserGroupAttributeMappingClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return UserGroupAttributeMapping.class;
	}

	@Override
	public String getModelClassName() {
		return UserGroupAttributeMapping.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _collaboration_usergroupid;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setCollaboration_usergroupid(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _collaboration_usergroupid;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("collaboration_usergroupid",
			getCollaboration_usergroupid());
		attributes.put("classpk", getClasspk());
		attributes.put("user_group_name", getUser_group_name());
		attributes.put("isgroup", getIsgroup());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long collaboration_usergroupid = (Long)attributes.get(
				"collaboration_usergroupid");

		if (collaboration_usergroupid != null) {
			setCollaboration_usergroupid(collaboration_usergroupid);
		}

		Long classpk = (Long)attributes.get("classpk");

		if (classpk != null) {
			setClasspk(classpk);
		}

		String user_group_name = (String)attributes.get("user_group_name");

		if (user_group_name != null) {
			setUser_group_name(user_group_name);
		}

		Boolean isgroup = (Boolean)attributes.get("isgroup");

		if (isgroup != null) {
			setIsgroup(isgroup);
		}
	}

	@Override
	public long getCollaboration_usergroupid() {
		return _collaboration_usergroupid;
	}

	@Override
	public void setCollaboration_usergroupid(long collaboration_usergroupid) {
		_collaboration_usergroupid = collaboration_usergroupid;

		if (_userGroupAttributeMappingRemoteModel != null) {
			try {
				Class<?> clazz = _userGroupAttributeMappingRemoteModel.getClass();

				Method method = clazz.getMethod("setCollaboration_usergroupid",
						long.class);

				method.invoke(_userGroupAttributeMappingRemoteModel,
					collaboration_usergroupid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getClasspk() {
		return _classpk;
	}

	@Override
	public void setClasspk(long classpk) {
		_classpk = classpk;

		if (_userGroupAttributeMappingRemoteModel != null) {
			try {
				Class<?> clazz = _userGroupAttributeMappingRemoteModel.getClass();

				Method method = clazz.getMethod("setClasspk", long.class);

				method.invoke(_userGroupAttributeMappingRemoteModel, classpk);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUser_group_name() {
		return _user_group_name;
	}

	@Override
	public void setUser_group_name(String user_group_name) {
		_user_group_name = user_group_name;

		if (_userGroupAttributeMappingRemoteModel != null) {
			try {
				Class<?> clazz = _userGroupAttributeMappingRemoteModel.getClass();

				Method method = clazz.getMethod("setUser_group_name",
						String.class);

				method.invoke(_userGroupAttributeMappingRemoteModel,
					user_group_name);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public boolean getIsgroup() {
		return _isgroup;
	}

	@Override
	public boolean isIsgroup() {
		return _isgroup;
	}

	@Override
	public void setIsgroup(boolean isgroup) {
		_isgroup = isgroup;

		if (_userGroupAttributeMappingRemoteModel != null) {
			try {
				Class<?> clazz = _userGroupAttributeMappingRemoteModel.getClass();

				Method method = clazz.getMethod("setIsgroup", boolean.class);

				method.invoke(_userGroupAttributeMappingRemoteModel, isgroup);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getUserGroupAttributeMappingRemoteModel() {
		return _userGroupAttributeMappingRemoteModel;
	}

	public void setUserGroupAttributeMappingRemoteModel(
		BaseModel<?> userGroupAttributeMappingRemoteModel) {
		_userGroupAttributeMappingRemoteModel = userGroupAttributeMappingRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _userGroupAttributeMappingRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_userGroupAttributeMappingRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			UserGroupAttributeMappingLocalServiceUtil.addUserGroupAttributeMapping(this);
		}
		else {
			UserGroupAttributeMappingLocalServiceUtil.updateUserGroupAttributeMapping(this);
		}
	}

	@Override
	public UserGroupAttributeMapping toEscapedModel() {
		return (UserGroupAttributeMapping)ProxyUtil.newProxyInstance(UserGroupAttributeMapping.class.getClassLoader(),
			new Class[] { UserGroupAttributeMapping.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		UserGroupAttributeMappingClp clone = new UserGroupAttributeMappingClp();

		clone.setCollaboration_usergroupid(getCollaboration_usergroupid());
		clone.setClasspk(getClasspk());
		clone.setUser_group_name(getUser_group_name());
		clone.setIsgroup(getIsgroup());

		return clone;
	}

	@Override
	public int compareTo(UserGroupAttributeMapping userGroupAttributeMapping) {
		long primaryKey = userGroupAttributeMapping.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof UserGroupAttributeMappingClp)) {
			return false;
		}

		UserGroupAttributeMappingClp userGroupAttributeMapping = (UserGroupAttributeMappingClp)obj;

		long primaryKey = userGroupAttributeMapping.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(9);

		sb.append("{collaboration_usergroupid=");
		sb.append(getCollaboration_usergroupid());
		sb.append(", classpk=");
		sb.append(getClasspk());
		sb.append(", user_group_name=");
		sb.append(getUser_group_name());
		sb.append(", isgroup=");
		sb.append(getIsgroup());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(16);

		sb.append("<model><model-name>");
		sb.append(
			"com.jio.central.services.custom.tables.model.UserGroupAttributeMapping");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>collaboration_usergroupid</column-name><column-value><![CDATA[");
		sb.append(getCollaboration_usergroupid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>classpk</column-name><column-value><![CDATA[");
		sb.append(getClasspk());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>user_group_name</column-name><column-value><![CDATA[");
		sb.append(getUser_group_name());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>isgroup</column-name><column-value><![CDATA[");
		sb.append(getIsgroup());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _collaboration_usergroupid;
	private long _classpk;
	private String _user_group_name;
	private boolean _isgroup;
	private BaseModel<?> _userGroupAttributeMappingRemoteModel;
	private Class<?> _clpSerializerClass = com.jio.central.services.custom.tables.service.ClpSerializer.class;
}