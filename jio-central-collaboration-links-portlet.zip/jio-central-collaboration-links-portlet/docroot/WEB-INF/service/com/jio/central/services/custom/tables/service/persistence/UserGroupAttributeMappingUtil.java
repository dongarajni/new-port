/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.service.persistence;

import com.jio.central.services.custom.tables.model.UserGroupAttributeMapping;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import java.util.List;

/**
 * The persistence utility for the user group attribute mapping service. This utility wraps {@link UserGroupAttributeMappingPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author dewang.patel
 * @see UserGroupAttributeMappingPersistence
 * @see UserGroupAttributeMappingPersistenceImpl
 * @generated
 */
public class UserGroupAttributeMappingUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(
		UserGroupAttributeMapping userGroupAttributeMapping) {
		getPersistence().clearCache(userGroupAttributeMapping);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<UserGroupAttributeMapping> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<UserGroupAttributeMapping> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<UserGroupAttributeMapping> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static UserGroupAttributeMapping update(
		UserGroupAttributeMapping userGroupAttributeMapping)
		throws SystemException {
		return getPersistence().update(userGroupAttributeMapping);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static UserGroupAttributeMapping update(
		UserGroupAttributeMapping userGroupAttributeMapping,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(userGroupAttributeMapping, serviceContext);
	}

	/**
	* Caches the user group attribute mapping in the entity cache if it is enabled.
	*
	* @param userGroupAttributeMapping the user group attribute mapping
	*/
	public static void cacheResult(
		com.jio.central.services.custom.tables.model.UserGroupAttributeMapping userGroupAttributeMapping) {
		getPersistence().cacheResult(userGroupAttributeMapping);
	}

	/**
	* Caches the user group attribute mappings in the entity cache if it is enabled.
	*
	* @param userGroupAttributeMappings the user group attribute mappings
	*/
	public static void cacheResult(
		java.util.List<com.jio.central.services.custom.tables.model.UserGroupAttributeMapping> userGroupAttributeMappings) {
		getPersistence().cacheResult(userGroupAttributeMappings);
	}

	/**
	* Creates a new user group attribute mapping with the primary key. Does not add the user group attribute mapping to the database.
	*
	* @param collaboration_usergroupid the primary key for the new user group attribute mapping
	* @return the new user group attribute mapping
	*/
	public static com.jio.central.services.custom.tables.model.UserGroupAttributeMapping create(
		long collaboration_usergroupid) {
		return getPersistence().create(collaboration_usergroupid);
	}

	/**
	* Removes the user group attribute mapping with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param collaboration_usergroupid the primary key of the user group attribute mapping
	* @return the user group attribute mapping that was removed
	* @throws com.jio.central.services.custom.tables.NoSuchUserGroupAttributeMappingException if a user group attribute mapping with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.central.services.custom.tables.model.UserGroupAttributeMapping remove(
		long collaboration_usergroupid)
		throws com.jio.central.services.custom.tables.NoSuchUserGroupAttributeMappingException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().remove(collaboration_usergroupid);
	}

	public static com.jio.central.services.custom.tables.model.UserGroupAttributeMapping updateImpl(
		com.jio.central.services.custom.tables.model.UserGroupAttributeMapping userGroupAttributeMapping)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(userGroupAttributeMapping);
	}

	/**
	* Returns the user group attribute mapping with the primary key or throws a {@link com.jio.central.services.custom.tables.NoSuchUserGroupAttributeMappingException} if it could not be found.
	*
	* @param collaboration_usergroupid the primary key of the user group attribute mapping
	* @return the user group attribute mapping
	* @throws com.jio.central.services.custom.tables.NoSuchUserGroupAttributeMappingException if a user group attribute mapping with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.central.services.custom.tables.model.UserGroupAttributeMapping findByPrimaryKey(
		long collaboration_usergroupid)
		throws com.jio.central.services.custom.tables.NoSuchUserGroupAttributeMappingException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPrimaryKey(collaboration_usergroupid);
	}

	/**
	* Returns the user group attribute mapping with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param collaboration_usergroupid the primary key of the user group attribute mapping
	* @return the user group attribute mapping, or <code>null</code> if a user group attribute mapping with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.central.services.custom.tables.model.UserGroupAttributeMapping fetchByPrimaryKey(
		long collaboration_usergroupid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(collaboration_usergroupid);
	}

	/**
	* Returns all the user group attribute mappings.
	*
	* @return the user group attribute mappings
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.central.services.custom.tables.model.UserGroupAttributeMapping> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the user group attribute mappings.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.UserGroupAttributeMappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of user group attribute mappings
	* @param end the upper bound of the range of user group attribute mappings (not inclusive)
	* @return the range of user group attribute mappings
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.central.services.custom.tables.model.UserGroupAttributeMapping> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the user group attribute mappings.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.UserGroupAttributeMappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of user group attribute mappings
	* @param end the upper bound of the range of user group attribute mappings (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of user group attribute mappings
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.central.services.custom.tables.model.UserGroupAttributeMapping> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the user group attribute mappings from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of user group attribute mappings.
	*
	* @return the number of user group attribute mappings
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static UserGroupAttributeMappingPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (UserGroupAttributeMappingPersistence)PortletBeanLocatorUtil.locate(com.jio.central.services.custom.tables.service.ClpSerializer.getServletContextName(),
					UserGroupAttributeMappingPersistence.class.getName());

			ReferenceRegistry.registerReference(UserGroupAttributeMappingUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(UserGroupAttributeMappingPersistence persistence) {
	}

	private static UserGroupAttributeMappingPersistence _persistence;
}