/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.model;

import com.jio.central.services.custom.tables.service.ClpSerializer;
import com.jio.central.services.custom.tables.service.MessageUserGroupLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author dewang.patel
 */
public class MessageUserGroupClp extends BaseModelImpl<MessageUserGroup>
	implements MessageUserGroup {
	public MessageUserGroupClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return MessageUserGroup.class;
	}

	@Override
	public String getModelClassName() {
		return MessageUserGroup.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _pid;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setPid(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _pid;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("pid", getPid());
		attributes.put("messageid", getMessageid());
		attributes.put("isgroup", getIsgroup());
		attributes.put("userorgrp_name", getUserorgrp_name());
		attributes.put("userorgrp_id", getUserorgrp_id());
		attributes.put("createdbyuserid", getCreatedbyuserid());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long pid = (Long)attributes.get("pid");

		if (pid != null) {
			setPid(pid);
		}

		Long messageid = (Long)attributes.get("messageid");

		if (messageid != null) {
			setMessageid(messageid);
		}

		Boolean isgroup = (Boolean)attributes.get("isgroup");

		if (isgroup != null) {
			setIsgroup(isgroup);
		}

		String userorgrp_name = (String)attributes.get("userorgrp_name");

		if (userorgrp_name != null) {
			setUserorgrp_name(userorgrp_name);
		}

		Long userorgrp_id = (Long)attributes.get("userorgrp_id");

		if (userorgrp_id != null) {
			setUserorgrp_id(userorgrp_id);
		}

		Long createdbyuserid = (Long)attributes.get("createdbyuserid");

		if (createdbyuserid != null) {
			setCreatedbyuserid(createdbyuserid);
		}
	}

	@Override
	public long getPid() {
		return _pid;
	}

	@Override
	public void setPid(long pid) {
		_pid = pid;

		if (_messageUserGroupRemoteModel != null) {
			try {
				Class<?> clazz = _messageUserGroupRemoteModel.getClass();

				Method method = clazz.getMethod("setPid", long.class);

				method.invoke(_messageUserGroupRemoteModel, pid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getMessageid() {
		return _messageid;
	}

	@Override
	public void setMessageid(long messageid) {
		_messageid = messageid;

		if (_messageUserGroupRemoteModel != null) {
			try {
				Class<?> clazz = _messageUserGroupRemoteModel.getClass();

				Method method = clazz.getMethod("setMessageid", long.class);

				method.invoke(_messageUserGroupRemoteModel, messageid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public boolean getIsgroup() {
		return _isgroup;
	}

	@Override
	public boolean isIsgroup() {
		return _isgroup;
	}

	@Override
	public void setIsgroup(boolean isgroup) {
		_isgroup = isgroup;

		if (_messageUserGroupRemoteModel != null) {
			try {
				Class<?> clazz = _messageUserGroupRemoteModel.getClass();

				Method method = clazz.getMethod("setIsgroup", boolean.class);

				method.invoke(_messageUserGroupRemoteModel, isgroup);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUserorgrp_name() {
		return _userorgrp_name;
	}

	@Override
	public void setUserorgrp_name(String userorgrp_name) {
		_userorgrp_name = userorgrp_name;

		if (_messageUserGroupRemoteModel != null) {
			try {
				Class<?> clazz = _messageUserGroupRemoteModel.getClass();

				Method method = clazz.getMethod("setUserorgrp_name",
						String.class);

				method.invoke(_messageUserGroupRemoteModel, userorgrp_name);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getUserorgrp_id() {
		return _userorgrp_id;
	}

	@Override
	public void setUserorgrp_id(long userorgrp_id) {
		_userorgrp_id = userorgrp_id;

		if (_messageUserGroupRemoteModel != null) {
			try {
				Class<?> clazz = _messageUserGroupRemoteModel.getClass();

				Method method = clazz.getMethod("setUserorgrp_id", long.class);

				method.invoke(_messageUserGroupRemoteModel, userorgrp_id);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getCreatedbyuserid() {
		return _createdbyuserid;
	}

	@Override
	public void setCreatedbyuserid(long createdbyuserid) {
		_createdbyuserid = createdbyuserid;

		if (_messageUserGroupRemoteModel != null) {
			try {
				Class<?> clazz = _messageUserGroupRemoteModel.getClass();

				Method method = clazz.getMethod("setCreatedbyuserid", long.class);

				method.invoke(_messageUserGroupRemoteModel, createdbyuserid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getMessageUserGroupRemoteModel() {
		return _messageUserGroupRemoteModel;
	}

	public void setMessageUserGroupRemoteModel(
		BaseModel<?> messageUserGroupRemoteModel) {
		_messageUserGroupRemoteModel = messageUserGroupRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _messageUserGroupRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_messageUserGroupRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			MessageUserGroupLocalServiceUtil.addMessageUserGroup(this);
		}
		else {
			MessageUserGroupLocalServiceUtil.updateMessageUserGroup(this);
		}
	}

	@Override
	public MessageUserGroup toEscapedModel() {
		return (MessageUserGroup)ProxyUtil.newProxyInstance(MessageUserGroup.class.getClassLoader(),
			new Class[] { MessageUserGroup.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		MessageUserGroupClp clone = new MessageUserGroupClp();

		clone.setPid(getPid());
		clone.setMessageid(getMessageid());
		clone.setIsgroup(getIsgroup());
		clone.setUserorgrp_name(getUserorgrp_name());
		clone.setUserorgrp_id(getUserorgrp_id());
		clone.setCreatedbyuserid(getCreatedbyuserid());

		return clone;
	}

	@Override
	public int compareTo(MessageUserGroup messageUserGroup) {
		long primaryKey = messageUserGroup.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof MessageUserGroupClp)) {
			return false;
		}

		MessageUserGroupClp messageUserGroup = (MessageUserGroupClp)obj;

		long primaryKey = messageUserGroup.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{pid=");
		sb.append(getPid());
		sb.append(", messageid=");
		sb.append(getMessageid());
		sb.append(", isgroup=");
		sb.append(getIsgroup());
		sb.append(", userorgrp_name=");
		sb.append(getUserorgrp_name());
		sb.append(", userorgrp_id=");
		sb.append(getUserorgrp_id());
		sb.append(", createdbyuserid=");
		sb.append(getCreatedbyuserid());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(22);

		sb.append("<model><model-name>");
		sb.append(
			"com.jio.central.services.custom.tables.model.MessageUserGroup");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>pid</column-name><column-value><![CDATA[");
		sb.append(getPid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>messageid</column-name><column-value><![CDATA[");
		sb.append(getMessageid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>isgroup</column-name><column-value><![CDATA[");
		sb.append(getIsgroup());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userorgrp_name</column-name><column-value><![CDATA[");
		sb.append(getUserorgrp_name());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userorgrp_id</column-name><column-value><![CDATA[");
		sb.append(getUserorgrp_id());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>createdbyuserid</column-name><column-value><![CDATA[");
		sb.append(getCreatedbyuserid());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _pid;
	private long _messageid;
	private boolean _isgroup;
	private String _userorgrp_name;
	private long _userorgrp_id;
	private long _createdbyuserid;
	private BaseModel<?> _messageUserGroupRemoteModel;
	private Class<?> _clpSerializerClass = com.jio.central.services.custom.tables.service.ClpSerializer.class;
}