/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link UserGroupAttributeMapping}.
 * </p>
 *
 * @author dewang.patel
 * @see UserGroupAttributeMapping
 * @generated
 */
public class UserGroupAttributeMappingWrapper
	implements UserGroupAttributeMapping,
		ModelWrapper<UserGroupAttributeMapping> {
	public UserGroupAttributeMappingWrapper(
		UserGroupAttributeMapping userGroupAttributeMapping) {
		_userGroupAttributeMapping = userGroupAttributeMapping;
	}

	@Override
	public Class<?> getModelClass() {
		return UserGroupAttributeMapping.class;
	}

	@Override
	public String getModelClassName() {
		return UserGroupAttributeMapping.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("collaboration_usergroupid",
			getCollaboration_usergroupid());
		attributes.put("classpk", getClasspk());
		attributes.put("user_group_name", getUser_group_name());
		attributes.put("isgroup", getIsgroup());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long collaboration_usergroupid = (Long)attributes.get(
				"collaboration_usergroupid");

		if (collaboration_usergroupid != null) {
			setCollaboration_usergroupid(collaboration_usergroupid);
		}

		Long classpk = (Long)attributes.get("classpk");

		if (classpk != null) {
			setClasspk(classpk);
		}

		String user_group_name = (String)attributes.get("user_group_name");

		if (user_group_name != null) {
			setUser_group_name(user_group_name);
		}

		Boolean isgroup = (Boolean)attributes.get("isgroup");

		if (isgroup != null) {
			setIsgroup(isgroup);
		}
	}

	/**
	* Returns the primary key of this user group attribute mapping.
	*
	* @return the primary key of this user group attribute mapping
	*/
	@Override
	public long getPrimaryKey() {
		return _userGroupAttributeMapping.getPrimaryKey();
	}

	/**
	* Sets the primary key of this user group attribute mapping.
	*
	* @param primaryKey the primary key of this user group attribute mapping
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_userGroupAttributeMapping.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the collaboration_usergroupid of this user group attribute mapping.
	*
	* @return the collaboration_usergroupid of this user group attribute mapping
	*/
	@Override
	public long getCollaboration_usergroupid() {
		return _userGroupAttributeMapping.getCollaboration_usergroupid();
	}

	/**
	* Sets the collaboration_usergroupid of this user group attribute mapping.
	*
	* @param collaboration_usergroupid the collaboration_usergroupid of this user group attribute mapping
	*/
	@Override
	public void setCollaboration_usergroupid(long collaboration_usergroupid) {
		_userGroupAttributeMapping.setCollaboration_usergroupid(collaboration_usergroupid);
	}

	/**
	* Returns the classpk of this user group attribute mapping.
	*
	* @return the classpk of this user group attribute mapping
	*/
	@Override
	public long getClasspk() {
		return _userGroupAttributeMapping.getClasspk();
	}

	/**
	* Sets the classpk of this user group attribute mapping.
	*
	* @param classpk the classpk of this user group attribute mapping
	*/
	@Override
	public void setClasspk(long classpk) {
		_userGroupAttributeMapping.setClasspk(classpk);
	}

	/**
	* Returns the user_group_name of this user group attribute mapping.
	*
	* @return the user_group_name of this user group attribute mapping
	*/
	@Override
	public java.lang.String getUser_group_name() {
		return _userGroupAttributeMapping.getUser_group_name();
	}

	/**
	* Sets the user_group_name of this user group attribute mapping.
	*
	* @param user_group_name the user_group_name of this user group attribute mapping
	*/
	@Override
	public void setUser_group_name(java.lang.String user_group_name) {
		_userGroupAttributeMapping.setUser_group_name(user_group_name);
	}

	/**
	* Returns the isgroup of this user group attribute mapping.
	*
	* @return the isgroup of this user group attribute mapping
	*/
	@Override
	public boolean getIsgroup() {
		return _userGroupAttributeMapping.getIsgroup();
	}

	/**
	* Returns <code>true</code> if this user group attribute mapping is isgroup.
	*
	* @return <code>true</code> if this user group attribute mapping is isgroup; <code>false</code> otherwise
	*/
	@Override
	public boolean isIsgroup() {
		return _userGroupAttributeMapping.isIsgroup();
	}

	/**
	* Sets whether this user group attribute mapping is isgroup.
	*
	* @param isgroup the isgroup of this user group attribute mapping
	*/
	@Override
	public void setIsgroup(boolean isgroup) {
		_userGroupAttributeMapping.setIsgroup(isgroup);
	}

	@Override
	public boolean isNew() {
		return _userGroupAttributeMapping.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_userGroupAttributeMapping.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _userGroupAttributeMapping.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_userGroupAttributeMapping.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _userGroupAttributeMapping.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _userGroupAttributeMapping.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_userGroupAttributeMapping.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _userGroupAttributeMapping.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_userGroupAttributeMapping.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_userGroupAttributeMapping.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_userGroupAttributeMapping.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new UserGroupAttributeMappingWrapper((UserGroupAttributeMapping)_userGroupAttributeMapping.clone());
	}

	@Override
	public int compareTo(
		com.jio.central.services.custom.tables.model.UserGroupAttributeMapping userGroupAttributeMapping) {
		return _userGroupAttributeMapping.compareTo(userGroupAttributeMapping);
	}

	@Override
	public int hashCode() {
		return _userGroupAttributeMapping.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jio.central.services.custom.tables.model.UserGroupAttributeMapping> toCacheModel() {
		return _userGroupAttributeMapping.toCacheModel();
	}

	@Override
	public com.jio.central.services.custom.tables.model.UserGroupAttributeMapping toEscapedModel() {
		return new UserGroupAttributeMappingWrapper(_userGroupAttributeMapping.toEscapedModel());
	}

	@Override
	public com.jio.central.services.custom.tables.model.UserGroupAttributeMapping toUnescapedModel() {
		return new UserGroupAttributeMappingWrapper(_userGroupAttributeMapping.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _userGroupAttributeMapping.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _userGroupAttributeMapping.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_userGroupAttributeMapping.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof UserGroupAttributeMappingWrapper)) {
			return false;
		}

		UserGroupAttributeMappingWrapper userGroupAttributeMappingWrapper = (UserGroupAttributeMappingWrapper)obj;

		if (Validator.equals(_userGroupAttributeMapping,
					userGroupAttributeMappingWrapper._userGroupAttributeMapping)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public UserGroupAttributeMapping getWrappedUserGroupAttributeMapping() {
		return _userGroupAttributeMapping;
	}

	@Override
	public UserGroupAttributeMapping getWrappedModel() {
		return _userGroupAttributeMapping;
	}

	@Override
	public void resetOriginalValues() {
		_userGroupAttributeMapping.resetOriginalValues();
	}

	private UserGroupAttributeMapping _userGroupAttributeMapping;
}