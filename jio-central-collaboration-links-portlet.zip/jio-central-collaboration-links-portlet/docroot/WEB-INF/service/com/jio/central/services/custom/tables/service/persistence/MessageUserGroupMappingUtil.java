/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.service.persistence;

import com.jio.central.services.custom.tables.model.MessageUserGroupMapping;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import java.util.List;

/**
 * The persistence utility for the message user group mapping service. This utility wraps {@link MessageUserGroupMappingPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author dewang.patel
 * @see MessageUserGroupMappingPersistence
 * @see MessageUserGroupMappingPersistenceImpl
 * @generated
 */
public class MessageUserGroupMappingUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(
		MessageUserGroupMapping messageUserGroupMapping) {
		getPersistence().clearCache(messageUserGroupMapping);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<MessageUserGroupMapping> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<MessageUserGroupMapping> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<MessageUserGroupMapping> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static MessageUserGroupMapping update(
		MessageUserGroupMapping messageUserGroupMapping)
		throws SystemException {
		return getPersistence().update(messageUserGroupMapping);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static MessageUserGroupMapping update(
		MessageUserGroupMapping messageUserGroupMapping,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(messageUserGroupMapping, serviceContext);
	}

	/**
	* Caches the message user group mapping in the entity cache if it is enabled.
	*
	* @param messageUserGroupMapping the message user group mapping
	*/
	public static void cacheResult(
		com.jio.central.services.custom.tables.model.MessageUserGroupMapping messageUserGroupMapping) {
		getPersistence().cacheResult(messageUserGroupMapping);
	}

	/**
	* Caches the message user group mappings in the entity cache if it is enabled.
	*
	* @param messageUserGroupMappings the message user group mappings
	*/
	public static void cacheResult(
		java.util.List<com.jio.central.services.custom.tables.model.MessageUserGroupMapping> messageUserGroupMappings) {
		getPersistence().cacheResult(messageUserGroupMappings);
	}

	/**
	* Creates a new message user group mapping with the primary key. Does not add the message user group mapping to the database.
	*
	* @param message_relationid the primary key for the new message user group mapping
	* @return the new message user group mapping
	*/
	public static com.jio.central.services.custom.tables.model.MessageUserGroupMapping create(
		long message_relationid) {
		return getPersistence().create(message_relationid);
	}

	/**
	* Removes the message user group mapping with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param message_relationid the primary key of the message user group mapping
	* @return the message user group mapping that was removed
	* @throws com.jio.central.services.custom.tables.NoSuchMessageUserGroupMappingException if a message user group mapping with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.central.services.custom.tables.model.MessageUserGroupMapping remove(
		long message_relationid)
		throws com.jio.central.services.custom.tables.NoSuchMessageUserGroupMappingException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().remove(message_relationid);
	}

	public static com.jio.central.services.custom.tables.model.MessageUserGroupMapping updateImpl(
		com.jio.central.services.custom.tables.model.MessageUserGroupMapping messageUserGroupMapping)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(messageUserGroupMapping);
	}

	/**
	* Returns the message user group mapping with the primary key or throws a {@link com.jio.central.services.custom.tables.NoSuchMessageUserGroupMappingException} if it could not be found.
	*
	* @param message_relationid the primary key of the message user group mapping
	* @return the message user group mapping
	* @throws com.jio.central.services.custom.tables.NoSuchMessageUserGroupMappingException if a message user group mapping with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.central.services.custom.tables.model.MessageUserGroupMapping findByPrimaryKey(
		long message_relationid)
		throws com.jio.central.services.custom.tables.NoSuchMessageUserGroupMappingException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPrimaryKey(message_relationid);
	}

	/**
	* Returns the message user group mapping with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param message_relationid the primary key of the message user group mapping
	* @return the message user group mapping, or <code>null</code> if a message user group mapping with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.central.services.custom.tables.model.MessageUserGroupMapping fetchByPrimaryKey(
		long message_relationid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(message_relationid);
	}

	/**
	* Returns all the message user group mappings.
	*
	* @return the message user group mappings
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.central.services.custom.tables.model.MessageUserGroupMapping> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the message user group mappings.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.MessageUserGroupMappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of message user group mappings
	* @param end the upper bound of the range of message user group mappings (not inclusive)
	* @return the range of message user group mappings
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.central.services.custom.tables.model.MessageUserGroupMapping> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the message user group mappings.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.MessageUserGroupMappingModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of message user group mappings
	* @param end the upper bound of the range of message user group mappings (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of message user group mappings
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.central.services.custom.tables.model.MessageUserGroupMapping> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the message user group mappings from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of message user group mappings.
	*
	* @return the number of message user group mappings
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static MessageUserGroupMappingPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (MessageUserGroupMappingPersistence)PortletBeanLocatorUtil.locate(com.jio.central.services.custom.tables.service.ClpSerializer.getServletContextName(),
					MessageUserGroupMappingPersistence.class.getName());

			ReferenceRegistry.registerReference(MessageUserGroupMappingUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(MessageUserGroupMappingPersistence persistence) {
	}

	private static MessageUserGroupMappingPersistence _persistence;
}