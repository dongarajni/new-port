/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableLocalService;

/**
 * Provides the local service utility for MessageUserGroup. This utility wraps
 * {@link com.jio.central.services.custom.tables.service.impl.MessageUserGroupLocalServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author dewang.patel
 * @see MessageUserGroupLocalService
 * @see com.jio.central.services.custom.tables.service.base.MessageUserGroupLocalServiceBaseImpl
 * @see com.jio.central.services.custom.tables.service.impl.MessageUserGroupLocalServiceImpl
 * @generated
 */
public class MessageUserGroupLocalServiceUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to {@link com.jio.central.services.custom.tables.service.impl.MessageUserGroupLocalServiceImpl} and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	* Adds the message user group to the database. Also notifies the appropriate model listeners.
	*
	* @param messageUserGroup the message user group
	* @return the message user group that was added
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.central.services.custom.tables.model.MessageUserGroup addMessageUserGroup(
		com.jio.central.services.custom.tables.model.MessageUserGroup messageUserGroup)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().addMessageUserGroup(messageUserGroup);
	}

	/**
	* Creates a new message user group with the primary key. Does not add the message user group to the database.
	*
	* @param pid the primary key for the new message user group
	* @return the new message user group
	*/
	public static com.jio.central.services.custom.tables.model.MessageUserGroup createMessageUserGroup(
		long pid) {
		return getService().createMessageUserGroup(pid);
	}

	/**
	* Deletes the message user group with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param pid the primary key of the message user group
	* @return the message user group that was removed
	* @throws PortalException if a message user group with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.central.services.custom.tables.model.MessageUserGroup deleteMessageUserGroup(
		long pid)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteMessageUserGroup(pid);
	}

	/**
	* Deletes the message user group from the database. Also notifies the appropriate model listeners.
	*
	* @param messageUserGroup the message user group
	* @return the message user group that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.central.services.custom.tables.model.MessageUserGroup deleteMessageUserGroup(
		com.jio.central.services.custom.tables.model.MessageUserGroup messageUserGroup)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteMessageUserGroup(messageUserGroup);
	}

	public static com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.MessageUserGroupModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.MessageUserGroupModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static com.jio.central.services.custom.tables.model.MessageUserGroup fetchMessageUserGroup(
		long pid) throws com.liferay.portal.kernel.exception.SystemException {
		return getService().fetchMessageUserGroup(pid);
	}

	/**
	* Returns the message user group with the primary key.
	*
	* @param pid the primary key of the message user group
	* @return the message user group
	* @throws PortalException if a message user group with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.central.services.custom.tables.model.MessageUserGroup getMessageUserGroup(
		long pid)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getMessageUserGroup(pid);
	}

	public static com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the message user groups.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.MessageUserGroupModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of message user groups
	* @param end the upper bound of the range of message user groups (not inclusive)
	* @return the range of message user groups
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jio.central.services.custom.tables.model.MessageUserGroup> getMessageUserGroups(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getMessageUserGroups(start, end);
	}

	/**
	* Returns the number of message user groups.
	*
	* @return the number of message user groups
	* @throws SystemException if a system exception occurred
	*/
	public static int getMessageUserGroupsCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getMessageUserGroupsCount();
	}

	/**
	* Updates the message user group in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param messageUserGroup the message user group
	* @return the message user group that was updated
	* @throws SystemException if a system exception occurred
	*/
	public static com.jio.central.services.custom.tables.model.MessageUserGroup updateMessageUserGroup(
		com.jio.central.services.custom.tables.model.MessageUserGroup messageUserGroup)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().updateMessageUserGroup(messageUserGroup);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	public static java.lang.String getBeanIdentifier() {
		return getService().getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	public static void setBeanIdentifier(java.lang.String beanIdentifier) {
		getService().setBeanIdentifier(beanIdentifier);
	}

	public static java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return getService().invokeMethod(name, parameterTypes, arguments);
	}

	public static java.util.List<com.liferay.portal.model.Organization> getAllOrganizationByMessageId(
		long messageId) {
		return getService().getAllOrganizationByMessageId(messageId);
	}

	public static java.util.List<com.liferay.portal.model.User> getAllUsersByMessageId(
		long messageId) {
		return getService().getAllUsersByMessageId(messageId);
	}

	public static java.util.List<java.lang.Long> getAllMessageIdByOrg(
		java.lang.String organizationName) {
		return getService().getAllMessageIdByOrg(organizationName);
	}

	public static java.util.List<java.lang.Long> getAllMessageIdByUserId(
		long userId) {
		return getService().getAllMessageIdByUserId(userId);
	}

	public static java.util.List<java.lang.Long> getAllMessageUserGroupPid(
		long messageId, java.lang.Boolean isGroup) {
		return getService().getAllMessageUserGroupPid(messageId, isGroup);
	}

	public static java.util.List<java.lang.String> getAllMessageUserGroupNamebyMessageId(
		long messageId, java.lang.Boolean isGroup) {
		return getService()
				   .getAllMessageUserGroupNamebyMessageId(messageId, isGroup);
	}

	public static java.util.List<java.lang.Long> getAllMessageUserGroupPidbyUsrGrpName(
		java.lang.String userGroupName, java.lang.Boolean isGroup,
		java.lang.Long messageId) {
		return getService()
				   .getAllMessageUserGroupPidbyUsrGrpName(userGroupName,
			isGroup, messageId);
	}

	public static java.util.List<java.lang.Long> getAllTaggedMessagesByUserId(
		long userId) {
		return getService().getAllTaggedMessagesByUserId(userId);
	}

	public static java.util.List<java.lang.Long> getUserOrGroupIdsByMessageId(
		long messageId, boolean isGroup) {
		return getService().getUserOrGroupIdsByMessageId(messageId, isGroup);
	}

	public static void clearService() {
		_service = null;
	}

	public static MessageUserGroupLocalService getService() {
		if (_service == null) {
			InvokableLocalService invokableLocalService = (InvokableLocalService)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
					MessageUserGroupLocalService.class.getName());

			if (invokableLocalService instanceof MessageUserGroupLocalService) {
				_service = (MessageUserGroupLocalService)invokableLocalService;
			}
			else {
				_service = new MessageUserGroupLocalServiceClp(invokableLocalService);
			}

			ReferenceRegistry.registerReference(MessageUserGroupLocalServiceUtil.class,
				"_service");
		}

		return _service;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setService(MessageUserGroupLocalService service) {
	}

	private static MessageUserGroupLocalService _service;
}