create index IX_2BD40DCB on jiocentral_JoinOrganization (companyId);
create index IX_BA0B8B0D on jiocentral_JoinOrganization (groupId);
create index IX_2D5F3590 on jiocentral_JoinOrganization (groupId, joinOrganizationStatus);