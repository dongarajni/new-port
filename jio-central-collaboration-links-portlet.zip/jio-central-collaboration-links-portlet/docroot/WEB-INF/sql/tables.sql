create table jc_collaboration_message_usergroup_mapping (
	message_relationid LONG not null primary key,
	messagepid LONG,
	cust_attributeid LONG,
	createdbyid LONG
);

create table jc_collaboration_usergroup_attrmapping (
	collaboration_usergroupid LONG not null primary key,
	classpk LONG,
	user_group_name VARCHAR(75) null,
	isgroup BOOLEAN
);

create table jc_messageusergroup (
	pid LONG not null primary key,
	messageid LONG,
	isgroup BOOLEAN,
	userorgrp_name VARCHAR(75) null,
	userorgrp_id LONG,
	createdbyuserid LONG
);

create table jiocentral_JoinOrganization (
	joinOrganizationId LONG not null primary key,
	joinOrganizationName VARCHAR(75) null,
	description VARCHAR(75) null,
	joinOrganizationStatus INTEGER,
	statusByUserId LONG,
	statusDate DATE null,
	companyId LONG,
	groupId LONG,
	userId LONG,
	organizaId LONG,
	createDate DATE null
);