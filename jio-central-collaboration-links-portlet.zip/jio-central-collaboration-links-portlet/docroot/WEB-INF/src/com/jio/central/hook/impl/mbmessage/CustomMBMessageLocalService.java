package com.jio.central.hook.impl.mbmessage;

import com.jio.central.collaboration.util.ExpandoUtility;
import com.jio.central.collaboration.util.JioCentralUtil;
import com.jio.central.constants.Consts;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.io.ByteArrayFileInputStream;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageBusUtil;
import com.liferay.portal.kernel.util.FileUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.MimeTypesUtil;
import com.liferay.portal.kernel.util.ObjectValuePair;
import com.liferay.portal.kernel.util.PortalClassLoaderUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.security.auth.PrincipalException;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portlet.documentlibrary.FileExtensionException;
import com.liferay.portlet.documentlibrary.model.DLFileEntry;
import com.liferay.portlet.documentlibrary.service.DLFileEntryLocalServiceUtil;
import com.liferay.portlet.expando.model.ExpandoValue;
import com.liferay.portlet.messageboards.NoSuchMessageException;
import com.liferay.portlet.messageboards.RequiredMessageException;
import com.liferay.portlet.messageboards.model.MBMessage;
import com.liferay.portlet.messageboards.model.MBThread;
import com.liferay.portlet.messageboards.service.MBMessageLocalService;
import com.liferay.portlet.messageboards.service.MBMessageLocalServiceUtil;
import com.liferay.portlet.messageboards.service.MBMessageLocalServiceWrapper;
import com.liferay.portlet.messageboards.service.MBThreadLocalServiceUtil;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

public class CustomMBMessageLocalService extends MBMessageLocalServiceWrapper {

	private static Log LOGGER = LogFactoryUtil.getLog(CustomMBMessageLocalService.class.getName());
	
	public CustomMBMessageLocalService(
			MBMessageLocalService mbMessageLocalService) {
		super(mbMessageLocalService);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public MBMessage deleteMessage(long messageId) throws PortalException,
			SystemException {
		MBMessage message = null;
		try {
			message = MBMessageLocalServiceUtil.fetchMBMessage(messageId);
			
			if(message.isRoot()){
				
				 MBThread thread = MBThreadLocalServiceUtil.getThread(message.getThreadId());
	              if (thread.getRootMessageId() == message.getMessageId()) {                 
	              
	            	  MBThreadLocalServiceUtil.deleteThread(thread.getThreadId());
	            
	              }
	        }else if(message.isReply()){
	        	MBMessageLocalServiceUtil.deleteMessage(message);
	        }
			
       } catch (Exception e) {
    	  if(e instanceof NoSuchMessageException){
    		  	LOGGER.error("Unable to find message while deleting: "+e.getMessage());	  
    	  }
    	  if(e instanceof PrincipalException){
    		  	LOGGER.error("Principal exception, check if get method was invoked: "+e.getMessage());	  
    	  }
    	  if(e instanceof RequiredMessageException){
    		  	LOGGER.error("Post having multiple reply cannot be deleted: "+e.getMessage());	  
    	  }
    	  if(e instanceof NullPointerException){
  		  		LOGGER.error("After deleting check what needs to be return: "+e.getMessage());	  
    	  }
    	  		LOGGER.error("Error while deleting post: "+e.getMessage());
		}
	
		return message;
	}

	
	
	
	
	@Override
	public MBMessage addMessage(long userId, String userName, long groupId,
			long categoryId, String subject, String body, String format,
			List<ObjectValuePair<String, InputStream>> inputStreamOVPs,
			boolean anonymous, double priority, boolean allowPingbacks,
			ServiceContext serviceContext) throws PortalException,
			SystemException {
		
		
		MBMessage message = null;
		
	
		try {
			List<File> tempFiles = new ArrayList<File>();
			
			
			String tempBody = "";
			String sharedMessageID  = "";
			
			// get the shared Message id from body
			if(Validator.isNotNull(body) && body.contains("("))
			tempBody = body.substring(body.lastIndexOf("("), body.length());
			
			// regex as to look only for number = sharedMessageId
			 Matcher matcher = Pattern.compile(".*\\(([\\d,]+)\\)").matcher(tempBody);
		     while(matcher.find()) {
		       sharedMessageID = matcher.group(1);
		     }
		     
			
		     // Incase sharedMessageID is null that means fresh post with attachment.
			if(Validator.isNotNull(sharedMessageID) && sharedMessageID.length()>0){
				
				
			// assumption : only one document per messageID
			
			DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(DLFileEntry.class,PortalClassLoaderUtil.getClassLoader());
			dynamicQuery.add(PropertyFactoryUtil.forName("classPK").eq(Long.valueOf(sharedMessageID)));
			List<DLFileEntry> dlFileEntries = DLFileEntryLocalServiceUtil.dynamicQuery(dynamicQuery);
			
			
			
			if(Validator.isNotNull(dlFileEntries)){
				
				for(DLFileEntry itr : dlFileEntries){
					
					InputStream inputStream = DLFileEntryLocalServiceUtil.getFileAsStream(itr.getFileEntryId(), String.valueOf(itr.getVersion()));
					ObjectValuePair<String, InputStream> inputStreamOVP = null;
					
						if (inputStream != null) {
							
							if((itr.getTitle().startsWith("/"))){
								/* if user removes image from front end then in db liferay stores data as "/D-I-G-I-T-S",
								* so if we continue to share same file error will be thrown.	
								 * Incase if user removes and upload fresh doc dont do anything over it*/
								
							}else{
								
								inputStreamOVPs = new ArrayList<ObjectValuePair<String, InputStream>>();
								inputStreamOVP = new ObjectValuePair<String, InputStream>(itr.getTitle(), inputStream);
								inputStreamOVPs.add(inputStreamOVP);
							}
								
						}
				
					}
			}// end of shared post if.
			
			// Pass original message id for sharing counter increment.
			updateMessageShareCount(Long.valueOf(sharedMessageID));
			
		}

			// recover original body message
			if(Validator.isNotNull(body) && body.contains("("))
			body = recoverOriginalBody(body);

			// file validation
			//boolean allowAllFiles = GetterUtil.getBoolean(PropsUtil.get("attachment.allowed.all"),false);
			boolean isValidationIgnored = false;
			HttpServletRequest httpRequest = serviceContext.getRequest();
			
			if(Validator.isNotNull(httpRequest)){
				LOGGER.info("File validation initiated...... ");
				isValidationIgnored = checkUploadingFileContent(inputStreamOVPs, tempFiles);
			}else if(Validator.isNull(httpRequest) || "all".equalsIgnoreCase(PropsUtil.get("attachment.allowed.all"))){
				LOGGER.warn("mime type check not required...... ");
				isValidationIgnored = true;
			}
		
			
			if(!isValidationIgnored){
				LOGGER.warn("iN FreshPost File size validation result: "+isValidationIgnored);
				inputStreamOVPs = new ArrayList<ObjectValuePair<String, InputStream>>();
			}			
		
		
		} catch (Exception e) {
				LOGGER.error("Err in impl share file upload:",e);
		}
		
		
		
		
		
		message  = super.addMessage(userId, userName, groupId, categoryId, subject, body,
				format, inputStreamOVPs, anonymous, priority, allowPingbacks,
				serviceContext);

		
		
		
		try {
		
			
			// check if email feature is turned on or not
			
			if(Consts.TURN_ON_MAIL_ALERT){
			
				HttpServletRequest httpServletRequest = serviceContext.getRequest();
				
				if(Validator.isNotNull(httpServletRequest) ){
				ThemeDisplay themeDisplay=  (ThemeDisplay) httpServletRequest.getAttribute(WebKeys.THEME_DISPLAY);
		
				// prepare the message url for email body
				String message_URL = JioCentralUtil.getInstance().getMbMessageUrl(themeDisplay, message.getMessageId());
					
					// get the tagged Users/Group for mail
					String taggedGroups = (String)serviceContext.getRequest().getAttribute("mailTaggedGroup");
					String taggedUsers = (String)serviceContext.getRequest().getAttribute("mailTaggedUsers");
					
					//Message Bus implmentation
					Message messageBus = new Message();
					messageBus.put("taggedUsers",taggedUsers);
					messageBus.put("taggedGroups",taggedGroups);
					messageBus.put("message_URL",message_URL);
					messageBus.put("MbMessage",message);
					
			    	try {
			    		MessageBusUtil.sendMessage("liferay/freshpost", messageBus);
			    		LOGGER.info("Message Bus invoked for User :"+message.getUserName()+" with Message Id:"+message.getMessageId());
					} catch (Exception e2) {
						LOGGER.error("Exception in invoking message: ",e2);
					}
			    	
					
					
				}else{
					LOGGER.warn("Unable to fetch service context. Mail can't be sent.");
				}
				
			}else{
				LOGGER.info("===New post Mail alert turned off===");
			}
			
			
			
				
	
		} catch (Exception e) {
			LOGGER.error("Error while creating post mail:..."+e.getMessage());
		}
		
		
		
		
				
		return message;
	}


	/*
	 * Method gets called when Reply is pass without any file attahcments
	 * 
	 * */
	@Override
	public MBMessage addMessage(long userId, String userName, long groupId,
			long categoryId, long threadId, long parentMessageId,
			String subject, String body, String format,
			List<ObjectValuePair<String, InputStream>> inputStreamOVPs,
			boolean anonymous, double priority, boolean allowPingbacks,
			ServiceContext serviceContext) throws PortalException,
			SystemException {
		MBMessage message = null;
		// Retrieve original body contents
		body = recoverOriginalBody(body);		
		
		
		HttpServletRequest ServletRequest = serviceContext.getRequest();
		boolean isValidationIgnored = false;
		List<File> tempFiles = new ArrayList<File>();
		
		// if not null then allow file cheking, if null then ignore as it may be incoming from file migration
		if(Validator.isNotNull(ServletRequest)){
			LOGGER.info("Re:: File validation initiated...");
			isValidationIgnored =  checkUploadingFileContent(inputStreamOVPs, tempFiles);
		}else if(Validator.isNull(ServletRequest) || "all".equalsIgnoreCase(PropsUtil.get("attachment.allowed.all"))){
			LOGGER.warn("In Reply msg  File validation ignored!");
			isValidationIgnored = true;
		}
		
		// if valiadtion failed then also continue with message creation with file inputstream as null
		if(!isValidationIgnored){
			LOGGER.warn("File size validation result: "+isValidationIgnored);
			inputStreamOVPs = new ArrayList<ObjectValuePair<String, InputStream>>();
		}	
		
		
		
		message = super.addMessage(userId, userName, groupId, categoryId, threadId,
				parentMessageId, subject, body, format, inputStreamOVPs, anonymous,
				priority, allowPingbacks, serviceContext);
		
		// in reply no users/group are tagged so get the tagged users/group from parentMessage
		try {
			
			
			
			// check if email feature is turned on or not
			
			if(Consts.TURN_ON_MAIL_ALERT){
			
				//prepare link for reply mail url
				HttpServletRequest httpServletRequest = serviceContext.getRequest();
				
				if(Validator.isNotNull(httpServletRequest) && Validator.isNotNull(message)){
						ThemeDisplay themeDisplay=  (ThemeDisplay) httpServletRequest.getAttribute(WebKeys.THEME_DISPLAY);
					
						String message_URL = JioCentralUtil.getInstance().getMbMessageUrl(themeDisplay, message.getMessageId());		
						
						//Message Bus implmentation
						Message messageBus = new Message();
						messageBus.put("ReplyMbMessage",message);
						messageBus.put("ReplyMessageURL",message_URL);
						
				    	try {
				    		MessageBusUtil.sendMessage("liferay/replypost", messageBus);
				    		LOGGER.info("Message Bus invoked for Repling... User :"+message.getUserName()+" with Message Id:"+message.getMessageId());
						} catch (Exception e2) {
							LOGGER.error("Exception in invoking message: ",e2);
						}
				    	
					
				}else{
					LOGGER.info("No reply mail to be invoked by bus as either http request is null or message is null");
				}
			
			}else{
				LOGGER.info("===Reply Mail alert turned off===");
			}
			
			
		} catch (Exception e) {
			LOGGER.error("Error in Reply addMessage()"+e.getMessage());
		}
		
		return message;
		
	}
	
	
	
/*
 * Method gets called when mb messages is updated
 * 
 * */	
	@Override
	public MBMessage updateMessage(long userId, long messageId, String subject,
			String body,
			List<ObjectValuePair<String, InputStream>> inputStreamOVPs,
			List<String> existingFiles, double priority,
			boolean allowPingbacks, ServiceContext serviceContext)
			throws PortalException, SystemException {
	
		// Retrieve original body contents
		body = recoverOriginalBody(body);
		
		HttpServletRequest ServletRequest = serviceContext.getRequest();
		boolean isValidationIgnored = false;
		List<File> tempFiles = new ArrayList<File>();
		
		// if not null then allow file cheking, if null then ignore as it may be incoming from file migration
		if(Validator.isNotNull(ServletRequest)){
			isValidationIgnored =  checkUploadingFileContent(inputStreamOVPs, tempFiles);
		}else if(Validator.isNull(ServletRequest) || "all".equalsIgnoreCase(PropsUtil.get("attachment.allowed.all"))){
			LOGGER.warn("In update msg File validation ignored !");
			isValidationIgnored = true;
		}
		
		// if valiadtion failed then also continue with message creation with file inputstream as null
		if(!isValidationIgnored){
			LOGGER.warn("In update File size validation result: "+isValidationIgnored);
			inputStreamOVPs = new ArrayList<ObjectValuePair<String, InputStream>>();
		}	
		
		
		
		return super.updateMessage(userId, messageId, subject, body, inputStreamOVPs,
				existingFiles, priority, allowPingbacks, serviceContext);
	}

	
	
	
	public static boolean checkUploadingFileContent(List<ObjectValuePair<String, InputStream>> inputStreamOVPs, List<File> tempFiles) throws FileExtensionException{
		
		boolean isValidationSuccess = true;
			if (Validator.isNotNull(inputStreamOVPs) && !inputStreamOVPs.isEmpty())  {
				for(ObjectValuePair<String, InputStream> inputStreamOVP : inputStreamOVPs) {
					String fileName = inputStreamOVP.getKey();
					File tempFile = null;
					String mimeType = StringPool.BLANK;
					try {
						tempFile = FileUtil.createTempFile(inputStreamOVP.getValue());
						tempFiles.add(tempFile);
						mimeType = MimeTypesUtil.getContentType(tempFile, fileName);					
						
						// check upload file extension
						String inputFileExtn =  FileUtil.getExtension(fileName);
						String allowedExtention = PropsUtil.get("attachment.extension.allowed");
						//String allowedExtention = "pdf,doc,docx,xls,xlsx,ppt,pptx,pps,ppsx,csv,txt,mp3,mp4,jpeg,jpg,png,gif";
						
						//saperate all extention by any special char present in portal.properties file
						boolean extenFound = false;
						boolean extnCheckPoint = false;
						Pattern pattern = Pattern.compile("[^a-z0-9]", Pattern.CASE_INSENSITIVE);
					    Matcher matcher = pattern.matcher(allowedExtention);
					 
					     Set<String> charSaperator = new HashSet<String>();
					     
					      while (matcher.find()) {
					         //System.out.println("position "  + matcher.start() + ": " + allowedExtention.charAt(matcher.start()));
					         charSaperator.add( String.valueOf(allowedExtention.charAt(matcher.start())));
					      }
					     
					      if(Validator.isNotNull(charSaperator) && charSaperator.size()==1){
					    	  
					    	  int loopCounter = 0;
					    	  for(String itr : charSaperator){
					    		  extenFound = Arrays.asList(allowedExtention.split(itr)).contains(inputFileExtn);
					    		  loopCounter++;
					    	  }
					    	  LOGGER.debug("NO of times file extention loop counter run"+loopCounter);
					      }else{
					    	  LOGGER.error("Server property error: property file has allowed extn saperated by more than one character");
					      }
					      
						
						if(extenFound){
							extnCheckPoint =true;
							LOGGER.debug("File extention check passed for filename::"+fileName+" having extn::"+inputFileExtn);
						}else{
							extnCheckPoint = false;
							isValidationSuccess = false;
							LOGGER.debug("File extention check FAILED for filename::"+fileName+" having extn::"+inputFileExtn+". Ignoring MIME check, returning validation false");
						}
						
						if(extnCheckPoint){
						//pdf,doc,docx,xls,xlsx,ppt,pptx,pps,ppsx,csv,txt,mp3,mp4,jpeg,jpg,png,gif
	                    if(!"application/vnd.openxmlformats-officedocument.wordprocessingml.document".equalsIgnoreCase(mimeType) &&
	                  /*.xls.xlt.xla*/!"application/vnd.ms-excel".equalsIgnoreCase(mimeType) &&
	                    	 /*.xlsx*/!"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet".equalsIgnoreCase(mimeType) &&
	                    	   /*ppt*/!"application/vnd.ms-powerpoint".equalsIgnoreCase(mimeType) &&
	                    	  /*pptx*/!"application/vnd.openxmlformats-officedocument.presentationml.presentation".equalsIgnoreCase(mimeType) &&
	                    	   /*pps*/!"application/vnd.ms-powerpoint".equalsIgnoreCase(mimeType) &&
	                    	 /*.ppsx*/!"application/vnd.openxmlformats-officedocument.presentationml.slideshow".equals(mimeType) &&
	                    	   /*mp3*/!"audio/mpeg3".equals(mimeType) &&
	                    	   /*mp3*/!"audio/x-mpeg-3".equals(mimeType) &&
	                    	   /*mp3*/!"video/mpeg".equals(mimeType) &&
	                    	   /*mp3*/!"video/x-mpeg".equals(mimeType) &&
	                    	   /*mp4*/!"video/mp4".equals(mimeType) &&
	                    	   /*mp4*/!"video/mp4".equals(mimeType) &&
	                    	   /*csv*/!"text/csv".equals(mimeType) &&
	                                  !"application/pdf".equalsIgnoreCase(mimeType) &&
	                                  !"text/plain".equalsIgnoreCase(mimeType) &&
	                                  !"image/jpeg".equalsIgnoreCase(mimeType) &&
	                                  !"image/png".equalsIgnoreCase(mimeType) &&
	                                  !"image/gif".equalsIgnoreCase(mimeType) ) {
							LOGGER.warn("Error in parsing file::"+fileName+"::mimeType is::"+mimeType);
							isValidationSuccess = false;
							LOGGER.debug("Mime type check FAILED"+fileName+"::mimeType is::"+mimeType);
							//throw new FileExtensionException();
						 }else{
							 LOGGER.debug("Mime type check passed"+fileName+"::mimeType is::"+mimeType);
						 }
	                    
					}
	                    
					} catch (IOException e1) {
							LOGGER.error("Error IO:"+e1);
						//throw new FileExtensionException();
						
					} catch (Exception e1) {
						//throw new FileExtensionException();
						LOGGER.error("Error E:"+e1);
						
					}
					InputStream inputStream = new ByteArrayFileInputStream(tempFile, GetterUtil.getInteger(PropsUtil.get("com.liferay.portal.upload.LiferayFileItem.threshold.size"),262144));
					inputStreamOVP.setValue(inputStream);
				}
			}
			
			if(isValidationSuccess){
				LOGGER.info("File validation success.");
			}
			//return tempFiles;
			return isValidationSuccess;
		}
	
	
	
	public String recoverOriginalBody(String htmlBody){

		String localBody = "";
		try {
			// Retrieve original body contents
			localBody = htmlBody.substring(0, htmlBody.lastIndexOf("("));
		} catch (Exception e) {
			LOGGER.error("Err in recoverOriginalBody(::",e);
		}
		return localBody;
	}
	
	public ExpandoValue updateMessageShareCount(long messageId){
		ExpandoValue expandoValue = null;
		try {
			
			int newCount= ExpandoUtility.getInstance().updateMsgShareCount(messageId);
			LOGGER.debug("Share count:"+newCount);
		} catch (Exception e) {
			LOGGER.error("Error in updateMessageShareCount:"+e.getMessage());
		}
		return expandoValue;
	}
	
	
}