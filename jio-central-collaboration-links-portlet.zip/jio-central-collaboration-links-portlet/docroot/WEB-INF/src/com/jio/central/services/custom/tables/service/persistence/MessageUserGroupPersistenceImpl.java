/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.service.persistence;

import com.jio.central.services.custom.tables.NoSuchMessageUserGroupException;
import com.jio.central.services.custom.tables.model.MessageUserGroup;
import com.jio.central.services.custom.tables.model.impl.MessageUserGroupImpl;
import com.jio.central.services.custom.tables.model.impl.MessageUserGroupModelImpl;
import com.jio.central.services.custom.tables.service.persistence.MessageUserGroupPersistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the message user group service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author dewang.patel
 * @see MessageUserGroupPersistence
 * @see MessageUserGroupUtil
 * @generated
 */
public class MessageUserGroupPersistenceImpl extends BasePersistenceImpl<MessageUserGroup>
	implements MessageUserGroupPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link MessageUserGroupUtil} to access the message user group persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = MessageUserGroupImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(MessageUserGroupModelImpl.ENTITY_CACHE_ENABLED,
			MessageUserGroupModelImpl.FINDER_CACHE_ENABLED,
			MessageUserGroupImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(MessageUserGroupModelImpl.ENTITY_CACHE_ENABLED,
			MessageUserGroupModelImpl.FINDER_CACHE_ENABLED,
			MessageUserGroupImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(MessageUserGroupModelImpl.ENTITY_CACHE_ENABLED,
			MessageUserGroupModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);

	public MessageUserGroupPersistenceImpl() {
		setModelClass(MessageUserGroup.class);
	}

	/**
	 * Caches the message user group in the entity cache if it is enabled.
	 *
	 * @param messageUserGroup the message user group
	 */
	@Override
	public void cacheResult(MessageUserGroup messageUserGroup) {
		EntityCacheUtil.putResult(MessageUserGroupModelImpl.ENTITY_CACHE_ENABLED,
			MessageUserGroupImpl.class, messageUserGroup.getPrimaryKey(),
			messageUserGroup);

		messageUserGroup.resetOriginalValues();
	}

	/**
	 * Caches the message user groups in the entity cache if it is enabled.
	 *
	 * @param messageUserGroups the message user groups
	 */
	@Override
	public void cacheResult(List<MessageUserGroup> messageUserGroups) {
		for (MessageUserGroup messageUserGroup : messageUserGroups) {
			if (EntityCacheUtil.getResult(
						MessageUserGroupModelImpl.ENTITY_CACHE_ENABLED,
						MessageUserGroupImpl.class,
						messageUserGroup.getPrimaryKey()) == null) {
				cacheResult(messageUserGroup);
			}
			else {
				messageUserGroup.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all message user groups.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(MessageUserGroupImpl.class.getName());
		}

		EntityCacheUtil.clearCache(MessageUserGroupImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the message user group.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(MessageUserGroup messageUserGroup) {
		EntityCacheUtil.removeResult(MessageUserGroupModelImpl.ENTITY_CACHE_ENABLED,
			MessageUserGroupImpl.class, messageUserGroup.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<MessageUserGroup> messageUserGroups) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (MessageUserGroup messageUserGroup : messageUserGroups) {
			EntityCacheUtil.removeResult(MessageUserGroupModelImpl.ENTITY_CACHE_ENABLED,
				MessageUserGroupImpl.class, messageUserGroup.getPrimaryKey());
		}
	}

	/**
	 * Creates a new message user group with the primary key. Does not add the message user group to the database.
	 *
	 * @param pid the primary key for the new message user group
	 * @return the new message user group
	 */
	@Override
	public MessageUserGroup create(long pid) {
		MessageUserGroup messageUserGroup = new MessageUserGroupImpl();

		messageUserGroup.setNew(true);
		messageUserGroup.setPrimaryKey(pid);

		return messageUserGroup;
	}

	/**
	 * Removes the message user group with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param pid the primary key of the message user group
	 * @return the message user group that was removed
	 * @throws com.jio.central.services.custom.tables.NoSuchMessageUserGroupException if a message user group with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public MessageUserGroup remove(long pid)
		throws NoSuchMessageUserGroupException, SystemException {
		return remove((Serializable)pid);
	}

	/**
	 * Removes the message user group with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the message user group
	 * @return the message user group that was removed
	 * @throws com.jio.central.services.custom.tables.NoSuchMessageUserGroupException if a message user group with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public MessageUserGroup remove(Serializable primaryKey)
		throws NoSuchMessageUserGroupException, SystemException {
		Session session = null;

		try {
			session = openSession();

			MessageUserGroup messageUserGroup = (MessageUserGroup)session.get(MessageUserGroupImpl.class,
					primaryKey);

			if (messageUserGroup == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchMessageUserGroupException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(messageUserGroup);
		}
		catch (NoSuchMessageUserGroupException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected MessageUserGroup removeImpl(MessageUserGroup messageUserGroup)
		throws SystemException {
		messageUserGroup = toUnwrappedModel(messageUserGroup);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(messageUserGroup)) {
				messageUserGroup = (MessageUserGroup)session.get(MessageUserGroupImpl.class,
						messageUserGroup.getPrimaryKeyObj());
			}

			if (messageUserGroup != null) {
				session.delete(messageUserGroup);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (messageUserGroup != null) {
			clearCache(messageUserGroup);
		}

		return messageUserGroup;
	}

	@Override
	public MessageUserGroup updateImpl(
		com.jio.central.services.custom.tables.model.MessageUserGroup messageUserGroup)
		throws SystemException {
		messageUserGroup = toUnwrappedModel(messageUserGroup);

		boolean isNew = messageUserGroup.isNew();

		Session session = null;

		try {
			session = openSession();

			if (messageUserGroup.isNew()) {
				session.save(messageUserGroup);

				messageUserGroup.setNew(false);
			}
			else {
				session.merge(messageUserGroup);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		EntityCacheUtil.putResult(MessageUserGroupModelImpl.ENTITY_CACHE_ENABLED,
			MessageUserGroupImpl.class, messageUserGroup.getPrimaryKey(),
			messageUserGroup);

		return messageUserGroup;
	}

	protected MessageUserGroup toUnwrappedModel(
		MessageUserGroup messageUserGroup) {
		if (messageUserGroup instanceof MessageUserGroupImpl) {
			return messageUserGroup;
		}

		MessageUserGroupImpl messageUserGroupImpl = new MessageUserGroupImpl();

		messageUserGroupImpl.setNew(messageUserGroup.isNew());
		messageUserGroupImpl.setPrimaryKey(messageUserGroup.getPrimaryKey());

		messageUserGroupImpl.setPid(messageUserGroup.getPid());
		messageUserGroupImpl.setMessageid(messageUserGroup.getMessageid());
		messageUserGroupImpl.setIsgroup(messageUserGroup.isIsgroup());
		messageUserGroupImpl.setUserorgrp_name(messageUserGroup.getUserorgrp_name());
		messageUserGroupImpl.setUserorgrp_id(messageUserGroup.getUserorgrp_id());
		messageUserGroupImpl.setCreatedbyuserid(messageUserGroup.getCreatedbyuserid());

		return messageUserGroupImpl;
	}

	/**
	 * Returns the message user group with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the message user group
	 * @return the message user group
	 * @throws com.jio.central.services.custom.tables.NoSuchMessageUserGroupException if a message user group with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public MessageUserGroup findByPrimaryKey(Serializable primaryKey)
		throws NoSuchMessageUserGroupException, SystemException {
		MessageUserGroup messageUserGroup = fetchByPrimaryKey(primaryKey);

		if (messageUserGroup == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchMessageUserGroupException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return messageUserGroup;
	}

	/**
	 * Returns the message user group with the primary key or throws a {@link com.jio.central.services.custom.tables.NoSuchMessageUserGroupException} if it could not be found.
	 *
	 * @param pid the primary key of the message user group
	 * @return the message user group
	 * @throws com.jio.central.services.custom.tables.NoSuchMessageUserGroupException if a message user group with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public MessageUserGroup findByPrimaryKey(long pid)
		throws NoSuchMessageUserGroupException, SystemException {
		return findByPrimaryKey((Serializable)pid);
	}

	/**
	 * Returns the message user group with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the message user group
	 * @return the message user group, or <code>null</code> if a message user group with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public MessageUserGroup fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		MessageUserGroup messageUserGroup = (MessageUserGroup)EntityCacheUtil.getResult(MessageUserGroupModelImpl.ENTITY_CACHE_ENABLED,
				MessageUserGroupImpl.class, primaryKey);

		if (messageUserGroup == _nullMessageUserGroup) {
			return null;
		}

		if (messageUserGroup == null) {
			Session session = null;

			try {
				session = openSession();

				messageUserGroup = (MessageUserGroup)session.get(MessageUserGroupImpl.class,
						primaryKey);

				if (messageUserGroup != null) {
					cacheResult(messageUserGroup);
				}
				else {
					EntityCacheUtil.putResult(MessageUserGroupModelImpl.ENTITY_CACHE_ENABLED,
						MessageUserGroupImpl.class, primaryKey,
						_nullMessageUserGroup);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(MessageUserGroupModelImpl.ENTITY_CACHE_ENABLED,
					MessageUserGroupImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return messageUserGroup;
	}

	/**
	 * Returns the message user group with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param pid the primary key of the message user group
	 * @return the message user group, or <code>null</code> if a message user group with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public MessageUserGroup fetchByPrimaryKey(long pid)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)pid);
	}

	/**
	 * Returns all the message user groups.
	 *
	 * @return the message user groups
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<MessageUserGroup> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the message user groups.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.MessageUserGroupModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of message user groups
	 * @param end the upper bound of the range of message user groups (not inclusive)
	 * @return the range of message user groups
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<MessageUserGroup> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the message user groups.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.MessageUserGroupModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of message user groups
	 * @param end the upper bound of the range of message user groups (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of message user groups
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<MessageUserGroup> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<MessageUserGroup> list = (List<MessageUserGroup>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_MESSAGEUSERGROUP);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_MESSAGEUSERGROUP;

				if (pagination) {
					sql = sql.concat(MessageUserGroupModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<MessageUserGroup>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<MessageUserGroup>(list);
				}
				else {
					list = (List<MessageUserGroup>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the message user groups from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (MessageUserGroup messageUserGroup : findAll()) {
			remove(messageUserGroup);
		}
	}

	/**
	 * Returns the number of message user groups.
	 *
	 * @return the number of message user groups
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_MESSAGEUSERGROUP);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the message user group persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.jio.central.services.custom.tables.model.MessageUserGroup")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<MessageUserGroup>> listenersList = new ArrayList<ModelListener<MessageUserGroup>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<MessageUserGroup>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(MessageUserGroupImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_MESSAGEUSERGROUP = "SELECT messageUserGroup FROM MessageUserGroup messageUserGroup";
	private static final String _SQL_COUNT_MESSAGEUSERGROUP = "SELECT COUNT(messageUserGroup) FROM MessageUserGroup messageUserGroup";
	private static final String _ORDER_BY_ENTITY_ALIAS = "messageUserGroup.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No MessageUserGroup exists with the primary key ";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(MessageUserGroupPersistenceImpl.class);
	private static MessageUserGroup _nullMessageUserGroup = new MessageUserGroupImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<MessageUserGroup> toCacheModel() {
				return _nullMessageUserGroupCacheModel;
			}
		};

	private static CacheModel<MessageUserGroup> _nullMessageUserGroupCacheModel = new CacheModel<MessageUserGroup>() {
			@Override
			public MessageUserGroup toEntityModel() {
				return _nullMessageUserGroup;
			}
		};
}