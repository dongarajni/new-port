/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.model.impl;

import com.jio.central.services.custom.tables.model.MessageUserGroup;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing MessageUserGroup in entity cache.
 *
 * @author dewang.patel
 * @see MessageUserGroup
 * @generated
 */
public class MessageUserGroupCacheModel implements CacheModel<MessageUserGroup>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{pid=");
		sb.append(pid);
		sb.append(", messageid=");
		sb.append(messageid);
		sb.append(", isgroup=");
		sb.append(isgroup);
		sb.append(", userorgrp_name=");
		sb.append(userorgrp_name);
		sb.append(", userorgrp_id=");
		sb.append(userorgrp_id);
		sb.append(", createdbyuserid=");
		sb.append(createdbyuserid);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public MessageUserGroup toEntityModel() {
		MessageUserGroupImpl messageUserGroupImpl = new MessageUserGroupImpl();

		messageUserGroupImpl.setPid(pid);
		messageUserGroupImpl.setMessageid(messageid);
		messageUserGroupImpl.setIsgroup(isgroup);

		if (userorgrp_name == null) {
			messageUserGroupImpl.setUserorgrp_name(StringPool.BLANK);
		}
		else {
			messageUserGroupImpl.setUserorgrp_name(userorgrp_name);
		}

		messageUserGroupImpl.setUserorgrp_id(userorgrp_id);
		messageUserGroupImpl.setCreatedbyuserid(createdbyuserid);

		messageUserGroupImpl.resetOriginalValues();

		return messageUserGroupImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		pid = objectInput.readLong();
		messageid = objectInput.readLong();
		isgroup = objectInput.readBoolean();
		userorgrp_name = objectInput.readUTF();
		userorgrp_id = objectInput.readLong();
		createdbyuserid = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(pid);
		objectOutput.writeLong(messageid);
		objectOutput.writeBoolean(isgroup);

		if (userorgrp_name == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(userorgrp_name);
		}

		objectOutput.writeLong(userorgrp_id);
		objectOutput.writeLong(createdbyuserid);
	}

	public long pid;
	public long messageid;
	public boolean isgroup;
	public String userorgrp_name;
	public long userorgrp_id;
	public long createdbyuserid;
}