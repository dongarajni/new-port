package com.jio.central.collaboration.util;

import com.jio.central.constants.Consts;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.service.ClassNameLocalServiceUtil;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.expando.model.ExpandoColumn;
import com.liferay.portlet.expando.model.ExpandoTable;
import com.liferay.portlet.expando.model.ExpandoValue;
import com.liferay.portlet.expando.service.ExpandoColumnLocalServiceUtil;
import com.liferay.portlet.expando.service.ExpandoTableLocalServiceUtil;
import com.liferay.portlet.expando.service.ExpandoValueLocalServiceUtil;
import com.liferay.portlet.messageboards.model.MBMessage;


public class ExpandoUtility {

	private static ExpandoUtility utility = new ExpandoUtility();
	
	public static ExpandoUtility getInstance(){
		return utility;
	}
	
	Log LOGGER = LogFactoryUtil.getLog(ExpandoUtility.class.getName());
	
	public ExpandoValue fetchCurrentShareCount(long messageId){
		ExpandoValue expandoValue = null;
		try {
			
			if(Validator.isNotNull(messageId) && messageId!=0){
			
				// Get the className i.e MbMessage for custom field operation
				long classNameId = ClassNameLocalServiceUtil.getClassNameId(MBMessage.class.getName());
				//Get the table Custom_Field
				ExpandoTable expandoTable = ExpandoUtility.getInstance().fetchExpandoTable(classNameId);
				// Get the column Name SHare Count
				ExpandoColumn expandoColumn =  ExpandoUtility.getInstance().fetchExpandoColumn(classNameId, expandoTable);
				// Get the current expando value 
				expandoValue = ExpandoValueLocalServiceUtil.getValue(expandoTable.getTableId(), expandoColumn.getColumnId(), messageId);
				
			}else{
				expandoValue = null;
			}
			
			
		} catch (Exception e) {
			LOGGER.error("Errror in fetchCurrentShareCount()::"+e.getMessage());
		}
		return expandoValue;
	}
	
	public ExpandoTable fetchExpandoTable(long classNameId){
		ExpandoTable expandoTable = null;
		try {
			expandoTable = ExpandoTableLocalServiceUtil.getTable(PortalUtil.getDefaultCompanyId(), classNameId, Consts.TABLENAME);
		} catch (Exception e) {
			LOGGER.error("Error in fetchExpandoTable():",e);
		}
		return expandoTable;
	}
	
	public ExpandoColumn fetchExpandoColumn(long classNameId , ExpandoTable expandoTable){
		ExpandoColumn expandoColumn = null;
		try {
			expandoColumn = ExpandoColumnLocalServiceUtil.getColumn(PortalUtil.getDefaultCompanyId(), classNameId, expandoTable.getName(), Consts.SHARECOUNT);
		} catch (Exception e) {
			LOGGER.error("Error in fetchExpandoTable():",e);
		}
		return expandoColumn;
	}
	
	
	public int getMsgShareCount(long messageId){
		int count = 0;
		try {
				// Get the current share count object based on messageId
				ExpandoValue currExpandoValue = fetchCurrentShareCount(messageId);
			
			if(Validator.isNotNull(currExpandoValue)){
				// return the current share count
				count = Integer.parseInt(currExpandoValue.getData());
			}else{
				LOGGER.debug("getMsgShareCount()::::NO such message Id found:"+messageId);
			}
			
		} catch (Exception e) {
			LOGGER.error("Errror in getMsgShareCount()::"+e.getMessage());
		}
		return count;
	}
	
	public int updateMsgShareCount(long messageId){
		ExpandoValue updatedExpandoValue = null;
		int count = 0;
		try {
			 	// Get the current share count object based on messageId 
				ExpandoValue currentExpandoValue = fetchCurrentShareCount(messageId);
			
			if(Validator.isNotNull(currentExpandoValue)){
				// Get the current share count
				int tempshareCount = Integer.parseInt(currentExpandoValue.getData());
				// Increment the current share count by 1 
				currentExpandoValue.setData(String.valueOf(++tempshareCount));
				// Store the updated value in db
				updatedExpandoValue = ExpandoValueLocalServiceUtil.updateExpandoValue(currentExpandoValue);
				// Return the updated count from db object
				count = Integer.parseInt(updatedExpandoValue.getData());
			}
			// share count for migration posts
			else if(Validator.isNull(currentExpandoValue) && Validator.isNotNull(messageId) && messageId!=0){
				// Get the current share count
				
				
				long classNameId = ClassNameLocalServiceUtil.getClassNameId(MBMessage.class.getName());
				ExpandoTable expandoTable =null;
				ExpandoColumn expandoColumn= null;
				ExpandoValue expandoValue =null;
				
				expandoTable = ExpandoUtility.getInstance().fetchExpandoTable(classNameId);
				if(Validator.isNotNull(expandoTable))
				expandoColumn= ExpandoUtility.getInstance().fetchExpandoColumn(classNameId, expandoTable);
				if(Validator.isNotNull(expandoColumn))
				expandoValue = ExpandoValueLocalServiceUtil.addValue(classNameId, expandoTable.getTableId(), expandoColumn.getColumnId(), messageId,"1");
				
				// Return the updated count from db object
				if(Validator.isNotNull(expandoValue))
				count = Integer.parseInt(expandoValue.getData());
			}
			else{
				LOGGER.error("No share count found for message Id:"+messageId);
			}
			
		} catch (Exception e) {
			LOGGER.error("Errror in updateMsgShareCount()::"+e.getMessage());
		}
		return count;
	}
	
	
	public boolean deleteExpandoValues(long messagId){
		boolean isValueDel = false;
		try {
			ExpandoValueLocalServiceUtil.deleteValues(ClassNameLocalServiceUtil.getClassNameId(MBMessage.class), messagId);
			isValueDel = true;
		} catch (Exception expandoDel) {
			LOGGER.error("Error while deleting expando value:"+expandoDel);
		}
		return isValueDel;
	}
	
	
}