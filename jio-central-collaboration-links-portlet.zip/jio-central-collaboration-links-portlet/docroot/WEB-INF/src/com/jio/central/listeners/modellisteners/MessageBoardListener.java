package com.jio.central.listeners.modellisteners;

import com.jio.central.collaboration.util.ExpandoUtility;
import com.jio.central.services.custom.tables.model.MessageUserGroup;
import com.jio.central.services.custom.tables.service.MessageUserGroupLocalServiceUtil;
import com.liferay.portal.ModelListenerException;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletClassLoaderUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelListener;
import com.liferay.portlet.messageboards.model.MBMessage;

import java.util.List;

/**
 * @author Vaibhav6.Singh
 *
 */
public class MessageBoardListener implements ModelListener<MBMessage> {

	private Log LOGGER = LogFactoryUtil.getLog(MessageBoardListener.class.getName());
	
	
	@Override
	public void onAfterAddAssociation(Object arg0, String arg1, Object arg2)
			throws ModelListenerException {
		// TODO Auto-generated method stub
	}

	@Override
	public void onAfterCreate(MBMessage message) throws ModelListenerException {
		// TODO Auto-generated method stub
	}

	@Override
	public void onAfterRemove(MBMessage message) throws ModelListenerException {
		// TODO Auto-generated method stub
	}

	@Override
	public void onAfterRemoveAssociation(Object arg0, String arg1, Object arg2)
			throws ModelListenerException {
		// TODO Auto-generated method stub
	}

	@Override
	public void onAfterUpdate(MBMessage message) throws ModelListenerException {
		// TODO Auto-generated method stub
	}

	@Override
	public void onBeforeAddAssociation(Object arg0, String arg1, Object arg2)
			throws ModelListenerException {
		// TODO Auto-generated method stub
	}

	@Override
	public void onBeforeCreate(MBMessage arg0) throws ModelListenerException {
		// TODO Auto-generated method stub
	}

	@Override
	public void onBeforeRemove(MBMessage message) throws ModelListenerException {
		try {
			
			// delete Expando Value tags
			boolean isValueDeleted = false;
			isValueDeleted = ExpandoUtility.getInstance().deleteExpandoValues(message.getMessageId());
			LOGGER.info("Deleted expando value:"+isValueDeleted+", for messageId:"+message.getMessageId());
			
			// Reply has no tagged members/Group so no delete operation will be carried out
			if(message.getParentMessageId()!=0 || message.isReply()){
				LOGGER.info("No operation due to to reply happens to have no tags.");
			}else{
				
				DynamicQuery msgUserGroupdynamicQuery = DynamicQueryFactoryUtil.forClass(MessageUserGroup.class,"mugm",PortletClassLoaderUtil.getClassLoader());
		    	msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.messageid", message.getMessageId()));
		    	msgUserGroupdynamicQuery.setProjection(PropertyFactoryUtil.forName("mugm.pid"));
		    	
		    	List<Long> listCollection = MessageUserGroupLocalServiceUtil.dynamicQuery(msgUserGroupdynamicQuery);
		    	
		    	if(Validator.isNotNull(listCollection) && listCollection.size()>0){
		    		for (Long primaryId : listCollection) {
		    			MessageUserGroupLocalServiceUtil.deleteMessageUserGroup(primaryId);
					}
		    		LOGGER.info("Total MbMessage tags deleted is "+listCollection.size()+" for MbMessage "+message.getMessageId());
		    	}
			}
		} catch (Exception e) {
				LOGGER.error("Error in onBeforeRemove:"+e.getMessage());
		}
				
	}

	@Override
	public void onBeforeRemoveAssociation(Object arg0, String arg1, Object arg2)
			throws ModelListenerException {
		// TODO Auto-generated method stub
	}

	@Override
	public void onBeforeUpdate(MBMessage message) throws ModelListenerException {
		// TODO Auto-generated method stub
	}
	
}