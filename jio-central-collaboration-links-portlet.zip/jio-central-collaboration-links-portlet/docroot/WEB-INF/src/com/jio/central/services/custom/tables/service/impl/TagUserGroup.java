package com.jio.central.services.custom.tables.service.impl;


/*import java.util.LinkedList;*/
import com.jio.central.constants.Consts;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.Order;
import com.liferay.portal.kernel.dao.orm.OrderFactoryUtil;
import com.liferay.portal.kernel.dao.orm.ProjectionFactoryUtil;
import com.liferay.portal.kernel.dao.orm.ProjectionList;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.HtmlUtil;
import com.liferay.portal.kernel.util.PortalClassLoaderUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.Organization;
import com.liferay.portal.model.User;
import com.liferay.portal.security.auth.PrincipalThreadLocal;
import com.liferay.portal.service.OrganizationLocalServiceUtil;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.util.portlet.PortletProps;

import java.util.List;


/*
 * This util class based on filter produce jsonArray response matched against response 
 * */
public class TagUserGroup {

	private static Log LOGGER = LogFactoryUtil.getLog(TagUserGroup.class.getName());
	
	private static TagUserGroup tagUserGroupINSTANCE = new TagUserGroup();
	
	//setting initial value to screenName incase blank value is passed from prop file for user lookup.
	public String userSearchFieldName = "screenName"; 
	
	public TagUserGroup(){
		userSearchFieldName = HtmlUtil.escape(PortletProps.get("for.tagging.search.user.by"));
		LOGGER.debug("db column name:"+userSearchFieldName);
	}
	
	public static TagUserGroup getInstance(){
		return tagUserGroupINSTANCE; 	
	}
	
	
	/*
	 * Filter type = User or Group
	 * search Query is letter typed by user at view page.
	 * */
	public JSONArray getAllUserGroup(final String filterType , final String searchQuery){
		JSONArray jsonArray = JSONFactoryUtil.createJSONArray();
		
		try {
			JSONObject jsonObject = null;
			
			String localSearchAttribute = HtmlUtil.escape(searchQuery);
			String searchFilters = HtmlUtil.escape(filterType);
			LOGGER.debug("Tagged Assets========" + localSearchAttribute);
			LOGGER.debug("Filter========" + searchFilters);
			
			// search all Users
			if(Validator.isNotNull(localSearchAttribute) && Validator.isNotNull(searchFilters) && Consts.filterIsUser.equalsIgnoreCase(filterType)){
				/*JsonARray getting passed over here will return back all the result
				 * localsearchAttribute is the phrase typed by user for which user search in db is to be carried out
				 * userSearchFieldName = is database column name upon which search lookup is performed
				 * limiting the result to 75 currently for better performance.
				 * */
				jsonArray = getUserMatch(jsonArray, localSearchAttribute ,userSearchFieldName , 75);
			}
			
			// Search all groups
			else if(Validator.isNotNull(localSearchAttribute) && Validator.isNotNull(searchFilters) && Consts.filterIsGroup.equalsIgnoreCase(filterType)){
				// principal local thread return current logged in user's id 
				jsonArray = getGroupMatch(jsonArray, localSearchAttribute, Long.valueOf(PrincipalThreadLocal.getName()));
			}
			// In-case of filter is provided other then above two then please create another check point till then bad input as op
			else{
				jsonObject = JSONFactoryUtil.createJSONObject();
				jsonObject.put("Error", "Bad Input");
				jsonArray.put(jsonObject);
			}
			
			
		}catch(Exception e){
			LOGGER.error("Error while fetching user/group matching result--::"+e.getMessage());
		}
			return jsonArray;
	}
	
	
	
	/*
	 * Pass Json Array as to get respecive response in same object
	 * lookingForUser is typed user name or searchQuery for which all user based data is to be sent back in JSONARRAY
	 * */
	public JSONArray getUserMatch (JSONArray usersJSONArray , String lookingForUser  , final String searchInDBColumn , final int resultLimit){
		 
		 JSONObject userJSONObject = null;
		try {
			
			
			// Pass: typed userName here as case insensitive value i.e iLike
			DynamicQuery userQuery = DynamicQueryFactoryUtil.forClass(User.class, "user",PortalClassLoaderUtil.getClassLoader());
			Criterion criterion = RestrictionsFactoryUtil.ilike(searchInDBColumn,StringPool.PERCENT + lookingForUser + StringPool.PERCENT);
			userQuery.add(criterion);
			
			//get only selected column
			ProjectionList projectionList = ProjectionFactoryUtil.projectionList();
			projectionList.add(PropertyFactoryUtil.forName("user.userId"));
			projectionList.add(PropertyFactoryUtil.forName("user."+searchInDBColumn));
			userQuery.setProjection(projectionList);
			
			//order by screenName
			Order defaultOrder = OrderFactoryUtil.asc(searchInDBColumn);
			
			userQuery.addOrder(defaultOrder);
			userQuery.setLimit(0,resultLimit);
			
				List<Object[]> users = UserLocalServiceUtil.dynamicQuery(userQuery);
				for (Object[] user : users) {
					
						userJSONObject = JSONFactoryUtil.createJSONObject();
						
						userJSONObject.put("primaryId", String.valueOf(user[0]));
						userJSONObject.put("value", String.valueOf(user[1]));
						usersJSONArray.put(userJSONObject);
				}
            
			
		} catch (Exception e) {
			LOGGER.error("Error in finding matched user against searched query::"+e.getMessage());
		}
		return usersJSONArray;
		
	}
	
	/*
	 * */
	public JSONArray getGroupMatch (JSONArray groupJSONArray , String lookingForGroup , long byUserId){
		 	try {
				
				//get Org match query
				JSONObject groupJSONObject = null;		
				
				List<Organization> orgList = OrganizationLocalServiceUtil.getUserOrganizations(byUserId);
				
					if(Validator.isNotNull(orgList) && orgList.size()>0){
					for (Organization orgsItr : orgList) {
						
							groupJSONObject = JSONFactoryUtil.createJSONObject();
							
							if(orgsItr.getName().toLowerCase().contains(lookingForGroup.toLowerCase())){
								
								groupJSONObject.put("value", String.valueOf(orgsItr.getName()));
								groupJSONObject.put("primaryId", String.valueOf(orgsItr.getOrganizationId()));
								groupJSONArray.put(groupJSONObject);	
							}							
						}// end of for
					}
			} catch (Exception e) {
				LOGGER.error("Error in getGROUPMatch ::",e);
			}
			return groupJSONArray;
	}
}