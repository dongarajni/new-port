package com.jio.central.collaboration.menu.portlet;

import com.jio.central.collaboration.util.ImageValidation;
import com.jio.central.collaboration.util.MenuWallConstants;
import com.jio.central.constants.Consts;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.FileUtil;
import com.liferay.portal.kernel.util.HtmlUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.Group;
import com.liferay.portal.model.LayoutSet;
import com.liferay.portal.model.Organization;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ClassNameLocalServiceUtil;
import com.liferay.portal.service.LayoutSetLocalServiceUtil;
import com.liferay.portal.service.OrganizationLocalServiceUtil;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.expando.model.ExpandoColumn;
import com.liferay.portlet.expando.model.ExpandoColumnConstants;
import com.liferay.portlet.expando.model.ExpandoTable;
import com.liferay.portlet.expando.service.ExpandoColumnLocalServiceUtil;
import com.liferay.portlet.expando.service.ExpandoTableLocalServiceUtil;
import com.liferay.portlet.messageboards.model.MBMessage;
import com.liferay.util.bridges.mvc.MVCPortlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.ProcessAction;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

/**
 * Portlet implementation class JioCollaborationMenuController
 */

public class MenuController extends MVCPortlet {

	private Log LOGGER = LogFactoryUtil.getLog(MenuController.class.getName());

	
	
	@Override
	public void init() throws PortletException {
	
		
		
		long classNameId = ClassNameLocalServiceUtil.getClassNameId(MBMessage.class.getName());
		LOGGER.info("Creating expando...");
		ExpandoTable table = createExpandoTable(Consts.TABLENAME,classNameId);
		// columns to be created
		HashMap<String, Integer> columnNamesMap = new HashMap<String, Integer>();
			columnNamesMap.put(Consts.TAGUSER, ExpandoColumnConstants.STRING_ARRAY);
			columnNamesMap.put(Consts.TAGGROUP, ExpandoColumnConstants.STRING_ARRAY);
			columnNamesMap.put(Consts.SHARECOUNT, ExpandoColumnConstants.STRING);
		createExpandoColumn(table.getTableId(), columnNamesMap);
		
		super.init();
	}
	
	public ExpandoTable createExpandoTable(String tableName, long classNameId) {
		ExpandoTable table = null;
		try {
			
			boolean isTableExist = checkExpandoTableOrColumn("table", PortalUtil.getDefaultCompanyId(), tableName, classNameId, 0,"");
		
			if(Validator.isNotNull(isTableExist) && !isTableExist){
				table = ExpandoTableLocalServiceUtil.addTable(PortalUtil.getDefaultCompanyId(), classNameId, tableName);
				LOGGER.info("table created:"+table);
					
			}else if(Validator.isNotNull(isTableExist) && isTableExist){
				LOGGER.info("Table already exist, name is "+tableName);
				table = ExpandoTableLocalServiceUtil.fetchTable(PortalUtil.getDefaultCompanyId(), classNameId, tableName);
			}
			
		}
		 catch (Exception e) {
				LOGGER.error("Error while creating table:"+e);
		}
		return table;
	}
	
	public void  createExpandoColumn(long tableId , HashMap<String, Integer> columnNamesMap) {
		try {
			
			for (Map.Entry<String, Integer> entry : columnNamesMap.entrySet()){
				
			    ExpandoColumn column = null;
			    boolean isColExists = checkExpandoTableOrColumn("column", PortalUtil.getDefaultCompanyId(), "", 0, tableId , entry.getKey());
			    
				if(Validator.isNotNull(isColExists) && !isColExists){
					
					column = ExpandoColumnLocalServiceUtil.addColumn(tableId, entry.getKey(), entry.getValue());
					LOGGER.info("Column created :"+column);
						
				}else if(Validator.isNotNull(isColExists) && isColExists){
					LOGGER.info("Column already exist, name is "+entry.getKey());
				}
			    
			}
			
			
		} catch (Exception e) {
			LOGGER.error("Error while creating Column:",e);
		}
	}
	
	public boolean checkExpandoTableOrColumn(String checkType ,long companyId, String tableName, long classNameId, long tableID , String columnName){
		boolean isExist = false;
		try {
			if("column".equals(checkType)){
				ExpandoColumn column = ExpandoColumnLocalServiceUtil.getColumn(tableID, columnName);
				if(Validator.isNotNull(column))
				isExist = true;
			}
			else if("table".equalsIgnoreCase(checkType)){
				
				ExpandoTable table = ExpandoTableLocalServiceUtil.fetchTable(companyId, classNameId, tableName);
				if(Validator.isNotNull(table))
				isExist = true;
			}
		} catch (Exception e) {
			LOGGER.error("Error while checking entity:",e);
		}
		return isExist;
	}
	
	
	
	
	
	@ProcessAction(name = "processView")
	/*public void processAction(ActionRequest actionRequest, ActionResponse actionResponse)*/
	public void processView(ActionRequest actionRequest, ActionResponse actionResponse)
			throws IOException, PortletException {
		/*
		 Fetching the view Names from portlet.properties file.		
		 View to generated for displaying related data through click action of
		 the menu.
		*/
		
		String view_name = ParamUtil.getString(actionRequest, "view-name", MenuWallConstants.ATTR_DEFAULT_VIEW);
		actionResponse.setRenderParameter(MenuWallConstants.TRIGGER_VIEW_TYPE, view_name);

		String logged_in_userName = ParamUtil.getString(actionRequest, "loggedInUser", "0");
		actionResponse.setRenderParameter(MenuWallConstants.LOGGED_IN_USER, logged_in_userName);
	}
	
	
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws PortletException, IOException {
		
		
		ThemeDisplay themeDisplay = (ThemeDisplay)renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		String view_name = ParamUtil.getString(renderRequest,MenuWallConstants.TRIGGER_VIEW_TYPE);
		String requested_user_frmParam = ParamUtil.getString(renderRequest,MenuWallConstants.LOGGED_IN_USER);
		
		HttpServletRequest request = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(renderRequest));
		
		String requested_user_frmRequest = request.getParameter(MenuWallConstants.LOGGED_IN_USER);
		
		if(Validator.isNotNull(requested_user_frmRequest))
		{
			renderRequest.setAttribute(MenuWallConstants.LOGGED_IN_USER, requested_user_frmRequest);
		}
		else if(Validator.isNotNull(requested_user_frmParam))
		{
			renderRequest.setAttribute(MenuWallConstants.LOGGED_IN_USER, requested_user_frmParam);
		}
		else
		{
			renderRequest.setAttribute(MenuWallConstants.LOGGED_IN_USER, String.valueOf(themeDisplay.getUserId()));
		}
		
		
		
		LOGGER.debug("Type of View from renderResponse :::" + view_name);
		LOGGER.debug("user from HttpRequest :::" + requested_user_frmRequest);
		LOGGER.debug("user From RenderParam ::: " + requested_user_frmParam);
	
		super.render(renderRequest, renderResponse);
	}
	
	/*Date : 11 AUg,2017
	 * 
	 *  Display pic operation Begin
	 *  fetch pic and based on type pic assest & upload it in respective (user/grp) table.
	 *  
	 *  */

	@ProcessAction(name="updateProfile")
    public void updateProfile(ActionRequest actionRequest, ActionResponse actionResponse) throws PortalException, SystemException{
        ThemeDisplay themeDisplay = (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
        UploadPortletRequest uploadRequest = PortalUtil.getUploadPortletRequest(actionRequest);
        String orgIdFromReq = uploadRequest.getParameter("orgid");
        
            try {
            	
            	ImageValidation imageValidationObj = new ImageValidation();
            	
            	// disable default error messages
            	SessionErrors.add(actionRequest, "error-key");
            	SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
            	
            	// get the user or group picture
            	File userfile = uploadRequest.getFile("userFile");
                File grpfile = uploadRequest.getFile("grpFile");
            	
                String referrer = HtmlUtil.escape(ParamUtil.getString(actionRequest, "redirect"));
                
                
                
            	if(Validator.isNotNull(userfile))    {
            		
            		// get the file attributes
            		String mimeTypes = uploadRequest.getContentType("userFile");
            		long fileSize = uploadRequest.getSize("userFile");
            		String fileName = uploadRequest.getFileName("userFile");
            		String extn = FileUtil.getExtension(fileName);
            		
            		//Apply image validation 
            		List<String> isFailure = imageValidationObj.imageValidation(mimeTypes, fileName, fileSize, extn);
            		
            		if(isFailure.size()==0){
	            		Boolean result = changeUserPicture(themeDisplay, userfile ,actionRequest);
	                    if(result){
	                    	SessionMessages.add(actionRequest, "userSuccess");
	                    }else{
	                    	imageValidationObj.setErrorMessages(actionRequest, "errorDisplayPic");
	                    }
            		}else{
            			
            			// if validation failed then display all error messages
            			for(String itr : isFailure){
            				imageValidationObj.setErrorMessages(actionRequest, itr);
            			}
            			
            		}
            	}

             
            	else if(Validator.isNotNull(grpfile)){
            		LOGGER.debug("grp fileFile Name:::"+ grpfile.getTotalSpace());
            		
            		
               		// get the file attributes
            		String mimeTypes = uploadRequest.getContentType("grpFile");
            		long fileSize = uploadRequest.getSize("grpFile");
            		String fileName = uploadRequest.getFileName("grpFile");
            		String extn = FileUtil.getExtension(fileName);
            		
            		//send for validation 
            		List<String> isFailure = imageValidationObj.imageValidation(mimeTypes, fileName, fileSize , extn);
            		
            		if(isFailure.size()==0){
            			Boolean result = changeGroupPicture(themeDisplay , grpfile , Long.valueOf(orgIdFromReq));
	                    if(result){
	                    	SessionMessages.add(actionRequest, "grpSuccess");
	                    }else{
	                    	imageValidationObj.setErrorMessages(actionRequest, "errorDisplayPic");
	                    }
            		}else{
            			
            			// if validation failed then display all error messages
            			for(String itr : isFailure){
            				imageValidationObj.setErrorMessages(actionRequest, itr);
            			}
            		}
         
            		
            		
                }
            	
            	else{
            		SessionErrors.add(actionRequest, "errorDisplayPic");
            	}
                
            	LOGGER.debug("==========END of display file upload=========");
            	actionResponse.sendRedirect(themeDisplay.getPortalURL()+referrer);
            	
            	
            } catch (Exception e) {
                LOGGER.error("Error in display picture file upload :::" + e.getMessage());
            }
          
   }
	
	
	
	private Boolean changeGroupPicture(ThemeDisplay themeDisplay , File grpFileObj , Long orgIdFromReq){
		
		Boolean changedGrpPic = false;
		try {
			InputStream inputStream = new FileInputStream(grpFileObj);

            byte[] bytes = FileUtil.getBytes(inputStream);
            
            
            Group group = themeDisplay.getScopeGroup();
            Organization org = null;
            if(group.isOrganization()){
            	 
            	org = OrganizationLocalServiceUtil.getOrganization(group.getClassPK());
            	if(Validator.isNotNull(org)){
            		LayoutSet updateCompanyLogo = LayoutSetLocalServiceUtil.updateLogo(group.getGroupId(), true, true, bytes);
            		LOGGER.info("Organization/Group logo updated:::"+updateCompanyLogo.getLogoId());
            		changedGrpPic = true;
            	}
            }

            //LayoutSet updateCompanyLogo = LayoutSetLocalServiceUtil.updateLogo(group.getGroupId(), true, true, bytes);
            
            

		} catch (java.io.IOException e) {
			LOGGER.error("While Updating Organization/Group Profile Pic Unable to decode image:::"+e.getMessage());
		} 
		catch (Exception e) {
			LOGGER.error("While Updating Organization/Group Profile Pic :::"+e.getMessage());
		}
		
		
		return changedGrpPic;
		
	}
	
	public Boolean changeUserPicture(ThemeDisplay themeDisplay , File userFileObj, ActionRequest actionRequest){
		Boolean changedUserPic = false;
		try {
            
			 InputStream inputStream = new FileInputStream(userFileObj);
             byte[] bytes = FileUtil.getBytes(inputStream);
             User userObj = UserLocalServiceUtil.updatePortrait(themeDisplay.getUser().getUserId(), bytes);
             LOGGER.info("User logo updated:: " + userObj);
             changedUserPic = true;
             
		} 
		catch(com.liferay.portal.UserPortraitSizeException e){
			LOGGER.error("While Changing User Profile Pic UserPortraitSizeException :::"+e.getMessage());
		}
		catch (Exception e) {
			LOGGER.error("While Changing User Profile Pic :::" + e.getMessage());
			
        }
		
		return changedUserPic;
	}
	
	
}