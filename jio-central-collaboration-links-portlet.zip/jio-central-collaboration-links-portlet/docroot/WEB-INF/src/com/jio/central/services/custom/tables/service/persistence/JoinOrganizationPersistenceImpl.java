/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.service.persistence;

import com.jio.central.services.custom.tables.NoSuchJoinOrganizationException;
import com.jio.central.services.custom.tables.model.JoinOrganization;
import com.jio.central.services.custom.tables.model.impl.JoinOrganizationImpl;
import com.jio.central.services.custom.tables.model.impl.JoinOrganizationModelImpl;
import com.jio.central.services.custom.tables.service.persistence.JoinOrganizationPersistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the join organization service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author dewang.patel
 * @see JoinOrganizationPersistence
 * @see JoinOrganizationUtil
 * @generated
 */
public class JoinOrganizationPersistenceImpl extends BasePersistenceImpl<JoinOrganization>
	implements JoinOrganizationPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link JoinOrganizationUtil} to access the join organization persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = JoinOrganizationImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
			JoinOrganizationModelImpl.FINDER_CACHE_ENABLED,
			JoinOrganizationImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
			JoinOrganizationModelImpl.FINDER_CACHE_ENABLED,
			JoinOrganizationImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
			JoinOrganizationModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_GROUPID = new FinderPath(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
			JoinOrganizationModelImpl.FINDER_CACHE_ENABLED,
			JoinOrganizationImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByGroupId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID =
		new FinderPath(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
			JoinOrganizationModelImpl.FINDER_CACHE_ENABLED,
			JoinOrganizationImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByGroupId",
			new String[] { Long.class.getName() },
			JoinOrganizationModelImpl.GROUPID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_GROUPID = new FinderPath(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
			JoinOrganizationModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByGroupId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the join organizations where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the matching join organizations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<JoinOrganization> findByGroupId(long groupId)
		throws SystemException {
		return findByGroupId(groupId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the join organizations where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.JoinOrganizationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of join organizations
	 * @param end the upper bound of the range of join organizations (not inclusive)
	 * @return the range of matching join organizations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<JoinOrganization> findByGroupId(long groupId, int start, int end)
		throws SystemException {
		return findByGroupId(groupId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the join organizations where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.JoinOrganizationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of join organizations
	 * @param end the upper bound of the range of join organizations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching join organizations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<JoinOrganization> findByGroupId(long groupId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID;
			finderArgs = new Object[] { groupId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_GROUPID;
			finderArgs = new Object[] { groupId, start, end, orderByComparator };
		}

		List<JoinOrganization> list = (List<JoinOrganization>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (JoinOrganization joinOrganization : list) {
				if ((groupId != joinOrganization.getGroupId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_JOINORGANIZATION_WHERE);

			query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(JoinOrganizationModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(groupId);

				if (!pagination) {
					list = (List<JoinOrganization>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<JoinOrganization>(list);
				}
				else {
					list = (List<JoinOrganization>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first join organization in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching join organization
	 * @throws com.jio.central.services.custom.tables.NoSuchJoinOrganizationException if a matching join organization could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization findByGroupId_First(long groupId,
		OrderByComparator orderByComparator)
		throws NoSuchJoinOrganizationException, SystemException {
		JoinOrganization joinOrganization = fetchByGroupId_First(groupId,
				orderByComparator);

		if (joinOrganization != null) {
			return joinOrganization;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("groupId=");
		msg.append(groupId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchJoinOrganizationException(msg.toString());
	}

	/**
	 * Returns the first join organization in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching join organization, or <code>null</code> if a matching join organization could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization fetchByGroupId_First(long groupId,
		OrderByComparator orderByComparator) throws SystemException {
		List<JoinOrganization> list = findByGroupId(groupId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last join organization in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching join organization
	 * @throws com.jio.central.services.custom.tables.NoSuchJoinOrganizationException if a matching join organization could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization findByGroupId_Last(long groupId,
		OrderByComparator orderByComparator)
		throws NoSuchJoinOrganizationException, SystemException {
		JoinOrganization joinOrganization = fetchByGroupId_Last(groupId,
				orderByComparator);

		if (joinOrganization != null) {
			return joinOrganization;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("groupId=");
		msg.append(groupId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchJoinOrganizationException(msg.toString());
	}

	/**
	 * Returns the last join organization in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching join organization, or <code>null</code> if a matching join organization could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization fetchByGroupId_Last(long groupId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByGroupId(groupId);

		if (count == 0) {
			return null;
		}

		List<JoinOrganization> list = findByGroupId(groupId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the join organizations before and after the current join organization in the ordered set where groupId = &#63;.
	 *
	 * @param joinOrganizationId the primary key of the current join organization
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next join organization
	 * @throws com.jio.central.services.custom.tables.NoSuchJoinOrganizationException if a join organization with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization[] findByGroupId_PrevAndNext(
		long joinOrganizationId, long groupId,
		OrderByComparator orderByComparator)
		throws NoSuchJoinOrganizationException, SystemException {
		JoinOrganization joinOrganization = findByPrimaryKey(joinOrganizationId);

		Session session = null;

		try {
			session = openSession();

			JoinOrganization[] array = new JoinOrganizationImpl[3];

			array[0] = getByGroupId_PrevAndNext(session, joinOrganization,
					groupId, orderByComparator, true);

			array[1] = joinOrganization;

			array[2] = getByGroupId_PrevAndNext(session, joinOrganization,
					groupId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected JoinOrganization getByGroupId_PrevAndNext(Session session,
		JoinOrganization joinOrganization, long groupId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_JOINORGANIZATION_WHERE);

		query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(JoinOrganizationModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(groupId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(joinOrganization);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<JoinOrganization> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the join organizations where groupId = &#63; from the database.
	 *
	 * @param groupId the group ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByGroupId(long groupId) throws SystemException {
		for (JoinOrganization joinOrganization : findByGroupId(groupId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(joinOrganization);
		}
	}

	/**
	 * Returns the number of join organizations where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the number of matching join organizations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByGroupId(long groupId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_GROUPID;

		Object[] finderArgs = new Object[] { groupId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_JOINORGANIZATION_WHERE);

			query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(groupId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_GROUPID_GROUPID_2 = "joinOrganization.groupId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_COMPANYID =
		new FinderPath(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
			JoinOrganizationModelImpl.FINDER_CACHE_ENABLED,
			JoinOrganizationImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByCompanyId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANYID =
		new FinderPath(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
			JoinOrganizationModelImpl.FINDER_CACHE_ENABLED,
			JoinOrganizationImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCompanyId",
			new String[] { Long.class.getName() },
			JoinOrganizationModelImpl.COMPANYID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_COMPANYID = new FinderPath(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
			JoinOrganizationModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCompanyId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the join organizations where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the matching join organizations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<JoinOrganization> findByCompanyId(long companyId)
		throws SystemException {
		return findByCompanyId(companyId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the join organizations where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.JoinOrganizationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of join organizations
	 * @param end the upper bound of the range of join organizations (not inclusive)
	 * @return the range of matching join organizations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<JoinOrganization> findByCompanyId(long companyId, int start,
		int end) throws SystemException {
		return findByCompanyId(companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the join organizations where companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.JoinOrganizationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param companyId the company ID
	 * @param start the lower bound of the range of join organizations
	 * @param end the upper bound of the range of join organizations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching join organizations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<JoinOrganization> findByCompanyId(long companyId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANYID;
			finderArgs = new Object[] { companyId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_COMPANYID;
			finderArgs = new Object[] { companyId, start, end, orderByComparator };
		}

		List<JoinOrganization> list = (List<JoinOrganization>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (JoinOrganization joinOrganization : list) {
				if ((companyId != joinOrganization.getCompanyId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_JOINORGANIZATION_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(JoinOrganizationModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				if (!pagination) {
					list = (List<JoinOrganization>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<JoinOrganization>(list);
				}
				else {
					list = (List<JoinOrganization>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first join organization in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching join organization
	 * @throws com.jio.central.services.custom.tables.NoSuchJoinOrganizationException if a matching join organization could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization findByCompanyId_First(long companyId,
		OrderByComparator orderByComparator)
		throws NoSuchJoinOrganizationException, SystemException {
		JoinOrganization joinOrganization = fetchByCompanyId_First(companyId,
				orderByComparator);

		if (joinOrganization != null) {
			return joinOrganization;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchJoinOrganizationException(msg.toString());
	}

	/**
	 * Returns the first join organization in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching join organization, or <code>null</code> if a matching join organization could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization fetchByCompanyId_First(long companyId,
		OrderByComparator orderByComparator) throws SystemException {
		List<JoinOrganization> list = findByCompanyId(companyId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last join organization in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching join organization
	 * @throws com.jio.central.services.custom.tables.NoSuchJoinOrganizationException if a matching join organization could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization findByCompanyId_Last(long companyId,
		OrderByComparator orderByComparator)
		throws NoSuchJoinOrganizationException, SystemException {
		JoinOrganization joinOrganization = fetchByCompanyId_Last(companyId,
				orderByComparator);

		if (joinOrganization != null) {
			return joinOrganization;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("companyId=");
		msg.append(companyId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchJoinOrganizationException(msg.toString());
	}

	/**
	 * Returns the last join organization in the ordered set where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching join organization, or <code>null</code> if a matching join organization could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization fetchByCompanyId_Last(long companyId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByCompanyId(companyId);

		if (count == 0) {
			return null;
		}

		List<JoinOrganization> list = findByCompanyId(companyId, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the join organizations before and after the current join organization in the ordered set where companyId = &#63;.
	 *
	 * @param joinOrganizationId the primary key of the current join organization
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next join organization
	 * @throws com.jio.central.services.custom.tables.NoSuchJoinOrganizationException if a join organization with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization[] findByCompanyId_PrevAndNext(
		long joinOrganizationId, long companyId,
		OrderByComparator orderByComparator)
		throws NoSuchJoinOrganizationException, SystemException {
		JoinOrganization joinOrganization = findByPrimaryKey(joinOrganizationId);

		Session session = null;

		try {
			session = openSession();

			JoinOrganization[] array = new JoinOrganizationImpl[3];

			array[0] = getByCompanyId_PrevAndNext(session, joinOrganization,
					companyId, orderByComparator, true);

			array[1] = joinOrganization;

			array[2] = getByCompanyId_PrevAndNext(session, joinOrganization,
					companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected JoinOrganization getByCompanyId_PrevAndNext(Session session,
		JoinOrganization joinOrganization, long companyId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_JOINORGANIZATION_WHERE);

		query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(JoinOrganizationModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(companyId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(joinOrganization);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<JoinOrganization> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the join organizations where companyId = &#63; from the database.
	 *
	 * @param companyId the company ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByCompanyId(long companyId) throws SystemException {
		for (JoinOrganization joinOrganization : findByCompanyId(companyId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(joinOrganization);
		}
	}

	/**
	 * Returns the number of join organizations where companyId = &#63;.
	 *
	 * @param companyId the company ID
	 * @return the number of matching join organizations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByCompanyId(long companyId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_COMPANYID;

		Object[] finderArgs = new Object[] { companyId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_JOINORGANIZATION_WHERE);

			query.append(_FINDER_COLUMN_COMPANYID_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_COMPANYID_COMPANYID_2 = "joinOrganization.companyId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_G_S = new FinderPath(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
			JoinOrganizationModelImpl.FINDER_CACHE_ENABLED,
			JoinOrganizationImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByG_S",
			new String[] {
				Long.class.getName(), Integer.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_G_S = new FinderPath(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
			JoinOrganizationModelImpl.FINDER_CACHE_ENABLED,
			JoinOrganizationImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByG_S",
			new String[] { Long.class.getName(), Integer.class.getName() },
			JoinOrganizationModelImpl.GROUPID_COLUMN_BITMASK |
			JoinOrganizationModelImpl.JOINORGANIZATIONSTATUS_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_G_S = new FinderPath(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
			JoinOrganizationModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByG_S",
			new String[] { Long.class.getName(), Integer.class.getName() });

	/**
	 * Returns all the join organizations where groupId = &#63; and joinOrganizationStatus = &#63;.
	 *
	 * @param groupId the group ID
	 * @param joinOrganizationStatus the join organization status
	 * @return the matching join organizations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<JoinOrganization> findByG_S(long groupId,
		int joinOrganizationStatus) throws SystemException {
		return findByG_S(groupId, joinOrganizationStatus, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the join organizations where groupId = &#63; and joinOrganizationStatus = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.JoinOrganizationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param joinOrganizationStatus the join organization status
	 * @param start the lower bound of the range of join organizations
	 * @param end the upper bound of the range of join organizations (not inclusive)
	 * @return the range of matching join organizations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<JoinOrganization> findByG_S(long groupId,
		int joinOrganizationStatus, int start, int end)
		throws SystemException {
		return findByG_S(groupId, joinOrganizationStatus, start, end, null);
	}

	/**
	 * Returns an ordered range of all the join organizations where groupId = &#63; and joinOrganizationStatus = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.JoinOrganizationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param joinOrganizationStatus the join organization status
	 * @param start the lower bound of the range of join organizations
	 * @param end the upper bound of the range of join organizations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching join organizations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<JoinOrganization> findByG_S(long groupId,
		int joinOrganizationStatus, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_G_S;
			finderArgs = new Object[] { groupId, joinOrganizationStatus };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_G_S;
			finderArgs = new Object[] {
					groupId, joinOrganizationStatus,
					
					start, end, orderByComparator
				};
		}

		List<JoinOrganization> list = (List<JoinOrganization>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (JoinOrganization joinOrganization : list) {
				if ((groupId != joinOrganization.getGroupId()) ||
						(joinOrganizationStatus != joinOrganization.getJoinOrganizationStatus())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_JOINORGANIZATION_WHERE);

			query.append(_FINDER_COLUMN_G_S_GROUPID_2);

			query.append(_FINDER_COLUMN_G_S_JOINORGANIZATIONSTATUS_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(JoinOrganizationModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(groupId);

				qPos.add(joinOrganizationStatus);

				if (!pagination) {
					list = (List<JoinOrganization>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<JoinOrganization>(list);
				}
				else {
					list = (List<JoinOrganization>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first join organization in the ordered set where groupId = &#63; and joinOrganizationStatus = &#63;.
	 *
	 * @param groupId the group ID
	 * @param joinOrganizationStatus the join organization status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching join organization
	 * @throws com.jio.central.services.custom.tables.NoSuchJoinOrganizationException if a matching join organization could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization findByG_S_First(long groupId,
		int joinOrganizationStatus, OrderByComparator orderByComparator)
		throws NoSuchJoinOrganizationException, SystemException {
		JoinOrganization joinOrganization = fetchByG_S_First(groupId,
				joinOrganizationStatus, orderByComparator);

		if (joinOrganization != null) {
			return joinOrganization;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("groupId=");
		msg.append(groupId);

		msg.append(", joinOrganizationStatus=");
		msg.append(joinOrganizationStatus);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchJoinOrganizationException(msg.toString());
	}

	/**
	 * Returns the first join organization in the ordered set where groupId = &#63; and joinOrganizationStatus = &#63;.
	 *
	 * @param groupId the group ID
	 * @param joinOrganizationStatus the join organization status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching join organization, or <code>null</code> if a matching join organization could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization fetchByG_S_First(long groupId,
		int joinOrganizationStatus, OrderByComparator orderByComparator)
		throws SystemException {
		List<JoinOrganization> list = findByG_S(groupId,
				joinOrganizationStatus, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last join organization in the ordered set where groupId = &#63; and joinOrganizationStatus = &#63;.
	 *
	 * @param groupId the group ID
	 * @param joinOrganizationStatus the join organization status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching join organization
	 * @throws com.jio.central.services.custom.tables.NoSuchJoinOrganizationException if a matching join organization could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization findByG_S_Last(long groupId,
		int joinOrganizationStatus, OrderByComparator orderByComparator)
		throws NoSuchJoinOrganizationException, SystemException {
		JoinOrganization joinOrganization = fetchByG_S_Last(groupId,
				joinOrganizationStatus, orderByComparator);

		if (joinOrganization != null) {
			return joinOrganization;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("groupId=");
		msg.append(groupId);

		msg.append(", joinOrganizationStatus=");
		msg.append(joinOrganizationStatus);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchJoinOrganizationException(msg.toString());
	}

	/**
	 * Returns the last join organization in the ordered set where groupId = &#63; and joinOrganizationStatus = &#63;.
	 *
	 * @param groupId the group ID
	 * @param joinOrganizationStatus the join organization status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching join organization, or <code>null</code> if a matching join organization could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization fetchByG_S_Last(long groupId,
		int joinOrganizationStatus, OrderByComparator orderByComparator)
		throws SystemException {
		int count = countByG_S(groupId, joinOrganizationStatus);

		if (count == 0) {
			return null;
		}

		List<JoinOrganization> list = findByG_S(groupId,
				joinOrganizationStatus, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the join organizations before and after the current join organization in the ordered set where groupId = &#63; and joinOrganizationStatus = &#63;.
	 *
	 * @param joinOrganizationId the primary key of the current join organization
	 * @param groupId the group ID
	 * @param joinOrganizationStatus the join organization status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next join organization
	 * @throws com.jio.central.services.custom.tables.NoSuchJoinOrganizationException if a join organization with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization[] findByG_S_PrevAndNext(long joinOrganizationId,
		long groupId, int joinOrganizationStatus,
		OrderByComparator orderByComparator)
		throws NoSuchJoinOrganizationException, SystemException {
		JoinOrganization joinOrganization = findByPrimaryKey(joinOrganizationId);

		Session session = null;

		try {
			session = openSession();

			JoinOrganization[] array = new JoinOrganizationImpl[3];

			array[0] = getByG_S_PrevAndNext(session, joinOrganization, groupId,
					joinOrganizationStatus, orderByComparator, true);

			array[1] = joinOrganization;

			array[2] = getByG_S_PrevAndNext(session, joinOrganization, groupId,
					joinOrganizationStatus, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected JoinOrganization getByG_S_PrevAndNext(Session session,
		JoinOrganization joinOrganization, long groupId,
		int joinOrganizationStatus, OrderByComparator orderByComparator,
		boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_JOINORGANIZATION_WHERE);

		query.append(_FINDER_COLUMN_G_S_GROUPID_2);

		query.append(_FINDER_COLUMN_G_S_JOINORGANIZATIONSTATUS_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(JoinOrganizationModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(groupId);

		qPos.add(joinOrganizationStatus);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(joinOrganization);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<JoinOrganization> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the join organizations where groupId = &#63; and joinOrganizationStatus = &#63; from the database.
	 *
	 * @param groupId the group ID
	 * @param joinOrganizationStatus the join organization status
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByG_S(long groupId, int joinOrganizationStatus)
		throws SystemException {
		for (JoinOrganization joinOrganization : findByG_S(groupId,
				joinOrganizationStatus, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
				null)) {
			remove(joinOrganization);
		}
	}

	/**
	 * Returns the number of join organizations where groupId = &#63; and joinOrganizationStatus = &#63;.
	 *
	 * @param groupId the group ID
	 * @param joinOrganizationStatus the join organization status
	 * @return the number of matching join organizations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByG_S(long groupId, int joinOrganizationStatus)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_G_S;

		Object[] finderArgs = new Object[] { groupId, joinOrganizationStatus };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_JOINORGANIZATION_WHERE);

			query.append(_FINDER_COLUMN_G_S_GROUPID_2);

			query.append(_FINDER_COLUMN_G_S_JOINORGANIZATIONSTATUS_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(groupId);

				qPos.add(joinOrganizationStatus);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_G_S_GROUPID_2 = "joinOrganization.groupId = ? AND ";
	private static final String _FINDER_COLUMN_G_S_JOINORGANIZATIONSTATUS_2 = "joinOrganization.joinOrganizationStatus = ?";

	public JoinOrganizationPersistenceImpl() {
		setModelClass(JoinOrganization.class);
	}

	/**
	 * Caches the join organization in the entity cache if it is enabled.
	 *
	 * @param joinOrganization the join organization
	 */
	@Override
	public void cacheResult(JoinOrganization joinOrganization) {
		EntityCacheUtil.putResult(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
			JoinOrganizationImpl.class, joinOrganization.getPrimaryKey(),
			joinOrganization);

		joinOrganization.resetOriginalValues();
	}

	/**
	 * Caches the join organizations in the entity cache if it is enabled.
	 *
	 * @param joinOrganizations the join organizations
	 */
	@Override
	public void cacheResult(List<JoinOrganization> joinOrganizations) {
		for (JoinOrganization joinOrganization : joinOrganizations) {
			if (EntityCacheUtil.getResult(
						JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
						JoinOrganizationImpl.class,
						joinOrganization.getPrimaryKey()) == null) {
				cacheResult(joinOrganization);
			}
			else {
				joinOrganization.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all join organizations.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(JoinOrganizationImpl.class.getName());
		}

		EntityCacheUtil.clearCache(JoinOrganizationImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the join organization.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(JoinOrganization joinOrganization) {
		EntityCacheUtil.removeResult(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
			JoinOrganizationImpl.class, joinOrganization.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<JoinOrganization> joinOrganizations) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (JoinOrganization joinOrganization : joinOrganizations) {
			EntityCacheUtil.removeResult(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
				JoinOrganizationImpl.class, joinOrganization.getPrimaryKey());
		}
	}

	/**
	 * Creates a new join organization with the primary key. Does not add the join organization to the database.
	 *
	 * @param joinOrganizationId the primary key for the new join organization
	 * @return the new join organization
	 */
	@Override
	public JoinOrganization create(long joinOrganizationId) {
		JoinOrganization joinOrganization = new JoinOrganizationImpl();

		joinOrganization.setNew(true);
		joinOrganization.setPrimaryKey(joinOrganizationId);

		return joinOrganization;
	}

	/**
	 * Removes the join organization with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param joinOrganizationId the primary key of the join organization
	 * @return the join organization that was removed
	 * @throws com.jio.central.services.custom.tables.NoSuchJoinOrganizationException if a join organization with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization remove(long joinOrganizationId)
		throws NoSuchJoinOrganizationException, SystemException {
		return remove((Serializable)joinOrganizationId);
	}

	/**
	 * Removes the join organization with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the join organization
	 * @return the join organization that was removed
	 * @throws com.jio.central.services.custom.tables.NoSuchJoinOrganizationException if a join organization with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization remove(Serializable primaryKey)
		throws NoSuchJoinOrganizationException, SystemException {
		Session session = null;

		try {
			session = openSession();

			JoinOrganization joinOrganization = (JoinOrganization)session.get(JoinOrganizationImpl.class,
					primaryKey);

			if (joinOrganization == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchJoinOrganizationException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(joinOrganization);
		}
		catch (NoSuchJoinOrganizationException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected JoinOrganization removeImpl(JoinOrganization joinOrganization)
		throws SystemException {
		joinOrganization = toUnwrappedModel(joinOrganization);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(joinOrganization)) {
				joinOrganization = (JoinOrganization)session.get(JoinOrganizationImpl.class,
						joinOrganization.getPrimaryKeyObj());
			}

			if (joinOrganization != null) {
				session.delete(joinOrganization);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (joinOrganization != null) {
			clearCache(joinOrganization);
		}

		return joinOrganization;
	}

	@Override
	public JoinOrganization updateImpl(
		com.jio.central.services.custom.tables.model.JoinOrganization joinOrganization)
		throws SystemException {
		joinOrganization = toUnwrappedModel(joinOrganization);

		boolean isNew = joinOrganization.isNew();

		JoinOrganizationModelImpl joinOrganizationModelImpl = (JoinOrganizationModelImpl)joinOrganization;

		Session session = null;

		try {
			session = openSession();

			if (joinOrganization.isNew()) {
				session.save(joinOrganization);

				joinOrganization.setNew(false);
			}
			else {
				session.merge(joinOrganization);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !JoinOrganizationModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((joinOrganizationModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						joinOrganizationModelImpl.getOriginalGroupId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_GROUPID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID,
					args);

				args = new Object[] { joinOrganizationModelImpl.getGroupId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_GROUPID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID,
					args);
			}

			if ((joinOrganizationModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANYID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						joinOrganizationModelImpl.getOriginalCompanyId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_COMPANYID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANYID,
					args);

				args = new Object[] { joinOrganizationModelImpl.getCompanyId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_COMPANYID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_COMPANYID,
					args);
			}

			if ((joinOrganizationModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_G_S.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						joinOrganizationModelImpl.getOriginalGroupId(),
						joinOrganizationModelImpl.getOriginalJoinOrganizationStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_G_S, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_G_S,
					args);

				args = new Object[] {
						joinOrganizationModelImpl.getGroupId(),
						joinOrganizationModelImpl.getJoinOrganizationStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_G_S, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_G_S,
					args);
			}
		}

		EntityCacheUtil.putResult(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
			JoinOrganizationImpl.class, joinOrganization.getPrimaryKey(),
			joinOrganization);

		return joinOrganization;
	}

	protected JoinOrganization toUnwrappedModel(
		JoinOrganization joinOrganization) {
		if (joinOrganization instanceof JoinOrganizationImpl) {
			return joinOrganization;
		}

		JoinOrganizationImpl joinOrganizationImpl = new JoinOrganizationImpl();

		joinOrganizationImpl.setNew(joinOrganization.isNew());
		joinOrganizationImpl.setPrimaryKey(joinOrganization.getPrimaryKey());

		joinOrganizationImpl.setJoinOrganizationId(joinOrganization.getJoinOrganizationId());
		joinOrganizationImpl.setJoinOrganizationName(joinOrganization.getJoinOrganizationName());
		joinOrganizationImpl.setDescription(joinOrganization.getDescription());
		joinOrganizationImpl.setJoinOrganizationStatus(joinOrganization.getJoinOrganizationStatus());
		joinOrganizationImpl.setStatusByUserId(joinOrganization.getStatusByUserId());
		joinOrganizationImpl.setStatusDate(joinOrganization.getStatusDate());
		joinOrganizationImpl.setCompanyId(joinOrganization.getCompanyId());
		joinOrganizationImpl.setGroupId(joinOrganization.getGroupId());
		joinOrganizationImpl.setUserId(joinOrganization.getUserId());
		joinOrganizationImpl.setOrganizaId(joinOrganization.getOrganizaId());
		joinOrganizationImpl.setCreateDate(joinOrganization.getCreateDate());

		return joinOrganizationImpl;
	}

	/**
	 * Returns the join organization with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the join organization
	 * @return the join organization
	 * @throws com.jio.central.services.custom.tables.NoSuchJoinOrganizationException if a join organization with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization findByPrimaryKey(Serializable primaryKey)
		throws NoSuchJoinOrganizationException, SystemException {
		JoinOrganization joinOrganization = fetchByPrimaryKey(primaryKey);

		if (joinOrganization == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchJoinOrganizationException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return joinOrganization;
	}

	/**
	 * Returns the join organization with the primary key or throws a {@link com.jio.central.services.custom.tables.NoSuchJoinOrganizationException} if it could not be found.
	 *
	 * @param joinOrganizationId the primary key of the join organization
	 * @return the join organization
	 * @throws com.jio.central.services.custom.tables.NoSuchJoinOrganizationException if a join organization with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization findByPrimaryKey(long joinOrganizationId)
		throws NoSuchJoinOrganizationException, SystemException {
		return findByPrimaryKey((Serializable)joinOrganizationId);
	}

	/**
	 * Returns the join organization with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the join organization
	 * @return the join organization, or <code>null</code> if a join organization with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		JoinOrganization joinOrganization = (JoinOrganization)EntityCacheUtil.getResult(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
				JoinOrganizationImpl.class, primaryKey);

		if (joinOrganization == _nullJoinOrganization) {
			return null;
		}

		if (joinOrganization == null) {
			Session session = null;

			try {
				session = openSession();

				joinOrganization = (JoinOrganization)session.get(JoinOrganizationImpl.class,
						primaryKey);

				if (joinOrganization != null) {
					cacheResult(joinOrganization);
				}
				else {
					EntityCacheUtil.putResult(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
						JoinOrganizationImpl.class, primaryKey,
						_nullJoinOrganization);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(JoinOrganizationModelImpl.ENTITY_CACHE_ENABLED,
					JoinOrganizationImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return joinOrganization;
	}

	/**
	 * Returns the join organization with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param joinOrganizationId the primary key of the join organization
	 * @return the join organization, or <code>null</code> if a join organization with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public JoinOrganization fetchByPrimaryKey(long joinOrganizationId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)joinOrganizationId);
	}

	/**
	 * Returns all the join organizations.
	 *
	 * @return the join organizations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<JoinOrganization> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the join organizations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.JoinOrganizationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of join organizations
	 * @param end the upper bound of the range of join organizations (not inclusive)
	 * @return the range of join organizations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<JoinOrganization> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the join organizations.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jio.central.services.custom.tables.model.impl.JoinOrganizationModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of join organizations
	 * @param end the upper bound of the range of join organizations (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of join organizations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<JoinOrganization> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<JoinOrganization> list = (List<JoinOrganization>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_JOINORGANIZATION);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_JOINORGANIZATION;

				if (pagination) {
					sql = sql.concat(JoinOrganizationModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<JoinOrganization>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<JoinOrganization>(list);
				}
				else {
					list = (List<JoinOrganization>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the join organizations from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (JoinOrganization joinOrganization : findAll()) {
			remove(joinOrganization);
		}
	}

	/**
	 * Returns the number of join organizations.
	 *
	 * @return the number of join organizations
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_JOINORGANIZATION);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the join organization persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.jio.central.services.custom.tables.model.JoinOrganization")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<JoinOrganization>> listenersList = new ArrayList<ModelListener<JoinOrganization>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<JoinOrganization>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(JoinOrganizationImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_JOINORGANIZATION = "SELECT joinOrganization FROM JoinOrganization joinOrganization";
	private static final String _SQL_SELECT_JOINORGANIZATION_WHERE = "SELECT joinOrganization FROM JoinOrganization joinOrganization WHERE ";
	private static final String _SQL_COUNT_JOINORGANIZATION = "SELECT COUNT(joinOrganization) FROM JoinOrganization joinOrganization";
	private static final String _SQL_COUNT_JOINORGANIZATION_WHERE = "SELECT COUNT(joinOrganization) FROM JoinOrganization joinOrganization WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "joinOrganization.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No JoinOrganization exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No JoinOrganization exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(JoinOrganizationPersistenceImpl.class);
	private static JoinOrganization _nullJoinOrganization = new JoinOrganizationImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<JoinOrganization> toCacheModel() {
				return _nullJoinOrganizationCacheModel;
			}
		};

	private static CacheModel<JoinOrganization> _nullJoinOrganizationCacheModel = new CacheModel<JoinOrganization>() {
			@Override
			public JoinOrganization toEntityModel() {
				return _nullJoinOrganization;
			}
		};
}