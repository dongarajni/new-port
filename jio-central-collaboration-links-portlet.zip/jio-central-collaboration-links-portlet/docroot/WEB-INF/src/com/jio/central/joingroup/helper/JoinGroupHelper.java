package com.jio.central.joingroup.helper;


import com.jio.central.collaboration.util.JioCentralUtil;
import com.jio.central.constants.Consts;
import com.jio.central.services.custom.tables.model.JoinOrganization;
import com.jio.central.services.custom.tables.service.JoinOrganizationLocalServiceUtil;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.NoSuchWorkflowDefinitionLinkException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.kernel.workflow.WorkflowHandlerRegistryUtil;
import com.liferay.portal.model.Organization;
import com.liferay.portal.model.User;
import com.liferay.portal.model.WorkflowDefinitionLink;
import com.liferay.portal.service.OrganizationLocalServiceUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.service.WorkflowDefinitionLinkLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.asset.service.AssetEntryLocalServiceUtil;

import java.io.IOException;
import java.io.PrintWriter;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class JoinGroupHelper {
	private static Log _log = LogFactoryUtil.getLog(JoinGroupHelper.class);
	
	public static void initiateJoinRequest(ActionRequest actionRequest,
			ActionResponse actionResponse) {
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest
				.getAttribute(WebKeys.THEME_DISPLAY);
		
		String str = ParamUtil.getString(actionRequest, "orgName");
		String[] st = str.split(StringPool.COLON);

		long orgId = Long.parseLong(st[0]);

		ServiceContext serviceContext = null;
		try {
			serviceContext = ServiceContextFactory.getInstance(
					JoinOrganization.class.getName(), actionRequest);
		} catch (Exception e) {
			_log.error("exception occured :" + e.getMessage());
		} 
		try {
			User user = themeDisplay.getUser();
			String description = "";
			description = user.getFullName() + " has requested to join "+ st[1] + " group.";

			Organization requestedOrg = OrganizationLocalServiceUtil.getOrganization(orgId);
			
			JoinOrganization joinOrganization = JoinOrganizationLocalServiceUtil
					.createJoinOrganization(CounterLocalServiceUtil.increment());
			joinOrganization.setCompanyId(themeDisplay.getCompanyId());
			joinOrganization.setGroupId(requestedOrg.getGroupId());
			joinOrganization.setJoinOrganizationName(st[1]);
			joinOrganization.setDescription(description);
			joinOrganization.setOrganizaId(orgId);
			joinOrganization
			.setJoinOrganizationStatus(WorkflowConstants.STATUS_DRAFT);
			joinOrganization.setUserId(themeDisplay.getUserId());
			joinOrganization.setStatusByUserId(themeDisplay.getUserId());
			joinOrganization = JoinOrganizationLocalServiceUtil
					.addJoinOrganization(joinOrganization);
			
			WorkflowDefinitionLink workflowDefinitionLink = null;
			try {
				workflowDefinitionLink = WorkflowDefinitionLinkLocalServiceUtil
						.getDefaultWorkflowDefinitionLink(
								themeDisplay.getCompanyId(),
								JoinOrganization.class.getName(), 0, 0);

			} catch (Exception e) {
				if (e instanceof NoSuchWorkflowDefinitionLinkException) {
					_log.error("exception occured :" + e.getMessage());
					SessionMessages.add(actionRequest.getPortletSession(),
							"workflow-not-enabled");
				}
				_log.error("exception occured :" + e.getMessage());
			}
			// checking workflow defintion is enabled to joinOrganization asset
			// or not
			if (joinOrganization != null && workflowDefinitionLink != null) {

				// add joinOrganization asset in asset entry table
				AssetEntryLocalServiceUtil.updateEntry(
						themeDisplay.getUserId(),
						joinOrganization.getGroupId(),
						JoinOrganization.class.getName(),
						joinOrganization.getJoinOrganizationId(),
						serviceContext.getAssetCategoryIds(),
						serviceContext.getAssetTagNames());
				// start workflow instance to joinOrganization.
				WorkflowHandlerRegistryUtil.startWorkflowInstance(
						joinOrganization.getCompanyId(),
						joinOrganization.getGroupId(),
						themeDisplay.getUserId(),
						JoinOrganization.class.getName(),
						joinOrganization.getPrimaryKey(), joinOrganization,
						serviceContext);
				
				long toUserId = requestedOrg.getUserId();
				if(Validator.isNotNull(toUserId)){
					User toUser = UserLocalServiceUtil.getUser(toUserId);
					_log.debug("Join group request initiated by user");
					JioCentralUtil.sendJoinGroupMail(Consts.FROM_ADDRESS,toUser.getEmailAddress(),toUser.getFirstName(),
							description,Consts.EMAIL_SUBJECT_JOIN_GROUP,Consts.EMAIL_BODY_JOIN_GROUP);
					
				}
			}
			if (joinOrganization == null) {
				_log.error("Join group request failed!");
				SessionErrors.add(actionRequest,
						"joinOrganization-submit-failed");
			} else {
				_log.info("Join group request sent! " );
				SessionMessages.add(actionRequest,
						"joinOrganization-submit-success");
			}
		} catch (Exception e) {
			if (e instanceof NoSuchWorkflowDefinitionLinkException) {
				SessionMessages.add(actionRequest.getPortletSession(),
						"workflow-not-enabled");
				SessionErrors.add(actionRequest, "join-request-failed");
			}
			_log.error("exception occured :" + e.getMessage());
		}
		
		try {
			HttpServletRequest originalRequest = PortalUtil.getHttpServletRequest(actionRequest);
			String referer = originalRequest.getHeader("Referer");
			actionResponse.sendRedirect(referer);
			SessionMessages.add(originalRequest, "join-request-success");
		} catch (IOException e) {
			SessionErrors.add(actionRequest, "join-request-failed");
			_log.error("exception occured :" + e.getMessage());
		}
		
	}

	public static void initiateJoinRequest(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse) {

		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest
				.getAttribute(WebKeys.THEME_DISPLAY);

		String str = ParamUtil.getString(resourceRequest, "orgName");
		String[] st = str.split(StringPool.COLON);

		long orgId = Long.parseLong(st[0]);

		ServiceContext serviceContext = null;
		try {
			serviceContext = ServiceContextFactory.getInstance(
					JoinOrganization.class.getName(), resourceRequest);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		try {
			User user = themeDisplay.getUser();
			String description = user.getFullName() + " has requested to join "+ st[1] + " group.";

			JoinOrganization joinOrganization = JoinOrganizationLocalServiceUtil
					.createJoinOrganization(CounterLocalServiceUtil.increment());
			joinOrganization.setCompanyId(themeDisplay.getCompanyId());
			joinOrganization.setGroupId(themeDisplay.getScopeGroupId());
			joinOrganization.setJoinOrganizationName(st[1]);
			joinOrganization.setDescription(description);
			joinOrganization.setOrganizaId(orgId);
			joinOrganization
			.setJoinOrganizationStatus(WorkflowConstants.STATUS_DRAFT);
			joinOrganization.setUserId(themeDisplay.getUserId());
			joinOrganization.setStatusByUserId(themeDisplay.getUserId());
			joinOrganization = JoinOrganizationLocalServiceUtil
					.addJoinOrganization(joinOrganization);
			WorkflowDefinitionLink workflowDefinitionLink = null;
			try {
				workflowDefinitionLink = WorkflowDefinitionLinkLocalServiceUtil
						.getDefaultWorkflowDefinitionLink(
								themeDisplay.getCompanyId(),
								JoinOrganization.class.getName(), 0, 0);

			} catch (Exception e) {
				if (e instanceof NoSuchWorkflowDefinitionLinkException) {
					SessionMessages.add(resourceRequest.getPortletSession(),
							"workflow-not-enabled");
				}
				e.printStackTrace();
			}
			// checking workflow defintion is enabled to joinOrganization asset
			// or not
			if (joinOrganization != null && workflowDefinitionLink != null) {

				// add joinOrganization asset in asset entry table
				AssetEntryLocalServiceUtil.updateEntry(
						themeDisplay.getUserId(),
						joinOrganization.getGroupId(),
						JoinOrganization.class.getName(),
						joinOrganization.getJoinOrganizationId(),
						serviceContext.getAssetCategoryIds(),
						serviceContext.getAssetTagNames());
				// start workflow instance to joinOrganization.
				WorkflowHandlerRegistryUtil.startWorkflowInstance(
						joinOrganization.getCompanyId(),
						joinOrganization.getGroupId(),
						themeDisplay.getUserId(),
						JoinOrganization.class.getName(),
						joinOrganization.getPrimaryKey(), joinOrganization,
						serviceContext);
			}
			if (joinOrganization == null) {
				SessionErrors.add(resourceRequest,
						"joinOrganization-submit-failed");
			} else {
				
				SessionMessages.add(resourceRequest,
						"joinOrganization-submit-success");
				
				PrintWriter printout = resourceResponse.getWriter();
				printout.println(HttpServletResponse.SC_OK);   
			}
		} catch (Exception e) {
			if (e instanceof NoSuchWorkflowDefinitionLinkException) {
				SessionMessages.add(resourceRequest.getPortletSession(),
						"workflow-not-enabled");
				PrintWriter printout;
				try {
					printout = resourceResponse.getWriter();
					printout.println(HttpServletResponse.SC_FORBIDDEN);   
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			e.printStackTrace();
		}
	
	}

}
