package com.jio.central.links.controller;

import com.jio.central.bean.JioCentralLinksBean;
import com.jio.central.collaboration.util.MenuWallConstants;
import com.jio.central.joingroup.helper.JoinGroupHelper;
import com.liferay.portal.NoSuchLayoutException;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.ProjectionFactoryUtil;
import com.liferay.portal.kernel.dao.orm.ProjectionList;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.LiferayWindowState;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalClassLoaderUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.model.Group;
import com.liferay.portal.model.Layout;
import com.liferay.portal.model.LayoutSet;
import com.liferay.portal.model.Organization;
import com.liferay.portal.model.User;
import com.liferay.portal.model.UserConstants;
import com.liferay.portal.service.GroupLocalServiceUtil;
import com.liferay.portal.service.LayoutLocalServiceUtil;
import com.liferay.portal.service.LayoutSetLocalServiceUtil;
import com.liferay.portal.service.OrganizationLocalServiceUtil;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portal.util.comparator.OrganizationNameComparator;
import com.liferay.portal.util.comparator.UserFirstNameComparator;
import com.liferay.portal.webserver.WebServerServletTokenUtil;
import com.liferay.portlet.PortletURLFactoryUtil;
import com.liferay.portlet.messageboards.model.MBBan;
import com.liferay.portlet.messageboards.service.MBBanLocalServiceUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletMode;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.portlet.PortletSession;
import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.portlet.WindowStateException;
import javax.servlet.http.HttpServletRequest;

public class JioCentralLinksPortlet extends MVCPortlet{
	
	private static Log _log = LogFactoryUtil.getLog(JioCentralLinksPortlet.class);
	@Override
	public void render(RenderRequest renderRequest,
			RenderResponse renderResponse) throws IOException, PortletException {
		// TODO Auto-generated method stub
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		String viewType = renderRequest.getParameter(MenuWallConstants.TRIGGER_VIEW_TYPE);
		String loggedInUser = renderRequest.getParameter(MenuWallConstants.LOGGED_IN_USER);
		PortletPreferences preferences = (PortletPreferences) renderRequest.getPreferences();
		PortletSession portletSession = renderRequest.getPortletSession(); 
		if(Validator.isNull(viewType)){
			renderRequest.setAttribute("viewType", "IPC");
			preferences.setValue("userGroup", "seachOrgUserGroup");
		}
		if(Validator.isNotNull(viewType) && viewType.equalsIgnoreCase(MenuWallConstants.ATTR_PEOPLE)){
			viewType = StringUtil.replace(viewType, viewType,"user");
			preferences.setValue("userGroup", viewType);
			portletSession.setAttribute("viewType", viewType,PortletSession.PORTLET_SCOPE);
			renderRequest.setAttribute("viewType", viewType);
		} else if(Validator.isNotNull(viewType) && viewType.equalsIgnoreCase(MenuWallConstants.ATTR_MY_GROUPS)){
			viewType = StringUtil.replace(viewType, viewType, "orgGroup");
			preferences.setValue("userGroup", viewType);
			portletSession.setAttribute("viewType", viewType,PortletSession.PORTLET_SCOPE);
			renderRequest.setAttribute("viewType", viewType);
		} else if(Validator.isNotNull(viewType) && viewType.equalsIgnoreCase(MenuWallConstants.ATTR_OWN_GROUPS)){
			viewType = StringUtil.replace(viewType, viewType, "ownOrgGroup");
			preferences.setValue("userGroup", viewType);
			portletSession.setAttribute("viewType", viewType,PortletSession.PORTLET_SCOPE);
			renderRequest.setAttribute("viewType", viewType);
			renderRequest.setAttribute("ownGroup", "ownGroup");
			
			getOwnGroup(renderRequest, renderResponse, themeDisplay);
		} 
		preferences.store();
		
		getPostMessageFriendlyUrl(renderRequest, themeDisplay);
		renderRequest.setAttribute("loggedInUser", loggedInUser);
		super.render(renderRequest, renderResponse);
	}

	private void getOwnGroup(RenderRequest renderRequest,
			RenderResponse renderResponse, ThemeDisplay themeDisplay) throws IOException {
		// TODO Auto-generated method stub
		long ownUserId = ParamUtil.getLong(renderRequest, MenuWallConstants.LOGGED_IN_USER);
		List<Organization> ownOrgLists = null;
		List<MBBan> banUserLists = new ArrayList<MBBan>();
		List<Long> banUserIdList = new ArrayList<Long>();
		JioCentralLinksBean jioCentralLinksBean = null;
		User user;
		List<Organization> userOrgLists = new ArrayList<Organization>();
		List<Organization> myOrgLists = new ArrayList<Organization>();
    	try {
    		user = UserLocalServiceUtil.getUser(ownUserId); 
			myOrgLists = user.getOrganizations();
		} catch (PortalException e2) {
			_log.info("Error while getting user's organization lists" +e2.getMessage());
		} catch (SystemException e2) {
			_log.info("Error while getting user's organization lists" +e2.getMessage());
		}
	    
		List<JioCentralLinksBean> ownGroupLists = new ArrayList<JioCentralLinksBean>();
		DynamicQuery userQuery = DynamicQueryFactoryUtil.forClass(Organization.class,PortalClassLoaderUtil.getClassLoader());
		Criterion criterion =  RestrictionsFactoryUtil.eq("userId", new Long(ownUserId));
		userQuery.add(criterion);
		
		try {
			ownOrgLists = OrganizationLocalServiceUtil.dynamicQuery(userQuery);
			userOrgLists.addAll(myOrgLists);
			userOrgLists.addAll(ownOrgLists);
			
			Set<Organization> orgSet =  SetUtil.fromCollection(userOrgLists);
			for (Organization orgGroup : orgSet) {
				jioCentralLinksBean = new JioCentralLinksBean();
				banUserLists = MBBanLocalServiceUtil.getMBBans(QueryUtil.ALL_POS, QueryUtil.ALL_POS);
				for (MBBan mbBan : banUserLists) {
					if(Validator.isNotNull(mbBan)){
						banUserIdList.add(mbBan.getBanUserId());
					}
				}
			
	    		long logoId = orgGroup.getLogoId();
	    		
	    		Group organizationGroup = GroupLocalServiceUtil.getOrganizationGroup(themeDisplay.getCompanyId(), orgGroup.getOrganizationId());
	    		LayoutSet siblingLayoutSet = LayoutSetLocalServiceUtil.getLayoutSet(organizationGroup.getGroupId(), true);
					if (siblingLayoutSet.getLogoId() > 0) {
						logoId = siblingLayoutSet.getLogoId();
					}
					StringBundler sb = new StringBundler(5);
					String imagePath=PortalUtil.getPathImage();
					sb.append(imagePath);
					sb.append("/logo?img_id=");
					sb.append(logoId);
					sb.append("&t=");
					sb.append(WebServerServletTokenUtil.getToken(orgGroup.getLogoId()));
					
					PortletSession portletSession = renderRequest.getPortletSession();
					
					String viewType = (String) portletSession.getAttribute("viewType", PortletSession.PORTLET_SCOPE);
					//String viewType = (String) renderRequest.getAttribute("viewType");
					
					String dataURL = themeDisplay.getPortalURL() + themeDisplay.getPathFriendlyURLPrivateGroup() + orgGroup.getGroup().getFriendlyURL();
		    		int orgUsers =  UserLocalServiceUtil.getOrganizationUsersCount(orgGroup.getOrganizationId(), WorkflowConstants.STATUS_APPROVED);
		    		jioCentralLinksBean.setUserName(orgGroup.getName());
		    		jioCentralLinksBean.setOrgUsersCount(orgUsers);
		    		jioCentralLinksBean.setUserId(orgGroup.getUserId());
		    		jioCentralLinksBean.setUserImageURL(sb.toString());
		    		jioCentralLinksBean.setOwnerName(orgGroup.getUserName());
		    		jioCentralLinksBean.setGroupName(orgGroup.toString());
		    		jioCentralLinksBean.setViewType(viewType);
		    		jioCentralLinksBean.setDataURL(dataURL);
		    		jioCentralLinksBean.setOrgUserGroup(true);
		    		
		    		boolean isMember =  UserLocalServiceUtil.hasOrganizationUser( orgGroup.getOrganizationId(),themeDisplay.getUserId());
		    		
		    		if (isMember) {
		    			jioCentralLinksBean.setIsOrgMember("1");
					} else {
						jioCentralLinksBean.setIsOrgMember("0");
					} 	    		
		    		ownGroupLists.add(jioCentralLinksBean);
	    	}
	    	
		} catch (SystemException e1) {
			_log.error("Error while getting Organizations::> "+ e1.getMessage());
		}  catch (PortalException e1) {
			_log.error("Error while getting Organizations::> "+ e1.getMessage());
		}
	    renderRequest.setAttribute("ownGroupLists", ownGroupLists);
	}

	private void getPostMessageFriendlyUrl(RenderRequest renderRequest,
			ThemeDisplay themeDisplay) {
		
		long plId =  0L;
		try {
			String userSite = PropsUtil.get("jio.central.collaboration.user.site");
			Group userSiteGroup = GroupLocalServiceUtil.getGroup(themeDisplay.getCompanyId(), userSite);
			String friendlyURL =  "/message";
			Layout layout = LayoutLocalServiceUtil.getFriendlyURLLayout(userSiteGroup.getGroupId(), true, friendlyURL);
			String lastURL = themeDisplay.getPortalURL()+themeDisplay.getPathFriendlyURLPublic()+layout.getGroup().getFriendlyURL()+layout.getFriendlyURL();
			plId =  layout.getPlid();
			renderRequest.setAttribute("lastURL", lastURL);
			renderRequest.setAttribute("plId", plId);
		} catch (NoSuchLayoutException e) {
			e.getMessage();
		} catch (SystemException e) {
			e.getMessage();
		} catch (PortalException e) {
			e.getMessage();
		}
	}
	
	public void saveSearchPreference(ActionRequest actionRequest,ActionResponse actionResponse) throws IOException, PortletException, SystemException, PortalException {
		
		String userGroup = ParamUtil.getString(actionRequest, "userGroup");
		PortletPreferences preferences = (PortletPreferences) actionRequest.getPreferences();
		preferences.setValue("userGroup", userGroup);
		preferences.store();
		SessionMessages.add(actionRequest, "preference-saved");
		actionRequest.setAttribute("viewType", userGroup);
		actionResponse.setPortletMode(PortletMode.EDIT);
	}
	
	public void searchUserGroup(ActionRequest actionRequest, ActionResponse actionResponse){
		HttpServletRequest servletRequest = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(actionRequest));
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		String keyword = ParamUtil.getString(servletRequest, "homesearch_keyword");
		getUsersByFirstCharQuery(themeDisplay, keyword);
	}
	
	private static List<User> getUsersByFirstCharQuery(ThemeDisplay themeDisplay,String firstChar) {
		
		List<User> charUsers = new ArrayList<User>();
		try {
			DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(User.class, PortalClassLoaderUtil.getClassLoader());
			dynamicQuery.add(PropertyFactoryUtil.forName("firstName").like(firstChar+StringPool.PERCENT));
			charUsers = UserLocalServiceUtil.dynamicQuery(dynamicQuery, QueryUtil.ALL_POS, QueryUtil.ALL_POS, new UserFirstNameComparator(true));
		} catch (SystemException e) {
		  _log.error("Error while getting user ::> "+ e.getMessage());
		}
		return charUsers;
	}
	
	@Override
	public void serveResource(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse) throws IOException,
			PortletException {
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);
	    String keyWords = (String)resourceRequest.getParameter("keyword");
	    
	    PortletPreferences preferences = (PortletPreferences) resourceRequest.getPreferences();
	    
		if(preferences.getValue("userGroup", "").equalsIgnoreCase("orgGroup")){
			getOrgUserGroups(resourceRequest, resourceResponse, themeDisplay, keyWords);
		} else if(preferences.getValue("userGroup", "").equalsIgnoreCase("user")){
			getUsers(resourceRequest, resourceResponse, themeDisplay, keyWords);
		} else if (preferences.getValue("userGroup", "").equalsIgnoreCase("seachOrgUserGroup")){
			getUsersandOrgUserGroups(resourceRequest, resourceResponse, themeDisplay, keyWords);
		} else if (preferences.getValue("userGroup", "").equalsIgnoreCase("ownOrgGroup")){
			getOwnOrgUserGroups(resourceRequest, resourceResponse, themeDisplay, keyWords);
		}
		resourceRequest.setAttribute("viewType", "IPC"); 
		super.serveResource(resourceRequest, resourceResponse);
	}
	
	private void getUsersandOrgUserGroups(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse, ThemeDisplay themeDisplay,
			String keyWords) throws IOException {
		
		DynamicQuery orgQuery = DynamicQueryFactoryUtil.forClass(Organization.class,PortalClassLoaderUtil.getClassLoader());
		Criterion orgCriterion = RestrictionsFactoryUtil.ilike("name",StringPool.PERCENT + keyWords + StringPool.PERCENT);
		orgQuery.add(orgCriterion);
		
		DynamicQuery userQuery = DynamicQueryFactoryUtil.forClass(User.class,"user",PortalClassLoaderUtil.getClassLoader());
		Criterion criterion = RestrictionsFactoryUtil.ilike("user.screenName",StringPool.PERCENT + keyWords + StringPool.PERCENT);
		criterion = RestrictionsFactoryUtil.or(criterion, RestrictionsFactoryUtil.ilike("user.emailAddress", StringPool.PERCENT + keyWords + StringPool.PERCENT));
		userQuery.add(criterion);
		
		ProjectionList projectionList = ProjectionFactoryUtil.projectionList();
		projectionList.add(PropertyFactoryUtil.forName("user.userId"));
		projectionList.add(PropertyFactoryUtil.forName("user.screenName"));
		projectionList.add(PropertyFactoryUtil.forName("user.emailAddress"));
		projectionList.add(PropertyFactoryUtil.forName("user.status"));
		projectionList.add(PropertyFactoryUtil.forName("user.portraitId"));
		projectionList.add(PropertyFactoryUtil.forName("user.firstName"));
		projectionList.add(PropertyFactoryUtil.forName("user.lastName"));
		userQuery.setProjection(projectionList);
		
	    if(Validator.isNotNull(keyWords)){
		
		JSONArray joCategory = JSONFactoryUtil.createJSONArray();
		List<MBBan> banUserLists = new ArrayList<MBBan>();
		List<Long> banUserIdList = new ArrayList<Long>();
		JSONObject jsonobjUser = null;
		try {
			List<Object[]> userList = UserLocalServiceUtil.dynamicQuery(userQuery);
	    	for(Object[] users : userList){
				
    		 jsonobjUser = JSONFactoryUtil.createJSONObject();
	    		
				String imageURL = UserConstants.getPortraitURL(themeDisplay.getPathImage(), true, Long.valueOf(String.valueOf(users[4])));
				PortletSession portletSession = resourceRequest.getPortletSession();
				String viewType = (String) portletSession.getAttribute("viewType", PortletSession.PORTLET_SCOPE);
	    		
	    		String siteURL = PropsUtil.get("jio.central.collaboration.user.site");
	    		Group group = GroupLocalServiceUtil.getGroup(themeDisplay.getCompanyId(), siteURL);
	    		String dataURL = themeDisplay.getPortalURL() + themeDisplay.getPathFriendlyURLPrivateGroup() + group.getFriendlyURL() + StringPool.QUESTION + MenuWallConstants.LOGGED_IN_USER + StringPool.EQUAL + String.valueOf(users[0]);
	    		
	    		jsonobjUser.put("orgUserGrp", false);
	    		jsonobjUser.put("userId", String.valueOf(users[0]));
	    		//jsonobjUser.put("userName", String.valueOf(users[5])+StringPool.SPACE+String.valueOf(users[6]));
	    		User user = UserLocalServiceUtil.getUser((Long)users[0]);
	    		if(Validator.isNotNull(user))
	    			jsonobjUser.put("userName", user.getFullName());
	    		else {
	    			jsonobjUser.put("userName", String.valueOf(users[5]));
	    		}  
	    		jsonobjUser.put("imageSrc", imageURL);
	    		jsonobjUser.put("viewType", viewType);
	    		jsonobjUser.put("dataURL", dataURL);
	    		joCategory.put(jsonobjUser);
	    	}
		
		List<Organization> orgGroupLists = OrganizationLocalServiceUtil.dynamicQuery(orgQuery);
		    	for(Organization orgGroup : orgGroupLists){
					banUserLists = MBBanLocalServiceUtil.getMBBans(QueryUtil.ALL_POS, QueryUtil.ALL_POS);
					for (MBBan mbBan : banUserLists) {
						if(Validator.isNotNull(mbBan)){
							banUserIdList.add(mbBan.getBanUserId());
						}
					}
				
		    		jsonobjUser = JSONFactoryUtil.createJSONObject();
		    		long logoId = orgGroup.getLogoId();
		    		
		    		Group organizationGroup = GroupLocalServiceUtil.getOrganizationGroup(themeDisplay.getCompanyId(), orgGroup.getOrganizationId());
		    		LayoutSet siblingLayoutSet = LayoutSetLocalServiceUtil.getLayoutSet(organizationGroup.getGroupId(), true);
						if (siblingLayoutSet.getLogoId() > 0) {
							logoId = siblingLayoutSet.getLogoId();
						}
						StringBundler sb = new StringBundler(5);
						String imagePath=PortalUtil.getPathImage();
						sb.append(imagePath);
						sb.append("/logo?img_id=");
						sb.append(logoId);
						sb.append("&t=");
						sb.append(WebServerServletTokenUtil.getToken(orgGroup.getLogoId()));
						
		    		PortletSession portletSession = resourceRequest.getPortletSession();
		    		String viewType = (String) portletSession.getAttribute("viewType", PortletSession.PORTLET_SCOPE);
		    		PortletURL renderURL = PortletURLFactoryUtil.create(resourceRequest, themeDisplay.getPortletDisplay().getId(), themeDisplay.getPlid(), PortletRequest.RENDER_PHASE);
		    		String dataURL = themeDisplay.getPortalURL()+ themeDisplay.getPathFriendlyURLPrivateGroup()+orgGroup.getGroup().getFriendlyURL();
		    		renderURL.setParameter("userId", String.valueOf(orgGroup.getUserId()));
		    		renderURL.setParameter("jspPage", "/html/MainUserDetails/userPopup.jsp");
		    		int orgUsers =  UserLocalServiceUtil.getOrganizationUsersCount(orgGroup.getOrganizationId(), WorkflowConstants.STATUS_APPROVED);
		    		jsonobjUser.put("orgUserGrp", true);
		    		jsonobjUser.put("orgUsers", orgUsers);
		    		jsonobjUser.put("userId", orgGroup.getUserId());
		    		jsonobjUser.put("userName", orgGroup.getName());
		    		jsonobjUser.put("ownerName", orgGroup.getUserName());
		    		jsonobjUser.put("imageSrc", sb.toString());
		    		jsonobjUser.put("viewType", viewType);
		    		
		    		
		    		long loggedInUser = themeDisplay.getUserId();
		    		boolean isMember =  UserLocalServiceUtil.hasOrganizationUser( orgGroup.getOrganizationId(),loggedInUser);
		    		jsonobjUser.put("isMember", isMember);
		    		String joinGroupUrl ="";
		    		if(isMember){
		    			joinGroupUrl = getJoinGroupUrl(orgGroup, false,resourceResponse,themeDisplay);
		    			jsonobjUser.put("dataURL", dataURL);
		    		}else{
		    			joinGroupUrl = getJoinGroupUrl(orgGroup, true, resourceResponse,themeDisplay);
		    			jsonobjUser.put("dataURL", "#");
		    		}
		    		jsonobjUser.put("joinGroupUrl", joinGroupUrl);
		    		joCategory.put(jsonobjUser);
		    	}
			} catch (SystemException e1) {
				_log.error("Error while getting org user ::> "+ e1.getMessage());
			} catch (PortalException e) {
				_log.error("Error while getting org user ::> "+ e.getMessage());
			} catch (WindowStateException e) {
				_log.error("Error while getting join group url::> "+ e.getMessage());
			}
	    
	    PrintWriter printout = resourceResponse.getWriter();
		printout.println(joCategory.toString());   
	    }
	}
	
	private void getOrgUserGroups(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse, ThemeDisplay themeDisplay,
			String keyWords) throws IOException {
		
	    if(Validator.isNotNull(keyWords)){
		DynamicQuery userQuery = DynamicQueryFactoryUtil.forClass(Organization.class,PortalClassLoaderUtil.getClassLoader());
		Criterion criterion = RestrictionsFactoryUtil.ilike("name",StringPool.PERCENT + keyWords + StringPool.PERCENT);
		userQuery.add(criterion);
		
		JSONArray joCategory = JSONFactoryUtil.createJSONArray();
		List<MBBan> banUserLists = new ArrayList<MBBan>();
		List<Long> banUserIdList = new ArrayList<Long>();
		JSONObject jsonobjUser = null;
		try {
			List<Organization> userList = OrganizationLocalServiceUtil.dynamicQuery(userQuery);
		    	for(Organization orgGroup : userList){
					banUserLists = MBBanLocalServiceUtil.getMBBans(QueryUtil.ALL_POS, QueryUtil.ALL_POS);
					for (MBBan mbBan : banUserLists) {
						if(Validator.isNotNull(mbBan)){
							banUserIdList.add(mbBan.getBanUserId());
						}
					}
				
		    		jsonobjUser = JSONFactoryUtil.createJSONObject();
		    		long logoId = orgGroup.getLogoId();
		    		
		    		Group organizationGroup = GroupLocalServiceUtil.getOrganizationGroup(themeDisplay.getCompanyId(), orgGroup.getOrganizationId());
		    		LayoutSet siblingLayoutSet = LayoutSetLocalServiceUtil.getLayoutSet(organizationGroup.getGroupId(), true);
						if (siblingLayoutSet.getLogoId() > 0) {
							logoId = siblingLayoutSet.getLogoId();
						}
						StringBundler sb = new StringBundler(5);
						String imagePath=PortalUtil.getPathImage();
						sb.append(imagePath);
						sb.append("/logo?img_id=");
						sb.append(logoId);
						sb.append("&t=");
						sb.append(WebServerServletTokenUtil.getToken(orgGroup.getLogoId()));
						PortletSession portletSession = resourceRequest.getPortletSession();
						String viewType = (String) portletSession.getAttribute("viewType", PortletSession.PORTLET_SCOPE);
		    		
						PortletURL renderURL = PortletURLFactoryUtil.create(resourceRequest, themeDisplay.getPortletDisplay().getId(), themeDisplay.getPlid(), PortletRequest.RENDER_PHASE);
		    		
			    		renderURL.setParameter("userId", String.valueOf(orgGroup.getUserId()));
			    		renderURL.setParameter("jspPage", "/html/MainUserDetails/userPopup.jsp");
			    		String dataURL = themeDisplay.getPortalURL() + themeDisplay.getPathFriendlyURLPrivateGroup() + orgGroup.getGroup().getFriendlyURL();
			    		int orgUsers =  UserLocalServiceUtil.getOrganizationUsersCount(orgGroup.getOrganizationId(), WorkflowConstants.STATUS_APPROVED);
			    		jsonobjUser.put("orgUserGrp", true);
			    		jsonobjUser.put("orgUsers", orgUsers);
			    		jsonobjUser.put("userId", orgGroup.getUserId());
			    		jsonobjUser.put("userName", orgGroup.getName());
			    		jsonobjUser.put("imageSrc", sb.toString());
			    		jsonobjUser.put("ownerName", orgGroup.getUserName());
			    		jsonobjUser.put("members", orgGroup.toString());
			    		jsonobjUser.put("viewType", viewType);
			    		
			    		long loggedInUser = themeDisplay.getUserId();
			    		boolean isMember =  UserLocalServiceUtil.hasOrganizationUser( orgGroup.getOrganizationId(),loggedInUser);
			    		jsonobjUser.put("isMember", isMember);
			    		String joinGroupUrl ="";
			    		if(isMember){
			    			joinGroupUrl = getJoinGroupUrl(orgGroup, false,resourceResponse,themeDisplay);
			    			jsonobjUser.put("dataURL", dataURL);
			    		}else{
			    			joinGroupUrl = getJoinGroupUrl(orgGroup, true, resourceResponse,themeDisplay);
			    			jsonobjUser.put("dataURL", "#");
			    		}
			    		jsonobjUser.put("joinGroupUrl", joinGroupUrl);
			    		joCategory.put(jsonobjUser);
		    	}
		    	
			} catch (SystemException e1) {
				_log.error("Error while getting Organizations::> "+ e1.getMessage());
			}  catch (PortalException e1) {
				_log.error("Error while getting Organizations::> "+ e1.getMessage());
			} catch (WindowStateException e) {
				_log.error("Error while getting join group url::> "+ e.getMessage());
			}
	    
	    PrintWriter printout = resourceResponse.getWriter();
		printout.println(joCategory.toString());   
	    }
	}
	
	
	private void getOwnOrgUserGroups(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse, ThemeDisplay themeDisplay,
			String keyWords) throws IOException {
		
	    if(Validator.isNotNull(keyWords)){
	    long ownUserId = ParamUtil.getLong(resourceRequest, MenuWallConstants.LOGGED_IN_USER);
	    
		List<Organization> ownOrgLists = null;
		List<MBBan> banUserLists = new ArrayList<MBBan>();
		List<Long> banUserIdList = new ArrayList<Long>();
		User user;
		List<Organization> userOrgLists = new ArrayList<Organization>();
		List<Organization> myOrgLists = new ArrayList<Organization>();
    	try {
    		user = UserLocalServiceUtil.getUser(ownUserId);
			myOrgLists = user.getOrganizations();
		} catch (PortalException e2) {
			_log.info("Error while getting user's organization lists" +e2.getMessage());
		} catch (SystemException e2) {
			_log.info("Error while getting user's organization lists" +e2.getMessage());
		}
	    
    	DynamicQuery userQuery = DynamicQueryFactoryUtil.forClass(Organization.class, "organization",PortalClassLoaderUtil.getClassLoader());
    	userQuery.add(RestrictionsFactoryUtil.and(RestrictionsFactoryUtil.eq("organization.userId",ownUserId), RestrictionsFactoryUtil.like("organization.name", StringPool.PERCENT + keyWords + StringPool.PERCENT)));
    	
    	
		JSONArray joCategory = JSONFactoryUtil.createJSONArray();
		JSONObject jsonobjUser = null;
		try {
			ownOrgLists = OrganizationLocalServiceUtil.dynamicQuery(userQuery);
			userOrgLists.addAll(myOrgLists);
			userOrgLists.addAll(ownOrgLists);
			
//			List<Organization> userList = OrganizationLocalServiceUtil.dynamicQuery(userQuery);
			Set<Organization> orgSet =  SetUtil.fromCollection(userOrgLists);
		    	for(Organization orgGroup : orgSet){
					banUserLists = MBBanLocalServiceUtil.getMBBans(QueryUtil.ALL_POS, QueryUtil.ALL_POS);
					for (MBBan mbBan : banUserLists) {
						if(Validator.isNotNull(mbBan)){
							banUserIdList.add(mbBan.getBanUserId());
						}
					}
				
		    		jsonobjUser = JSONFactoryUtil.createJSONObject();
		    		long logoId = orgGroup.getLogoId();
		    		
		    		Group organizationGroup = GroupLocalServiceUtil.getOrganizationGroup(themeDisplay.getCompanyId(), orgGroup.getOrganizationId());
		    		LayoutSet siblingLayoutSet = LayoutSetLocalServiceUtil.getLayoutSet(organizationGroup.getGroupId(), true);
						if (siblingLayoutSet.getLogoId() > 0) {
							logoId = siblingLayoutSet.getLogoId();
						}
						StringBundler sb = new StringBundler(5);
						String imagePath=PortalUtil.getPathImage();
						sb.append(imagePath);
						sb.append("/logo?img_id=");
						sb.append(logoId);
						sb.append("&t=");
						sb.append(WebServerServletTokenUtil.getToken(orgGroup.getLogoId()));
						PortletSession portletSession = resourceRequest.getPortletSession();
						String viewType = (String) portletSession.getAttribute("viewType", PortletSession.PORTLET_SCOPE);
		    		
						PortletURL renderURL = PortletURLFactoryUtil.create(resourceRequest, themeDisplay.getPortletDisplay().getId(), themeDisplay.getPlid(), PortletRequest.RENDER_PHASE);
		    		
			    		renderURL.setParameter("userId", String.valueOf(orgGroup.getUserId()));
			    		renderURL.setParameter("jspPage", "/html/MainUserDetails/userPopup.jsp");
			    		String dataURL = themeDisplay.getPortalURL() + themeDisplay.getPathFriendlyURLPrivateGroup() + orgGroup.getGroup().getFriendlyURL();
			    		int orgUsers =  UserLocalServiceUtil.getOrganizationUsersCount(orgGroup.getOrganizationId(), WorkflowConstants.STATUS_APPROVED);
			    		jsonobjUser.put("orgUserGrp", true);
			    		jsonobjUser.put("orgUsers", orgUsers);
			    		jsonobjUser.put("userId", orgGroup.getUserId());
			    		jsonobjUser.put("userName", orgGroup.getName());
			    		jsonobjUser.put("imageSrc", sb.toString());
			    		jsonobjUser.put("ownerName", orgGroup.getUserName());
			    		jsonobjUser.put("members", orgGroup.toString());
			    		jsonobjUser.put("viewType", viewType);
			    		
			    		long loggedInUser = themeDisplay.getUserId();
			    		boolean isMember =  UserLocalServiceUtil.hasOrganizationUser( orgGroup.getOrganizationId(),loggedInUser);
			    		jsonobjUser.put("isMember", isMember);
			    		String joinGroupUrl ="";
			    		if(isMember){
			    			joinGroupUrl = getJoinGroupUrl(orgGroup, false,resourceResponse,themeDisplay);
			    			jsonobjUser.put("dataURL", dataURL);
			    		}else{
			    			joinGroupUrl = getJoinGroupUrl(orgGroup, true, resourceResponse,themeDisplay);
			    			jsonobjUser.put("dataURL", "#");
			    		}
			    		jsonobjUser.put("joinGroupUrl", joinGroupUrl);
			    		joCategory.put(jsonobjUser);
		    	}
		    	
			} catch (SystemException e1) {
				_log.error("Error while getting Organizations::> "+ e1.getMessage());
			}  catch (PortalException e1) {
				_log.error("Error while getting Organizations::> "+ e1.getMessage());
			} catch (WindowStateException e) {
				_log.error("Error while getting join group url::> "+ e.getMessage());
			}
	    
	    PrintWriter printout = resourceResponse.getWriter();
		printout.println(joCategory.toString());   
	    }
	}
	
	
	private void getUsers(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse, ThemeDisplay themeDisplay,
			String keyWords) throws IOException {
		
	    if(Validator.isNotNull(keyWords)){
		DynamicQuery userQuery = DynamicQueryFactoryUtil.forClass(User.class,"user",PortalClassLoaderUtil.getClassLoader());
		Criterion criterion = RestrictionsFactoryUtil.ilike("user.screenName",StringPool.PERCENT + keyWords + StringPool.PERCENT);
		criterion = RestrictionsFactoryUtil.or(criterion, RestrictionsFactoryUtil.ilike("user.emailAddress", StringPool.PERCENT + keyWords + StringPool.PERCENT));
		userQuery.add(criterion);
		
		ProjectionList projectionList = ProjectionFactoryUtil.projectionList();
		projectionList.add(PropertyFactoryUtil.forName("user.userId"));
		projectionList.add(PropertyFactoryUtil.forName("user.screenName"));
		projectionList.add(PropertyFactoryUtil.forName("user.emailAddress"));
		projectionList.add(PropertyFactoryUtil.forName("user.status"));
		projectionList.add(PropertyFactoryUtil.forName("user.portraitId"));
		projectionList.add(PropertyFactoryUtil.forName("user.firstName"));
		projectionList.add(PropertyFactoryUtil.forName("user.lastName"));
		userQuery.setProjection(projectionList);
		JSONArray joCategory = JSONFactoryUtil.createJSONArray();
		JSONObject jsonobjUser = null;
		try {
			List<Object[]> userList = UserLocalServiceUtil.dynamicQuery(userQuery);
		    	for(Object[] users : userList){
					
	    		 jsonobjUser = JSONFactoryUtil.createJSONObject();
		    		
					String imageURL = UserConstants.getPortraitURL(themeDisplay.getPathImage(), true, Long.valueOf(String.valueOf(users[4])));
					PortletSession portletSession = resourceRequest.getPortletSession();
					String viewType = (String) portletSession.getAttribute("viewType", PortletSession.PORTLET_SCOPE);
		    		
		    		String siteURL = PropsUtil.get("jio.central.collaboration.user.site");
		    		Group group = GroupLocalServiceUtil.getGroup(themeDisplay.getCompanyId(), siteURL);
		    		String dataURL = themeDisplay.getPortalURL() + themeDisplay.getPathFriendlyURLPrivateGroup() + group.getFriendlyURL() + StringPool.QUESTION + MenuWallConstants.LOGGED_IN_USER + StringPool.EQUAL + String.valueOf(users[0]);
		    		
		    		jsonobjUser.put("orgUserGrp", false);
		    		jsonobjUser.put("userId", String.valueOf(users[0]));
		    		
		    		User user = UserLocalServiceUtil.getUser((Long)users[0]);
		    		if(Validator.isNotNull(user))
		    			jsonobjUser.put("userName", user.getFullName());
		    		else {
		    			jsonobjUser.put("userName", "");
		    		}
		    		jsonobjUser.put("imageSrc", imageURL);
		    		jsonobjUser.put("viewType", viewType);
		    		jsonobjUser.put("dataURL", dataURL);
		    		joCategory.put(jsonobjUser);
		    	}
			} catch (SystemException e1) {
				_log.error("Error while getting user ::> "+ e1.getMessage());
			} catch (PortalException e) {
				_log.error("Error while getting user ::> "+ e.getMessage());
			} 
	    PrintWriter printout = resourceResponse.getWriter();
		printout.println(joCategory.toString());   
	    }
	}
	
	private String getJoinGroupUrl(Organization organization,boolean isJoin, ResourceResponse resourceResponse, ThemeDisplay themeDisplay) throws WindowStateException {
		
		PortletURL actionUrl = resourceResponse.createActionURL();
		
		String orgName = organization.getOrganizationId() + StringPool.COLON + organization.getName();
		actionUrl.setWindowState(LiferayWindowState.MAXIMIZED);
		actionUrl.setParameter("javax.portlet.action", "joinGroupAction");
		actionUrl.setParameter("orgName", orgName);
		actionUrl.setParameter("isJoin", String.valueOf(isJoin));
		
		return actionUrl.toString();
	}
	
	public void joinGroupAction(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		JoinGroupHelper.initiateJoinRequest(actionRequest, actionResponse);
	}
}
