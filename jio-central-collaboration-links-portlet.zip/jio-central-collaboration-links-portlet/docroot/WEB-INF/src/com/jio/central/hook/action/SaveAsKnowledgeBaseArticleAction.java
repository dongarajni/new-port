package com.jio.central.hook.action;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.struts.BaseStrutsPortletAction;
import com.liferay.portal.kernel.struts.StrutsPortletAction;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.FriendlyURLNormalizerUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.journal.model.JournalArticle;
import com.liferay.portlet.journal.service.JournalArticleLocalServiceUtil;

import java.util.regex.Pattern;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletConfig;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

public class SaveAsKnowledgeBaseArticleAction extends BaseStrutsPortletAction{

	private static Log LOGGER = LogFactoryUtil.getLog(SaveAsKnowledgeBaseArticleAction.class);
	private static Pattern _friendlyURLPattern = Pattern.compile("[^a-z0-9_-]");
	
	@Override
	public void processAction(StrutsPortletAction originalStrutsPortletAction,PortletConfig portletConfig,
			ActionRequest actionRequest, ActionResponse actionResponse)
			throws Exception {
		LOGGER.info("====== call article process action =====");
		ThemeDisplay themeDisplay = (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		
		
		boolean validateTag = isValidateTag(actionRequest);
		
		if(validateTag){
			//get Title
			UploadPortletRequest uploadPortletRequest = PortalUtil.getUploadPortletRequest(actionRequest);
			String defaultLanguageId = ParamUtil.getString(uploadPortletRequest, "defaultLanguageId");
			String toLanguageId = ParamUtil.getString(uploadPortletRequest, "toLanguageId");
			String title = StringPool.BLANK;
			if (Validator.isNull(toLanguageId)) {
				title = ParamUtil.getString(uploadPortletRequest, "title_" + defaultLanguageId);
			}else {
				title = ParamUtil.getString(uploadPortletRequest, "title_" + toLanguageId);
			}
			
			String articleId = ParamUtil.getString(uploadPortletRequest, "articleId");
			double version = ParamUtil.getDouble(uploadPortletRequest, "version");
			
			boolean titleDuplicate = isTitleDuplicate(title,themeDisplay.getScopeGroupId(),articleId,version);
			
			if(titleDuplicate){
				SessionErrors.add(actionRequest,"content-title-already-exists");
			}else{
				originalStrutsPortletAction.processAction(originalStrutsPortletAction, portletConfig, actionRequest,actionResponse);
			}
		}else{
			originalStrutsPortletAction.processAction(originalStrutsPortletAction, portletConfig, actionRequest,actionResponse);
		}
		SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		
		//super.processAction(portletConfig, actionRequest, actionResponse);
	}

	/*
	 * This method will get article and check title is exist or not. 
	 */
	private boolean isTitleDuplicate(String title, long groupId,String articleId,double version) {
		boolean isTitle = false;
		JournalArticle articleTitle = null;
		title = FriendlyURLNormalizerUtil.normalize(title, _friendlyURLPattern);
		try {
			if(Validator.isNotNull(articleId)){
				JournalArticle article = JournalArticleLocalServiceUtil.getArticle(groupId, articleId, version);
				if(title.equalsIgnoreCase(article.getUrlTitle())){
					isTitle = false;
				}else{
					articleTitle = JournalArticleLocalServiceUtil.getArticleByUrlTitle(groupId, title);
				}
			}else{
				articleTitle = JournalArticleLocalServiceUtil.getArticleByUrlTitle(groupId, title);
			}
			if(Validator.isNotNull(articleTitle)){
				isTitle = true;
			}
		} catch (PortalException e) {
			LOGGER.info("Exception occured while get article");
		} catch (SystemException e) {
			LOGGER.info("Exception occured while get article");
		}
		
		return isTitle;
	}

	/*
	 * This method will check tag is exist or not. 
	 */
	private boolean isValidateTag(ActionRequest actionRequest) {
		
		try {
			ServiceContext serviceContext = ServiceContextFactory.getInstance(JournalArticle.class.getName(), actionRequest);
			String[] tags = serviceContext.getAssetTagNames();
			if(tags != null){
				for (int i = 0; i < tags.length ; i++) {
					if(tags[i].equalsIgnoreCase("article")){
						return true;
					}
				}
			}
		} catch (PortalException e) {
			LOGGER.info("Exception occured while get serviceContext");
		} catch (SystemException e) {
			LOGGER.info("Exception occured while get serviceContext");
		}
		return false;
	}

	
	@Override
	public String render(StrutsPortletAction originalStrutsPortletAction,
			PortletConfig portletConfig, RenderRequest renderRequest,
			RenderResponse renderResponse) throws Exception {
		
		return originalStrutsPortletAction.render(null, portletConfig, renderRequest, renderResponse);

	}
	
	@Override
	public void serveResource(StrutsPortletAction originalStrutsPortletAction,
			PortletConfig portletConfig, ResourceRequest resourceRequest,
			ResourceResponse resourceResponse) throws Exception {
		
		 originalStrutsPortletAction.serveResource(
		            originalStrutsPortletAction, portletConfig, resourceRequest,
		            resourceResponse);
	}
	
}
