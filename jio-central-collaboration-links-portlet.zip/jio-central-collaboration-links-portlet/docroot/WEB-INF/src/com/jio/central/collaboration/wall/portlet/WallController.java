package com.jio.central.collaboration.wall.portlet;

import com.jio.central.bean.JioMBMessageBean;
import com.jio.central.collaboration.util.MenuWallConstants;
import com.jio.central.collaboration.wall.utils.WallMessageBoardUtil;
import com.liferay.portal.NoSuchLayoutException;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ListUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.Group;
import com.liferay.portal.model.Layout;
import com.liferay.portal.model.Organization;
import com.liferay.portal.service.GroupLocalServiceUtil;
import com.liferay.portal.service.LayoutLocalServiceUtil;
import com.liferay.portal.service.OrganizationLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

public class WallController extends MVCPortlet {


	private static Log _log = LogFactoryUtil.getLog(WallController.class);	

	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws PortletException, IOException {
		// TODO Auto-generated method stub
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		if(themeDisplay.isSignedIn()){
			long userId = 0;

			/*
			 * This variable is used to show pages based on user ids TO check from
			 * which portlet the user param is passed and requested, and also it is used in IPC.
			 */

			String viewType = renderRequest.getParameter(MenuWallConstants.TRIGGER_VIEW_TYPE);

			if (Validator.isNotNull(viewType)) {
				renderRequest.setAttribute(MenuWallConstants.TRIGGER_VIEW_TYPE, viewType);
			} else {
				//setting View ttpe to default View Page.
				viewType= MenuWallConstants.ATTR_DEFAULT_VIEW;
				renderRequest.setAttribute(MenuWallConstants.TRIGGER_VIEW_TYPE, viewType);
			}
			_log.debug("View Type :::: " + viewType);

			Organization organization = null; 	
			
			//TO Check whether we are at organization layout.
			
			Group group = themeDisplay.getScopeGroup();
						
			if(group.isOrganization()){
				try {
					organization = OrganizationLocalServiceUtil.getOrganization(group.getClassPK());
					_log.info("layout is an Organization and name is ::: " + organization.getName());
					
				} catch (PortalException e) {
					_log.error(e.getMessage());
					
				}catch (SystemException e){
					_log.error(e.getMessage());
				}
			}		 

			String loggedInUser = renderRequest.getParameter(MenuWallConstants.LOGGED_IN_USER);
			HttpServletRequest request = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(renderRequest));

			String loggedInUser_fromRequest = request.getParameter(MenuWallConstants.LOGGED_IN_USER);

			if (Validator.isNotNull(loggedInUser) && loggedInUser != "0") {

				userId = Long.parseLong(loggedInUser);
			} else if (Validator.isNotNull(loggedInUser_fromRequest)) {

				userId = Long.parseLong(loggedInUser_fromRequest);
			} else if(Validator.isNull(loggedInUser) && Validator.isNull(loggedInUser_fromRequest)){

				userId = themeDisplay.getUserId();
			}

			//PReparing View for Wall Portlet Start
			
				viewAndData(userId,viewType,organization,renderRequest,renderResponse);
			
		
			//PReparing View for Wall Portlet Start
				renderRequest.setAttribute(MenuWallConstants.LOGGED_IN_USER,userId);
			createViewMessageURL(renderRequest,themeDisplay);

			super.render(renderRequest, renderResponse);

		}
		else{
			String message = "Please sign in to view your feeds";

			renderRequest.setAttribute("not_signed_in_message",message);
			super.render(renderRequest, renderResponse);
		}

	}

	/*
	 * @param userId User Id of the User
	 * @param viewType View type for the user.
	 *
	 */private void viewAndData(long userId, String viewType,Organization organization,RenderRequest renderRequest, RenderResponse renderResponse){

		 PortletURL iteratorURL = renderResponse.createRenderURL();		
		 List<JioMBMessageBean> jioMessagesBean = new ArrayList<JioMBMessageBean>(); 
		 
		 
		 try {
			 int noOfMsgs=0;
			 if(Validator.isNull(organization)){
				 jioMessagesBean = WallMessageBoardUtil.latestMessageOnWall(userId,viewType,renderRequest);
				 noOfMsgs = jioMessagesBean == null ? 0 : jioMessagesBean.size();
				 _log.info("No.of Messages To be Displayed on Wall ::: " + noOfMsgs);
			 }
			 else{
				 jioMessagesBean = WallMessageBoardUtil.latestMessagesOfOrganization(organization);
				 noOfMsgs = jioMessagesBean == null ? 0 : jioMessagesBean.size();
				 _log.info("No.of Messages To be Displayed on Wall" + noOfMsgs);
			 }
			 if(jioMessagesBean !=null && jioMessagesBean.size()>0){
				 SearchContainer<JioMBMessageBean> searchContainer = new SearchContainer<JioMBMessageBean>(renderRequest,null, null, "cur_",5,iteratorURL,null,"null empty List");;


				 List<JioMBMessageBean> subList = ListUtil.subList(jioMessagesBean, searchContainer.getStart(), searchContainer.getEnd());

				 searchContainer.setResults(subList);
				 searchContainer.setTotal(jioMessagesBean.size());
				 searchContainer.setDeltaConfigurable(true);

				 renderRequest.setAttribute("threadContainer", searchContainer);
			 }
			 else{

				 SessionMessages.add(renderRequest, "no-threads-found");
			 }
		 } catch (PortalException e) {
			 // TODO Auto-generated catch block
			 _log.error(e);
		 } catch (SystemException e) {
			 // TODO Auto-generated catch block
			 _log.error(e);
		 }

	 }


	 private void createViewMessageURL(RenderRequest renderRequest,
			 ThemeDisplay themeDisplay) {
		 // TODO Auto-generated method stub

		 long plId =  0L;
		 try {
			 String userSite = PropsUtil.get("jio.central.collaboration.user.site");
			 Group userSiteGroup = GroupLocalServiceUtil.getGroup(themeDisplay.getCompanyId(), userSite);
			 String friendlyURL =  "/message";
			 Layout layout = LayoutLocalServiceUtil.getFriendlyURLLayout(userSiteGroup.getGroupId(), true, friendlyURL);
			 String lastURL = themeDisplay.getPortalURL()+themeDisplay.getPathFriendlyURLPublic()+layout.getGroup().getFriendlyURL()+layout.getFriendlyURL();
			 plId =  layout.getPlid();
			 renderRequest.setAttribute("msglastURL", lastURL);
			 renderRequest.setAttribute("viewMessagepPLId", plId);
		 } catch (NoSuchLayoutException e) {
			 e.getMessage();
		 } catch (SystemException e) {
			 e.getMessage();
		 } catch (PortalException e) {
			 e.getMessage();
		 }
	 }
}
