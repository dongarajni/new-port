package com.jio.central.bean;

import com.liferay.util.bridges.mvc.MVCPortlet;

public class JioCentralLinksBean extends MVCPortlet {

	private long userId;
	private long groupId;
	private long userGroupId;
	private String groupName;
	private String userName;
	private String userGroupName;
	private String userImageURL;
	private String userGroupImageURL;
	private String userURL;
	private String viewType;
	private String dataURL;
	private String userGroupURL;
	private boolean orgUserGroup;
	private int orgUsersCount;
	private String ownerName;
	private String isOrgMember;
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public long getGroupId() {
		return groupId;
	}
	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}
	public long getUserGroupId() {
		return userGroupId;
	}
	public void setUserGroupId(long userGroupId) {
		this.userGroupId = userGroupId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserGroupName() {
		return userGroupName;
	}
	public void setUserGroupName(String userGroupName) {
		this.userGroupName = userGroupName;
	}
	public String getUserImageURL() {
		return userImageURL;
	}
	public void setUserImageURL(String userImageURL) {
		this.userImageURL = userImageURL;
	}
	public String getUserGroupImageURL() {
		return userGroupImageURL;
	}
	public void setUserGroupImageURL(String userGroupImageURL) {
		this.userGroupImageURL = userGroupImageURL;
	}
	public String getUserURL() {
		return userURL;
	}
	public void setUserURL(String userURL) {
		this.userURL = userURL;
	}
	public String getUserGroupURL() {
		return userGroupURL;
	}
	public void setUserGroupURL(String userGroupURL) {
		this.userGroupURL = userGroupURL;
	}
	public String getViewType() {
		return viewType;
	}
	public void setViewType(String viewType) {
		this.viewType = viewType;
	}
	public String getDataURL() {
		return dataURL;
	}
	public void setDataURL(String dataURL) {
		this.dataURL = dataURL;
	}
	public boolean isOrgUserGroup() {
		return orgUserGroup;
	}
	public void setOrgUserGroup(boolean orgUserGroup) {
		this.orgUserGroup = orgUserGroup;
	}
	public int getOrgUsersCount() {
		return orgUsersCount;
	}
	public void setOrgUsersCount(int orgUsersCount) {
		this.orgUsersCount = orgUsersCount;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getIsOrgMember() {
		return isOrgMember;
	}
	public void setIsOrgMember(String isOrgMember) {
		this.isOrgMember = isOrgMember;
	}

	

	
}
