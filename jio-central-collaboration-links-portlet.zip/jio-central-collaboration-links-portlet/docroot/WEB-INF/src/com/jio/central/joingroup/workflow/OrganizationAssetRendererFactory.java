package com.jio.central.joingroup.workflow;

import com.jio.central.services.custom.tables.model.JoinOrganization;
import com.jio.central.services.custom.tables.service.JoinOrganizationLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portlet.asset.model.AssetRenderer;
import com.liferay.portlet.asset.model.BaseAssetRendererFactory;

public class OrganizationAssetRendererFactory extends BaseAssetRendererFactory {

	@Override
	public AssetRenderer getAssetRenderer(long classpk, int arg1)
			throws PortalException, SystemException {

		JoinOrganization joinOrganization = JoinOrganizationLocalServiceUtil
				.getJoinOrganization(classpk);
		return new OrgnizationAssetRender(joinOrganization);

	}

	@Override
	public String getClassName() {
		return CLASS_NAME;
	}

	@Override
	public String getType() {
		return TYPE;
	}

	public static final String TYPE = "Join Group";
	public static final String CLASS_NAME = JoinOrganization.class.getName();

}
