/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.model.impl;

import com.jio.central.services.custom.tables.model.JoinOrganization;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing JoinOrganization in entity cache.
 *
 * @author dewang.patel
 * @see JoinOrganization
 * @generated
 */
public class JoinOrganizationCacheModel implements CacheModel<JoinOrganization>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(23);

		sb.append("{joinOrganizationId=");
		sb.append(joinOrganizationId);
		sb.append(", joinOrganizationName=");
		sb.append(joinOrganizationName);
		sb.append(", description=");
		sb.append(description);
		sb.append(", joinOrganizationStatus=");
		sb.append(joinOrganizationStatus);
		sb.append(", statusByUserId=");
		sb.append(statusByUserId);
		sb.append(", statusDate=");
		sb.append(statusDate);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", groupId=");
		sb.append(groupId);
		sb.append(", userId=");
		sb.append(userId);
		sb.append(", organizaId=");
		sb.append(organizaId);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public JoinOrganization toEntityModel() {
		JoinOrganizationImpl joinOrganizationImpl = new JoinOrganizationImpl();

		joinOrganizationImpl.setJoinOrganizationId(joinOrganizationId);

		if (joinOrganizationName == null) {
			joinOrganizationImpl.setJoinOrganizationName(StringPool.BLANK);
		}
		else {
			joinOrganizationImpl.setJoinOrganizationName(joinOrganizationName);
		}

		if (description == null) {
			joinOrganizationImpl.setDescription(StringPool.BLANK);
		}
		else {
			joinOrganizationImpl.setDescription(description);
		}

		joinOrganizationImpl.setJoinOrganizationStatus(joinOrganizationStatus);
		joinOrganizationImpl.setStatusByUserId(statusByUserId);

		if (statusDate == Long.MIN_VALUE) {
			joinOrganizationImpl.setStatusDate(null);
		}
		else {
			joinOrganizationImpl.setStatusDate(new Date(statusDate));
		}

		joinOrganizationImpl.setCompanyId(companyId);
		joinOrganizationImpl.setGroupId(groupId);
		joinOrganizationImpl.setUserId(userId);
		joinOrganizationImpl.setOrganizaId(organizaId);

		if (createDate == Long.MIN_VALUE) {
			joinOrganizationImpl.setCreateDate(null);
		}
		else {
			joinOrganizationImpl.setCreateDate(new Date(createDate));
		}

		joinOrganizationImpl.resetOriginalValues();

		return joinOrganizationImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		joinOrganizationId = objectInput.readLong();
		joinOrganizationName = objectInput.readUTF();
		description = objectInput.readUTF();
		joinOrganizationStatus = objectInput.readInt();
		statusByUserId = objectInput.readLong();
		statusDate = objectInput.readLong();
		companyId = objectInput.readLong();
		groupId = objectInput.readLong();
		userId = objectInput.readLong();
		organizaId = objectInput.readLong();
		createDate = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(joinOrganizationId);

		if (joinOrganizationName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(joinOrganizationName);
		}

		if (description == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(description);
		}

		objectOutput.writeInt(joinOrganizationStatus);
		objectOutput.writeLong(statusByUserId);
		objectOutput.writeLong(statusDate);
		objectOutput.writeLong(companyId);
		objectOutput.writeLong(groupId);
		objectOutput.writeLong(userId);
		objectOutput.writeLong(organizaId);
		objectOutput.writeLong(createDate);
	}

	public long joinOrganizationId;
	public String joinOrganizationName;
	public String description;
	public int joinOrganizationStatus;
	public long statusByUserId;
	public long statusDate;
	public long companyId;
	public long groupId;
	public long userId;
	public long organizaId;
	public long createDate;
}