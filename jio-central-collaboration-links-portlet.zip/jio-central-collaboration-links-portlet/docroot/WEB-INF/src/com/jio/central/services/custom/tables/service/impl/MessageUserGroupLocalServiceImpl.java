/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.central.services.custom.tables.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.jio.central.services.custom.tables.model.MessageUserGroup;
import com.jio.central.services.custom.tables.service.MessageUserGroupLocalServiceUtil;
import com.jio.central.services.custom.tables.service.base.MessageUserGroupLocalServiceBaseImpl;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletClassLoaderUtil;
import com.liferay.portal.model.Organization;
import com.liferay.portal.model.User;
import com.liferay.portal.service.OrganizationLocalServiceUtil;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.util.PortalUtil;

/**
 * The implementation of the message user group local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jio.central.services.custom.tables.service.MessageUserGroupLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author vaibhavs13
 * @see com.jio.central.services.custom.tables.service.base.MessageUserGroupLocalServiceBaseImpl
 * @see com.jio.central.services.custom.tables.service.MessageUserGroupLocalServiceUtil
 */
public class MessageUserGroupLocalServiceImpl
	extends MessageUserGroupLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.jio.central.services.custom.tables.service.MessageUserGroupLocalServiceUtil} to access the message user group local service.
	 */
	
	private static Log LOGGER = LogFactoryUtil.getLog(MessageUserGroupLocalServiceImpl.class.getName());
	
	public List<Organization> getAllOrganizationByMessageId (long messageId){
		List<Organization> listCollection = new ArrayList<Organization>();	
		try {
			
	
			
			DynamicQuery msgUserGroupdynamicQuery = DynamicQueryFactoryUtil.forClass(MessageUserGroup.class,"mugm",PortletClassLoaderUtil.getClassLoader());
	    	msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.messageid", messageId));
	    	msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.isgroup", Boolean.TRUE));
	    	msgUserGroupdynamicQuery.setProjection(PropertyFactoryUtil.forName("mugm.userorgrp_name"));
	    	
	    	List<String> messageUserGroupObj = MessageUserGroupLocalServiceUtil.dynamicQuery(msgUserGroupdynamicQuery);	
	    	
	    	for(String mappingItr : messageUserGroupObj){
	    		listCollection.add(OrganizationLocalServiceUtil.getOrganization(PortalUtil.getDefaultCompanyId(),mappingItr));
	    	}
	    	
			
		} catch (Exception e) {
			LOGGER.error("ERR IN getAllOrganizationByMessageId :::"+e.getMessage());
		}
		return listCollection;
	}
	
	public List<User> getAllUsersByMessageId (long messageId){
		List<User> listCollection = new ArrayList<User>();	
		try {
			
	
			
			DynamicQuery msgUserGroupdynamicQuery = DynamicQueryFactoryUtil.forClass(MessageUserGroup.class,"mugm",PortletClassLoaderUtil.getClassLoader());
	    	msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.messageid", messageId));
	    	msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.isgroup", Boolean.FALSE));
	    	msgUserGroupdynamicQuery.setProjection(PropertyFactoryUtil.forName("mugm.userorgrp_name"));
	    	
	    	List<String> messageUserGroupObj = MessageUserGroupLocalServiceUtil.dynamicQuery(msgUserGroupdynamicQuery);	
	    	
	    	for(String mappingItr : messageUserGroupObj){
	    		listCollection.add(UserLocalServiceUtil.fetchUserByScreenName(PortalUtil.getDefaultCompanyId(), mappingItr));
	    	}
	    	
			
		} catch (Exception e) {
			LOGGER.error("ERR IN getAllUsersByMessageId :::"+e.getMessage());
		}
		return listCollection;
	}
	
	public List<Long> getAllMessageIdByOrg (String organizationName){
		List<Long> listCollection =  new ArrayList<Long>();
		try {
			
	
			
			DynamicQuery msgUserGroupdynamicQuery = DynamicQueryFactoryUtil.forClass(MessageUserGroup.class,"mugm",PortletClassLoaderUtil.getClassLoader());
	    	msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.userorgrp_name", organizationName));
	    	msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.isgroup", Boolean.TRUE));
	    	msgUserGroupdynamicQuery.setProjection(PropertyFactoryUtil.forName("mugm.messageid"));
	    	
	    	listCollection = MessageUserGroupLocalServiceUtil.dynamicQuery(msgUserGroupdynamicQuery);	
	    		
		} catch (Exception e) {
			LOGGER.error("ERR IN getAllMessageIdByOrg :::"+e.getMessage());
		}
		return listCollection;
	}
	
	public List<Long> getAllMessageIdByUserId (long userId){
		List<Long> listCollection = new ArrayList<Long>();	
		try {
			
	
			
			DynamicQuery msgUserGroupdynamicQuery = DynamicQueryFactoryUtil.forClass(MessageUserGroup.class,"mugm",PortletClassLoaderUtil.getClassLoader());
	    	msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.userorgrp_id", userId));
	    	msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.isgroup", Boolean.FALSE));
	    	msgUserGroupdynamicQuery.setProjection(PropertyFactoryUtil.forName("mugm.messageid"));
	    	
	    	listCollection = MessageUserGroupLocalServiceUtil.dynamicQuery(msgUserGroupdynamicQuery);	
	    		
		} catch (Exception e) {
			LOGGER.error("ERR IN getAllMessageIdByUserId :::"+e.getMessage());
		}
		return listCollection;
	}
	
	public List<Long> getAllMessageUserGroupPid (long messageId , Boolean isGroup){
		List<Long> listCollection = new ArrayList<Long>();
		try {
			
	
			
			DynamicQuery msgUserGroupdynamicQuery = DynamicQueryFactoryUtil.forClass(MessageUserGroup.class,"mugm",PortletClassLoaderUtil.getClassLoader());
	    	msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.messageid", messageId));
	    	msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.isgroup", isGroup));
	    	msgUserGroupdynamicQuery.setProjection(PropertyFactoryUtil.forName("mugm.pid"));
	    	
	    	listCollection = MessageUserGroupLocalServiceUtil.dynamicQuery(msgUserGroupdynamicQuery);	
	    	
	    	
		} catch (Exception e) {
			LOGGER.error("ERR IN getAllMessageIdByUserId :::"+e.getMessage());
		}
		return listCollection;
	}
	
	
	public List<String> getAllMessageUserGroupNamebyMessageId (long messageId, Boolean isGroup){
		List<String> listCollection = new ArrayList<String>();
		try {
			
	
			
			DynamicQuery msgUserGroupdynamicQuery = DynamicQueryFactoryUtil.forClass(MessageUserGroup.class,"mugm",PortletClassLoaderUtil.getClassLoader());
	    	msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.messageid", messageId));
	    	msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.isgroup", isGroup));
	    	msgUserGroupdynamicQuery.setProjection(PropertyFactoryUtil.forName("mugm.userorgrp_name"));
	    	
	    	listCollection = MessageUserGroupLocalServiceUtil.dynamicQuery(msgUserGroupdynamicQuery);	
	    	
	    	
		} catch (Exception e) {
			LOGGER.error("ERR IN getAllMessageIdByUserId :::"+e.getMessage());
		}
		return listCollection;
	}
	
	public List<Long> getAllMessageUserGroupPidbyUsrGrpName (String userGroupName, Boolean isGroup , Long messageId){
		List<Long> listCollection = new ArrayList<Long>();
		try {
			
	
			
			DynamicQuery msgUserGroupdynamicQuery = DynamicQueryFactoryUtil.forClass(MessageUserGroup.class,"mugm",PortletClassLoaderUtil.getClassLoader());
	    	
			msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.messageid", messageId));
			msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.userorgrp_name", userGroupName));
	    	msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.isgroup", isGroup));
	    	msgUserGroupdynamicQuery.setProjection(PropertyFactoryUtil.forName("mugm.pid"));
	    	
	    	listCollection = MessageUserGroupLocalServiceUtil.dynamicQuery(msgUserGroupdynamicQuery);	
	    	
	    	
		} catch (Exception e) {
			LOGGER.error("ERR IN getAllMessageIdByUserId :::"+e.getMessage());
		}
		return listCollection;
	}
	
	public List<Long> getAllTaggedMessagesByUserId(long userId){
		List<Long> listOfMessages = new ArrayList<Long>();	
		try{
		DynamicQuery msgUserGroupdynamicQuery = DynamicQueryFactoryUtil.forClass(MessageUserGroup.class,"mugm",PortletClassLoaderUtil.getClassLoader());
		
		
		msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.userorgrp_id", userId));
    	msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.isgroup", Boolean.FALSE));
    	msgUserGroupdynamicQuery.setProjection(PropertyFactoryUtil.forName("mugm.messageid"));
		
    	listOfMessages = MessageUserGroupLocalServiceUtil.dynamicQuery(msgUserGroupdynamicQuery);
		}catch(Exception e)
		{
			LOGGER.error("ERR IN getAllTaggedMessagesByUserId :::"+e.getMessage());
		}
		return listOfMessages;
	}
	
	
	public List<Long> getUserOrGroupIdsByMessageId(long messageId , boolean isGroup){
		List<Long> listOfTagIds = new ArrayList<Long>();	
		try{
		DynamicQuery msgUserGroupdynamicQuery = DynamicQueryFactoryUtil.forClass(MessageUserGroup.class,"mugm",PortletClassLoaderUtil.getClassLoader());
		
		
		msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.messageid", messageId));
    	msgUserGroupdynamicQuery.add(RestrictionsFactoryUtil.eq("mugm.isgroup", isGroup));
    	msgUserGroupdynamicQuery.setProjection(PropertyFactoryUtil.forName("mugm.userorgrp_id"));
		
    	listOfTagIds = MessageUserGroupLocalServiceUtil.dynamicQuery(msgUserGroupdynamicQuery);
		}catch(Exception e)
		{
			LOGGER.error("ERR IN getUserOrGroupIdsByMessageId :::"+e.getMessage());
		}
		return listOfTagIds;
	}
	
	
}