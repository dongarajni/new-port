package com.jio.central.collaboration.wall.utils;

import com.jio.central.bean.JioMBMessageBean;
import com.jio.central.services.custom.tables.service.MessageUserGroupLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ListUtil;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.model.Organization;
import com.liferay.portlet.messageboards.model.MBMessage;
import com.liferay.portlet.messageboards.model.MBThread;
import com.liferay.portlet.messageboards.service.MBMessageLocalServiceUtil;
import com.liferay.portlet.messageboards.util.comparator.MessageCreateDateComparator;

import java.util.ArrayList;
import java.util.List;

public class JioWallMessageAggreagator{
	
	public static List<JioMBMessageBean> messageBuilder(List<MBThread> mbThreadList,boolean isSharedWithMe)
			throws PortalException, SystemException{
		
		List<JioMBMessageBean> listJioMessageBean = new ArrayList<JioMBMessageBean>();
 		
		if (mbThreadList != null && mbThreadList.size() > 0) {
	
			List<MBMessage> messages = new ArrayList<MBMessage>();
			for (MBThread thread : mbThreadList) {
	
				// Instantiation of bean for every message Thread
	
				JioMBMessageBean jioMBbean = new JioMBMessageBean();
	
				// fetch all the threadMessages based on thread list fetched in mbThreadList			
		
				// Fetching the message with the root Message.
				MBMessage message = MBMessageLocalServiceUtil.getMBMessage(thread.getRootMessageId());						
				
				//To Fetch Last Repiled Message	To be set inside message bean.		
				lastRepliedMessage(jioMBbean, message);	
				//To Fetch Last Repiled Message	
				
				jioMBbean.setNoOfReply(thread.getMessageCount()-1);
				jioMBbean.setMessage_creatorUserId(message.getUserId());
				jioMBbean.setMessageRootId(message.getRootMessageId());
				jioMBbean.setMessageDescription(message.getBody());
				jioMBbean.setMessages(messages);				
				jioMBbean.setCreatedDate(thread.getCreateDate());
				
				jioMBbean.setTaggedUsers(MessageUserGroupLocalServiceUtil.getAllUsersByMessageId(message.getMessageId()));
				
				if(isSharedWithMe){				
					jioMBbean.setTaggedOrganization(new ArrayList<Organization>());				
				}
				else{
					jioMBbean.setTaggedOrganization(MessageUserGroupLocalServiceUtil.getAllOrganizationByMessageId(message.getMessageId()));
				}
				
				listJioMessageBean.add(jioMBbean);
	
			}

		} else {
		listJioMessageBean = new ArrayList<JioMBMessageBean>();
		}
	return listJioMessageBean;
	}
	
	
	private static void lastRepliedMessage(JioMBMessageBean jioMBbean,MBMessage message){
		
		List<MBMessage> repChildMessages  = new ArrayList<MBMessage>();
		
		JioMBMessageTreeWalker treeWalker = new JioMBMessageTreeWalker(message,WorkflowConstants.STATUS_APPROVED);
		
		if (treeWalker != null) {
			
			repChildMessages.addAll(treeWalker.getMessages());

			repChildMessages = ListUtil.sort(repChildMessages, new MessageCreateDateComparator(false));

			if (repChildMessages.size() > 1) {
				jioMBbean.setLastReply(repChildMessages.get(0));
			}
		}
	}
	
	
}
