package com.jio.central.collaboration.util;

/**
 * The type Social wall constant.
 */
public final class MenuWallConstants {

	private MenuWallConstants() {
	}
	
	//IPC param to transfer view type
	public static final String TRIGGER_VIEW_TYPE="triggerView";
	public static final String LOGGED_IN_USER="loggedInUser";
	
	public static final String ATTR_FEEDS="feeds";
	public static final String ATTR_SHARED_WITH_ME ="sharedWithMe";
	public static final String ATTR_BOOKMARK ="bookmark";
	public static final String ATTR_PEOPLE ="people";
	public static final String ATTR_MY_GROUPS ="my_groups";
	public static final String ATTR_OWN_GROUPS ="own_groups";
	
	public static final String ATTR_DEFAULT_VIEW ="default_view";
	
	
	

}
