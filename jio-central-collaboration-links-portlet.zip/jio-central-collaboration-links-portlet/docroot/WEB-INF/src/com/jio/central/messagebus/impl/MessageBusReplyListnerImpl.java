/**
 * 
 */
package com.jio.central.messagebus.impl;

import com.jio.central.collaboration.util.JioCentralUtil;
import com.jio.central.collaboration.util.MailUtility;
import com.jio.central.services.custom.tables.service.MessageUserGroupLocalServiceUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portlet.messageboards.model.MBMessage;
import com.liferay.portlet.messageboards.service.MBMessageLocalServiceUtil;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author Vaibhav6.Singh
 *
 */
public class MessageBusReplyListnerImpl implements MessageListener{
	
	Log LOGGER = LogFactoryUtil.getLog(MessageBusReplyListnerImpl.class.getName());
	
	@Override
	public void receive(Message message) throws MessageListenerException {
		doReceive(message);
	}
	
	/**
	  * Below method act as a filter to regulate call towards listers method
	  * @param message
	  */
	private void doReceive(Message message) {
		replyEmail(message);
	}
	
	/**
	  * Below method gets call during REPLY post creation from message board 
	  * @param message -- message received from MEssageBUs
	  * 
	  */
	public void replyEmail(Message message) {
		
		try {
				
			
			// get all the inputs
			String message_URL = (String) message.get("ReplyMessageURL");
			MBMessage mbMessage = (MBMessage) message.get("ReplyMbMessage");
			
			
			LOGGER.info("Reply Message Bus Listner received input for Message Id:" + String.valueOf((Validator.isNotNull(mbMessage)) ? (mbMessage.getMessageId()) : "Err: Unable to fetch Message Id==========>"));
			
			if(Validator.isNotNull(mbMessage)){

				
				/*
				 * Commented on Oct 6, 2017
				 * Currently all members tagged individually or in a group will get email.
				 * 
				 * List<Long> userIds = MessageUserGroupLocalServiceUtil.getUserOrGroupIdsByMessageId(mbMessage.getRootMessageId(), Boolean.FALSE);
				 * List<Long> organizationIds = MessageUserGroupLocalServiceUtil.getUserOrGroupIdsByMessageId(mbMessage.getRootMessageId(), Boolean.TRUE);
				 * Set<Long> uniqueUsers = MailUtility.getInstance(). getUniqueUsersFromUserGroup(userIds, organizationIds);
				 * */
				/*
				 * *******************************************************************************************************
				 * DELIBERATELY SETTING VALUE TO NULL SO THAT ONLY REPLIED OVER POST CREATOR WILL GET EMAIL.
				 * *******************************************************************************************************
				 * */
				
				
				/*
				 *  
				 * */
				List<Long> organizationIds = null;
				List<Long> userIds = null;
				Set<Long> uniqueUsers = new HashSet<Long>();
				// get the list of all unique users tagged individually and also present among groups
				MBMessage replyToUser = MBMessageLocalServiceUtil.fetchMBMessage(mbMessage.getParentMessageId());
				
				if(Validator.isNotNull(replyToUser)){
					
					uniqueUsers.add(replyToUser.getUserId());
					
					// Commented on Oct 6,2017-- Group mebers wont receive mail over reply. Only replied over member.
					//Set<Long> taggedOrgId = new HashSet<Long>(organizationIds);
					Set<Long> taggedOrgId = new HashSet<Long>();
					Set<Long> taggedUserId = new HashSet<Long>(uniqueUsers);
					
					
					if(Validator.isNotNull(uniqueUsers) && uniqueUsers.size()>0){
						LOGGER.info("Reply mail to be sent to unique users of size "+uniqueUsers.size());
						LOGGER.info("Reply mail to be sent at userID  "+replyToUser.getUserId());
						JioCentralUtil.sendMailAdd(uniqueUsers, mbMessage, Boolean.TRUE, message_URL , taggedUserId , taggedOrgId );
					}else{
						LOGGER.warn("No unique users found while tagging in reply.");
					}
					
				}else{
					LOGGER.warn("Unable to fetch MbPost creator data to send reply mail...");
				}
				
				

				
			}else{
				LOGGER.error("=====Err: MbMessage not received,No REPLY mail will be triggered=====");
			}
			
			
		} catch (Exception e) {
			LOGGER.error("Error during reply::"+e);
		}
				
	}
	
	
	
}
