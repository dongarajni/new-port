package com.jio.central.hook.action;

import com.jio.central.collaboration.util.ExpandoUtility;
import com.jio.central.constants.Consts;
import com.jio.central.services.custom.tables.service.MessageUserGroupLocalServiceUtil;
import com.jio.central.services.custom.tables.service.impl.TagUserGroup;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.struts.BaseStrutsPortletAction;
import com.liferay.portal.kernel.struts.StrutsPortletAction;
import com.liferay.portal.kernel.util.Constants;
import com.liferay.portal.kernel.util.HtmlUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.Organization;
import com.liferay.portal.model.User;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.messageboards.model.MBMessage;
import com.liferay.portlet.messageboards.service.MBMessageLocalServiceUtil;

import java.io.PrintWriter;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletConfig;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;


/*
 * This class is created as to act interceptor for all message board request-response.
 * Auto complete/Auto suggestion through tagging of user and group are carried out here
 * 
 * */

public class CustomEditMessageAction extends BaseStrutsPortletAction {


	private static Log LOGGER = LogFactoryUtil.getLog(CustomEditMessageAction.class.getName());
	
	    public void processAction(
	            StrutsPortletAction originalStrutsPortletAction,
	            PortletConfig portletConfig, ActionRequest actionRequest,
	            ActionResponse actionResponse)
	        throws Exception {

	    	
	    	String referalURL = (String) actionRequest.getParameter("refererHomeURL");	
	    	String cmdValue = HtmlUtil.escape(ParamUtil.getString(actionRequest, Constants.CMD));
	    	
	    	
	    	String taggedGroups = actionRequest.getParameter("ExpandoAttribute--Tag Group--");
	        String taggedUsers = actionRequest.getParameter("ExpandoAttribute--Tag User--");
	        
	        if(Validator.isNotNull(taggedGroups) && taggedGroups.length()>0)
	        	actionRequest.setAttribute("mailTaggedGroup", taggedGroups);
	        if(Validator.isNotNull(taggedUsers) && taggedUsers.length()>0)
	        	actionRequest.setAttribute("mailTaggedUsers", taggedUsers);
	    	
	    	originalStrutsPortletAction.processAction(
	            originalStrutsPortletAction, portletConfig, actionRequest,
	            actionResponse);
	    	
	    	if(SessionErrors.isEmpty(actionRequest)){
				if(Validator.isNotNull(referalURL)){
					
					actionResponse.sendRedirect(referalURL);
					SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest)+SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
				}
				
				// hide default success message
				SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest)+SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_SUCCESS_MESSAGE);
				
				if(Validator.isNotNull(cmdValue) && Constants.DELETE.equalsIgnoreCase(cmdValue)){
					SessionMessages.add(actionRequest, "mbmessage-reply-delete");	
				}
			}
	    	
	    	
	    }

	    public String render(
	            StrutsPortletAction originalStrutsPortletAction,
	            PortletConfig portletConfig, RenderRequest renderRequest,
	            RenderResponse renderResponse)
	        throws Exception {

	    	
	    	String sharedMessageId = HtmlUtil.escape(ParamUtil.get(renderRequest, "customMessageId", ""));
	    	
	    	Boolean hideSubject = ParamUtil.getBoolean(renderRequest, "hideSubject");
	    	
	    	if(Validator.isNotNull(sharedMessageId)){
	    		
	    		MBMessage message = MBMessageLocalServiceUtil.fetchMBMessage(Long.valueOf(sharedMessageId));
		    	
	    		renderRequest.setAttribute("sharedMessageId",sharedMessageId);
	    		renderRequest.setAttribute("sharedMessageBody", "'"+message.getBody()+"'");
		    	renderRequest.setAttribute("sharedMessageCheck", Boolean.TRUE);
		    	renderRequest.setAttribute("sharedMessageMessage", message);
		    	renderRequest.setAttribute("hideSubject",hideSubject);
		    	
	    	}else{
	    		renderRequest.setAttribute("sharedMessageCheck", Boolean.FALSE);
	    	}
	    	
	    	return originalStrutsPortletAction.render(
	            null, portletConfig, renderRequest, renderResponse);

	    }

	    
	/* (non-Javadoc)
	 * @see com.liferay.portal.kernel.struts.BaseStrutsPortletAction#serveResource(javax.portlet.PortletConfig, javax.portlet.ResourceRequest, javax.portlet.ResourceResponse)
	 * 
	 * Serve user/ group suggestion based on phrase(s) typed by user
	 * 
	 */
	@Override
	public void serveResource(PortletConfig portletConfig,
			ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws Exception {
		JSONArray usersJSONArray = JSONFactoryUtil.createJSONArray();
		JSONObject json = JSONFactoryUtil.createJSONObject();
		
		try{
			
			String assetSuggestionType = HtmlUtil.escape(ParamUtil.getString(resourceRequest, "assetType")); 
			
			// Initialize suggestion class
			TagUserGroup tagUserGroup = TagUserGroup.getInstance();
			
			// below conditioned get called if auto user list is to be fetched
			if (Validator.isNotNull(assetSuggestionType) && Consts.autoUserSuggestionType.equals(assetSuggestionType)) {

				// param to be used at filtering
				String searchFilter = Consts.filterIsUser; 
				String keywords = HtmlUtil.escape(ParamUtil.getString(resourceRequest, Consts.customAttrKeywords));
	    		
	    		
				// get the suggestion list based on phrases
				usersJSONArray = tagUserGroup.getAllUserGroup(searchFilter , keywords);
				json.put("response", usersJSONArray);
				
						
	    		PrintWriter outobj = resourceResponse.getWriter();
		    	outobj.println(json.toString());
		    	
	    	}
			
			// below conditioned get called if auto group list is to be fetched
	    	else if (Validator.isNotNull(assetSuggestionType) && Consts.autoGroupSuggestionType.equals(assetSuggestionType)) {
	    		
	    		// param to be used at filtering
	    		String searchFilter = Consts.filterIsGroup;
				String keywords = HtmlUtil.escape(ParamUtil.getString(resourceRequest, Consts.customAttrKeywords));
	    		
				// get the suggestion list based on phrases
				usersJSONArray = tagUserGroup.getAllUserGroup(searchFilter , keywords);
				json.put("response", usersJSONArray);
				
	    		PrintWriter outobj = resourceResponse.getWriter();
		    	outobj.println(json.toString());

	    	}
	 		
			/*
			 * Previous Call
			 * Show previously tagged users in edit message section
			 * 
			 */
			else if(Validator.isNotNull(assetSuggestionType) && assetSuggestionType.length()>=0 && "get_previous_assest".equalsIgnoreCase(assetSuggestionType)){
				String currentMessageId = HtmlUtil.escape(ParamUtil.getString(resourceRequest, "editPageMessageId"));
				
				/*
				 * Group data based on message ID
				 * 
				 * */
				if(Validator.isNotNull(currentMessageId) && currentMessageId.length()>0){
					
					
					List <Organization> groupObj = MessageUserGroupLocalServiceUtil.getAllOrganizationByMessageId(Long.valueOf(currentMessageId));
			    	
			    	JSONArray array = null;
			    	JSONArray arrayChild = JSONFactoryUtil.createJSONArray();
					JSONObject jsonObjectParent = JSONFactoryUtil.createJSONObject();
					
					if(Validator.isNotNull(groupObj) && groupObj.size()>0){
			    	
						for(Organization mappingItr : groupObj){
				    		array = JSONFactoryUtil.createJSONArray();
				    		array.put(mappingItr.getOrganizationId()+"|"+mappingItr.getName());
				    		arrayChild.put(array);
				    		
			    		}
						
					}
					jsonObjectParent.put("group",arrayChild);
					
				
				/*
				 * 
				 * User Data
				 * 
				 * */
				
				arrayChild = JSONFactoryUtil.createJSONArray();
			    List<User> userObj = MessageUserGroupLocalServiceUtil.getAllUsersByMessageId(Long.valueOf(currentMessageId));
		    	
			    if(Validator.isNotNull(userObj)){
		    	
		    		
		    		for(User mappingItr : userObj){
			    		array = JSONFactoryUtil.createJSONArray();
			    		array.put(mappingItr.getUserId()+"|"+mappingItr.getScreenName().trim());
			    		arrayChild.put(array);
			    	}
		    	}
			    
			    jsonObjectParent.put("user",arrayChild);
			    
				
		    	PrintWriter outobj = resourceResponse.getWriter();
		    	outobj.println(jsonObjectParent.toString());
		    	
				}// end of previous
			}
			else if(Validator.isNotNull(assetSuggestionType) && assetSuggestionType.length()>=0 && "get_share_count".equalsIgnoreCase(assetSuggestionType)){
				
				long currentMessageId = ParamUtil.getLong(resourceRequest, "messageId");
				PrintWriter outobj = resourceResponse.getWriter();
		    	outobj.println(String.valueOf(fetchShareCount(resourceRequest, resourceResponse,currentMessageId)));
			}
		
			} catch (Exception e) {
			LOGGER.error("Error in User/Group serve()::",e);
		}	
	}
	
	
	public int fetchShareCount(ResourceRequest resourceRequest, ResourceResponse resourceResponse,long currentMessageId){
		int shareCount = 0;
		try {
			
			ExpandoUtility expandoUtility = new ExpandoUtility();
			shareCount = expandoUtility.getMsgShareCount(currentMessageId);
			
		} catch (Exception e) {
			LOGGER.error("Error while fetching share count:"+e.getMessage());
		}
		return shareCount;
	}
	
	
}