package com.jio.central.messagebus.impl;

import com.jio.central.collaboration.util.JioCentralUtil;
import com.jio.central.collaboration.util.MailUtility;
import com.jio.central.constants.Consts;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portlet.messageboards.model.MBMessage;

import java.util.Set;

/**
 * @author Vaibhav6.Singh
 *
 */
public class MessageBusFreshPostListnerImpl implements MessageListener {

	Log LOGGER = LogFactoryUtil.getLog(MessageBusFreshPostListnerImpl.class.getName());

	@Override
	public void receive(Message message) throws MessageListenerException {
		doReceive(message);
	}

/**
  * Below method act as a filter to regulate call towards listers method
  * @param message
  */
	private void doReceive(Message message) {
		postEmail(message);
	}

	/**
  * Below method gets call during new post creation from message board 
  * @param message -- message received from MEssageBUs
  * 
  */
	public void postEmail(Message message) {

		try {

			// get all the input parameters
			String taggedUsers = (String) message.get("taggedUsers");
			String taggedGroups = (String) message.get("taggedGroups");
			String message_URL = (String) message.get("message_URL");
			MBMessage mbMessage = (MBMessage) message.get("MbMessage");

			LOGGER.info("Fresh Post Message Bus Listner received input for Message Id:" + String.valueOf((Validator.isNotNull(mbMessage)) ? (mbMessage.getMessageId()) : "Err: Unable to fetch Message Id==========>"));
			LOGGER.debug("In Listner: taggedUsers:" + taggedUsers);
			LOGGER.debug("In Listner: tagged Group:" + taggedGroups);

			if (Validator.isNotNull(mbMessage)) {
				Set < Long > userList = null;
				Set < Long > userListFromGroup = null;

				// prepare the list of group
				Set < Long > groupList = null;

				// userid of all tagged user. Replace last semicolon
				if (Validator.isNotNull(taggedUsers) && taggedUsers.length() > 0) {
					userList = MailUtility.getInstance().getUniqueUsersOrOrganizationIds((StringPool.SEMICOLON.equalsIgnoreCase(String.valueOf(taggedUsers.charAt(taggedUsers.length() - 1)))) ? taggedUsers.replaceAll(";+$", "") : taggedUsers, Consts.filterIsUser);
				}

				// userid of all users present in tagged group. Replace last
				// semicolon
				if (Validator.isNotNull(taggedGroups) && taggedGroups.length() > 0) {
					userListFromGroup = MailUtility.getInstance().getUniqueUsersOrOrganizationIds((StringPool.SEMICOLON.equalsIgnoreCase(String.valueOf(taggedGroups.charAt(taggedGroups.length() - 1)))) ? taggedGroups.replaceAll(";+$", "") : taggedGroups, Consts.filterIsGroup);
					groupList = MailUtility.getInstance().getSetOfUniqueOrganizationIds((StringPool.SEMICOLON.equalsIgnoreCase(String.valueOf(taggedGroups.charAt(taggedGroups.length() - 1)))) ? taggedGroups.replaceAll(";+$", "") : taggedGroups, Consts.filterIsGroup);
				}

				// prepare the list of unique users
				Set < Long > uniqueUserList = MailUtility.getInstance().getUniqueUsers(userList, userListFromGroup);

				if (Validator.isNotNull(uniqueUserList) && uniqueUserList.size() > 0) {
					LOGGER.info("Fresh post mail to be sent to unique users of size "+uniqueUserList.size());
					JioCentralUtil.sendMailAdd(uniqueUserList, mbMessage, Boolean.FALSE, message_URL, userList, groupList);
				} else {
					LOGGER.warn("Unable to create unique user list, empty list found. Probably no asset tagged.");
				}

			} else {
				LOGGER.error("=====Err: MbMessage not received,No new post mail will be triggered=====");
			}

		} catch(Exception e) {
			if (e instanceof NullPointerException) {
				LOGGER.error("Error in Message Bus Listner: NullPointerException "+e.getMessage());
			}
			else if (e instanceof SystemException) {
				LOGGER.error("Error in Message Bus Listner: SystemException "+ e.getMessage());
			}
			else if (e instanceof PortalException) {
				LOGGER.error("Error in Message Bus Listner: PortalException"+ e.getMessage());
			}
			else{
				LOGGER.error("Error in Message Bus Listner:postEmail:::::: ", e);
			}
			
		}

	}
	
}