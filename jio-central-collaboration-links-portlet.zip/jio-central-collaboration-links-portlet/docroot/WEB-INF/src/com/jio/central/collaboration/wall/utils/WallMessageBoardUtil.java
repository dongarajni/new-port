package com.jio.central.collaboration.wall.utils;

import com.jio.central.bean.JioMBMessageBean;
import com.jio.central.collaboration.util.MenuWallConstants;
import com.jio.central.services.custom.tables.service.MessageUserGroupLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.model.Group;
import com.liferay.portal.model.Organization;
import com.liferay.portal.model.User;
import com.liferay.portal.service.GroupLocalServiceUtil;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.messageboards.model.MBMessage;
import com.liferay.portlet.messageboards.model.MBThread;
import com.liferay.portlet.messageboards.service.MBMessageLocalServiceUtil;
import java.util.ArrayList;
import java.util.List;
import javax.portlet.RenderRequest;

public class WallMessageBoardUtil {

	// Feeds related
	/*
	 * 	@param userId - Id of the user 
	 * 	@param viewType - Which view is requested by user at click. 
	 */
	private static Log _log = LogFactoryUtil.getLog(WallMessageBoardUtil.class); 
	
	public static List<JioMBMessageBean> latestMessageOnWall(long userId, String viewType, RenderRequest renderRequest)
			throws PortalException, SystemException {		
		
		 int messageCount = 0;
		List<Organization> subscribedOrganizations = subscribedOrganization(userId);
		
		_log.info(" No. of Organization Subscribed:::: " + subscribedOrganizations.size());
		
		/*This flag is used to hide tagged organization just to show one to one conversation.*/
		boolean isOnlyUserMessage = false;
		List <Long> messageIds = new ArrayList<Long>();
		
		/*
		 * This conditions aggregates messages for the following sections
		 *  1) Personal Messages
		 *  2) User subscribed Organization Messages
		 *  3) The messages which are tagged to me		
		*/
		
		if(viewType.equals(MenuWallConstants.ATTR_DEFAULT_VIEW)){			
			_log.debug(" Inside Default View  ");
			/*
			 * Fetching the Site, where the message portlet has been deployed.
			 * This is implemented to fetch all the messages which has been created by logged in user.
			 * 			
			*/
			String groupName = PropsUtil.get("jio.central.collaboration.user.site");			
			_log.debug(" groupName from properties : " + groupName);
			
			Group grp = GroupLocalServiceUtil.fetchGroup(PortalUtil.getCompanyId(renderRequest),groupName);			
			_log.debug(" Group from Liferay :" + grp.getDescriptiveName());
			/*
			 * To fetch messages which are tagged with Organization, So fetching Organizations with userID.
			 * And adding those in an list and adding it as a part of other fetched messages.
			 * 			
			*/			
			messageIds = fetchOrganizationSubscribedMessages(userId,subscribedOrganizations,renderRequest);
			messageCount = messageIds == null ? 0 : messageIds.size();
			_log.info("No.of messages From subscribed organizations ::: " + messageCount );
			
			if(messageIds.isEmpty()){
				messageIds = new ArrayList<Long>();
			}
			/*
			 * To Fetch messages which are tagged personnaly.			
			*/
			List<Long> personnelmessageIds = fetchTaggedToMeMessages(userId);
			messageCount =  personnelmessageIds == null ? 0 : personnelmessageIds.size();
			_log.info("No.of messages tagged to individual ::: " + messageCount);

			if(personnelmessageIds.size() > 0){
				for(Long messageid : personnelmessageIds)
				messageIds.add(messageid);
			}
			messageCount = messageIds == null ? 0 : messageIds.size();
			_log.info("Total No of Messages After fetching from both the custom Tables ::: " + messageCount );
			/*
			 * Collect those messages which are created by users only. on the feed pages.
			*/
			List<MBMessage> userOrgMessages = MBMessageLocalServiceUtil.getGroupMessages(grp.getGroupId(), userId, WorkflowConstants.STATUS_APPROVED, QueryUtil.ALL_POS, QueryUtil.ALL_POS);
			messageCount = userOrgMessages == null ? 0 : userOrgMessages.size();
			_log.info("No.of messages created by himself  ::: " + messageCount );
			
			if(Validator.isNotNull(userOrgMessages) && userOrgMessages.size() > 0){
				for(MBMessage userMessage: userOrgMessages)
				{	
					if(!userMessage.isReply()){								
						messageIds.add(userMessage.getMessageId());
					}

				}				
			}
			messageCount = messageIds == null ? 0 : messageIds.size();
			_log.info("Total No.of messages including replies  ::: " + messageCount );
		} 
		/*
		 * This conditions aggregates messages for the following sections
		 *  1) User subscribed Organization Messages
		 */
		
		else if(viewType.equals(MenuWallConstants.ATTR_FEEDS)){
			messageIds = fetchOrganizationSubscribedMessages(userId,subscribedOrganizations, renderRequest);
			messageCount = messageIds == null ? 0 : messageIds.size();
			_log.info("Total No.of messages From What I Follow Tab  ::: " + messageCount);
		} 
		
		/*
		 * This conditions aggregates messages for the following sections
		 *	1) The messages which are tagged to me		
		*/
		else if(viewType.equals(MenuWallConstants.ATTR_SHARED_WITH_ME)){			
			if(Validator.isNotNull(userId) && userId > 0){
				messageIds =  fetchTaggedToMeMessages(userId);
				messageCount = messageIds == null ? 0 : messageIds.size();
				_log.info("Total No.of  Private messages from With Me Tab ::: " + messageCount);

				if(messageIds.size() > 0){
					isOnlyUserMessage = true;
				}					
			}		
		}			
		List<MBThread> mbThreadList = JioMBThread.buildJioMBThreads(messageIds);
		messageCount = mbThreadList == null ? 0 : mbThreadList.size();
		_log.info("Thread messages To be displayed ::: " + messageCount);

		if (Validator.isNotNull(mbThreadList) && mbThreadList.size() > 0){			
			return JioWallMessageAggreagator.messageBuilder(mbThreadList,isOnlyUserMessage);
		} else {			
			_log.info("No thread messages found to display");
			return null;		
		}
	}	

	private static List<Long> fetchOrganizationSubscribedMessages(long userId,List<Organization> userSubscribedOrganizations,RenderRequest renderRequest) throws PortalException, SystemException{
		
		List<Long> messageIds = new ArrayList<Long>();
		 if (Validator.isNotNull(userSubscribedOrganizations) && !userSubscribedOrganizations.isEmpty()) {

			for (Organization org : userSubscribedOrganizations) {	
				_log.debug("Organization Name::: " +org.getName() );
				messageIds.addAll(MessageUserGroupLocalServiceUtil.getAllMessageIdByOrg(org.getName()));
			}

			return messageIds;
		} else {

			userSubscribedOrganizations = new ArrayList<Organization>();
			SessionMessages.add(renderRequest, "no-organization");

			return new ArrayList<Long>();
		}	
	} 


	/*
	 * This method returns Personal messages if any.
	*/
	private static List<Long> fetchTaggedToMeMessages(long userId){

		List<Long> messageIds = new ArrayList<Long>();
		messageIds = MessageUserGroupLocalServiceUtil.getAllTaggedMessagesByUserId(userId);		
		if(Validator.isNotNull(messageIds) && messageIds.size() > 0) {
			return messageIds;
		}
		else {
			return new ArrayList<Long>();
		}
	} 
	
	/*
	 * This method returns Sbscribed Organization of the given userID..
	*/
	public static List<Organization> subscribedOrganization(long userId){
		List<Organization> subscribedOrganization = new ArrayList<Organization>();		
			User user;
			try {
				user = UserLocalServiceUtil.getUser(userId);
				subscribedOrganization = user.getOrganizations();
				
			} catch (PortalException e) {
				// TODO Auto-generated catch block
				_log.error("Error while fetching Organizations ::: " + e.getMessage());
				subscribedOrganization = new ArrayList<Organization>();
			}
			catch (SystemException e) {
				// TODO Auto-generated catch block
				_log.error("Error while fetching Organizations ::: " + e.getMessage());
				subscribedOrganization = new ArrayList<Organization>();
			}
			
			return subscribedOrganization;
			
		}

	/*
	 * This method returns messages of Organization specific Site.
	*/
	public static List<JioMBMessageBean> latestMessagesOfOrganization(Organization organization) throws PortalException, SystemException {
		List<Long> onlyOrganizationMessage = new ArrayList<Long>();
		List<JioMBMessageBean> jioMBMessageList = new ArrayList<JioMBMessageBean>();
		boolean isOnlyUserMessage = false;
		
		onlyOrganizationMessage = MessageUserGroupLocalServiceUtil.getAllMessageIdByOrg(organization.getName());
		
		if(!onlyOrganizationMessage.isEmpty()){
			
			List<MBThread> mbThreadList = JioMBThread.buildJioMBThreads(onlyOrganizationMessage);

			if (Validator.isNotNull(mbThreadList) && mbThreadList.size() > 0){	
				
				jioMBMessageList = JioWallMessageAggreagator.messageBuilder(mbThreadList,isOnlyUserMessage);
			
			} else {			
				_log.info(" No Thread messages found display");
				jioMBMessageList = new ArrayList<JioMBMessageBean>();		
			}
		}
		else{
			_log.info(" Organization with Name ::: " + organization.getName() + " has no messages yet posted");
			 jioMBMessageList = new  ArrayList<JioMBMessageBean>();	
		}
		return  jioMBMessageList;
	}


}
