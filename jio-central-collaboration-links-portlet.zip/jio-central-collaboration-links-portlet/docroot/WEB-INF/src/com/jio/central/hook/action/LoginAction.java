package com.jio.central.hook.action;

import com.jio.central.constants.Consts;
import com.jioc.query.model.Emp_User_Mapping;
import com.jioc.query.service.EMP_DETAILSLocalServiceUtil;
import com.jioc.query.service.Emp_User_MappingLocalServiceUtil;
import com.liferay.portal.kernel.events.Action;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.model.RoleConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.service.RoleLocalServiceUtil;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.util.PortalUtil;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginAction extends Action {
	
	private static Log LOGGER = LogFactoryUtil.getLog(LoginAction.class.getName());
	
	public void run(HttpServletRequest req, HttpServletResponse res) {
        LOGGER.info("Custom login action");
        
        try{
        	// print login IP in log
        	printLoginIP(req);
        	
        	// authenticate JC user
        	authenticateUser(req, res);
            
        	
            
        }catch(Exception e){
        	LOGGER.error("Exeption while processing login post action ", e);
        }
        
        
        
    }
	
	private static void authenticateUser(HttpServletRequest req, HttpServletResponse res){
		boolean isValidUser = false;
		
		try{
			String isAuthenticateUser = PropsUtil.get(Consts.AUTHENTICATE_LOGGED_IN_JC_USER);
			
			if(Validator.isNotNull(isAuthenticateUser) && isAuthenticateUser.equalsIgnoreCase("true")){
				User user = PortalUtil.getUser(req);
	        	boolean isAdmin = RoleLocalServiceUtil.hasUserRole(user.getUserId(), user.getCompanyId(), RoleConstants.ADMINISTRATOR, true);
	        	LOGGER.info("isAdmin:"+isAdmin);
	        	
				if(!isAdmin){
	                List<Object[]> empList = EMP_DETAILSLocalServiceUtil.fetchEmpByDomainId(user.getScreenName());
	                if(Validator.isNotNull(empList) && empList.size() > 0){
	                	for(Object[] empDetails : empList){
	                    	if(Validator.isNotNull(empDetails[0]) /*&& Validator.isNotNull(empDetails[3])*/ && Validator.isNotNull(empDetails[5])){
	                    		//String empGroup = String.valueOf(empDetails[3]);
	                    		int status = Integer.parseInt(String.valueOf(empDetails[5]));
	                    		
	                    		//if(Consts.DEFAULT_EMP_GROUP.equalsIgnoreCase(empGroup)){
	                    			createOrUpdateUserMapping(req, empDetails);
	                    			if(Consts.TIBCO_EMP_STATUS_ACTIVE == status){
	                    				user.setStatus(WorkflowConstants.STATUS_APPROVED);
	                    				user.setLastFailedLoginDate(null);
	                    				user.setFailedLoginAttempts(0);
	                    				isValidUser = true;
	                    			}
	                    			break;
	                    		//}
	                    		
	                    	}
	                    }
	                    
	                }
	                
	                if(!isValidUser){
	                	user.setStatus(WorkflowConstants.STATUS_INACTIVE);
	                	LOGGER.info("Unauthorised user");
	                	res.sendRedirect("/web/jiocentral/unauthorised");
	                	
	                }
	                
	                UserLocalServiceUtil.updateUser(user);
	            }
			}
			
		}catch(Exception e){
        	LOGGER.error("Exeption while checking authentic JC user ", e);
        	try {
				res.sendRedirect("/web/jiocentral/unauthorised");
			} catch (Exception e1) {
				e1.printStackTrace();
			}
        }
	}
	
	private static void createOrUpdateUserMapping(HttpServletRequest req, Object[] empDetails){
		User user = null;
		Emp_User_Mapping empUserMapping = null;
		try {
			user = PortalUtil.getUser(req);
			String empId = String.valueOf(empDetails[0]);
			String samlFederationId = String.valueOf(empDetails[8]); 
			int status = Integer.parseInt(String.valueOf(empDetails[5]));
			
			if(Validator.isNotNull(user)){
				try{
					empUserMapping = Emp_User_MappingLocalServiceUtil.getEmp_User_Mapping(user.getUserId());
				}catch(Exception e){
					empUserMapping = null;
					LOGGER.error("EmpUserMapping not found for userId:"+user.getUserId());
				}
				
				if(Validator.isNotNull(empUserMapping)){
					empUserMapping.setEmpId(empId);
					empUserMapping.setEmailId(user.getEmailAddress());
					empUserMapping.setDomainId(user.getScreenName());
					empUserMapping.setSamlFederationId(samlFederationId);
					empUserMapping.setStatus(status);
					
					Emp_User_MappingLocalServiceUtil.updateEmp_User_Mapping(empUserMapping);
					LOGGER.info("Emp user mapping updated for userId:"+empUserMapping.getUserId());
				}else{
					empUserMapping = Emp_User_MappingLocalServiceUtil.createEmp_User_Mapping(user.getUserId());
					empUserMapping.setEmpId(empId);
					empUserMapping.setEmailId(user.getEmailAddress());
					empUserMapping.setDomainId(user.getScreenName());
					empUserMapping.setSamlFederationId(samlFederationId);
					empUserMapping.setStatus(status);
					
					Emp_User_MappingLocalServiceUtil.addEmp_User_Mapping(empUserMapping);
					LOGGER.info("Emp user mapping added for userId:"+empUserMapping.getUserId());
				}
			}else{
				LOGGER.info("Could not get user info from request");
			}
				
			
			
		} catch (Exception e) {
			user = null;
			empUserMapping = null;
			LOGGER.error("Exception while creating Employee User Mapping ", e);
			
		}
		
	}
	
	private static void printLoginIP(HttpServletRequest req){
		try{
			HttpServletRequest originalServletRequest = PortalUtil.getOriginalServletRequest(req);
	        
			String ip = originalServletRequest.getHeader("x-forwarded-for");
			if(Validator.isNull(ip)){
				ip = req.getRemoteAddr();
			}
	        if(LOGGER.isInfoEnabled()){
	            try {
	            	User user = PortalUtil.getUser(req);
	            	String info = "Logged in user : "+user.getFullName()+","+user.getScreenName()+". Login IP : "+ip;
	                LOGGER.info(info);
	            } catch (Exception e) {
	            	LOGGER.error(e.getMessage());
	            }
	            req.getSession().setAttribute("isSignin", Boolean.TRUE);
	        }
		}catch(Exception e){
			LOGGER.error("Exception while printing login IP "+e.getMessage());
		}
		

	}
	
}
