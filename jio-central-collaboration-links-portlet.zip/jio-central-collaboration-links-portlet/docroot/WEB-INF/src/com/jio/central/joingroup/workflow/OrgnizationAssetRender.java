package com.jio.central.joingroup.workflow;

import com.jio.central.services.custom.tables.model.JoinOrganization;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portlet.asset.model.BaseAssetRenderer;

import java.util.Locale;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

public class OrgnizationAssetRender extends BaseAssetRenderer {

	
	private JoinOrganization _joinOrganization;
	
	 public OrgnizationAssetRender(JoinOrganization joinOrganization) {
		 _joinOrganization = joinOrganization;
	    }
	
	@Override
	public String getClassName() {
		
		return  "Join Group";
	}

	@Override
	public long getClassPK() {
		
		 return _joinOrganization.getJoinOrganizationId();
	}

	@Override
	public long getGroupId() {
		
		return _joinOrganization.getGroupId();
	}

	@Override
	public String getSummary(Locale arg0) {
		
		return _joinOrganization.getDescription();
	}

	@Override
	public String getTitle(Locale arg0) {
		
		return _joinOrganization.getDescription();
	}

	@Override
	public long getUserId() {
		
		return _joinOrganization.getUserId();
	}

	@Override
	public String getUserName() {
		
		return StringPool.BLANK;
	}

	@Override
	public String getUuid() {
		
		try {
			return _joinOrganization.getUserUuid();
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String render(RenderRequest arg0, RenderResponse arg1, String arg2)
			throws Exception {
		
		return StringPool.BLANK;
	}

}
