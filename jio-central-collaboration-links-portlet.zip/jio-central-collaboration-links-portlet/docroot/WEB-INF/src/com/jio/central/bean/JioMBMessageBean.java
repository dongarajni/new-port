package com.jio.central.bean;

import java.util.Date;
import java.util.List;

import com.liferay.portal.model.Organization;
import com.liferay.portal.model.User;
import com.liferay.portlet.messageboards.model.MBMessage;

public class JioMBMessageBean {

	
	long threadId;
	
	long messageRootId;
	List<MBMessage> messages;
	long messageId;
	String messageTitle;
	String messageDescription;
	String messageUrl;
	String messageReplyUrl;
	long message_creatorUserId;	
	List<User> taggedUsers;
	List<Organization> taggedOrganization;	
	Date createdDate;
	int noOfReply;
	
	MBMessage lastReply;
	
	public MBMessage getLastReply() {
		return lastReply;
	}
	public void setLastReply(MBMessage lastReply) {
		this.lastReply = lastReply;
	}
	public long getThreadId() {
		return threadId;
	}
	public void setThreadId(long threadId) {
		this.threadId = threadId;
	}
	public long getMessageRootId() {
		return messageRootId;
	}
	public void setMessageRootId(long messageRootId) {
		this.messageRootId = messageRootId;
	}
	public List<MBMessage> getMessages() {
		return messages;
	}
	public void setMessages(List<MBMessage> messages) {
		this.messages = messages;
	}
	public long getMessageId() {
		return messageId;
	}
	public void setMessageId(long messageId) {
		this.messageId = messageId;
	}
	public String getMessageTitle() {
		return messageTitle;
	}
	public void setMessageTitle(String messageTitle) {
		this.messageTitle = messageTitle;
	}
	public String getMessageDescription() {
		return messageDescription;
	}
	public void setMessageDescription(String messageDescription) {
		this.messageDescription = messageDescription;
	}
	public String getMessageUrl() {
		return messageUrl;
	}
	public void setMessageUrl(String messageUrl) {
		this.messageUrl = messageUrl;
	}
	public String getMessageReplyUrl() {
		return messageReplyUrl;
	}
	public void setMessageReplyUrl(String messageReplyUrl) {
		this.messageReplyUrl = messageReplyUrl;
	}
	public long getMessage_creatorUserId() {
		return message_creatorUserId;
	}
	public void setMessage_creatorUserId(long message_creatorUserId) {
		this.message_creatorUserId = message_creatorUserId;
	}
	public List<User> getTaggedUsers() {
		return taggedUsers;
	}
	public void setTaggedUsers(List<User> taggedUsers) {
		this.taggedUsers = taggedUsers;
	}
	public List<Organization> getTaggedOrganization() {
		return taggedOrganization;
	}
	public void setTaggedOrganization(List<Organization> taggedOrganization) {
		this.taggedOrganization = taggedOrganization;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public int getNoOfReply() {
		return noOfReply;
	}
	public void setNoOfReply(int noOfReply) {
		this.noOfReply = noOfReply;
	}
	
	
	
	
	
}
