package com.jio.central.constants;

import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.HtmlUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.util.ContentUtil;
import com.liferay.util.portlet.PortletProps;

public final class Consts {

	// search filter constants
	public static final String filterIsUser = "user";
	public static final String filterIsGroup = "group";
	
	// auto suggestion field name
	public static final String autoUserSuggestionType = "getUsers";
	public static final String autoGroupSuggestionType = "getGroup";
	
	// custom attribute delimiter
	public static final String customAttrDelimiter = ";";
	public static final String customAttrDelimiterPidName = "|";
	public static final String customAttrKeywords = "keywords";
	
	// user authentication
	public static final String DEFAULT_EMP_GROUP 		= "JO";
	public static final int TIBCO_EMP_STATUS_ACTIVE 	= 3;
	public static final int TIBCO_EMP_STATUS_INACTIVE 	= 0;
	public static final String AUTHENTICATE_LOGGED_IN_JC_USER 	= "AUTHENTICATE.LOGGED.IN.JC.USER";
	
	// error messages 
	public static final String PORTRAITSIZEEXCEPTION 	= "PortraitSizeException";
	public static final String MIMEEXCEPTION 	= "Mimeexception";
	
	// cutom field attributes 
	public static final String TABLENAME = "CUSTOM_FIELDS";
	
	// property file constants
	public static final String TAGUSER 	= GetterUtil.getString(PortletProps.get("custom.attribute.field.name.user"));
	public static final String TAGGROUP	= GetterUtil.getString(PortletProps.get("custom.attribute.field.name.group"));
	public static final String SHARECOUNT 	= GetterUtil.getString(PortletProps.get("custom.attribute.field.share.count"));
	
	//Mail constants
	public static final String FROM_ADDRESS = GetterUtil.getString(PropsUtil.get("sender.email.address"));
	public static final String TO_ADDRESS = "dewang.patel@ril.com";
	public static final String EMAIL_SUBJECT_ADD_POST = ContentUtil.get("/templates/email_subject_add_post.tmpl", Boolean.TRUE);
	public static final String EMAIL_BODY_ADD_POST = ContentUtil.get("/templates/email_body_add_post.tmpl", Boolean.TRUE);
	public static final String EMAIL_BODY_REPLY_POST = ContentUtil.get("/templates/email_body_reply_post.tmpl", Boolean.TRUE);
	public static final String TAGGEDUSER_PREFIX = "@";
	public static final String EMAIL_BODY_JOIN_GROUP = ContentUtil.get("/templates/email_body_join_group.tmpl", Boolean.TRUE);
	public static final String EMAIL_SUBJECT_JOIN_GROUP = ContentUtil.get("/templates/email_subject_join_group.tmpl", Boolean.TRUE);
	public static final String EMAIL_BODY_APPROVED_GROUP = ContentUtil.get("/templates/email_body_approved_group.tmpl", Boolean.TRUE);
	public static final Boolean TURN_ON_MAIL_ALERT = Boolean.valueOf(HtmlUtil.escape(PropsUtil.get("turn.on.collaboration.mail.alert")));
}
