package com.jio.central.collaboration.wall.utils;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.ListUtil;
import com.liferay.portlet.messageboards.model.MBThread;
import com.liferay.portlet.messageboards.service.MBMessageLocalServiceUtil;
import com.liferay.portlet.messageboards.service.MBThreadLocalServiceUtil;
import com.liferay.portlet.messageboards.util.comparator.ThreadLastPostDateComparator;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class JioMBThread {
	
	private final static Log _log = LogFactoryUtil.getLog(JioMBThread.class);
	
	public static List<MBThread> buildJioMBThreads(List<Long> messageIds){
		
		List<MBThread> mbThreadList = new ArrayList<MBThread>();

		if (messageIds != null && messageIds.size() > 0) {

		// Logic To Remove duplicate records of messageIDs
			Set<Long> uniqueMessageId = new HashSet<Long>();
			uniqueMessageId.addAll(messageIds);
			messageIds = new ArrayList<Long>();
			messageIds.addAll(uniqueMessageId);
		// END
			for (Long messageId : messageIds) {
				try {

					mbThreadList.add(MBThreadLocalServiceUtil.getMBThread(MBMessageLocalServiceUtil.getMBMessage(messageId).getThreadId()));

				} catch (Exception e) {
					_log.error(e.getMessage());
				}
			}
			if(mbThreadList != null && mbThreadList.size() > 0){
				
				ListUtil.sort(mbThreadList, new ThreadLastPostDateComparator(false));

			} else{
				mbThreadList = new ArrayList<MBThread>();
			}
		}

		return mbThreadList;
		
	}
}
