package com.jio.central.collaboration.util;

import com.jio.central.constants.Consts;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.User;
import com.liferay.portal.service.UserLocalServiceUtil;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MailUtility {

    private static MailUtility returnUniqueUsers = new MailUtility();
    private Log LOGGER = LogFactoryUtil.getLog(MailUtility.class.getName());

    public static MailUtility getInstance() {
        return returnUniqueUsers;
    }

    // user/group comes in format
    // userId1-userScreeName1;userId2-userScreeName2
    // groupId1-groupName1;groupId2-groupName2

    public Set < String > separateMultipleUserGroup(String userGroupObj) {

        Set < String > allSetObj = new HashSet < String > ();
        try {
        	
        	// user/Group operation
            String[] dataArr = userGroupObj.split(Consts.customAttrDelimiter);
            for (int i = 0; i < dataArr.length; i++) {
                if (dataArr[i].length() > 0) {
                    allSetObj.add(dataArr[i].trim());
                }
            }
        } catch (Exception e) {
            LOGGER.error("Error in separateUserOrGroup()" + e.getMessage());
        }
        return allSetObj;
    }

/*
 * <userList> list of all usersIds
 * <userListFromGroup> List of all userIds which are present in organization.
 * Return set of unique userIds
 * */
    public Set < Long > getUniqueUsers(Set < Long > userList, Set < Long > userListFromGroup) {
        Set < Long > uniqueUsers = new HashSet < Long > ();
        try {
        	// get the list of all userIds list
            if (Validator.isNotNull(userList) && userList.size() > 0)
                uniqueUsers.addAll(userList);
            // get the list of all userids obtained from group
            if (Validator.isNotNull(userListFromGroup) && userListFromGroup.size() > 0)
                uniqueUsers.addAll(userListFromGroup);

        } catch (Exception e) {
            LOGGER.error("Error in getUniqueUserList:" + e.getMessage());
        }
        
        // returns list of unique set of user list
        return uniqueUsers;

    }
    
    /*
     * <userIds> list of all usersIds.
     * <groupIds> List of all Organization id for which users are to be fetched.
     * Return set of unique userIds present as a combination of both the param
     * */
        public Set < Long > getUniqueUsersFromUserGroup(List < Long > userIds, List < Long > groupIds) {
            Set < Long > uniqueUsers = new HashSet < Long > ();
            try {
            	// get the list of all userIds list
                if (Validator.isNotNull(userIds) && userIds.size() > 0)
                    uniqueUsers.addAll(userIds);
                // get the list of all groupIds
                if (Validator.isNotNull(groupIds)){
                	
                	/*
                	 * Two scenarion considered
                	 * 1. If user is unique per group
                	 * 2. If a user is present in multiple group
                	 * */
                	// Incase if single group arrives as input
                	if(groupIds.size() == 1){
                		List<User> users = UserLocalServiceUtil.getOrganizationUsers(groupIds.get(0));
                		if(Validator.isNotNull(users)){
                			for(User userItr : users){
                    			uniqueUsers.add(userItr.getUserId());
                    		}
                		}
                	}
                	// Incase if multiple group arrives as input
                	else if(groupIds.size() > 1){
                		for(Long organizationId : groupIds){
                			List<User> users = UserLocalServiceUtil.getOrganizationUsers(organizationId);
                			if(Validator.isNotNull(users)){
                    			for(User userItr : users){
                        			uniqueUsers.add(userItr.getUserId());
                        		}
                    		}	
                		}
                		
                	}
                	
                }
                    

            } catch (Exception e) {
                LOGGER.error("Error in getUniqueUserList:" + e.getMessage());
            }
            
            // returns list of unique set of user list
            return uniqueUsers;

        }
        
        /*
         * <assetData> - this param contains  user or organization data in format below
         *  			Incase of singleuser : userId-screenName
         *  			Incase of multipleuser : userId1-screenName1;userId2-screenName2
         *  			Incase of single group/org : orgId-orgName
         *  			Incase of multiple group/org : orgId1-orgName1;orgId2-orgName2
         *  
         *  <assetType> act as filter which will return ids of unique users
         * 
         * */
        public Set < Long > getUniqueUsersOrOrganizationIds(String assetData , String assetType) {
        	Set<Long> userOrgIds = null;
        	try {
        		// assetType group
				if(Validator.isNotNull(assetData) && assetData.length()>0 && Validator.isNotNull(assetType) && assetType.length()>0 && Consts.filterIsGroup.equalsIgnoreCase(assetType)){
					
					// incase if multiple organizations are present
					if(assetData.contains(StringPool.SEMICOLON)){
						// scenario where a user is present in multiple group and all those group are tagged.
						userOrgIds = new HashSet < Long > ();

	                    //get the list of all semicolon separated organization (orgId-OrgName)
	                    Set < String > organizationSet = MailUtility.getInstance().separateMultipleUserGroup(assetData);

	                    List < User > users = null;

					for (String organization : organizationSet) {
						// fetch list of all users present in organization
						if (Validator.isNotNull(organization) && organization.length() > 0 && organization.contains(Consts.customAttrDelimiterPidName)) {
							users = UserLocalServiceUtil.getOrganizationUsers(Long.valueOf(organization.split("\\"+Consts.customAttrDelimiterPidName)[0]));
							if (Validator.isNotNull(users) && users.size() > 0) {
								for (User userItr : users) {
									userOrgIds.add(userItr.getUserId());
								}
							}
						}
					}
					}
					// incase single Organization is present
					else{
						 List < User > users = UserLocalServiceUtil.getOrganizationUsers((assetData.contains(Consts.customAttrDelimiterPidName))?Long.valueOf(assetData.split("\\"+Consts.customAttrDelimiterPidName)[0]):0);
		                    if (Validator.isNotNull(users) && users.size() > 0) {
								userOrgIds = new HashSet < Long > ();
		                    	for (User userItr: users) {
		                        	userOrgIds.add(userItr.getUserId());
		                        }
		                    }
					}
					
				}
				// assetType user
				else if(Validator.isNotNull(assetData) && assetData.length()>0 && Validator.isNotNull(assetType) && assetType.length()>0  && Consts.filterIsUser.equalsIgnoreCase(assetType)){
					
					// incase if multiple users are present
	                if (assetData.contains(StringPool.SEMICOLON)) {
	                    Set < String > userSet = MailUtility.getInstance().separateMultipleUserGroup(assetData);
	                    if(Validator.isNotNull(userSet) && userSet.size()>0){
	                    	
	                    	userOrgIds = new HashSet < Long > ();
	                    	
	                    	for (String userItr: userSet) {
		                    	userOrgIds.add((userItr.contains(Consts.customAttrDelimiterPidName))?Long.valueOf(userItr.split("\\"+Consts.customAttrDelimiterPidName)[0]):0);
		                    }
	                    }
	                    
	                }
	                // below only single user is present with format userId-ScreenName
	                else {
	                	userOrgIds = new HashSet < Long > ();
	                	userOrgIds.add((assetData.contains(Consts.customAttrDelimiterPidName))?Long.valueOf(assetData.split("\\"+Consts.customAttrDelimiterPidName)[0]):0);
	                }
					
					
				}
			} catch (Exception e) {
				LOGGER.error("Error in getUniqueUsersOrOrganizationIds :"+e.getMessage());
			}
        	return userOrgIds;
        }
        
        
        //get the list of users & Organization
        public Set < Long > getSetOfUniqueOrganizationIds(String assetData , String assetType) {
        	Set<Long> OrgIds = null;
        	
        	try {
				
        		// assetType group
				if(Validator.isNotNull(assetData) && assetData.length()>0 && Validator.isNotNull(assetType) && assetType.length()>0 && Consts.filterIsGroup.equalsIgnoreCase(assetType)){
					
					// incase if multiple organizations are present
					if(assetData.contains(StringPool.SEMICOLON)){
						// scenario where a user is present in multiple group and all those group are tagged.
						OrgIds = new HashSet < Long > ();

	                    //get the list of all semicolon separated organization (orgId-OrgName)
	                    Set < String > organizationSet = MailUtility.getInstance().separateMultipleUserGroup(assetData);
	                    
					for (String organization : organizationSet) {
						// prepare all unique org list
						if (Validator.isNotNull(organization) && organization.length() > 0 && organization.contains(Consts.customAttrDelimiterPidName)) {
							OrgIds.add(Long.valueOf(organization.split("\\"+Consts.customAttrDelimiterPidName)[0]));
							
						}
					}
				}// incase single Organization is present
					else{
						OrgIds = new HashSet < Long > ();
						OrgIds.add(Long.valueOf((assetData.contains(Consts.customAttrDelimiterPidName))?Long.valueOf(assetData.split("\\"+Consts.customAttrDelimiterPidName)[0]):0));
					}
			}
        		
			} catch (Exception e) {
				LOGGER.error("Error in getSetOfUniqueOrganizationIds",e);
			}
        	return OrgIds;
        }
        

}