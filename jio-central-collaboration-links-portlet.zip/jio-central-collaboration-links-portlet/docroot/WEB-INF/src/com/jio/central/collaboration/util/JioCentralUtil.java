package com.jio.central.collaboration.util;

import com.jio.central.constants.Consts;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.Group;
import com.liferay.portal.model.Layout;
import com.liferay.portal.model.Organization;
import com.liferay.portal.model.User;
import com.liferay.portal.service.GroupLocalServiceUtil;
import com.liferay.portal.service.LayoutLocalServiceUtil;
import com.liferay.portal.service.OrganizationLocalServiceUtil;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.messageboards.model.MBMessage;
import com.liferay.portlet.messageboards.service.MBMessageLocalServiceUtil;
import com.liferay.util.mail.MailEngine;
import com.liferay.util.mail.MailEngineException;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

public class JioCentralUtil {
	private static final Log LOGGER = LogFactoryUtil.getLog(JioCentralUtil.class.getName());
	
	private static JioCentralUtil jioCentralUtil = new JioCentralUtil();
	
	public static JioCentralUtil getInstance(){
		return jioCentralUtil;
	}
	
	
	/*Below message is to fetch Portlet Layout Id
	 * <usersite> name of site upon which portlet resides on a particular page
	 * <company Id> pass the instance Id
	 * <friendlyUrl> pass this custom url set for the page
	 * */
	public Long getPLId(String userSite , long companyId , String friendlyURL){
		long plId =  0L;
		try {
			 Group userSiteGroup = GroupLocalServiceUtil.getGroup(companyId, userSite);
			 Layout layout = LayoutLocalServiceUtil.getFriendlyURLLayout(userSiteGroup.getGroupId(), true, friendlyURL);
			 plId =  layout.getPlid();
		} catch (Exception e) {
			LOGGER.error("Error while creating page Layout URL:"+e.getMessage());
		}
		return plId;
	}
	
	/*
	 * Below method is to fetch MbMessageUrl
	 * <themeDisplay> used to get the layout Url
	 * <messageId> used to get the message Assests
	 * */
	public String getMbMessageUrl (ThemeDisplay themeDisplay , long messageId){
		String messageURL = "";
		try {
			String layoutURL = PortalUtil.getLayoutURL(themeDisplay);
			messageURL = layoutURL + "/-/message_boards/message/" + messageId;
		} catch (Exception e) {
			LOGGER.error("Error while creating Message URL :"+e.getMessage());
		}
		return messageURL;
	}
	
	/*
	 * <uniqueIds> list of all unique user which are tagged in a post
	 * <isReply> represents whether incoming request is reply or not
	 * Incase of reply contributer is parent's messageId creater. participator is current messageId's creater
	 * */
public static void sendMailAdd(Set<Long> uniqueIds, MBMessage mbMessage , boolean isReply , String message_URL, Set<Long> tagUserList , Set<Long> tagGroupList){
		
		try {
			// if user/org is tagged in fresh post
				if(Validator.isNotNull(uniqueIds) && uniqueIds.size()>0 && Validator.isNotNull(mbMessage) && !isReply){
					User postCreator = UserLocalServiceUtil.fetchUser(mbMessage.getUserId());
					List<User> mailToUsers = new ArrayList<User>();
					
					
					// prepare the list of tagged Users & users to whom mail is to be triggers
					String taggedMembers = "";
					for(Long userItr : uniqueIds){
						User user = UserLocalServiceUtil.fetchUser(userItr);
						if(Validator.isNotNull(user) && Validator.isNotNull(user.getEmailAddress()) && user.getEmailAddress().length()>0 && Validator.isNotNull(postCreator) ){

							// send mail to users
							mailToUsers.add(user);
						}
					}
					
					//show list of tagged Users
					if(Validator.isNotNull(tagUserList)){
						for(Long itr : tagUserList){
							User user = UserLocalServiceUtil.fetchUser(itr);
							if(Validator.isNotNull(user) && Validator.isNotNull(user.getEmailAddress()) && user.getEmailAddress().length()>0){
								taggedMembers += Consts.TAGGEDUSER_PREFIX+user.getFullName()+",";	
							}
							// get list of tagged users for diplay purpose
						}
					}
					
					//show list of tagged Group
					if(Validator.isNotNull(tagGroupList)){
						for(Long itr : tagGroupList){
							Organization organization = OrganizationLocalServiceUtil.fetchOrganization(itr);
							if(Validator.isNotNull(organization) && Validator.isNotNull(organization.getName())){
								taggedMembers += Consts.TAGGEDUSER_PREFIX+organization.getName()+",";	
							}
							// get list of tagged users for diplay purpose
						}
					}
					
					
					
					
					// iterate over mail to users and proceed with mail trigger
					if(Validator.isNotNull(mailToUsers) && mailToUsers.size()>0){
					
						// replace last character from tagged Member list
						taggedMembers = StringPool.COMMA.equalsIgnoreCase(String.valueOf(taggedMembers.charAt(taggedMembers.length()-1)))?taggedMembers.replaceAll(",+$", ""):taggedMembers;
						
						List<String> emailRecepients = new ArrayList<String>();
						
						for(User mailToUser : mailToUsers){
							emailRecepients.add(mailToUser.getEmailAddress());
						}
						
						String [] toUserEmail = new String[emailRecepients.size()];
						emailRecepients.toArray(toUserEmail);
						
						sendMailDuringFreshPost(Consts.EMAIL_SUBJECT_ADD_POST, Consts.EMAIL_BODY_ADD_POST, Consts.FROM_ADDRESS, toUserEmail, mbMessage, taggedMembers, message_URL);					
						/*Commented on Oct 12,2017
						 * for (User mailToUser : mailToUsers) {
						 	* Mail address to be sent in batch 
							 * sendMailPostAddParticipator(Consts.FROM_ADDRESS, mailToUser.getEmailAddress(), taggedMembers, Consts.EMAIL_SUBJECT_ADD_POST, Consts.EMAIL_BODY_ADD_POST, mailToUser.getFullName(), mbMessage , message_URL);
						}*/
						
					}

				
				}
				
			// if reply is triggered
				else if(  isReply && Validator.isNotNull(uniqueIds) && uniqueIds.size()>0 && Validator.isNotNull(mbMessage)){
					
					//contributer is parent's messageId
					User contributerUser = UserLocalServiceUtil.fetchUser(MBMessageLocalServiceUtil.fetchMBMessage(mbMessage.getParentMessageId()).getUserId());
					
					// participator is replyer's message id
					User participatorUser = UserLocalServiceUtil.fetchUser(mbMessage.getUserId());
					
					List<User> users = new ArrayList<User>();
					String taggedMembers = "";
					
					for(Long userItr : uniqueIds){
						User user = UserLocalServiceUtil.fetchUser(userItr);
						if(Validator.isNotNull(user) && Validator.isNotNull(user.getEmailAddress()) && user.getEmailAddress().length()>0 && Validator.isNotNull(contributerUser) && Validator.isNotNull(participatorUser))
							users.add(user);
					/*	// get list of tagged users for diplay purpose
						taggedMembers += Consts.TAGGEDUSER_PREFIX+user.getFullName()+",";*/
					}
					
					
					//show list of tagged Users
					if(Validator.isNotNull(tagUserList)){
						for(Long itr : tagUserList){
							User user = UserLocalServiceUtil.fetchUser(itr);
							if(Validator.isNotNull(user) && Validator.isNotNull(user.getEmailAddress())){
								taggedMembers += Consts.TAGGEDUSER_PREFIX+user.getFullName()+",";	
							}
							// get list of tagged users for diplay purpose
						}
					}
					
					//show list of tagged Group
					if(Validator.isNotNull(tagGroupList)){
						for(Long itr : tagGroupList){
							Organization organization = OrganizationLocalServiceUtil.fetchOrganization(itr);
							if(Validator.isNotNull(organization) && Validator.isNotNull(organization.getName())){
								taggedMembers += Consts.TAGGEDUSER_PREFIX+organization.getName()+",";	
							}
							// get list of tagged users for diplay purpose
						}
					}
					
					
					
					/*Boolean  contributerFound = false;*/
					for(User userItr : users){
						if(Validator.isNotNull(userItr) && Validator.isNotNull(userItr.getEmailAddress()) && userItr.getEmailAddress().length()>0 && Validator.isNotNull(contributerUser) && Validator.isNotNull(participatorUser)){
							
							if(userItr.getEmailAddress().equalsIgnoreCase(contributerUser.getEmailAddress())){
								sendMailPostReplyParticipator(Consts.FROM_ADDRESS, contributerUser.getEmailAddress(), participatorUser.getFullName()+" has replied to the post.", Consts.EMAIL_BODY_REPLY_POST, taggedMembers, participatorUser.getFullName(), contributerUser.getFullName(), mbMessage, message_URL);
								/*contributerFound = true;*/
							}else{
								sendMailPostReplyParticipator(Consts.FROM_ADDRESS, userItr.getEmailAddress(), participatorUser.getFullName()+" has replied to the post.", Consts.EMAIL_BODY_REPLY_POST, taggedMembers, participatorUser.getFullName(), userItr.getFullName(), mbMessage, message_URL);	
							}
							
						}else{
							LOGGER.warn("Improper data! while sending reply mail.");
						}
					}
					
					/*if(!contributerFound){
						sendMailPostReplyParticipator(Consts.FROM_ADDRESS, contributerUser.getEmailAddress(), participatorUser.getFullName()+" has replied to the post.", Consts.EMAIL_BODY_REPLY_POST, taggedMembers, participatorUser.getFullName(), contributerUser.getFullName(), mbMessage, message_URL);
					}*/
					
				}
				
				//if no user/org is tagged in fresh post
				else if( Validator.isNotNull(uniqueIds) && uniqueIds.size()==0 && Validator.isNotNull(mbMessage)){
					LOGGER.error("Neither Fresh post mail nor reply mail triggred.");
				}
			
		} catch (Exception e) {
			LOGGER.error("Error in sendMailAdd:"+e.getMessage());
			e.printStackTrace();
		}
	}
	

public static void sendMailDuringFreshPost(String subject, String body, String fromAddress, String toAddress[], MBMessage mbMessage, String taggedMembers, String messageURL){
	
	
	InternetAddress[] toAddressees =  new InternetAddress[toAddress.length];
    
    
    for (int i=0; i<toAddress.length;i++) {                              
           try {
                 toAddressees[i] = new InternetAddress(toAddress[i]);                        
           } catch (AddressException e) {                                       
                 LOGGER.error("Not a Proper EmailAddress" + toAddress[i]);
           }
    }
    
    
    try {  
           InternetAddress from = new InternetAddress(fromAddress);
        
			body = StringUtil.replace(body, new String[] { "[$USERNAME$]",
					"[$MEMBERS_TAGGED$]", "[$BODY$]", "[$MESSAGEURL$]",
					"[$MESSAGE_SUBJECT$]", "[$MESSAGE_BODY$]" }, new String[] {
					"Member",
					taggedMembers,
					body,
					messageURL,
					(Validator.isNotNull(mbMessage) ? mbMessage.getSubject(): "Click Here"),
					(Validator.isNotNull(mbMessage) ? mbMessage.getBody(): "Click here to see post") });
           
           MailEngine.send(from, new InternetAddress[0], new InternetAddress[0], toAddressees, toAddressees, subject, body, Boolean.TRUE, new InternetAddress[0], "", "");
          
           LOGGER.info("Emails have been sent to ::::" + toAddress.length);
    } catch (MailEngineException e) {
    	LOGGER.error("Mail Engine Exception " + e.getMessage());
    } catch (AddressException e) {
    	LOGGER.error("Address Exception " + e.getMessage());
    } catch (Exception e) {
    	LOGGER.error("Main Exception " + e.getMessage());
    }
	
	
}



/*Commented on Oct 12, 2017
 * ABove mail method gets called now on during fresh post
 * Reason: Email server incapability
 * 
 * public static void sendMailPostAddParticipator(String fromAddress,
		String toAddress,String taggedMembers, String subject, String body, String contributorUserName,
		MBMessage mbMessage, String messageURL) {
	try {
		
		
		InternetAddress from = new InternetAddress(fromAddress);
		InternetAddress to = new InternetAddress(toAddress);
		body = StringUtil.replace(body, new String []{"[$USERNAME$]","[$MEMBERS_TAGGED$]","[$BODY$]","[$MESSAGEURL$]","[$MESSAGE_SUBJECT$]","[$MESSAGE_BODY$]" }, new String []{contributorUserName,taggedMembers,body,messageURL,(Validator.isNotNull(mbMessage)?mbMessage.getSubject():"Click Here"),(Validator.isNotNull(mbMessage)?mbMessage.getBody():"Click here to see post")});
		
		MailEngine.send(from, to, subject, body, Boolean.TRUE);
		
		
		}
	 	catch (Exception exception) {
			if(exception instanceof AddressException ){
				LOGGER.error("Unable to send message to user ="+toAddress+", for MessageId: "+mbMessage.getMessageId());
				LOGGER.error("Error while sending email during add post Address exp ::> "+exception.getMessage());
			}
			else if(exception instanceof MailEngineException ){
				LOGGER.error("Error while sending email during add post MailEngineException ::> "+exception	.getMessage());	
			}
			else if(exception instanceof NullPointerException ){
				LOGGER.error("Error while sending email during add post NullPointerException ::> "+exception.getMessage());	
			}
			else{
				LOGGER.error("Error while sending email during add post Exception ::> "+exception);
			}
	 		
		}
}*/

	public static void sendMailPostReplyParticipator(String fromAddress, String contributorAddress, 
			String subject, String body, String taggedMembers , String participatorUserName, String contributorUserName, MBMessage mbMessage ,String messagURL) {				

	try {
		InternetAddress from = new InternetAddress(fromAddress);
		InternetAddress to = new InternetAddress(contributorAddress);
		
			body = StringUtil.replace(body, new String[] {"[$CONTRIBUTOR_USERNAME$]","[$SUBJECT$]","[$MEMBERS_TAGGED$]","[$BODY$]", "[$MESSAGEURL$]", "[$MEMBER_REPLY$]","[$MESSAGE_SUBJECT$]","[$MESSAGE_BODY$]" },new String[] {contributorUserName,subject,taggedMembers,body,messagURL,participatorUserName,(Validator.isNotNull(mbMessage)?mbMessage.getSubject():"Click Here"),(Validator.isNotNull(mbMessage)?mbMessage.getBody():"Click here to see post.")});
			MailEngine.send(from, to, subject, body, Boolean.TRUE);
		
		} catch (AddressException addressException) {
			LOGGER.error("Error while sending email for reply post to participator ::> "+addressException.getMessage());
		} catch (MailEngineException mailEngineException) {
			LOGGER.error("Error while sending email for reply post to participator ::> "+mailEngineException.getMessage());
		}catch (Exception exception) {
			LOGGER.error("Error while sending email for reply post to participator ::> "+exception);
		}
	
	}

	public static void sendJoinGroupMail(String fromAddress, String toUserEmail,String toUserName, String description,String subject,String body) {
		try {
			InternetAddress from = new InternetAddress(fromAddress);
			InternetAddress to = new InternetAddress(toUserEmail);

			body = StringUtil.replace(body, new String[] {
					"[$USERNAME$]","[$SUBJECT$]",
					"[$DESCRIPTION$]" },
					new String[] {toUserName,subject,description});
			MailEngine.send(from, to, subject, body, Boolean.TRUE);
			LOGGER.debug("Join Group Request Mail Sent");
		} catch (AddressException e) {
			LOGGER.error("Error while sending email for join group request ::> "+e.getMessage());
		} catch (MailEngineException e) {
			LOGGER.error("Error while sending email for join group request ::> "+e.getMessage());
		}
	}


	public static void sendApprovedJoin(String fromAddress,
			String toUserEmail, String toUserName, String description,
			String subject, String body) {
		try {
			InternetAddress from = new InternetAddress(fromAddress);
			InternetAddress to = new InternetAddress(toUserEmail);

			body = StringUtil.replace(body, new String[] {
					"[$USERNAME$]","[$SUBJECT$]",
					"[$DESCRIPTION$]" },
					new String[] {toUserName,subject,description});
			MailEngine.send(from, to, subject, body, Boolean.TRUE);
			
			LOGGER.debug("Mail sent for approval");
		} catch (AddressException e) {
			LOGGER.error("Error while sending mail to assigned members ::> "+e.getMessage());
		} catch (MailEngineException e) {
			LOGGER.error("Error while sending mail to assigned members ::> "+e.getMessage());
		}
	}
	
}
