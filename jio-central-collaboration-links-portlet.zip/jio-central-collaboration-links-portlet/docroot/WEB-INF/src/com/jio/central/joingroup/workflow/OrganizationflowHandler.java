package com.jio.central.joingroup.workflow;

import com.jio.central.collaboration.util.JioCentralUtil;
import com.jio.central.constants.Consts;
import com.jio.central.services.custom.tables.model.JoinOrganization;
import com.jio.central.services.custom.tables.service.JoinOrganizationLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.workflow.BaseWorkflowHandler;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.service.UserServiceUtil;
import com.liferay.portlet.asset.service.AssetEntryLocalServiceUtil;

import java.io.Serializable;
import java.util.Locale;
import java.util.Map;

public class OrganizationflowHandler  extends BaseWorkflowHandler{
	
	@Override
	 public String getClassName() {
        return CLASS_NAME;
    }
	
	@Override
	  public String getType(Locale locale) {
        return TYPE;
    }
 

	public JoinOrganization updateStatus(int status, Map<String, Serializable> workflowContext)
			throws PortalException, SystemException {
		
			long userId = GetterUtil.getLong(workflowContext.get(WorkflowConstants.CONTEXT_USER_ID));
	        long resourcePrimKey = GetterUtil.getLong(workflowContext.get(WorkflowConstants.CONTEXT_ENTRY_CLASS_PK));
	        JoinOrganization feedback = JoinOrganizationLocalServiceUtil.getJoinOrganization(resourcePrimKey);
	        feedback.setJoinOrganizationStatus(status);
	        feedback.setUserId(userId);
	        User requestor = UserLocalServiceUtil.getUser(userId);
	        
	        feedback=JoinOrganizationLocalServiceUtil.updateJoinOrganization(feedback);
	        if (status == WorkflowConstants.STATUS_APPROVED) {
	        	long[] userIds = {userId};
	        	UserServiceUtil.addOrganizationUsers(feedback.getOrganizaId(), userIds);
	        	
	            AssetEntryLocalServiceUtil.updateVisible(JoinOrganization.class.getName(),
	                    resourcePrimKey, true);
	            
	            //send approved mail
	            String subject = "Welcome to " + feedback.getJoinOrganizationName();
	            String description = "Welcome! You're now a member of " + feedback.getJoinOrganizationName();
	            _log.debug("Join group request approved");
	            JioCentralUtil.sendApprovedJoin(Consts.FROM_ADDRESS, requestor.getEmailAddress(),requestor.getFirstName(),description,subject,Consts.EMAIL_BODY_APPROVED_GROUP);
	        }else if(status == WorkflowConstants.STATUS_DENIED){
	        	//send reject mail
	            String subject = "Your Join Group request was rejected for " + feedback.getJoinOrganizationName();
	            String description = "Your submission was rejected by "+feedback.getJoinOrganizationName()+
	            		 " owner , please modify and resubmit.";
	            _log.debug("Join group request rejected");
	        	JioCentralUtil.sendApprovedJoin(Consts.FROM_ADDRESS, requestor.getEmailAddress(),requestor.getFirstName(),description,subject,Consts.EMAIL_BODY_APPROVED_GROUP);
	        }
	        else {
	        	AssetEntryLocalServiceUtil.updateVisible(JoinOrganization.class.getName(),
	                    resourcePrimKey, false);
	        }
	        return feedback;
	}

	    public static final String CLASS_NAME = JoinOrganization.class.getName();
	    private static final String TYPE = "Join Group";
	    private static Log _log = LogFactoryUtil.getLog(JoinOrganization.class);
}
