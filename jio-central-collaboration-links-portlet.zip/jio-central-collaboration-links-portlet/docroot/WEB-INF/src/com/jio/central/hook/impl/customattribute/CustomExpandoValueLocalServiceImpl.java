package com.jio.central.hook.impl.customattribute;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.jio.central.constants.Consts;
import com.jio.central.services.custom.tables.model.MessageUserGroup;
import com.jio.central.services.custom.tables.model.impl.MessageUserGroupImpl;
import com.jio.central.services.custom.tables.service.MessageUserGroupLocalServiceUtil;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.HtmlUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.security.auth.PrincipalThreadLocal;
import com.liferay.portlet.expando.model.ExpandoValue;
import com.liferay.portlet.expando.service.ExpandoValueLocalService;
import com.liferay.portlet.expando.service.ExpandoValueLocalServiceWrapper;
import com.liferay.util.portlet.PortletProps;

public class CustomExpandoValueLocalServiceImpl extends ExpandoValueLocalServiceWrapper {
	
	
	private Log LOGGER = LogFactoryUtil.getLog(CustomExpandoValueLocalServiceImpl.class.getName());
	
	/* (non-Java-doc)
	 * @see com.liferay.portlet.expando.service.ExpandoValueLocalServiceWrapper#ExpandoValueLocalServiceWrapper(ExpandoValueLocalService expandoValueLocalService)
	 * 
	 * classPk here will show new updated messageId not the original messageId initially shared incase of post sharing
	 */
	public CustomExpandoValueLocalServiceImpl(ExpandoValueLocalService expandoValueLocalService) {
		
		super(expandoValueLocalService);
	}

	
	/*Below method used for share data column operation*/
	@Override
	public ExpandoValue addValue(long companyId, String className,
			String tableName, String columnName, long classPK, String data)
			throws PortalException, SystemException {
	
		
		return super.addValue(companyId, className, tableName, columnName, classPK,
				data);
	}
	
	/*
	 * During tag User and group below method receives call.
	 * 
	 * <companyId>  : Default company ID
	 * <className>  : MbMessage.class
	 * <tableName>  : Custom_field
	 * <columnName> : custom attributes created in message board
	 * <classPK>	: MbMessage's messageId
	 * <data>		: Array of custom field value as they are of type group of text values.
	 * 
	 * */
	@Override
	public ExpandoValue addValue(long companyId, String className,
			String tableName, String columnName, long classPK, String[] data)
			throws PortalException, SystemException {
		
		
		
		// declare all local variables
        ExpandoValue expandoValue = null;
        String [] storeUserdataArray  = new String[0];
        
		
		// get the name of custom attribute fields created in message boards
				String grpFldNameFrmProp = HtmlUtil.escape(PortletProps.get("custom.attribute.field.name.group"));
				String usrFldNameFrmProp = HtmlUtil.escape(PortletProps.get("custom.attribute.field.name.user"));
				
				
				
				
		// Check first {Empty user list}
		// if any user is tagged then below condition is satisfied
		if(Validator.isNotNull(usrFldNameFrmProp) && usrFldNameFrmProp.equalsIgnoreCase(columnName)){
			
			performUserGroupOp( data, classPK, Boolean.FALSE);
			
		}
		// In case any group is tagged then below condition is satisfied
		else if(Validator.isNotNull(grpFldNameFrmProp) && grpFldNameFrmProp.equalsIgnoreCase(columnName)){
			
			performUserGroupOp( data, classPK, Boolean.TRUE);
		}
		
		
		expandoValue = super.addValue(companyId, className, tableName, columnName, classPK, storeUserdataArray);
		
		return expandoValue;
	}
	
	
/*
 * User check points
 * 
 * */
	
	
	private void performUserGroupOp ( String[] data, Long classPK, Boolean isGroup){

		
		try{
			
	
		int initArrayLength = 0;
		
		
		for(String itr : data){
			initArrayLength = itr.length();
		}
		
		
		/* check if first ever entry or Edit entry
		 * */
		if(initArrayLength==0){
			 checkEmptyInstance(data ,classPK , isGroup);
		}
		
		/*
		 * If initial user list is not empty then check for following scenario
		 * 1. New user/Group list entry
		 * 2. Same user/Group list returned
		 * 3. few entry has been removed from previously user/Group list on edit page
		 * 
		 * */
		else{
			Set<String> allSetObj = new HashSet<String>();
			List<String> shallowCopy = new ArrayList<String>();
			
			
			List<String> currentUserDbEntry = MessageUserGroupLocalServiceUtil.getAllMessageUserGroupNamebyMessageId(classPK, isGroup);
			
			shallowCopy.addAll(currentUserDbEntry);
			
			// split all tagged group by delimiter			
			String[] dataArr = data[0].split(Consts.customAttrDelimiter);
			for(int i = 0; i < dataArr.length ; i++){
				
				if(dataArr[i].length()>0){
					allSetObj.add(dataArr[i].trim());
				}
				
			}
			// allUser set has fresh entry from jsp
			if(Validator.isNotNull(allSetObj) && allSetObj.size()>0 && !allSetObj.isEmpty()){
				
				// userid-userName
				for(String iterator : allSetObj){
					
					// Shallocopy has name of user or group as they are considered to save screenName of groupName which is always going to be unique
					if(shallowCopy.contains(iterator.split("\\"+Consts.customAttrDelimiterPidName)[1])){
					
						shallowCopy.remove(iterator.split("\\"+Consts.customAttrDelimiterPidName)[1]);	
						LOGGER.info("@override Already User/Group present"+iterator);
					
					}
					// if no match found then add to db
					else{
						
						MessageUserGroup userGroupAttributeMapping = MessageUserGroupLocalServiceUtil.createMessageUserGroup(CounterLocalServiceUtil.increment());
						userGroupAttributeMapping.setMessageid(classPK);
						userGroupAttributeMapping.setIsgroup(isGroup);
						userGroupAttributeMapping.setUserorgrp_name(iterator.split("\\"+Consts.customAttrDelimiterPidName)[1]);
						userGroupAttributeMapping.setUserorgrp_id(Long.valueOf(iterator.split("\\"+Consts.customAttrDelimiterPidName)[0]));
						userGroupAttributeMapping.setCreatedbyuserid(Long.valueOf(PrincipalThreadLocal.getName()));
						
						MessageUserGroupLocalServiceUtil.addMessageUserGroup(userGroupAttributeMapping);
						
						
						shallowCopy.remove(iterator.split("\\"+Consts.customAttrDelimiterPidName)[1]);
					}
					
				}// end of for loop
				
				
				if(Validator.isNotNull(shallowCopy) && shallowCopy.size()>0){
					List<Long>delObj = null;
					
					for(String nameItr : shallowCopy){
						delObj = MessageUserGroupLocalServiceUtil.getAllMessageUserGroupPidbyUsrGrpName(nameItr, isGroup, classPK);	
						
						if(Validator.isNotNull(delObj)){
							for(Long delPidItr : delObj){
								MessageUserGroupLocalServiceUtil.deleteMessageUserGroup(delPidItr);
							}
						
				
				
						}
					
					}
					
				}
				
				
			}
			
			
			
			
			
		}/* no more user operation */
		
	}catch(Exception e){
		LOGGER.error("Err:::",e);
	}
	
		
	}
	
	
	
	private void checkEmptyInstance(String [] data, long messageId , Boolean isGroup){
		
		try {
			
				/*
				 *  first time of user array list
				 *  No addition at all
				 *  
				 * */
			List<Long>messagUserGroupPidObj = MessageUserGroupLocalServiceUtil.getAllMessageUserGroupPid(messageId, isGroup);
		
			// if something is present then delete all of them
			if(Validator.isNotNull(messagUserGroupPidObj)){
			
				for(Long messagUserGroupPid : messagUserGroupPidObj){
					MessageUserGroupLocalServiceUtil.deleteMessageUserGroup(messagUserGroupPid);
				}
				
			}
			// if no result found then none of the user/group is tagged yet
			else{
				// simply do nothing
				//System.out.println("No user/group tagged yet...");
			}
			
		} catch (Exception e) {
			LOGGER.error("Error in first check point::",e);
		}
	}
}