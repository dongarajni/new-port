package com.jio.central.collaboration.util;

import com.jio.central.constants.Consts;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.util.portlet.PortletProps;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.portlet.ActionRequest;


public class ImageValidation {

	private Log LOGGER = LogFactoryUtil.getLog(ImageValidation.class.getName());
	
	
	/*
	 * Current validation:
	 * 1. Mime (pdf, text , jpg , png , gif , word)
	 * 2. FIle size
	 * */
	public List<String> imageValidation(String mimeTypes,String fileName , long fileSize , String extension ){
		List<String> errorList = new ArrayList<String>();
		
		try {
			
			String mimeType = mimeTypes;
			long userGroupPortraitFileSize = Long.valueOf(PropsUtil.get("users.image.max.size"));
			
					// check file format
					if(/*!"application/vnd.openxmlformats-officedocument.wordprocessingml.document".equalsIgnoreCase(mimeType) &&*/
                            /*!"application/pdf".equalsIgnoreCase(mimeType) &&*/
                            /*!"text/plain".equalsIgnoreCase(mimeType) &&*/
                            !"image/jpeg".equalsIgnoreCase(mimeType) &&
                            !"image/png".equalsIgnoreCase(mimeType) /*&&
                            !"image/gif".equalsIgnoreCase(mimeType) */) {
		                     LOGGER.error("Error in parsing file::"+fileName+"::mimeType is::"+mimeType);
		                     errorList.add(Consts.MIMEEXCEPTION);
		                     
					}
					
					// check file size
					if(fileSize>userGroupPortraitFileSize){
						LOGGER.error("Filesize :"+fileSize+"greater than allowed file size >"+userGroupPortraitFileSize);
						errorList.add( Consts.PORTRAITSIZEEXCEPTION);
					}
					
					
					if(!Arrays.asList(PortletProps.get("displaypic.extension.allowed").split(",")).contains(extension)){
						LOGGER.error("Error during extension check while parsing file::"+fileName+"::extn is::"+extension);
	                    errorList.add(Consts.MIMEEXCEPTION);
					}
					
					
		} catch (Exception e) {
			LOGGER.error("Error in image validation"+e.getMessage());
		}

		return errorList;
	}
	
	
	public void setErrorMessages (ActionRequest actionRequest , String err){
		
		try {
			if(Consts.PORTRAITSIZEEXCEPTION.equals(err)){
				SessionErrors.add(actionRequest, Consts.PORTRAITSIZEEXCEPTION);
			}
			if(Consts.MIMEEXCEPTION.equals(err)){
				SessionErrors.add(actionRequest, Consts.MIMEEXCEPTION);
			}
			if("errorDisplayPic".equals(err)){
				SessionErrors.add(actionRequest, "errorDisplayPic");
			}
		} catch (Exception e) {
				LOGGER.error("Error in setting error messages"+e.getMessage());
		}
	}
	
}
