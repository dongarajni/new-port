package com.jio.central.collaboration.menu.configuration;

import com.liferay.portal.kernel.portlet.DefaultConfigurationAction;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.Constants;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portlet.PortletPreferencesFactoryUtil;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletConfig;
import javax.portlet.PortletPreferences;

/**
 * The type Social wall configuration action.
 */
public class MenuConfiguration extends DefaultConfigurationAction {

	/*
	 * @Override public void processAction(PortletConfig portletConfig,
	 * ActionRequest actionRequest, ActionResponse actionResponse) throws
	 * Exception {
	 *
	 * String cmd = ParamUtil.getString(actionRequest, Constants.CMD); if
	 * (!cmd.equals(Constants.UPDATE)) { return; }
	 *
	 * savePreferences(actionRequest, "menuItemsIndex",
	 * MenuWallConstants.Preferences.MENU_ITEM_PEOPLE);
	 *
	 *
	 * super.processAction(portletConfig, actionRequest, actionResponse); }
	 *
	 * private void savePreferences(ActionRequest actionRequest, String
	 * paramIndexes, String paramWall) { String string =
	 * ParamUtil.getString(actionRequest, paramIndexes); int[] indexes =
	 * StringUtil.split(string, 0); String[] tab = new String[indexes.length];
	 * for (int i = 0; i < indexes.length; i++) { int index = indexes[i]; String
	 * param = ParamUtil.getString(actionRequest, paramWall + index); tab[i] =
	 * param; } setPreference(actionRequest, paramWall, tab); }
	 */

	@Override
	public void processAction(PortletConfig portletConfig, ActionRequest actionRequest, ActionResponse actionResponse)
			throws Exception {

		System.out.println("Here proceess.......");

		String portletResource = ParamUtil.getString(actionRequest, "portletResource");

		 PortletPreferences prefs = PortletPreferencesFactoryUtil.getPortletSetup(actionRequest, portletResource);

		 String cmd = ParamUtil.getString(actionRequest, Constants.CMD);

		if (cmd.equalsIgnoreCase("ADD_PARENT")) {
			System.out.println("ADD_PARENT");
			 String userInput = ParamUtil.getString(actionRequest, "parentEle", StringPool.BLANK);
			String parentEles = prefs.getValue("parent_eles", StringPool.BLANK);
			if (!userInput.equals(StringPool.BLANK)) {

				// check for first entry
				if (parentEles.equals(StringPool.BLANK)) {
					parentEles = userInput;
				} else {
					parentEles = parentEles + StringPool.COMMA + userInput;
				}

				prefs.setValue("parent_eles", parentEles);
				prefs.store();
			}
			SessionMessages.add(actionRequest, "preference-set-successfully");
			SessionMessages.add(actionRequest,
					portletConfig.getPortletName() + SessionMessages.KEY_SUFFIX_REFRESH_PORTLET, portletResource);
		} else if (cmd.equalsIgnoreCase("ADD_CHILD")) {
			System.out.println("ADD_CHILD");

			 String forParentEle = ParamUtil.getString(actionRequest, "forParentEle", StringPool.BLANK);
			 String childEle = ParamUtil.getString(actionRequest, "childEle", StringPool.BLANK);

			System.out.println("forParentEle " + forParentEle);
			System.out.println("childEle " + childEle);

			// check for proper input
			if (!(forParentEle.equals(StringPool.BLANK) && childEle.equals(StringPool.BLANK))) {
				// we are considering "getChildsForParent_<parent name>" as key
				// to fetch childs
				 String keyForChild = "getChildsForParent_" + forParentEle;
				String childs = prefs.getValue(keyForChild, StringPool.BLANK);

				// check for first entry
				if (childs.equals(StringPool.BLANK)) {
					childs = childEle;
				} else {
					childs = childs + StringPool.COMMA + childEle;
				}

				prefs.setValue(keyForChild, childs);
				prefs.store();
				System.out.println("childs : " + childs);
				SessionMessages.add(actionRequest, "preference-set-successfully");
				SessionMessages.add(actionRequest,
						portletConfig.getPortletName() + SessionMessages.KEY_SUFFIX_REFRESH_PORTLET, portletResource);
			}

		}

		super.processAction(portletConfig, actionRequest, actionResponse);
	}

}
