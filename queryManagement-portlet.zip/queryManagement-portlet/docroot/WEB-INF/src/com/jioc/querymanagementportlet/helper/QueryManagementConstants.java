package com.jioc.querymanagementportlet.helper;

public class QueryManagementConstants {

	public static final String FILENAME = "fileName";
	public static final String UPLOADED_FILE = ".csv";
}
