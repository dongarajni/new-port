package com.jioc.querymanagementportlet.helper;

import com.jioc.query.NoSuchQuery_AttachmentsException;
import com.jioc.query.model.Query_Attachments;
import com.jioc.query.model.Query_Transaction;
import com.jioc.query.service.Query_AttachmentsLocalServiceUtil;
import com.jioc.query.service.Query_TransactionLocalServiceUtil;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.repository.model.Folder;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.MimeTypesUtil;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.documentlibrary.model.DLFileShortcut;
import com.liferay.portlet.documentlibrary.model.DLFolder;
import com.liferay.portlet.documentlibrary.model.DLFolderConstants;
import com.liferay.portlet.documentlibrary.service.DLAppLocalServiceUtil;
import com.liferay.portlet.documentlibrary.service.DLFolderLocalServiceUtil;
import com.liferay.portlet.documentlibrary.service.DLFolderServiceUtil;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import sun.nio.cs.ext.ISCII91;

public class QueryManagementHelper {
	private static final Log LOGGER = LogFactoryUtil.getLog(QueryManagementHelper.class);
	private static final String FILE_PATH=GetterUtil.getString(PropsUtil.get("jioc.querymanagement.file.path"));
	private static final String FOLDER_NAME=GetterUtil.getString(PropsUtil.get("jioc.dl.querymanagement.folder"));

	public static void processCSV(ActionRequest actionRequest,ActionResponse actionResponse) {

		UploadRequest request = PortalUtil.getUploadPortletRequest(actionRequest);
        File file = request.getFile(QueryManagementConstants.FILENAME);
		if(isCSVFile(file)){
			FileReader fileReader = null;
	        CSVParser csvFileParser = null;
	        List<String> success = new ArrayList<String>();
			List<String> failure = new ArrayList<String>();
	        try {
	        	CSVFormat csvFileFormat = CSVFormat.DEFAULT.withHeader().withDelimiter(',');
	            fileReader = new FileReader(file);
				csvFileParser = new CSVParser(fileReader, csvFileFormat);
				List<CSVRecord> csvRecords = csvFileParser.getRecords();
				
				for (int i = 0; i < csvRecords.size(); i++) {
					CSVRecord record = csvRecords.get(i);
	                long queryId = Long.valueOf(record.get("Query_Id"));
	                String fileName= record.get("File_Name");
	                
	                System.out.println("QueryId==>>"+queryId);
	                System.out.println("fileName==>>"+fileName);
	                
	                long fileEntryId = getFileEntry(actionRequest, actionResponse, fileName);
	                System.out.println("fileEntryId==>>"+fileEntryId);
	                processRecord(queryId,fileName,fileEntryId);
				}
	        }catch (FileNotFoundException e) {
	        	LOGGER.error("Error occurred during fileReader");
			} catch (IOException e) {
				LOGGER.error("Error occurred during fileReader");
			}finally {
               try {
                     if(fileReader !=null){
                            fileReader.close();
                     }
                     if(csvFileParser !=null){
                            csvFileParser.close();
                     }
               } catch (IOException e) {
                     LOGGER.error("Error occurred during closing stream");
               }
               LOGGER.info(" ================================================= SUCCESS =========================================================");
               LOGGER.info("Success Count : "+success.size());
               for (String s : success) {
            	   LOGGER.info(s);
               }
               LOGGER.info("Success Count : "+success.size());
               LOGGER.info("\n");
               
               LOGGER.info(" ================================================= FAILURE =========================================================");
               LOGGER.info("Failure Count : "+failure.size());
               for (String f : failure) {
            	   LOGGER.info(f);
               }
               LOGGER.info("Failure Count : "+failure.size());
			}
		}else{
			SessionErrors.add(actionRequest,"csv-upload-error");
		}
		
		SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
	}

	private static long getFileEntry(ActionRequest actionRequest,ActionResponse actionResponse, String fileName) {

		long fileEntryid = 0;
        if(Validator.isNotNull(fileName)){
        	FileEntry fileEntry = addFile(actionRequest, actionResponse, fileName);
        	if(Validator.isNotNull(fileEntry)){
        		fileEntryid = fileEntry.getFileEntryId();
        	}else{
        		fileEntry = getFile(actionRequest, actionResponse, fileName);
        		fileEntryid = fileEntry.getFileEntryId();
        	}
        }
		return fileEntryid;
	}

	private static FileEntry getFile(ActionRequest actionRequest,ActionResponse actionResponse, String fileName) {
		ThemeDisplay themeDisplay = (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long groupId=themeDisplay.getLayout().getGroupId();
		long parentFolderId=DLFolderConstants.DEFAULT_PARENT_FOLDER_ID;
		DLFolder dir=null;
		try{
			dir=DLFolderLocalServiceUtil.getFolder(groupId, parentFolderId, FOLDER_NAME);
		}catch(Exception e){
			LOGGER.error("Error while getting folder ::> "+e.getMessage());
		}
		FileEntry fileEntry = null;
		try {
			fileEntry = DLAppLocalServiceUtil.getFileEntry(groupId, dir.getFolderId(), fileName);
		} catch (PortalException e) {
			LOGGER.error("Error while getting file ::> "+e.getMessage());
		} catch (SystemException e) {
			LOGGER.error("Error while getting file ::> "+e.getMessage());
		}
		return fileEntry;
	}

	private static FileEntry addFile(ActionRequest actionRequest,ActionResponse actionResponse, String fileName) {
		ThemeDisplay themeDisplay = (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long groupId=themeDisplay.getLayout().getGroupId();
		long parentFolderId=DLFolderConstants.DEFAULT_PARENT_FOLDER_ID;
		
		String filepath =PropsUtil.get(PropsKeys.LIFERAY_HOME)+File.separator+"data"+File.separator+FILE_PATH+File.separator+fileName;
		boolean isExists = new File(filepath).exists();
		File sourceFile = new File(filepath);
		
		if(!isExists || Validator.isNull(sourceFile)){
			LOGGER.error("No file found at path : "+filepath);
			return null;
		}
		FileEntry fileEntry =null;
		DLFolder dir=null;
		
		try{
			dir=DLFolderLocalServiceUtil.getFolder(groupId, parentFolderId, FOLDER_NAME);
			
		}catch(Exception e){
			LOGGER.error("Error while getting folder ::> "+e.getMessage());
		}
		
		if(Validator.isNull(dir)){
			long repositoryId=themeDisplay.getScopeGroupId();
			try {
				ServiceContext serviceContext=ServiceContextFactory.getInstance(DLFileShortcut.class.getName(), actionRequest);
				serviceContext.setAddGuestPermissions(true);
				dir=DLFolderServiceUtil.addFolder(groupId, repositoryId, false, parentFolderId, FOLDER_NAME, null, serviceContext);
			} catch (PortalException e) {
				LOGGER.error("Error while adding folder ::> "+e.getMessage());
			} catch (SystemException e) {	
				LOGGER.error("Error while adding folder ::> "+e.getMessage());
			}
		}
		
		try {
			ServiceContext serviceContext=ServiceContextFactory.getInstance(DLFileShortcut.class.getName(), actionRequest);
			serviceContext.setAddGuestPermissions(true);
			Folder folder = DLAppLocalServiceUtil.getFolder(dir.getFolderId());
			fileEntry = DLAppLocalServiceUtil.addFileEntry(themeDisplay.getUserId(), folder.getRepositoryId(), folder.getFolderId(), fileName, MimeTypesUtil.getContentType(sourceFile), fileName, StringPool.BLANK, StringPool.BLANK, sourceFile, serviceContext);
		} catch (PortalException e) {
			LOGGER.error("Error while adding fileEntry ::> "+e.getMessage());
		} catch (SystemException e) {
			LOGGER.error("Error while adding fileEntry ::> "+e.getMessage());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return fileEntry;
	}

	private static void processRecord(long queryId, String fileName,long fileEntryId) {
		
		
		Query_Transaction query_Transaction = null;
		Date updateDate = null;
		try {
			query_Transaction=Query_TransactionLocalServiceUtil.getQuery_Transaction(queryId);
			updateDate= query_Transaction.getRaisedTimestamp();
		} catch (PortalException e1) {
			LOGGER.error("Error while getting query transaction ::> "+e1.getMessage());
		} catch (SystemException e1) {
			LOGGER.error("Error while getting query transaction ::> "+e1.getMessage());
		}
		
		Query_Attachments query_attachment = null;
		try {
			query_attachment = Query_AttachmentsLocalServiceUtil.getQueryByQueryIdAndFileEntryId(queryId, fileEntryId);
		} catch (NoSuchQuery_AttachmentsException e1) {
			LOGGER.info("Exception while getting query attachment ::> "+e1.getMessage());
		} catch (SystemException e1) {
			LOGGER.info("Exception while getting query attachment ::> "+e1.getMessage());
		}
		
		if(Validator.isNull(query_attachment)){
			try {
				query_attachment = Query_AttachmentsLocalServiceUtil.createQuery_Attachments(CounterLocalServiceUtil.increment(Query_Attachments.class.getName()));
			} catch (SystemException e) {
				LOGGER.error("error occurred while query attachment increment");
			}
		}
		query_attachment.setFileEntryId(fileEntryId);
		query_attachment.setUpdatedTimestamp(updateDate);
		query_attachment.setQueryId(queryId);
		query_attachment.setFile_name(fileName);
			
		try {
			Query_AttachmentsLocalServiceUtil.updateQuery_Attachments(query_attachment);
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public static boolean isCSVFile(File file) {
        if(QueryManagementConstants.UPLOADED_FILE.equals(getFileExtension(file))){
               return true;
        }else{
               return false;
        }
	}

	public static String getFileExtension(File file) {
        String name = file.getName();
	     try {
	         return name.substring(name.lastIndexOf("."));
	     } catch (Exception e) {
	         return StringPool.BLANK;
	     }
	 }

}
