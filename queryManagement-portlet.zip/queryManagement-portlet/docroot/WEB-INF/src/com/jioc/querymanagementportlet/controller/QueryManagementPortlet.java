package com.jioc.querymanagementportlet.controller;

import com.jioc.querymanagementportlet.helper.QueryManagementHelper;
import com.liferay.util.bridges.mvc.MVCPortlet;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

/**
 * Portlet implementation class QueryManagementPortlet
 */
public class QueryManagementPortlet extends MVCPortlet {
 
	public void uploadQueryManagementCSV(ActionRequest actionRequest,ActionResponse actionResponse){
		QueryManagementHelper.processCSV(actionRequest,actionResponse);
	}

}
