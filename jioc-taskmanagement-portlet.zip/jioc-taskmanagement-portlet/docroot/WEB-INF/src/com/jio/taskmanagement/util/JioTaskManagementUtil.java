package com.jio.taskmanagement.util;

import com.jioc.taskmanagement.model.TaskDetails;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.util.mail.MailEngine;
import com.liferay.util.mail.MailEngineException;

import java.util.List;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

public class JioTaskManagementUtil {
	
	private static final Log _log = LogFactoryUtil.getLog(JioTaskManagementUtil.class);
	
	
	
	public static void sendMailTaskAssignment(String fromAddress, String toAddress, String subject, 
				String body, String toUserName, long assigneeTaskId, List<TaskDetails> taskDetailsList) {				

		try {
			InternetAddress from = new InternetAddress(fromAddress);
			InternetAddress to = new InternetAddress(toAddress);
			//body = StringUtil.replace(body, "[$USERNAME$]", participatorUserName);
			subject = StringUtil.replace(subject, new String[]{"[$ASSIGNEETASKID$]"}, new String []{String.valueOf(assigneeTaskId)});
			    //open table..
			  String htmlBody = "<table border='1'><tr><th>S.No.</th><th>KPI</th><th>Target</th></tr>";

			    //iterate over list and output columns/data into table rows...
			int count = 1;
			for (TaskDetails taskDetails : taskDetailsList) {
				String description = taskDetails.getDescription(); 
				long target = taskDetails.getTarget(); 
		        
		        htmlBody += "<tr><td>" + count + "</td><td>" + description + "</td><td>" + target + "</td></tr>";
		        count++;
			}
			
			htmlBody += "</table>";
			
			
			body = StringUtil.replace(body, new String []{"[$USERNAME$]","[$ASSIGNEETASKID$]", "[$TASKASSIGNMENTTABLE$]" }, new String []{toUserName,String.valueOf(assigneeTaskId),htmlBody});
			MailEngine.send(from, to, subject, body, Boolean.TRUE);
			} catch (AddressException e) {
			_log.error("Error while sending email for add post ::> "+e.getMessage());
			} catch (MailEngineException e) {
			_log.error("Error while sending email for add post ::> "+e.getMessage());
			}
		}	
	
	
	public static void sendMailTaskCompleted(String fromAddress, String toAddress, String subject, 
			String body, String toUserName, long assigneeTaskId) {				

	try {
		InternetAddress from = new InternetAddress(fromAddress);
		InternetAddress to = new InternetAddress(toAddress);
		//body = StringUtil.replace(body, "[$USERNAME$]", participatorUserName);
		subject = StringUtil.replace(subject, new String[]{"[$ASSIGNEETASKID$]"}, new String []{String.valueOf(assigneeTaskId)});
		body = StringUtil.replace(body, new String []{"[$USERNAME$]","[$ASSIGNEETASKID$]" }, new String []{toUserName,String.valueOf(assigneeTaskId)});
		MailEngine.send(from, to, subject, body, Boolean.TRUE);
		} catch (AddressException e) {
		_log.error("Error while sending email for add post ::> "+e.getMessage());
		} catch (MailEngineException e) {
		_log.error("Error while sending email for add post ::> "+e.getMessage());
		}
	}	
		
	
}
