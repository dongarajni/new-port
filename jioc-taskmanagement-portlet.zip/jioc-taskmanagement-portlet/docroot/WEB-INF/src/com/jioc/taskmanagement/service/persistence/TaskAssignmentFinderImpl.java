package com.jioc.taskmanagement.service.persistence;

import com.jioc.taskmanagement.model.TaskAssignment;
import com.jioc.taskmanagement.model.impl.TaskAssignmentImpl;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.SQLQuery;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;
import com.liferay.util.dao.orm.CustomSQLUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class TaskAssignmentFinderImpl extends BasePersistenceImpl<TaskAssignment> implements TaskAssignmentFinder{

	
	public List<TaskAssignment> getAllTasksAndAssignUserToMeByStatus(long userId,String status, String fromDate, String toDate){
        
        Session session = null;
        SQLQuery queryObject = null;
        try{
        	
        	session = openSession();
            String sql = CustomSQLUtil.get("com.jioc.taskmanagement.service.persistence.getAllTasksAssignToMebyStatusAdnDate");
            //sql = StringUtil.replace(sql, "[$USER_ID$]", String.valueOf(userId));
            
                        
            queryObject = session.createSQLQuery(sql);
            queryObject.setCacheable(false);
            
            QueryPos qPos = QueryPos.getInstance(queryObject);
            qPos.add(userId);
            qPos.add(status);
            qPos.add(fromDate);
            qPos.add(toDate);
            return getTaskList((List<Object[]>)QueryUtil.list(queryObject, getDialect(), QueryUtil.ALL_POS, QueryUtil.ALL_POS));
        } finally{
           if(session !=null) {
        	   closeSession(session);
           }
        }
	}

	private List<TaskAssignment> getTaskList(List<Object[]> list) {
	    List<TaskAssignment> taskList = new ArrayList<TaskAssignment>();
	    TaskAssignment taskAssignment = null;
	    SimpleDateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
	    for (Object[] object : list) {
	    	taskAssignment = new TaskAssignmentImpl();
	    	taskAssignment.setTaskAssignmentId(GetterUtil.getLong(object[0]));
	    	taskAssignment.setTaskId(GetterUtil.getLong(object[1]));
	    	taskAssignment.setAssignByUserId(GetterUtil.getLong(object[2]));
	    	taskAssignment.setAssignToUserId(GetterUtil.getLong(object[3]));
	    	taskAssignment.setStatus(GetterUtil.getString(object[4]));
	    	taskAssignment.setAchieved(GetterUtil.getString(object[5]));
	    	taskAssignment.setModifiedBy(GetterUtil.getLong(object[6]));
	    	taskAssignment.setCreateDate(GetterUtil.getDate(object[7], dateFormat));
	    	taskAssignment.setModifiedDate(GetterUtil.getDate(object[8], dateFormat));
	        taskList.add(taskAssignment);
	    }
	    return taskList;
	}
	
	
	public List<TaskAssignment> getAllTaskAssignByMe(long userId){
        
        Session session = null;
        SQLQuery queryObject = null;
        try{
        	
        	session = openSession();
            String sql = CustomSQLUtil.get("com.jioc.taskmanagement.service.persistence.getAllTasksAssignByMe");
            sql = StringUtil.replace(sql, "[$USERID$]", String.valueOf(userId));
            
                        
            queryObject = session.createSQLQuery(sql);
            queryObject.setCacheable(false);
            
            return getTasksAssignByMeList((List<Object[]>)QueryUtil.list(queryObject, getDialect(), QueryUtil.ALL_POS, QueryUtil.ALL_POS));
        } finally{
           if(session !=null) {
        	   closeSession(session);
           }
        }
	}
	
	private List<TaskAssignment> getTasksAssignByMeList(List<Object[]> list) {
		List<TaskAssignment> taskList = new ArrayList<TaskAssignment>();
	    TaskAssignment taskAssignment = null;
	    SimpleDateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
	    
	    for (Object[] object : list) {
	    	taskAssignment = new TaskAssignmentImpl();
	    	taskAssignment.setAssigneeTaskId(GetterUtil.getLong(object[0]));
	    	taskAssignment.setAssignByUserId(GetterUtil.getLong(object[1]));
	    	taskAssignment.setAssignToUserId(GetterUtil.getLong(object[2]));
	    	taskAssignment.setCreateDate(GetterUtil.getDate(object[3], dateFormat));
	    	taskAssignment.setFinal_status(GetterUtil.getString(object[4]));
	    	
	        taskList.add(taskAssignment);
	    }
	    return taskList;
	}
	
	
	
	public List<TaskAssignment> getAllTasksAssignToMe(long userId){
        
        Session session = null;
        SQLQuery queryObject = null;
        try{
        	
        	session = openSession();
            String sql = CustomSQLUtil.get("com.jioc.taskmanagement.service.persistence.getAllTasksAssignToMe");
            //sql = StringUtil.replace(sql, "[$USER_ID$]", String.valueOf(userId));
            
                        
            queryObject = session.createSQLQuery(sql);
            queryObject.setCacheable(false);
            
            QueryPos qPos = QueryPos.getInstance(queryObject);
            qPos.add(userId);
            //System.out.println("sql query=="+sql);
            return getTasksAssignToMeList((List<Object[]>)QueryUtil.list(queryObject, getDialect(), QueryUtil.ALL_POS, QueryUtil.ALL_POS));
        } finally{
           if(session !=null) {
        	   closeSession(session);
           }
        }
	}
	
	private List<TaskAssignment> getTasksAssignToMeList(List<Object[]> list) {
	    List<TaskAssignment> taskList = new ArrayList<TaskAssignment>();
	    TaskAssignment taskAssignment = null;
	    SimpleDateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
	    
	    for (Object[] object : list) {
	    	taskAssignment = new TaskAssignmentImpl();
	    	taskAssignment.setAssigneeTaskId(GetterUtil.getLong(object[0]));
	    	taskAssignment.setAssignByUserId(GetterUtil.getLong(object[1]));
	    	taskAssignment.setAssignToUserId(GetterUtil.getLong(object[2]));
	    	taskAssignment.setCreateDate(GetterUtil.getDate(object[3], dateFormat));
	    	taskAssignment.setFinal_status(GetterUtil.getString(object[4]));
	    	
	        taskList.add(taskAssignment);
	    }
	    return taskList;
	}
	
	
	public List<TaskAssignment> getAllTasksAssignToMeByStatusWithDate(long userId,String final_status, String fromDate, String toDate){
        
        Session session = null;
        SQLQuery queryObject = null;
        try{
        	
        	session = openSession();
            String sql = CustomSQLUtil.get("com.jioc.taskmanagement.service.persistence.getAllTasksAssignToMeByStatusWithDate");
            sql = StringUtil.replace(sql, "[$FROM_DATE$]", fromDate);
            sql = StringUtil.replace(sql, "[$TO_DATE$]", toDate);
            sql = StringUtil.replace(sql, "[$FINAL_STATUS$]",final_status);
            sql = StringUtil.replace(sql, "[$USERID$]", String.valueOf(userId));
            
                        
            queryObject = session.createSQLQuery(sql);
            queryObject.setCacheable(false);
            
            return getTasksAssignToMeByStatusWithDateList((List<Object[]>)QueryUtil.list(queryObject, getDialect(), QueryUtil.ALL_POS, QueryUtil.ALL_POS));
        } finally{
           if(session !=null) {
        	   closeSession(session);
           }
        }
	}
	
	private List<TaskAssignment> getTasksAssignToMeByStatusWithDateList(List<Object[]> list) {
	    List<TaskAssignment> taskList = new ArrayList<TaskAssignment>();
	    TaskAssignment taskAssignment = null;
	    SimpleDateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
	    
	    for (Object[] object : list) {
	    	taskAssignment = new TaskAssignmentImpl();
	    	taskAssignment.setAssigneeTaskId(GetterUtil.getLong(object[0]));
	    	taskAssignment.setAssignByUserId(GetterUtil.getLong(object[1]));
	    	taskAssignment.setAssignToUserId(GetterUtil.getLong(object[2]));
	    	taskAssignment.setCreateDate(GetterUtil.getDate(object[3], dateFormat));
	    	taskAssignment.setFinal_status(GetterUtil.getString(object[4]));
	    	
	        taskList.add(taskAssignment);
	    }
	    return taskList;
	}
	
public List<TaskAssignment> getAllTasksAssignByMeByStatusWithDate(long userId,String final_status, String fromDate, String toDate){
        
        Session session = null;
        SQLQuery queryObject = null;
        try{
        	
        	session = openSession();
            String sql = CustomSQLUtil.get("com.jioc.taskmanagement.service.persistence.getAllTasksAssignByMeByStatusWithDate");
            sql = StringUtil.replace(sql, "[$FROM_DATE$]", fromDate);
            sql = StringUtil.replace(sql, "[$TO_DATE$]", toDate);
            sql = StringUtil.replace(sql, "[$FINAL_STATUS$]",final_status);
            sql = StringUtil.replace(sql, "[$USERID$]", String.valueOf(userId));
            
                        
            queryObject = session.createSQLQuery(sql);
            queryObject.setCacheable(false);
            
            return getTasksAssignByMeByStatusWithDateList((List<Object[]>)QueryUtil.list(queryObject, getDialect(), QueryUtil.ALL_POS, QueryUtil.ALL_POS));
        } finally{
           if(session !=null) {
        	   closeSession(session);
           }
        }
	}
	
	private List<TaskAssignment> getTasksAssignByMeByStatusWithDateList(List<Object[]> list) {
	    List<TaskAssignment> taskList = new ArrayList<TaskAssignment>();
	    TaskAssignment taskAssignment = null;
	    SimpleDateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
	    
	    for (Object[] object : list) {
	    	taskAssignment = new TaskAssignmentImpl();
	    	taskAssignment.setAssigneeTaskId(GetterUtil.getLong(object[0]));
	    	taskAssignment.setAssignByUserId(GetterUtil.getLong(object[1]));
	    	taskAssignment.setAssignToUserId(GetterUtil.getLong(object[2]));
	    	taskAssignment.setCreateDate(GetterUtil.getDate(object[3], dateFormat));
	    	taskAssignment.setFinal_status(GetterUtil.getString(object[4]));
	    	
	        taskList.add(taskAssignment);
	    }
	    return taskList;
	}
	
	public List<TaskAssignment> getAllTaskAssignToMeByStatus(long userId,String final_status){
        
        Session session = null;
        SQLQuery queryObject = null;
        try{
        	
        	session = openSession();
            String sql = CustomSQLUtil.get("com.jioc.taskmanagement.service.persistence.getAllTaskAssignToMeByStatus");
            queryObject = session.createSQLQuery(sql);
            queryObject.setCacheable(false);
            
            QueryPos qPos = QueryPos.getInstance(queryObject);
            qPos.add(final_status);
            qPos.add(userId);
            return getTaskAssignToMeByStatusList((List<Object[]>)QueryUtil.list(queryObject, getDialect(), QueryUtil.ALL_POS, QueryUtil.ALL_POS));
        } finally{
           if(session !=null) {
        	   closeSession(session);
           }
        }
	}
	
	private List<TaskAssignment> getTaskAssignToMeByStatusList(List<Object[]> list) {
	    List<TaskAssignment> taskList = new ArrayList<TaskAssignment>();
	    TaskAssignment taskAssignment = null;
	    SimpleDateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
	    
	    for (Object[] object : list) {
	    	taskAssignment = new TaskAssignmentImpl();
	    	taskAssignment.setAssigneeTaskId(GetterUtil.getLong(object[0]));
	    	taskAssignment.setAssignByUserId(GetterUtil.getLong(object[1]));
	    	taskAssignment.setAssignToUserId(GetterUtil.getLong(object[2]));
	    	taskAssignment.setCreateDate(GetterUtil.getDate(object[3], dateFormat));
	    	taskAssignment.setFinal_status(GetterUtil.getString(object[4]));
	    	
	        taskList.add(taskAssignment);
	    }
	    return taskList;
	}
	
	public List<TaskAssignment> getAllTaskAssignToMeWithDate(long userId,String fromDate, String toDate){
        
        Session session = null;
        SQLQuery queryObject = null;
        try{
        	
        	session = openSession();
            String sql = CustomSQLUtil.get("com.jioc.taskmanagement.service.persistence.getAllTaskAssignToMeWithDate");
            sql = StringUtil.replace(sql, "[$FROM_DATE$]", fromDate);
            sql = StringUtil.replace(sql, "[$TO_DATE$]", toDate);
            sql = StringUtil.replace(sql, "[$USERID$]", String.valueOf(userId));
            
            queryObject = session.createSQLQuery(sql);
            queryObject.setCacheable(false);
            return getTaskAssignToMeWithDateList((List<Object[]>)QueryUtil.list(queryObject, getDialect(), QueryUtil.ALL_POS, QueryUtil.ALL_POS));
        } finally{
           if(session !=null) {
        	   closeSession(session);
           }
        }
	}
	
	private List<TaskAssignment> getTaskAssignToMeWithDateList(List<Object[]> list) {
	    List<TaskAssignment> taskList = new ArrayList<TaskAssignment>();
	    TaskAssignment taskAssignment = null;
	    SimpleDateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
	    
	    for (Object[] object : list) {
	    	taskAssignment = new TaskAssignmentImpl();
	    	taskAssignment.setAssigneeTaskId(GetterUtil.getLong(object[0]));
	    	taskAssignment.setAssignByUserId(GetterUtil.getLong(object[1]));
	    	taskAssignment.setAssignToUserId(GetterUtil.getLong(object[2]));
	    	taskAssignment.setCreateDate(GetterUtil.getDate(object[3], dateFormat));
	    	taskAssignment.setFinal_status(GetterUtil.getString(object[4]));
	    	
	        taskList.add(taskAssignment);
	    }
	    return taskList;
	}
	
	public List<TaskAssignment> getAllTaskAssignByMeWithDate(long userId,String fromDate, String toDate){
        
        Session session = null;
        SQLQuery queryObject = null;
        try{
        	
        	session = openSession();
            String sql = CustomSQLUtil.get("com.jioc.taskmanagement.service.persistence.getAllTaskAssignByMeWithDate");
            sql = StringUtil.replace(sql, "[$FROM_DATE$]", fromDate);
            sql = StringUtil.replace(sql, "[$TO_DATE$]", toDate);
            sql = StringUtil.replace(sql, "[$USERID$]", String.valueOf(userId));
            
            queryObject = session.createSQLQuery(sql);
            queryObject.setCacheable(false);
            
            return getTaskAssignByMeWithDateList((List<Object[]>)QueryUtil.list(queryObject, getDialect(), QueryUtil.ALL_POS, QueryUtil.ALL_POS));
        } finally{
           if(session !=null) {
        	   closeSession(session);
           }
        }
	}
	
	private List<TaskAssignment> getTaskAssignByMeWithDateList(List<Object[]> list) {
	    List<TaskAssignment> taskList = new ArrayList<TaskAssignment>();
	    TaskAssignment taskAssignment = null;
	    SimpleDateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
	    
	    for (Object[] object : list) {
	    	taskAssignment = new TaskAssignmentImpl();
	    	taskAssignment.setAssigneeTaskId(GetterUtil.getLong(object[0]));
	    	taskAssignment.setAssignByUserId(GetterUtil.getLong(object[1]));
	    	taskAssignment.setAssignToUserId(GetterUtil.getLong(object[2]));
	    	taskAssignment.setCreateDate(GetterUtil.getDate(object[3], dateFormat));
	    	taskAssignment.setFinal_status(GetterUtil.getString(object[4]));
	    	
	        taskList.add(taskAssignment);
	    }
	    return taskList;
	}
	
	public List<TaskAssignment> getAllTaskAssignByMeByStatus(long userId,String final_status){
        
        Session session = null;
        SQLQuery queryObject = null;
        try{
        	
        	session = openSession();
            String sql = CustomSQLUtil.get("com.jioc.taskmanagement.service.persistence.getAllTaskAssignByMeByStatus");
            sql = StringUtil.replace(sql, "[$FINAL_STATUS$]",final_status);
            sql = StringUtil.replace(sql, "[$USERID$]", String.valueOf(userId));
            
            queryObject = session.createSQLQuery(sql);
            queryObject.setCacheable(false);
            return getTaskAssignByMeByStatusList((List<Object[]>)QueryUtil.list(queryObject, getDialect(), QueryUtil.ALL_POS, QueryUtil.ALL_POS));
        } finally{
           if(session !=null) {
        	   closeSession(session);
           }
        }
	}
	
	private List<TaskAssignment> getTaskAssignByMeByStatusList(List<Object[]> list) {
	    List<TaskAssignment> taskList = new ArrayList<TaskAssignment>();
	    TaskAssignment taskAssignment = null;
	    SimpleDateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
	    
	    for (Object[] object : list) {
	    	taskAssignment = new TaskAssignmentImpl();
	    	taskAssignment.setAssigneeTaskId(GetterUtil.getLong(object[0]));
	    	taskAssignment.setAssignByUserId(GetterUtil.getLong(object[1]));
	    	taskAssignment.setAssignToUserId(GetterUtil.getLong(object[2]));
	    	taskAssignment.setCreateDate(GetterUtil.getDate(object[3], dateFormat));
	    	taskAssignment.setFinal_status(GetterUtil.getString(object[4]));
	    	
	        taskList.add(taskAssignment);
	    }
	    return taskList;
	}
	public List<TaskAssignment> getTasksByAssigneetaskId(long assigneetaskid, String status){
        
        Session session = null;
        SQLQuery queryObject = null;
        try{
        	
        	session = openSession();
            String sql = CustomSQLUtil.get("com.jioc.taskmanagement.service.persistence.getTasksByAssigneetaskId");
                        
            queryObject = session.createSQLQuery(sql);
            queryObject.setCacheable(false);
            
            QueryPos qPos = QueryPos.getInstance(queryObject);
            qPos.add(assigneetaskid);
            qPos.add(status);
            return getTasksAssignTaskIdList((List<Object[]>)QueryUtil.list(queryObject, getDialect(), QueryUtil.ALL_POS, QueryUtil.ALL_POS));
        } finally{
           if(session !=null) {
        	   closeSession(session);
           }
        }
	}
	
	private List<TaskAssignment> getTasksAssignTaskIdList(List<Object[]> list) {
	    List<TaskAssignment> taskList = new ArrayList<TaskAssignment>();
	    TaskAssignment taskAssignment = null;
	   
	    for (Object[] object : list) {
	    	taskAssignment = new TaskAssignmentImpl();
	    	taskAssignment.setTaskAssignmentId(GetterUtil.getLong(object[0]));
	    	taskAssignment.setTaskId(GetterUtil.getLong(object[1]));
	    	taskAssignment.setAssigneeTaskId(GetterUtil.getLong(object[2]));
	    	taskAssignment.setAssignToUserId(GetterUtil.getLong(object[3]));
	    	taskAssignment.setStatus(GetterUtil.getString(object[4]));
	    	taskAssignment.setAchieved(GetterUtil.getString(object[5]));
	    	taskAssignment.setDescription(GetterUtil.getString(object[6]));
	    	taskAssignment.setTarget(GetterUtil.getLong(object[7]));
	    	
	        taskList.add(taskAssignment);
	    }
	    return taskList;
	}
}
