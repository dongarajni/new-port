/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.taskmanagement.service.impl;

import com.jioc.taskmanagement.model.TaskAssignment;
import com.jioc.taskmanagement.model.TaskDetails;
import com.jioc.taskmanagement.service.base.TaskDetailsLocalServiceBaseImpl;
import com.jioc.taskmanagement.service.persistence.TaskAssignmentFinderUtil;
import com.jioc.taskmanagement.service.persistence.TaskDetailsFinderUtil;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.SQLQuery;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;

import java.util.List;

/**
 * The implementation of the task details local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jioc.taskmanagement.service.TaskDetailsLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author rajnikant.donga
 * @see com.jioc.taskmanagement.service.base.TaskDetailsLocalServiceBaseImpl
 * @see com.jioc.taskmanagement.service.TaskDetailsLocalServiceUtil
 */
public class TaskDetailsLocalServiceImpl extends TaskDetailsLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.jioc.taskmanagement.service.TaskDetailsLocalServiceUtil} to access the task details local service.
	 */
	
	public List<TaskDetails> getTasksAssignByMe(long Userid){
		
		try {
			return taskDetailsPersistence.findByAssignByMe(Userid);
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	
	public List<Object[]> getTaskByStatus(long userId,String status){
		try {
			
			Session session =taskDetailsPersistence.openSession(); 
			SQLQuery query = session.createSQLQuery("SELECT a.taskid, a.modifieddate, b.assignbyuserid,(SELECT CASE WHEN COUNT(1) > 0 THEN 'In Progress' ELSE 'Complete' END FROM jioc_taskassignment c WHERE STATUS = ? AND c.taskid = b.taskid) AS Status_CodeFROM jioc_taskdetails a LEFT JOIN jioc_taskassignment b ON a.taskid = b.taskidWHERE b.assignbyuserid = ? GROUP BY a.taskid, a.modifieddate, b.assignbyuserid");
			QueryPos pos = QueryPos.getInstance(query);
			pos.add(status);
			pos.add(userId);
			
			return query.list();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public List<TaskDetails> getAllTaskAssigneeByTaskId(long assigneetaskid){
		return TaskDetailsFinderUtil.getAllTasksAssigneeById(assigneetaskid);
		
	}
	
	
}