/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.taskmanagement.service.persistence;

import com.jioc.taskmanagement.NoSuchTaskAssignmentException;
import com.jioc.taskmanagement.model.TaskAssignment;
import com.jioc.taskmanagement.model.impl.TaskAssignmentImpl;
import com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl;
import com.jioc.taskmanagement.service.persistence.TaskAssignmentPersistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The persistence implementation for the task assignment service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author rajnikant.donga
 * @see TaskAssignmentPersistence
 * @see TaskAssignmentUtil
 * @generated
 */
public class TaskAssignmentPersistenceImpl extends BasePersistenceImpl<TaskAssignment>
	implements TaskAssignmentPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link TaskAssignmentUtil} to access the task assignment persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = TaskAssignmentImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED,
			TaskAssignmentImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED,
			TaskAssignmentImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ASSIGNEEUSER =
		new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED,
			TaskAssignmentImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByAssigneeUser",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNEEUSER =
		new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED,
			TaskAssignmentImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByAssigneeUser",
			new String[] { Long.class.getName() },
			TaskAssignmentModelImpl.TASKID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_ASSIGNEEUSER = new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAssigneeUser",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the task assignments where taskId = &#63;.
	 *
	 * @param taskId the task ID
	 * @return the matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByAssigneeUser(long taskId)
		throws SystemException {
		return findByAssigneeUser(taskId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the task assignments where taskId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param taskId the task ID
	 * @param start the lower bound of the range of task assignments
	 * @param end the upper bound of the range of task assignments (not inclusive)
	 * @return the range of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByAssigneeUser(long taskId, int start,
		int end) throws SystemException {
		return findByAssigneeUser(taskId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the task assignments where taskId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param taskId the task ID
	 * @param start the lower bound of the range of task assignments
	 * @param end the upper bound of the range of task assignments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByAssigneeUser(long taskId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNEEUSER;
			finderArgs = new Object[] { taskId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ASSIGNEEUSER;
			finderArgs = new Object[] { taskId, start, end, orderByComparator };
		}

		List<TaskAssignment> list = (List<TaskAssignment>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (TaskAssignment taskAssignment : list) {
				if ((taskId != taskAssignment.getTaskId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_ASSIGNEEUSER_TASKID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(TaskAssignmentModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(taskId);

				if (!pagination) {
					list = (List<TaskAssignment>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<TaskAssignment>(list);
				}
				else {
					list = (List<TaskAssignment>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first task assignment in the ordered set where taskId = &#63;.
	 *
	 * @param taskId the task ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment findByAssigneeUser_First(long taskId,
		OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = fetchByAssigneeUser_First(taskId,
				orderByComparator);

		if (taskAssignment != null) {
			return taskAssignment;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("taskId=");
		msg.append(taskId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchTaskAssignmentException(msg.toString());
	}

	/**
	 * Returns the first task assignment in the ordered set where taskId = &#63;.
	 *
	 * @param taskId the task ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByAssigneeUser_First(long taskId,
		OrderByComparator orderByComparator) throws SystemException {
		List<TaskAssignment> list = findByAssigneeUser(taskId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last task assignment in the ordered set where taskId = &#63;.
	 *
	 * @param taskId the task ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment findByAssigneeUser_Last(long taskId,
		OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = fetchByAssigneeUser_Last(taskId,
				orderByComparator);

		if (taskAssignment != null) {
			return taskAssignment;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("taskId=");
		msg.append(taskId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchTaskAssignmentException(msg.toString());
	}

	/**
	 * Returns the last task assignment in the ordered set where taskId = &#63;.
	 *
	 * @param taskId the task ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByAssigneeUser_Last(long taskId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByAssigneeUser(taskId);

		if (count == 0) {
			return null;
		}

		List<TaskAssignment> list = findByAssigneeUser(taskId, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the task assignments before and after the current task assignment in the ordered set where taskId = &#63;.
	 *
	 * @param taskAssignmentId the primary key of the current task assignment
	 * @param taskId the task ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment[] findByAssigneeUser_PrevAndNext(
		long taskAssignmentId, long taskId, OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = findByPrimaryKey(taskAssignmentId);

		Session session = null;

		try {
			session = openSession();

			TaskAssignment[] array = new TaskAssignmentImpl[3];

			array[0] = getByAssigneeUser_PrevAndNext(session, taskAssignment,
					taskId, orderByComparator, true);

			array[1] = taskAssignment;

			array[2] = getByAssigneeUser_PrevAndNext(session, taskAssignment,
					taskId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected TaskAssignment getByAssigneeUser_PrevAndNext(Session session,
		TaskAssignment taskAssignment, long taskId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_TASKASSIGNMENT_WHERE);

		query.append(_FINDER_COLUMN_ASSIGNEEUSER_TASKID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(TaskAssignmentModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(taskId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(taskAssignment);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<TaskAssignment> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the task assignments where taskId = &#63; from the database.
	 *
	 * @param taskId the task ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByAssigneeUser(long taskId) throws SystemException {
		for (TaskAssignment taskAssignment : findByAssigneeUser(taskId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(taskAssignment);
		}
	}

	/**
	 * Returns the number of task assignments where taskId = &#63;.
	 *
	 * @param taskId the task ID
	 * @return the number of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByAssigneeUser(long taskId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_ASSIGNEEUSER;

		Object[] finderArgs = new Object[] { taskId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_ASSIGNEEUSER_TASKID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(taskId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_ASSIGNEEUSER_TASKID_2 = "taskAssignment.taskId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ASSIGNTOUSER =
		new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED,
			TaskAssignmentImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByAssignToUser",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNTOUSER =
		new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED,
			TaskAssignmentImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByAssignToUser",
			new String[] { Long.class.getName() },
			TaskAssignmentModelImpl.ASSIGNTOUSERID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_ASSIGNTOUSER = new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAssignToUser",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the task assignments where assignToUserId = &#63;.
	 *
	 * @param assignToUserId the assign to user ID
	 * @return the matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByAssignToUser(long assignToUserId)
		throws SystemException {
		return findByAssignToUser(assignToUserId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the task assignments where assignToUserId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param assignToUserId the assign to user ID
	 * @param start the lower bound of the range of task assignments
	 * @param end the upper bound of the range of task assignments (not inclusive)
	 * @return the range of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByAssignToUser(long assignToUserId,
		int start, int end) throws SystemException {
		return findByAssignToUser(assignToUserId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the task assignments where assignToUserId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param assignToUserId the assign to user ID
	 * @param start the lower bound of the range of task assignments
	 * @param end the upper bound of the range of task assignments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByAssignToUser(long assignToUserId,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNTOUSER;
			finderArgs = new Object[] { assignToUserId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ASSIGNTOUSER;
			finderArgs = new Object[] {
					assignToUserId,
					
					start, end, orderByComparator
				};
		}

		List<TaskAssignment> list = (List<TaskAssignment>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (TaskAssignment taskAssignment : list) {
				if ((assignToUserId != taskAssignment.getAssignToUserId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_ASSIGNTOUSER_ASSIGNTOUSERID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(TaskAssignmentModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(assignToUserId);

				if (!pagination) {
					list = (List<TaskAssignment>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<TaskAssignment>(list);
				}
				else {
					list = (List<TaskAssignment>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first task assignment in the ordered set where assignToUserId = &#63;.
	 *
	 * @param assignToUserId the assign to user ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment findByAssignToUser_First(long assignToUserId,
		OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = fetchByAssignToUser_First(assignToUserId,
				orderByComparator);

		if (taskAssignment != null) {
			return taskAssignment;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("assignToUserId=");
		msg.append(assignToUserId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchTaskAssignmentException(msg.toString());
	}

	/**
	 * Returns the first task assignment in the ordered set where assignToUserId = &#63;.
	 *
	 * @param assignToUserId the assign to user ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByAssignToUser_First(long assignToUserId,
		OrderByComparator orderByComparator) throws SystemException {
		List<TaskAssignment> list = findByAssignToUser(assignToUserId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last task assignment in the ordered set where assignToUserId = &#63;.
	 *
	 * @param assignToUserId the assign to user ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment findByAssignToUser_Last(long assignToUserId,
		OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = fetchByAssignToUser_Last(assignToUserId,
				orderByComparator);

		if (taskAssignment != null) {
			return taskAssignment;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("assignToUserId=");
		msg.append(assignToUserId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchTaskAssignmentException(msg.toString());
	}

	/**
	 * Returns the last task assignment in the ordered set where assignToUserId = &#63;.
	 *
	 * @param assignToUserId the assign to user ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByAssignToUser_Last(long assignToUserId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByAssignToUser(assignToUserId);

		if (count == 0) {
			return null;
		}

		List<TaskAssignment> list = findByAssignToUser(assignToUserId,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the task assignments before and after the current task assignment in the ordered set where assignToUserId = &#63;.
	 *
	 * @param taskAssignmentId the primary key of the current task assignment
	 * @param assignToUserId the assign to user ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment[] findByAssignToUser_PrevAndNext(
		long taskAssignmentId, long assignToUserId,
		OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = findByPrimaryKey(taskAssignmentId);

		Session session = null;

		try {
			session = openSession();

			TaskAssignment[] array = new TaskAssignmentImpl[3];

			array[0] = getByAssignToUser_PrevAndNext(session, taskAssignment,
					assignToUserId, orderByComparator, true);

			array[1] = taskAssignment;

			array[2] = getByAssignToUser_PrevAndNext(session, taskAssignment,
					assignToUserId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected TaskAssignment getByAssignToUser_PrevAndNext(Session session,
		TaskAssignment taskAssignment, long assignToUserId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_TASKASSIGNMENT_WHERE);

		query.append(_FINDER_COLUMN_ASSIGNTOUSER_ASSIGNTOUSERID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(TaskAssignmentModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(assignToUserId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(taskAssignment);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<TaskAssignment> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the task assignments where assignToUserId = &#63; from the database.
	 *
	 * @param assignToUserId the assign to user ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByAssignToUser(long assignToUserId)
		throws SystemException {
		for (TaskAssignment taskAssignment : findByAssignToUser(
				assignToUserId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(taskAssignment);
		}
	}

	/**
	 * Returns the number of task assignments where assignToUserId = &#63;.
	 *
	 * @param assignToUserId the assign to user ID
	 * @return the number of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByAssignToUser(long assignToUserId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_ASSIGNTOUSER;

		Object[] finderArgs = new Object[] { assignToUserId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_ASSIGNTOUSER_ASSIGNTOUSERID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(assignToUserId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_ASSIGNTOUSER_ASSIGNTOUSERID_2 = "taskAssignment.assignToUserId = ?";
	public static final FinderPath FINDER_PATH_FETCH_BY_TASKDETAILASSIGNTOME = new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED,
			TaskAssignmentImpl.class, FINDER_CLASS_NAME_ENTITY,
			"fetchByTaskDetailAssignToMe",
			new String[] { Long.class.getName(), Long.class.getName() },
			TaskAssignmentModelImpl.TASKID_COLUMN_BITMASK |
			TaskAssignmentModelImpl.ASSIGNBYUSERID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_TASKDETAILASSIGNTOME = new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByTaskDetailAssignToMe",
			new String[] { Long.class.getName(), Long.class.getName() });

	/**
	 * Returns the task assignment where taskId = &#63; and assignByUserId = &#63; or throws a {@link com.jioc.taskmanagement.NoSuchTaskAssignmentException} if it could not be found.
	 *
	 * @param taskId the task ID
	 * @param assignByUserId the assign by user ID
	 * @return the matching task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment findByTaskDetailAssignToMe(long taskId,
		long assignByUserId)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = fetchByTaskDetailAssignToMe(taskId,
				assignByUserId);

		if (taskAssignment == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("taskId=");
			msg.append(taskId);

			msg.append(", assignByUserId=");
			msg.append(assignByUserId);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchTaskAssignmentException(msg.toString());
		}

		return taskAssignment;
	}

	/**
	 * Returns the task assignment where taskId = &#63; and assignByUserId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param taskId the task ID
	 * @param assignByUserId the assign by user ID
	 * @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByTaskDetailAssignToMe(long taskId,
		long assignByUserId) throws SystemException {
		return fetchByTaskDetailAssignToMe(taskId, assignByUserId, true);
	}

	/**
	 * Returns the task assignment where taskId = &#63; and assignByUserId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param taskId the task ID
	 * @param assignByUserId the assign by user ID
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByTaskDetailAssignToMe(long taskId,
		long assignByUserId, boolean retrieveFromCache)
		throws SystemException {
		Object[] finderArgs = new Object[] { taskId, assignByUserId };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_TASKDETAILASSIGNTOME,
					finderArgs, this);
		}

		if (result instanceof TaskAssignment) {
			TaskAssignment taskAssignment = (TaskAssignment)result;

			if ((taskId != taskAssignment.getTaskId()) ||
					(assignByUserId != taskAssignment.getAssignByUserId())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_TASKDETAILASSIGNTOME_TASKID_2);

			query.append(_FINDER_COLUMN_TASKDETAILASSIGNTOME_ASSIGNBYUSERID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(taskId);

				qPos.add(assignByUserId);

				List<TaskAssignment> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TASKDETAILASSIGNTOME,
						finderArgs, list);
				}
				else {
					if ((list.size() > 1) && _log.isWarnEnabled()) {
						_log.warn(
							"TaskAssignmentPersistenceImpl.fetchByTaskDetailAssignToMe(long, long, boolean) with parameters (" +
							StringUtil.merge(finderArgs) +
							") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
					}

					TaskAssignment taskAssignment = list.get(0);

					result = taskAssignment;

					cacheResult(taskAssignment);

					if ((taskAssignment.getTaskId() != taskId) ||
							(taskAssignment.getAssignByUserId() != assignByUserId)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TASKDETAILASSIGNTOME,
							finderArgs, taskAssignment);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_TASKDETAILASSIGNTOME,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (TaskAssignment)result;
		}
	}

	/**
	 * Removes the task assignment where taskId = &#63; and assignByUserId = &#63; from the database.
	 *
	 * @param taskId the task ID
	 * @param assignByUserId the assign by user ID
	 * @return the task assignment that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment removeByTaskDetailAssignToMe(long taskId,
		long assignByUserId)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = findByTaskDetailAssignToMe(taskId,
				assignByUserId);

		return remove(taskAssignment);
	}

	/**
	 * Returns the number of task assignments where taskId = &#63; and assignByUserId = &#63;.
	 *
	 * @param taskId the task ID
	 * @param assignByUserId the assign by user ID
	 * @return the number of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByTaskDetailAssignToMe(long taskId, long assignByUserId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_TASKDETAILASSIGNTOME;

		Object[] finderArgs = new Object[] { taskId, assignByUserId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_TASKDETAILASSIGNTOME_TASKID_2);

			query.append(_FINDER_COLUMN_TASKDETAILASSIGNTOME_ASSIGNBYUSERID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(taskId);

				qPos.add(assignByUserId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_TASKDETAILASSIGNTOME_TASKID_2 = "taskAssignment.taskId = ? AND ";
	private static final String _FINDER_COLUMN_TASKDETAILASSIGNTOME_ASSIGNBYUSERID_2 =
		"taskAssignment.assignByUserId = ?";
	public static final FinderPath FINDER_PATH_FETCH_BY_AVAILABLEASSIGNEE = new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED,
			TaskAssignmentImpl.class, FINDER_CLASS_NAME_ENTITY,
			"fetchByAvailableAssignee",
			new String[] { Long.class.getName(), Long.class.getName() },
			TaskAssignmentModelImpl.TASKID_COLUMN_BITMASK |
			TaskAssignmentModelImpl.ASSIGNTOUSERID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_AVAILABLEASSIGNEE = new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByAvailableAssignee",
			new String[] { Long.class.getName(), Long.class.getName() });

	/**
	 * Returns the task assignment where taskId = &#63; and assignToUserId = &#63; or throws a {@link com.jioc.taskmanagement.NoSuchTaskAssignmentException} if it could not be found.
	 *
	 * @param taskId the task ID
	 * @param assignToUserId the assign to user ID
	 * @return the matching task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment findByAvailableAssignee(long taskId,
		long assignToUserId)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = fetchByAvailableAssignee(taskId,
				assignToUserId);

		if (taskAssignment == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("taskId=");
			msg.append(taskId);

			msg.append(", assignToUserId=");
			msg.append(assignToUserId);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchTaskAssignmentException(msg.toString());
		}

		return taskAssignment;
	}

	/**
	 * Returns the task assignment where taskId = &#63; and assignToUserId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param taskId the task ID
	 * @param assignToUserId the assign to user ID
	 * @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByAvailableAssignee(long taskId,
		long assignToUserId) throws SystemException {
		return fetchByAvailableAssignee(taskId, assignToUserId, true);
	}

	/**
	 * Returns the task assignment where taskId = &#63; and assignToUserId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param taskId the task ID
	 * @param assignToUserId the assign to user ID
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByAvailableAssignee(long taskId,
		long assignToUserId, boolean retrieveFromCache)
		throws SystemException {
		Object[] finderArgs = new Object[] { taskId, assignToUserId };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_AVAILABLEASSIGNEE,
					finderArgs, this);
		}

		if (result instanceof TaskAssignment) {
			TaskAssignment taskAssignment = (TaskAssignment)result;

			if ((taskId != taskAssignment.getTaskId()) ||
					(assignToUserId != taskAssignment.getAssignToUserId())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_AVAILABLEASSIGNEE_TASKID_2);

			query.append(_FINDER_COLUMN_AVAILABLEASSIGNEE_ASSIGNTOUSERID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(taskId);

				qPos.add(assignToUserId);

				List<TaskAssignment> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_AVAILABLEASSIGNEE,
						finderArgs, list);
				}
				else {
					if ((list.size() > 1) && _log.isWarnEnabled()) {
						_log.warn(
							"TaskAssignmentPersistenceImpl.fetchByAvailableAssignee(long, long, boolean) with parameters (" +
							StringUtil.merge(finderArgs) +
							") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
					}

					TaskAssignment taskAssignment = list.get(0);

					result = taskAssignment;

					cacheResult(taskAssignment);

					if ((taskAssignment.getTaskId() != taskId) ||
							(taskAssignment.getAssignToUserId() != assignToUserId)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_AVAILABLEASSIGNEE,
							finderArgs, taskAssignment);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_AVAILABLEASSIGNEE,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (TaskAssignment)result;
		}
	}

	/**
	 * Removes the task assignment where taskId = &#63; and assignToUserId = &#63; from the database.
	 *
	 * @param taskId the task ID
	 * @param assignToUserId the assign to user ID
	 * @return the task assignment that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment removeByAvailableAssignee(long taskId,
		long assignToUserId)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = findByAvailableAssignee(taskId,
				assignToUserId);

		return remove(taskAssignment);
	}

	/**
	 * Returns the number of task assignments where taskId = &#63; and assignToUserId = &#63;.
	 *
	 * @param taskId the task ID
	 * @param assignToUserId the assign to user ID
	 * @return the number of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByAvailableAssignee(long taskId, long assignToUserId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_AVAILABLEASSIGNEE;

		Object[] finderArgs = new Object[] { taskId, assignToUserId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_AVAILABLEASSIGNEE_TASKID_2);

			query.append(_FINDER_COLUMN_AVAILABLEASSIGNEE_ASSIGNTOUSERID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(taskId);

				qPos.add(assignToUserId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_AVAILABLEASSIGNEE_TASKID_2 = "taskAssignment.taskId = ? AND ";
	private static final String _FINDER_COLUMN_AVAILABLEASSIGNEE_ASSIGNTOUSERID_2 =
		"taskAssignment.assignToUserId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ASSIGNTOUSERIDANDASSIGNEETASKID =
		new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED,
			TaskAssignmentImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByAssignToUserIdAndAssigneeTaskId",
			new String[] {
				Long.class.getName(), Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNTOUSERIDANDASSIGNEETASKID =
		new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED,
			TaskAssignmentImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByAssignToUserIdAndAssigneeTaskId",
			new String[] { Long.class.getName(), Long.class.getName() },
			TaskAssignmentModelImpl.ASSIGNTOUSERID_COLUMN_BITMASK |
			TaskAssignmentModelImpl.ASSIGNEETASKID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_ASSIGNTOUSERIDANDASSIGNEETASKID =
		new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByAssignToUserIdAndAssigneeTaskId",
			new String[] { Long.class.getName(), Long.class.getName() });

	/**
	 * Returns all the task assignments where assignToUserId = &#63; and assigneeTaskId = &#63;.
	 *
	 * @param assignToUserId the assign to user ID
	 * @param assigneeTaskId the assignee task ID
	 * @return the matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByAssignToUserIdAndAssigneeTaskId(
		long assignToUserId, long assigneeTaskId) throws SystemException {
		return findByAssignToUserIdAndAssigneeTaskId(assignToUserId,
			assigneeTaskId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the task assignments where assignToUserId = &#63; and assigneeTaskId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param assignToUserId the assign to user ID
	 * @param assigneeTaskId the assignee task ID
	 * @param start the lower bound of the range of task assignments
	 * @param end the upper bound of the range of task assignments (not inclusive)
	 * @return the range of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByAssignToUserIdAndAssigneeTaskId(
		long assignToUserId, long assigneeTaskId, int start, int end)
		throws SystemException {
		return findByAssignToUserIdAndAssigneeTaskId(assignToUserId,
			assigneeTaskId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the task assignments where assignToUserId = &#63; and assigneeTaskId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param assignToUserId the assign to user ID
	 * @param assigneeTaskId the assignee task ID
	 * @param start the lower bound of the range of task assignments
	 * @param end the upper bound of the range of task assignments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByAssignToUserIdAndAssigneeTaskId(
		long assignToUserId, long assigneeTaskId, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNTOUSERIDANDASSIGNEETASKID;
			finderArgs = new Object[] { assignToUserId, assigneeTaskId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ASSIGNTOUSERIDANDASSIGNEETASKID;
			finderArgs = new Object[] {
					assignToUserId, assigneeTaskId,
					
					start, end, orderByComparator
				};
		}

		List<TaskAssignment> list = (List<TaskAssignment>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (TaskAssignment taskAssignment : list) {
				if ((assignToUserId != taskAssignment.getAssignToUserId()) ||
						(assigneeTaskId != taskAssignment.getAssigneeTaskId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_ASSIGNTOUSERIDANDASSIGNEETASKID_ASSIGNTOUSERID_2);

			query.append(_FINDER_COLUMN_ASSIGNTOUSERIDANDASSIGNEETASKID_ASSIGNEETASKID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(TaskAssignmentModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(assignToUserId);

				qPos.add(assigneeTaskId);

				if (!pagination) {
					list = (List<TaskAssignment>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<TaskAssignment>(list);
				}
				else {
					list = (List<TaskAssignment>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first task assignment in the ordered set where assignToUserId = &#63; and assigneeTaskId = &#63;.
	 *
	 * @param assignToUserId the assign to user ID
	 * @param assigneeTaskId the assignee task ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment findByAssignToUserIdAndAssigneeTaskId_First(
		long assignToUserId, long assigneeTaskId,
		OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = fetchByAssignToUserIdAndAssigneeTaskId_First(assignToUserId,
				assigneeTaskId, orderByComparator);

		if (taskAssignment != null) {
			return taskAssignment;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("assignToUserId=");
		msg.append(assignToUserId);

		msg.append(", assigneeTaskId=");
		msg.append(assigneeTaskId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchTaskAssignmentException(msg.toString());
	}

	/**
	 * Returns the first task assignment in the ordered set where assignToUserId = &#63; and assigneeTaskId = &#63;.
	 *
	 * @param assignToUserId the assign to user ID
	 * @param assigneeTaskId the assignee task ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByAssignToUserIdAndAssigneeTaskId_First(
		long assignToUserId, long assigneeTaskId,
		OrderByComparator orderByComparator) throws SystemException {
		List<TaskAssignment> list = findByAssignToUserIdAndAssigneeTaskId(assignToUserId,
				assigneeTaskId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last task assignment in the ordered set where assignToUserId = &#63; and assigneeTaskId = &#63;.
	 *
	 * @param assignToUserId the assign to user ID
	 * @param assigneeTaskId the assignee task ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment findByAssignToUserIdAndAssigneeTaskId_Last(
		long assignToUserId, long assigneeTaskId,
		OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = fetchByAssignToUserIdAndAssigneeTaskId_Last(assignToUserId,
				assigneeTaskId, orderByComparator);

		if (taskAssignment != null) {
			return taskAssignment;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("assignToUserId=");
		msg.append(assignToUserId);

		msg.append(", assigneeTaskId=");
		msg.append(assigneeTaskId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchTaskAssignmentException(msg.toString());
	}

	/**
	 * Returns the last task assignment in the ordered set where assignToUserId = &#63; and assigneeTaskId = &#63;.
	 *
	 * @param assignToUserId the assign to user ID
	 * @param assigneeTaskId the assignee task ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByAssignToUserIdAndAssigneeTaskId_Last(
		long assignToUserId, long assigneeTaskId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByAssignToUserIdAndAssigneeTaskId(assignToUserId,
				assigneeTaskId);

		if (count == 0) {
			return null;
		}

		List<TaskAssignment> list = findByAssignToUserIdAndAssigneeTaskId(assignToUserId,
				assigneeTaskId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the task assignments before and after the current task assignment in the ordered set where assignToUserId = &#63; and assigneeTaskId = &#63;.
	 *
	 * @param taskAssignmentId the primary key of the current task assignment
	 * @param assignToUserId the assign to user ID
	 * @param assigneeTaskId the assignee task ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment[] findByAssignToUserIdAndAssigneeTaskId_PrevAndNext(
		long taskAssignmentId, long assignToUserId, long assigneeTaskId,
		OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = findByPrimaryKey(taskAssignmentId);

		Session session = null;

		try {
			session = openSession();

			TaskAssignment[] array = new TaskAssignmentImpl[3];

			array[0] = getByAssignToUserIdAndAssigneeTaskId_PrevAndNext(session,
					taskAssignment, assignToUserId, assigneeTaskId,
					orderByComparator, true);

			array[1] = taskAssignment;

			array[2] = getByAssignToUserIdAndAssigneeTaskId_PrevAndNext(session,
					taskAssignment, assignToUserId, assigneeTaskId,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected TaskAssignment getByAssignToUserIdAndAssigneeTaskId_PrevAndNext(
		Session session, TaskAssignment taskAssignment, long assignToUserId,
		long assigneeTaskId, OrderByComparator orderByComparator,
		boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_TASKASSIGNMENT_WHERE);

		query.append(_FINDER_COLUMN_ASSIGNTOUSERIDANDASSIGNEETASKID_ASSIGNTOUSERID_2);

		query.append(_FINDER_COLUMN_ASSIGNTOUSERIDANDASSIGNEETASKID_ASSIGNEETASKID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(TaskAssignmentModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(assignToUserId);

		qPos.add(assigneeTaskId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(taskAssignment);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<TaskAssignment> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the task assignments where assignToUserId = &#63; and assigneeTaskId = &#63; from the database.
	 *
	 * @param assignToUserId the assign to user ID
	 * @param assigneeTaskId the assignee task ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByAssignToUserIdAndAssigneeTaskId(long assignToUserId,
		long assigneeTaskId) throws SystemException {
		for (TaskAssignment taskAssignment : findByAssignToUserIdAndAssigneeTaskId(
				assignToUserId, assigneeTaskId, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(taskAssignment);
		}
	}

	/**
	 * Returns the number of task assignments where assignToUserId = &#63; and assigneeTaskId = &#63;.
	 *
	 * @param assignToUserId the assign to user ID
	 * @param assigneeTaskId the assignee task ID
	 * @return the number of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByAssignToUserIdAndAssigneeTaskId(long assignToUserId,
		long assigneeTaskId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_ASSIGNTOUSERIDANDASSIGNEETASKID;

		Object[] finderArgs = new Object[] { assignToUserId, assigneeTaskId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_ASSIGNTOUSERIDANDASSIGNEETASKID_ASSIGNTOUSERID_2);

			query.append(_FINDER_COLUMN_ASSIGNTOUSERIDANDASSIGNEETASKID_ASSIGNEETASKID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(assignToUserId);

				qPos.add(assigneeTaskId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_ASSIGNTOUSERIDANDASSIGNEETASKID_ASSIGNTOUSERID_2 =
		"taskAssignment.assignToUserId = ? AND ";
	private static final String _FINDER_COLUMN_ASSIGNTOUSERIDANDASSIGNEETASKID_ASSIGNEETASKID_2 =
		"taskAssignment.assigneeTaskId = ?";
	public static final FinderPath FINDER_PATH_FETCH_BY_TASKANDASSIGNEETASKID = new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED,
			TaskAssignmentImpl.class, FINDER_CLASS_NAME_ENTITY,
			"fetchByTaskAndAssigneeTaskId",
			new String[] {
				Long.class.getName(), Long.class.getName(), Long.class.getName()
			},
			TaskAssignmentModelImpl.TASKID_COLUMN_BITMASK |
			TaskAssignmentModelImpl.ASSIGNTOUSERID_COLUMN_BITMASK |
			TaskAssignmentModelImpl.ASSIGNEETASKID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_TASKANDASSIGNEETASKID = new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByTaskAndAssigneeTaskId",
			new String[] {
				Long.class.getName(), Long.class.getName(), Long.class.getName()
			});

	/**
	 * Returns the task assignment where taskId = &#63; and assignToUserId = &#63; and assigneeTaskId = &#63; or throws a {@link com.jioc.taskmanagement.NoSuchTaskAssignmentException} if it could not be found.
	 *
	 * @param taskId the task ID
	 * @param assignToUserId the assign to user ID
	 * @param assigneeTaskId the assignee task ID
	 * @return the matching task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment findByTaskAndAssigneeTaskId(long taskId,
		long assignToUserId, long assigneeTaskId)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = fetchByTaskAndAssigneeTaskId(taskId,
				assignToUserId, assigneeTaskId);

		if (taskAssignment == null) {
			StringBundler msg = new StringBundler(8);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("taskId=");
			msg.append(taskId);

			msg.append(", assignToUserId=");
			msg.append(assignToUserId);

			msg.append(", assigneeTaskId=");
			msg.append(assigneeTaskId);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchTaskAssignmentException(msg.toString());
		}

		return taskAssignment;
	}

	/**
	 * Returns the task assignment where taskId = &#63; and assignToUserId = &#63; and assigneeTaskId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param taskId the task ID
	 * @param assignToUserId the assign to user ID
	 * @param assigneeTaskId the assignee task ID
	 * @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByTaskAndAssigneeTaskId(long taskId,
		long assignToUserId, long assigneeTaskId) throws SystemException {
		return fetchByTaskAndAssigneeTaskId(taskId, assignToUserId,
			assigneeTaskId, true);
	}

	/**
	 * Returns the task assignment where taskId = &#63; and assignToUserId = &#63; and assigneeTaskId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param taskId the task ID
	 * @param assignToUserId the assign to user ID
	 * @param assigneeTaskId the assignee task ID
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByTaskAndAssigneeTaskId(long taskId,
		long assignToUserId, long assigneeTaskId, boolean retrieveFromCache)
		throws SystemException {
		Object[] finderArgs = new Object[] {
				taskId, assignToUserId, assigneeTaskId
			};

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_TASKANDASSIGNEETASKID,
					finderArgs, this);
		}

		if (result instanceof TaskAssignment) {
			TaskAssignment taskAssignment = (TaskAssignment)result;

			if ((taskId != taskAssignment.getTaskId()) ||
					(assignToUserId != taskAssignment.getAssignToUserId()) ||
					(assigneeTaskId != taskAssignment.getAssigneeTaskId())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(5);

			query.append(_SQL_SELECT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_TASKANDASSIGNEETASKID_TASKID_2);

			query.append(_FINDER_COLUMN_TASKANDASSIGNEETASKID_ASSIGNTOUSERID_2);

			query.append(_FINDER_COLUMN_TASKANDASSIGNEETASKID_ASSIGNEETASKID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(taskId);

				qPos.add(assignToUserId);

				qPos.add(assigneeTaskId);

				List<TaskAssignment> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TASKANDASSIGNEETASKID,
						finderArgs, list);
				}
				else {
					if ((list.size() > 1) && _log.isWarnEnabled()) {
						_log.warn(
							"TaskAssignmentPersistenceImpl.fetchByTaskAndAssigneeTaskId(long, long, long, boolean) with parameters (" +
							StringUtil.merge(finderArgs) +
							") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
					}

					TaskAssignment taskAssignment = list.get(0);

					result = taskAssignment;

					cacheResult(taskAssignment);

					if ((taskAssignment.getTaskId() != taskId) ||
							(taskAssignment.getAssignToUserId() != assignToUserId) ||
							(taskAssignment.getAssigneeTaskId() != assigneeTaskId)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TASKANDASSIGNEETASKID,
							finderArgs, taskAssignment);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_TASKANDASSIGNEETASKID,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (TaskAssignment)result;
		}
	}

	/**
	 * Removes the task assignment where taskId = &#63; and assignToUserId = &#63; and assigneeTaskId = &#63; from the database.
	 *
	 * @param taskId the task ID
	 * @param assignToUserId the assign to user ID
	 * @param assigneeTaskId the assignee task ID
	 * @return the task assignment that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment removeByTaskAndAssigneeTaskId(long taskId,
		long assignToUserId, long assigneeTaskId)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = findByTaskAndAssigneeTaskId(taskId,
				assignToUserId, assigneeTaskId);

		return remove(taskAssignment);
	}

	/**
	 * Returns the number of task assignments where taskId = &#63; and assignToUserId = &#63; and assigneeTaskId = &#63;.
	 *
	 * @param taskId the task ID
	 * @param assignToUserId the assign to user ID
	 * @param assigneeTaskId the assignee task ID
	 * @return the number of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByTaskAndAssigneeTaskId(long taskId, long assignToUserId,
		long assigneeTaskId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_TASKANDASSIGNEETASKID;

		Object[] finderArgs = new Object[] {
				taskId, assignToUserId, assigneeTaskId
			};

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_COUNT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_TASKANDASSIGNEETASKID_TASKID_2);

			query.append(_FINDER_COLUMN_TASKANDASSIGNEETASKID_ASSIGNTOUSERID_2);

			query.append(_FINDER_COLUMN_TASKANDASSIGNEETASKID_ASSIGNEETASKID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(taskId);

				qPos.add(assignToUserId);

				qPos.add(assigneeTaskId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_TASKANDASSIGNEETASKID_TASKID_2 = "taskAssignment.taskId = ? AND ";
	private static final String _FINDER_COLUMN_TASKANDASSIGNEETASKID_ASSIGNTOUSERID_2 =
		"taskAssignment.assignToUserId = ? AND ";
	private static final String _FINDER_COLUMN_TASKANDASSIGNEETASKID_ASSIGNEETASKID_2 =
		"taskAssignment.assigneeTaskId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_STATUSBYASSIGNEETASKID =
		new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED,
			TaskAssignmentImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByStatusByAssigneeTaskId",
			new String[] {
				Long.class.getName(), String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATUSBYASSIGNEETASKID =
		new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED,
			TaskAssignmentImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByStatusByAssigneeTaskId",
			new String[] { Long.class.getName(), String.class.getName() },
			TaskAssignmentModelImpl.ASSIGNEETASKID_COLUMN_BITMASK |
			TaskAssignmentModelImpl.STATUS_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_STATUSBYASSIGNEETASKID = new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByStatusByAssigneeTaskId",
			new String[] { Long.class.getName(), String.class.getName() });

	/**
	 * Returns all the task assignments where assigneeTaskId = &#63; and status = &#63;.
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @param status the status
	 * @return the matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByStatusByAssigneeTaskId(
		long assigneeTaskId, String status) throws SystemException {
		return findByStatusByAssigneeTaskId(assigneeTaskId, status,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the task assignments where assigneeTaskId = &#63; and status = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @param status the status
	 * @param start the lower bound of the range of task assignments
	 * @param end the upper bound of the range of task assignments (not inclusive)
	 * @return the range of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByStatusByAssigneeTaskId(
		long assigneeTaskId, String status, int start, int end)
		throws SystemException {
		return findByStatusByAssigneeTaskId(assigneeTaskId, status, start, end,
			null);
	}

	/**
	 * Returns an ordered range of all the task assignments where assigneeTaskId = &#63; and status = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @param status the status
	 * @param start the lower bound of the range of task assignments
	 * @param end the upper bound of the range of task assignments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByStatusByAssigneeTaskId(
		long assigneeTaskId, String status, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATUSBYASSIGNEETASKID;
			finderArgs = new Object[] { assigneeTaskId, status };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_STATUSBYASSIGNEETASKID;
			finderArgs = new Object[] {
					assigneeTaskId, status,
					
					start, end, orderByComparator
				};
		}

		List<TaskAssignment> list = (List<TaskAssignment>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (TaskAssignment taskAssignment : list) {
				if ((assigneeTaskId != taskAssignment.getAssigneeTaskId()) ||
						!Validator.equals(status, taskAssignment.getStatus())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_STATUSBYASSIGNEETASKID_ASSIGNEETASKID_2);

			boolean bindStatus = false;

			if (status == null) {
				query.append(_FINDER_COLUMN_STATUSBYASSIGNEETASKID_STATUS_1);
			}
			else if (status.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_STATUSBYASSIGNEETASKID_STATUS_3);
			}
			else {
				bindStatus = true;

				query.append(_FINDER_COLUMN_STATUSBYASSIGNEETASKID_STATUS_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(TaskAssignmentModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(assigneeTaskId);

				if (bindStatus) {
					qPos.add(status);
				}

				if (!pagination) {
					list = (List<TaskAssignment>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<TaskAssignment>(list);
				}
				else {
					list = (List<TaskAssignment>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first task assignment in the ordered set where assigneeTaskId = &#63; and status = &#63;.
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment findByStatusByAssigneeTaskId_First(
		long assigneeTaskId, String status, OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = fetchByStatusByAssigneeTaskId_First(assigneeTaskId,
				status, orderByComparator);

		if (taskAssignment != null) {
			return taskAssignment;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("assigneeTaskId=");
		msg.append(assigneeTaskId);

		msg.append(", status=");
		msg.append(status);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchTaskAssignmentException(msg.toString());
	}

	/**
	 * Returns the first task assignment in the ordered set where assigneeTaskId = &#63; and status = &#63;.
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByStatusByAssigneeTaskId_First(
		long assigneeTaskId, String status, OrderByComparator orderByComparator)
		throws SystemException {
		List<TaskAssignment> list = findByStatusByAssigneeTaskId(assigneeTaskId,
				status, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last task assignment in the ordered set where assigneeTaskId = &#63; and status = &#63;.
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment findByStatusByAssigneeTaskId_Last(
		long assigneeTaskId, String status, OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = fetchByStatusByAssigneeTaskId_Last(assigneeTaskId,
				status, orderByComparator);

		if (taskAssignment != null) {
			return taskAssignment;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("assigneeTaskId=");
		msg.append(assigneeTaskId);

		msg.append(", status=");
		msg.append(status);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchTaskAssignmentException(msg.toString());
	}

	/**
	 * Returns the last task assignment in the ordered set where assigneeTaskId = &#63; and status = &#63;.
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByStatusByAssigneeTaskId_Last(
		long assigneeTaskId, String status, OrderByComparator orderByComparator)
		throws SystemException {
		int count = countByStatusByAssigneeTaskId(assigneeTaskId, status);

		if (count == 0) {
			return null;
		}

		List<TaskAssignment> list = findByStatusByAssigneeTaskId(assigneeTaskId,
				status, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the task assignments before and after the current task assignment in the ordered set where assigneeTaskId = &#63; and status = &#63;.
	 *
	 * @param taskAssignmentId the primary key of the current task assignment
	 * @param assigneeTaskId the assignee task ID
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment[] findByStatusByAssigneeTaskId_PrevAndNext(
		long taskAssignmentId, long assigneeTaskId, String status,
		OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = findByPrimaryKey(taskAssignmentId);

		Session session = null;

		try {
			session = openSession();

			TaskAssignment[] array = new TaskAssignmentImpl[3];

			array[0] = getByStatusByAssigneeTaskId_PrevAndNext(session,
					taskAssignment, assigneeTaskId, status, orderByComparator,
					true);

			array[1] = taskAssignment;

			array[2] = getByStatusByAssigneeTaskId_PrevAndNext(session,
					taskAssignment, assigneeTaskId, status, orderByComparator,
					false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected TaskAssignment getByStatusByAssigneeTaskId_PrevAndNext(
		Session session, TaskAssignment taskAssignment, long assigneeTaskId,
		String status, OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_TASKASSIGNMENT_WHERE);

		query.append(_FINDER_COLUMN_STATUSBYASSIGNEETASKID_ASSIGNEETASKID_2);

		boolean bindStatus = false;

		if (status == null) {
			query.append(_FINDER_COLUMN_STATUSBYASSIGNEETASKID_STATUS_1);
		}
		else if (status.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_STATUSBYASSIGNEETASKID_STATUS_3);
		}
		else {
			bindStatus = true;

			query.append(_FINDER_COLUMN_STATUSBYASSIGNEETASKID_STATUS_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(TaskAssignmentModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(assigneeTaskId);

		if (bindStatus) {
			qPos.add(status);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(taskAssignment);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<TaskAssignment> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the task assignments where assigneeTaskId = &#63; and status = &#63; from the database.
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @param status the status
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByStatusByAssigneeTaskId(long assigneeTaskId,
		String status) throws SystemException {
		for (TaskAssignment taskAssignment : findByStatusByAssigneeTaskId(
				assigneeTaskId, status, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
				null)) {
			remove(taskAssignment);
		}
	}

	/**
	 * Returns the number of task assignments where assigneeTaskId = &#63; and status = &#63;.
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @param status the status
	 * @return the number of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByStatusByAssigneeTaskId(long assigneeTaskId, String status)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_STATUSBYASSIGNEETASKID;

		Object[] finderArgs = new Object[] { assigneeTaskId, status };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_STATUSBYASSIGNEETASKID_ASSIGNEETASKID_2);

			boolean bindStatus = false;

			if (status == null) {
				query.append(_FINDER_COLUMN_STATUSBYASSIGNEETASKID_STATUS_1);
			}
			else if (status.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_STATUSBYASSIGNEETASKID_STATUS_3);
			}
			else {
				bindStatus = true;

				query.append(_FINDER_COLUMN_STATUSBYASSIGNEETASKID_STATUS_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(assigneeTaskId);

				if (bindStatus) {
					qPos.add(status);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_STATUSBYASSIGNEETASKID_ASSIGNEETASKID_2 =
		"taskAssignment.assigneeTaskId = ? AND ";
	private static final String _FINDER_COLUMN_STATUSBYASSIGNEETASKID_STATUS_1 = "taskAssignment.status IS NULL";
	private static final String _FINDER_COLUMN_STATUSBYASSIGNEETASKID_STATUS_2 = "taskAssignment.status = ?";
	private static final String _FINDER_COLUMN_STATUSBYASSIGNEETASKID_STATUS_3 = "(taskAssignment.status IS NULL OR taskAssignment.status = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ASSIGNMENTSBYASSIGNEETASKID =
		new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED,
			TaskAssignmentImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByAssignmentsByAssigneetaskId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNMENTSBYASSIGNEETASKID =
		new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED,
			TaskAssignmentImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByAssignmentsByAssigneetaskId",
			new String[] { Long.class.getName() },
			TaskAssignmentModelImpl.ASSIGNEETASKID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_ASSIGNMENTSBYASSIGNEETASKID =
		new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByAssignmentsByAssigneetaskId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the task assignments where assigneeTaskId = &#63;.
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @return the matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByAssignmentsByAssigneetaskId(
		long assigneeTaskId) throws SystemException {
		return findByAssignmentsByAssigneetaskId(assigneeTaskId,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the task assignments where assigneeTaskId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @param start the lower bound of the range of task assignments
	 * @param end the upper bound of the range of task assignments (not inclusive)
	 * @return the range of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByAssignmentsByAssigneetaskId(
		long assigneeTaskId, int start, int end) throws SystemException {
		return findByAssignmentsByAssigneetaskId(assigneeTaskId, start, end,
			null);
	}

	/**
	 * Returns an ordered range of all the task assignments where assigneeTaskId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @param start the lower bound of the range of task assignments
	 * @param end the upper bound of the range of task assignments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByAssignmentsByAssigneetaskId(
		long assigneeTaskId, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNMENTSBYASSIGNEETASKID;
			finderArgs = new Object[] { assigneeTaskId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ASSIGNMENTSBYASSIGNEETASKID;
			finderArgs = new Object[] {
					assigneeTaskId,
					
					start, end, orderByComparator
				};
		}

		List<TaskAssignment> list = (List<TaskAssignment>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (TaskAssignment taskAssignment : list) {
				if ((assigneeTaskId != taskAssignment.getAssigneeTaskId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_ASSIGNMENTSBYASSIGNEETASKID_ASSIGNEETASKID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(TaskAssignmentModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(assigneeTaskId);

				if (!pagination) {
					list = (List<TaskAssignment>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<TaskAssignment>(list);
				}
				else {
					list = (List<TaskAssignment>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first task assignment in the ordered set where assigneeTaskId = &#63;.
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment findByAssignmentsByAssigneetaskId_First(
		long assigneeTaskId, OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = fetchByAssignmentsByAssigneetaskId_First(assigneeTaskId,
				orderByComparator);

		if (taskAssignment != null) {
			return taskAssignment;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("assigneeTaskId=");
		msg.append(assigneeTaskId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchTaskAssignmentException(msg.toString());
	}

	/**
	 * Returns the first task assignment in the ordered set where assigneeTaskId = &#63;.
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByAssignmentsByAssigneetaskId_First(
		long assigneeTaskId, OrderByComparator orderByComparator)
		throws SystemException {
		List<TaskAssignment> list = findByAssignmentsByAssigneetaskId(assigneeTaskId,
				0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last task assignment in the ordered set where assigneeTaskId = &#63;.
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment findByAssignmentsByAssigneetaskId_Last(
		long assigneeTaskId, OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = fetchByAssignmentsByAssigneetaskId_Last(assigneeTaskId,
				orderByComparator);

		if (taskAssignment != null) {
			return taskAssignment;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("assigneeTaskId=");
		msg.append(assigneeTaskId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchTaskAssignmentException(msg.toString());
	}

	/**
	 * Returns the last task assignment in the ordered set where assigneeTaskId = &#63;.
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByAssignmentsByAssigneetaskId_Last(
		long assigneeTaskId, OrderByComparator orderByComparator)
		throws SystemException {
		int count = countByAssignmentsByAssigneetaskId(assigneeTaskId);

		if (count == 0) {
			return null;
		}

		List<TaskAssignment> list = findByAssignmentsByAssigneetaskId(assigneeTaskId,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the task assignments before and after the current task assignment in the ordered set where assigneeTaskId = &#63;.
	 *
	 * @param taskAssignmentId the primary key of the current task assignment
	 * @param assigneeTaskId the assignee task ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment[] findByAssignmentsByAssigneetaskId_PrevAndNext(
		long taskAssignmentId, long assigneeTaskId,
		OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = findByPrimaryKey(taskAssignmentId);

		Session session = null;

		try {
			session = openSession();

			TaskAssignment[] array = new TaskAssignmentImpl[3];

			array[0] = getByAssignmentsByAssigneetaskId_PrevAndNext(session,
					taskAssignment, assigneeTaskId, orderByComparator, true);

			array[1] = taskAssignment;

			array[2] = getByAssignmentsByAssigneetaskId_PrevAndNext(session,
					taskAssignment, assigneeTaskId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected TaskAssignment getByAssignmentsByAssigneetaskId_PrevAndNext(
		Session session, TaskAssignment taskAssignment, long assigneeTaskId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_TASKASSIGNMENT_WHERE);

		query.append(_FINDER_COLUMN_ASSIGNMENTSBYASSIGNEETASKID_ASSIGNEETASKID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(TaskAssignmentModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(assigneeTaskId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(taskAssignment);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<TaskAssignment> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the task assignments where assigneeTaskId = &#63; from the database.
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByAssignmentsByAssigneetaskId(long assigneeTaskId)
		throws SystemException {
		for (TaskAssignment taskAssignment : findByAssignmentsByAssigneetaskId(
				assigneeTaskId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(taskAssignment);
		}
	}

	/**
	 * Returns the number of task assignments where assigneeTaskId = &#63;.
	 *
	 * @param assigneeTaskId the assignee task ID
	 * @return the number of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByAssignmentsByAssigneetaskId(long assigneeTaskId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_ASSIGNMENTSBYASSIGNEETASKID;

		Object[] finderArgs = new Object[] { assigneeTaskId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_ASSIGNMENTSBYASSIGNEETASKID_ASSIGNEETASKID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(assigneeTaskId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_ASSIGNMENTSBYASSIGNEETASKID_ASSIGNEETASKID_2 =
		"taskAssignment.assigneeTaskId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_ASSIGNMENTSBYTASKIDANDSTATUS =
		new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED,
			TaskAssignmentImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByAssignmentsByTaskIdAndStatus",
			new String[] {
				Long.class.getName(), String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNMENTSBYTASKIDANDSTATUS =
		new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED,
			TaskAssignmentImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByAssignmentsByTaskIdAndStatus",
			new String[] { Long.class.getName(), String.class.getName() },
			TaskAssignmentModelImpl.TASKID_COLUMN_BITMASK |
			TaskAssignmentModelImpl.STATUS_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_ASSIGNMENTSBYTASKIDANDSTATUS =
		new FinderPath(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByAssignmentsByTaskIdAndStatus",
			new String[] { Long.class.getName(), String.class.getName() });

	/**
	 * Returns all the task assignments where taskId = &#63; and status = &#63;.
	 *
	 * @param taskId the task ID
	 * @param status the status
	 * @return the matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByAssignmentsByTaskIdAndStatus(
		long taskId, String status) throws SystemException {
		return findByAssignmentsByTaskIdAndStatus(taskId, status,
			QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the task assignments where taskId = &#63; and status = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param taskId the task ID
	 * @param status the status
	 * @param start the lower bound of the range of task assignments
	 * @param end the upper bound of the range of task assignments (not inclusive)
	 * @return the range of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByAssignmentsByTaskIdAndStatus(
		long taskId, String status, int start, int end)
		throws SystemException {
		return findByAssignmentsByTaskIdAndStatus(taskId, status, start, end,
			null);
	}

	/**
	 * Returns an ordered range of all the task assignments where taskId = &#63; and status = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param taskId the task ID
	 * @param status the status
	 * @param start the lower bound of the range of task assignments
	 * @param end the upper bound of the range of task assignments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findByAssignmentsByTaskIdAndStatus(
		long taskId, String status, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNMENTSBYTASKIDANDSTATUS;
			finderArgs = new Object[] { taskId, status };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_ASSIGNMENTSBYTASKIDANDSTATUS;
			finderArgs = new Object[] {
					taskId, status,
					
					start, end, orderByComparator
				};
		}

		List<TaskAssignment> list = (List<TaskAssignment>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (TaskAssignment taskAssignment : list) {
				if ((taskId != taskAssignment.getTaskId()) ||
						!Validator.equals(status, taskAssignment.getStatus())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_ASSIGNMENTSBYTASKIDANDSTATUS_TASKID_2);

			boolean bindStatus = false;

			if (status == null) {
				query.append(_FINDER_COLUMN_ASSIGNMENTSBYTASKIDANDSTATUS_STATUS_1);
			}
			else if (status.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_ASSIGNMENTSBYTASKIDANDSTATUS_STATUS_3);
			}
			else {
				bindStatus = true;

				query.append(_FINDER_COLUMN_ASSIGNMENTSBYTASKIDANDSTATUS_STATUS_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(TaskAssignmentModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(taskId);

				if (bindStatus) {
					qPos.add(status);
				}

				if (!pagination) {
					list = (List<TaskAssignment>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<TaskAssignment>(list);
				}
				else {
					list = (List<TaskAssignment>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first task assignment in the ordered set where taskId = &#63; and status = &#63;.
	 *
	 * @param taskId the task ID
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment findByAssignmentsByTaskIdAndStatus_First(
		long taskId, String status, OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = fetchByAssignmentsByTaskIdAndStatus_First(taskId,
				status, orderByComparator);

		if (taskAssignment != null) {
			return taskAssignment;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("taskId=");
		msg.append(taskId);

		msg.append(", status=");
		msg.append(status);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchTaskAssignmentException(msg.toString());
	}

	/**
	 * Returns the first task assignment in the ordered set where taskId = &#63; and status = &#63;.
	 *
	 * @param taskId the task ID
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByAssignmentsByTaskIdAndStatus_First(
		long taskId, String status, OrderByComparator orderByComparator)
		throws SystemException {
		List<TaskAssignment> list = findByAssignmentsByTaskIdAndStatus(taskId,
				status, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last task assignment in the ordered set where taskId = &#63; and status = &#63;.
	 *
	 * @param taskId the task ID
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment findByAssignmentsByTaskIdAndStatus_Last(long taskId,
		String status, OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = fetchByAssignmentsByTaskIdAndStatus_Last(taskId,
				status, orderByComparator);

		if (taskAssignment != null) {
			return taskAssignment;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("taskId=");
		msg.append(taskId);

		msg.append(", status=");
		msg.append(status);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchTaskAssignmentException(msg.toString());
	}

	/**
	 * Returns the last task assignment in the ordered set where taskId = &#63; and status = &#63;.
	 *
	 * @param taskId the task ID
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByAssignmentsByTaskIdAndStatus_Last(
		long taskId, String status, OrderByComparator orderByComparator)
		throws SystemException {
		int count = countByAssignmentsByTaskIdAndStatus(taskId, status);

		if (count == 0) {
			return null;
		}

		List<TaskAssignment> list = findByAssignmentsByTaskIdAndStatus(taskId,
				status, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the task assignments before and after the current task assignment in the ordered set where taskId = &#63; and status = &#63;.
	 *
	 * @param taskAssignmentId the primary key of the current task assignment
	 * @param taskId the task ID
	 * @param status the status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment[] findByAssignmentsByTaskIdAndStatus_PrevAndNext(
		long taskAssignmentId, long taskId, String status,
		OrderByComparator orderByComparator)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = findByPrimaryKey(taskAssignmentId);

		Session session = null;

		try {
			session = openSession();

			TaskAssignment[] array = new TaskAssignmentImpl[3];

			array[0] = getByAssignmentsByTaskIdAndStatus_PrevAndNext(session,
					taskAssignment, taskId, status, orderByComparator, true);

			array[1] = taskAssignment;

			array[2] = getByAssignmentsByTaskIdAndStatus_PrevAndNext(session,
					taskAssignment, taskId, status, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected TaskAssignment getByAssignmentsByTaskIdAndStatus_PrevAndNext(
		Session session, TaskAssignment taskAssignment, long taskId,
		String status, OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_TASKASSIGNMENT_WHERE);

		query.append(_FINDER_COLUMN_ASSIGNMENTSBYTASKIDANDSTATUS_TASKID_2);

		boolean bindStatus = false;

		if (status == null) {
			query.append(_FINDER_COLUMN_ASSIGNMENTSBYTASKIDANDSTATUS_STATUS_1);
		}
		else if (status.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_ASSIGNMENTSBYTASKIDANDSTATUS_STATUS_3);
		}
		else {
			bindStatus = true;

			query.append(_FINDER_COLUMN_ASSIGNMENTSBYTASKIDANDSTATUS_STATUS_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(TaskAssignmentModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(taskId);

		if (bindStatus) {
			qPos.add(status);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(taskAssignment);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<TaskAssignment> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the task assignments where taskId = &#63; and status = &#63; from the database.
	 *
	 * @param taskId the task ID
	 * @param status the status
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByAssignmentsByTaskIdAndStatus(long taskId, String status)
		throws SystemException {
		for (TaskAssignment taskAssignment : findByAssignmentsByTaskIdAndStatus(
				taskId, status, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(taskAssignment);
		}
	}

	/**
	 * Returns the number of task assignments where taskId = &#63; and status = &#63;.
	 *
	 * @param taskId the task ID
	 * @param status the status
	 * @return the number of matching task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByAssignmentsByTaskIdAndStatus(long taskId, String status)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_ASSIGNMENTSBYTASKIDANDSTATUS;

		Object[] finderArgs = new Object[] { taskId, status };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_TASKASSIGNMENT_WHERE);

			query.append(_FINDER_COLUMN_ASSIGNMENTSBYTASKIDANDSTATUS_TASKID_2);

			boolean bindStatus = false;

			if (status == null) {
				query.append(_FINDER_COLUMN_ASSIGNMENTSBYTASKIDANDSTATUS_STATUS_1);
			}
			else if (status.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_ASSIGNMENTSBYTASKIDANDSTATUS_STATUS_3);
			}
			else {
				bindStatus = true;

				query.append(_FINDER_COLUMN_ASSIGNMENTSBYTASKIDANDSTATUS_STATUS_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(taskId);

				if (bindStatus) {
					qPos.add(status);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_ASSIGNMENTSBYTASKIDANDSTATUS_TASKID_2 =
		"taskAssignment.taskId = ? AND ";
	private static final String _FINDER_COLUMN_ASSIGNMENTSBYTASKIDANDSTATUS_STATUS_1 =
		"taskAssignment.status IS NULL";
	private static final String _FINDER_COLUMN_ASSIGNMENTSBYTASKIDANDSTATUS_STATUS_2 =
		"taskAssignment.status = ?";
	private static final String _FINDER_COLUMN_ASSIGNMENTSBYTASKIDANDSTATUS_STATUS_3 =
		"(taskAssignment.status IS NULL OR taskAssignment.status = '')";

	public TaskAssignmentPersistenceImpl() {
		setModelClass(TaskAssignment.class);
	}

	/**
	 * Caches the task assignment in the entity cache if it is enabled.
	 *
	 * @param taskAssignment the task assignment
	 */
	@Override
	public void cacheResult(TaskAssignment taskAssignment) {
		EntityCacheUtil.putResult(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentImpl.class, taskAssignment.getPrimaryKey(),
			taskAssignment);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TASKDETAILASSIGNTOME,
			new Object[] {
				taskAssignment.getTaskId(), taskAssignment.getAssignByUserId()
			}, taskAssignment);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_AVAILABLEASSIGNEE,
			new Object[] {
				taskAssignment.getTaskId(), taskAssignment.getAssignToUserId()
			}, taskAssignment);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TASKANDASSIGNEETASKID,
			new Object[] {
				taskAssignment.getTaskId(), taskAssignment.getAssignToUserId(),
				taskAssignment.getAssigneeTaskId()
			}, taskAssignment);

		taskAssignment.resetOriginalValues();
	}

	/**
	 * Caches the task assignments in the entity cache if it is enabled.
	 *
	 * @param taskAssignments the task assignments
	 */
	@Override
	public void cacheResult(List<TaskAssignment> taskAssignments) {
		for (TaskAssignment taskAssignment : taskAssignments) {
			if (EntityCacheUtil.getResult(
						TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
						TaskAssignmentImpl.class, taskAssignment.getPrimaryKey()) == null) {
				cacheResult(taskAssignment);
			}
			else {
				taskAssignment.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all task assignments.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(TaskAssignmentImpl.class.getName());
		}

		EntityCacheUtil.clearCache(TaskAssignmentImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the task assignment.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(TaskAssignment taskAssignment) {
		EntityCacheUtil.removeResult(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentImpl.class, taskAssignment.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache(taskAssignment);
	}

	@Override
	public void clearCache(List<TaskAssignment> taskAssignments) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (TaskAssignment taskAssignment : taskAssignments) {
			EntityCacheUtil.removeResult(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
				TaskAssignmentImpl.class, taskAssignment.getPrimaryKey());

			clearUniqueFindersCache(taskAssignment);
		}
	}

	protected void cacheUniqueFindersCache(TaskAssignment taskAssignment) {
		if (taskAssignment.isNew()) {
			Object[] args = new Object[] {
					taskAssignment.getTaskId(),
					taskAssignment.getAssignByUserId()
				};

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_TASKDETAILASSIGNTOME,
				args, Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TASKDETAILASSIGNTOME,
				args, taskAssignment);

			args = new Object[] {
					taskAssignment.getTaskId(),
					taskAssignment.getAssignToUserId()
				};

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_AVAILABLEASSIGNEE,
				args, Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_AVAILABLEASSIGNEE,
				args, taskAssignment);

			args = new Object[] {
					taskAssignment.getTaskId(),
					taskAssignment.getAssignToUserId(),
					taskAssignment.getAssigneeTaskId()
				};

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_TASKANDASSIGNEETASKID,
				args, Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TASKANDASSIGNEETASKID,
				args, taskAssignment);
		}
		else {
			TaskAssignmentModelImpl taskAssignmentModelImpl = (TaskAssignmentModelImpl)taskAssignment;

			if ((taskAssignmentModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_TASKDETAILASSIGNTOME.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						taskAssignment.getTaskId(),
						taskAssignment.getAssignByUserId()
					};

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_TASKDETAILASSIGNTOME,
					args, Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TASKDETAILASSIGNTOME,
					args, taskAssignment);
			}

			if ((taskAssignmentModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_AVAILABLEASSIGNEE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						taskAssignment.getTaskId(),
						taskAssignment.getAssignToUserId()
					};

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_AVAILABLEASSIGNEE,
					args, Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_AVAILABLEASSIGNEE,
					args, taskAssignment);
			}

			if ((taskAssignmentModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_TASKANDASSIGNEETASKID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						taskAssignment.getTaskId(),
						taskAssignment.getAssignToUserId(),
						taskAssignment.getAssigneeTaskId()
					};

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_TASKANDASSIGNEETASKID,
					args, Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_TASKANDASSIGNEETASKID,
					args, taskAssignment);
			}
		}
	}

	protected void clearUniqueFindersCache(TaskAssignment taskAssignment) {
		TaskAssignmentModelImpl taskAssignmentModelImpl = (TaskAssignmentModelImpl)taskAssignment;

		Object[] args = new Object[] {
				taskAssignment.getTaskId(), taskAssignment.getAssignByUserId()
			};

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TASKDETAILASSIGNTOME,
			args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_TASKDETAILASSIGNTOME,
			args);

		if ((taskAssignmentModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_TASKDETAILASSIGNTOME.getColumnBitmask()) != 0) {
			args = new Object[] {
					taskAssignmentModelImpl.getOriginalTaskId(),
					taskAssignmentModelImpl.getOriginalAssignByUserId()
				};

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TASKDETAILASSIGNTOME,
				args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_TASKDETAILASSIGNTOME,
				args);
		}

		args = new Object[] {
				taskAssignment.getTaskId(), taskAssignment.getAssignToUserId()
			};

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_AVAILABLEASSIGNEE,
			args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_AVAILABLEASSIGNEE,
			args);

		if ((taskAssignmentModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_AVAILABLEASSIGNEE.getColumnBitmask()) != 0) {
			args = new Object[] {
					taskAssignmentModelImpl.getOriginalTaskId(),
					taskAssignmentModelImpl.getOriginalAssignToUserId()
				};

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_AVAILABLEASSIGNEE,
				args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_AVAILABLEASSIGNEE,
				args);
		}

		args = new Object[] {
				taskAssignment.getTaskId(), taskAssignment.getAssignToUserId(),
				taskAssignment.getAssigneeTaskId()
			};

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TASKANDASSIGNEETASKID,
			args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_TASKANDASSIGNEETASKID,
			args);

		if ((taskAssignmentModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_TASKANDASSIGNEETASKID.getColumnBitmask()) != 0) {
			args = new Object[] {
					taskAssignmentModelImpl.getOriginalTaskId(),
					taskAssignmentModelImpl.getOriginalAssignToUserId(),
					taskAssignmentModelImpl.getOriginalAssigneeTaskId()
				};

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_TASKANDASSIGNEETASKID,
				args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_TASKANDASSIGNEETASKID,
				args);
		}
	}

	/**
	 * Creates a new task assignment with the primary key. Does not add the task assignment to the database.
	 *
	 * @param taskAssignmentId the primary key for the new task assignment
	 * @return the new task assignment
	 */
	@Override
	public TaskAssignment create(long taskAssignmentId) {
		TaskAssignment taskAssignment = new TaskAssignmentImpl();

		taskAssignment.setNew(true);
		taskAssignment.setPrimaryKey(taskAssignmentId);

		return taskAssignment;
	}

	/**
	 * Removes the task assignment with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param taskAssignmentId the primary key of the task assignment
	 * @return the task assignment that was removed
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment remove(long taskAssignmentId)
		throws NoSuchTaskAssignmentException, SystemException {
		return remove((Serializable)taskAssignmentId);
	}

	/**
	 * Removes the task assignment with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the task assignment
	 * @return the task assignment that was removed
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment remove(Serializable primaryKey)
		throws NoSuchTaskAssignmentException, SystemException {
		Session session = null;

		try {
			session = openSession();

			TaskAssignment taskAssignment = (TaskAssignment)session.get(TaskAssignmentImpl.class,
					primaryKey);

			if (taskAssignment == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchTaskAssignmentException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(taskAssignment);
		}
		catch (NoSuchTaskAssignmentException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected TaskAssignment removeImpl(TaskAssignment taskAssignment)
		throws SystemException {
		taskAssignment = toUnwrappedModel(taskAssignment);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(taskAssignment)) {
				taskAssignment = (TaskAssignment)session.get(TaskAssignmentImpl.class,
						taskAssignment.getPrimaryKeyObj());
			}

			if (taskAssignment != null) {
				session.delete(taskAssignment);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (taskAssignment != null) {
			clearCache(taskAssignment);
		}

		return taskAssignment;
	}

	@Override
	public TaskAssignment updateImpl(
		com.jioc.taskmanagement.model.TaskAssignment taskAssignment)
		throws SystemException {
		taskAssignment = toUnwrappedModel(taskAssignment);

		boolean isNew = taskAssignment.isNew();

		TaskAssignmentModelImpl taskAssignmentModelImpl = (TaskAssignmentModelImpl)taskAssignment;

		Session session = null;

		try {
			session = openSession();

			if (taskAssignment.isNew()) {
				session.save(taskAssignment);

				taskAssignment.setNew(false);
			}
			else {
				session.merge(taskAssignment);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !TaskAssignmentModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((taskAssignmentModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNEEUSER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						taskAssignmentModelImpl.getOriginalTaskId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ASSIGNEEUSER,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNEEUSER,
					args);

				args = new Object[] { taskAssignmentModelImpl.getTaskId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ASSIGNEEUSER,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNEEUSER,
					args);
			}

			if ((taskAssignmentModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNTOUSER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						taskAssignmentModelImpl.getOriginalAssignToUserId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ASSIGNTOUSER,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNTOUSER,
					args);

				args = new Object[] { taskAssignmentModelImpl.getAssignToUserId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ASSIGNTOUSER,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNTOUSER,
					args);
			}

			if ((taskAssignmentModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNTOUSERIDANDASSIGNEETASKID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						taskAssignmentModelImpl.getOriginalAssignToUserId(),
						taskAssignmentModelImpl.getOriginalAssigneeTaskId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ASSIGNTOUSERIDANDASSIGNEETASKID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNTOUSERIDANDASSIGNEETASKID,
					args);

				args = new Object[] {
						taskAssignmentModelImpl.getAssignToUserId(),
						taskAssignmentModelImpl.getAssigneeTaskId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ASSIGNTOUSERIDANDASSIGNEETASKID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNTOUSERIDANDASSIGNEETASKID,
					args);
			}

			if ((taskAssignmentModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATUSBYASSIGNEETASKID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						taskAssignmentModelImpl.getOriginalAssigneeTaskId(),
						taskAssignmentModelImpl.getOriginalStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_STATUSBYASSIGNEETASKID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATUSBYASSIGNEETASKID,
					args);

				args = new Object[] {
						taskAssignmentModelImpl.getAssigneeTaskId(),
						taskAssignmentModelImpl.getStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_STATUSBYASSIGNEETASKID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STATUSBYASSIGNEETASKID,
					args);
			}

			if ((taskAssignmentModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNMENTSBYASSIGNEETASKID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						taskAssignmentModelImpl.getOriginalAssigneeTaskId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ASSIGNMENTSBYASSIGNEETASKID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNMENTSBYASSIGNEETASKID,
					args);

				args = new Object[] { taskAssignmentModelImpl.getAssigneeTaskId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ASSIGNMENTSBYASSIGNEETASKID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNMENTSBYASSIGNEETASKID,
					args);
			}

			if ((taskAssignmentModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNMENTSBYTASKIDANDSTATUS.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						taskAssignmentModelImpl.getOriginalTaskId(),
						taskAssignmentModelImpl.getOriginalStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ASSIGNMENTSBYTASKIDANDSTATUS,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNMENTSBYTASKIDANDSTATUS,
					args);

				args = new Object[] {
						taskAssignmentModelImpl.getTaskId(),
						taskAssignmentModelImpl.getStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ASSIGNMENTSBYTASKIDANDSTATUS,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_ASSIGNMENTSBYTASKIDANDSTATUS,
					args);
			}
		}

		EntityCacheUtil.putResult(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
			TaskAssignmentImpl.class, taskAssignment.getPrimaryKey(),
			taskAssignment);

		clearUniqueFindersCache(taskAssignment);
		cacheUniqueFindersCache(taskAssignment);

		return taskAssignment;
	}

	protected TaskAssignment toUnwrappedModel(TaskAssignment taskAssignment) {
		if (taskAssignment instanceof TaskAssignmentImpl) {
			return taskAssignment;
		}

		TaskAssignmentImpl taskAssignmentImpl = new TaskAssignmentImpl();

		taskAssignmentImpl.setNew(taskAssignment.isNew());
		taskAssignmentImpl.setPrimaryKey(taskAssignment.getPrimaryKey());

		taskAssignmentImpl.setTaskAssignmentId(taskAssignment.getTaskAssignmentId());
		taskAssignmentImpl.setTaskId(taskAssignment.getTaskId());
		taskAssignmentImpl.setAssigneeTaskId(taskAssignment.getAssigneeTaskId());
		taskAssignmentImpl.setAssignByUserId(taskAssignment.getAssignByUserId());
		taskAssignmentImpl.setAssignToUserId(taskAssignment.getAssignToUserId());
		taskAssignmentImpl.setStatus(taskAssignment.getStatus());
		taskAssignmentImpl.setFinal_status(taskAssignment.getFinal_status());
		taskAssignmentImpl.setAchieved(taskAssignment.getAchieved());
		taskAssignmentImpl.setModifiedBy(taskAssignment.getModifiedBy());
		taskAssignmentImpl.setCreateDate(taskAssignment.getCreateDate());
		taskAssignmentImpl.setModifiedDate(taskAssignment.getModifiedDate());

		return taskAssignmentImpl;
	}

	/**
	 * Returns the task assignment with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the task assignment
	 * @return the task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment findByPrimaryKey(Serializable primaryKey)
		throws NoSuchTaskAssignmentException, SystemException {
		TaskAssignment taskAssignment = fetchByPrimaryKey(primaryKey);

		if (taskAssignment == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchTaskAssignmentException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return taskAssignment;
	}

	/**
	 * Returns the task assignment with the primary key or throws a {@link com.jioc.taskmanagement.NoSuchTaskAssignmentException} if it could not be found.
	 *
	 * @param taskAssignmentId the primary key of the task assignment
	 * @return the task assignment
	 * @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment findByPrimaryKey(long taskAssignmentId)
		throws NoSuchTaskAssignmentException, SystemException {
		return findByPrimaryKey((Serializable)taskAssignmentId);
	}

	/**
	 * Returns the task assignment with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the task assignment
	 * @return the task assignment, or <code>null</code> if a task assignment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		TaskAssignment taskAssignment = (TaskAssignment)EntityCacheUtil.getResult(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
				TaskAssignmentImpl.class, primaryKey);

		if (taskAssignment == _nullTaskAssignment) {
			return null;
		}

		if (taskAssignment == null) {
			Session session = null;

			try {
				session = openSession();

				taskAssignment = (TaskAssignment)session.get(TaskAssignmentImpl.class,
						primaryKey);

				if (taskAssignment != null) {
					cacheResult(taskAssignment);
				}
				else {
					EntityCacheUtil.putResult(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
						TaskAssignmentImpl.class, primaryKey,
						_nullTaskAssignment);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(TaskAssignmentModelImpl.ENTITY_CACHE_ENABLED,
					TaskAssignmentImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return taskAssignment;
	}

	/**
	 * Returns the task assignment with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param taskAssignmentId the primary key of the task assignment
	 * @return the task assignment, or <code>null</code> if a task assignment with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public TaskAssignment fetchByPrimaryKey(long taskAssignmentId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)taskAssignmentId);
	}

	/**
	 * Returns all the task assignments.
	 *
	 * @return the task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the task assignments.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of task assignments
	 * @param end the upper bound of the range of task assignments (not inclusive)
	 * @return the range of task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the task assignments.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of task assignments
	 * @param end the upper bound of the range of task assignments (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<TaskAssignment> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<TaskAssignment> list = (List<TaskAssignment>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_TASKASSIGNMENT);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_TASKASSIGNMENT;

				if (pagination) {
					sql = sql.concat(TaskAssignmentModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<TaskAssignment>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<TaskAssignment>(list);
				}
				else {
					list = (List<TaskAssignment>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the task assignments from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (TaskAssignment taskAssignment : findAll()) {
			remove(taskAssignment);
		}
	}

	/**
	 * Returns the number of task assignments.
	 *
	 * @return the number of task assignments
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_TASKASSIGNMENT);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Initializes the task assignment persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.jioc.taskmanagement.model.TaskAssignment")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<TaskAssignment>> listenersList = new ArrayList<ModelListener<TaskAssignment>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<TaskAssignment>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(TaskAssignmentImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_TASKASSIGNMENT = "SELECT taskAssignment FROM TaskAssignment taskAssignment";
	private static final String _SQL_SELECT_TASKASSIGNMENT_WHERE = "SELECT taskAssignment FROM TaskAssignment taskAssignment WHERE ";
	private static final String _SQL_COUNT_TASKASSIGNMENT = "SELECT COUNT(taskAssignment) FROM TaskAssignment taskAssignment";
	private static final String _SQL_COUNT_TASKASSIGNMENT_WHERE = "SELECT COUNT(taskAssignment) FROM TaskAssignment taskAssignment WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "taskAssignment.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No TaskAssignment exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No TaskAssignment exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(TaskAssignmentPersistenceImpl.class);
	private static TaskAssignment _nullTaskAssignment = new TaskAssignmentImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<TaskAssignment> toCacheModel() {
				return _nullTaskAssignmentCacheModel;
			}
		};

	private static CacheModel<TaskAssignment> _nullTaskAssignmentCacheModel = new CacheModel<TaskAssignment>() {
			@Override
			public TaskAssignment toEntityModel() {
				return _nullTaskAssignment;
			}
		};
}