/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.taskmanagement.service.impl;

import com.jioc.taskmanagement.NoSuchTaskAssignmentException;
import com.jioc.taskmanagement.model.TaskAssignment;
import com.jioc.taskmanagement.service.base.TaskAssignmentLocalServiceBaseImpl;
import com.jioc.taskmanagement.service.persistence.TaskAssignmentFinderUtil;
import com.liferay.portal.kernel.exception.SystemException;

import java.util.List;

/**
 * The implementation of the task assignment local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jioc.taskmanagement.service.TaskAssignmentLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author rajnikant.donga
 * @see com.jioc.taskmanagement.service.base.TaskAssignmentLocalServiceBaseImpl
 * @see com.jioc.taskmanagement.service.TaskAssignmentLocalServiceUtil
 */
public class TaskAssignmentLocalServiceImpl
	extends TaskAssignmentLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.jioc.taskmanagement.service.TaskAssignmentLocalServiceUtil} to access the task assignment local service.
	 */
	
	public List<TaskAssignment> getAssigneeUserByMe(long taskId){
		
		try {
			return taskAssignmentPersistence.findByAssigneeUser(taskId);
		} catch (SystemException e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	/*public List<TaskAssignment> getAllTaskAssignToMe(long assignToUserId){
		
		try {
			return taskAssignmentPersistence.findByAssignToUser(assignToUserId);
		} catch (SystemException e) {
			e.printStackTrace();
		}
		return null;
		
	}*/
	
	public TaskAssignment getTaskDetailsAssignToMe(long taskId, long assignByUserId){
		
			try {
				return taskAssignmentPersistence.findByTaskDetailAssignToMe(taskId, assignByUserId);
			} catch (NoSuchTaskAssignmentException e) {
				e.printStackTrace();
			} catch (SystemException e) {
				e.printStackTrace();
			}
			return null;
		
		
	}
	
	public TaskAssignment getAvailableAssignee(long taskId, long assignToUserId){
		
		try {
			return taskAssignmentPersistence.findByAvailableAssignee(taskId, assignToUserId);
		} catch (NoSuchTaskAssignmentException e) {
		} catch (SystemException e) {
		}
		return null;
		
	}
	
	
	public List<TaskAssignment> getAllTaskAssignToMeByStatusAndDate(long assignToUserId, String status, String fromDate, String toDate){
		
		return TaskAssignmentFinderUtil.getAllTasksAndAssignUserToMeByStatus(assignToUserId, status, fromDate, toDate);
		
	}
	//create new methods
	
	public List<TaskAssignment> getAssignToUserIdAndAssigneeTaskId(long assignToUserId, long assigneeTaskId) throws SystemException{
			return taskAssignmentPersistence.findByAssignToUserIdAndAssigneeTaskId(assignToUserId, assigneeTaskId);
	}

	public TaskAssignment getByTaskAndAssigneeTaskId(long taskId, long assignToUserId,long assigneeTaskId) throws SystemException, NoSuchTaskAssignmentException{
		return taskAssignmentPersistence.findByTaskAndAssigneeTaskId(taskId, assignToUserId,assigneeTaskId);
	}
	public List<TaskAssignment> getStatusByAssigneeTaskId(long assigneeTaskId, String status) throws SystemException{
		return taskAssignmentPersistence.findByStatusByAssigneeTaskId(assigneeTaskId, status);
	}
	public List<TaskAssignment> getTasksByAssigneetaskId(long assigneeTaskId, String status) throws SystemException{
		return TaskAssignmentFinderUtil.getTasksByAssigneetaskId(assigneeTaskId, status);
	}
	public List<TaskAssignment> getAssignmentsByAssigneetaskId(long assigneeTaskId) throws SystemException{
		return taskAssignmentPersistence.findByAssignmentsByAssigneetaskId(assigneeTaskId);
	}
	public List<TaskAssignment> getAllTaskAssignToMeByStatusWithDate(long assignToUserId, String final_status, String fromDate, String toDate){
		return TaskAssignmentFinderUtil.getAllTasksAssignToMeByStatusWithDate(assignToUserId, final_status, fromDate, toDate);
		
	}
	public List<TaskAssignment> getAllTaskAssignByMeByStatusWithDate(long assignByUserId, String final_status, String fromDate, String toDate){
		return TaskAssignmentFinderUtil.getAllTasksAssignByMeByStatusWithDate(assignByUserId, final_status, fromDate, toDate);
		
	}
	
	public List<TaskAssignment> getAllTasksAssignToMeByStatus(long assignToUserId, String final_status){
		return TaskAssignmentFinderUtil.getAllTaskAssignToMeByStatus(assignToUserId, final_status);
		
	}
	public List<TaskAssignment> getAllTasksAssignByMeByStatus(long assignByUserId, String final_status){
		return TaskAssignmentFinderUtil.getAllTaskAssignByMeByStatus(assignByUserId, final_status);
		
	}
	
	public List<TaskAssignment> getAllTasksAssignToMeWithDate(long assignToUserId, String fromDate, String toDate){
		return TaskAssignmentFinderUtil.getAllTaskAssignToMeWithDate(assignToUserId, fromDate, toDate);
		
	}
	public List<TaskAssignment> getAllTasksAssignByMeWithDate(long assignByUserId, String fromDate, String toDate){
		return TaskAssignmentFinderUtil.getAllTaskAssignByMeWithDate(assignByUserId, fromDate, toDate);
		
	}
	
	public List<TaskAssignment> getAllTaskAssignToMe(long userId){
		return TaskAssignmentFinderUtil.getAllTasksAssignToMe(userId);
		
	}
	public List<TaskAssignment> getAllTasksAssignByMe(long assignByUserId){
		return TaskAssignmentFinderUtil.getAllTaskAssignByMe(assignByUserId);
		
	}
	public List<TaskAssignment> getAssignmentsByTaskIdAndStatus(long taskId, String status) throws SystemException{
		return taskAssignmentPersistence.findByAssignmentsByTaskIdAndStatus(taskId, status);
		
	}
	
	
	
}