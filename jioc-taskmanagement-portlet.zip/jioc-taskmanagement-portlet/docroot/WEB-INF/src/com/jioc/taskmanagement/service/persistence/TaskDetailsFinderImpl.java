package com.jioc.taskmanagement.service.persistence;

import com.jioc.taskmanagement.model.TaskDetails;
import com.jioc.taskmanagement.model.impl.TaskDetailsImpl;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.SQLQuery;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;
import com.liferay.util.dao.orm.CustomSQLUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class TaskDetailsFinderImpl extends BasePersistenceImpl<TaskDetails> implements TaskDetailsFinder {
	
	public List<TaskDetails> getAllTasksAssigneeById(long assigneetaskid){
        
        Session session = null;
        SQLQuery queryObject = null;
        try{
        	
        	session = openSession();
            String sql = CustomSQLUtil.get("com.jioc.taskmanagement.service.persistence.getAllTasksByAssigneetaskId");
            //sql = StringUtil.replace(sql, "[$USER_ID$]", String.valueOf(userId));
            
            queryObject = session.createSQLQuery(sql);
            queryObject.setCacheable(false);
            
            QueryPos qPos = QueryPos.getInstance(queryObject);
            qPos.add(assigneetaskid);
            System.out.println("sql query=="+sql);
            return getTasksByAssigneeTaskIdList((List<Object[]>)QueryUtil.list(queryObject, getDialect(), QueryUtil.ALL_POS, QueryUtil.ALL_POS));
        } finally{
           if(session !=null) {
        	   closeSession(session);
           }
        }
	}
	
	private List<TaskDetails> getTasksByAssigneeTaskIdList(List<Object[]> list) {
	    List<TaskDetails> taskList = new ArrayList<TaskDetails>();
	    TaskDetails taskDetails = null;
	    SimpleDateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
	    //System.out.println("object size"+list.size());
	    for (Object[] object : list) {
	    	taskDetails = new TaskDetailsImpl();
	    	taskDetails.setTaskId(GetterUtil.getLong(object[0]));
	    	taskDetails.setDescription(GetterUtil.getString(object[1]));
	    	taskDetails.setTarget(GetterUtil.getLong(object[2]));
	    	taskDetails.setCreateDate(GetterUtil.getDate(object[3], dateFormat));
	    	taskDetails.setAchieved(GetterUtil.getString(object[4]));
	    	taskDetails.setStatus(GetterUtil.getString(object[5]));
	    	
	    	    	
	        taskList.add(taskDetails);
	        System.out.println("query taskList=="+taskList);
	    }
	    return taskList;
	}

}
