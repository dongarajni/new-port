package com.jioc.taskmanagement.helper;

import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.util.ContentUtil;

public class TaskManagementConstant {

	public static final String Keyword = "keyword";
	public static final String GET_USERS = "get_users";
	public static final String ASSIGN_BY_ME = "assign-by-me";
	public static final String ASSIGN_TO_ME = "assign-to-me";
	public static final String UPLOAD_CSV = "upload-csv";
	public static final String UPLOADED_FILE = ".csv";
	
	public static final String TASKS_INDEXES = "tasksIndexes";
	public static final String DESCRIPTION = "description";
	public static final String TARGET = "target";
	public static final String ACHIEVED = "achieved";
	public static final String MY_INPUT_USER = "myinputUser";
	public static final String IN_PROGRESS = "In Progress";
	public static final String COMPLETE = "Completed";
	public static final String DELETE = "Deleted";
	public static final String IS_SEARCH_TRUE = "TRUE";
	public static final String STATUS_All = "ALL";
	public static final String CAT_TYPE_OC = "OC";
	public static final int OC_STATUS = 0;
	
	public static final String TASK_ASSIGNMENT_BODY_TMPL =  ContentUtil.get("/templates/task_assignment_body.tmpl");
	public static final String TASK_ASSIGNMENT_STATUS_COMPLETE_BODY_TMPL =  ContentUtil.get("/templates/task_assignment_status_complete_body.tmpl");
	public static final String TASK_ASSIGNMENT_SUBJECT_TMPL =  ContentUtil.get("/templates/task_assignment_subject.tmpl");
	public static final String TASK_ASSIGNMENT_STATUS_COMPLETE_SUBJECT_TMPL =  ContentUtil.get("/templates/task_assignment_status_complete_subject.tmpl");
	
	public static final boolean SEND_MAIL_ON = GetterUtil.getBoolean(PropsUtil.get("jioc.task.management.sendemail"), Boolean.TRUE);
	public static final String FROM_MAIL_ID = GetterUtil.getString(PropsUtil.get("sender.email.address"));
	
	public static final String CMD = "cmd1";
	public static final String REGION = "region";
	public static final String CIRCLE = "circle";
	public static final String AREA = "area";
	public static final String JIOCENTER = "jioCenter";
	public static final String JOB = "job";
}
