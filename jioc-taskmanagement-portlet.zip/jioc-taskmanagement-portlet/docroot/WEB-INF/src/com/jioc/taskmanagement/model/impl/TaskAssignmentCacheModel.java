/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.taskmanagement.model.impl;

import com.jioc.taskmanagement.model.TaskAssignment;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing TaskAssignment in entity cache.
 *
 * @author rajnikant.donga
 * @see TaskAssignment
 * @generated
 */
public class TaskAssignmentCacheModel implements CacheModel<TaskAssignment>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(23);

		sb.append("{taskAssignmentId=");
		sb.append(taskAssignmentId);
		sb.append(", taskId=");
		sb.append(taskId);
		sb.append(", assigneeTaskId=");
		sb.append(assigneeTaskId);
		sb.append(", assignByUserId=");
		sb.append(assignByUserId);
		sb.append(", assignToUserId=");
		sb.append(assignToUserId);
		sb.append(", status=");
		sb.append(status);
		sb.append(", final_status=");
		sb.append(final_status);
		sb.append(", achieved=");
		sb.append(achieved);
		sb.append(", modifiedBy=");
		sb.append(modifiedBy);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", modifiedDate=");
		sb.append(modifiedDate);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public TaskAssignment toEntityModel() {
		TaskAssignmentImpl taskAssignmentImpl = new TaskAssignmentImpl();

		taskAssignmentImpl.setTaskAssignmentId(taskAssignmentId);
		taskAssignmentImpl.setTaskId(taskId);
		taskAssignmentImpl.setAssigneeTaskId(assigneeTaskId);
		taskAssignmentImpl.setAssignByUserId(assignByUserId);
		taskAssignmentImpl.setAssignToUserId(assignToUserId);

		if (status == null) {
			taskAssignmentImpl.setStatus(StringPool.BLANK);
		}
		else {
			taskAssignmentImpl.setStatus(status);
		}

		if (final_status == null) {
			taskAssignmentImpl.setFinal_status(StringPool.BLANK);
		}
		else {
			taskAssignmentImpl.setFinal_status(final_status);
		}

		if (achieved == null) {
			taskAssignmentImpl.setAchieved(StringPool.BLANK);
		}
		else {
			taskAssignmentImpl.setAchieved(achieved);
		}

		taskAssignmentImpl.setModifiedBy(modifiedBy);

		if (createDate == Long.MIN_VALUE) {
			taskAssignmentImpl.setCreateDate(null);
		}
		else {
			taskAssignmentImpl.setCreateDate(new Date(createDate));
		}

		if (modifiedDate == Long.MIN_VALUE) {
			taskAssignmentImpl.setModifiedDate(null);
		}
		else {
			taskAssignmentImpl.setModifiedDate(new Date(modifiedDate));
		}

		taskAssignmentImpl.resetOriginalValues();

		return taskAssignmentImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		taskAssignmentId = objectInput.readLong();
		taskId = objectInput.readLong();
		assigneeTaskId = objectInput.readLong();
		assignByUserId = objectInput.readLong();
		assignToUserId = objectInput.readLong();
		status = objectInput.readUTF();
		final_status = objectInput.readUTF();
		achieved = objectInput.readUTF();
		modifiedBy = objectInput.readLong();
		createDate = objectInput.readLong();
		modifiedDate = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(taskAssignmentId);
		objectOutput.writeLong(taskId);
		objectOutput.writeLong(assigneeTaskId);
		objectOutput.writeLong(assignByUserId);
		objectOutput.writeLong(assignToUserId);

		if (status == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(status);
		}

		if (final_status == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(final_status);
		}

		if (achieved == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(achieved);
		}

		objectOutput.writeLong(modifiedBy);
		objectOutput.writeLong(createDate);
		objectOutput.writeLong(modifiedDate);
	}

	public long taskAssignmentId;
	public long taskId;
	public long assigneeTaskId;
	public long assignByUserId;
	public long assignToUserId;
	public String status;
	public String final_status;
	public String achieved;
	public long modifiedBy;
	public long createDate;
	public long modifiedDate;
}