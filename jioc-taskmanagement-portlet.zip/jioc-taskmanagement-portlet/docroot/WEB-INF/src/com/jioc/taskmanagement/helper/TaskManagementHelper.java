package com.jioc.taskmanagement.helper;

import com.jio.taskmanagement.util.JioTaskManagementUtil;
import com.jioc.query.model.EMP_DETAILS;
import com.jioc.query.service.EMP_DETAILSLocalServiceUtil;
import com.jioc.taskmanagement.model.TaskAssignment;
import com.jioc.taskmanagement.model.TaskDetails;
import com.jioc.taskmanagement.service.TaskAssignmentLocalServiceUtil;
import com.jioc.taskmanagement.service.TaskDetailsLocalServiceUtil;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.ListUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.model.UserModel;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.PortletURLUtil;
import com.liferay.portlet.asset.service.AssetTagLocalServiceUtil;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

public class TaskManagementHelper {
	private static Log _log = LogFactoryUtil.getLog(TaskManagementHelper.class);
	
	public static void getSearchAssigneeDetails(RenderRequest request,RenderResponse response){
		List<Object[]> regions = EMP_DETAILSLocalServiceUtil.getDistinctJoRegion();
		regions.removeAll(Arrays.asList(null,""));
		request.setAttribute("regions", regions);
					
		List<Object[]> job = EMP_DETAILSLocalServiceUtil.getDistinctJob();
		job.removeAll(Arrays.asList(null,""));
		request.setAttribute("jobs", job);
		
	}
	
	public static void assignByMeSearchContainer(RenderRequest request,RenderResponse response){
		
		_log.info("call display SearchContainer");
		ThemeDisplay themeDisplay = (ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
		
		List<TaskAssignment> taskAssignByMe = null;
		DateFormat dateFormate=new SimpleDateFormat("yyyy-MM-dd");
		DateFormat df=new SimpleDateFormat("dd-MMM-yyyy");
		String status = ParamUtil.getString(request, "status");
		//_log.info("status==="+status);
		String isSearch = ParamUtil.getString(request, "isSearch");
		//_log.info("isSearch==="+isSearch);
		String fromdates = ParamUtil.getString(request, "dateFrom");
		String dateTo = ParamUtil.getString(request, "dateTo");
		Date fromdate = null;
		Date todate = null;
		String fromDate = null;
		String toDate = null;
		if(Validator.isNotNull(fromdates)){
			try {
				 fromdate = dateFormate.parse(fromdates);
				 todate = dateFormate.parse(dateTo);
				
			} catch (ParseException e) {
				e.printStackTrace();
			}
			fromDate = df.format(fromdate);
			toDate = df.format(todate);
		}
		
		if(Validator.isNotNull(isSearch) && TaskManagementConstant.IS_SEARCH_TRUE.equalsIgnoreCase(isSearch)){
			if(Validator.isNotNull(fromDate) || Validator.isNotNull(toDate)){
				if(status.equalsIgnoreCase(TaskManagementConstant.STATUS_All)){
					taskAssignByMe = TaskAssignmentLocalServiceUtil.getAllTasksAssignByMeWithDate(themeDisplay.getUserId(), fromDate, toDate);
				}else{
					taskAssignByMe = TaskAssignmentLocalServiceUtil.getAllTaskAssignByMeByStatusWithDate(themeDisplay.getUserId(), status, fromDate, toDate);
				}
			}else {
				if(status.equalsIgnoreCase(TaskManagementConstant.STATUS_All)){
					taskAssignByMe = TaskAssignmentLocalServiceUtil.getAllTasksAssignByMe(themeDisplay.getUserId());
				}else{
					taskAssignByMe = TaskAssignmentLocalServiceUtil.getAllTasksAssignByMeByStatus(themeDisplay.getUserId(), status);
				}
			}
		}else{
			taskAssignByMe = TaskAssignmentLocalServiceUtil.getAllTasksAssignByMeByStatus(themeDisplay.getUserId(), TaskManagementConstant.IN_PROGRESS);
		}
		
		for (TaskAssignment taskAssignment : taskAssignByMe) {
			
			EMP_DETAILS empDetails = EMP_DETAILSLocalServiceUtil.getEmpDetailsByUserId(taskAssignment.getAssignToUserId());
			taskAssignment.setEmployeeFullName(empDetails.getFULL_NAME());
			try {
			List<TaskAssignment> taskAssignments = TaskAssignmentLocalServiceUtil.getStatusByAssigneeTaskId(taskAssignment.getAssigneeTaskId(), TaskManagementConstant.COMPLETE);
			if(taskAssignments.size() > 0){
				taskAssignment.setStatus(TaskManagementConstant.COMPLETE);
			}
			} catch (SystemException e) {
				_log.error("error while getting taskAssignment by complete status");
			}
		}
		
		PortletURL iteratorURL = response.createRenderURL();
		iteratorURL.setParameter("flag", "assign-by-me");
		iteratorURL.setParameter("jspPage", "/html/taskmanagement/task-assign-by-me.jsp");
        //iteratorURL = PortletURLUtil.getCurrent(request, response);
        SearchContainer<TaskAssignment> searchContainer = new SearchContainer<TaskAssignment>(request, null, null, SearchContainer.DEFAULT_CUR_PARAM, SearchContainer.DEFAULT_DELTA, iteratorURL, null, "there-are-no-records");
        searchContainer.setDeltaConfigurable(true);
		searchContainer.setTotal(taskAssignByMe.size());
		List<TaskAssignment> subList = ListUtil.subList(taskAssignByMe, searchContainer.getStart(), searchContainer.getEnd()); 
		searchContainer.setResults(subList);
        
        request.setAttribute("assignByMeSearchContainer", searchContainer);
	}
	
	public static void assignToMeSearchContainer(RenderRequest request,RenderResponse response){
		
		_log.info("call display assignToMe SearchContainer");
		
		ThemeDisplay themeDisplay = (ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
		// start search by status
		List<TaskAssignment> taskAssignToMe = null;
		DateFormat dateFormate=new SimpleDateFormat("yyyy-MM-dd");
		DateFormat df=new SimpleDateFormat("dd-MMM-yyyy");
		String status = ParamUtil.getString(request, "status");
		//_log.info("status==="+status);
		String isSearch = ParamUtil.getString(request, "isSearch");
		//_log.info("isSearch==="+isSearch);
		String fromdates = ParamUtil.getString(request, "dateFrom");
		
		String dateTo = ParamUtil.getString(request, "dateTo");
		Date fromdate = null;
		Date todate = null;
		String fromDate = null;
		String toDate = null;
		if(Validator.isNotNull(fromdates)){
			try {
				 fromdate = dateFormate.parse(fromdates);
				 todate = dateFormate.parse(dateTo);
				
			} catch (ParseException e) {
				e.printStackTrace();
			}
			fromDate = df.format(fromdate);
			toDate = df.format(todate);
		}
		
		if(Validator.isNotNull(isSearch) && TaskManagementConstant.IS_SEARCH_TRUE.equalsIgnoreCase(isSearch)){
			
			if(Validator.isNotNull(fromDate) || Validator.isNotNull(toDate)){
				if(status.equalsIgnoreCase(TaskManagementConstant.STATUS_All)){
					taskAssignToMe = TaskAssignmentLocalServiceUtil.getAllTasksAssignToMeWithDate(themeDisplay.getUserId(), fromDate, toDate);
				}else{
					taskAssignToMe = TaskAssignmentLocalServiceUtil.getAllTaskAssignToMeByStatusWithDate(themeDisplay.getUserId(), status, fromDate, toDate);
				}
			}else {
				if(status.equalsIgnoreCase(TaskManagementConstant.STATUS_All)){
					taskAssignToMe = TaskAssignmentLocalServiceUtil.getAllTaskAssignToMe(themeDisplay.getUserId());
				}else{
					taskAssignToMe = TaskAssignmentLocalServiceUtil.getAllTasksAssignToMeByStatus(themeDisplay.getUserId(), status);
				}
				
			}
		}else{
			taskAssignToMe = TaskAssignmentLocalServiceUtil.getAllTasksAssignToMeByStatus(themeDisplay.getUserId(), TaskManagementConstant.IN_PROGRESS);
		}
			
		//End 
		
		for (TaskAssignment taskAssignment : taskAssignToMe) {
							
			EMP_DETAILS empDetails = EMP_DETAILSLocalServiceUtil.getEmpDetailsByUserId(taskAssignment.getAssignByUserId());
			taskAssignment.setEmployeeFullName(empDetails.getFULL_NAME());
			
		}
		PortletURL iteratorURL = response.createRenderURL();
		iteratorURL.setParameter("flag", "assign-to-me");
		iteratorURL.setParameter("jspPage", "/html/taskmanagement/task-assign-to-me.jsp");
        //iteratorURL = PortletURLUtil.getCurrent(request, response);
        SearchContainer<TaskAssignment> searchContainer = new SearchContainer<TaskAssignment>(request, null, null, SearchContainer.DEFAULT_CUR_PARAM, SearchContainer.DEFAULT_DELTA, iteratorURL, null, "there-are-no-records");
        searchContainer.setDeltaConfigurable(true);
		searchContainer.setTotal(taskAssignToMe.size());
		List<TaskAssignment> subList = ListUtil.subList(taskAssignToMe, searchContainer.getStart(), searchContainer.getEnd());
		searchContainer.setResults(subList);
        
        request.setAttribute("assignToMeSearchContainer", searchContainer);
	}
	
	public static void displayEditTaskRender(RenderRequest request,RenderResponse response){
		
		ThemeDisplay themeDisplay = (ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
		String url = themeDisplay.getURLPortal()+
					 themeDisplay.getPathFriendlyURLPrivateGroup()+
					 themeDisplay.getScopeGroup().getFriendlyURL()+
					 themeDisplay.getLayout().getFriendlyURL()+
					 StringPool.QUESTION+"flag=assign-by-me";
		request.setAttribute("assignbymeurl", url);
		
		long assigneeTaskId = ParamUtil.getLong(request, "assigneeTaskId");
		//_log.info("AssigneeTask Id==="+assigneeTaskId);
		request.setAttribute("assigneeTaskId", assigneeTaskId);
		
		long assignToUserId = ParamUtil.getLong(request, "assignToUserId");
        request.setAttribute("assignToUserId", assignToUserId);
        
        String finalStatus = ParamUtil.getString(request, "finalStatus");
        request.setAttribute("finalStatus", finalStatus);
        
    	if(assignToUserId > 0){
    		EMP_DETAILS empDetails = EMP_DETAILSLocalServiceUtil.getEmpDetailsByUserId(assignToUserId);
    		request.setAttribute("assineeUserName", empDetails.getFULL_NAME());
    	}
        
		List<TaskDetails> tasksDetail = TaskDetailsLocalServiceUtil.getAllTaskAssigneeByTaskId(assigneeTaskId);
		for (TaskDetails taskDetails : tasksDetail) {
			try {
				List<TaskAssignment> taskAssignment =TaskAssignmentLocalServiceUtil.getAssignmentsByTaskIdAndStatus(taskDetails.getTaskId(), TaskManagementConstant.COMPLETE);
				if(taskAssignment.size() > 0){
					taskDetails.setTaskDetails_Status(TaskManagementConstant.COMPLETE);
					request.setAttribute("changeAssigneeStatus", Boolean.TRUE);
				}
			} catch (SystemException e) {
				_log.error("error while getting taskAssignmnet");
			}
			Date createDate = taskDetails.getCreateDate();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
			
			request.setAttribute("createDate", sdf.format(createDate));
		}
		request.setAttribute("assigneeTaskIds", tasksDetail);
	}
	
	public static void displayTaskDetailsRender(RenderRequest request,RenderResponse response){
		
		ThemeDisplay themeDisplay = (ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
		
		String url = themeDisplay.getURLPortal()+
					 themeDisplay.getPathFriendlyURLPrivateGroup()+
					 themeDisplay.getScopeGroup().getFriendlyURL()+
					 themeDisplay.getLayout().getFriendlyURL()+
					 StringPool.QUESTION+"flag=assign-to-me";
		request.setAttribute("assigntomeurl", url);
		
		long assigneeTaskId = ParamUtil.getLong(request, "assigneeTaskId",0);
        
		taskInProgressStatus(request, response, assigneeTaskId);
		taskCompleteStatus(request, response, assigneeTaskId);
		
	}
	
	private static void taskCompleteStatus(RenderRequest request,RenderResponse response, long assigneeTaskId) {
		
		List<TaskAssignment> taskassignment = null;
		try {
			taskassignment = TaskAssignmentLocalServiceUtil.getTasksByAssigneetaskId(assigneeTaskId, TaskManagementConstant.COMPLETE);
		} catch (SystemException e) {
			e.printStackTrace();
		}
		
		PortletURL iteratorURL = response.createRenderURL();
        iteratorURL = PortletURLUtil.getCurrent(request, response);
        SearchContainer<TaskAssignment> searchContainer = new SearchContainer<TaskAssignment>(request, null, null, SearchContainer.DEFAULT_CUR_PARAM, SearchContainer.DEFAULT_DELTA, iteratorURL, null, "there-are-no-records");
        searchContainer.setDeltaConfigurable(true);
		searchContainer.setTotal(taskassignment.size());
		List<TaskAssignment> subList = ListUtil.subList(taskassignment, searchContainer.getStart(), searchContainer.getEnd());
		searchContainer.setResults(subList);
        
        request.setAttribute("TasksCompleteSearchContainer", searchContainer);
	}

	private static void taskInProgressStatus(RenderRequest request,RenderResponse response, long assigneeTaskId) {
		
		List<TaskAssignment> taskassignment = null;
		try {
			taskassignment = TaskAssignmentLocalServiceUtil.getTasksByAssigneetaskId(assigneeTaskId, TaskManagementConstant.IN_PROGRESS);
			
			request.setAttribute("taskassignmentsize", taskassignment.size());
			for (TaskAssignment tasks : taskassignment) {
				//System.out.println("assigneetaskId====="+tasks.getAssigneeTaskId());
				request.setAttribute("assigneetaskid", tasks.getAssigneeTaskId());
			}
		} catch (SystemException e) {
			e.printStackTrace();
		}
		
		PortletURL iteratorURL = response.createRenderURL();
        iteratorURL = PortletURLUtil.getCurrent(request, response);
        SearchContainer<TaskAssignment> searchContainer = new SearchContainer<TaskAssignment>(request, null, null, SearchContainer.DEFAULT_CUR_PARAM, SearchContainer.DEFAULT_DELTA, iteratorURL, null, "there-are-no-records");
        searchContainer.setDeltaConfigurable(true);
		searchContainer.setTotal(taskassignment.size());
		List<TaskAssignment> subList = ListUtil.subList(taskassignment, searchContainer.getStart(), searchContainer.getEnd());
		searchContainer.setResults(subList);
        
        request.setAttribute("TasksInProgressSearchContainer", searchContainer);
		
	}

	public static void addTaskManagement(ActionRequest actionRequest, ActionResponse actionResponse) throws SystemException{
		
        String tasksIndexesString = actionRequest.getParameter(TaskManagementConstant.TASKS_INDEXES);
       
        long assigneeTaskId = ParamUtil.getLong(actionRequest, "assigneeTaskId",0);
        String cmd = ParamUtil.getString(actionRequest, "cmd");
        
        
        TaskDetails taskDetails = null;
        int[] tasksIndexes = StringUtil.split(tasksIndexesString, 0);
        List<Long> taskIds = new ArrayList<Long>();
        List<TaskDetails> taskDetailsList = new ArrayList<TaskDetails>();
        for (int tasksIndex : tasksIndexes) {
        	//System.out.println("tasksIndex=="+tasksIndex);
        	taskDetails = addUpdateTask(tasksIndex,actionRequest);
            taskIds.add(taskDetails.getTaskId());
            taskDetailsList.add(taskDetails);
        }
        
		if(Validator.isNotNull(taskDetails)){
        	if(assigneeTaskId > 0){
        		long updateUserId = ParamUtil.getLong(actionRequest, "updateUserId");
        		long assignToUserId = ParamUtil.getLong(actionRequest, "assignToUserId");
        		if(updateUserId > 0){
        			updateTaskAssignment(actionRequest, assigneeTaskId, updateUserId);
        			actionResponse.setRenderParameter("assignToUserId", String.valueOf(updateUserId));
        		}else{
        			actionResponse.setRenderParameter("assignToUserId", String.valueOf(assignToUserId));
        		}
        		
        		if(TaskManagementConstant.SEND_MAIL_ON){
        			if(updateUserId == 0){
        				updateUserId = assignToUserId;
        			}
        			User user = null;
 				   	try {
 				   		user = UserLocalServiceUtil.getUser(updateUserId);
 				   	} catch (PortalException e) {
 				   		_log.error("error while getting add assignee user");
 				   	}
 				   	String subject=TaskManagementConstant.TASK_ASSIGNMENT_SUBJECT_TMPL;
 				   	String body=TaskManagementConstant.TASK_ASSIGNMENT_BODY_TMPL;
 				   	JioTaskManagementUtil.sendMailTaskAssignment(TaskManagementConstant.FROM_MAIL_ID,user.getEmailAddress() , subject, body, user.getFullName(), assigneeTaskId, taskDetailsList);
        		}
        		SessionMessages.add(actionRequest, "task-updated-successfully");
        	}else{
        		String inputUser = ParamUtil.getString(actionRequest, TaskManagementConstant.MY_INPUT_USER);
        		//System.out.println("inputUser=="+inputUser);
        		JSONArray jsonArray;
        		try {
        			jsonArray = JSONFactoryUtil.createJSONArray(inputUser);
        			
        			for(int i=0; i<jsonArray.length(); i++) {
    				   JSONObject item = jsonArray.getJSONObject(i);
    				   String id = item.getString("Id");
    				   long userId = Long.parseLong(id);
    				   
    				   long assigneetaskId=CounterLocalServiceUtil.increment(TaskAssignment.class.getName());
    				   for (Long tId : taskIds) {
    					   addTaskAssignment(tId, actionRequest, userId,assigneetaskId);
    				   }
    				   
    				   if(TaskManagementConstant.SEND_MAIL_ON){
    					   User user = null;
        				   try {
        					   user = UserLocalServiceUtil.getUser(userId);
        				   } catch (PortalException e) {
        					  _log.error("error while getting add assignee user");
        				   }
    					   String subject=TaskManagementConstant.TASK_ASSIGNMENT_SUBJECT_TMPL;
        				   String body=TaskManagementConstant.TASK_ASSIGNMENT_BODY_TMPL;
        				  _log.info("Sender mail=="+TaskManagementConstant.FROM_MAIL_ID);
        				   JioTaskManagementUtil.sendMailTaskAssignment(TaskManagementConstant.FROM_MAIL_ID,user.getEmailAddress() , subject, body, user.getFullName(), assigneetaskId, taskDetailsList);
    				   }
    				   
        			}
        			SessionMessages.add(actionRequest, "task-added-successfully");
        		} catch (JSONException e) {
        			_log.info("Exception occured while create task assignment json");
        		}
        	}
        }
		
		if(assigneeTaskId != 0){
			actionResponse.setRenderParameter("assigneeTaskId", String.valueOf(assigneeTaskId));
			actionResponse.setRenderParameter("cmd", cmd);
		}
		
		
	}
	
	private static TaskDetails addUpdateTask(long tasksIndex, ActionRequest actionRequest) {
		String description = ParamUtil.getString(actionRequest, TaskManagementConstant.DESCRIPTION + tasksIndex);
        long target = ParamUtil.getLong(actionRequest, TaskManagementConstant.TARGET + tasksIndex);
        long taskId = ParamUtil.getLong(actionRequest, "taskDetailsId" + tasksIndex);
        
		ThemeDisplay themeDisplay = (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		TaskDetails taskDetails= null;
		
			try {
				taskDetails = TaskDetailsLocalServiceUtil.getTaskDetails(taskId);
			} catch (PortalException e1) {
				_log.info("Exception occured while getting task details");
			} catch (SystemException e1) {
				_log.info("Exception occured while getting task details");
			}
		 
		
		if(Validator.isNull(taskDetails)){
			try {
				taskDetails = TaskDetailsLocalServiceUtil.createTaskDetails(CounterLocalServiceUtil.increment(TaskDetails.class.getName()));
				taskDetails.setCreateDate(new Date());
			} catch (SystemException e) {
				_log.info("Exception occured while increment task details id");
			}
		}
		taskDetails.setDescription(description);
		taskDetails.setTarget(target);
		taskDetails.setModifiedBy(themeDisplay.getUserId());
		taskDetails.setModifiedDate(new Date());
		
		try {
			taskDetails = TaskDetailsLocalServiceUtil.updateTaskDetails(taskDetails);
		} catch (SystemException e) {
			_log.info("Exception occured while updating task details");
		}
		
		return taskDetails;
	}

	
	private static TaskAssignment addTaskAssignment(long taskId, ActionRequest actionRequest, long assignToUserId, long assigneeTaskId){
		_log.info("========== Add Task Assignment ============");
		ThemeDisplay themeDisplay = (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		TaskAssignment taskAssignment = null;
		try {
			taskAssignment = TaskAssignmentLocalServiceUtil.createTaskAssignment(CounterLocalServiceUtil.increment(TaskAssignment.class.getName()));
			taskAssignment.setTaskId(taskId);
			taskAssignment.setAssigneeTaskId(assigneeTaskId);
			taskAssignment.setAssignByUserId(themeDisplay.getUserId());
			taskAssignment.setAssignToUserId(assignToUserId);
			taskAssignment.setStatus(TaskManagementConstant.IN_PROGRESS);
			taskAssignment.setFinal_status(TaskManagementConstant.IN_PROGRESS);
			taskAssignment.setModifiedBy(themeDisplay.getUserId());
			taskAssignment.setModifiedDate(new Date());
			taskAssignment.setCreateDate(new Date());
			
			TaskAssignmentLocalServiceUtil.addTaskAssignment(taskAssignment);
			
		} catch (SystemException e) {
			_log.info("Exception occured while add task assignment");
		}
		
		return taskAssignment;
		
	}
	
	private static void updateTaskAssignment(ActionRequest actionRequest, long assigneeTaskId, long assignToUserId){
		
		try {
			List<TaskAssignment> taskAssignments =TaskAssignmentLocalServiceUtil.getAssignmentsByAssigneetaskId(assigneeTaskId);
			for (TaskAssignment taskAssignment : taskAssignments) {
				taskAssignment.setAssignToUserId(assignToUserId);
				TaskAssignmentLocalServiceUtil.updateTaskAssignment(taskAssignment);
			}
		} catch (SystemException e) {
			_log.error("error occurred while getting task assignment");
		}
		
	}
	
	public static void UploadTasksbyCSV(ActionRequest actionRequest, ActionResponse actionResponse) {
		ThemeDisplay themeDisplay = (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		String cmd = ParamUtil.getString(actionRequest, "cmd");
		UploadRequest request = PortalUtil.getUploadPortletRequest(actionRequest);
        File file = request.getFile("fileName");
        Set<String> failure = new HashSet<String>();
        
        if(isCSVFile(file)){
        	
            FileReader fileReader = null;
            CSVParser csvFileParser = null;
            
            try {
            	CSVFormat csvFileFormat = CSVFormat.DEFAULT.withHeader().withDelimiter(',');
                  
    			fileReader = new FileReader(file);
    			csvFileParser = new CSVParser(fileReader, csvFileFormat);
                //List<CSVRecord> records = new ArrayList<CSVRecord>();     
                List<CSVRecord> csvRecords = csvFileParser.getRecords();
                String prevEmail = StringPool.BLANK;
                long prevAssigneeTaskId= 0;
                for (int i = 0; i < csvRecords.size(); i++) {
                	CSVRecord record = csvRecords.get(i);
                	String email = record.get("Email");
                	String kpi = record.get("KPI");
                	
                	try{
                		long target = Long.valueOf(record.get("Target"));
                		User user = null;
	                	long userId = 0;
	                	try {
	    					user = UserLocalServiceUtil.getUserByEmailAddress(themeDisplay.getCompanyId(), email);
	    					userId= user.getUserId();
	    					_log.info("userId==="+userId);
	    				} catch (PortalException e) {
	    					_log.error("error occurred while getting user by email");
	    				} catch (SystemException e) {
	    					_log.error("error occurred while getting user by email");
	    				}
                	
                	if(userId > 0 && Validator.isNotNull(kpi) && kpi.length() <=1000){
            			TaskDetails taskDetails =addTasks(actionRequest, kpi, target);
            			long assigneetaskId = 0;
            			if(email.equalsIgnoreCase(prevEmail)){
                			assigneetaskId = prevAssigneeTaskId;
                			//taskDetailsList.add(taskDetails);
                		}else{
                			try {
        						assigneetaskId=CounterLocalServiceUtil.increment(TaskAssignment.class.getName());
        						//prevAssigneeTaskId = assigneetaskId;
        					} catch (SystemException e) {
        						_log.error("error occurred while increment assigneetaskId");
        					}
                		}
            			addTaskAssignment(taskDetails.getTaskId(), actionRequest, userId, assigneetaskId);
                		/*if(prevAssigneeTaskId == 0){
                			addTaskAssignment(taskDetails.getTaskId(), actionRequest, userId, assigneetaskId);
                		}else{
                			addTaskAssignment(taskDetails.getTaskId(), actionRequest, userId, prevAssigneeTaskId);
                		}*/
                		
	                	
                		if(TaskManagementConstant.SEND_MAIL_ON && !prevEmail.equalsIgnoreCase(email) && Validator.isNotNull(prevEmail)){
                			sendMail(themeDisplay, prevEmail, prevAssigneeTaskId);
     				    }
                		if(!email.equalsIgnoreCase(prevEmail)){
                			prevEmail = email;
                			prevAssigneeTaskId = assigneetaskId;
                		}
                	}else{
                		failure.add(email);
                	}
                	}catch(NumberFormatException e){
                		failure.add(email);
                		_log.error("Error occurred while adding record of email id ::> "+email);
                	}
                	
                }
                if(TaskManagementConstant.SEND_MAIL_ON && Validator.isNotNull(prevEmail)){
        			sendMail(themeDisplay, prevEmail, prevAssigneeTaskId);
				}
            }catch (FileNotFoundException e) {
            	_log.error("Error occurred during fileReader");
    		}catch (IOException e) {
    			_log.error("Error occurred during fileReader");
    		}catch(IllegalArgumentException argEx) {
    			_log.error("Error ocured during reading csv ",argEx);
                SessionErrors.add(actionRequest, "invalid-csv");
    		} catch(IllegalStateException se) {
    			_log.error("Error ocured during reading csv ",se);
                SessionErrors.add(actionRequest, "invalid-csv");
    		} catch(NoSuchElementException nsex){
    			_log.error("Error occured during reading csv ",nsex);
                SessionErrors.add(actionRequest, "invalid-csv");
    		}
            finally {
    			try {
    				if(fileReader !=null){
    					fileReader.close();
    				}
                    if(csvFileParser !=null){
                    	csvFileParser.close();
                    }
    			} catch (IOException e) {
    				_log.error("Error occurred during closing stream");
                }
    			_log.info(" =============================== FAILURE ==================================");
    			_log.info("Failure Count : "+failure.size());
                for (String f : failure) {
                	_log.info(f);
                }
                _log.info("Failure Count : "+failure.size());
            }
        }else{
        	SessionErrors.add(actionRequest,"csv-import-error");
        }

        String failedemails = StringUtil.merge(failure);
        actionResponse.setRenderParameter("failedEmails",failedemails);
        //actionRequest.setAttribute("errorRecordList", records);
        
        actionResponse.setRenderParameter("cmd", cmd);
        SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
	}
	
	private static void sendMail(ThemeDisplay themeDisplay, String prevEmail, long prevAssigneeTaskId) {
		User users=null;
		List<TaskAssignment> taskAssignmnets = null;
		List<TaskDetails> taskDetailsList = new ArrayList<TaskDetails>();
    	try {
			users =UserLocalServiceUtil.getUserByEmailAddress(themeDisplay.getCompanyId(), prevEmail);
			taskAssignmnets = TaskAssignmentLocalServiceUtil.getAssignmentsByAssigneetaskId(prevAssigneeTaskId);
			for (TaskAssignment taskAssignmnet : taskAssignmnets) {
				taskDetailsList.add(TaskDetailsLocalServiceUtil.getTaskDetails(taskAssignmnet.getTaskId()));
			}
		} catch (PortalException e) {
			_log.info("Exception occured while getting user");
		} catch (SystemException e) {
			_log.info("Exception occured while getting user");
		}
    	
		   String subject=TaskManagementConstant.TASK_ASSIGNMENT_SUBJECT_TMPL;
		   String body=TaskManagementConstant.TASK_ASSIGNMENT_BODY_TMPL;
		  _log.info("Sender mail=="+TaskManagementConstant.FROM_MAIL_ID);
		   JioTaskManagementUtil.sendMailTaskAssignment(TaskManagementConstant.FROM_MAIL_ID,users.getEmailAddress() , subject, body, users.getFullName(), prevAssigneeTaskId, taskDetailsList);
	}

	public static boolean isCSVFile(File file) {
        if(TaskManagementConstant.UPLOADED_FILE.equals(getFileExtension(file))){
               return true;
        }else{
               return false;
        }
	}

	public static String getFileExtension(File file) {
        String name = file.getName();
	     try {
	         return name.substring(name.lastIndexOf("."));
	     } catch (Exception e) {
	         return StringPool.BLANK;
	     }
	 }


	private static TaskDetails addTasks(ActionRequest actionRequest, String description, long target) {
		
		ThemeDisplay themeDisplay = (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		TaskDetails taskDetails= null;
		try {
			taskDetails = TaskDetailsLocalServiceUtil.createTaskDetails(CounterLocalServiceUtil.increment(TaskDetails.class.getName()));
			taskDetails.setDescription(description);
			taskDetails.setTarget(target);
			taskDetails.setModifiedBy(themeDisplay.getUserId());
			taskDetails.setCreateDate(new Date());
			taskDetails.setModifiedDate(new Date());
			
			TaskDetailsLocalServiceUtil.addTaskDetails(taskDetails);
		} catch (SystemException e) {
			_log.error("error occured for add task by csv");
		}
		
		return taskDetails;
		
	}
	
	
	
}
