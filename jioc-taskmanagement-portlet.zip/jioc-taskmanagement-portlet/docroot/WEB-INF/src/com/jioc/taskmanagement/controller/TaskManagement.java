package com.jioc.taskmanagement.controller;

import com.jio.taskmanagement.util.JioTaskManagementUtil;
import com.jioc.query.model.EMP_DETAILS;
import com.jioc.query.service.EMP_DETAILSLocalServiceUtil;
import com.jioc.taskmanagement.NoSuchTaskOcDetailsException;
import com.jioc.taskmanagement.helper.TaskManagementConstant;
import com.jioc.taskmanagement.helper.TaskManagementHelper;
import com.jioc.taskmanagement.model.TaskAssignment;
import com.jioc.taskmanagement.model.TaskOcDetails;
import com.jioc.taskmanagement.service.TaskAssignmentLocalServiceUtil;
import com.jioc.taskmanagement.service.TaskOcDetailsLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.servlet.http.HttpServletRequest;


/**
 * Portlet implementation class TaskManagement
 */
public class TaskManagement extends MVCPortlet {
	private static Log _log = LogFactoryUtil.getLog(TaskManagement.class);
	
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws PortletException, IOException {
		
		
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		HttpServletRequest httpReq = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(renderRequest)); 
		String flag = httpReq.getParameter("flag");
		if(Validator.isNull(flag)){
			String renderFlag=ParamUtil.getString(renderRequest, "flag");
			flag=renderFlag;
		}
		String cmd = ParamUtil.getString(renderRequest, "cmd");
		//_log.info("Flag==="+flag);
		EMP_DETAILS empDetails = EMP_DETAILSLocalServiceUtil.getEmpDetailsByUserId(themeDisplay.getUserId());
		
		if(Validator.isNotNull(empDetails)){
			TaskOcDetails ocDetail = null;
			try {
				ocDetail = TaskOcDetailsLocalServiceUtil.getStatusbyOcAndCatType(empDetails.getDEPARTMENT(), TaskManagementConstant.OC_STATUS, TaskManagementConstant.CAT_TYPE_OC);
			} catch (NoSuchTaskOcDetailsException e) {
				_log.error("error occured while getting ocDetails");
			} catch (SystemException e) {
				_log.error("error occured while getting ocDetails");
			}
			if(Validator.isNotNull(ocDetail)){
				if(Validator.isNotNull(flag)){
					if(flag.equalsIgnoreCase(TaskManagementConstant.ASSIGN_BY_ME)){
						viewTemplate ="/html/taskmanagement/task-assign-by-me.jsp";
						TaskManagementHelper.assignByMeSearchContainer(renderRequest, renderResponse);
					}else if (flag.equalsIgnoreCase(TaskManagementConstant.ASSIGN_TO_ME)) {
						viewTemplate ="/html/taskmanagement/task-assign-to-me.jsp";
						TaskManagementHelper.assignToMeSearchContainer(renderRequest, renderResponse);
					}else if(flag.equalsIgnoreCase(TaskManagementConstant.UPLOAD_CSV)){
						viewTemplate ="/html/taskmanagement/upload_csv.jsp";
					}
				}else if(Validator.isNotNull(cmd)){
					
					if(cmd.equals("moveEditJSP")){
						TaskManagementHelper.displayEditTaskRender(renderRequest, renderResponse);
						TaskManagementHelper.getSearchAssigneeDetails(renderRequest, renderResponse);
						viewTemplate ="/html/taskmanagement/view.jsp";
					}
					if(cmd.equals("taskDetailJSP")){
						TaskManagementHelper.displayTaskDetailsRender(renderRequest, renderResponse);
						viewTemplate = "/html/taskmanagement/task_detail.jsp";
					}
					if(cmd.equals("assignByMejsp")){
						viewTemplate ="/html/taskmanagement/task-assign-by-me.jsp";
						TaskManagementHelper.assignByMeSearchContainer(renderRequest, renderResponse);
					}
					if(cmd.equals("assignToMejsp")){
						viewTemplate ="/html/taskmanagement/task-assign-to-me.jsp";
						TaskManagementHelper.assignToMeSearchContainer(renderRequest, renderResponse);
					}
					if(cmd.equals("moveUploadcsvJSP")){
						String failedEmails = (String) renderRequest.getParameter("failedEmails");
						renderRequest.setAttribute("failedEmails", failedEmails);	
						viewTemplate = "/html/taskmanagement/upload_csv.jsp";
					}
				}else {
					TaskManagementHelper.getSearchAssigneeDetails(renderRequest, renderResponse);
					viewTemplate = "/html/taskmanagement/view.jsp";
				}
			}else{
				viewTemplate = "/html/taskmanagement/error.jsp";
				SessionErrors.add(renderRequest, "error-jsp-redirection");
			}
		}else{
			viewTemplate = "/html/taskmanagement/error.jsp";
			SessionErrors.add(renderRequest, "error-jsp-redirection");
		}
		SessionMessages.add(renderRequest, PortalUtil.getPortletId(renderRequest) + SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		super.render(renderRequest, renderResponse);
	}
	
	public void getTaskManagementData(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException{
				System.out.println("==================== getTaskManagementData   =========================");
		TaskManagementHelper.addTaskManagement(actionRequest,actionResponse);
		
	}
	
		
	public void deleteAssigneeTask(ActionRequest request,ActionResponse response){
		
		long assigneeTaskId = ParamUtil.getLong(request, "assigneeTaskId");
		_log.info("assigneeTaskId==>"+assigneeTaskId);
		String cmd = ParamUtil.getString(request, "cmd");
		
		try {
			List<TaskAssignment> taskAssignments = TaskAssignmentLocalServiceUtil.getAssignmentsByAssigneetaskId(assigneeTaskId);
			for (TaskAssignment taskAssignment : taskAssignments) {
				_log.info("taskAssignmentId===>>"+taskAssignment.getTaskAssignmentId());
				try {
					taskAssignment = TaskAssignmentLocalServiceUtil.getTaskAssignment(taskAssignment.getTaskAssignmentId());
					taskAssignment.setStatus(TaskManagementConstant.DELETE);
					taskAssignment.setFinal_status(TaskManagementConstant.DELETE);
					TaskAssignmentLocalServiceUtil.updateTaskAssignment(taskAssignment);
					SessionMessages.add(request, "task-deleted-successfully");
				} catch (PortalException e) {
					_log.error("error while getting taskassignment by delete task assignment");
				}
			}
		} catch (SystemException e) {
			_log.error("error while delete task assignment");
		}
		response.setRenderParameter("cmd", cmd);
	}
	
	public void completeTasks(ActionRequest request,ActionResponse response) {
		
		long[] taskAssignmentIds = ParamUtil.getLongValues(request, "taskAssignmentIds");
		long assigneeTaskId = ParamUtil.getLong(request, "assigneeTaskId");
		User assignedTo = null;
		User assignedBy = null;
		String cmd = ParamUtil.getString(request, "cmd");
		for(long taskAssignmentId : taskAssignmentIds){
			String achieved = ParamUtil.getString(request, "achieved"+taskAssignmentId);
		
			try {
				TaskAssignment taskAssignment = TaskAssignmentLocalServiceUtil.getTaskAssignment(taskAssignmentId);
				assignedBy = UserLocalServiceUtil.getUser(taskAssignment.getAssignByUserId());
				assignedTo = UserLocalServiceUtil.getUser(taskAssignment.getAssignToUserId());
				taskAssignment.setStatus(TaskManagementConstant.COMPLETE);
				taskAssignment.setAchieved(achieved);
				taskAssignment.setModifiedDate(new Date());
				
				TaskAssignmentLocalServiceUtil.updateTaskAssignment(taskAssignment);
			} catch (PortalException e) {
				_log.error("error while getting by task Completed");
			} catch (SystemException e) {
				_log.error("error while getting by task Completed");
			}
		}
		if(TaskManagementConstant.SEND_MAIL_ON){
			_log.info("========== Send mail for complete task ==========");
			String subject = TaskManagementConstant.TASK_ASSIGNMENT_STATUS_COMPLETE_SUBJECT_TMPL;
			String body = TaskManagementConstant.TASK_ASSIGNMENT_STATUS_COMPLETE_BODY_TMPL;
			JioTaskManagementUtil.sendMailTaskCompleted(TaskManagementConstant.FROM_MAIL_ID, assignedBy.getEmailAddress(), subject, body, assignedBy.getFullName(), assigneeTaskId);
		}
		
		try {
			List<TaskAssignment> tasks = TaskAssignmentLocalServiceUtil.getStatusByAssigneeTaskId(assigneeTaskId, TaskManagementConstant.IN_PROGRESS);
			if(tasks.size() == 0){
				List<TaskAssignment> taskAssignments = TaskAssignmentLocalServiceUtil.getAssignmentsByAssigneetaskId(assigneeTaskId);
				for (TaskAssignment taskAssignment : taskAssignments) {
					try {
						TaskAssignment tasksAssignment = TaskAssignmentLocalServiceUtil.getTaskAssignment(taskAssignment.getTaskAssignmentId());
						tasksAssignment.setFinal_status(TaskManagementConstant.COMPLETE);
						
						TaskAssignmentLocalServiceUtil.updateTaskAssignment(tasksAssignment);
					} catch (PortalException e) {
						_log.error("error while getting by task Completed");
					}
					
				}
			}
		} catch (SystemException e) {
			e.printStackTrace();
		}
		
		response.setRenderParameter("assigneeTaskId", String.valueOf(assigneeTaskId));
		response.setRenderParameter("cmd", cmd);
		SessionMessages.add(request, "task-complete-successfully");
	}
	
	public void searchTaskAssignByMe(ActionRequest actionRequest,ActionResponse actionResponse){
		
		_log.info("call searchTaskAssignByMe ");
		
		String status = ParamUtil.getString(actionRequest, "status");
		String dateFrom = ParamUtil.getString(actionRequest, "dateFrom");
		String dateTo = ParamUtil.getString(actionRequest, "dateTo");
		String cmd = ParamUtil.getString(actionRequest, "cmd");
		
		actionResponse.setRenderParameter("isSearch", "TRUE");
        actionResponse.setRenderParameter("status", status);
        actionResponse.setRenderParameter("dateFrom", dateFrom);
        actionResponse.setRenderParameter("dateTo", dateTo);
        actionResponse.setRenderParameter("cmd", cmd);
        
        SessionMessages.add(actionRequest, "task-search-successfully");
		
	}
	
	public void searchTaskAssignToMe(ActionRequest actionRequest,ActionResponse actionResponse){
		
		_log.info("call searchTaskAssignToMe ");
		
		String status = ParamUtil.getString(actionRequest, "status");
		String dateFrom = ParamUtil.getString(actionRequest, "dateFrom");
		String dateTo = ParamUtil.getString(actionRequest, "dateTo");
		String cmd = ParamUtil.getString(actionRequest, "cmd");
		
		actionResponse.setRenderParameter("isSearch", "TRUE");
        actionResponse.setRenderParameter("status", status);
        actionResponse.setRenderParameter("dateFrom", dateFrom);
        actionResponse.setRenderParameter("dateTo", dateTo);
        actionResponse.setRenderParameter("cmd", cmd);

        SessionMessages.add(actionRequest, "task-search-successfully");
	}
	
	public void UploadTaskAssigneeByCSV(ActionRequest actionRequest,ActionResponse actionResponse){
		
		TaskManagementHelper.UploadTasksbyCSV(actionRequest, actionResponse);
	    
 }


	
	@Override
	 public void serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws IOException, PortletException {
		System.out.println(" ============================== serve resource =============================");
	  String cmd = ParamUtil.getString(resourceRequest, TaskManagementConstant.CMD);
	  if (cmd.equals(TaskManagementConstant.GET_USERS)) {
		  String keyword= ParamUtil.getString(resourceRequest, TaskManagementConstant.Keyword);
		  //System.out.println("keyword==="+keyword);
		   if(Validator.isNotNull(keyword)){
			   getUsers(resourceRequest, resourceResponse, keyword.toUpperCase());
		   }
	  }
	  
	  if(cmd.equals("search_region")){
		 
		String region = ParamUtil.getString(resourceRequest, TaskManagementConstant.REGION);
		String circle = ParamUtil.getString(resourceRequest, TaskManagementConstant.CIRCLE);
		String area = ParamUtil.getString(resourceRequest, TaskManagementConstant.AREA);
		String center = ParamUtil.getString(resourceRequest, TaskManagementConstant.JIOCENTER);
		List<String> empDetails = EMP_DETAILSLocalServiceUtil.getSearchJobByAreaCircleRegionJioCenterAndOC(region, circle, area, center);
		
		try {
			List<String> circles = EMP_DETAILSLocalServiceUtil.getSearchCircleByRegion(region);
			circles.removeAll(Arrays.asList(null,""));
			JSONArray usersJSONArray = JSONFactoryUtil.createJSONArray();
			JSONObject userJSON= JSONFactoryUtil.createJSONObject();
			JSONObject userJobJSON= JSONFactoryUtil.createJSONObject();
			userJSON.put("searchCircle", circles.toString());
			usersJSONArray.put(userJSON);
			userJobJSON.put("searchJob", empDetails.toString());
			usersJSONArray.put(userJobJSON);
						
			PrintWriter out=resourceResponse.getWriter();
		    out.println(usersJSONArray.toString());
		} catch (SystemException e) {
			_log.error("error while getting circles");
		}
	  }
	  
	  if(cmd.equals("search_circle")){
		  _log.info("call search Circle");
		  String region = ParamUtil.getString(resourceRequest, TaskManagementConstant.REGION);
		  String circle = ParamUtil.getString(resourceRequest, TaskManagementConstant.CIRCLE);
		  String area = ParamUtil.getString(resourceRequest, TaskManagementConstant.AREA);
		  String center = ParamUtil.getString(resourceRequest, TaskManagementConstant.JIOCENTER);
		  List<String> empDetails = EMP_DETAILSLocalServiceUtil.getSearchJobByAreaCircleRegionJioCenterAndOC(region, circle, area, center);
		  try {
			List<String> areas = EMP_DETAILSLocalServiceUtil.getSearchAreaByCircleRegion(circle, region);
			areas.removeAll(Arrays.asList(null,""));
			JSONArray usersJSONArray = JSONFactoryUtil.createJSONArray();
			JSONObject userJSON= JSONFactoryUtil.createJSONObject();
			JSONObject userJobJSON= JSONFactoryUtil.createJSONObject();
			userJSON.put("searchAreas", areas.toString());
			usersJSONArray.put(userJSON);
			userJobJSON.put("searchJob", empDetails.toString());
			usersJSONArray.put(userJobJSON);
			/*for (String searchAreas: areas) {
				userJSON=JSONFactoryUtil.createJSONObject();
				userJSON.put("searchAreas", searchAreas);
				usersJSONArray.put(userJSON);
			}*/
			PrintWriter out=resourceResponse.getWriter();
		    out.println(usersJSONArray.toString());
		} catch (SystemException e) {
			_log.error("error while getting areas");
		}
	  }
	  
	  if(cmd.equals("search_area")){
		  _log.info("call search Area");
		  String region = ParamUtil.getString(resourceRequest, TaskManagementConstant.REGION);
		  String circle = ParamUtil.getString(resourceRequest, TaskManagementConstant.CIRCLE);
		  String area = ParamUtil.getString(resourceRequest, TaskManagementConstant.AREA);
		  String center = ParamUtil.getString(resourceRequest, TaskManagementConstant.JIOCENTER);
		 
		  try {
			List<String> empDetails = EMP_DETAILSLocalServiceUtil.getSearchJobByAreaCircleRegionJioCenterAndOC(region, circle, area, center);
			List<String> jioCenters = EMP_DETAILSLocalServiceUtil.getSearchJioCenterByAreaCircleRegion(circle, region, area);
			jioCenters.removeAll(Arrays.asList(null,""));
			JSONArray usersJSONArray = JSONFactoryUtil.createJSONArray();
			JSONObject userJSON= JSONFactoryUtil.createJSONObject();
			JSONObject userJobJSON= JSONFactoryUtil.createJSONObject();
			userJSON.put("searchJioCenter", jioCenters.toString());
			usersJSONArray.put(userJSON);
			userJobJSON.put("searchJob", empDetails.toString());
			usersJSONArray.put(userJobJSON);
			/*for (String searchJioCenter: jioCenters) {
				userJSON=JSONFactoryUtil.createJSONObject();
				userJSON.put("searchJioCenter", searchJioCenter);
				usersJSONArray.put(userJSON);
			}*/
			PrintWriter out=resourceResponse.getWriter();
		    out.println(usersJSONArray.toString());
		  } catch (SystemException e) {
				_log.error("error while getting jioCenters");
		  }
	  }
	  
	  if(cmd.equals("search_jioCenter")){
		  _log.info("call search jiocenter");
		  String region = ParamUtil.getString(resourceRequest, TaskManagementConstant.REGION);
		  String circle = ParamUtil.getString(resourceRequest, TaskManagementConstant.CIRCLE);
		  String area = ParamUtil.getString(resourceRequest, TaskManagementConstant.AREA);
		  String center = ParamUtil.getString(resourceRequest, TaskManagementConstant.JIOCENTER);
		 
		  List<String> jobs = EMP_DETAILSLocalServiceUtil.getSearchJobByAreaCircleRegionJioCenterAndOC(region, circle, area, center);
		  jobs.removeAll(Arrays.asList(null,""));
		  JSONArray usersJSONArray = JSONFactoryUtil.createJSONArray();
		  JSONObject userJSON=JSONFactoryUtil.createJSONObject();
		  userJSON.put("searchJob", jobs.toString());
		  usersJSONArray.put(userJSON);
			/*for (String searchJob: jobs) {
						userJSON=JSONFactoryUtil.createJSONObject();
						userJSON.put("searchJob", searchJob);
						usersJSONArray.put(userJSON);
			}*/
		  PrintWriter out=resourceResponse.getWriter();
		  out.println(usersJSONArray.toString());
	  }
	  
	  if(cmd.equals("search_job")){
		  
		  List<Object[]> jobs = EMP_DETAILSLocalServiceUtil.getDistinctJob();
		  jobs.removeAll(Arrays.asList(null,""));
		  
		  JSONArray usersJSONArray = JSONFactoryUtil.createJSONArray();
			JSONObject userJSON= null;
			
			for (Object objects : jobs) {
				userJSON=JSONFactoryUtil.createJSONObject();
				userJSON.put("jobs", objects.toString());
				usersJSONArray.put(userJSON);
			}
			PrintWriter out=resourceResponse.getWriter();
		    out.println(usersJSONArray.toString());
		  
	  }
	  
	  
	  if(cmd.equals("search_users")){
		  _log.info("call search users");
		  String region = ParamUtil.getString(resourceRequest, TaskManagementConstant.REGION);
		  String circle = ParamUtil.getString(resourceRequest, TaskManagementConstant.CIRCLE);
		  String area = ParamUtil.getString(resourceRequest, TaskManagementConstant.AREA);
		  String center = ParamUtil.getString(resourceRequest, TaskManagementConstant.JIOCENTER);
		  String job = ParamUtil.getString(resourceRequest, TaskManagementConstant.JOB);
			
		  JSONArray usersJSONArray = JSONFactoryUtil.createJSONArray();
		  JSONObject userJSON=null;
			
		  List<EMP_DETAILS> empDetails = EMP_DETAILSLocalServiceUtil.getsearchAssignees(region, circle, area,center,job);
		  for (EMP_DETAILS emps : empDetails) {
			userJSON=JSONFactoryUtil.createJSONObject();
			userJSON.put("fullName", emps.getFULL_NAME());
			userJSON.put("empId", emps.getEMP_ID());
			userJSON.put("userId", emps.getUserId());
			userJSON.put("userName", emps.getUserName());
			userJSON.put("email", emps.getEMAIL());
			usersJSONArray.put(userJSON);
		  }
		  PrintWriter out=resourceResponse.getWriter();
		  out.println(usersJSONArray.toString());
	  }
	 
	}

	
	private void getUsers(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse, String keyword) throws IOException {
		
		ThemeDisplay themeDisplay = (ThemeDisplay)resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

		EMP_DETAILS empDetails = EMP_DETAILSLocalServiceUtil.getEmpDetailsByUserId(themeDisplay.getUserId());
		if(Validator.isNotNull(empDetails)){
			List<Object[]> details = EMP_DETAILSLocalServiceUtil.searchUserByNameOrEmpIdInOC(keyword, empDetails.getDEPARTMENT());
			
			JSONArray usersJSONArray = JSONFactoryUtil.createJSONArray();
			JSONObject userJSON=null;
			for (Object[] objects : details) {
				
				userJSON=JSONFactoryUtil.createJSONObject();
				userJSON.put("fullName", GetterUtil.getString(objects[0]));
				userJSON.put("empId", GetterUtil.getLong(objects[1]));
				userJSON.put("userId", GetterUtil.getLong(objects[2]));
				usersJSONArray.put(userJSON);
				
			}
			
			PrintWriter out=resourceResponse.getWriter();
		    out.println(usersJSONArray.toString());
			
		}
	}
}
