/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.taskmanagement.model.impl;

import com.jioc.taskmanagement.model.TaskDetails;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing TaskDetails in entity cache.
 *
 * @author rajnikant.donga
 * @see TaskDetails
 * @generated
 */
public class TaskDetailsCacheModel implements CacheModel<TaskDetails>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{taskId=");
		sb.append(taskId);
		sb.append(", description=");
		sb.append(description);
		sb.append(", target=");
		sb.append(target);
		sb.append(", modifiedBy=");
		sb.append(modifiedBy);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", modifiedDate=");
		sb.append(modifiedDate);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public TaskDetails toEntityModel() {
		TaskDetailsImpl taskDetailsImpl = new TaskDetailsImpl();

		taskDetailsImpl.setTaskId(taskId);

		if (description == null) {
			taskDetailsImpl.setDescription(StringPool.BLANK);
		}
		else {
			taskDetailsImpl.setDescription(description);
		}

		taskDetailsImpl.setTarget(target);
		taskDetailsImpl.setModifiedBy(modifiedBy);

		if (createDate == Long.MIN_VALUE) {
			taskDetailsImpl.setCreateDate(null);
		}
		else {
			taskDetailsImpl.setCreateDate(new Date(createDate));
		}

		if (modifiedDate == Long.MIN_VALUE) {
			taskDetailsImpl.setModifiedDate(null);
		}
		else {
			taskDetailsImpl.setModifiedDate(new Date(modifiedDate));
		}

		taskDetailsImpl.resetOriginalValues();

		return taskDetailsImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		taskId = objectInput.readLong();
		description = objectInput.readUTF();
		target = objectInput.readLong();
		modifiedBy = objectInput.readLong();
		createDate = objectInput.readLong();
		modifiedDate = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(taskId);

		if (description == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(description);
		}

		objectOutput.writeLong(target);
		objectOutput.writeLong(modifiedBy);
		objectOutput.writeLong(createDate);
		objectOutput.writeLong(modifiedDate);
	}

	public long taskId;
	public String description;
	public long target;
	public long modifiedBy;
	public long createDate;
	public long modifiedDate;
}