create index IX_E214F928 on jioc_TaskAssignment (assignToUserId);
create index IX_D7A8AF0B on jioc_TaskAssignment (assignToUserId, assigneeTaskId);
create index IX_47B902E7 on jioc_TaskAssignment (assigneeTaskId);
create index IX_59956ACD on jioc_TaskAssignment (assigneeTaskId, status);
create index IX_9A8A75F8 on jioc_TaskAssignment (taskId);
create index IX_F88E3F8 on jioc_TaskAssignment (taskId, assignByUserId);
create index IX_7206821C on jioc_TaskAssignment (taskId, assignToUserId);
create index IX_8571CFFF on jioc_TaskAssignment (taskId, assignToUserId, assigneeTaskId);
create index IX_E1CF3CDE on jioc_TaskAssignment (taskId, status);

create index IX_48202E6B on jioc_TaskDetails (modifiedBy);

create index IX_4801F1 on jioc_TaskOcDetails (oc, status);
create index IX_DFD9ECE8 on jioc_TaskOcDetails (oc, status, cat_type);