create table jioc_TaskAssignment (
	taskAssignmentId LONG not null primary key,
	taskId LONG,
	assigneeTaskId LONG,
	assignByUserId LONG,
	assignToUserId LONG,
	status VARCHAR(75) null,
	final_status VARCHAR(75) null,
	achieved VARCHAR(300) null,
	modifiedBy LONG,
	createDate DATE null,
	modifiedDate DATE null
);

create table jioc_TaskDetails (
	taskId LONG not null primary key,
	description VARCHAR(1000) null,
	target LONG,
	modifiedBy LONG,
	createDate DATE null,
	modifiedDate DATE null
);

create table jioc_TaskJobDetails (
	jobId LONG not null primary key,
	job VARCHAR(75) null,
	status_TM INTEGER,
	status_MyApps INTEGER,
	modifiedDate DATE null
);

create table jioc_TaskOcDetails (
	ocId LONG not null primary key,
	oc VARCHAR(75) null,
	cat_type VARCHAR(75) null,
	status INTEGER,
	modifiedDate DATE null
);