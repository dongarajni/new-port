/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.taskmanagement.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link TaskDetails}.
 * </p>
 *
 * @author rajnikant.donga
 * @see TaskDetails
 * @generated
 */
public class TaskDetailsWrapper implements TaskDetails,
	ModelWrapper<TaskDetails> {
	public TaskDetailsWrapper(TaskDetails taskDetails) {
		_taskDetails = taskDetails;
	}

	@Override
	public Class<?> getModelClass() {
		return TaskDetails.class;
	}

	@Override
	public String getModelClassName() {
		return TaskDetails.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("taskId", getTaskId());
		attributes.put("description", getDescription());
		attributes.put("target", getTarget());
		attributes.put("modifiedBy", getModifiedBy());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long taskId = (Long)attributes.get("taskId");

		if (taskId != null) {
			setTaskId(taskId);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}

		Long target = (Long)attributes.get("target");

		if (target != null) {
			setTarget(target);
		}

		Long modifiedBy = (Long)attributes.get("modifiedBy");

		if (modifiedBy != null) {
			setModifiedBy(modifiedBy);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}
	}

	/**
	* Returns the primary key of this task details.
	*
	* @return the primary key of this task details
	*/
	@Override
	public long getPrimaryKey() {
		return _taskDetails.getPrimaryKey();
	}

	/**
	* Sets the primary key of this task details.
	*
	* @param primaryKey the primary key of this task details
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_taskDetails.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the task ID of this task details.
	*
	* @return the task ID of this task details
	*/
	@Override
	public long getTaskId() {
		return _taskDetails.getTaskId();
	}

	/**
	* Sets the task ID of this task details.
	*
	* @param taskId the task ID of this task details
	*/
	@Override
	public void setTaskId(long taskId) {
		_taskDetails.setTaskId(taskId);
	}

	/**
	* Returns the description of this task details.
	*
	* @return the description of this task details
	*/
	@Override
	public java.lang.String getDescription() {
		return _taskDetails.getDescription();
	}

	/**
	* Sets the description of this task details.
	*
	* @param description the description of this task details
	*/
	@Override
	public void setDescription(java.lang.String description) {
		_taskDetails.setDescription(description);
	}

	/**
	* Returns the target of this task details.
	*
	* @return the target of this task details
	*/
	@Override
	public long getTarget() {
		return _taskDetails.getTarget();
	}

	/**
	* Sets the target of this task details.
	*
	* @param target the target of this task details
	*/
	@Override
	public void setTarget(long target) {
		_taskDetails.setTarget(target);
	}

	/**
	* Returns the modified by of this task details.
	*
	* @return the modified by of this task details
	*/
	@Override
	public long getModifiedBy() {
		return _taskDetails.getModifiedBy();
	}

	/**
	* Sets the modified by of this task details.
	*
	* @param modifiedBy the modified by of this task details
	*/
	@Override
	public void setModifiedBy(long modifiedBy) {
		_taskDetails.setModifiedBy(modifiedBy);
	}

	/**
	* Returns the create date of this task details.
	*
	* @return the create date of this task details
	*/
	@Override
	public java.util.Date getCreateDate() {
		return _taskDetails.getCreateDate();
	}

	/**
	* Sets the create date of this task details.
	*
	* @param createDate the create date of this task details
	*/
	@Override
	public void setCreateDate(java.util.Date createDate) {
		_taskDetails.setCreateDate(createDate);
	}

	/**
	* Returns the modified date of this task details.
	*
	* @return the modified date of this task details
	*/
	@Override
	public java.util.Date getModifiedDate() {
		return _taskDetails.getModifiedDate();
	}

	/**
	* Sets the modified date of this task details.
	*
	* @param modifiedDate the modified date of this task details
	*/
	@Override
	public void setModifiedDate(java.util.Date modifiedDate) {
		_taskDetails.setModifiedDate(modifiedDate);
	}

	@Override
	public boolean isNew() {
		return _taskDetails.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_taskDetails.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _taskDetails.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_taskDetails.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _taskDetails.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _taskDetails.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_taskDetails.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _taskDetails.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_taskDetails.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_taskDetails.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_taskDetails.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new TaskDetailsWrapper((TaskDetails)_taskDetails.clone());
	}

	@Override
	public int compareTo(com.jioc.taskmanagement.model.TaskDetails taskDetails) {
		return _taskDetails.compareTo(taskDetails);
	}

	@Override
	public int hashCode() {
		return _taskDetails.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jioc.taskmanagement.model.TaskDetails> toCacheModel() {
		return _taskDetails.toCacheModel();
	}

	@Override
	public com.jioc.taskmanagement.model.TaskDetails toEscapedModel() {
		return new TaskDetailsWrapper(_taskDetails.toEscapedModel());
	}

	@Override
	public com.jioc.taskmanagement.model.TaskDetails toUnescapedModel() {
		return new TaskDetailsWrapper(_taskDetails.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _taskDetails.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _taskDetails.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_taskDetails.persist();
	}

	@Override
	public java.lang.String getTaskDetails_Status() {
		return _taskDetails.getTaskDetails_Status();
	}

	@Override
	public void setTaskDetails_Status(java.lang.String taskDetails_Status) {
		_taskDetails.setTaskDetails_Status(taskDetails_Status);
	}

	@Override
	public java.lang.String getAchieved() {
		return _taskDetails.getAchieved();
	}

	@Override
	public void setAchieved(java.lang.String achieved) {
		_taskDetails.setAchieved(achieved);
	}

	@Override
	public java.lang.String getStatus() {
		return _taskDetails.getStatus();
	}

	@Override
	public void setStatus(java.lang.String status) {
		_taskDetails.setStatus(status);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof TaskDetailsWrapper)) {
			return false;
		}

		TaskDetailsWrapper taskDetailsWrapper = (TaskDetailsWrapper)obj;

		if (Validator.equals(_taskDetails, taskDetailsWrapper._taskDetails)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public TaskDetails getWrappedTaskDetails() {
		return _taskDetails;
	}

	@Override
	public TaskDetails getWrappedModel() {
		return _taskDetails;
	}

	@Override
	public void resetOriginalValues() {
		_taskDetails.resetOriginalValues();
	}

	private TaskDetails _taskDetails;
}