/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.taskmanagement.service.persistence;

import com.jioc.taskmanagement.model.TaskDetails;

import com.liferay.portal.service.persistence.BasePersistence;

/**
 * The persistence interface for the task details service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author rajnikant.donga
 * @see TaskDetailsPersistenceImpl
 * @see TaskDetailsUtil
 * @generated
 */
public interface TaskDetailsPersistence extends BasePersistence<TaskDetails> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link TaskDetailsUtil} to access the task details persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the task detailses where modifiedBy = &#63;.
	*
	* @param modifiedBy the modified by
	* @return the matching task detailses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskDetails> findByAssignByMe(
		long modifiedBy)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the task detailses where modifiedBy = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskDetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param modifiedBy the modified by
	* @param start the lower bound of the range of task detailses
	* @param end the upper bound of the range of task detailses (not inclusive)
	* @return the range of matching task detailses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskDetails> findByAssignByMe(
		long modifiedBy, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the task detailses where modifiedBy = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskDetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param modifiedBy the modified by
	* @param start the lower bound of the range of task detailses
	* @param end the upper bound of the range of task detailses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching task detailses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskDetails> findByAssignByMe(
		long modifiedBy, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first task details in the ordered set where modifiedBy = &#63;.
	*
	* @param modifiedBy the modified by
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task details
	* @throws com.jioc.taskmanagement.NoSuchTaskDetailsException if a matching task details could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskDetails findByAssignByMe_First(
		long modifiedBy,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskDetailsException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first task details in the ordered set where modifiedBy = &#63;.
	*
	* @param modifiedBy the modified by
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task details, or <code>null</code> if a matching task details could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskDetails fetchByAssignByMe_First(
		long modifiedBy,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last task details in the ordered set where modifiedBy = &#63;.
	*
	* @param modifiedBy the modified by
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task details
	* @throws com.jioc.taskmanagement.NoSuchTaskDetailsException if a matching task details could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskDetails findByAssignByMe_Last(
		long modifiedBy,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskDetailsException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last task details in the ordered set where modifiedBy = &#63;.
	*
	* @param modifiedBy the modified by
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task details, or <code>null</code> if a matching task details could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskDetails fetchByAssignByMe_Last(
		long modifiedBy,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task detailses before and after the current task details in the ordered set where modifiedBy = &#63;.
	*
	* @param taskId the primary key of the current task details
	* @param modifiedBy the modified by
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next task details
	* @throws com.jioc.taskmanagement.NoSuchTaskDetailsException if a task details with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskDetails[] findByAssignByMe_PrevAndNext(
		long taskId, long modifiedBy,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskDetailsException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the task detailses where modifiedBy = &#63; from the database.
	*
	* @param modifiedBy the modified by
	* @throws SystemException if a system exception occurred
	*/
	public void removeByAssignByMe(long modifiedBy)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of task detailses where modifiedBy = &#63;.
	*
	* @param modifiedBy the modified by
	* @return the number of matching task detailses
	* @throws SystemException if a system exception occurred
	*/
	public int countByAssignByMe(long modifiedBy)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the task details in the entity cache if it is enabled.
	*
	* @param taskDetails the task details
	*/
	public void cacheResult(
		com.jioc.taskmanagement.model.TaskDetails taskDetails);

	/**
	* Caches the task detailses in the entity cache if it is enabled.
	*
	* @param taskDetailses the task detailses
	*/
	public void cacheResult(
		java.util.List<com.jioc.taskmanagement.model.TaskDetails> taskDetailses);

	/**
	* Creates a new task details with the primary key. Does not add the task details to the database.
	*
	* @param taskId the primary key for the new task details
	* @return the new task details
	*/
	public com.jioc.taskmanagement.model.TaskDetails create(long taskId);

	/**
	* Removes the task details with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param taskId the primary key of the task details
	* @return the task details that was removed
	* @throws com.jioc.taskmanagement.NoSuchTaskDetailsException if a task details with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskDetails remove(long taskId)
		throws com.jioc.taskmanagement.NoSuchTaskDetailsException,
			com.liferay.portal.kernel.exception.SystemException;

	public com.jioc.taskmanagement.model.TaskDetails updateImpl(
		com.jioc.taskmanagement.model.TaskDetails taskDetails)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task details with the primary key or throws a {@link com.jioc.taskmanagement.NoSuchTaskDetailsException} if it could not be found.
	*
	* @param taskId the primary key of the task details
	* @return the task details
	* @throws com.jioc.taskmanagement.NoSuchTaskDetailsException if a task details with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskDetails findByPrimaryKey(
		long taskId)
		throws com.jioc.taskmanagement.NoSuchTaskDetailsException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task details with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param taskId the primary key of the task details
	* @return the task details, or <code>null</code> if a task details with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskDetails fetchByPrimaryKey(
		long taskId) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the task detailses.
	*
	* @return the task detailses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskDetails> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the task detailses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskDetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of task detailses
	* @param end the upper bound of the range of task detailses (not inclusive)
	* @return the range of task detailses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskDetails> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the task detailses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskDetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of task detailses
	* @param end the upper bound of the range of task detailses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of task detailses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskDetails> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the task detailses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of task detailses.
	*
	* @return the number of task detailses
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}