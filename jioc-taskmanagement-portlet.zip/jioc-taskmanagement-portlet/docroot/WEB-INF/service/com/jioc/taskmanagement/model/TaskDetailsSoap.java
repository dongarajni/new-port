/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.taskmanagement.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author rajnikant.donga
 * @generated
 */
public class TaskDetailsSoap implements Serializable {
	public static TaskDetailsSoap toSoapModel(TaskDetails model) {
		TaskDetailsSoap soapModel = new TaskDetailsSoap();

		soapModel.setTaskId(model.getTaskId());
		soapModel.setDescription(model.getDescription());
		soapModel.setTarget(model.getTarget());
		soapModel.setModifiedBy(model.getModifiedBy());
		soapModel.setCreateDate(model.getCreateDate());
		soapModel.setModifiedDate(model.getModifiedDate());

		return soapModel;
	}

	public static TaskDetailsSoap[] toSoapModels(TaskDetails[] models) {
		TaskDetailsSoap[] soapModels = new TaskDetailsSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static TaskDetailsSoap[][] toSoapModels(TaskDetails[][] models) {
		TaskDetailsSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new TaskDetailsSoap[models.length][models[0].length];
		}
		else {
			soapModels = new TaskDetailsSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static TaskDetailsSoap[] toSoapModels(List<TaskDetails> models) {
		List<TaskDetailsSoap> soapModels = new ArrayList<TaskDetailsSoap>(models.size());

		for (TaskDetails model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new TaskDetailsSoap[soapModels.size()]);
	}

	public TaskDetailsSoap() {
	}

	public long getPrimaryKey() {
		return _taskId;
	}

	public void setPrimaryKey(long pk) {
		setTaskId(pk);
	}

	public long getTaskId() {
		return _taskId;
	}

	public void setTaskId(long taskId) {
		_taskId = taskId;
	}

	public String getDescription() {
		return _description;
	}

	public void setDescription(String description) {
		_description = description;
	}

	public long getTarget() {
		return _target;
	}

	public void setTarget(long target) {
		_target = target;
	}

	public long getModifiedBy() {
		return _modifiedBy;
	}

	public void setModifiedBy(long modifiedBy) {
		_modifiedBy = modifiedBy;
	}

	public Date getCreateDate() {
		return _createDate;
	}

	public void setCreateDate(Date createDate) {
		_createDate = createDate;
	}

	public Date getModifiedDate() {
		return _modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;
	}

	private long _taskId;
	private String _description;
	private long _target;
	private long _modifiedBy;
	private Date _createDate;
	private Date _modifiedDate;
}