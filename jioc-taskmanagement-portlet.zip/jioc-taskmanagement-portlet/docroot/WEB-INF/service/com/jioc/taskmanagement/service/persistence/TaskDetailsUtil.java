/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.taskmanagement.service.persistence;

import com.jioc.taskmanagement.model.TaskDetails;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import java.util.List;

/**
 * The persistence utility for the task details service. This utility wraps {@link TaskDetailsPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author rajnikant.donga
 * @see TaskDetailsPersistence
 * @see TaskDetailsPersistenceImpl
 * @generated
 */
public class TaskDetailsUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(TaskDetails taskDetails) {
		getPersistence().clearCache(taskDetails);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<TaskDetails> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<TaskDetails> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<TaskDetails> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static TaskDetails update(TaskDetails taskDetails)
		throws SystemException {
		return getPersistence().update(taskDetails);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static TaskDetails update(TaskDetails taskDetails,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(taskDetails, serviceContext);
	}

	/**
	* Returns all the task detailses where modifiedBy = &#63;.
	*
	* @param modifiedBy the modified by
	* @return the matching task detailses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskDetails> findByAssignByMe(
		long modifiedBy)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByAssignByMe(modifiedBy);
	}

	/**
	* Returns a range of all the task detailses where modifiedBy = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskDetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param modifiedBy the modified by
	* @param start the lower bound of the range of task detailses
	* @param end the upper bound of the range of task detailses (not inclusive)
	* @return the range of matching task detailses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskDetails> findByAssignByMe(
		long modifiedBy, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByAssignByMe(modifiedBy, start, end);
	}

	/**
	* Returns an ordered range of all the task detailses where modifiedBy = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskDetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param modifiedBy the modified by
	* @param start the lower bound of the range of task detailses
	* @param end the upper bound of the range of task detailses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching task detailses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskDetails> findByAssignByMe(
		long modifiedBy, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignByMe(modifiedBy, start, end, orderByComparator);
	}

	/**
	* Returns the first task details in the ordered set where modifiedBy = &#63;.
	*
	* @param modifiedBy the modified by
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task details
	* @throws com.jioc.taskmanagement.NoSuchTaskDetailsException if a matching task details could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskDetails findByAssignByMe_First(
		long modifiedBy,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskDetailsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignByMe_First(modifiedBy, orderByComparator);
	}

	/**
	* Returns the first task details in the ordered set where modifiedBy = &#63;.
	*
	* @param modifiedBy the modified by
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task details, or <code>null</code> if a matching task details could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskDetails fetchByAssignByMe_First(
		long modifiedBy,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAssignByMe_First(modifiedBy, orderByComparator);
	}

	/**
	* Returns the last task details in the ordered set where modifiedBy = &#63;.
	*
	* @param modifiedBy the modified by
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task details
	* @throws com.jioc.taskmanagement.NoSuchTaskDetailsException if a matching task details could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskDetails findByAssignByMe_Last(
		long modifiedBy,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskDetailsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignByMe_Last(modifiedBy, orderByComparator);
	}

	/**
	* Returns the last task details in the ordered set where modifiedBy = &#63;.
	*
	* @param modifiedBy the modified by
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task details, or <code>null</code> if a matching task details could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskDetails fetchByAssignByMe_Last(
		long modifiedBy,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAssignByMe_Last(modifiedBy, orderByComparator);
	}

	/**
	* Returns the task detailses before and after the current task details in the ordered set where modifiedBy = &#63;.
	*
	* @param taskId the primary key of the current task details
	* @param modifiedBy the modified by
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next task details
	* @throws com.jioc.taskmanagement.NoSuchTaskDetailsException if a task details with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskDetails[] findByAssignByMe_PrevAndNext(
		long taskId, long modifiedBy,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskDetailsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignByMe_PrevAndNext(taskId, modifiedBy,
			orderByComparator);
	}

	/**
	* Removes all the task detailses where modifiedBy = &#63; from the database.
	*
	* @param modifiedBy the modified by
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByAssignByMe(long modifiedBy)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByAssignByMe(modifiedBy);
	}

	/**
	* Returns the number of task detailses where modifiedBy = &#63;.
	*
	* @param modifiedBy the modified by
	* @return the number of matching task detailses
	* @throws SystemException if a system exception occurred
	*/
	public static int countByAssignByMe(long modifiedBy)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByAssignByMe(modifiedBy);
	}

	/**
	* Caches the task details in the entity cache if it is enabled.
	*
	* @param taskDetails the task details
	*/
	public static void cacheResult(
		com.jioc.taskmanagement.model.TaskDetails taskDetails) {
		getPersistence().cacheResult(taskDetails);
	}

	/**
	* Caches the task detailses in the entity cache if it is enabled.
	*
	* @param taskDetailses the task detailses
	*/
	public static void cacheResult(
		java.util.List<com.jioc.taskmanagement.model.TaskDetails> taskDetailses) {
		getPersistence().cacheResult(taskDetailses);
	}

	/**
	* Creates a new task details with the primary key. Does not add the task details to the database.
	*
	* @param taskId the primary key for the new task details
	* @return the new task details
	*/
	public static com.jioc.taskmanagement.model.TaskDetails create(long taskId) {
		return getPersistence().create(taskId);
	}

	/**
	* Removes the task details with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param taskId the primary key of the task details
	* @return the task details that was removed
	* @throws com.jioc.taskmanagement.NoSuchTaskDetailsException if a task details with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskDetails remove(long taskId)
		throws com.jioc.taskmanagement.NoSuchTaskDetailsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().remove(taskId);
	}

	public static com.jioc.taskmanagement.model.TaskDetails updateImpl(
		com.jioc.taskmanagement.model.TaskDetails taskDetails)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(taskDetails);
	}

	/**
	* Returns the task details with the primary key or throws a {@link com.jioc.taskmanagement.NoSuchTaskDetailsException} if it could not be found.
	*
	* @param taskId the primary key of the task details
	* @return the task details
	* @throws com.jioc.taskmanagement.NoSuchTaskDetailsException if a task details with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskDetails findByPrimaryKey(
		long taskId)
		throws com.jioc.taskmanagement.NoSuchTaskDetailsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPrimaryKey(taskId);
	}

	/**
	* Returns the task details with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param taskId the primary key of the task details
	* @return the task details, or <code>null</code> if a task details with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskDetails fetchByPrimaryKey(
		long taskId) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(taskId);
	}

	/**
	* Returns all the task detailses.
	*
	* @return the task detailses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskDetails> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the task detailses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskDetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of task detailses
	* @param end the upper bound of the range of task detailses (not inclusive)
	* @return the range of task detailses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskDetails> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the task detailses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskDetailsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of task detailses
	* @param end the upper bound of the range of task detailses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of task detailses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskDetails> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the task detailses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of task detailses.
	*
	* @return the number of task detailses
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static TaskDetailsPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (TaskDetailsPersistence)PortletBeanLocatorUtil.locate(com.jioc.taskmanagement.service.ClpSerializer.getServletContextName(),
					TaskDetailsPersistence.class.getName());

			ReferenceRegistry.registerReference(TaskDetailsUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(TaskDetailsPersistence persistence) {
	}

	private static TaskDetailsPersistence _persistence;
}