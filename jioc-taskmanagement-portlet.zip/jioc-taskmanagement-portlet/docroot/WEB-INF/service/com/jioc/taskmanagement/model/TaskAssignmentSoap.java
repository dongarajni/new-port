/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.taskmanagement.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author rajnikant.donga
 * @generated
 */
public class TaskAssignmentSoap implements Serializable {
	public static TaskAssignmentSoap toSoapModel(TaskAssignment model) {
		TaskAssignmentSoap soapModel = new TaskAssignmentSoap();

		soapModel.setTaskAssignmentId(model.getTaskAssignmentId());
		soapModel.setTaskId(model.getTaskId());
		soapModel.setAssigneeTaskId(model.getAssigneeTaskId());
		soapModel.setAssignByUserId(model.getAssignByUserId());
		soapModel.setAssignToUserId(model.getAssignToUserId());
		soapModel.setStatus(model.getStatus());
		soapModel.setFinal_status(model.getFinal_status());
		soapModel.setAchieved(model.getAchieved());
		soapModel.setModifiedBy(model.getModifiedBy());
		soapModel.setCreateDate(model.getCreateDate());
		soapModel.setModifiedDate(model.getModifiedDate());

		return soapModel;
	}

	public static TaskAssignmentSoap[] toSoapModels(TaskAssignment[] models) {
		TaskAssignmentSoap[] soapModels = new TaskAssignmentSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static TaskAssignmentSoap[][] toSoapModels(TaskAssignment[][] models) {
		TaskAssignmentSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new TaskAssignmentSoap[models.length][models[0].length];
		}
		else {
			soapModels = new TaskAssignmentSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static TaskAssignmentSoap[] toSoapModels(List<TaskAssignment> models) {
		List<TaskAssignmentSoap> soapModels = new ArrayList<TaskAssignmentSoap>(models.size());

		for (TaskAssignment model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new TaskAssignmentSoap[soapModels.size()]);
	}

	public TaskAssignmentSoap() {
	}

	public long getPrimaryKey() {
		return _taskAssignmentId;
	}

	public void setPrimaryKey(long pk) {
		setTaskAssignmentId(pk);
	}

	public long getTaskAssignmentId() {
		return _taskAssignmentId;
	}

	public void setTaskAssignmentId(long taskAssignmentId) {
		_taskAssignmentId = taskAssignmentId;
	}

	public long getTaskId() {
		return _taskId;
	}

	public void setTaskId(long taskId) {
		_taskId = taskId;
	}

	public long getAssigneeTaskId() {
		return _assigneeTaskId;
	}

	public void setAssigneeTaskId(long assigneeTaskId) {
		_assigneeTaskId = assigneeTaskId;
	}

	public long getAssignByUserId() {
		return _assignByUserId;
	}

	public void setAssignByUserId(long assignByUserId) {
		_assignByUserId = assignByUserId;
	}

	public long getAssignToUserId() {
		return _assignToUserId;
	}

	public void setAssignToUserId(long assignToUserId) {
		_assignToUserId = assignToUserId;
	}

	public String getStatus() {
		return _status;
	}

	public void setStatus(String status) {
		_status = status;
	}

	public String getFinal_status() {
		return _final_status;
	}

	public void setFinal_status(String final_status) {
		_final_status = final_status;
	}

	public String getAchieved() {
		return _achieved;
	}

	public void setAchieved(String achieved) {
		_achieved = achieved;
	}

	public long getModifiedBy() {
		return _modifiedBy;
	}

	public void setModifiedBy(long modifiedBy) {
		_modifiedBy = modifiedBy;
	}

	public Date getCreateDate() {
		return _createDate;
	}

	public void setCreateDate(Date createDate) {
		_createDate = createDate;
	}

	public Date getModifiedDate() {
		return _modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;
	}

	private long _taskAssignmentId;
	private long _taskId;
	private long _assigneeTaskId;
	private long _assignByUserId;
	private long _assignToUserId;
	private String _status;
	private String _final_status;
	private String _achieved;
	private long _modifiedBy;
	private Date _createDate;
	private Date _modifiedDate;
}