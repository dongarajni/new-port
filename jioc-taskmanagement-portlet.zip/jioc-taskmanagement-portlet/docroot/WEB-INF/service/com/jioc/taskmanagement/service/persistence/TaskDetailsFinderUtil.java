/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.taskmanagement.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;

/**
 * @author rajnikant.donga
 */
public class TaskDetailsFinderUtil {
	public static java.util.List<com.jioc.taskmanagement.model.TaskDetails> getAllTasksAssigneeById(
		long assigneetaskid) {
		return getFinder().getAllTasksAssigneeById(assigneetaskid);
	}

	public static TaskDetailsFinder getFinder() {
		if (_finder == null) {
			_finder = (TaskDetailsFinder)PortletBeanLocatorUtil.locate(com.jioc.taskmanagement.service.ClpSerializer.getServletContextName(),
					TaskDetailsFinder.class.getName());

			ReferenceRegistry.registerReference(TaskDetailsFinderUtil.class,
				"_finder");
		}

		return _finder;
	}

	public void setFinder(TaskDetailsFinder finder) {
		_finder = finder;

		ReferenceRegistry.registerReference(TaskDetailsFinderUtil.class,
			"_finder");
	}

	private static TaskDetailsFinder _finder;
}