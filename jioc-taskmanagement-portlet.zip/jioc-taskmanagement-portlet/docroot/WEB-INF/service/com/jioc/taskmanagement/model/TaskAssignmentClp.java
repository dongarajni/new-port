/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.taskmanagement.model;

import com.jioc.taskmanagement.service.ClpSerializer;
import com.jioc.taskmanagement.service.TaskAssignmentLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author rajnikant.donga
 */
public class TaskAssignmentClp extends BaseModelImpl<TaskAssignment>
	implements TaskAssignment {
	public TaskAssignmentClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return TaskAssignment.class;
	}

	@Override
	public String getModelClassName() {
		return TaskAssignment.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _taskAssignmentId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setTaskAssignmentId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _taskAssignmentId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("taskAssignmentId", getTaskAssignmentId());
		attributes.put("taskId", getTaskId());
		attributes.put("assigneeTaskId", getAssigneeTaskId());
		attributes.put("assignByUserId", getAssignByUserId());
		attributes.put("assignToUserId", getAssignToUserId());
		attributes.put("status", getStatus());
		attributes.put("final_status", getFinal_status());
		attributes.put("achieved", getAchieved());
		attributes.put("modifiedBy", getModifiedBy());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long taskAssignmentId = (Long)attributes.get("taskAssignmentId");

		if (taskAssignmentId != null) {
			setTaskAssignmentId(taskAssignmentId);
		}

		Long taskId = (Long)attributes.get("taskId");

		if (taskId != null) {
			setTaskId(taskId);
		}

		Long assigneeTaskId = (Long)attributes.get("assigneeTaskId");

		if (assigneeTaskId != null) {
			setAssigneeTaskId(assigneeTaskId);
		}

		Long assignByUserId = (Long)attributes.get("assignByUserId");

		if (assignByUserId != null) {
			setAssignByUserId(assignByUserId);
		}

		Long assignToUserId = (Long)attributes.get("assignToUserId");

		if (assignToUserId != null) {
			setAssignToUserId(assignToUserId);
		}

		String status = (String)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String final_status = (String)attributes.get("final_status");

		if (final_status != null) {
			setFinal_status(final_status);
		}

		String achieved = (String)attributes.get("achieved");

		if (achieved != null) {
			setAchieved(achieved);
		}

		Long modifiedBy = (Long)attributes.get("modifiedBy");

		if (modifiedBy != null) {
			setModifiedBy(modifiedBy);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}
	}

	@Override
	public long getTaskAssignmentId() {
		return _taskAssignmentId;
	}

	@Override
	public void setTaskAssignmentId(long taskAssignmentId) {
		_taskAssignmentId = taskAssignmentId;

		if (_taskAssignmentRemoteModel != null) {
			try {
				Class<?> clazz = _taskAssignmentRemoteModel.getClass();

				Method method = clazz.getMethod("setTaskAssignmentId",
						long.class);

				method.invoke(_taskAssignmentRemoteModel, taskAssignmentId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getTaskId() {
		return _taskId;
	}

	@Override
	public void setTaskId(long taskId) {
		_taskId = taskId;

		if (_taskAssignmentRemoteModel != null) {
			try {
				Class<?> clazz = _taskAssignmentRemoteModel.getClass();

				Method method = clazz.getMethod("setTaskId", long.class);

				method.invoke(_taskAssignmentRemoteModel, taskId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getAssigneeTaskId() {
		return _assigneeTaskId;
	}

	@Override
	public void setAssigneeTaskId(long assigneeTaskId) {
		_assigneeTaskId = assigneeTaskId;

		if (_taskAssignmentRemoteModel != null) {
			try {
				Class<?> clazz = _taskAssignmentRemoteModel.getClass();

				Method method = clazz.getMethod("setAssigneeTaskId", long.class);

				method.invoke(_taskAssignmentRemoteModel, assigneeTaskId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getAssignByUserId() {
		return _assignByUserId;
	}

	@Override
	public void setAssignByUserId(long assignByUserId) {
		_assignByUserId = assignByUserId;

		if (_taskAssignmentRemoteModel != null) {
			try {
				Class<?> clazz = _taskAssignmentRemoteModel.getClass();

				Method method = clazz.getMethod("setAssignByUserId", long.class);

				method.invoke(_taskAssignmentRemoteModel, assignByUserId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAssignByUserUuid() throws SystemException {
		return PortalUtil.getUserValue(getAssignByUserId(), "uuid",
			_assignByUserUuid);
	}

	@Override
	public void setAssignByUserUuid(String assignByUserUuid) {
		_assignByUserUuid = assignByUserUuid;
	}

	@Override
	public long getAssignToUserId() {
		return _assignToUserId;
	}

	@Override
	public void setAssignToUserId(long assignToUserId) {
		_assignToUserId = assignToUserId;

		if (_taskAssignmentRemoteModel != null) {
			try {
				Class<?> clazz = _taskAssignmentRemoteModel.getClass();

				Method method = clazz.getMethod("setAssignToUserId", long.class);

				method.invoke(_taskAssignmentRemoteModel, assignToUserId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAssignToUserUuid() throws SystemException {
		return PortalUtil.getUserValue(getAssignToUserId(), "uuid",
			_assignToUserUuid);
	}

	@Override
	public void setAssignToUserUuid(String assignToUserUuid) {
		_assignToUserUuid = assignToUserUuid;
	}

	@Override
	public String getStatus() {
		return _status;
	}

	@Override
	public void setStatus(String status) {
		_status = status;

		if (_taskAssignmentRemoteModel != null) {
			try {
				Class<?> clazz = _taskAssignmentRemoteModel.getClass();

				Method method = clazz.getMethod("setStatus", String.class);

				method.invoke(_taskAssignmentRemoteModel, status);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getFinal_status() {
		return _final_status;
	}

	@Override
	public void setFinal_status(String final_status) {
		_final_status = final_status;

		if (_taskAssignmentRemoteModel != null) {
			try {
				Class<?> clazz = _taskAssignmentRemoteModel.getClass();

				Method method = clazz.getMethod("setFinal_status", String.class);

				method.invoke(_taskAssignmentRemoteModel, final_status);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAchieved() {
		return _achieved;
	}

	@Override
	public void setAchieved(String achieved) {
		_achieved = achieved;

		if (_taskAssignmentRemoteModel != null) {
			try {
				Class<?> clazz = _taskAssignmentRemoteModel.getClass();

				Method method = clazz.getMethod("setAchieved", String.class);

				method.invoke(_taskAssignmentRemoteModel, achieved);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getModifiedBy() {
		return _modifiedBy;
	}

	@Override
	public void setModifiedBy(long modifiedBy) {
		_modifiedBy = modifiedBy;

		if (_taskAssignmentRemoteModel != null) {
			try {
				Class<?> clazz = _taskAssignmentRemoteModel.getClass();

				Method method = clazz.getMethod("setModifiedBy", long.class);

				method.invoke(_taskAssignmentRemoteModel, modifiedBy);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getCreateDate() {
		return _createDate;
	}

	@Override
	public void setCreateDate(Date createDate) {
		_createDate = createDate;

		if (_taskAssignmentRemoteModel != null) {
			try {
				Class<?> clazz = _taskAssignmentRemoteModel.getClass();

				Method method = clazz.getMethod("setCreateDate", Date.class);

				method.invoke(_taskAssignmentRemoteModel, createDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getModifiedDate() {
		return _modifiedDate;
	}

	@Override
	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;

		if (_taskAssignmentRemoteModel != null) {
			try {
				Class<?> clazz = _taskAssignmentRemoteModel.getClass();

				Method method = clazz.getMethod("setModifiedDate", Date.class);

				method.invoke(_taskAssignmentRemoteModel, modifiedDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public java.lang.String getDescription() {
		try {
			String methodName = "getDescription";

			Class<?>[] parameterTypes = new Class<?>[] {  };

			Object[] parameterValues = new Object[] {  };

			java.lang.String returnObj = (java.lang.String)invokeOnRemoteModel(methodName,
					parameterTypes, parameterValues);

			return returnObj;
		}
		catch (Exception e) {
			throw new UnsupportedOperationException(e);
		}
	}

	@Override
	public void setDescription(java.lang.String description) {
		try {
			String methodName = "setDescription";

			Class<?>[] parameterTypes = new Class<?>[] { java.lang.String.class };

			Object[] parameterValues = new Object[] { description };

			invokeOnRemoteModel(methodName, parameterTypes, parameterValues);
		}
		catch (Exception e) {
			throw new UnsupportedOperationException(e);
		}
	}

	@Override
	public void setTarget(long target) {
		try {
			String methodName = "setTarget";

			Class<?>[] parameterTypes = new Class<?>[] { long.class };

			Object[] parameterValues = new Object[] { target };

			invokeOnRemoteModel(methodName, parameterTypes, parameterValues);
		}
		catch (Exception e) {
			throw new UnsupportedOperationException(e);
		}
	}

	@Override
	public long getTarget() {
		try {
			String methodName = "getTarget";

			Class<?>[] parameterTypes = new Class<?>[] {  };

			Object[] parameterValues = new Object[] {  };

			Long returnObj = (Long)invokeOnRemoteModel(methodName,
					parameterTypes, parameterValues);

			return returnObj;
		}
		catch (Exception e) {
			throw new UnsupportedOperationException(e);
		}
	}

	@Override
	public void setEmployeeFullName(java.lang.String employeeFullName) {
		try {
			String methodName = "setEmployeeFullName";

			Class<?>[] parameterTypes = new Class<?>[] { java.lang.String.class };

			Object[] parameterValues = new Object[] { employeeFullName };

			invokeOnRemoteModel(methodName, parameterTypes, parameterValues);
		}
		catch (Exception e) {
			throw new UnsupportedOperationException(e);
		}
	}

	@Override
	public java.lang.String getEmployeeFullName() {
		try {
			String methodName = "getEmployeeFullName";

			Class<?>[] parameterTypes = new Class<?>[] {  };

			Object[] parameterValues = new Object[] {  };

			java.lang.String returnObj = (java.lang.String)invokeOnRemoteModel(methodName,
					parameterTypes, parameterValues);

			return returnObj;
		}
		catch (Exception e) {
			throw new UnsupportedOperationException(e);
		}
	}

	public BaseModel<?> getTaskAssignmentRemoteModel() {
		return _taskAssignmentRemoteModel;
	}

	public void setTaskAssignmentRemoteModel(
		BaseModel<?> taskAssignmentRemoteModel) {
		_taskAssignmentRemoteModel = taskAssignmentRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _taskAssignmentRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_taskAssignmentRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			TaskAssignmentLocalServiceUtil.addTaskAssignment(this);
		}
		else {
			TaskAssignmentLocalServiceUtil.updateTaskAssignment(this);
		}
	}

	@Override
	public TaskAssignment toEscapedModel() {
		return (TaskAssignment)ProxyUtil.newProxyInstance(TaskAssignment.class.getClassLoader(),
			new Class[] { TaskAssignment.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		TaskAssignmentClp clone = new TaskAssignmentClp();

		clone.setTaskAssignmentId(getTaskAssignmentId());
		clone.setTaskId(getTaskId());
		clone.setAssigneeTaskId(getAssigneeTaskId());
		clone.setAssignByUserId(getAssignByUserId());
		clone.setAssignToUserId(getAssignToUserId());
		clone.setStatus(getStatus());
		clone.setFinal_status(getFinal_status());
		clone.setAchieved(getAchieved());
		clone.setModifiedBy(getModifiedBy());
		clone.setCreateDate(getCreateDate());
		clone.setModifiedDate(getModifiedDate());

		return clone;
	}

	@Override
	public int compareTo(TaskAssignment taskAssignment) {
		long primaryKey = taskAssignment.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof TaskAssignmentClp)) {
			return false;
		}

		TaskAssignmentClp taskAssignment = (TaskAssignmentClp)obj;

		long primaryKey = taskAssignment.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(23);

		sb.append("{taskAssignmentId=");
		sb.append(getTaskAssignmentId());
		sb.append(", taskId=");
		sb.append(getTaskId());
		sb.append(", assigneeTaskId=");
		sb.append(getAssigneeTaskId());
		sb.append(", assignByUserId=");
		sb.append(getAssignByUserId());
		sb.append(", assignToUserId=");
		sb.append(getAssignToUserId());
		sb.append(", status=");
		sb.append(getStatus());
		sb.append(", final_status=");
		sb.append(getFinal_status());
		sb.append(", achieved=");
		sb.append(getAchieved());
		sb.append(", modifiedBy=");
		sb.append(getModifiedBy());
		sb.append(", createDate=");
		sb.append(getCreateDate());
		sb.append(", modifiedDate=");
		sb.append(getModifiedDate());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(37);

		sb.append("<model><model-name>");
		sb.append("com.jioc.taskmanagement.model.TaskAssignment");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>taskAssignmentId</column-name><column-value><![CDATA[");
		sb.append(getTaskAssignmentId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>taskId</column-name><column-value><![CDATA[");
		sb.append(getTaskId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>assigneeTaskId</column-name><column-value><![CDATA[");
		sb.append(getAssigneeTaskId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>assignByUserId</column-name><column-value><![CDATA[");
		sb.append(getAssignByUserId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>assignToUserId</column-name><column-value><![CDATA[");
		sb.append(getAssignToUserId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>status</column-name><column-value><![CDATA[");
		sb.append(getStatus());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>final_status</column-name><column-value><![CDATA[");
		sb.append(getFinal_status());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>achieved</column-name><column-value><![CDATA[");
		sb.append(getAchieved());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>modifiedBy</column-name><column-value><![CDATA[");
		sb.append(getModifiedBy());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>createDate</column-name><column-value><![CDATA[");
		sb.append(getCreateDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>modifiedDate</column-name><column-value><![CDATA[");
		sb.append(getModifiedDate());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _taskAssignmentId;
	private long _taskId;
	private long _assigneeTaskId;
	private long _assignByUserId;
	private String _assignByUserUuid;
	private long _assignToUserId;
	private String _assignToUserUuid;
	private String _status;
	private String _final_status;
	private String _achieved;
	private long _modifiedBy;
	private Date _createDate;
	private Date _modifiedDate;
	private BaseModel<?> _taskAssignmentRemoteModel;
	private Class<?> _clpSerializerClass = com.jioc.taskmanagement.service.ClpSerializer.class;
}