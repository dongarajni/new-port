/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.taskmanagement.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link TaskAssignmentLocalService}.
 *
 * @author rajnikant.donga
 * @see TaskAssignmentLocalService
 * @generated
 */
public class TaskAssignmentLocalServiceWrapper
	implements TaskAssignmentLocalService,
		ServiceWrapper<TaskAssignmentLocalService> {
	public TaskAssignmentLocalServiceWrapper(
		TaskAssignmentLocalService taskAssignmentLocalService) {
		_taskAssignmentLocalService = taskAssignmentLocalService;
	}

	/**
	* Adds the task assignment to the database. Also notifies the appropriate model listeners.
	*
	* @param taskAssignment the task assignment
	* @return the task assignment that was added
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.jioc.taskmanagement.model.TaskAssignment addTaskAssignment(
		com.jioc.taskmanagement.model.TaskAssignment taskAssignment)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.addTaskAssignment(taskAssignment);
	}

	/**
	* Creates a new task assignment with the primary key. Does not add the task assignment to the database.
	*
	* @param taskAssignmentId the primary key for the new task assignment
	* @return the new task assignment
	*/
	@Override
	public com.jioc.taskmanagement.model.TaskAssignment createTaskAssignment(
		long taskAssignmentId) {
		return _taskAssignmentLocalService.createTaskAssignment(taskAssignmentId);
	}

	/**
	* Deletes the task assignment with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param taskAssignmentId the primary key of the task assignment
	* @return the task assignment that was removed
	* @throws PortalException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.jioc.taskmanagement.model.TaskAssignment deleteTaskAssignment(
		long taskAssignmentId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.deleteTaskAssignment(taskAssignmentId);
	}

	/**
	* Deletes the task assignment from the database. Also notifies the appropriate model listeners.
	*
	* @param taskAssignment the task assignment
	* @return the task assignment that was removed
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.jioc.taskmanagement.model.TaskAssignment deleteTaskAssignment(
		com.jioc.taskmanagement.model.TaskAssignment taskAssignment)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.deleteTaskAssignment(taskAssignment);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _taskAssignmentLocalService.dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.dynamicQuery(dynamicQuery, start,
			end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.dynamicQueryCount(dynamicQuery,
			projection);
	}

	@Override
	public com.jioc.taskmanagement.model.TaskAssignment fetchTaskAssignment(
		long taskAssignmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.fetchTaskAssignment(taskAssignmentId);
	}

	/**
	* Returns the task assignment with the primary key.
	*
	* @param taskAssignmentId the primary key of the task assignment
	* @return the task assignment
	* @throws PortalException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.jioc.taskmanagement.model.TaskAssignment getTaskAssignment(
		long taskAssignmentId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.getTaskAssignment(taskAssignmentId);
	}

	@Override
	public com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the task assignments.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @return the range of task assignments
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> getTaskAssignments(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.getTaskAssignments(start, end);
	}

	/**
	* Returns the number of task assignments.
	*
	* @return the number of task assignments
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getTaskAssignmentsCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.getTaskAssignmentsCount();
	}

	/**
	* Updates the task assignment in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param taskAssignment the task assignment
	* @return the task assignment that was updated
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.jioc.taskmanagement.model.TaskAssignment updateTaskAssignment(
		com.jioc.taskmanagement.model.TaskAssignment taskAssignment)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.updateTaskAssignment(taskAssignment);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _taskAssignmentLocalService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_taskAssignmentLocalService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _taskAssignmentLocalService.invokeMethod(name, parameterTypes,
			arguments);
	}

	@Override
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> getAssigneeUserByMe(
		long taskId) {
		return _taskAssignmentLocalService.getAssigneeUserByMe(taskId);
	}

	@Override
	public com.jioc.taskmanagement.model.TaskAssignment getTaskDetailsAssignToMe(
		long taskId, long assignByUserId) {
		return _taskAssignmentLocalService.getTaskDetailsAssignToMe(taskId,
			assignByUserId);
	}

	@Override
	public com.jioc.taskmanagement.model.TaskAssignment getAvailableAssignee(
		long taskId, long assignToUserId) {
		return _taskAssignmentLocalService.getAvailableAssignee(taskId,
			assignToUserId);
	}

	@Override
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> getAllTaskAssignToMeByStatusAndDate(
		long assignToUserId, java.lang.String status,
		java.lang.String fromDate, java.lang.String toDate) {
		return _taskAssignmentLocalService.getAllTaskAssignToMeByStatusAndDate(assignToUserId,
			status, fromDate, toDate);
	}

	@Override
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> getAssignToUserIdAndAssigneeTaskId(
		long assignToUserId, long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.getAssignToUserIdAndAssigneeTaskId(assignToUserId,
			assigneeTaskId);
	}

	@Override
	public com.jioc.taskmanagement.model.TaskAssignment getByTaskAndAssigneeTaskId(
		long taskId, long assignToUserId, long assigneeTaskId)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.getByTaskAndAssigneeTaskId(taskId,
			assignToUserId, assigneeTaskId);
	}

	@Override
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> getStatusByAssigneeTaskId(
		long assigneeTaskId, java.lang.String status)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.getStatusByAssigneeTaskId(assigneeTaskId,
			status);
	}

	@Override
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> getTasksByAssigneetaskId(
		long assigneeTaskId, java.lang.String status)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.getTasksByAssigneetaskId(assigneeTaskId,
			status);
	}

	@Override
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> getAssignmentsByAssigneetaskId(
		long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.getAssignmentsByAssigneetaskId(assigneeTaskId);
	}

	@Override
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> getAllTaskAssignToMeByStatusWithDate(
		long assignToUserId, java.lang.String final_status,
		java.lang.String fromDate, java.lang.String toDate) {
		return _taskAssignmentLocalService.getAllTaskAssignToMeByStatusWithDate(assignToUserId,
			final_status, fromDate, toDate);
	}

	@Override
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> getAllTaskAssignByMeByStatusWithDate(
		long assignByUserId, java.lang.String final_status,
		java.lang.String fromDate, java.lang.String toDate) {
		return _taskAssignmentLocalService.getAllTaskAssignByMeByStatusWithDate(assignByUserId,
			final_status, fromDate, toDate);
	}

	@Override
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> getAllTasksAssignToMeByStatus(
		long assignToUserId, java.lang.String final_status) {
		return _taskAssignmentLocalService.getAllTasksAssignToMeByStatus(assignToUserId,
			final_status);
	}

	@Override
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> getAllTasksAssignByMeByStatus(
		long assignByUserId, java.lang.String final_status) {
		return _taskAssignmentLocalService.getAllTasksAssignByMeByStatus(assignByUserId,
			final_status);
	}

	@Override
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> getAllTasksAssignToMeWithDate(
		long assignToUserId, java.lang.String fromDate, java.lang.String toDate) {
		return _taskAssignmentLocalService.getAllTasksAssignToMeWithDate(assignToUserId,
			fromDate, toDate);
	}

	@Override
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> getAllTasksAssignByMeWithDate(
		long assignByUserId, java.lang.String fromDate, java.lang.String toDate) {
		return _taskAssignmentLocalService.getAllTasksAssignByMeWithDate(assignByUserId,
			fromDate, toDate);
	}

	@Override
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> getAllTaskAssignToMe(
		long userId) {
		return _taskAssignmentLocalService.getAllTaskAssignToMe(userId);
	}

	@Override
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> getAllTasksAssignByMe(
		long assignByUserId) {
		return _taskAssignmentLocalService.getAllTasksAssignByMe(assignByUserId);
	}

	@Override
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> getAssignmentsByTaskIdAndStatus(
		long taskId, java.lang.String status)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignmentLocalService.getAssignmentsByTaskIdAndStatus(taskId,
			status);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public TaskAssignmentLocalService getWrappedTaskAssignmentLocalService() {
		return _taskAssignmentLocalService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedTaskAssignmentLocalService(
		TaskAssignmentLocalService taskAssignmentLocalService) {
		_taskAssignmentLocalService = taskAssignmentLocalService;
	}

	@Override
	public TaskAssignmentLocalService getWrappedService() {
		return _taskAssignmentLocalService;
	}

	@Override
	public void setWrappedService(
		TaskAssignmentLocalService taskAssignmentLocalService) {
		_taskAssignmentLocalService = taskAssignmentLocalService;
	}

	private TaskAssignmentLocalService _taskAssignmentLocalService;
}