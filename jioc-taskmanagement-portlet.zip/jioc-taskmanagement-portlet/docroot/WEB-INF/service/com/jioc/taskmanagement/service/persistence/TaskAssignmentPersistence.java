/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.taskmanagement.service.persistence;

import com.jioc.taskmanagement.model.TaskAssignment;

import com.liferay.portal.service.persistence.BasePersistence;

/**
 * The persistence interface for the task assignment service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author rajnikant.donga
 * @see TaskAssignmentPersistenceImpl
 * @see TaskAssignmentUtil
 * @generated
 */
public interface TaskAssignmentPersistence extends BasePersistence<TaskAssignment> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link TaskAssignmentUtil} to access the task assignment persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the task assignments where taskId = &#63;.
	*
	* @param taskId the task ID
	* @return the matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssigneeUser(
		long taskId) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the task assignments where taskId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param taskId the task ID
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @return the range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssigneeUser(
		long taskId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the task assignments where taskId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param taskId the task ID
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssigneeUser(
		long taskId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first task assignment in the ordered set where taskId = &#63;.
	*
	* @param taskId the task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment findByAssigneeUser_First(
		long taskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first task assignment in the ordered set where taskId = &#63;.
	*
	* @param taskId the task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByAssigneeUser_First(
		long taskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last task assignment in the ordered set where taskId = &#63;.
	*
	* @param taskId the task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment findByAssigneeUser_Last(
		long taskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last task assignment in the ordered set where taskId = &#63;.
	*
	* @param taskId the task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByAssigneeUser_Last(
		long taskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task assignments before and after the current task assignment in the ordered set where taskId = &#63;.
	*
	* @param taskAssignmentId the primary key of the current task assignment
	* @param taskId the task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment[] findByAssigneeUser_PrevAndNext(
		long taskAssignmentId, long taskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the task assignments where taskId = &#63; from the database.
	*
	* @param taskId the task ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByAssigneeUser(long taskId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of task assignments where taskId = &#63;.
	*
	* @param taskId the task ID
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public int countByAssigneeUser(long taskId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the task assignments where assignToUserId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @return the matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignToUser(
		long assignToUserId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the task assignments where assignToUserId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param assignToUserId the assign to user ID
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @return the range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignToUser(
		long assignToUserId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the task assignments where assignToUserId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param assignToUserId the assign to user ID
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignToUser(
		long assignToUserId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first task assignment in the ordered set where assignToUserId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment findByAssignToUser_First(
		long assignToUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first task assignment in the ordered set where assignToUserId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByAssignToUser_First(
		long assignToUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last task assignment in the ordered set where assignToUserId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment findByAssignToUser_Last(
		long assignToUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last task assignment in the ordered set where assignToUserId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByAssignToUser_Last(
		long assignToUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task assignments before and after the current task assignment in the ordered set where assignToUserId = &#63;.
	*
	* @param taskAssignmentId the primary key of the current task assignment
	* @param assignToUserId the assign to user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment[] findByAssignToUser_PrevAndNext(
		long taskAssignmentId, long assignToUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the task assignments where assignToUserId = &#63; from the database.
	*
	* @param assignToUserId the assign to user ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByAssignToUser(long assignToUserId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of task assignments where assignToUserId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public int countByAssignToUser(long assignToUserId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task assignment where taskId = &#63; and assignByUserId = &#63; or throws a {@link com.jioc.taskmanagement.NoSuchTaskAssignmentException} if it could not be found.
	*
	* @param taskId the task ID
	* @param assignByUserId the assign by user ID
	* @return the matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment findByTaskDetailAssignToMe(
		long taskId, long assignByUserId)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task assignment where taskId = &#63; and assignByUserId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param taskId the task ID
	* @param assignByUserId the assign by user ID
	* @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByTaskDetailAssignToMe(
		long taskId, long assignByUserId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task assignment where taskId = &#63; and assignByUserId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param taskId the task ID
	* @param assignByUserId the assign by user ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByTaskDetailAssignToMe(
		long taskId, long assignByUserId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the task assignment where taskId = &#63; and assignByUserId = &#63; from the database.
	*
	* @param taskId the task ID
	* @param assignByUserId the assign by user ID
	* @return the task assignment that was removed
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment removeByTaskDetailAssignToMe(
		long taskId, long assignByUserId)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of task assignments where taskId = &#63; and assignByUserId = &#63;.
	*
	* @param taskId the task ID
	* @param assignByUserId the assign by user ID
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public int countByTaskDetailAssignToMe(long taskId, long assignByUserId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task assignment where taskId = &#63; and assignToUserId = &#63; or throws a {@link com.jioc.taskmanagement.NoSuchTaskAssignmentException} if it could not be found.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @return the matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment findByAvailableAssignee(
		long taskId, long assignToUserId)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task assignment where taskId = &#63; and assignToUserId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByAvailableAssignee(
		long taskId, long assignToUserId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task assignment where taskId = &#63; and assignToUserId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByAvailableAssignee(
		long taskId, long assignToUserId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the task assignment where taskId = &#63; and assignToUserId = &#63; from the database.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @return the task assignment that was removed
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment removeByAvailableAssignee(
		long taskId, long assignToUserId)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of task assignments where taskId = &#63; and assignToUserId = &#63;.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public int countByAvailableAssignee(long taskId, long assignToUserId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the task assignments where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @return the matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignToUserIdAndAssigneeTaskId(
		long assignToUserId, long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the task assignments where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @return the range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignToUserIdAndAssigneeTaskId(
		long assignToUserId, long assigneeTaskId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the task assignments where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignToUserIdAndAssigneeTaskId(
		long assignToUserId, long assigneeTaskId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first task assignment in the ordered set where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment findByAssignToUserIdAndAssigneeTaskId_First(
		long assignToUserId, long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first task assignment in the ordered set where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByAssignToUserIdAndAssigneeTaskId_First(
		long assignToUserId, long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last task assignment in the ordered set where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment findByAssignToUserIdAndAssigneeTaskId_Last(
		long assignToUserId, long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last task assignment in the ordered set where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByAssignToUserIdAndAssigneeTaskId_Last(
		long assignToUserId, long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task assignments before and after the current task assignment in the ordered set where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* @param taskAssignmentId the primary key of the current task assignment
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment[] findByAssignToUserIdAndAssigneeTaskId_PrevAndNext(
		long taskAssignmentId, long assignToUserId, long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the task assignments where assignToUserId = &#63; and assigneeTaskId = &#63; from the database.
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByAssignToUserIdAndAssigneeTaskId(long assignToUserId,
		long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of task assignments where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public int countByAssignToUserIdAndAssigneeTaskId(long assignToUserId,
		long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task assignment where taskId = &#63; and assignToUserId = &#63; and assigneeTaskId = &#63; or throws a {@link com.jioc.taskmanagement.NoSuchTaskAssignmentException} if it could not be found.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @return the matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment findByTaskAndAssigneeTaskId(
		long taskId, long assignToUserId, long assigneeTaskId)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task assignment where taskId = &#63; and assignToUserId = &#63; and assigneeTaskId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByTaskAndAssigneeTaskId(
		long taskId, long assignToUserId, long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task assignment where taskId = &#63; and assignToUserId = &#63; and assigneeTaskId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByTaskAndAssigneeTaskId(
		long taskId, long assignToUserId, long assigneeTaskId,
		boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the task assignment where taskId = &#63; and assignToUserId = &#63; and assigneeTaskId = &#63; from the database.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @return the task assignment that was removed
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment removeByTaskAndAssigneeTaskId(
		long taskId, long assignToUserId, long assigneeTaskId)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of task assignments where taskId = &#63; and assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public int countByTaskAndAssigneeTaskId(long taskId, long assignToUserId,
		long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the task assignments where assigneeTaskId = &#63; and status = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @return the matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByStatusByAssigneeTaskId(
		long assigneeTaskId, java.lang.String status)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the task assignments where assigneeTaskId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @return the range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByStatusByAssigneeTaskId(
		long assigneeTaskId, java.lang.String status, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the task assignments where assigneeTaskId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByStatusByAssigneeTaskId(
		long assigneeTaskId, java.lang.String status, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first task assignment in the ordered set where assigneeTaskId = &#63; and status = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment findByStatusByAssigneeTaskId_First(
		long assigneeTaskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first task assignment in the ordered set where assigneeTaskId = &#63; and status = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByStatusByAssigneeTaskId_First(
		long assigneeTaskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last task assignment in the ordered set where assigneeTaskId = &#63; and status = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment findByStatusByAssigneeTaskId_Last(
		long assigneeTaskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last task assignment in the ordered set where assigneeTaskId = &#63; and status = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByStatusByAssigneeTaskId_Last(
		long assigneeTaskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task assignments before and after the current task assignment in the ordered set where assigneeTaskId = &#63; and status = &#63;.
	*
	* @param taskAssignmentId the primary key of the current task assignment
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment[] findByStatusByAssigneeTaskId_PrevAndNext(
		long taskAssignmentId, long assigneeTaskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the task assignments where assigneeTaskId = &#63; and status = &#63; from the database.
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @throws SystemException if a system exception occurred
	*/
	public void removeByStatusByAssigneeTaskId(long assigneeTaskId,
		java.lang.String status)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of task assignments where assigneeTaskId = &#63; and status = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public int countByStatusByAssigneeTaskId(long assigneeTaskId,
		java.lang.String status)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the task assignments where assigneeTaskId = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @return the matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignmentsByAssigneetaskId(
		long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the task assignments where assigneeTaskId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param assigneeTaskId the assignee task ID
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @return the range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignmentsByAssigneetaskId(
		long assigneeTaskId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the task assignments where assigneeTaskId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param assigneeTaskId the assignee task ID
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignmentsByAssigneetaskId(
		long assigneeTaskId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first task assignment in the ordered set where assigneeTaskId = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment findByAssignmentsByAssigneetaskId_First(
		long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first task assignment in the ordered set where assigneeTaskId = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByAssignmentsByAssigneetaskId_First(
		long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last task assignment in the ordered set where assigneeTaskId = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment findByAssignmentsByAssigneetaskId_Last(
		long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last task assignment in the ordered set where assigneeTaskId = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByAssignmentsByAssigneetaskId_Last(
		long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task assignments before and after the current task assignment in the ordered set where assigneeTaskId = &#63;.
	*
	* @param taskAssignmentId the primary key of the current task assignment
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment[] findByAssignmentsByAssigneetaskId_PrevAndNext(
		long taskAssignmentId, long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the task assignments where assigneeTaskId = &#63; from the database.
	*
	* @param assigneeTaskId the assignee task ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByAssignmentsByAssigneetaskId(long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of task assignments where assigneeTaskId = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public int countByAssignmentsByAssigneetaskId(long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the task assignments where taskId = &#63; and status = &#63;.
	*
	* @param taskId the task ID
	* @param status the status
	* @return the matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignmentsByTaskIdAndStatus(
		long taskId, java.lang.String status)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the task assignments where taskId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param taskId the task ID
	* @param status the status
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @return the range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignmentsByTaskIdAndStatus(
		long taskId, java.lang.String status, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the task assignments where taskId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param taskId the task ID
	* @param status the status
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignmentsByTaskIdAndStatus(
		long taskId, java.lang.String status, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first task assignment in the ordered set where taskId = &#63; and status = &#63;.
	*
	* @param taskId the task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment findByAssignmentsByTaskIdAndStatus_First(
		long taskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first task assignment in the ordered set where taskId = &#63; and status = &#63;.
	*
	* @param taskId the task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByAssignmentsByTaskIdAndStatus_First(
		long taskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last task assignment in the ordered set where taskId = &#63; and status = &#63;.
	*
	* @param taskId the task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment findByAssignmentsByTaskIdAndStatus_Last(
		long taskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last task assignment in the ordered set where taskId = &#63; and status = &#63;.
	*
	* @param taskId the task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByAssignmentsByTaskIdAndStatus_Last(
		long taskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task assignments before and after the current task assignment in the ordered set where taskId = &#63; and status = &#63;.
	*
	* @param taskAssignmentId the primary key of the current task assignment
	* @param taskId the task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment[] findByAssignmentsByTaskIdAndStatus_PrevAndNext(
		long taskAssignmentId, long taskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the task assignments where taskId = &#63; and status = &#63; from the database.
	*
	* @param taskId the task ID
	* @param status the status
	* @throws SystemException if a system exception occurred
	*/
	public void removeByAssignmentsByTaskIdAndStatus(long taskId,
		java.lang.String status)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of task assignments where taskId = &#63; and status = &#63;.
	*
	* @param taskId the task ID
	* @param status the status
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public int countByAssignmentsByTaskIdAndStatus(long taskId,
		java.lang.String status)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the task assignment in the entity cache if it is enabled.
	*
	* @param taskAssignment the task assignment
	*/
	public void cacheResult(
		com.jioc.taskmanagement.model.TaskAssignment taskAssignment);

	/**
	* Caches the task assignments in the entity cache if it is enabled.
	*
	* @param taskAssignments the task assignments
	*/
	public void cacheResult(
		java.util.List<com.jioc.taskmanagement.model.TaskAssignment> taskAssignments);

	/**
	* Creates a new task assignment with the primary key. Does not add the task assignment to the database.
	*
	* @param taskAssignmentId the primary key for the new task assignment
	* @return the new task assignment
	*/
	public com.jioc.taskmanagement.model.TaskAssignment create(
		long taskAssignmentId);

	/**
	* Removes the task assignment with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param taskAssignmentId the primary key of the task assignment
	* @return the task assignment that was removed
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment remove(
		long taskAssignmentId)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	public com.jioc.taskmanagement.model.TaskAssignment updateImpl(
		com.jioc.taskmanagement.model.TaskAssignment taskAssignment)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task assignment with the primary key or throws a {@link com.jioc.taskmanagement.NoSuchTaskAssignmentException} if it could not be found.
	*
	* @param taskAssignmentId the primary key of the task assignment
	* @return the task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment findByPrimaryKey(
		long taskAssignmentId)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the task assignment with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param taskAssignmentId the primary key of the task assignment
	* @return the task assignment, or <code>null</code> if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.jioc.taskmanagement.model.TaskAssignment fetchByPrimaryKey(
		long taskAssignmentId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the task assignments.
	*
	* @return the task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the task assignments.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @return the range of task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the task assignments.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of task assignments
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the task assignments from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of task assignments.
	*
	* @return the number of task assignments
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}