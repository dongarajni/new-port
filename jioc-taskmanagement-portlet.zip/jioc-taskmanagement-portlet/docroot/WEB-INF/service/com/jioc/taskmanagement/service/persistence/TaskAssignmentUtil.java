/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.taskmanagement.service.persistence;

import com.jioc.taskmanagement.model.TaskAssignment;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import java.util.List;

/**
 * The persistence utility for the task assignment service. This utility wraps {@link TaskAssignmentPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author rajnikant.donga
 * @see TaskAssignmentPersistence
 * @see TaskAssignmentPersistenceImpl
 * @generated
 */
public class TaskAssignmentUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(TaskAssignment taskAssignment) {
		getPersistence().clearCache(taskAssignment);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<TaskAssignment> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<TaskAssignment> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<TaskAssignment> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static TaskAssignment update(TaskAssignment taskAssignment)
		throws SystemException {
		return getPersistence().update(taskAssignment);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static TaskAssignment update(TaskAssignment taskAssignment,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(taskAssignment, serviceContext);
	}

	/**
	* Returns all the task assignments where taskId = &#63;.
	*
	* @param taskId the task ID
	* @return the matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssigneeUser(
		long taskId) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByAssigneeUser(taskId);
	}

	/**
	* Returns a range of all the task assignments where taskId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param taskId the task ID
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @return the range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssigneeUser(
		long taskId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByAssigneeUser(taskId, start, end);
	}

	/**
	* Returns an ordered range of all the task assignments where taskId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param taskId the task ID
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssigneeUser(
		long taskId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssigneeUser(taskId, start, end, orderByComparator);
	}

	/**
	* Returns the first task assignment in the ordered set where taskId = &#63;.
	*
	* @param taskId the task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment findByAssigneeUser_First(
		long taskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssigneeUser_First(taskId, orderByComparator);
	}

	/**
	* Returns the first task assignment in the ordered set where taskId = &#63;.
	*
	* @param taskId the task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByAssigneeUser_First(
		long taskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAssigneeUser_First(taskId, orderByComparator);
	}

	/**
	* Returns the last task assignment in the ordered set where taskId = &#63;.
	*
	* @param taskId the task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment findByAssigneeUser_Last(
		long taskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssigneeUser_Last(taskId, orderByComparator);
	}

	/**
	* Returns the last task assignment in the ordered set where taskId = &#63;.
	*
	* @param taskId the task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByAssigneeUser_Last(
		long taskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAssigneeUser_Last(taskId, orderByComparator);
	}

	/**
	* Returns the task assignments before and after the current task assignment in the ordered set where taskId = &#63;.
	*
	* @param taskAssignmentId the primary key of the current task assignment
	* @param taskId the task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment[] findByAssigneeUser_PrevAndNext(
		long taskAssignmentId, long taskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssigneeUser_PrevAndNext(taskAssignmentId, taskId,
			orderByComparator);
	}

	/**
	* Removes all the task assignments where taskId = &#63; from the database.
	*
	* @param taskId the task ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByAssigneeUser(long taskId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByAssigneeUser(taskId);
	}

	/**
	* Returns the number of task assignments where taskId = &#63;.
	*
	* @param taskId the task ID
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static int countByAssigneeUser(long taskId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByAssigneeUser(taskId);
	}

	/**
	* Returns all the task assignments where assignToUserId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @return the matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignToUser(
		long assignToUserId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByAssignToUser(assignToUserId);
	}

	/**
	* Returns a range of all the task assignments where assignToUserId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param assignToUserId the assign to user ID
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @return the range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignToUser(
		long assignToUserId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByAssignToUser(assignToUserId, start, end);
	}

	/**
	* Returns an ordered range of all the task assignments where assignToUserId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param assignToUserId the assign to user ID
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignToUser(
		long assignToUserId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignToUser(assignToUserId, start, end,
			orderByComparator);
	}

	/**
	* Returns the first task assignment in the ordered set where assignToUserId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment findByAssignToUser_First(
		long assignToUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignToUser_First(assignToUserId, orderByComparator);
	}

	/**
	* Returns the first task assignment in the ordered set where assignToUserId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByAssignToUser_First(
		long assignToUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAssignToUser_First(assignToUserId, orderByComparator);
	}

	/**
	* Returns the last task assignment in the ordered set where assignToUserId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment findByAssignToUser_Last(
		long assignToUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignToUser_Last(assignToUserId, orderByComparator);
	}

	/**
	* Returns the last task assignment in the ordered set where assignToUserId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByAssignToUser_Last(
		long assignToUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAssignToUser_Last(assignToUserId, orderByComparator);
	}

	/**
	* Returns the task assignments before and after the current task assignment in the ordered set where assignToUserId = &#63;.
	*
	* @param taskAssignmentId the primary key of the current task assignment
	* @param assignToUserId the assign to user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment[] findByAssignToUser_PrevAndNext(
		long taskAssignmentId, long assignToUserId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignToUser_PrevAndNext(taskAssignmentId,
			assignToUserId, orderByComparator);
	}

	/**
	* Removes all the task assignments where assignToUserId = &#63; from the database.
	*
	* @param assignToUserId the assign to user ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByAssignToUser(long assignToUserId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByAssignToUser(assignToUserId);
	}

	/**
	* Returns the number of task assignments where assignToUserId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static int countByAssignToUser(long assignToUserId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByAssignToUser(assignToUserId);
	}

	/**
	* Returns the task assignment where taskId = &#63; and assignByUserId = &#63; or throws a {@link com.jioc.taskmanagement.NoSuchTaskAssignmentException} if it could not be found.
	*
	* @param taskId the task ID
	* @param assignByUserId the assign by user ID
	* @return the matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment findByTaskDetailAssignToMe(
		long taskId, long assignByUserId)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByTaskDetailAssignToMe(taskId, assignByUserId);
	}

	/**
	* Returns the task assignment where taskId = &#63; and assignByUserId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param taskId the task ID
	* @param assignByUserId the assign by user ID
	* @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByTaskDetailAssignToMe(
		long taskId, long assignByUserId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByTaskDetailAssignToMe(taskId, assignByUserId);
	}

	/**
	* Returns the task assignment where taskId = &#63; and assignByUserId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param taskId the task ID
	* @param assignByUserId the assign by user ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByTaskDetailAssignToMe(
		long taskId, long assignByUserId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByTaskDetailAssignToMe(taskId, assignByUserId,
			retrieveFromCache);
	}

	/**
	* Removes the task assignment where taskId = &#63; and assignByUserId = &#63; from the database.
	*
	* @param taskId the task ID
	* @param assignByUserId the assign by user ID
	* @return the task assignment that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment removeByTaskDetailAssignToMe(
		long taskId, long assignByUserId)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .removeByTaskDetailAssignToMe(taskId, assignByUserId);
	}

	/**
	* Returns the number of task assignments where taskId = &#63; and assignByUserId = &#63;.
	*
	* @param taskId the task ID
	* @param assignByUserId the assign by user ID
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static int countByTaskDetailAssignToMe(long taskId,
		long assignByUserId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .countByTaskDetailAssignToMe(taskId, assignByUserId);
	}

	/**
	* Returns the task assignment where taskId = &#63; and assignToUserId = &#63; or throws a {@link com.jioc.taskmanagement.NoSuchTaskAssignmentException} if it could not be found.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @return the matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment findByAvailableAssignee(
		long taskId, long assignToUserId)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByAvailableAssignee(taskId, assignToUserId);
	}

	/**
	* Returns the task assignment where taskId = &#63; and assignToUserId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByAvailableAssignee(
		long taskId, long assignToUserId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByAvailableAssignee(taskId, assignToUserId);
	}

	/**
	* Returns the task assignment where taskId = &#63; and assignToUserId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByAvailableAssignee(
		long taskId, long assignToUserId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAvailableAssignee(taskId, assignToUserId,
			retrieveFromCache);
	}

	/**
	* Removes the task assignment where taskId = &#63; and assignToUserId = &#63; from the database.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @return the task assignment that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment removeByAvailableAssignee(
		long taskId, long assignToUserId)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().removeByAvailableAssignee(taskId, assignToUserId);
	}

	/**
	* Returns the number of task assignments where taskId = &#63; and assignToUserId = &#63;.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static int countByAvailableAssignee(long taskId, long assignToUserId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByAvailableAssignee(taskId, assignToUserId);
	}

	/**
	* Returns all the task assignments where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @return the matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignToUserIdAndAssigneeTaskId(
		long assignToUserId, long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignToUserIdAndAssigneeTaskId(assignToUserId,
			assigneeTaskId);
	}

	/**
	* Returns a range of all the task assignments where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @return the range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignToUserIdAndAssigneeTaskId(
		long assignToUserId, long assigneeTaskId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignToUserIdAndAssigneeTaskId(assignToUserId,
			assigneeTaskId, start, end);
	}

	/**
	* Returns an ordered range of all the task assignments where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignToUserIdAndAssigneeTaskId(
		long assignToUserId, long assigneeTaskId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignToUserIdAndAssigneeTaskId(assignToUserId,
			assigneeTaskId, start, end, orderByComparator);
	}

	/**
	* Returns the first task assignment in the ordered set where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment findByAssignToUserIdAndAssigneeTaskId_First(
		long assignToUserId, long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignToUserIdAndAssigneeTaskId_First(assignToUserId,
			assigneeTaskId, orderByComparator);
	}

	/**
	* Returns the first task assignment in the ordered set where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByAssignToUserIdAndAssigneeTaskId_First(
		long assignToUserId, long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAssignToUserIdAndAssigneeTaskId_First(assignToUserId,
			assigneeTaskId, orderByComparator);
	}

	/**
	* Returns the last task assignment in the ordered set where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment findByAssignToUserIdAndAssigneeTaskId_Last(
		long assignToUserId, long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignToUserIdAndAssigneeTaskId_Last(assignToUserId,
			assigneeTaskId, orderByComparator);
	}

	/**
	* Returns the last task assignment in the ordered set where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByAssignToUserIdAndAssigneeTaskId_Last(
		long assignToUserId, long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAssignToUserIdAndAssigneeTaskId_Last(assignToUserId,
			assigneeTaskId, orderByComparator);
	}

	/**
	* Returns the task assignments before and after the current task assignment in the ordered set where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* @param taskAssignmentId the primary key of the current task assignment
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment[] findByAssignToUserIdAndAssigneeTaskId_PrevAndNext(
		long taskAssignmentId, long assignToUserId, long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignToUserIdAndAssigneeTaskId_PrevAndNext(taskAssignmentId,
			assignToUserId, assigneeTaskId, orderByComparator);
	}

	/**
	* Removes all the task assignments where assignToUserId = &#63; and assigneeTaskId = &#63; from the database.
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByAssignToUserIdAndAssigneeTaskId(
		long assignToUserId, long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence()
			.removeByAssignToUserIdAndAssigneeTaskId(assignToUserId,
			assigneeTaskId);
	}

	/**
	* Returns the number of task assignments where assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static int countByAssignToUserIdAndAssigneeTaskId(
		long assignToUserId, long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .countByAssignToUserIdAndAssigneeTaskId(assignToUserId,
			assigneeTaskId);
	}

	/**
	* Returns the task assignment where taskId = &#63; and assignToUserId = &#63; and assigneeTaskId = &#63; or throws a {@link com.jioc.taskmanagement.NoSuchTaskAssignmentException} if it could not be found.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @return the matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment findByTaskAndAssigneeTaskId(
		long taskId, long assignToUserId, long assigneeTaskId)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByTaskAndAssigneeTaskId(taskId, assignToUserId,
			assigneeTaskId);
	}

	/**
	* Returns the task assignment where taskId = &#63; and assignToUserId = &#63; and assigneeTaskId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByTaskAndAssigneeTaskId(
		long taskId, long assignToUserId, long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByTaskAndAssigneeTaskId(taskId, assignToUserId,
			assigneeTaskId);
	}

	/**
	* Returns the task assignment where taskId = &#63; and assignToUserId = &#63; and assigneeTaskId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByTaskAndAssigneeTaskId(
		long taskId, long assignToUserId, long assigneeTaskId,
		boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByTaskAndAssigneeTaskId(taskId, assignToUserId,
			assigneeTaskId, retrieveFromCache);
	}

	/**
	* Removes the task assignment where taskId = &#63; and assignToUserId = &#63; and assigneeTaskId = &#63; from the database.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @return the task assignment that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment removeByTaskAndAssigneeTaskId(
		long taskId, long assignToUserId, long assigneeTaskId)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .removeByTaskAndAssigneeTaskId(taskId, assignToUserId,
			assigneeTaskId);
	}

	/**
	* Returns the number of task assignments where taskId = &#63; and assignToUserId = &#63; and assigneeTaskId = &#63;.
	*
	* @param taskId the task ID
	* @param assignToUserId the assign to user ID
	* @param assigneeTaskId the assignee task ID
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static int countByTaskAndAssigneeTaskId(long taskId,
		long assignToUserId, long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .countByTaskAndAssigneeTaskId(taskId, assignToUserId,
			assigneeTaskId);
	}

	/**
	* Returns all the task assignments where assigneeTaskId = &#63; and status = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @return the matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByStatusByAssigneeTaskId(
		long assigneeTaskId, java.lang.String status)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByStatusByAssigneeTaskId(assigneeTaskId, status);
	}

	/**
	* Returns a range of all the task assignments where assigneeTaskId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @return the range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByStatusByAssigneeTaskId(
		long assigneeTaskId, java.lang.String status, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByStatusByAssigneeTaskId(assigneeTaskId, status, start,
			end);
	}

	/**
	* Returns an ordered range of all the task assignments where assigneeTaskId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByStatusByAssigneeTaskId(
		long assigneeTaskId, java.lang.String status, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByStatusByAssigneeTaskId(assigneeTaskId, status, start,
			end, orderByComparator);
	}

	/**
	* Returns the first task assignment in the ordered set where assigneeTaskId = &#63; and status = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment findByStatusByAssigneeTaskId_First(
		long assigneeTaskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByStatusByAssigneeTaskId_First(assigneeTaskId, status,
			orderByComparator);
	}

	/**
	* Returns the first task assignment in the ordered set where assigneeTaskId = &#63; and status = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByStatusByAssigneeTaskId_First(
		long assigneeTaskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByStatusByAssigneeTaskId_First(assigneeTaskId, status,
			orderByComparator);
	}

	/**
	* Returns the last task assignment in the ordered set where assigneeTaskId = &#63; and status = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment findByStatusByAssigneeTaskId_Last(
		long assigneeTaskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByStatusByAssigneeTaskId_Last(assigneeTaskId, status,
			orderByComparator);
	}

	/**
	* Returns the last task assignment in the ordered set where assigneeTaskId = &#63; and status = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByStatusByAssigneeTaskId_Last(
		long assigneeTaskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByStatusByAssigneeTaskId_Last(assigneeTaskId, status,
			orderByComparator);
	}

	/**
	* Returns the task assignments before and after the current task assignment in the ordered set where assigneeTaskId = &#63; and status = &#63;.
	*
	* @param taskAssignmentId the primary key of the current task assignment
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment[] findByStatusByAssigneeTaskId_PrevAndNext(
		long taskAssignmentId, long assigneeTaskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByStatusByAssigneeTaskId_PrevAndNext(taskAssignmentId,
			assigneeTaskId, status, orderByComparator);
	}

	/**
	* Removes all the task assignments where assigneeTaskId = &#63; and status = &#63; from the database.
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByStatusByAssigneeTaskId(long assigneeTaskId,
		java.lang.String status)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByStatusByAssigneeTaskId(assigneeTaskId, status);
	}

	/**
	* Returns the number of task assignments where assigneeTaskId = &#63; and status = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param status the status
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static int countByStatusByAssigneeTaskId(long assigneeTaskId,
		java.lang.String status)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .countByStatusByAssigneeTaskId(assigneeTaskId, status);
	}

	/**
	* Returns all the task assignments where assigneeTaskId = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @return the matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignmentsByAssigneetaskId(
		long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByAssignmentsByAssigneetaskId(assigneeTaskId);
	}

	/**
	* Returns a range of all the task assignments where assigneeTaskId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param assigneeTaskId the assignee task ID
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @return the range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignmentsByAssigneetaskId(
		long assigneeTaskId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignmentsByAssigneetaskId(assigneeTaskId, start, end);
	}

	/**
	* Returns an ordered range of all the task assignments where assigneeTaskId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param assigneeTaskId the assignee task ID
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignmentsByAssigneetaskId(
		long assigneeTaskId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignmentsByAssigneetaskId(assigneeTaskId, start,
			end, orderByComparator);
	}

	/**
	* Returns the first task assignment in the ordered set where assigneeTaskId = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment findByAssignmentsByAssigneetaskId_First(
		long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignmentsByAssigneetaskId_First(assigneeTaskId,
			orderByComparator);
	}

	/**
	* Returns the first task assignment in the ordered set where assigneeTaskId = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByAssignmentsByAssigneetaskId_First(
		long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAssignmentsByAssigneetaskId_First(assigneeTaskId,
			orderByComparator);
	}

	/**
	* Returns the last task assignment in the ordered set where assigneeTaskId = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment findByAssignmentsByAssigneetaskId_Last(
		long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignmentsByAssigneetaskId_Last(assigneeTaskId,
			orderByComparator);
	}

	/**
	* Returns the last task assignment in the ordered set where assigneeTaskId = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByAssignmentsByAssigneetaskId_Last(
		long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAssignmentsByAssigneetaskId_Last(assigneeTaskId,
			orderByComparator);
	}

	/**
	* Returns the task assignments before and after the current task assignment in the ordered set where assigneeTaskId = &#63;.
	*
	* @param taskAssignmentId the primary key of the current task assignment
	* @param assigneeTaskId the assignee task ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment[] findByAssignmentsByAssigneetaskId_PrevAndNext(
		long taskAssignmentId, long assigneeTaskId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignmentsByAssigneetaskId_PrevAndNext(taskAssignmentId,
			assigneeTaskId, orderByComparator);
	}

	/**
	* Removes all the task assignments where assigneeTaskId = &#63; from the database.
	*
	* @param assigneeTaskId the assignee task ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByAssignmentsByAssigneetaskId(long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByAssignmentsByAssigneetaskId(assigneeTaskId);
	}

	/**
	* Returns the number of task assignments where assigneeTaskId = &#63;.
	*
	* @param assigneeTaskId the assignee task ID
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static int countByAssignmentsByAssigneetaskId(long assigneeTaskId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .countByAssignmentsByAssigneetaskId(assigneeTaskId);
	}

	/**
	* Returns all the task assignments where taskId = &#63; and status = &#63;.
	*
	* @param taskId the task ID
	* @param status the status
	* @return the matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignmentsByTaskIdAndStatus(
		long taskId, java.lang.String status)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignmentsByTaskIdAndStatus(taskId, status);
	}

	/**
	* Returns a range of all the task assignments where taskId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param taskId the task ID
	* @param status the status
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @return the range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignmentsByTaskIdAndStatus(
		long taskId, java.lang.String status, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignmentsByTaskIdAndStatus(taskId, status, start,
			end);
	}

	/**
	* Returns an ordered range of all the task assignments where taskId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param taskId the task ID
	* @param status the status
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findByAssignmentsByTaskIdAndStatus(
		long taskId, java.lang.String status, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignmentsByTaskIdAndStatus(taskId, status, start,
			end, orderByComparator);
	}

	/**
	* Returns the first task assignment in the ordered set where taskId = &#63; and status = &#63;.
	*
	* @param taskId the task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment findByAssignmentsByTaskIdAndStatus_First(
		long taskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignmentsByTaskIdAndStatus_First(taskId, status,
			orderByComparator);
	}

	/**
	* Returns the first task assignment in the ordered set where taskId = &#63; and status = &#63;.
	*
	* @param taskId the task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByAssignmentsByTaskIdAndStatus_First(
		long taskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAssignmentsByTaskIdAndStatus_First(taskId, status,
			orderByComparator);
	}

	/**
	* Returns the last task assignment in the ordered set where taskId = &#63; and status = &#63;.
	*
	* @param taskId the task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment findByAssignmentsByTaskIdAndStatus_Last(
		long taskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignmentsByTaskIdAndStatus_Last(taskId, status,
			orderByComparator);
	}

	/**
	* Returns the last task assignment in the ordered set where taskId = &#63; and status = &#63;.
	*
	* @param taskId the task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching task assignment, or <code>null</code> if a matching task assignment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByAssignmentsByTaskIdAndStatus_Last(
		long taskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAssignmentsByTaskIdAndStatus_Last(taskId, status,
			orderByComparator);
	}

	/**
	* Returns the task assignments before and after the current task assignment in the ordered set where taskId = &#63; and status = &#63;.
	*
	* @param taskAssignmentId the primary key of the current task assignment
	* @param taskId the task ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment[] findByAssignmentsByTaskIdAndStatus_PrevAndNext(
		long taskAssignmentId, long taskId, java.lang.String status,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAssignmentsByTaskIdAndStatus_PrevAndNext(taskAssignmentId,
			taskId, status, orderByComparator);
	}

	/**
	* Removes all the task assignments where taskId = &#63; and status = &#63; from the database.
	*
	* @param taskId the task ID
	* @param status the status
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByAssignmentsByTaskIdAndStatus(long taskId,
		java.lang.String status)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByAssignmentsByTaskIdAndStatus(taskId, status);
	}

	/**
	* Returns the number of task assignments where taskId = &#63; and status = &#63;.
	*
	* @param taskId the task ID
	* @param status the status
	* @return the number of matching task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static int countByAssignmentsByTaskIdAndStatus(long taskId,
		java.lang.String status)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .countByAssignmentsByTaskIdAndStatus(taskId, status);
	}

	/**
	* Caches the task assignment in the entity cache if it is enabled.
	*
	* @param taskAssignment the task assignment
	*/
	public static void cacheResult(
		com.jioc.taskmanagement.model.TaskAssignment taskAssignment) {
		getPersistence().cacheResult(taskAssignment);
	}

	/**
	* Caches the task assignments in the entity cache if it is enabled.
	*
	* @param taskAssignments the task assignments
	*/
	public static void cacheResult(
		java.util.List<com.jioc.taskmanagement.model.TaskAssignment> taskAssignments) {
		getPersistence().cacheResult(taskAssignments);
	}

	/**
	* Creates a new task assignment with the primary key. Does not add the task assignment to the database.
	*
	* @param taskAssignmentId the primary key for the new task assignment
	* @return the new task assignment
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment create(
		long taskAssignmentId) {
		return getPersistence().create(taskAssignmentId);
	}

	/**
	* Removes the task assignment with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param taskAssignmentId the primary key of the task assignment
	* @return the task assignment that was removed
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment remove(
		long taskAssignmentId)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().remove(taskAssignmentId);
	}

	public static com.jioc.taskmanagement.model.TaskAssignment updateImpl(
		com.jioc.taskmanagement.model.TaskAssignment taskAssignment)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(taskAssignment);
	}

	/**
	* Returns the task assignment with the primary key or throws a {@link com.jioc.taskmanagement.NoSuchTaskAssignmentException} if it could not be found.
	*
	* @param taskAssignmentId the primary key of the task assignment
	* @return the task assignment
	* @throws com.jioc.taskmanagement.NoSuchTaskAssignmentException if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment findByPrimaryKey(
		long taskAssignmentId)
		throws com.jioc.taskmanagement.NoSuchTaskAssignmentException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPrimaryKey(taskAssignmentId);
	}

	/**
	* Returns the task assignment with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param taskAssignmentId the primary key of the task assignment
	* @return the task assignment, or <code>null</code> if a task assignment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.jioc.taskmanagement.model.TaskAssignment fetchByPrimaryKey(
		long taskAssignmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(taskAssignmentId);
	}

	/**
	* Returns all the task assignments.
	*
	* @return the task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the task assignments.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @return the range of task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the task assignments.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.jioc.taskmanagement.model.impl.TaskAssignmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of task assignments
	* @param end the upper bound of the range of task assignments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.jioc.taskmanagement.model.TaskAssignment> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the task assignments from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of task assignments.
	*
	* @return the number of task assignments
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static TaskAssignmentPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (TaskAssignmentPersistence)PortletBeanLocatorUtil.locate(com.jioc.taskmanagement.service.ClpSerializer.getServletContextName(),
					TaskAssignmentPersistence.class.getName());

			ReferenceRegistry.registerReference(TaskAssignmentUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(TaskAssignmentPersistence persistence) {
	}

	private static TaskAssignmentPersistence _persistence;
}