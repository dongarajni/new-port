/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jioc.taskmanagement.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link TaskAssignment}.
 * </p>
 *
 * @author rajnikant.donga
 * @see TaskAssignment
 * @generated
 */
public class TaskAssignmentWrapper implements TaskAssignment,
	ModelWrapper<TaskAssignment> {
	public TaskAssignmentWrapper(TaskAssignment taskAssignment) {
		_taskAssignment = taskAssignment;
	}

	@Override
	public Class<?> getModelClass() {
		return TaskAssignment.class;
	}

	@Override
	public String getModelClassName() {
		return TaskAssignment.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("taskAssignmentId", getTaskAssignmentId());
		attributes.put("taskId", getTaskId());
		attributes.put("assigneeTaskId", getAssigneeTaskId());
		attributes.put("assignByUserId", getAssignByUserId());
		attributes.put("assignToUserId", getAssignToUserId());
		attributes.put("status", getStatus());
		attributes.put("final_status", getFinal_status());
		attributes.put("achieved", getAchieved());
		attributes.put("modifiedBy", getModifiedBy());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long taskAssignmentId = (Long)attributes.get("taskAssignmentId");

		if (taskAssignmentId != null) {
			setTaskAssignmentId(taskAssignmentId);
		}

		Long taskId = (Long)attributes.get("taskId");

		if (taskId != null) {
			setTaskId(taskId);
		}

		Long assigneeTaskId = (Long)attributes.get("assigneeTaskId");

		if (assigneeTaskId != null) {
			setAssigneeTaskId(assigneeTaskId);
		}

		Long assignByUserId = (Long)attributes.get("assignByUserId");

		if (assignByUserId != null) {
			setAssignByUserId(assignByUserId);
		}

		Long assignToUserId = (Long)attributes.get("assignToUserId");

		if (assignToUserId != null) {
			setAssignToUserId(assignToUserId);
		}

		String status = (String)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String final_status = (String)attributes.get("final_status");

		if (final_status != null) {
			setFinal_status(final_status);
		}

		String achieved = (String)attributes.get("achieved");

		if (achieved != null) {
			setAchieved(achieved);
		}

		Long modifiedBy = (Long)attributes.get("modifiedBy");

		if (modifiedBy != null) {
			setModifiedBy(modifiedBy);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}
	}

	/**
	* Returns the primary key of this task assignment.
	*
	* @return the primary key of this task assignment
	*/
	@Override
	public long getPrimaryKey() {
		return _taskAssignment.getPrimaryKey();
	}

	/**
	* Sets the primary key of this task assignment.
	*
	* @param primaryKey the primary key of this task assignment
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_taskAssignment.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the task assignment ID of this task assignment.
	*
	* @return the task assignment ID of this task assignment
	*/
	@Override
	public long getTaskAssignmentId() {
		return _taskAssignment.getTaskAssignmentId();
	}

	/**
	* Sets the task assignment ID of this task assignment.
	*
	* @param taskAssignmentId the task assignment ID of this task assignment
	*/
	@Override
	public void setTaskAssignmentId(long taskAssignmentId) {
		_taskAssignment.setTaskAssignmentId(taskAssignmentId);
	}

	/**
	* Returns the task ID of this task assignment.
	*
	* @return the task ID of this task assignment
	*/
	@Override
	public long getTaskId() {
		return _taskAssignment.getTaskId();
	}

	/**
	* Sets the task ID of this task assignment.
	*
	* @param taskId the task ID of this task assignment
	*/
	@Override
	public void setTaskId(long taskId) {
		_taskAssignment.setTaskId(taskId);
	}

	/**
	* Returns the assignee task ID of this task assignment.
	*
	* @return the assignee task ID of this task assignment
	*/
	@Override
	public long getAssigneeTaskId() {
		return _taskAssignment.getAssigneeTaskId();
	}

	/**
	* Sets the assignee task ID of this task assignment.
	*
	* @param assigneeTaskId the assignee task ID of this task assignment
	*/
	@Override
	public void setAssigneeTaskId(long assigneeTaskId) {
		_taskAssignment.setAssigneeTaskId(assigneeTaskId);
	}

	/**
	* Returns the assign by user ID of this task assignment.
	*
	* @return the assign by user ID of this task assignment
	*/
	@Override
	public long getAssignByUserId() {
		return _taskAssignment.getAssignByUserId();
	}

	/**
	* Sets the assign by user ID of this task assignment.
	*
	* @param assignByUserId the assign by user ID of this task assignment
	*/
	@Override
	public void setAssignByUserId(long assignByUserId) {
		_taskAssignment.setAssignByUserId(assignByUserId);
	}

	/**
	* Returns the assign by user uuid of this task assignment.
	*
	* @return the assign by user uuid of this task assignment
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getAssignByUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignment.getAssignByUserUuid();
	}

	/**
	* Sets the assign by user uuid of this task assignment.
	*
	* @param assignByUserUuid the assign by user uuid of this task assignment
	*/
	@Override
	public void setAssignByUserUuid(java.lang.String assignByUserUuid) {
		_taskAssignment.setAssignByUserUuid(assignByUserUuid);
	}

	/**
	* Returns the assign to user ID of this task assignment.
	*
	* @return the assign to user ID of this task assignment
	*/
	@Override
	public long getAssignToUserId() {
		return _taskAssignment.getAssignToUserId();
	}

	/**
	* Sets the assign to user ID of this task assignment.
	*
	* @param assignToUserId the assign to user ID of this task assignment
	*/
	@Override
	public void setAssignToUserId(long assignToUserId) {
		_taskAssignment.setAssignToUserId(assignToUserId);
	}

	/**
	* Returns the assign to user uuid of this task assignment.
	*
	* @return the assign to user uuid of this task assignment
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getAssignToUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _taskAssignment.getAssignToUserUuid();
	}

	/**
	* Sets the assign to user uuid of this task assignment.
	*
	* @param assignToUserUuid the assign to user uuid of this task assignment
	*/
	@Override
	public void setAssignToUserUuid(java.lang.String assignToUserUuid) {
		_taskAssignment.setAssignToUserUuid(assignToUserUuid);
	}

	/**
	* Returns the status of this task assignment.
	*
	* @return the status of this task assignment
	*/
	@Override
	public java.lang.String getStatus() {
		return _taskAssignment.getStatus();
	}

	/**
	* Sets the status of this task assignment.
	*
	* @param status the status of this task assignment
	*/
	@Override
	public void setStatus(java.lang.String status) {
		_taskAssignment.setStatus(status);
	}

	/**
	* Returns the final_status of this task assignment.
	*
	* @return the final_status of this task assignment
	*/
	@Override
	public java.lang.String getFinal_status() {
		return _taskAssignment.getFinal_status();
	}

	/**
	* Sets the final_status of this task assignment.
	*
	* @param final_status the final_status of this task assignment
	*/
	@Override
	public void setFinal_status(java.lang.String final_status) {
		_taskAssignment.setFinal_status(final_status);
	}

	/**
	* Returns the achieved of this task assignment.
	*
	* @return the achieved of this task assignment
	*/
	@Override
	public java.lang.String getAchieved() {
		return _taskAssignment.getAchieved();
	}

	/**
	* Sets the achieved of this task assignment.
	*
	* @param achieved the achieved of this task assignment
	*/
	@Override
	public void setAchieved(java.lang.String achieved) {
		_taskAssignment.setAchieved(achieved);
	}

	/**
	* Returns the modified by of this task assignment.
	*
	* @return the modified by of this task assignment
	*/
	@Override
	public long getModifiedBy() {
		return _taskAssignment.getModifiedBy();
	}

	/**
	* Sets the modified by of this task assignment.
	*
	* @param modifiedBy the modified by of this task assignment
	*/
	@Override
	public void setModifiedBy(long modifiedBy) {
		_taskAssignment.setModifiedBy(modifiedBy);
	}

	/**
	* Returns the create date of this task assignment.
	*
	* @return the create date of this task assignment
	*/
	@Override
	public java.util.Date getCreateDate() {
		return _taskAssignment.getCreateDate();
	}

	/**
	* Sets the create date of this task assignment.
	*
	* @param createDate the create date of this task assignment
	*/
	@Override
	public void setCreateDate(java.util.Date createDate) {
		_taskAssignment.setCreateDate(createDate);
	}

	/**
	* Returns the modified date of this task assignment.
	*
	* @return the modified date of this task assignment
	*/
	@Override
	public java.util.Date getModifiedDate() {
		return _taskAssignment.getModifiedDate();
	}

	/**
	* Sets the modified date of this task assignment.
	*
	* @param modifiedDate the modified date of this task assignment
	*/
	@Override
	public void setModifiedDate(java.util.Date modifiedDate) {
		_taskAssignment.setModifiedDate(modifiedDate);
	}

	@Override
	public boolean isNew() {
		return _taskAssignment.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_taskAssignment.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _taskAssignment.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_taskAssignment.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _taskAssignment.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _taskAssignment.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_taskAssignment.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _taskAssignment.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_taskAssignment.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_taskAssignment.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_taskAssignment.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new TaskAssignmentWrapper((TaskAssignment)_taskAssignment.clone());
	}

	@Override
	public int compareTo(
		com.jioc.taskmanagement.model.TaskAssignment taskAssignment) {
		return _taskAssignment.compareTo(taskAssignment);
	}

	@Override
	public int hashCode() {
		return _taskAssignment.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.jioc.taskmanagement.model.TaskAssignment> toCacheModel() {
		return _taskAssignment.toCacheModel();
	}

	@Override
	public com.jioc.taskmanagement.model.TaskAssignment toEscapedModel() {
		return new TaskAssignmentWrapper(_taskAssignment.toEscapedModel());
	}

	@Override
	public com.jioc.taskmanagement.model.TaskAssignment toUnescapedModel() {
		return new TaskAssignmentWrapper(_taskAssignment.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _taskAssignment.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _taskAssignment.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_taskAssignment.persist();
	}

	@Override
	public java.lang.String getDescription() {
		return _taskAssignment.getDescription();
	}

	@Override
	public void setDescription(java.lang.String description) {
		_taskAssignment.setDescription(description);
	}

	@Override
	public long getTarget() {
		return _taskAssignment.getTarget();
	}

	@Override
	public void setTarget(long target) {
		_taskAssignment.setTarget(target);
	}

	@Override
	public java.lang.String getEmployeeFullName() {
		return _taskAssignment.getEmployeeFullName();
	}

	@Override
	public void setEmployeeFullName(java.lang.String employeeFullName) {
		_taskAssignment.setEmployeeFullName(employeeFullName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof TaskAssignmentWrapper)) {
			return false;
		}

		TaskAssignmentWrapper taskAssignmentWrapper = (TaskAssignmentWrapper)obj;

		if (Validator.equals(_taskAssignment,
					taskAssignmentWrapper._taskAssignment)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public TaskAssignment getWrappedTaskAssignment() {
		return _taskAssignment;
	}

	@Override
	public TaskAssignment getWrappedModel() {
		return _taskAssignment;
	}

	@Override
	public void resetOriginalValues() {
		_taskAssignment.resetOriginalValues();
	}

	private TaskAssignment _taskAssignment;
}