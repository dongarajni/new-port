package com.jioc.mydesk.util;

public class MyDeskConstants {

	
	public static final int IS_RESOLVER_TRUE = 1;
	public static final int OC_STATUS = 0;
	public static final int JOB_STATUS = 0;
	public static final String CAT_TYPE_OC = "OC";
	public static final String CAT_TYPE_JOB = "JOB";
}
