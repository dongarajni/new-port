package com.jioc.mydesk.controller;

import com.jioc.mydesk.util.MyDeskConstants;
import com.jioc.query.model.EMP_DETAILS;
import com.jioc.query.service.EMP_DETAILSLocalServiceUtil;
import com.jioc.taskmanagement.NoSuchTaskOcDetailsException;
import com.jioc.taskmanagement.model.TaskOcDetails;
import com.jioc.taskmanagement.service.TaskOcDetailsLocalServiceUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.util.bridges.mvc.MVCPortlet;

import java.io.IOException;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

/**
 * Portlet implementation class MyDesk
 */
public class MyDesk extends MVCPortlet {
 
	private static Log _log = LogFactoryUtil.getLog(MyDesk.class.getName());
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException, IOException{
		
		renderRequest.setAttribute("isRaiseQuery", renderRequest.getAttribute("isRaiseQuery"));
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		
		EMP_DETAILS empDetails = EMP_DETAILSLocalServiceUtil.getEmpDetailsByUserId(themeDisplay.getUserId());
		if(Validator.isNotNull(empDetails)){
			if(empDetails.getIS_RESOLVER() == MyDeskConstants.IS_RESOLVER_TRUE){
				renderRequest.setAttribute("isResolver", Boolean.TRUE.toString());
			}
			
			try {
				TaskOcDetails ocDetail = TaskOcDetailsLocalServiceUtil.getStatusbyOcAndCatType(empDetails.getDEPARTMENT(), MyDeskConstants.OC_STATUS, MyDeskConstants.CAT_TYPE_OC);
				if(Validator.isNotNull(ocDetail)){
					renderRequest.setAttribute("isOcDetail", Boolean.TRUE.toString());
				}
				TaskOcDetails jobDetail = TaskOcDetailsLocalServiceUtil.getStatusbyOcAndCatType(empDetails.getJOB(), MyDeskConstants.JOB_STATUS, MyDeskConstants.CAT_TYPE_JOB);
				if(Validator.isNotNull(jobDetail)){
					renderRequest.setAttribute("isJobDetail", Boolean.TRUE.toString());
				}
			} catch (NoSuchTaskOcDetailsException e) {
				_log.error("error occured while getting oc and job Details");
			} catch (SystemException e) {
				_log.error("error occured while getting oc and job Details");
			}
			
			
		}
		
		super.render(renderRequest, renderResponse);
	}

}
